import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;

// ═══════════════════════════════════════════════════════════
// 🎨 DESIGN SYSTEM — MERAH PREMIUM
// ═══════════════════════════════════════════════════════════
class AppColors {
  static const Color bg0 = Color(0xFF08080A);
  static const Color bg1 = Color(0xFF101014);
  static const Color bg2 = Color(0xFF17171C);
  static const Color bg3 = Color(0xFF1F1F26);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text1 = Color(0xFFE4E4E7);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);

  static const Color red = Color(0xFFEF4444);
  static const Color redLight = Color(0xFFF87171);
  static const Color redDark = Color(0xFFB91C1C);
  static const Color redGlow = Color(0x4DEF4444);

  static const Color blue = Color(0xFF3B82F6);
  static const Color green = Color(0xFF22C55E);
  static const Color orange = Color(0xFFF97316);
  static const Color purple = Color(0xFFA855F7);
  static const Color pink = Color(0xFFEC4899);
  static const Color cyan = Color(0xFF06B6D4);
}

// ═══════════════════════════════════════════════════════════
// 📱 TOOLS PAGE
// ═══════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _rainbowController;

  // Rainbow Merah-Putih
  static const List<Color> _rainbowColors = [
    Color(0xFFFFFFFF),
    Color(0xFFF87171),
    Color(0xFFEF4444),
    Color(0xFFB91C1C),
    Color(0xFFEF4444),
    Color(0xFFF87171),
    Color(0xFFFFFFFF),
  ];

  @override
  void initState() {
    super.initState();
    _rainbowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _rainbowController.dispose();
    super.dispose();
  }

  // ─── RAINBOW SHADER ───
  Shader _rainbowShader(Rect bounds) {
    final shift = _rainbowController.value;
    return LinearGradient(
      begin: Alignment(-1.0 + shift * 2, -0.5),
      end: Alignment(1.0 + shift * 2, 0.5),
      colors: _rainbowColors,
      stops: const [0.0, 0.16, 0.32, 0.5, 0.68, 0.84, 1.0],
    ).createShader(bounds);
  }

  Widget _rainbowText({
    required String text,
    required double fontSize,
    double letterSpacing = 1.0,
    TextAlign textAlign = TextAlign.start,
    int maxLines = 1,
  }) {
    return AnimatedBuilder(
      animation: _rainbowController,
      builder: (context, _) {
        return ShaderMask(
          shaderCallback: _rainbowShader,
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            textAlign: textAlign,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: fontSize,
              fontFamily: 'Orbitron',
              letterSpacing: letterSpacing,
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // DATA TOOLS — SEMUA DALAM GRID
  // ═══════════════════════════════════════════════════════════
  List<_ToolItem> _getAllTools(BuildContext context) {
    final tools = <_ToolItem>[];

    // DDoS Tools
    tools.add(_ToolItem(
      icon: Icons.flash_on,
      label: "Attack\nPanel",
      group: "DDoS",
      color: AppColors.red,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AttackPanel(
            sessionKey: widget.sessionKey,
            listDoos: widget.listDoos,
          ),
        ),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.dns,
      label: "Manage\nServer",
      group: "DDoS",
      color: AppColors.redLight,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
        ),
      ),
    ));

    // Network
    tools.add(_ToolItem(
      icon: Icons.newspaper_outlined,
      label: "Spam\nNGL",
      group: "Network",
      color: AppColors.blue,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => NglPage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.wifi_off,
      label: "WiFi\nKiller",
      group: "Network",
      color: AppColors.cyan,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => WifiKillerPage()),
      ),
    ));
    if (widget.userRole == "vip" || widget.userRole == "owner") {
      tools.add(_ToolItem(
        icon: Icons.router,
        label: "WiFi\nExternal",
        group: "Network",
        color: AppColors.cyan,
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
          ),
        ),
      ));
    }

    // OSINT
    tools.add(_ToolItem(
      icon: Icons.badge,
      label: "NIK\nDetail",
      group: "OSINT",
      color: AppColors.purple,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const NikCheckerPage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.domain,
      label: "Domain\nOSINT",
      group: "OSINT",
      color: AppColors.purple,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const DomainOsintPage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.person_search,
      label: "Phone\nLookup",
      group: "OSINT",
      color: AppColors.purple,
      onTap: () => _showComingSoon(context),
    ));
    tools.add(_ToolItem(
      icon: Icons.email,
      label: "Email\nOSINT",
      group: "OSINT",
      color: AppColors.purple,
      onTap: () => _showComingSoon(context),
    ));

    // Downloader
    tools.add(_ToolItem(
      icon: Icons.video_library,
      label: "TikTok\nDownloader",
      group: "Download",
      color: AppColors.pink,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.camera_alt,
      label: "Instagram\nDownloader",
      group: "Download",
      color: AppColors.pink,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
      ),
    ));

    // Utilities
    tools.add(_ToolItem(
      icon: Icons.qr_code,
      label: "QR\nGenerator",
      group: "Utilities",
      color: AppColors.orange,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const QrGeneratorPage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.security,
      label: "IP\nScanner",
      group: "Utilities",
      color: AppColors.orange,
      onTap: () => _showComingSoon(context),
    ));
    tools.add(_ToolItem(
      icon: Icons.network_check,
      label: "Port\nScanner",
      group: "Utilities",
      color: AppColors.orange,
      onTap: () => _showComingSoon(context),
    ));

    // Watch
    tools.add(_ToolItem(
      icon: Icons.live_tv,
      label: "Anime\nStreaming",
      group: "Watch",
      color: AppColors.green,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const HomeAnimePage()),
      ),
    ));
    tools.add(_ToolItem(
      icon: Icons.local_fire_department,
      label: "Hentai\nMedia",
      group: "Watch",
      color: AppColors.green,
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const hentai.HomeScreen()),
      ),
    ));

    // Quick
    tools.add(_ToolItem(
      icon: Icons.star_border,
      label: "Quick\nAccess",
      group: "Quick",
      color: AppColors.red,
      onTap: () => _showComingSoon(context),
    ));

    return tools;
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final tools = _getAllTools(context);

    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildBanner(),
              const SizedBox(height: 24),
              _buildSectionHeader(tools.length),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: tools.length,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.95,
                  ),
                  itemBuilder: (context, index) {
                    return _buildToolCard(tools[index]);
                  },
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _buildBanner() {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppColors.red.withOpacity(0.3), width: 2),
        ),
      ),
      child: SizedBox(
        height: 200,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/banner.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF1A0A0A), Color(0xFF08080A)],
                  ),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.4),
                    AppColors.red.withOpacity(0.15),
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
            ),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _rainbowText(
                    text: "Whisper Tools",
                    fontSize: 32,
                    letterSpacing: 2,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    "Tools Whisper",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      letterSpacing: 1.2,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _buildSectionHeader(int count) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 20,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [AppColors.red, Colors.transparent],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          _rainbowText(
            text: "Tools Whisper",
            fontSize: 18,
            letterSpacing: 1.2,
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.red.withOpacity(0.12),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: AppColors.red.withOpacity(0.3)),
            ),
            child: Text(
              "$count Items",
              style: const TextStyle(
                color: AppColors.redLight,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOOL CARD (KOTAK)
  // ═══════════════════════════════════════════════════════════
  Widget _buildToolCard(_ToolItem tool) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: tool.onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1A0A0A), Color(0xFF101014)],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppColors.red.withOpacity(0.25),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: AppColors.red.withOpacity(0.10),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Decorative glow di pojok kanan atas
              Positioned(
                top: -20,
                right: -20,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        AppColors.red.withOpacity(0.12),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              // Content
              Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Icon container
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            tool.color.withOpacity(0.18),
                            tool.color.withOpacity(0.08),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: tool.color.withOpacity(0.35),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: tool.color.withOpacity(0.2),
                            blurRadius: 10,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Icon(
                        tool.icon,
                        color: tool.color,
                        size: 20,
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Label
                    Text(
                      tool.label,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.text0,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.2,
                        height: 1.2,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 3),
                    // Group subtitle
                    Text(
                      tool.group,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppColors.text3.withOpacity(0.7),
                        fontSize: 9,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // COMING SOON
  // ═══════════════════════════════════════════════════════════
  void _showComingSoon(BuildContext context) {
    CustomPopup.show(
      context,
      title: "Coming Soon",
      message: "Fitur ini masih dalam tahap pengembangan.",
      icon: Icons.info_outline,
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 📌 MODEL TOOL ITEM
// ═══════════════════════════════════════════════════════════
class _ToolItem {
  final IconData icon;
  final String label;
  final String group;
  final Color color;
  final VoidCallback onTap;

  _ToolItem({
    required this.icon,
    required this.label,
    required this.group,
    required this.color,
    required this.onTap,
  });
}