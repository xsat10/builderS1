import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'miku_stories_section.dart'; // ✅ TAMBAHAN

// ============================================================
// 🎨 DESIGN SYSTEM — RED PREMIUM
// ============================================================
class AppColors {
  static const Color bg0 = Color(0xFF08080A);
  static const Color bg1 = Color(0xFF101014);
  static const Color bg2 = Color(0xFF17171C);
  static const Color bg3 = Color(0xFF1F1F26);
  static const Color bg4 = Color(0xFF2A2A33);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text1 = Color(0xFFE4E4E7);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);
  static const Color text4 = Color(0xFF52525B);

  static const Color accent = Color(0xFFEF4444);
  static const Color accentLight = Color(0xFFF87171);
  static const Color accentDark = Color(0xFFB91C1C);

  static const Color success = Color(0xFF22C55E);
  static const Color info = Color(0xFF3B82F6);
  static const Color warning = Color(0xFFF97316);
  static const Color purple = Color(0xFFA855F7);
  static const Color pink = Color(0xFFEC4899);
  static const Color cyan = Color(0xFF06B6D4);
  static const Color telegram = Color(0xFF229ED9);

  static const Color border1 = Color(0x0DFFFFFF);
  static const Color border2 = Color(0x14FFFFFF);
  static const Color border3 = Color(0x1FFFFFFF);
}

// ============================================================
// 📊 MODEL
// ============================================================
class BentoTile {
  final String title;
  final String sub;
  final IconData icon;
  final String color;
  final bool isWide;
  final VoidCallback onTap;

  BentoTile({
    required this.title,
    required this.sub,
    required this.icon,
    required this.color,
    this.isWide = false,
    required this.onTap,
  });
}

class NewsItem {
  final String tag;
  final String title;
  final String desc;
  final String image;

  NewsItem({
    required this.tag,
    required this.title,
    required this.desc,
    this.image = '',
  });
}

// ============================================================
// 📱 DASHBOARD PAGE
// ============================================================
class DashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const String API_BASE = 'http://freepanelbygua.panel-xsat.my.id:3655';
  static const String TELEGRAM_URL = 'https://t.me/informationqueen';

  // ✅ GlobalKey untuk trigger upload story dari luar
  final GlobalKey<MikuStoriesSectionState> _storiesKey =
      GlobalKey<MikuStoriesSectionState>();

  // --- Stats ---
  int statOnline = 0;
  int statActive = 0;
  int statDays = 30;

  // --- News ---
  late PageController _newsController;
  Timer? _newsTimer;
  int _currentNewsIndex = 0;

  // --- Bottom nav ---
  int _bottomNavIndex = 0;

  // --- News data default ---
  final List<NewsItem> newsList = [
    NewsItem(
      tag: 'UPDATE',
      title: 'Sistem Update Baru',
      desc: 'Perbaikan performa dan stabilitas server',
    ),
    NewsItem(
      tag: 'FITUR',
      title: 'Tools Eksklusif Ditambahkan',
      desc: 'Fitur baru untuk semua member premium',
    ),
    NewsItem(
      tag: 'INFO',
      title: 'Maintenance Mingguan',
      desc: 'Server maintenance setiap Minggu malam',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _newsController = PageController(viewportFraction: 0.82);
    _startNewsAutoScroll();
    _fetchStats();
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsController.dispose();
    super.dispose();
  }

  // ============================================================
  // 🕒 GREETING
  // ============================================================
  String getGreetingPeriod() {
    final h = DateTime.now().hour;
    if (h >= 4 && h < 6) return 'Subuh';
    if (h >= 6 && h < 11) return 'Pagi';
    if (h >= 11 && h < 15) return 'Siang';
    if (h >= 15 && h < 18) return 'Sore';
    return 'Malam';
  }

  // ============================================================
  // 📊 STATS
  // ============================================================
  Future<void> _fetchStats() async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    setState(() {
      statOnline = 1234;
      statActive = 567;
    });
  }

  // ============================================================
  // 📰 NEWS AUTO SCROLL
  // ============================================================
  void _startNewsAutoScroll() {
    _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_newsController.hasClients) return;
      _currentNewsIndex = (_currentNewsIndex + 1) % newsList.length;
      _newsController.animateToPage(
        _currentNewsIndex,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
    });
  }

  // ============================================================
  // 🎨 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 120),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTopbar(),
                  _buildHero(),
                  _buildStatsRow(),

                  // ══════════════════════════════════════════
                  // ✅ STORY SECTION — DITAMBAHKAN DI SINI
                  // ══════════════════════════════════════════
                  MikuStoriesSection(
                    key: _storiesKey,
                    username: widget.username,
                    role: widget.role,
                    sessionKey: widget.sessionKey,
                  ),
                  // ══════════════════════════════════════════

                  _buildBentoGrid(),
                  _buildNewsSection(),
                  _buildChatCard(),
                  _buildTelegramBanner(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔝 TOPBAR
  // ============================================================
  Widget _buildTopbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xBF08080A),
        border: Border(
          bottom: BorderSide(color: AppColors.border1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.accent, AppColors.accentDark],
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.4),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              FontAwesomeIcons.crown,
              color: Colors.white,
              size: 15,
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'WHISPER',
            style: TextStyle(
              color: AppColors.text0,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const Spacer(),
          _buildIconBtn(
            icon: FontAwesomeIcons.headset,
            onTap: () => _showAlert('Info', 'Contact'),
          ),
          const SizedBox(width: 8),
          _buildIconBtn(
            icon: FontAwesomeIcons.userCircle,
            onTap: () => _showAlert('Info', 'Profile'),
          ),
        ],
      ),
    );
  }

  Widget _buildIconBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppColors.bg2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border2),
        ),
        child: Icon(icon, color: AppColors.text1, size: 15),
      ),
    );
  }

  // ============================================================
  // 🎯 HERO
  // ============================================================
  Widget _buildHero() {
    return Stack(
      children: [
        Positioned(
          top: -100,
          right: -100,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.accent.withOpacity(0.15),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 24, 18, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Selamat ${getGreetingPeriod()},',
                style: const TextStyle(
                  color: AppColors.text2,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                widget.username.toUpperCase(),
                style: const TextStyle(
                  color: AppColors.text0,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1.2,
                  height: 1.1,
                ),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                children: [
                  _buildChipRole(),
                  _buildChipStatus(),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildChipRole() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(FontAwesomeIcons.crown,
              color: AppColors.accentLight, size: 11),
          const SizedBox(width: 6),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: AppColors.accentLight,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChipStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.success.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.success.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: AppColors.success, blurRadius: 8),
              ],
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            'ONLINE',
            style: TextStyle(
              color: AppColors.success,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 📊 STATS ROW
  // ============================================================
  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(
        children: [
          Expanded(child: _buildStatCard('$statOnline', 'ONLINE')),
          const SizedBox(width: 10),
          Expanded(child: _buildStatCard('$statActive', 'ACTIVE')),
          const SizedBox(width: 10),
          Expanded(child: _buildStatCard('$statDays', 'DAYS LEFT')),
        ],
      ),
    );
  }

  Widget _buildStatCard(String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border1),
      ),
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [AppColors.accentLight, AppColors.accentDark],
            ).createShader(bounds),
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                fontFamily: 'monospace',
                letterSpacing: -0.5,
                height: 1.1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.text4,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🎯 BENTO GRID
  // ============================================================
  Widget _buildBentoGrid() {
    final tiles = _getBentoTiles();

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 24, 18, 28),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[0])),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[1])),
              const SizedBox(width: 10),
              Expanded(child: _buildBentoTile(tiles[2])),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[3])),
              const SizedBox(width: 10),
              Expanded(child: _buildBentoTile(tiles[4])),
            ],
          ),
        ],
      ),
    );
  }

  List<BentoTile> _getBentoTiles() {
    return [
      BentoTile(
        title: 'Bug Sender',
        sub: 'Pairing & Config',
        icon: FontAwesomeIcons.bug,
        color: 'red',
        isWide: true,
        onTap: () => _showAlert('Info', 'Bug Sender'),
      ),
      BentoTile(
        title: 'Riwayat',
        sub: 'Histori Aktivitas',
        icon: FontAwesomeIcons.clockRotateLeft,
        color: 'blue',
        onTap: () => _showAlert('Info', 'Riwayat'),
      ),
      BentoTile(
        title: 'Profile',
        sub: 'Kelola Akun',
        icon: FontAwesomeIcons.user,
        color: 'green',
        onTap: () => _showAlert('Info', 'Profile'),
      ),
      BentoTile(
        title: 'Contact',
        sub: 'Support 24/7',
        icon: FontAwesomeIcons.headset,
        color: 'orange',
        onTap: () => _showAlert('Info', 'Contact'),
      ),
      BentoTile(
        title: 'Info',
        sub: 'Panduan App',
        icon: FontAwesomeIcons.circleInfo,
        color: 'purple',
        onTap: () => _showAlert('Info', 'Info'),
      ),
    ];
  }

  Widget _buildBentoTile(BentoTile tile) {
    final colorMap = {
      'red': [const Color(0xFF2A0A0A), const Color(0xFF150505), AppColors.accent],
      'blue': [const Color(0xFF0A152A), const Color(0xFF050A15), AppColors.info],
      'green': [const Color(0xFF0A2A15), const Color(0xFF05150A), AppColors.success],
      'orange': [const Color(0xFF2A150A), const Color(0xFF150A05), AppColors.warning],
      'purple': [const Color(0xFF1F0A2A), const Color(0xFF100515), AppColors.purple],
      'pink': [const Color(0xFF2A0A1F), const Color(0xFF15050F), AppColors.pink],
    };

    final colors = colorMap[tile.color]!;
    final accentColor = colors[2];

    return GestureDetector(
      onTap: tile.onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(minHeight: tile.isWide ? 100 : 110),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [colors[0], colors[1]],
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accentColor.withOpacity(0.2)),
        ),
        child: Stack(
          children: [
            Positioned(
              right: -30,
              bottom: -30,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.03),
                ),
              ),
            ),
            if (tile.isWide)
              Row(
                children: [
                  _buildBentoIcon(tile.icon, accentColor),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          tile.title.toUpperCase(),
                          style: const TextStyle(
                            color: AppColors.text0,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.3,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          tile.sub,
                          style: const TextStyle(
                            color: AppColors.text3,
                            fontSize: 11,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    FontAwesomeIcons.arrowRight,
                    color: AppColors.text3,
                    size: 14,
                  ),
                ],
              )
            else
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildBentoIcon(tile.icon, accentColor),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tile.title.toUpperCase(),
                        style: const TextStyle(
                          color: AppColors.text0,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tile.sub,
                        style: const TextStyle(
                          color: AppColors.text3,
                          fontSize: 11,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildBentoIcon(IconData icon, Color color) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Icon(icon, color: color, size: 19),
    );
  }

  // ============================================================
  // 📰 NEWS SECTION
  // ============================================================
  Widget _buildNewsSection() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildSectionTitle('Latest Update'),
                GestureDetector(
                  onTap: () => _showAlert('Info', 'Semua Berita'),
                  child: const Row(
                    children: [
                      Text(
                        'Semua',
                        style: TextStyle(
                          color: AppColors.accentLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(
                        FontAwesomeIcons.arrowRight,
                        color: AppColors.accentLight,
                        size: 10,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 180,
            child: PageView.builder(
              controller: _newsController,
              itemCount: newsList.length,
              onPageChanged: (i) => setState(() => _currentNewsIndex = i),
              itemBuilder: (ctx, i) => _buildNewsCard(newsList[i]),
            ),
          ),
          const SizedBox(height: 12),
          _buildNewsDots(),
        ],
      ),
    );
  }

  Widget _buildNewsCard(NewsItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF101014), Color(0xFF1A1A22)],
                ),
              ),
              child: Center(
                child: Icon(
                  FontAwesomeIcons.newspaper,
                  color: AppColors.text4.withOpacity(0.3),
                  size: 60,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.9),
                  ],
                  stops: const [0, 0.35, 1],
                ),
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      item.tag,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item.desc,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 11,
                      height: 1.4,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(newsList.length, (i) {
        final isActive = i == _currentNewsIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(horizontal: 2.5),
          width: isActive ? 18 : 5,
          height: 5,
          decoration: BoxDecoration(
            color: isActive ? AppColors.accent : AppColors.bg4,
            borderRadius: BorderRadius.circular(3),
          ),
        );
      }),
    );
  }

  // ============================================================
  // 💬 CHAT CARD
  // ============================================================
  Widget _buildChatCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Global Chat'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => _showAlert('Info', 'Global Chat'),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A0A15), Color(0xFF0A0A1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.purple.withOpacity(0.2)),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: -40,
                    right: -40,
                    child: Container(
                      width: 160,
                      height: 160,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            AppColors.purple.withOpacity(0.2),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _buildChatAvatars(),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Community Room',
                                  style: TextStyle(
                                    color: AppColors.text0,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.2,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: const BoxDecoration(
                                        color: AppColors.success,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: AppColors.success,
                                            blurRadius: 6,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Text(
                                      '1,234 online',
                                      style: TextStyle(
                                        color: AppColors.text3,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border1),
                        ),
                        child: const Text(
                          '"Ngobrol langsung dengan semua pengguna Whisper di satu ruangan."',
                          style: TextStyle(
                            color: AppColors.text2,
                            fontSize: 12,
                            height: 1.5,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: AppColors.purple.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.purple.withOpacity(0.3)),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Masuk ke ruang chat',
                              style: TextStyle(
                                color: Color(0xFFC084FC),
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Icon(
                              FontAwesomeIcons.arrowRight,
                              color: Color(0xFFC084FC),
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatAvatars() {
    final avatars = [
      ('S', const LinearGradient(colors: [Color(0xFFEF4444), Color(0xFFB91C1C)])),
      ('A', const LinearGradient(colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)])),
      ('M', const LinearGradient(colors: [Color(0xFF22C55E), Color(0xFF15803D)])),
      ('K', const LinearGradient(colors: [Color(0xFFF97316), Color(0xFFC2410C)])),
    ];

    return SizedBox(
      width: 4 * 26 + 14,
      height: 36,
      child: Stack(
        children: [
          ...List.generate(avatars.length, (i) {
            return Positioned(
              left: i * 26,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: avatars[i].$2,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.bg0, width: 2),
                ),
                child: Center(
                  child: Text(
                    avatars[i].$1,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            );
          }),
          Positioned(
            left: 4 * 26,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.bg3,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.bg0, width: 2),
              ),
              child: const Center(
                child: Text(
                  '+99',
                  style: TextStyle(
                    color: AppColors.text2,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ✈️ TELEGRAM BANNER
  // ============================================================
  Widget _buildTelegramBanner() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Community Hub'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => launchUrl(
              Uri.parse(TELEGRAM_URL),
              mode: LaunchMode.externalApplication,
            ),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0A1A2A), Color(0xFF050F1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                    color: AppColors.telegram.withOpacity(0.25)),
              ),
              child: Stack(
                children: [
                  Positioned(
                    right: -20,
                    top: -20,
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            AppColors.telegram.withOpacity(0.2),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF229ED9), Color(0xFF1E88E5)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.telegram.withOpacity(0.4),
                              blurRadius: 20,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: const Icon(
                          FontAwesomeIcons.telegram,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Join Telegram Channel',
                              style: TextStyle(
                                color: AppColors.text0,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Update eksklusif & support 24/7',
                              style: TextStyle(
                                color: AppColors.text3,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        FontAwesomeIcons.arrowRight,
                        color: Color(0xFF60A5FA),
                        size: 14,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🔽 BOTTOM NAV
  // ============================================================
  Widget _buildBottomNav() {
    return Positioned(
      left: 16,
      right: 16,
      bottom: 16,
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          color: AppColors.bg1.withOpacity(0.92),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 40,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Row(
          children: [
            _buildNavItem(0, FontAwesomeIcons.house, 'HOME'),
            _buildNavItem(1, FontAwesomeIcons.whatsapp, 'WA',
                onTap: _showWhatsAppMenu),
            // ✅ Tombol tengah → upload story
            _buildNavItem(2, FontAwesomeIcons.plus, 'STORY',
                onTap: () => _storiesKey.currentState?.uploadStory()),
            _buildNavItem(3, FontAwesomeIcons.bell, 'INFO',
                onTap: () => _showAlert('Info', 'Info')),
            _buildNavItem(4, FontAwesomeIcons.screwdriverWrench, 'TOOLS',
                onTap: () => _showAlert('Info', 'Tools')),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
    int index,
    IconData icon,
    String label, {
    VoidCallback? onTap,
  }) {
    final isActive = _bottomNavIndex == index;

    return Expanded(
      child: GestureDetector(
        onTap: onTap ?? () => setState(() => _bottomNavIndex = index),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isActive ? AppColors.accent : AppColors.text4,
              size: 18,
            ),
            const SizedBox(height: 3),
            AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: isActive ? 1 : 0,
              child: Text(
                label,
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 📋 WHATSAPP MENU (Bottom Sheet)
  // ============================================================
  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        decoration: const BoxDecoration(
          color: AppColors.bg1,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(top: BorderSide(color: AppColors.border2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.bg4,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF25D366).withOpacity(0.4),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(
                FontAwesomeIcons.whatsapp,
                color: Colors.white,
                size: 26,
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'WhatsApp Tools',
              style: TextStyle(
                color: AppColors.text0,
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Choose an action to perform',
              style: TextStyle(color: AppColors.text3, fontSize: 12),
            ),
            const SizedBox(height: 24),
            _buildSheetOption(
              icon: FontAwesomeIcons.bug,
              iconColor: AppColors.accent,
              title: 'WhatsApp Crash',
              sub: 'Send payloads & crash codes',
              onTap: () {
                Navigator.pop(ctx);
                _showAlert('Info', 'WhatsApp Crash');
              },
            ),
            const SizedBox(height: 10),
            _buildSheetOption(
              icon: FontAwesomeIcons.mobileScreen,
              iconColor: AppColors.success,
              title: 'Manage Sender',
              sub: 'Pair devices & manage sessions',
              onTap: () {
                Navigator.pop(ctx);
                _showAlert('Info', 'Manage Sender');
              },
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: AppColors.border2),
                  ),
                ),
                child: const Text(
                  'Cancel',
                  style: TextStyle(
                    color: AppColors.text2,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSheetOption({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String sub,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.bg2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border1),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: iconColor.withOpacity(0.25)),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: AppColors.text0,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    sub,
                    style: const TextStyle(
                      color: AppColors.text3,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              FontAwesomeIcons.chevronRight,
              color: AppColors.text4,
              size: 13,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 18,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.accent,
                AppColors.accent.withOpacity(0),
              ],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: AppColors.text0,
            fontSize: 13,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 380),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.bg1,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.border2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.info.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: AppColors.info.withOpacity(0.3)),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.circleInfo,
                    color: AppColors.info,
                    size: 26,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.text0,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  message,
                  style: const TextStyle(
                    color: AppColors.text2,
                    fontSize: 13,
                    height: 1.6,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: TextButton.styleFrom(
                      backgroundColor: AppColors.bg2,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                        side: const BorderSide(color: AppColors.border2),
                      ),
                    ),
                    child: const Text(
                      'OK',
                      style: TextStyle(
                        color: AppColors.text0,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'miku_stories_section.dart'; // ✅ TAMBAHAN

// ============================================================
// 🎨 DESIGN SYSTEM — RED PREMIUM
// ============================================================
class AppColors {
  static const Color bg0 = Color(0xFF08080A);
  static const Color bg1 = Color(0xFF101014);
  static const Color bg2 = Color(0xFF17171C);
  static const Color bg3 = Color(0xFF1F1F26);
  static const Color bg4 = Color(0xFF2A2A33);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text1 = Color(0xFFE4E4E7);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);
  static const Color text4 = Color(0xFF52525B);

  static const Color accent = Color(0xFFEF4444);
  static const Color accentLight = Color(0xFFF87171);
  static const Color accentDark = Color(0xFFB91C1C);

  static const Color success = Color(0xFF22C55E);
  static const Color info = Color(0xFF3B82F6);
  static const Color warning = Color(0xFFF97316);
  static const Color purple = Color(0xFFA855F7);
  static const Color pink = Color(0xFFEC4899);
  static const Color cyan = Color(0xFF06B6D4);
  static const Color telegram = Color(0xFF229ED9);

  static const Color border1 = Color(0x0DFFFFFF);
  static const Color border2 = Color(0x14FFFFFF);
  static const Color border3 = Color(0x1FFFFFFF);
}

// ============================================================
// 📊 MODEL
// ============================================================
class BentoTile {
  final String title;
  final String sub;
  final IconData icon;
  final String color;
  final bool isWide;
  final VoidCallback onTap;

  BentoTile({
    required this.title,
    required this.sub,
    required this.icon,
    required this.color,
    this.isWide = false,
    required this.onTap,
  });
}

class NewsItem {
  final String tag;
  final String title;
  final String desc;
  final String image;

  NewsItem({
    required this.tag,
    required this.title,
    required this.desc,
    this.image = '',
  });
}

// ============================================================
// 📱 DASHBOARD PAGE
// ============================================================
class DashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const String API_BASE = 'http://freepanelbygua.panel-xsat.my.id:3655';
  static const String TELEGRAM_URL = 'https://t.me/informationqueen';

  // ✅ GlobalKey untuk trigger upload story dari luar
  final GlobalKey<MikuStoriesSectionState> _storiesKey =
      GlobalKey<MikuStoriesSectionState>();

  // --- Stats ---
  int statOnline = 0;
  int statActive = 0;
  int statDays = 30;

  // --- News ---
  late PageController _newsController;
  Timer? _newsTimer;
  int _currentNewsIndex = 0;

  // --- Bottom nav ---
  int _bottomNavIndex = 0;

  // --- News data default ---
  final List<NewsItem> newsList = [
    NewsItem(
      tag: 'UPDATE',
      title: 'Sistem Update Baru',
      desc: 'Perbaikan performa dan stabilitas server',
    ),
    NewsItem(
      tag: 'FITUR',
      title: 'Tools Eksklusif Ditambahkan',
      desc: 'Fitur baru untuk semua member premium',
    ),
    NewsItem(
      tag: 'INFO',
      title: 'Maintenance Mingguan',
      desc: 'Server maintenance setiap Minggu malam',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _newsController = PageController(viewportFraction: 0.82);
    _startNewsAutoScroll();
    _fetchStats();
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsController.dispose();
    super.dispose();
  }

  // ============================================================
  // 🕒 GREETING
  // ============================================================
  String getGreetingPeriod() {
    final h = DateTime.now().hour;
    if (h >= 4 && h < 6) return 'Subuh';
    if (h >= 6 && h < 11) return 'Pagi';
    if (h >= 11 && h < 15) return 'Siang';
    if (h >= 15 && h < 18) return 'Sore';
    return 'Malam';
  }

  // ============================================================
  // 📊 STATS
  // ============================================================
  Future<void> _fetchStats() async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    setState(() {
      statOnline = 1234;
      statActive = 567;
    });
  }

  // ============================================================
  // 📰 NEWS AUTO SCROLL
  // ============================================================
  void _startNewsAutoScroll() {
    _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_newsController.hasClients) return;
      _currentNewsIndex = (_currentNewsIndex + 1) % newsList.length;
      _newsController.animateToPage(
        _currentNewsIndex,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
    });
  }

  // ============================================================
  // 🎨 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 120),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTopbar(),
                  _buildHero(),
                  _buildStatsRow(),

                  // ══════════════════════════════════════════
                  // ✅ STORY SECTION — DITAMBAHKAN DI SINI
                  // ══════════════════════════════════════════
                  MikuStoriesSection(
                    key: _storiesKey,
                    username: widget.username,
                    role: widget.role,
                    sessionKey: widget.sessionKey,
                  ),
                  // ══════════════════════════════════════════

                  _buildBentoGrid(),
                  _buildNewsSection(),
                  _buildChatCard(),
                  _buildTelegramBanner(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔝 TOPBAR
  // ============================================================
  Widget _buildTopbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xBF08080A),
        border: Border(
          bottom: BorderSide(color: AppColors.border1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.accent, AppColors.accentDark],
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent.withOpacity(0.4),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              FontAwesomeIcons.crown,
              color: Colors.white,
              size: 15,
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'WHISPER',
            style: TextStyle(
              color: AppColors.text0,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
            ),
          ),
          const Spacer(),
          _buildIconBtn(
            icon: FontAwesomeIcons.headset,
            onTap: () => _showAlert('Info', 'Contact'),
          ),
          const SizedBox(width: 8),
          _buildIconBtn(
            icon: FontAwesomeIcons.userCircle,
            onTap: () => _showAlert('Info', 'Profile'),
          ),
        ],
      ),
    );
  }

  Widget _buildIconBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppColors.bg2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border2),
        ),
        child: Icon(icon, color: AppColors.text1, size: 15),
      ),
    );
  }

  // ============================================================
  // 🎯 HERO
  // ============================================================
  Widget _buildHero() {
    return Stack(
      children: [
        Positioned(
          top: -100,
          right: -100,
          child: Container(
            width: 300,
            height: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppColors.accent.withOpacity(0.15),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 24, 18, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Selamat ${getGreetingPeriod()},',
                style: const TextStyle(
                  color: AppColors.text2,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                widget.username.toUpperCase(),
                style: const TextStyle(
                  color: AppColors.text0,
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1.2,
                  height: 1.1,
                ),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                children: [
                  _buildChipRole(),
                  _buildChipStatus(),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildChipRole() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.accent.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(FontAwesomeIcons.crown,
              color: AppColors.accentLight, size: 11),
          const SizedBox(width: 6),
          Text(
            widget.role.toUpperCase(),
            style: const TextStyle(
              color: AppColors.accentLight,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChipStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.success.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.success.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: AppColors.success, blurRadius: 8),
              ],
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            'ONLINE',
            style: TextStyle(
              color: AppColors.success,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 📊 STATS ROW
  // ============================================================
  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(
        children: [
          Expanded(child: _buildStatCard('$statOnline', 'ONLINE')),
          const SizedBox(width: 10),
          Expanded(child: _buildStatCard('$statActive', 'ACTIVE')),
          const SizedBox(width: 10),
          Expanded(child: _buildStatCard('$statDays', 'DAYS LEFT')),
        ],
      ),
    );
  }

  Widget _buildStatCard(String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border1),
      ),
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [AppColors.accentLight, AppColors.accentDark],
            ).createShader(bounds),
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                fontFamily: 'monospace',
                letterSpacing: -0.5,
                height: 1.1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: AppColors.text4,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🎯 BENTO GRID
  // ============================================================
  Widget _buildBentoGrid() {
    final tiles = _getBentoTiles();

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 24, 18, 28),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[0])),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[1])),
              const SizedBox(width: 10),
              Expanded(child: _buildBentoTile(tiles[2])),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildBentoTile(tiles[3])),
              const SizedBox(width: 10),
              Expanded(child: _buildBentoTile(tiles[4])),
            ],
          ),
        ],
      ),
    );
  }

  List<BentoTile> _getBentoTiles() {
    return [
      BentoTile(
        title: 'Bug Sender',
        sub: 'Pairing & Config',
        icon: FontAwesomeIcons.bug,
        color: 'red',
        isWide: true,
        onTap: () => _showAlert('Info', 'Bug Sender'),
      ),
      BentoTile(
        title: 'Riwayat',
        sub: 'Histori Aktivitas',
        icon: FontAwesomeIcons.clockRotateLeft,
        color: 'blue',
        onTap: () => _showAlert('Info', 'Riwayat'),
      ),
      BentoTile(
        title: 'Profile',
        sub: 'Kelola Akun',
        icon: FontAwesomeIcons.user,
        color: 'green',
        onTap: () => _showAlert('Info', 'Profile'),
      ),
      BentoTile(
        title: 'Contact',
        sub: 'Support 24/7',
        icon: FontAwesomeIcons.headset,
        color: 'orange',
        onTap: () => _showAlert('Info', 'Contact'),
      ),
      BentoTile(
        title: 'Info',
        sub: 'Panduan App',
        icon: FontAwesomeIcons.circleInfo,
        color: 'purple',
        onTap: () => _showAlert('Info', 'Info'),
      ),
    ];
  }

  Widget _buildBentoTile(BentoTile tile) {
    final colorMap = {
      'red': [const Color(0xFF2A0A0A), const Color(0xFF150505), AppColors.accent],
      'blue': [const Color(0xFF0A152A), const Color(0xFF050A15), AppColors.info],
      'green': [const Color(0xFF0A2A15), const Color(0xFF05150A), AppColors.success],
      'orange': [const Color(0xFF2A150A), const Color(0xFF150A05), AppColors.warning],
      'purple': [const Color(0xFF1F0A2A), const Color(0xFF100515), AppColors.purple],
      'pink': [const Color(0xFF2A0A1F), const Color(0xFF15050F), AppColors.pink],
    };

    final colors = colorMap[tile.color]!;
    final accentColor = colors[2];

    return GestureDetector(
      onTap: tile.onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        constraints: BoxConstraints(minHeight: tile.isWide ? 100 : 110),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [colors[0], colors[1]],
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accentColor.withOpacity(0.2)),
        ),
        child: Stack(
          children: [
            Positioned(
              right: -30,
              bottom: -30,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.03),
                ),
              ),
            ),
            if (tile.isWide)
              Row(
                children: [
                  _buildBentoIcon(tile.icon, accentColor),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          tile.title.toUpperCase(),
                          style: const TextStyle(
                            color: AppColors.text0,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.3,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          tile.sub,
                          style: const TextStyle(
                            color: AppColors.text3,
                            fontSize: 11,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    FontAwesomeIcons.arrowRight,
                    color: AppColors.text3,
                    size: 14,
                  ),
                ],
              )
            else
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildBentoIcon(tile.icon, accentColor),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tile.title.toUpperCase(),
                        style: const TextStyle(
                          color: AppColors.text0,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.3,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tile.sub,
                        style: const TextStyle(
                          color: AppColors.text3,
                          fontSize: 11,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildBentoIcon(IconData icon, Color color) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Icon(icon, color: color, size: 19),
    );
  }

  // ============================================================
  // 📰 NEWS SECTION
  // ============================================================
  Widget _buildNewsSection() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildSectionTitle('Latest Update'),
                GestureDetector(
                  onTap: () => _showAlert('Info', 'Semua Berita'),
                  child: const Row(
                    children: [
                      Text(
                        'Semua',
                        style: TextStyle(
                          color: AppColors.accentLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(
                        FontAwesomeIcons.arrowRight,
                        color: AppColors.accentLight,
                        size: 10,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 180,
            child: PageView.builder(
              controller: _newsController,
              itemCount: newsList.length,
              onPageChanged: (i) => setState(() => _currentNewsIndex = i),
              itemBuilder: (ctx, i) => _buildNewsCard(newsList[i]),
            ),
          ),
          const SizedBox(height: 12),
          _buildNewsDots(),
        ],
      ),
    );
  }

  Widget _buildNewsCard(NewsItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF101014), Color(0xFF1A1A22)],
                ),
              ),
              child: Center(
                child: Icon(
                  FontAwesomeIcons.newspaper,
                  color: AppColors.text4.withOpacity(0.3),
                  size: 60,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.9),
                  ],
                  stops: const [0, 0.35, 1],
                ),
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      item.tag,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item.desc,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 11,
                      height: 1.4,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(newsList.length, (i) {
        final isActive = i == _currentNewsIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(horizontal: 2.5),
          width: isActive ? 18 : 5,
          height: 5,
          decoration: BoxDecoration(
            color: isActive ? AppColors.accent : AppColors.bg4,
            borderRadius: BorderRadius.circular(3),
          ),
        );
      }),
    );
  }

  // ============================================================
  // 💬 CHAT CARD
  // ============================================================
  Widget _buildChatCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Global Chat'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => _showAlert('Info', 'Global Chat'),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A0A15), Color(0xFF0A0A1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.purple.withOpacity(0.2)),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: -40,
                    right: -40,
                    child: Container(
                      width: 160,
                      height: 160,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            AppColors.purple.withOpacity(0.2),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _buildChatAvatars(),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Community Room',
                                  style: TextStyle(
                                    color: AppColors.text0,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.2,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Container(
                                      width: 6,
                                      height: 6,
                                      decoration: const BoxDecoration(
                                        color: AppColors.success,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: AppColors.success,
                                            blurRadius: 6,
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Text(
                                      '1,234 online',
                                      style: TextStyle(
                                        color: AppColors.text3,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: AppColors.border1),
                        ),
                        child: const Text(
                          '"Ngobrol langsung dengan semua pengguna Whisper di satu ruangan."',
                          style: TextStyle(
                            color: AppColors.text2,
                            fontSize: 12,
                            height: 1.5,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: AppColors.purple.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.purple.withOpacity(0.3)),
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Masuk ke ruang chat',
                              style: TextStyle(
                                color: Color(0xFFC084FC),
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Icon(
                              FontAwesomeIcons.arrowRight,
                              color: Color(0xFFC084FC),
                              size: 12,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatAvatars() {
    final avatars = [
      ('S', const LinearGradient(colors: [Color(0xFFEF4444), Color(0xFFB91C1C)])),
      ('A', const LinearGradient(colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)])),
      ('M', const LinearGradient(colors: [Color(0xFF22C55E), Color(0xFF15803D)])),
      ('K', const LinearGradient(colors: [Color(0xFFF97316), Color(0xFFC2410C)])),
    ];

    return SizedBox(
      width: 4 * 26 + 14,
      height: 36,
      child: Stack(
        children: [
          ...List.generate(avatars.length, (i) {
            return Positioned(
              left: i * 26,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: avatars[i].$2,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.bg0, width: 2),
                ),
                child: Center(
                  child: Text(
                    avatars[i].$1,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            );
          }),
          Positioned(
            left: 4 * 26,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.bg3,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.bg0, width: 2),
              ),
              child: const Center(
                child: Text(
                  '+99',
                  style: TextStyle(
                    color: AppColors.text2,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // ✈️ TELEGRAM BANNER
  // ============================================================
  Widget _buildTelegramBanner() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle('Community Hub'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => launchUrl(
              Uri.parse(TELEGRAM_URL),
              mode: LaunchMode.externalApplication,
            ),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0A1A2A), Color(0xFF050F1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                    color: AppColors.telegram.withOpacity(0.25)),
              ),
              child: Stack(
                children: [
                  Positioned(
                    right: -20,
                    top: -20,
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            AppColors.telegram.withOpacity(0.2),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF229ED9), Color(0xFF1E88E5)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.telegram.withOpacity(0.4),
                              blurRadius: 20,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: const Icon(
                          FontAwesomeIcons.telegram,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Join Telegram Channel',
                              style: TextStyle(
                                color: AppColors.text0,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Update eksklusif & support 24/7',
                              style: TextStyle(
                                color: AppColors.text3,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        FontAwesomeIcons.arrowRight,
                        color: Color(0xFF60A5FA),
                        size: 14,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🔽 BOTTOM NAV
  // ============================================================
  Widget _buildBottomNav() {
    return Positioned(
      left: 16,
      right: 16,
      bottom: 16,
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          color: AppColors.bg1.withOpacity(0.92),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 40,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Row(
          children: [
            _buildNavItem(0, FontAwesomeIcons.house, 'HOME'),
            _buildNavItem(1, FontAwesomeIcons.whatsapp, 'WA',
                onTap: _showWhatsAppMenu),
            // ✅ Tombol tengah → upload story
            _buildNavItem(2, FontAwesomeIcons.plus, 'STORY',
                onTap: () => _storiesKey.currentState?.uploadStory()),
            _buildNavItem(3, FontAwesomeIcons.bell, 'INFO',
                onTap: () => _showAlert('Info', 'Info')),
            _buildNavItem(4, FontAwesomeIcons.screwdriverWrench, 'TOOLS',
                onTap: () => _showAlert('Info', 'Tools')),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
    int index,
    IconData icon,
    String label, {
    VoidCallback? onTap,
  }) {
    final isActive = _bottomNavIndex == index;

    return Expanded(
      child: GestureDetector(
        onTap: onTap ?? () => setState(() => _bottomNavIndex = index),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isActive ? AppColors.accent : AppColors.text4,
              size: 18,
            ),
            const SizedBox(height: 3),
            AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: isActive ? 1 : 0,
              child: Text(
                label,
                style: const TextStyle(
                  color: AppColors.accent,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 📋 WHATSAPP MENU (Bottom Sheet)
  // ============================================================
  void _showWhatsAppMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        decoration: const BoxDecoration(
          color: AppColors.bg1,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(top: BorderSide(color: AppColors.border2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.bg4,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF25D366).withOpacity(0.4),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(
                FontAwesomeIcons.whatsapp,
                color: Colors.white,
                size: 26,
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'WhatsApp Tools',
              style: TextStyle(
                color: AppColors.text0,
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Choose an action to perform',
              style: TextStyle(color: AppColors.text3, fontSize: 12),
            ),
            const SizedBox(height: 24),
            _buildSheetOption(
              icon: FontAwesomeIcons.bug,
              iconColor: AppColors.accent,
              title: 'WhatsApp Crash',
              sub: 'Send payloads & crash codes',
              onTap: () {
                Navigator.pop(ctx);
                _showAlert('Info', 'WhatsApp Crash');
              },
            ),
            const SizedBox(height: 10),
            _buildSheetOption(
              icon: FontAwesomeIcons.mobileScreen,
              iconColor: AppColors.success,
              title: 'Manage Sender',
              sub: 'Pair devices & manage sessions',
              onTap: () {
                Navigator.pop(ctx);
                _showAlert('Info', 'Manage Sender');
              },
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(ctx),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: AppColors.border2),
                  ),
                ),
                child: const Text(
                  'Cancel',
                  style: TextStyle(
                    color: AppColors.text2,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSheetOption({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String sub,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.bg2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border1),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: iconColor.withOpacity(0.25)),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: AppColors.text0,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    sub,
                    style: const TextStyle(
                      color: AppColors.text3,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              FontAwesomeIcons.chevronRight,
              color: AppColors.text4,
              size: 13,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 18,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppColors.accent,
                AppColors.accent.withOpacity(0),
              ],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title.toUpperCase(),
          style: const TextStyle(
            color: AppColors.text0,
            fontSize: 13,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 380),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.bg1,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.border2),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: AppColors.info.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: AppColors.info.withOpacity(0.3)),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.circleInfo,
                    color: AppColors.info,
                    size: 26,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.text0,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  message,
                  style: const TextStyle(
                    color: AppColors.text2,
                    fontSize: 13,
                    height: 1.6,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: TextButton.styleFrom(
                      backgroundColor: AppColors.bg2,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                        side: const BorderSide(color: AppColors.border2),
                      ),
                    ),
                    child: const Text(
                      'OK',
                      style: TextStyle(
                        color: AppColors.text0,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}