import 'dart:async';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;

  const DashboardPage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  static const String TELEGRAM_URL = 'https://t.me/informationqueen';

  int onlineCount = 1234;
  int activeCount = 567;

  late PageController _newsPageController;
  late AnimationController _rainbowController;
  Timer? _newsTimer;
  int _currentNewsIndex = 0;

  // FIX #1: Font family dikomen biar gak error kalo font gak ada
  // Ganti ke 'Roboto' / hapus fontFamily kalo lo gak punya font-nya
  static const String fontOrbitron = 'Orbitron'; // comment out kalo gak ada
  static const String fontMono = 'JetBrainsMono'; // comment out kalo gak ada

  final List<Map<String, String>> _newsList = [
    {
      'tag': 'UPDATE',
      'title': 'Sistem Update Baru',
      'desc': 'Perbaikan performa dan stabilitas server',
      'image': 'assets/images/news1.jpg',
    },
    {
      'tag': 'FITUR',
      'title': 'Tools Eksklusif Ditambahkan',
      'desc': 'Fitur baru untuk semua member premium',
      'image': 'assets/images/news2.jpg',
    },
    {
      'tag': 'INFO',
      'title': 'Maintenance Mingguan',
      'desc': 'Server maintenance setiap Minggu malam',
      'image': 'assets/images/news3.jpg',
    },
  ];

  @override
  void initState() {
    super.initState();

    _rainbowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _newsPageController = PageController(viewportFraction: 0.85);

    // FIX #1: Pakai Timer.periodic (bisa di-cancel)
    _newsTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (!mounted) return;
      if (!_newsPageController.hasClients) return;

      setState(() {
        _currentNewsIndex = (_currentNewsIndex + 1) % _newsList.length;
      });
      _newsPageController.animateToPage(
        _currentNewsIndex,
        duration: const Duration(milliseconds: 800),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _newsTimer?.cancel(); // FIX #1
    _rainbowController.dispose();
    _newsPageController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // RAINBOW SHADER
  // ═══════════════════════════════════════════════════════════
  static const List<Color> _rainbowColors = [
    Color(0xFFFFFFFF),
    Color(0xFFF87171),
    Color(0xFFEF4444),
    Color(0xFFB91C1C),
    Color(0xFFEF4444),
    Color(0xFFF87171),
    Color(0xFFFFFFFF),
  ];

  Shader _rainbowShader(Rect bounds) {
    final shift = _rainbowController.value;
    return LinearGradient(
      begin: Alignment(-1.0 + shift * 2, -0.5),
      end: Alignment(1.0 + shift * 2, 0.5),
      colors: _rainbowColors,
      stops: const [0.0, 0.16, 0.32, 0.5, 0.68, 0.84, 1.0],
    ).createShader(bounds);
  }

  Widget _rainbowText({
    required String text,
    required double fontSize,
    double letterSpacing = 1.0,
    TextAlign textAlign = TextAlign.start,
    int maxLines = 1,
  }) {
    return AnimatedBuilder(
      animation: _rainbowController,
      builder: (context, _) {
        return ShaderMask(
          shaderCallback: _rainbowShader,
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            textAlign: textAlign,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: fontSize,
              // FIX #1: Hapus fontFamily biar gak error kalo font gak ada
              letterSpacing: letterSpacing,
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════
  String _getGreeting() {
    final h = DateTime.now().hour;
    if (h >= 4 && h < 6) return 'Subuh';
    if (h >= 6 && h < 11) return 'Pagi';
    if (h >= 11 && h < 15) return 'Siang';
    if (h >= 15 && h < 18) return 'Sore';
    return 'Malam';
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'founder':
      case 'owner':
      case 'vip':
        return const Color(0xFFEF4444);
      case 'admin':
        return const Color(0xFF22C55E);
      case 'moderator':
        return const Color(0xFF3B82F6);
      case 'partner':
        return const Color(0xFFF97316);
      case 'reseller':
        return const Color(0xFFA855F7);
      default:
        return const Color(0xFF71717A);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF08080A),
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.only(bottom: 120),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTopbar(),
              _buildLiveStats(),
              _buildHeroBanner(),
              _buildGreetingWithInfoCard(),
              _buildMarquee(),
              _buildNewsSection(),
              _buildFeaturedCard(),
              _buildQuickActions(),
              _buildTrendingFeed(),
              _buildHorizontalMenu(),
              _buildTipsCard(),
              _buildGlobalChatCard(),
              _buildCommunityHub(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOPBAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: const BoxDecoration(
        color: Color(0xBF08080A),
        border: Border(bottom: BorderSide(color: Color(0x0DFFFFFF))),
      ),
      child: Row(
        children: [
          Expanded(
            child: _rainbowText(
              text: 'WHISPER LOW',
              fontSize: 18,
              letterSpacing: 2,
            ),
          ),
          _iconBtn(Icons.headset_mic_outlined, onTap: openContact),
          const SizedBox(width: 8),
          _iconBtn(FontAwesomeIcons.userCircle, onTap: openProfile),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: const Color(0xFF17171C),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0x14FFFFFF)),
        ),
        child: Icon(icon, color: const Color(0xFFE4E4E7), size: 16),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LIVE STATS BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildLiveStats() {
    return SizedBox(
      height: 60,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        children: [
          _liveChip('ONLINE $onlineCount', const Color(0xFF22C55E)),
          const SizedBox(width: 8),
          _liveChip('BUG SENT 89.4K', const Color(0xFFEF4444)),
          const SizedBox(width: 8),
          _liveChip('SERVER ONLINE', const Color(0xFF3B82F6)),
          const SizedBox(width: 8),
          _liveChip('PING 96ms', const Color(0xFFF97316)),
        ],
      ),
    );
  }

  Widget _liveChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF17171C),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x14FFFFFF)),
      ),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color, blurRadius: 8)],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              color: Color(0xFFE4E4E7),
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HERO BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _buildHeroBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      height: 180,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x4DEF4444), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.15),
            blurRadius: 40,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 32,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/banner.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF1A0A0A), Color(0xFF08080A)],
                  ),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.2),
                    const Color(0xFFEF4444).withOpacity(0.15),
                    Colors.black.withOpacity(0.85),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 20,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _rainbowText(
                    text: 'Whisper Low',
                    fontSize: 32,
                    letterSpacing: 2,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '© By Jaa Cool',
                    style: TextStyle(
                      color: Color(0xB3FFFFFF),
                      fontSize: 11,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // GREETING + INFO CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildGreetingWithInfoCard() {
    final roleColor = _getRoleColor(widget.role);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Selamat ${_getGreeting()}, ${widget.username.toUpperCase()}!!',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            width: 60,
            height: 4,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Colors.white, Color(0xFFEF4444)],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: roleColor.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.crown, color: roleColor, size: 11),
                const SizedBox(width: 6),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: roleColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          _buildInfoCard(),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A0A0A), Color(0xFF101014)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x40EF4444)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: const Color(0xFFEF4444).withOpacity(0.08),
            blurRadius: 40,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: const Color(0xFFEF4444).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFEF4444).withOpacity(0.2),
                      blurRadius: 16,
                    ),
                  ],
                ),
                child: const Icon(
                  FontAwesomeIcons.shieldHalved,
                  color: Color(0xFFF87171),
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Whisper System',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                    SizedBox(height: 3),
                    Row(
                      children: [
                        _PulseDot(),
                        SizedBox(width: 6),
                        Text(
                          'Server Online',
                          style: TextStyle(
                            color: Color(0xFF4ADE80),
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFEF4444).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3)),
                ),
                child: const Text(
                  'v1.0',
                  style: TextStyle(
                    color: Color(0xFFF87171),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          RichText(
            text: const TextSpan(
              style: TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 12,
                height: 1.6,
              ),
              children: [
                TextSpan(text: 'Selamat datang kembali di '),
                TextSpan(
                  text: 'Whisper Low',
                  style: TextStyle(color: Color(0xFFF87171), fontWeight: FontWeight.w700),
                ),
                TextSpan(
                    text: '. Kami hadir membawa pembaruan masif untuk sistem manajemen dan tools eksklusif.'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.only(top: 14),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Color(0x26EF4444))),
            ),
            child: Row(
              children: [
                _statItem('$onlineCount', 'ONLINE'),
                Container(
                    width: 1,
                    height: 24,
                    color: const Color(0x26EF4444)),
                _statItem('$activeCount', 'ACTIVE'),
                Container(
                    width: 1,
                    height: 24,
                    color: const Color(0x26EF4444)),
                _statItem('30d', 'EXPIRES'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statItem(String value, String label) {
    return Expanded(
      child: Column(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Colors.white, Color(0xFFEF4444)],
            ).createShader(bounds),
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.5,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF52525B),
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MARQUEE
  // ═══════════════════════════════════════════════════════════
  Widget _buildMarquee() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0x1FEF4444), Color(0x0AEF4444)],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x40EF4444)),
      ),
      child: Row(
        children: [
          const Icon(FontAwesomeIcons.bullhorn,
              color: Color(0xFFEF4444), size: 14),
          const SizedBox(width: 10),
          Expanded(
            child: SizedBox(
              height: 16,
              child: _MarqueeText(
                text:
                    'Update v1.0 telah rilis! Fitur baru: Global Chat & Bug Sender V2 - Server maintenance setiap Minggu 02:00 WIB - Join Telegram untuk update eksklusif',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NEWS CAROUSEL
  // ═══════════════════════════════════════════════════════════
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: _sectionHead(
            icon: Icons.newspaper,
            title: 'LATEST UPDATE',
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 170,
          child: PageView.builder(
            controller: _newsPageController,
            itemCount: _newsList.length,
            onPageChanged: (i) => setState(() => _currentNewsIndex = i),
            itemBuilder: (context, i) => _buildNewsCard(_newsList[i]),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_newsList.length, (i) {
            final isActive = i == _currentNewsIndex;
            return GestureDetector(
              onTap: () {
                setState(() => _currentNewsIndex = i);
                _newsPageController.animateToPage(
                  i,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: isActive ? 20 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: isActive ? const Color(0xFFEF4444) : const Color(0xFF1F1F26),
                  borderRadius: BorderRadius.circular(3),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: const Color(0xFFEF4444).withOpacity(0.6),
                            blurRadius: 12,
                          ),
                        ]
                      : null,
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildNewsCard(Map<String, String> news) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x4DEF4444), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              news['image']!,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF2A0A0A), Color(0xFF0A0A15)],
                  ),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.transparent,
                    Colors.black.withOpacity(0.95),
                  ],
                  stops: const [0.0, 0.4, 1.0],
                ),
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xE6EF4444),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      news['tag']!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    news['title']!,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    news['desc']!,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 11,
                      height: 1.4,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FEATURED CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildFeaturedCard() {
    return GestureDetector(
      onTap: openBugSender,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2A0A0A), Color(0xFF1A0A2A)],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0x59EF4444), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFEF4444).withOpacity(0.15),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              top: -50,
              right: -40,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFFEF4444).withOpacity(0.3),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0x33EF4444),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: const Color(0x66EF4444)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(FontAwesomeIcons.star,
                          color: Color(0xFFF87171), size: 9),
                      SizedBox(width: 5),
                      Text(
                        'FEATURED',
                        style: TextStyle(
                          color: Color(0xFFF87171),
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                _rainbowText(
                  text: 'Bug Sender Pro',
                  fontSize: 20,
                  letterSpacing: 0.5,
                ),
                const SizedBox(height: 6),
                const Text(
                  'Fitur paling powerful untuk mengirim payload ke target WhatsApp. Pairing device, manage sender, dan kontrol penuh.',
                  style: TextStyle(
                    color: Color(0xFFA1A1AA),
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0x26EF4444),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: const Color(0x66EF4444)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Coba Sekarang',
                        style: TextStyle(
                          color: Color(0xFFF87171),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(FontAwesomeIcons.arrowRight,
                          color: Color(0xFFF87171), size: 10),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // QUICK ACTIONS (BENTO GRID) - FIX: pakai Row + Expanded
  // ═══════════════════════════════════════════════════════════
  Widget _buildQuickActions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _sectionHead(icon: Icons.bolt, title: 'QUICK ACTIONS'),
          const SizedBox(height: 14),
          // FIX #2: Ganti GridView ke Row + Expanded biar gak overflow
          Row(
            children: [
              Expanded(
                child: _bentoTile(
                  icon: FontAwesomeIcons.bug,
                  title: 'Bug Sender',
                  sub: 'Pairing & Config',
                  color: const Color(0xFFEF4444),
                  onTap: openBugSender,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _bentoTile(
                  icon: FontAwesomeIcons.clockRotateLeft,
                  title: 'Riwayat',
                  sub: 'Histori Aktivitas',
                  color: const Color(0xFF3B82F6),
                  onTap: openRiwayat,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _bentoTile(
                  icon: FontAwesomeIcons.user,
                  title: 'Profile',
                  sub: 'Kelola Akun',
                  color: const Color(0xFF22C55E),
                  onTap: openProfile,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _bentoTile(
                  icon: FontAwesomeIcons.headset,
                  title: 'Contact',
                  sub: 'Support 24/7',
                  color: const Color(0xFFF97316),
                  onTap: openContact,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _bentoWideTile(
            icon: FontAwesomeIcons.circleInfo,
            title: 'Info & Bantuan',
            sub: 'Panduan Penggunaan App',
            color: const Color(0xFFA855F7),
            onTap: openInfo,
          ),
        ],
      ),
    );
  }

  Widget _bentoTile({
    required IconData icon,
    required String title,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        constraints: const BoxConstraints(minHeight: 110),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              color.withOpacity(0.08),
              const Color(0xFF101014),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Stack(
          children: [
            Positioned(
              right: -30,
              bottom: -30,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.03),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.3)),
                  ),
                  child: Icon(icon, color: color, size: 18),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title.toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      sub,
                      style: const TextStyle(
                        color: Color(0xFF71717A),
                        fontSize: 11,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _bentoWideTile({
    required IconData icon,
    required String title,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              color.withOpacity(0.08),
              const Color(0xFF101014),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    sub,
                    style: const TextStyle(
                      color: Color(0xFF71717A),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(FontAwesomeIcons.arrowRight,
                color: Color(0xFF71717A), size: 14),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TRENDING FEED
  // ═══════════════════════════════════════════════════════════
  Widget _buildTrendingFeed() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _sectionHead(icon: Icons.local_fire_department, title: 'TRENDING'),
          const SizedBox(height: 14),
          _feedItem(
            initial: 'S',
            name: 'Sammy',
            action: 'baru saja mengirim bug ke 25 target',
            time: '2 menit lalu',
            color: const Color(0xFFEF4444),
            onTap: openRiwayat,
          ),
          const SizedBox(height: 8),
          _feedItem(
            initial: 'A',
            name: 'Andi',
            action: 'upgrade ke role VIP',
            time: '15 menit lalu',
            color: const Color(0xFF3B82F6),
            onTap: openProfile,
          ),
          const SizedBox(height: 8),
          _feedItem(
            initial: 'K',
            name: 'Kyy',
            action: 'berhasil pairing 3 sender baru',
            time: '1 jam lalu',
            color: const Color(0xFF22C55E),
            onTap: openBugSender,
          ),
        ],
      ),
    );
  }

  Widget _feedItem({
    required String initial,
    required String name,
    required String action,
    required String time,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF17171C),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0x0DFFFFFF)),
        ),
        child: Row(
          children: [
            Stack(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [color, color.withOpacity(0.7)],
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      initial,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: const Color(0xFF4ADE80),
                      shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF17171C), width: 2),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        color: Color(0xFFE4E4E7),
                        fontSize: 12,
                        height: 1.4,
                      ),
                      children: [
                        TextSpan(
                          text: name,
                          style: const TextStyle(
                            color: Color(0xFFF87171),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        TextSpan(text: ' $action'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      const Icon(Icons.access_time,
                          color: Color(0xFF52525B), size: 10),
                      const SizedBox(width: 4),
                      Text(
                        time,
                        style: const TextStyle(
                          color: Color(0xFF52525B),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HORIZONTAL MENU
  // ═══════════════════════════════════════════════════════════
  Widget _buildHorizontalMenu() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: _sectionHead(icon: Icons.grid_view, title: 'MENU LAINNYA'),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 100,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              _hItem(FontAwesomeIcons.bug, 'Bug\nSender',
                  const Color(0xFFEF4444), openBugSender),
              _hItem(FontAwesomeIcons.clockRotateLeft, 'Riwayat',
                  const Color(0xFF3B82F6), openRiwayat),
              _hItem(FontAwesomeIcons.user, 'Profile',
                  const Color(0xFF22C55E), openProfile),
              _hItem(FontAwesomeIcons.headset, 'Contact',
                  const Color(0xFFF97316), openContact),
              _hItem(FontAwesomeIcons.circleInfo, 'Info',
                  const Color(0xFFA855F7), openInfo),
              _hItem(FontAwesomeIcons.comments, 'Global\nChat',
                  const Color(0xFF06B6D4), openGlobalChat),
              _hItem(FontAwesomeIcons.whatsapp, 'WhatsApp',
                  const Color(0xFFEC4899), openWhatsAppMenu),
              _hItem(FontAwesomeIcons.tableCells, 'Devices',
                  const Color(0xFFFBBF24), openDeviceDashboard),
            ],
          ),
        ),
      ],
    );
  }

  Widget _hItem(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF17171C),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0x14FFFFFF)),
        ),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.7)],
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 16),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFFA1A1AA),
                fontSize: 10,
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TIPS CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildTipsCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 24, 16, 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1A2A), Color(0xFF050F1A)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x4006B6D4)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0x2606B6D4),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0x4D06B6D4)),
            ),
            child: const Icon(Icons.lightbulb,
                color: Color(0xFF22D3EE), size: 18),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TIPS HARI INI',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.3,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Gunakan mode Global di Bug Sender untuk mengirim ke semua sender sekaligus - lebih efisien!',
                  style: TextStyle(
                    color: Color(0xFFA1A1AA),
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // GLOBAL CHAT CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildGlobalChatCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHead(icon: Icons.comments, title: 'GLOBAL CHAT'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: openGlobalChat,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A0A15), Color(0xFF0A0A1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0x40A855F7)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: const Color(0x26A855F7),
                          shape: BoxShape.circle,
                          border: Border.all(color: const Color(0x4DA855F7)),
                        ),
                        child: const Icon(FontAwesomeIcons.users,
                            color: Color(0xFFC084FC), size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Community Room',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            SizedBox(height: 3),
                            Row(
                              children: [
                                _PulseDot(color: Color(0xFF22C55E)),
                                SizedBox(width: 6),
                                Text(
                                  'Tap untuk masuk ke ruang chat',
                                  style: TextStyle(
                                    color: Color(0xFF71717A),
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0x1FA855F7),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0x4DA855F7)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Masuk ke ruang chat',
                          style: TextStyle(
                            color: Color(0xFFC084FC),
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                          ),
                        ),
                        Icon(FontAwesomeIcons.arrowRight,
                            color: Color(0xFFC084FC), size: 12),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // COMMUNITY HUB
  // ═══════════════════════════════════════════════════════════
  Widget _buildCommunityHub() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _sectionHead(icon: Icons.public, title: 'COMMUNITY HUB'),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: openTelegram,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0A1A2A), Color(0xFF050F1A)],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0x40229ED9)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF229ED9), Color(0xFF1E88E5)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF229ED9).withOpacity(0.4),
                          blurRadius: 20,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: const Icon(FontAwesomeIcons.telegram,
                        color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Join Telegram Channel',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Update eksklusif & support 24/7',
                          style: TextStyle(
                            color: Color(0xFF71717A),
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION HEAD
  // ═══════════════════════════════════════════════════════════
  Widget _sectionHead({
    required IconData icon,
    required String title,
  }) {
    return Row(
      children: [
        Container(
          width: 3.5,
          height: 20,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFEF4444), Colors.transparent],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Icon(icon, color: const Color(0xFFEF4444), size: 16),
        const SizedBox(width: 8),
        _rainbowText(text: title, fontSize: 14, letterSpacing: 1.2),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BOTTOM NAV
  // ═══════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xF217171C),
        border: Border(top: BorderSide(color: Color(0x14FFFFFF))),
      ),
      padding: EdgeInsets.only(
        top: 8,
        bottom: MediaQuery.of(context).padding.bottom + 8,
      ),
      child: Row(
        children: [
          _navItem(Icons.home, 'Home', true, () {}),
          _navItem(FontAwesomeIcons.whatsapp, 'WA', false, openWhatsAppMenu),
          _navItem(Icons.grid_view, 'Devices', false, openDeviceDashboard),
          _navItem(Icons.notifications_none, 'Info', false, openInfo),
          _navItem(Icons.build_circle_outlined, 'Tools', false, openTools),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, String label, bool active, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (active)
              Container(
                width: 24,
                height: 2,
                margin: const EdgeInsets.only(bottom: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFEF4444),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFEF4444).withOpacity(0.6),
                      blurRadius: 12,
                    ),
                  ],
                ),
              )
            else
              const SizedBox(height: 8),
            Icon(
              icon,
              color: active ? const Color(0xFFEF4444) : const Color(0xFF71717A),
              size: 18,
            ),
            const SizedBox(height: 3),
            Text(
              label.toUpperCase(),
              style: TextStyle(
                color: active ? const Color(0xFFEF4444) : const Color(0xFF71717A),
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NAVIGATION
  // ═══════════════════════════════════════════════════════════
  void openBugSender() => debugPrint('Bug Sender');
  void openRiwayat() => debugPrint('Riwayat');
  void openProfile() => debugPrint('Profile');
  void openContact() => debugPrint('Contact');
  void openInfo() => debugPrint('Info');
  void openGlobalChat() => debugPrint('Global Chat');
  void openWhatsAppMenu() => debugPrint('WhatsApp Menu');
  void openDeviceDashboard() => debugPrint('Device Dashboard');
  void openTools() => debugPrint('Tools');

  Future<void> openTelegram() async {
    final uri = Uri.parse(TELEGRAM_URL);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// PULSE DOT WIDGET
// ═══════════════════════════════════════════════════════════════
class _PulseDot extends StatefulWidget {
  final Color color;
  const _PulseDot({this.color = const Color(0xFF4ADE80)});

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) => Container(
        width: 6,
        height: 6,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.color.withOpacity(_controller.value * 0.8),
              blurRadius: 8,
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// MARQUEE TEXT WIDGET
// ═══════════════════════════════════════════════════════════════
class _MarqueeText extends StatefulWidget {
  final String text;
  const _MarqueeText({required this.text});

  @override
  State<_MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<_MarqueeText>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return LayoutBuilder(
          builder: (context, constraints) {
            return Transform.translate(
              offset: Offset(
                constraints.maxWidth * (1 - _controller.value * 2),
                0,
              ),
              child: Text(
                widget.text,
                style: const TextStyle(
                  color: Color(0xFFE4E4E7),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 1,
                overflow: TextOverflow.visible,
                softWrap: false,
              ),
            );
          },
        );
      },
    );
  }
}