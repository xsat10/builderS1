import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'partner_page.dart';
import 'set.dart';
import 'tap.dart';
import 'moderator_page.dart';
import 'widgets/custom_popup.dart';
import 'global_chat_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox.shrink();

  int onlineUsers = 0;
  int activeConnections = 0;

  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;
  VideoPlayerController? _videoController;

  // TEMA MERAH WHISPER LOW
  static const Color bgMain = Color(0xFF08080A);
  static const Color bgSurface = Color(0xFF17171C);
  static const Color bgCard = Color(0xFF1A0A0A);
  static const Color textMain = Color(0xFFFFFFFF);
  static const Color textSub = Color(0xFFA1A1AA);
  static const Color accentRed = Color(0xFFEF4444);
  static const Color accentRedDark = Color(0xFFB91C1C);

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initNewsBanner();
    _selectedPage = _buildHomePage();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      }).catchError((e) => debugPrint("Video error: $e"));

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _startClock();
  }

  void _startClock() {
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  // ============ UTILITY ============
  void _initNewsBanner() {
    _newsPageController = PageController(initialPage: 0, viewportFraction: 0.9);
    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });
    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (_newsPageController.hasClients) {
          int target = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(target,
              duration: const Duration(milliseconds: 800),
              curve: Curves.easeInOut);
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      androidId = deviceInfo.id;
      _connectToWebSocket();
    } catch (e) {
      debugPrint("Device error: $e");
    }
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse('ws://panelpakekwoingen.ajengfeb.my.id:2078'),
      );
      channel.sink
          .add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
      channel.sink.add(jsonEncode({"type": "stats"}));

      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Akun login di perangkat lain.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key tidak valid.");
          }
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (e) => debugPrint("WS Error: $e"));
    } catch (e) {
      debugPrint("WS Connect Error: $e");
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    CustomPopup.show(context,
        title: "Session Expired",
        message: message,
        icon: Icons.error_outline,
        iconColor: Colors.redAccent,
        confirmText: "OK", onConfirm: () {
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
    });
  }

  String _formatDate(DateTime d) {
    const days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return '${days[d.weekday - 1]}, ${d.day} ${months[d.month - 1]} ${d.year}';
  }

  String _formatTimeFull(DateTime d) {
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';
  }

  // ==================================================
  // HEADER ATAS (FIX: KASIH SPACE LEBIH)
  // ==================================================
  Widget _buildTopHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Baris 1: Burger + Title + Avatar
        Row(
          children: [
            GestureDetector(
              onTap: () => _showCustomDrawer(),
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: bgSurface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white10),
                ),
                child: const Icon(Icons.menu_rounded, color: textMain, size: 20),
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: accentRed.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentRed.withOpacity(0.4)),
              ),
              child: const Text("WHISPER",
                  style: TextStyle(
                      color: accentRed,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
            ),
            const SizedBox(width: 8),
            const Text("LOW",
                style: TextStyle(
                    color: textMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2)),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ProfilePage(
                          username: username,
                          password: password,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey))),
              child: Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: accentRed.withOpacity(0.5), width: 1.5),
                ),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : Container(
                          color: accentRed.withOpacity(0.15),
                          child: const Icon(Icons.person, color: accentRed, size: 20),
                        ),
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 28),

        // Baris 2: System Online + Tanggal
        Row(
          children: [
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: Colors.greenAccent,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: Colors.greenAccent.withOpacity(0.5),
                      blurRadius: 8,
                      spreadRadius: 1),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Text("SYSTEM ONLINE",
                style: TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5)),
            const Spacer(),
            Text(_formatDate(_now).toUpperCase(),
                style: const TextStyle(
                    color: textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5)),
          ],
        ),

        const SizedBox(height: 18),

        // Baris 3: JAM DIGITAL GEDE (FittedBox anti-overflow)
        SizedBox(
          width: double.infinity,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _formatTimeFull(_now),
              style: const TextStyle(
                color: textMain,
                fontSize: 46,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                letterSpacing: 3,
                shadows: [
                  Shadow(color: accentRed, blurRadius: 24, offset: Offset(0, 0)),
                ],
              ),
            ),
          ),
        ),

        const SizedBox(height: 16),

        // Baris 4: Badge SECURE + ONLINE USERS
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: bgSurface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentRed.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.lock_outline, color: accentRed, size: 14),
                  SizedBox(width: 6),
                  Text("SECURE",
                      style: TextStyle(
                          color: textMain,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1)),
                ],
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: const BoxDecoration(
                    color: Colors.greenAccent,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text("$onlineUsers ONLINE",
                    style: const TextStyle(
                        color: textMain,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1)),
              ],
            ),
          ],
        ),

        const SizedBox(height: 18),

        // Divider gradient
        Container(
          height: 3,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              accentRed.withOpacity(0),
              accentRed,
              accentRed.withOpacity(0),
            ]),
            borderRadius: BorderRadius.circular(2),
            boxShadow: [BoxShadow(color: accentRed.withOpacity(0.5), blurRadius: 10)],
          ),
        ),
      ],
    );
  }

  // ==================================================
  // STATUS CARD (BULAT)
  // ==================================================
  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accentRed.withOpacity(0.25)),
        boxShadow: [
          BoxShadow(
              color: accentRed.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 8)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                    color: accentRed.withOpacity(0.15), shape: BoxShape.circle),
                child: const Icon(Icons.brightness_1, color: accentRed, size: 12),
              ),
              const SizedBox(width: 10),
              const Text("WHISPER STATUS",
                  style: TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5)),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              _buildCircleButton(
                icon: Icons.person_add_alt_1,
                label: "My Status",
                subtitle: "Online",
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => ProfilePage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey))),
              ),
              const SizedBox(width: 16),
              _buildCircleButton(
                icon: Icons.play_arrow_rounded,
                label: "Device",
                subtitle: "Manage",
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            DeviceDashboardPage(sessionKey: sessionKey))),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCircleButton({
    required IconData icon,
    required String label,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [bgSurface, bgMain],
              ),
              border: Border.all(color: accentRed.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(
                    color: accentRed.withOpacity(0.3),
                    blurRadius: 16,
                    spreadRadius: 1),
              ],
            ),
            child: Center(
              child: Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accentRed.withOpacity(0.1),
                ),
                child: Icon(icon, color: accentRed, size: 24),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(label,
            style: const TextStyle(
                color: textMain, fontSize: 12, fontWeight: FontWeight.bold)),
        Text(subtitle,
            style: const TextStyle(
                color: textSub, fontSize: 10, fontFamily: 'ShareTechMono')),
      ],
    );
  }

  // ==================================================
  // BANNER BESAR (FIX: PLACEHOLDER KALAU GAMBAR GAK ADA)
  // ==================================================
  Widget _buildBigBanner() {
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => GlobalChatPage(
                  username: username,
                  sessionKey: sessionKey,
                  androidId: androidId))),
      child: Container(
        height: 200,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: accentRed.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // ============ GAMBAR / PLACEHOLDER ============
              Image.asset(
                'assets/images/banner.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF2A0A0A),
                        Color(0xFF1A0505),
                        Color(0xFF08080A),
                      ],
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.image_outlined,
                      color: accentRed.withOpacity(0.15),
                      size: 80,
                    ),
                  ),
                ),
              ),
              // Overlay gelap
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      bgMain.withOpacity(0.7),
                      bgMain.withOpacity(0.95),
                    ],
                  ),
                ),
              ),
              // Badge kiri atas
              Positioned(
                top: 16, left: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: bgMain.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentRed.withOpacity(0.5)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.bolt, color: accentRed, size: 14),
                      SizedBox(width: 4),
                      Text("WHISPER LOW",
                          style: TextStyle(
                              color: textMain,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1)),
                    ],
                  ),
                ),
              ),
              // Badge LIVE
              Positioned(
                top: 16, right: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: bgMain.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentRed.withOpacity(0.5)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6, height: 6,
                        decoration: const BoxDecoration(
                          color: accentRed,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(color: accentRed, blurRadius: 6),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text("LIVE",
                          style: TextStyle(
                              color: textMain,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1)),
                    ],
                  ),
                ),
              ),
              // Text bawah + tombol panah
              Positioned(
                bottom: 20, left: 20, right: 20,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Text("NEXT LEVEL EXPERIENCE",
                              style: TextStyle(
                                  color: textSub,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 2)),
                          SizedBox(height: 6),
                          Text("WHISPER\nLOW",
                              style: TextStyle(
                                  color: textMain,
                                  fontSize: 26,
                                  height: 1.1,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 2)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                            colors: [accentRed, accentRedDark]),
                        boxShadow: [
                          BoxShadow(
                              color: accentRed.withOpacity(0.5),
                              blurRadius: 12,
                              offset: const Offset(0, 4)),
                        ],
                      ),
                      child: const Icon(Icons.arrow_outward_rounded,
                          color: Colors.white, size: 22),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================================================
  // GLOBAL CHAT CARD
  // ==================================================
  Widget _buildGlobalChatCard() {
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => GlobalChatPage(
                  username: username,
                  sessionKey: sessionKey,
                  androidId: androidId))),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: accentRed.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [accentRed, accentRedDark]),
                boxShadow: [
                  BoxShadow(color: accentRed.withOpacity(0.4), blurRadius: 12),
                ],
              ),
              child: const Icon(Icons.public, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text("PUBLIC & GLOBAL",
                      style: TextStyle(
                          color: textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                  SizedBox(height: 2),
                  Text("Chat with all users",
                      style: TextStyle(
                          color: textSub,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: accentRed.withOpacity(0.15),
                border: Border.all(color: accentRed.withOpacity(0.4)),
              ),
              child: const Icon(Icons.chat_bubble, color: accentRed, size: 18),
            ),
          ],
        ),
      ),
    );
  }

  // ==================================================
  // WELCOME BACK CARD
  // ==================================================
  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentRed.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [accentRed, accentRedDark]),
              boxShadow: [
                BoxShadow(color: accentRed.withOpacity(0.5), blurRadius: 16),
              ],
            ),
            child: Center(
              child: Text(
                username.isNotEmpty ? username[0].toUpperCase() : "?",
                style: const TextStyle(
                    color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("WELCOME BACK",
                    style: TextStyle(
                        color: textSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 2)),
                const SizedBox(height: 2),
                Text(username.toUpperCase(),
                    style: const TextStyle(
                        color: textMain,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1)),
              ],
            ),
          ),
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.greenAccent.withOpacity(0.15),
              border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
            ),
            child: const Icon(Icons.verified, color: Colors.greenAccent, size: 18),
          ),
        ],
      ),
    );
  }

  // ==================================================
  // QUICK ACTIONS (HORIZONTAL)
  // ==================================================
  Widget _buildQuickActionsHorizontal() {
    final actions = [
      {"icon": Icons.bug_report_rounded, "label": "Bug Sender", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)))},
      {"icon": Icons.history_rounded, "label": "Riwayat", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)))},
      {"icon": Icons.person_rounded, "label": "Profile", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))},
      {"icon": Icons.contact_support_rounded, "label": "Kontak", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactPage()))},
      {"icon": Icons.info_rounded, "label": "Info", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => InfoPage(sessionKey: sessionKey)))},
      {"icon": Icons.mobile_screen_share_rounded, "label": "Device", "onTap": () => Navigator.push(context, MaterialPageRoute(builder: (_) => DeviceDashboardPage(sessionKey: sessionKey)))},
    ];

    return SizedBox(
      height: 100,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, i) {
          final a = actions[i];
          return Column(
            children: [
              GestureDetector(
                onTap: a["onTap"] as VoidCallback,
                child: Container(
                  width: 60, height: 60,
                  decoration: BoxDecoration(
                    color: bgCard,
                    shape: BoxShape.circle,
                    border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
                    boxShadow: [
                      BoxShadow(color: accentRed.withOpacity(0.15), blurRadius: 10),
                    ],
                  ),
                  child: Icon(a["icon"] as IconData, color: accentRed, size: 24),
                ),
              ),
              const SizedBox(height: 8),
              Text(a["label"] as String,
                  style: const TextStyle(
                      color: textMain, fontSize: 11, fontWeight: FontWeight.w600)),
            ],
          );
        },
      ),
    );
  }

  // ==================================================
  // JADWAL SHOLAT
  // ==================================================
  Widget _buildPrayerCard() {
    final prayerTimes = {
      'Subuh': '04:35', 'Dzuhur': '11:55', 'Ashar': '15:15',
      'Maghrib': '18:10', 'Isya': '19:25',
    };
    final now = _now;
    final currentMin = now.hour * 60 + now.minute;

    String nextPrayer = 'Subuh';
    int nextDiff = 99999;
    prayerTimes.forEach((name, time) {
      final parts = time.split(':');
      final pm = int.parse(parts[0]) * 60 + int.parse(parts[1]);
      int diff = pm - currentMin;
      if (diff < 0) diff += 24 * 60;
      if (diff < nextDiff) {
        nextDiff = diff;
        nextPrayer = name;
      }
    });

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.greenAccent.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.mosque, color: Colors.greenAccent, size: 16),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text("JADWAL SHOLAT",
                    style: TextStyle(
                        color: textMain,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1)),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text("MENUJU",
                      style: TextStyle(
                          color: textSub, fontSize: 9, letterSpacing: 1)),
                  Text(nextPrayer,
                      style: const TextStyle(
                          color: Colors.greenAccent,
                          fontSize: 12,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: prayerTimes.entries.map((e) {
              final isActive = e.key == nextPrayer;
              return Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
                  decoration: BoxDecoration(
                    color: isActive
                        ? accentRed.withOpacity(0.15)
                        : bgSurface.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isActive ? accentRed : Colors.transparent,
                      width: 1.5,
                    ),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                                color: accentRed.withOpacity(0.4), blurRadius: 10),
                          ]
                        : null,
                  ),
                  child: Column(
                    children: [
                      Text(e.key,
                          style: TextStyle(
                              color: isActive ? accentRed : textSub,
                              fontSize: 9,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text(e.value,
                          style: TextStyle(
                              color: isActive ? accentRed : textMain,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron')),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // ==================================================
  // SERVER STATUS
  // ==================================================
  Widget _buildServerStatus() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentRed.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accentRed.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.dns, color: accentRed, size: 16),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text("SERVER STATUS",
                    style: TextStyle(
                        color: textMain,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1)),
              ),
              Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                    color: Colors.greenAccent, shape: BoxShape.circle),
              ),
              const SizedBox(width: 6),
              const Text("ONLINE",
                  style: TextStyle(
                      color: Colors.greenAccent,
                      fontSize: 9,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 14),
          _buildProgressBar("CPU", 0.42, accentRed),
          const SizedBox(height: 10),
          _buildProgressBar("RAM", 0.68, const Color(0xFFA855F7)),
          const SizedBox(height: 10),
          _buildProgressBar("DISK", 0.35, Colors.orangeAccent),
        ],
      ),
    );
  }

  Widget _buildProgressBar(String label, double value, Color color) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: const TextStyle(
                    color: textSub, fontSize: 10, fontFamily: 'ShareTechMono')),
            Text("${(value * 100).toInt()}%",
                style: const TextStyle(
                    color: textMain, fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: value,
            minHeight: 6,
            backgroundColor: Colors.white10,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ],
    );
  }

  // ==================================================
  // NEWS SECTION
  // ==================================================
  Widget _buildNewsSection() {
    if (newsList.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Container(width: 3, height: 16, color: accentRed),
              const SizedBox(width: 8),
              const Text("INFORMASI TERBARU",
                  style: TextStyle(
                      color: textMain,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 150,
          child: PageView.builder(
            controller: _newsPageController,
            itemCount: newsList.length,
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: accentRed.withOpacity(0.3)),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item['image'] != null &&
                          item['image'].toString().isNotEmpty)
                        NewsMedia(url: item['image']),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withOpacity(0.9),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 12, left: 16, right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item['title'] ?? 'No Title',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Text(item['desc'] ?? '',
                                style: TextStyle(
                                    color: Colors.white.withOpacity(0.8),
                                    fontSize: 11),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ==================================================
  // HALAMAN UTAMA
  // ==================================================
  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: _buildTopHeader(),
          ),
          const SizedBox(height: 20),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildStatusCard(),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildBigBanner(),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildGlobalChatCard(),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildWelcomeCard(),
          ),
          const SizedBox(height: 20),

          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text("QUICK ACTIONS",
                style: TextStyle(
                    color: textMain,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5)),
          ),
          const SizedBox(height: 12),
          _buildQuickActionsHorizontal(),
          const SizedBox(height: 20),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildPrayerCard(),
          ),
          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildServerStatus(),
          ),
          const SizedBox(height: 20),

          _buildNewsSection(),
          const SizedBox(height: 20),

          // COMMUNITY HUB
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: bgSurface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("COMMUNITY HUB",
                      style: TextStyle(
                          color: textMain,
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 8),
                  Text(
                      "Tetap terhubung dengan komunitas Whisper. Dapatkan update real-time, akses payload eksklusif, dan ikuti diskusi.",
                      style: TextStyle(
                          color: textSub,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                          height: 1.5)),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(FontAwesomeIcons.telegram,
                          color: Colors.white, size: 16),
                      label: const Text("Join Telegram Channel",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF229ED9),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () => _openUrl("https://t.me/informationqueen"),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 100),
        ],
      ),
    );
  }

  // ==================================================
  // DRAWER (BOTTOM SHEET)
  // ==================================================
  void _showCustomDrawer() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                      color: textSub.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 20),
              _buildDrawerItem(Icons.workspace_premium, "Owner Page", () {
                Navigator.pop(context);
                setState(() => _selectedPage =
                    OwnerPage(sessionKey: sessionKey, username: username));
              }),
              _buildDrawerItem(Icons.history_rounded, "Riwayat Aktivitas", () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            RiwayatPage(sessionKey: sessionKey, role: role)));
              }),
              _buildDrawerItem(Icons.logout, "Log Out", () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false);
              }, isLogout: true),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String label, VoidCallback onTap,
      {bool isLogout = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: isLogout ? accentRed : textSub, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? accentRed : textMain,
                fontSize: 14,
                fontWeight: FontWeight.w600)),
        trailing: Icon(Icons.arrow_forward_ios, color: textSub, size: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
              color: isLogout ? accentRed.withOpacity(0.3) : Colors.white10),
        ),
      ),
    );
  }

  // ==================================================
  // BOTTOM NAV (FIX: ICON ONLY, ANTI OVERFLOW)
  // ==================================================
  void _onBottomNavTapped(int index) {
    if (index == 1) {
      _showWhatsAppMenu();
      return;
    }
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildHomePage();
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      }
    });
  }

  Widget _buildBottomNav() {
    return Padding(
      padding: EdgeInsets.only(
          left: 16, right: 16, bottom: 16 + MediaQuery.of(context).padding.bottom),
      child: Container(
        height: 70,
        decoration: BoxDecoration(
          color: bgSurface.withOpacity(0.97),
          borderRadius: BorderRadius.circular(35),
          border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: accentRed.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(0, Icons.home_rounded, "Home"),
            _buildNavItem(1, FontAwesomeIcons.whatsapp, "WA"),
            GestureDetector(
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          DeviceDashboardPage(sessionKey: sessionKey))),
              child: Container(
                width: 50, height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(colors: [accentRed, accentRedDark]),
                  boxShadow: [
                    BoxShadow(color: accentRed.withOpacity(0.6), blurRadius: 16),
                  ],
                ),
                child: const Icon(Icons.gauge_rounded, color: Colors.white, size: 22),
              ),
            ),
            _buildNavItem(2, Icons.notifications_rounded, "Info"),
            _buildNavItem(3, Icons.build_circle_rounded, "Tools"),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final isActive = _bottomNavIndex == index;
    return GestureDetector(
      onTap: () => _onBottomNavTapped(index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 60,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: isActive ? accentRed : textSub, size: 22),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(label,
                  style: TextStyle(
                      color: isActive ? accentRed : textSub,
                      fontSize: 9,
                      fontWeight: isActive ? FontWeight.bold : FontWeight.normal)),
            ),
          ],
        ),
      ),
    );
  }

  // ==================================================
  // WHATSAPP MENU DIALOG
  // ==================================================
  void _showWhatsAppMenu() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF25D366).withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(FontAwesomeIcons.whatsapp,
                      size: 32, color: Color(0xFF25D366)),
                ),
                const SizedBox(height: 16),
                const Text("WHATSAPP TOOLS",
                    style: TextStyle(
                        color: textMain,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1)),
                const SizedBox(height: 6),
                const Text("Pilih aksi yang ingin dilakukan",
                    style: TextStyle(color: textSub, fontSize: 12)),
                const SizedBox(height: 20),
                _buildWhatsAppOption(
                    Icons.bug_report, accentRed, "WhatsApp Crash", "Kirim payload", () {
                  Navigator.pop(context);
                  setState(() {
                    _bottomNavIndex = 1;
                    _selectedPage = HomePage(
                      username: username,
                      password: password,
                      listBug: listBug,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    );
                  });
                }),
                const SizedBox(height: 10),
                _buildWhatsAppOption(Icons.devices, Colors.greenAccent,
                    "Manage Sender", "Pair device", () {
                  Navigator.pop(context);
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => BugSenderPage(
                              sessionKey: sessionKey,
                              username: username,
                              role: role)));
                }),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Batal", style: TextStyle(color: textSub)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWhatsAppOption(
      IconData icon, Color color, String title, String subtitle, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.15), shape: BoxShape.circle),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          color: textMain,
                          fontSize: 13,
                          fontWeight: FontWeight.bold)),
                  Text(subtitle,
                      style: const TextStyle(color: textSub, fontSize: 11)),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios,
                color: color.withOpacity(0.5), size: 14),
          ],
        ),
      ),
    );
  }

  // ==================================================
  // BUILD UTAMA
  // ==================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: Stack(
        children: [
          Positioned.fill(
            child: FadeTransition(opacity: _animation, child: _selectedPage),
          ),
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: _buildBottomNav(),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _newsTimer?.cancel();
    _clockTimer?.cancel();
    _newsPageController.dispose();
    try {
      channel.sink.close(status.goingAway);
    } catch (_) {}
    _controller.dispose();
    super.dispose();
  }
}

// ================= NEWS MEDIA WIDGET =================
class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov")) {
      return Container(
        color: Colors.black,
        child: const Center(
            child: Icon(Icons.videocam_off, color: Colors.grey, size: 50)),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF1C1C1E),
        child: const Center(child: Icon(Icons.broken_image, color: Colors.grey)),
      ),
    );
  }
}