plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.x.xeternalz"
    compileSdk = 34  // ← FIX: turunkan ke 34
    
    // Hapus ndkVersion (biarkan default)
    
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17  // ← FIX: naikkan ke 17
        targetCompatibility = JavaVersion.VERSION_17  // ← FIX: naikkan ke 17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()  // ← FIX: naikkan ke 17
    }

    defaultConfig {
        applicationId = "com.x.xeternalz"
        minSdk = flutter.minSdkVersion  // biasanya 21
        targetSdk = 34  // ← FIX: turunkan ke 34
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }

    buildTypes {
        release {
            signingConfig = null  // ← Untuk debug, biarkan null, tapi untuk release harus ada signing
        }
    }
}

dependencies {
    // Hapus duplikat, biarkan Flutter mengelola
    implementation("androidx.multidex:multidex:2.0.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
    // Hapus semua implementation yang tidak perlu, karena Flutter sudah include
    // Hanya tambahkan yang benar-benar dibutuhkan
}

flutter {
    source = "../.."
}

// HAPUS block subprojects (berisiko)