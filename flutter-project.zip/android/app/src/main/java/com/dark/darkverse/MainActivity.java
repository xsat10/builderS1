package com.dark.darkverse;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.StatFs;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "stux_x_01/device_info";

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    if ("getDeviceStats".equals(call.method)) {
                        result.success(getDeviceStats());
                    } else {
                        result.notImplemented();
                    }
                });
    }

    private Map<String, Object> getDeviceStats() {
        Map<String, Object> data = new HashMap<>();

        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = 0;
        boolean charging = false;
        if (batteryIntent != null) {
            int current = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (current >= 0 && scale > 0) level = Math.round((current * 100f) / scale);
            int status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        }

        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(memoryInfo);
        long totalRam = memoryInfo.totalMem;
        long freeRam = memoryInfo.availMem;

        StatFs stat = new StatFs(getFilesDir().getAbsolutePath());
        long totalStorage = stat.getTotalBytes();
        long freeStorage = stat.getAvailableBytes();

        data.put("batteryLevel", level);
        data.put("isCharging", charging);
        data.put("deviceModel", Build.MANUFACTURER + " " + Build.MODEL);
        data.put("androidVersion", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        data.put("ramInfo", formatBytes(totalRam - freeRam) + " / " + formatBytes(totalRam));
        data.put("storageInfo", formatBytes(totalStorage - freeStorage) + " / " + formatBytes(totalStorage));
        data.put("networkInfo", getNetworkInfo());
        return data;
    }

    private String getNetworkInfo() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return "Offline";
        Network network = cm.getActiveNetwork();
        if (network == null) return "Offline";
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        if (caps == null) return "Online";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Mobile Data";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
        return "Online";
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0) return "0 MB";
        double mb = bytes / 1024d / 1024d;
        if (mb < 1024) return String.format(Locale.US, "%.0f MB", mb);
        return String.format(Locale.US, "%.1f GB", mb / 1024d);
    }
}
