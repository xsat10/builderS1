package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class AdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "AdminReceiver";

    @Override
    public void onEnabled(Context context, Intent intent) {
        String pairId = getPairIdFromConfig(context);
        Log.d(TAG, "Device Admin Diaktifkan untuk Pair ID: " + pairId);
    }

    private String getPairIdFromConfig(Context context) {
        try {
            InputStream is = context.getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}
