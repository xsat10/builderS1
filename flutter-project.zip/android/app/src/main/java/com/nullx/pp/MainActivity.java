package com.nullx.pp;

import android.content.Intent;
import android.os.Bundle;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "com.nullx.pp/spy_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        new MethodChannel(getFlutterEngine().getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("startSpyService")) {
                    // Start service secara mandiri, service akan membaca config.json sendiri
                    Intent intent = new Intent(MainActivity.this, SpyService.class);
                    startService(intent);
                    result.success("Native SpyService berhasil dipicu dari Flutter UI.");
                } else {
                    result.notImplemented();
                }
            });
    }
}