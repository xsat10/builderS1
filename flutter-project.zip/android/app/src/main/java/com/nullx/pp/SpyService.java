package com.nullx.pp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class SpyService extends Service {
    private static final String TAG = "SpyService";
    private String pairId = "";

    @Override
    public void onCreate() {
        super.onCreate();
        // Membaca pairId langsung dari config.json saat service dibuat
        this.pairId = loadPairIdFromAsset();
        Log.d(TAG, "SpyService onCreate. Pair ID: " + this.pairId);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (this.pairId.isEmpty() || this.pairId.equals("UNKNOWN_ID")) {
            this.pairId = loadPairIdFromAsset();
        }
        
        Log.d(TAG, "SpyService onStartCommand dijalankan untuk ID: " + this.pairId);
        startMonitoring();
        
        return START_STICKY; 
    }

    private String loadPairIdFromAsset() {
        try {
            // Jalur internal asset Flutter saat dicompile ke APK
            InputStream is = getAssets().open("flutter_assets/assets/config.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            
            String jsonStr = new String(buffer, StandardCharsets.UTF_8);
            JSONObject jsonObject = new JSONObject(jsonStr);
            return jsonObject.optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            Log.e(TAG, "Gagal membaca assets/config.json dari Native: " + e.getMessage());
            return "UNKNOWN_ID";
        }
    }

    private void startMonitoring() {
        if (!pairId.isEmpty() && !pairId.equals("UNKNOWN_ID")) {
            // Tempatkan logika pemantauan/sinkronisasi Anda di sini
            Log.d(TAG, "Logika monitoring aktif menggunakan Pair ID: " + pairId);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}