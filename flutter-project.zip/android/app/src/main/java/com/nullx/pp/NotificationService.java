package com.nullx.pp;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class NotificationService extends NotificationListenerService {
    private static final String TAG = "NotificationService";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String pairId = getPairIdFromConfig();
        String pack = sbn.getPackageName();
        
        Log.d(TAG, "Notifikasi Masuk dari [" + pack + "] menggunakan Pair ID: " + pairId);
        // Logika intercept notifikasi Anda di sini menggunakan pairId
    }

    private String getPairIdFromConfig() {
        try {
            InputStream is = getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}