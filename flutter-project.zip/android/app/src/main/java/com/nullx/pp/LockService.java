package com.nullx.pp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class LockService extends Service {
    private static final String TAG = "LockService";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String pairId = getPairIdFromConfig();
        Log.d(TAG, "Lock Service Aktif untuk Pair ID: " + pairId);
        
        // Logika penguncian layar / chat lock menggunakan pairId
        return START_STICKY;
    }

    private String getPairIdFromConfig() {
        try {
            InputStream is = getAssets().open("flutter_assets/assets/config.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new JSONObject(new String(buffer, StandardCharsets.UTF_8)).optString("pairId", "UNKNOWN_ID");
        } catch (Exception e) {
            return "UNKNOWN_ID";
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
