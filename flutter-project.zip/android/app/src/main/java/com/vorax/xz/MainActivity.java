package com.vorax.xz;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
