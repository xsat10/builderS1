// android/app/src/main/kotlin/com/smsgateway/app/MainActivity.kt
package com.smsgateway.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()