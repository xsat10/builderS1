// android/app/src/main/kotlin/com/smsgateway/app/SmsReceiver.kt
package com.smsgateway.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class SmsReceiver : BroadcastReceiver() {
    companion object {
        // GANTI ke port HTTP NAT VPS Anda (BUKAN 27239 / port SSH)
        private const val SERVER_HOST = "66.33.22.220"
        private const val SERVER_PORT = 8080
        private const val API_PATH = "/api/sms"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val sender = sms.originatingAddress ?: "unknown"
                val body = sms.messageBody ?: ""
                val ts = System.currentTimeMillis()
                Thread { sendToServer(context, sender, body, ts) }.start()
            }
        } catch (e: Exception) {
            Log.e("SmsReceiver", "err: ${e.message}")
        }
    }

    private fun sendToServer(context: Context, sender: String, body: String, ts: Long) {
        try {
            val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            val deviceId = prefs.getString("flutter.device_id", "unknown") ?: "unknown"

            val url = URL("http://$SERVER_HOST:$SERVER_PORT$API_PATH")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 15000

            val json = JSONObject().apply {
                put("device_id", deviceId)
                put("sender", sender)
                put("body", body)
                put("timestamp", ts)
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(json.toString())
            writer.flush()
            writer.close()
            conn.responseCode
            conn.disconnect()
        } catch (e: Exception) {
            Log.e("SmsReceiver", "send err: ${e.message}")
        }
    }
}