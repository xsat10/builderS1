package com.novaguard.novaguard_control

import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.novaguard.novaguard_control/device"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "androidId" -> {
                    // ANDROID_ID: stabil per perangkat + tanda tangan app; bertahan
                    // walau app di-reinstall. Digunakan utk 1 HP = 1 akun.
                    try {
                        val id = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
                        result.success(id)
                    } catch (e: Exception) {
                        result.error("DEVICE_ERROR", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }
}
