package com.example.analyze_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
