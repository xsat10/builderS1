import org.gradle.api.file.Directory  // ← TAMBAHKAN IMPORT

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.1.4")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22")  // ← Update ke 1.9.22
        // HAPUS desugar_jdk_libs dari sini
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// Pengaturan build dir (opsional, boleh dipertahankan)
val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
    // HAPUS evaluationDependsOn - tidak perlu
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}