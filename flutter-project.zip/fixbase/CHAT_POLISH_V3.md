# Chat Polish V3

- Voice notes now record as WAV/PCM for reliable Android playback.
- Audio playback forces full volume and keeps the existing player flow.
- Global and Private chat visual/media handlers remain intact.
- Profile, edit/delete, photo/video, call and VC flows are preserved.
- private_call_page.dart was not modified.
