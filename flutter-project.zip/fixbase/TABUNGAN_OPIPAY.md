# Modul Tabungan + OpiPay QRIS

Ditambahkan tanpa menghapus modul lama.

## Setup API
Salin `.env.example` menjadi `.env` dan isi `OPIPAY_API_KEY` dari akun merchant OpiPay. API key hanya berada di backend, tidak di APK.

Deposit memakai endpoint OpiPay QRIS create/status. Penarikan dibuat sebagai request pending dan membutuhkan approval admin/owner; modul ini tidak mengarang payout OpiPay karena dokumentasi yang tersedia pada saat integrasi hanya mendokumentasikan QRIS create/status/image.

## APK
Menu **Tabungan** ditambahkan di drawer Dashboard. Fitur: saldo, deposit QRIS, polling status pembayaran, withdraw request, dan riwayat transaksi.
