# DARK LIGHT — Chat Media/VN Fix

- Global chat: foto, video, file, dan VN/audio via `/api/chat/upload`.
- Private chat: foto, video, file, dan VN/audio via `/api/chat/private/upload`.
- Private voice/video call code was not modified.
- VN uses the `record` package and tap-to-start/tap-to-stop behavior.
- Run `flutter pub get` before release build.
