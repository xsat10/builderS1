CHAT PROFILE + WHATSAPP STYLE FINAL

- Global chat: tap a participant avatar/name to view display name, username, bio and role.
- Private chat: tap conversation header or info icon to view profile.
- Passwords, session keys and secrets are never exposed by profile viewer endpoints.
- All accounts can edit their chat profile (display name, bio/about, avatar).
- Global messages are enriched with the current profile avatar/display name/about.
- Existing text/media/VN/edit/delete and private call/VC code is retained.
