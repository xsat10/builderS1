WhatsApp Premium Chat Rework
============================
Visual-only polish for Global Chat and Private Chat.

Preserved: text, edit/delete, profile, image, video, voice note, file, playback,
private call, private VC, socket/polling and existing API handlers.

Call/VC implementation file was not modified.
