DARK LIGHT const-fix
====================
Fixed lib/private_chat_page.dart:
- Removed const from the InputDecoration containing the runtime isRecordingVoice hintText.
- This resolves: Not a constant expression / isRecordingVoice.

No call/VC files were modified.
