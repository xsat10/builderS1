import 'package:flutter/material.dart';
import 'global_chat_page.dart';
import 'private_chat_page.dart';

class ChatRoomPage extends StatelessWidget {
  final String username;
  final String sessionKey;
  const ChatRoomPage({super.key, required this.username, required this.sessionKey});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050A12),
      appBar: AppBar(
        title: const Text('CHAT CENTER'),
        backgroundColor: const Color(0xFF0A1525),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _ChatChoice(
            icon: Icons.public_rounded,
            title: 'Chat Global',
            subtitle: 'Ngobrol dengan semua pengguna di room global',
            color: const Color(0xFF3B82F6),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => GlobalChatPage(username: username, sessionKey: sessionKey),
            )),
          ),
          const SizedBox(height: 14),
          _ChatChoice(
            icon: Icons.lock_rounded,
            title: 'Chat Privat',
            subtitle: 'Pilih user terdaftar dan kirim pesan, foto, video, atau file',
            color: const Color(0xFF8B5CF6),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => PrivateChatPage(username: username, sessionKey: sessionKey),
            )),
          ),
        ],
      ),
    );
  }
}

class _ChatChoice extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _ChatChoice({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFF0E1E35),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: color.withOpacity(.35))),
    child: InkWell(
      borderRadius: BorderRadius.circular(22), onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(children: [
          CircleAvatar(radius: 28, backgroundColor: color.withOpacity(.16), child: Icon(icon, color: color, size: 28)),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(height: 5),
            Text(subtitle, style: TextStyle(color: Colors.grey[400], height: 1.3)),
          ])),
          const Icon(Icons.chevron_right_rounded, color: Colors.white54),
        ]),
      ),
    ),
  );
}
