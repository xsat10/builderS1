class UserPreferencesData {
  UserPreferencesData();
}

class UserPreferences {
  static Future<UserPreferencesData> getUserPreferences() async {
    return UserPreferencesData();
  }
}
