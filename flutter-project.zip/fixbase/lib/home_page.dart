import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late VideoPlayerController _bannerController;
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  final targetController = TextEditingController();
  
  final PageController _bugPageController = PageController(viewportFraction: 0.85);
  
  final PageController _imagePageController = PageController();
  Timer? _imageSliderTimer;
  int _currentImagePage = 0;

  final List<String> _sliderImages = [
    'assets/images/ornes_2.png',
    'assets/images/ornes_1.png',
  ];

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage; 
  int _currentBugPage = 0;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;

  String _selectedSender = 'private';

  final Color _candyApple = const Color(0xFFFF0800);  
  final Color _candyDark = const Color(0xFFB30000);  
  final Color _greenAccent = const Color(0xFFEAECEE); 
  final Color _textWhite = Colors.white;
  final Color _textGrey = const Color(0xFF9AA0A6);   

  String _typedText = "";
  int _typeIndex = 0;
  bool _isDeleting = false;
  Timer? _typeTimer;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    final allowedRoles = ['owner', 'admin', 'developer', 'tk', 'moderator', 'panther', 'reseller', 'vip'];
    return allowedRoles.contains(r);
  }

  @override
  void initState() {
    super.initState();

    _bannerController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _bannerController.setLooping(true);
        _bannerController.setVolume(1.0);
        _bannerController.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _fetchSenderStats();
    _loadGlobalSenders();
    
    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
    });

    _imageSliderTimer = Timer.periodic(const Duration(seconds: 3), (Timer timer) {
      if (_imagePageController.hasClients) {
        if (_currentImagePage < _sliderImages.length - 1) {
          _currentImagePage++;
        } else {
          _currentImagePage = 0;
        }
        _imagePageController.animateToPage(
          _currentImagePage,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOutCubic,
        );
      }
    });

    if (widget.listBug.isNotEmpty) {
      final firstBug = widget.listBug[0];
      _selectedBugId = firstBug['bug_id'] as String? ?? '0';
    }

    _startTypewriter();
  }

  void _startTypewriter() {
    const fullText = "ZIXTER NIGHT V8.0.0";
    _typeTimer?.cancel();
    _typeIndex = 0;
    _isDeleting = false;
    _typedText = "";
    
    _typeTimer = Timer.periodic(const Duration(milliseconds: 120), (timer) {
      setState(() {
        if (!_isDeleting) {
          if (_typeIndex < fullText.length) {
            _typedText = fullText.substring(0, _typeIndex + 1);
            _typeIndex++;
          } else {
            _isDeleting = true;
            timer.cancel();
            Future.delayed(const Duration(seconds: 3), () {
              if (mounted) {
                _startDeleting();
              }
            });
          }
        }
      });
    });
  }

  void _startDeleting() {
    _typeTimer?.cancel();
    _typeTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      setState(() {
        if (_typeIndex > 0) {
          _typedText = _typedText.substring(0, _typeIndex - 1);
          _typeIndex--;
        } else {
          timer.cancel();
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) {
              _startTypewriter();
            }
          });
        }
      });
    });
  }

  @override
  void dispose() {
    _bannerController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _resultCtrl.dispose();
    targetController.dispose();
    _bugPageController.dispose();
    _imagePageController.dispose();
    _senderTimer?.cancel();
    _imageSliderTimer?.cancel();
    _typeTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final response = await http.get(
        Uri.parse("http://n.panelhost.web.id:2259/getSenderStats?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _loadingSender = false;
          });
        } else {
          setState(() => _loadingSender = false);
        }
      } else {
        setState(() => _loadingSender = false);
      }
    } catch (_) {
      setState(() => _loadingSender = false);
    }
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse('http://n.panelhost.web.id:2259/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) {
          setState(() {
            _globalSenders = List<String>.from(data['senders']);
            _globalSenderCount = _globalSenders.length;
          });
        }
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (formatPhoneNumber(rawInput) == null) {
      _showAlert("❌ Nomor Tidak Valid", "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
      return;
    }

    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert("❌ Akses Ditolak", "Sender Global hanya untuk Owner");
      return;
    }

    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert("❌ No Bug Selected", "Pilih 1 bug untuk dikirim.");
      return;
    }

    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert("❌ No Private Sender", "Tidak ada private sender tersedia.");
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert("❌ No Global Sender", "Tidak ada global sender tersedia.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });
    _resultCtrl.reset();

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final res = await http.get(Uri.parse('http://n.panelhost.web.id:2259/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final role = data['role'] ?? widget.role;
        _setResponse('success', 'Bug berhasil dikirim ke $rawInput! [$role]');
        targetController.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: _candyApple.withOpacity(0.4), width: 1.5),
          ),
          title: Text(title, style: TextStyle(color: _candyApple, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          content: Text(msg, style: TextStyle(color: _textGrey)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(
                backgroundColor: Colors.transparent,
                foregroundColor: _candyApple,
                side: BorderSide(color: _candyApple.withOpacity(0.4)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
              child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glassCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    BorderRadius? borderRadius,
    Color? borderColor,
    double blurSigma = 12,
    Color? bgColor,
  }) {
    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: bgColor ?? Colors.white.withOpacity(0.04), 
            borderRadius: borderRadius ?? BorderRadius.circular(20),
            border: Border.all(
              color: borderColor ?? Colors.white.withOpacity(0.1),
              width: 1.2,
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTopAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _candyDark.withOpacity(0.2),
              border: Border.all(color: _candyDark, width: 1.5),
            ),
            child: Icon(Icons.shield_rounded, color: _candyApple, size: 20),
          ),
          const SizedBox(width: 10),
          SizedBox(
            height: 30,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.3,
                    child: Text(
                      _typedText.isEmpty ? " " : _typedText,
                      style: TextStyle(
                        color: _candyApple,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 19,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(
                            color: _candyApple.withOpacity(0.8),
                            blurRadius: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Text(
                  _typedText.isEmpty ? " " : _typedText,
                  style: TextStyle(
                    color: _textWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 19,
                    letterSpacing: 2,
                  ),
                ),
                Positioned(
                  right: -4,
                  top: 0,
                  bottom: 0,
                  child: AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _pulseController.value > 0.5 ? 1.0 : 0.3,
                        child: Container(
                          width: 2,
                          height: 22,
                          margin: const EdgeInsets.only(top: 4),
                          color: _candyApple,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _candyApple, width: 1.5),
              color: Colors.transparent,
            ),
            child: Text(
              'V8.0',
              style: TextStyle(color: _candyApple, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      height: 140, 
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: _candyDark.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            _bannerController.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _bannerController.value.size.width,
                      height: _bannerController.value.size.height,
                      child: VideoPlayer(_bannerController),
                    ),
                  )
                : Container(
                    color: const Color(0xFF020617),
                    child: const Center(child: CircularProgressIndicator()),
                  ),
            
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.45),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          widget.username.toUpperCase(),
                          style: TextStyle(
                            color: _candyApple.withOpacity(0.9),
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 24,
                            letterSpacing: 1.5,
                            shadows: [
                              Shadow(
                                color: _candyApple.withOpacity(0.8),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _candyDark.withOpacity(0.15), 
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _candyApple.withOpacity(0.6), 
                            width: 1.2,
                          ),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: TextStyle(
                            color: _candyApple, 
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 10,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      
                      Container(
                        width: 54,
                        height: 54,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _candyApple,
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _candyApple.withOpacity(0.4),
                              blurRadius: 6,
                              spreadRadius: 1,
                            )
                          ],
                        ),
                        padding: const EdgeInsets.all(2),
                        child: Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF0F172A),
                          ),
                          child: Center(
                            child: Text(
                              widget.username.isNotEmpty ? widget.username[0].toUpperCase() : 'A',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 20,
              child: AnimatedBuilder(
                animation: _glowController,
                builder: (context, child) {
                  return CustomPaint(
                    painter: WaveLinePainter(
                      animationValue: _glowController.value,
                      waveColor: _candyApple, 
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSlider() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: AspectRatio(
        aspectRatio: 21 / 9, 
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _candyApple.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _candyApple.withOpacity(0.1),
                blurRadius: 10,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Stack(
              children: [
                PageView.builder(
                  controller: _imagePageController,
                  itemCount: _sliderImages.length,
                  onPageChanged: (int index) {
                    setState(() {
                      _currentImagePage = index;
                    });
                  },
                  itemBuilder: (context, index) {
                    return Image.asset(
                      _sliderImages[index],
                      fit: BoxFit.cover,
                    );
                  },
                ),
                Positioned(
                  bottom: 8,
                  right: 14,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _sliderImages.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        height: 6,
                        width: _currentImagePage == index ? 16 : 6,
                        decoration: BoxDecoration(
                          color: _currentImagePage == index ? _candyApple : Colors.white.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNomorTargetPanel() {
    return _glassCard(
      padding: const EdgeInsets.all(18),
      borderColor: _candyDark.withOpacity(0.3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.phone_android_rounded, color: _candyApple, size: 18),
              const SizedBox(width: 8),
              Text(
                'NOMOR TARGET',
                style: TextStyle(color: _textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 2),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1), 
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _candyApple.withOpacity(0.3), width: 1),
                ),
                child: TextField(
                  controller: targetController,
                  style: TextStyle(color: _textWhite, fontFamily: 'ShareTechMono', fontSize: 15),
                  cursorColor: _candyApple,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: 'Contoh: +62812xxxxxxxx',
                    hintStyle: TextStyle(color: _textGrey.withOpacity(0.4), fontFamily: 'ShareTechMono'),
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Icon(Icons.language_rounded, color: _candyApple.withOpacity(0.7), size: 20),
                    ),
                    prefixIconConstraints: const BoxConstraints(minWidth: 50, minHeight: 50),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPilihBugPanel() {
    return _glassCard(
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      bgColor: const Color(0xFF13161F).withOpacity(0.4), 
      borderColor: _candyDark.withOpacity(0.3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _candyDark.withOpacity(0.2), 
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.bug_report, color: _candyApple, size: 16),
              ),
              const SizedBox(width: 10),
              const Text(
                'PiLiH BUG',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          
          SizedBox(
            height: 140,
            child: PageView.builder(
              controller: _bugPageController,
              itemCount: widget.listBug.length,
              onPageChanged: (int page) {
                setState(() {
                  _currentBugPage = page;
                  final bug = widget.listBug[page];
                  _selectedBugId = bug['bug_id'] as String? ?? '$page';
                });
              },
              itemBuilder: (context, index) {
                final bug = widget.listBug[index];
                final bugId = bug['bug_id'] as String? ?? '$index';
                final isSelected = _selectedBugId == bugId;

                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0F121A), 
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: isSelected ? _candyApple : _candyDark.withOpacity(0.3),
                      width: isSelected ? 1.5 : 1,
                    ),
                    boxShadow: isSelected ? [BoxShadow(color: _candyApple.withOpacity(0.15), blurRadius: 10)] : [],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.shield_outlined,
                              color: isSelected ? _candyApple : Colors.white60,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Text(
                        (bug['bug_id'] as String? ?? 'BUG').toUpperCase(),
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          bugId.toLowerCase(),
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: _textGrey,
                            fontFamily: 'ShareTechMono',
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          
          if (widget.listBug.length > 1)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                widget.listBug.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  height: 6,
                  width: _currentBugPage == index ? 22 : 6,
                  decoration: BoxDecoration(
                    color: _currentBugPage == index ? _candyApple : _candyDark.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSenderPanel() {
    return _glassCard(
      padding: const EdgeInsets.all(16),
      borderColor: _candyDark.withOpacity(0.3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.swap_horiz_rounded, color: _textWhite, size: 20),
              const SizedBox(width: 8),
              Text(
                'PILIH SENDER',
                style: TextStyle(color: _textWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  _fetchSenderStats();
                  _loadGlobalSenders();
                },
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _candyApple.withOpacity(0.15), 
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _candyApple.withOpacity(0.5)),
                  ),
                  child: (_isLoadingSenders || _loadingSender)
                      ? Padding(padding: const EdgeInsets.all(7), child: CircularProgressIndicator(strokeWidth: 2, color: _candyApple))
                      : Icon(Icons.refresh_rounded, color: _candyApple, size: 16),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: _candyApple.withOpacity(0.6)), color: Colors.transparent),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: _candyApple, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    Text(
                      _loadingSender ? '-- sender online' : '${_privateSenderCount + _globalSenderCount} sender online',
                      style: TextStyle(color: _candyApple, fontFamily: 'ShareTechMono', fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedSender = 'private'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 155,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'private' ? _candyApple.withOpacity(0.15) : Colors.white.withOpacity(0.04), 
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: _selectedSender == 'private' ? _candyApple : _candyDark.withOpacity(0.3), width: 1.5),
                      boxShadow: _selectedSender == 'private' ? [BoxShadow(color: _candyApple.withOpacity(0.2), blurRadius: 20, spreadRadius: 1)] : [],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.person_rounded, color: _selectedSender == 'private' ? _candyApple : _textGrey, size: 38),
                        const SizedBox(height: 10),
                        Text('Pribadi', style: TextStyle(color: _selectedSender == 'private' ? _candyApple : _textGrey, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 6),
                        _privateSenderCount == 0
                            ? Text('✕ Kosong', style: TextStyle(color: _textGrey, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, fontSize: 12))
                            : Text('$_privateSenderCount sender', style: TextStyle(color: _selectedSender == 'private' ? _textWhite : _candyApple, fontFamily: 'ShareTechMono', fontSize: 12)),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk role tertentu');
                      return;
                    }
                    setState(() => _selectedSender = 'global');
                    _loadGlobalSenders();
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 155,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'global' ? _candyApple.withOpacity(0.15) : Colors.white.withOpacity(0.04), 
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: _selectedSender == 'global' ? _candyApple : _candyDark.withOpacity(0.3), width: 1.5),
                      boxShadow: _selectedSender == 'global' ? [BoxShadow(color: _candyApple.withOpacity(0.2), blurRadius: 20, spreadRadius: 1)] : [],
                    ),
                    child: Stack(
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(width: double.infinity),
                            Icon(Icons.public_rounded, color: _selectedSender == 'global' ? _candyApple : _textGrey, size: 38),
                            const SizedBox(height: 10),
                            Text('Global', style: TextStyle(color: _selectedSender == 'global' ? _candyApple : _textGrey, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 6),
                            _globalSenderCount == 0
                                ? Text('✕ Kosong', style: TextStyle(color: _textGrey, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, fontSize: 12))
                                : Text('$_globalSenderCount sender', style: TextStyle(color: _selectedSender == 'global' ? _textWhite : _candyApple, fontFamily: 'ShareTechMono', fontSize: 12)),
                          ],
                        ),
                        if (!canAccessGlobalSender)
                          Positioned(
                            top: 8,
                            right: 8,
                            child: Container(
                              width: 22,
                              height: 22,
                              decoration: BoxDecoration(shape: BoxShape.circle, color: _candyDark, border: Border.all(color: Colors.black26, width: 1.5)),
                              child: const Icon(Icons.lock_rounded, color: Colors.white, size: 12),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_selectedSender == 'global' && _globalSenders.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: _candyDark.withOpacity(0.3))), 
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Icon(Icons.format_list_bulleted_rounded, color: _textGrey, size: 13),
                    const SizedBox(width: 6),
                    Text('${_globalSenders.length} sender aktif', style: TextStyle(color: _textGrey, fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.w600)),
                  ]),
                  const SizedBox(height: 8),
                  ...(_globalSenders.take(3).map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(children: [
                          Container(width: 5, height: 5, decoration: BoxDecoration(shape: BoxShape.circle, color: _candyApple)),
                          const SizedBox(width: 8),
                          Text(s, style: TextStyle(color: _textWhite, fontSize: 11, fontFamily: 'ShareTechMono')),
                        ]),
                      ))),
                  if (_globalSenders.length > 3)
                    Text('+ ${_globalSenders.length - 3} lainnya...', style: TextStyle(color: _textGrey, fontSize: 10)),
                ],
              ),
            )
          else
            Row(
              children: [
                Icon(Icons.info_outline_rounded, color: _textGrey, size: 13),
                const SizedBox(width: 6),
                Text('Sisa kirim global hari ini: 8 / 8', style: TextStyle(color: _textGrey, fontFamily: 'ShareTechMono', fontSize: 11)),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: _candyApple.withOpacity(0.6 + _pulseController.value * 0.2),
              width: 1.8,
            ),
            boxShadow: [
              BoxShadow(
                color: _candyApple.withOpacity(0.2 + _pulseController.value * 0.2),
                blurRadius: 18 + _pulseController.value * 12,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
              elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                      SizedBox(width: 10),
                      Text(
                        'SEND BUG',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 2),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = const Color(0xFF10B981); 
        icon = Icons.check_circle_outline;
        title = 'Berhasil';
        break;
      case 'warning':
        color = Colors.amber;
        icon = Icons.warning_rounded;
        title = 'Peringatan';
        break;
      default:
        color = _candyApple; 
        icon = Icons.error_outline;
        title = 'Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              margin: const EdgeInsets.only(top: 12),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.1)),
                    child: Icon(icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: TextStyle(color: color, fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 3),
                        Text(msg, style: TextStyle(color: _textGrey, fontFamily: 'ShareTechMono', fontSize: 12, height: 1.4)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() => _responseMessage = null);
                      _resultCtrl.reset();
                    },
                    child: Icon(Icons.close_rounded, color: _textGrey, size: 16),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0202),
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: GridPatternPainter(gridColor: _candyApple.withOpacity(0.04)),
            ),
          ),

          Positioned.fill(
            child: AnimatedBuilder(
              animation: _glowController,
              builder: (context, child) {
                double glowScale = 0.75 + (_glowController.value * 0.2);
                return Container(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: Alignment.center,
                      radius: glowScale,
                      colors: [
                        const Color(0xFFFF2400).withOpacity(0.22),
                        const Color(0xFF800000).withOpacity(0.06), 
                        Colors.transparent,                        
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                );
              },
            ),
          ),

          Positioned(
            top: -100,
            left: MediaQuery.of(context).size.width * 0.1,
            right: MediaQuery.of(context).size.width * 0.1,
            height: 350,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFFFF0800).withOpacity(0.12), 
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildTopAppBar(),
                _buildHeader(),
                Container(height: 1, color: Colors.white.withOpacity(0.06)),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: _candyDark.withOpacity(0.3),
                              width: 1.2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(
                              children: [
                                BackdropFilter(
                                  filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                                  child: Container(
                                    color: Colors.white.withOpacity(0.04),
                                    padding: const EdgeInsets.only(top: 16, bottom: 24, left: 12, right: 12),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                      children: [
                                        HDStatItem(
                                          icon: Icons.pest_control_rodent_rounded,
                                          value: '${widget.listBug.length}',
                                          label: 'Total Bugs',
                                          iconColor: _candyApple,
                                          isGlow: false,
                                        ),
                                        HDStatItem(
                                          icon: Icons.bolt_rounded,
                                          value: 'GACOR',
                                          label: 'Success Rate',
                                          iconColor: _candyApple,
                                          isGlow: true,
                                        ),
                                        HDStatItem(
                                          icon: Icons.shield_rounded,
                                          value: 'ACTIVE',
                                          label: 'Status',
                                          iconColor: _candyApple,
                                          isGlow: true,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  height: 16,
                                  child: AnimatedBuilder(
                                    animation: _glowController,
                                    builder: (context, child) {
                                      return CustomPaint(
                                        painter: WaveLinePainter(
                                          animationValue: _glowController.value,
                                          waveColor: Colors.white,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        _buildImageSlider(), 
                        const SizedBox(height: 14),
                        _buildNomorTargetPanel(),
                        const SizedBox(height: 14),
                        _buildPilihBugPanel(), 
                        const SizedBox(height: 14),
                        _buildSenderPanel(),
                        const SizedBox(height: 20),
                        _buildSendButton(),
                        _buildResponseMessage(),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HDStatItem extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color iconColor;
  final bool isGlow;

  const HDStatItem({
    super.key,
    required this.icon,
    required this.value,
    required this.label,
    required this.iconColor,
    required this.isGlow,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: iconColor.withOpacity(0.3),
                  width: 1,
                ),
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: iconColor.withOpacity(0.15),
                boxShadow: isGlow
                    ? [
                        BoxShadow(
                          color: iconColor.withOpacity(0.4),
                          blurRadius: 12,
                          spreadRadius: 2,
                        )
                      ]
                    : [],
              ),
              child: Icon(icon, color: iconColor, size: 22),
            ),
            Positioned(
              right: 0,
              child: Container(
                width: 4,
                height: 8,
                decoration: BoxDecoration(
                  color: iconColor,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 15,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white60,
            fontSize: 11,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }
}

class GridPatternPainter extends CustomPainter {
  final Color gridColor;
  GridPatternPainter({required this.gridColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = gridColor
      ..strokeWidth = 1.0;

    const double step = 30.0; 

    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class WaveLinePainter extends CustomPainter {
  final double animationValue;
  final Color waveColor; 

  WaveLinePainter({required this.animationValue, required this.waveColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = waveColor.withOpacity(0.8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..imageFilter = ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5);

    final path = Path();
    path.moveTo(0, size.height * 0.5);

    for (double i = 0; i <= size.width; i++) {
      double angle = (i / size.width) * 2 * math.pi * 1.5 + (animationValue * 2 * math.pi);
      double y = math.sin(angle) * 4.0 + (size.height * 0.5);
      path.lineTo(i, y);
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant WaveLinePainter oldDelegate) {
    return oldDelegate.animationValue != animationValue || oldDelegate.waveColor != waveColor;
  }
}