import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class SavingsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const SavingsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<SavingsPage> createState() => _SavingsPageState();
}

class _SavingsPageState extends State<SavingsPage> {
  Map<String, dynamic> savings = {};
  List<dynamic> transactions = [];
  bool loading = true;
  bool busy = false;
  Timer? _poller;

  int minDeposit = 2000;
  int maxDeposit = 10000000;
  int minWithdraw = 10000;
  String _withdrawMethod = 'DANA';

  final _amount = TextEditingController();
  final _withdraw = TextEditingController();
  final _destination = TextEditingController();
  final _owner = TextEditingController();

  static const Color green = Color(0xFF20F0B2);
  static const Color cyan = Color(0xFF35D9FF);
  static const Color purple = Color(0xFF8B7CFF);
  static const Color bg = Color(0xFF050811);
  static const Color card = Color(0xFF0C1422);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _poller?.cancel();
    _amount.dispose();
    _withdraw.dispose();
    _destination.dispose();
    _owner.dispose();
    super.dispose();
  }

  String rupiah(dynamic value) {
    final n = int.tryParse('${value ?? 0}') ?? 0;
    final s = n.toString();
    final out = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) out.write('.');
      out.write(s[i]);
    }
    return 'Rp$out';
  }

  Future<Map<String, dynamic>> _get(String path) async {
    final uri = Uri.parse(
      '$baseUrl$path?key=${Uri.encodeQueryComponent(widget.sessionKey)}',
    );
    final response = await http.get(uri).timeout(const Duration(seconds: 12));
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode >= 400) {
      throw Exception(data['message'] ?? 'Permintaan gagal');
    }
    return data;
  }

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await http
        .post(
          Uri.parse('$baseUrl$path'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({...body, 'key': widget.sessionKey}),
        )
        .timeout(const Duration(seconds: 15));

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode >= 400) {
      throw Exception(data['message'] ?? 'Permintaan gagal');
    }
    return data;
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        _get('/api/savings/summary'),
        _get('/api/savings/transactions'),
        _get('/api/savings/config'),
      ]);

      final summary = results[0];
      final tx = results[1];
      final config = results[2];

      if (!mounted) return;
      setState(() {
        savings = Map<String, dynamic>.from(summary['savings'] ?? {});
        transactions = List<dynamic>.from(tx['transactions'] ?? []);
        minDeposit = int.tryParse('${config['minDeposit'] ?? 2000}') ?? 2000;
        maxDeposit =
            int.tryParse('${config['maxDeposit'] ?? 10000000}') ?? 10000000;
        minWithdraw =
            int.tryParse('${config['minWithdraw'] ?? 10000}') ?? 10000;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      _toast('Gagal memuat tabungan: $e');
    }
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.info_outline_rounded, color: cyan),
            const SizedBox(width: 10),
            Expanded(child: Text(message)),
          ],
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openDeposit() {
    _amount.clear();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            final current =
                int.tryParse(_amount.text.replaceAll(RegExp(r'[^0-9]'), '')) ??
                    0;

            void setAmount(int value) {
              _amount.text = value.toString();
              _amount.selection = TextSelection.collapsed(
                offset: _amount.text.length,
              );
              setSheet(() {});
            }

            return Container(
              padding: EdgeInsets.fromLTRB(
                20,
                12,
                20,
                MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              decoration: const BoxDecoration(
                color: Color(0xFF0A111A),
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 42,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(9),
                        ),
                      ),
                    ),
                    const SizedBox(height: 22),
                    Row(
                      children: [
                        _iconBox(Icons.add_card_rounded, green),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Tambah Tabungan',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 21,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              SizedBox(height: 3),
                              Text(
                                'Bayar aman menggunakan QRIS',
                                style: TextStyle(color: Colors.white54),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'Nominal deposit',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 9),
                    TextField(
                      controller: _amount,
                      onChanged: (_) => setSheet(() {}),
                      keyboardType: TextInputType.number,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.w900,
                      ),
                      decoration: InputDecoration(
                        prefixText: 'Rp ',
                        prefixStyle: const TextStyle(
                          color: green,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                        hintText: '0',
                        hintStyle: const TextStyle(color: Colors.white24),
                        filled: true,
                        fillColor: Colors.white.withOpacity(.055),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 17,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: BorderSide(color: green.withOpacity(.16)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide:
                              const BorderSide(color: green, width: 1.2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      'Minimal ${rupiah(minDeposit)} • Maksimal ${rupiah(maxDeposit)}',
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 17),
                    Wrap(
                      spacing: 9,
                      runSpacing: 9,
                      children: [
                        minDeposit,
                        3000,
                        5000,
                        10000,
                        25000,
                        50000,
                      ].where((v) => v >= minDeposit && v <= maxDeposit).map(
                        (value) {
                          final selected = current == value;
                          return InkWell(
                            onTap: () => setAmount(value),
                            borderRadius: BorderRadius.circular(13),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 160),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 11,
                              ),
                              decoration: BoxDecoration(
                                color: selected
                                    ? green.withOpacity(.14)
                                    : Colors.white.withOpacity(.045),
                                borderRadius: BorderRadius.circular(13),
                                border: Border.all(
                                  color: selected
                                      ? green.withOpacity(.7)
                                      : Colors.white10,
                                ),
                              ),
                              child: Text(
                                rupiah(value),
                                style: TextStyle(
                                  color: selected ? green : Colors.white70,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          );
                        },
                      ).toList(),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: busy
                            ? null
                            : () {
                                Navigator.pop(ctx);
                                _deposit();
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: green,
                          foregroundColor: Colors.black,
                          disabledBackgroundColor: green.withOpacity(.25),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17),
                          ),
                        ),
                        child: busy
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.black,
                                ),
                              )
                            : const Text(
                                'LANJUT KE QRIS',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: .4,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _deposit() async {
    final amount =
        int.tryParse(_amount.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;

    if (amount < minDeposit) {
      _toast('Minimal deposit ${rupiah(minDeposit)}');
      return;
    }
    if (amount > maxDeposit) {
      _toast('Maksimal deposit ${rupiah(maxDeposit)}');
      return;
    }

    setState(() => busy = true);
    try {
      final data = await _post(
        '/api/savings/deposit/create',
        {'amount': amount},
      );
      if (!mounted) return;
      setState(() => busy = false);

      final tx = Map<String, dynamic>.from(data['transaction'] ?? {});
      _amount.clear();
      _showPayment(tx);
    } catch (e) {
      if (mounted) setState(() => busy = false);
      _toast('$e');
    }
  }

  void _showPayment(Map<String, dynamic> tx) {
    _poller?.cancel();
    _poller = Timer.periodic(
      const Duration(seconds: 5),
      (_) => _checkPayment('${tx['id']}'),
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(ctx).size.height * .88,
          ),
          padding: EdgeInsets.fromLTRB(
            20,
            12,
            20,
            MediaQuery.of(ctx).viewInsets.bottom + 18,
          ),
          decoration: const BoxDecoration(
            color: Color(0xFF070D14),
            borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                const SizedBox(height: 18),
                _iconBox(Icons.qr_code_2_rounded, cyan),
                const SizedBox(height: 10),
                const Text(
                  'Bayar Deposit',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Scan QRIS sesuai nominal di bawah',
                  style: TextStyle(color: Colors.white54),
                ),
                const SizedBox(height: 16),
                Text(
                  rupiah(tx['totalAmount']),
                  style: const TextStyle(
                    color: green,
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (tx['uniqueCode'] != null &&
                    int.tryParse('${tx['uniqueCode']}') != 0)
                  Text(
                    'Termasuk kode unik ${tx['uniqueCode']}',
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 12,
                    ),
                  ),
                const SizedBox(height: 16),
                if (tx['qrUrl'] != null)
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: cyan.withOpacity(.15),
                          blurRadius: 30,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Image.network(
                      '${tx['qrUrl']}',
                      height: 245,
                      width: 245,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const SizedBox(
                        height: 245,
                        width: 245,
                        child: Center(
                          child: Text(
                            'QR gagal dimuat',
                            style: TextStyle(color: Colors.black54),
                          ),
                        ),
                      ),
                    ),
                  )
                else
                  const Padding(
                    padding: EdgeInsets.all(30),
                    child: Text(
                      'QRIS tidak tersedia dari gateway.',
                      style: TextStyle(color: Colors.white54),
                    ),
                  ),
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: cyan.withOpacity(.055),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: cyan.withOpacity(.12)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.autorenew_rounded, color: cyan, size: 19),
                      SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          'Status pembayaran dicek otomatis setiap 5 detik.',
                          style: TextStyle(color: Colors.white60, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: OutlinedButton.icon(
                    onPressed: () => _checkPayment(
                      '${tx['id']}',
                      closeOnSuccess: true,
                    ),
                    icon: const Icon(Icons.sync_rounded),
                    label: const Text('CEK SEKARANG'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: cyan,
                      side: BorderSide(color: cyan.withOpacity(.35)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    _poller?.cancel();
                    Navigator.pop(ctx);
                  },
                  child: const Text('Tutup'),
                ),
              ],
            ),
          ),
        );
      },
    ).whenComplete(() => _poller?.cancel());
  }

  Future<void> _checkPayment(
    String id, {
    bool closeOnSuccess = false,
  }) async {
    try {
      final data = await _post(
        '/api/savings/deposit/status',
        {'transaction_id': id},
      );
      final tx = Map<String, dynamic>.from(data['transaction'] ?? {});
      if (tx['status'] == 'success') {
        _poller?.cancel();
        await _load();
        if (closeOnSuccess && mounted) Navigator.pop(context);
        _toast('Deposit berhasil masuk ke saldo tabungan 🎉');
      }
    } catch (_) {}
  }

  Future<void> _withdrawRequest() async {
    final amount =
        int.tryParse(_withdraw.text.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;

    if (amount < minWithdraw) {
      _toast('Minimal penarikan ${rupiah(minWithdraw)}');
      return;
    }
    final destination = _destination.text.trim();
    final ownerName = _owner.text.trim();
    if (destination.isEmpty) {
      _toast('Masukkan nomor $_withdrawMethod tujuan');
      return;
    }
    final digits = destination.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length < 8 || digits.length > 15) {
      _toast('Nomor $_withdrawMethod tidak valid');
      return;
    }

    setState(() => busy = true);
    try {
      await _post(
        '/api/savings/withdraw',
        {
          'amount': amount,
          'destination': digits,
          'withdraw_method': _withdrawMethod,
          'owner_name': ownerName,
        },
      );

      if (!mounted) return;
      setState(() => busy = false);
      _withdraw.clear();
      _destination.clear();
      _owner.clear();
      _withdrawMethod = 'DANA';
      Navigator.pop(context);
      await _load();
      _toast('Penarikan diajukan. Menunggu proses admin.');
    } catch (e) {
      if (mounted) setState(() => busy = false);
      _toast('$e');
    }
  }

  void _openWithdraw() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Container(
        padding: EdgeInsets.fromLTRB(
          20,
          12,
          20,
          MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        decoration: const BoxDecoration(
          color: Color(0xFF0A111A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  _iconBox(Icons.account_balance_wallet_rounded, purple),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Tarik Tabungan',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              Text(
                'Saldo tersedia ${rupiah(savings['balance'])}',
                style: const TextStyle(color: green),
              ),
              const SizedBox(height: 17),
              _field(
                _withdraw,
                'Nominal penarikan',
                Icons.payments_outlined,
                keyboard: true,
              ),
              const Text(
                'Tujuan penarikan',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _withdrawMethodCard('DANA', Icons.account_balance_wallet_rounded, () => setSheet(() => _withdrawMethod = 'DANA'))),
                  const SizedBox(width: 10),
                  Expanded(child: _withdrawMethodCard('GOPAY', Icons.phone_android_rounded, () => setSheet(() => _withdrawMethod = 'GOPAY'))),
                ],
              ),
              const SizedBox(height: 12),
              _field(
                _destination,
                'Nomor $_withdrawMethod',
                Icons.phone_rounded,
                keyboard: true,
              ),
              _field(
                _owner,
                'Nama pemilik',
                Icons.person_outline_rounded,
              ),
              const Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: Text(
                  'Penarikan hanya tersedia ke DANA atau GoPay. Pastikan nomor dan nama penerima benar.',
                  style: TextStyle(color: Colors.white38, fontSize: 12, height: 1.35),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: busy ? null : _withdrawRequest,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: purple,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'AJUKAN PENARIKAN',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ),
        ),
        ),
      );
  }

  Widget _withdrawMethodCard(String method, IconData icon, VoidCallback onSelected) {
    final selected = _withdrawMethod == method;
    return InkWell(
      onTap: busy ? null : () {
        onSelected();
      },
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
        decoration: BoxDecoration(
          color: selected ? purple.withOpacity(.14) : Colors.white.withOpacity(.045),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? purple.withOpacity(.7) : Colors.white10),
        ),
        child: Row(
          children: [
            Icon(icon, color: selected ? purple : Colors.white54, size: 22),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                method,
                style: TextStyle(
                  color: selected ? Colors.white : Colors.white.withOpacity(0.65),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            if (selected) const Icon(Icons.check_circle_rounded, color: purple, size: 19),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String hint,
    IconData icon, {
    bool keyboard = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        keyboardType:
            keyboard ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.white54),
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white38),
          filled: true,
          fillColor: Colors.white.withOpacity(.05),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _iconBox(IconData icon, Color color) {
    return Container(
      width: 49,
      height: 49,
      decoration: BoxDecoration(
        color: color.withOpacity(.11),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(.22)),
      ),
      child: Icon(icon, color: color, size: 25),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        title: const Text(
          'Tabungan',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          IconButton(
            onPressed: loading ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(color: green),
            )
          : RefreshIndicator(
              onRefresh: _load,
              color: green,
              backgroundColor: card,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                children: [
                  _heroCard(),
                  const SizedBox(height: 13),
                  Row(
                    children: [
                      Expanded(
                        child: _actionCard(
                          Icons.add_circle_outline_rounded,
                          'Deposit',
                          'Tambah saldo',
                          green,
                          _openDeposit,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionCard(
                          Icons.account_balance_wallet_outlined,
                          'Tarik',
                          'Ajukan penarikan',
                          purple,
                          _openWithdraw,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D1B2F),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: cyan.withOpacity(.16)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: cyan.withOpacity(.10),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(Icons.qr_code_2_rounded, color: cyan, size: 27),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Deposit Cepat (QRIS)', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                              SizedBox(height: 3),
                              Text('Scan QR untuk menambah saldo otomatis', style: TextStyle(color: Colors.white54, fontSize: 11)),
                            ],
                          ),
                        ),
                        FilledButton.icon(
                          onPressed: _openDeposit,
                          icon: const Icon(Icons.qr_code_scanner_rounded, size: 18),
                          label: const Text('QRIS'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  _sectionTitle('Ringkasan'),
                  const SizedBox(height: 10),
                  _summary(),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(child: _sectionTitle('Riwayat transaksi')),
                      Text(
                        '${transactions.length} transaksi',
                        style: const TextStyle(
                          color: Colors.white30,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (transactions.isEmpty)
                    _empty()
                  else
                    ...transactions.take(30).map(_tx),
                ],
              ),
            ),
    );
  }

  Widget _heroCard() {
    final balance = int.tryParse('${savings['balance'] ?? 0}') ?? 0;
    final deposited =
        int.tryParse('${savings['totalDeposited'] ?? 0}') ?? 0;

    return Container(
      padding: const EdgeInsets.all(21),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF0B67C7),
            Color(0xFF0A397F),
            Color(0xFF07152D),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(27),
        border: Border.all(color: green.withOpacity(.22)),
        boxShadow: [
          BoxShadow(
            color: green.withOpacity(.07),
            blurRadius: 35,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -32,
            top: -45,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: cyan.withOpacity(.05),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _iconBox(Icons.savings_rounded, green),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Text(
                      'DARK LIGHT TABUNGAN',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: green.withOpacity(.08),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: green.withOpacity(.15)),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.verified_rounded, color: green, size: 14),
                        SizedBox(width: 5),
                        Text(
                          'AKTIF',
                          style: TextStyle(
                            color: green,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 25),
              const Text(
                'Saldo tersedia',
                style: TextStyle(color: Colors.white54, fontSize: 13),
              ),
              const SizedBox(height: 5),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  rupiah(balance),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _heroStat(
                      'Total disimpan',
                      rupiah(deposited),
                      green,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _heroStat(
                      'Total ditarik',
                      rupiah(savings['totalWithdrawn']),
                      Colors.orangeAccent,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroStat(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.16),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(.045)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w900,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(color: Colors.white38, fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _actionCard(
    IconData icon,
    String title,
    String subtitle,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(19),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(19),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          children: [
            Container(
              width: 43,
              height: 43,
              decoration: BoxDecoration(
                color: color.withOpacity(.10),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 17,
        fontWeight: FontWeight.w900,
      ),
    );
  }

  Widget _summary() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 17),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: Colors.white.withOpacity(.05)),
      ),
      child: Row(
        children: [
          Expanded(
            child: _stat(
              'Total masuk',
              savings['totalDeposited'],
              green,
              Icons.south_west_rounded,
            ),
          ),
          Container(width: 1, height: 42, color: Colors.white10),
          Expanded(
            child: _stat(
              'Total keluar',
              savings['totalWithdrawn'],
              Colors.orangeAccent,
              Icons.north_east_rounded,
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String title, dynamic value, Color color, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(height: 7),
        Text(
          rupiah(value),
          style: TextStyle(color: color, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: const TextStyle(color: Colors.white38, fontSize: 10),
        ),
      ],
    );
  }

  Widget _tx(dynamic raw) {
    final m = Map<String, dynamic>.from(raw as Map);
    final type = '${m['type']}';
    final status = '${m['status']}';
    final isIn = type == 'deposit';
    final statusColor = status == 'success'
        ? green
        : status == 'pending'
            ? Colors.orangeAccent
            : Colors.redAccent;

    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: Colors.white.withOpacity(.045)),
      ),
      child: Row(
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: BoxDecoration(
              color: statusColor.withOpacity(.09),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isIn
                  ? Icons.arrow_downward_rounded
                  : Icons.arrow_upward_rounded,
              color: statusColor,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  m['title'] ?? type,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  m['description'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${isIn ? '+' : '-'}${rupiah(m['amount'])}',
                style: TextStyle(
                  color: isIn ? green : Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                status.toUpperCase(),
                style: TextStyle(
                  color: statusColor,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: .7,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _empty() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 42),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Column(
        children: [
          Icon(
            Icons.receipt_long_rounded,
            color: Colors.white24,
            size: 38,
          ),
          SizedBox(height: 10),
          Text(
            'Belum ada transaksi tabungan',
            style: TextStyle(color: Colors.white38),
          ),
          SizedBox(height: 4),
          Text(
            'Mulai dengan deposit pertama kamu.',
            style: TextStyle(color: Colors.white24, fontSize: 11),
          ),
        ],
      ),
    );
  }
}
