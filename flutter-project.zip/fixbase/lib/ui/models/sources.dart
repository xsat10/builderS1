class SourceManager {
  static final SourceManager instance = SourceManager._();
  SourceManager._();

  List<dynamic> get inbuiltSources => [];

  SourceManager addSources(List<dynamic> sources) => this;

  void loadProviders({bool clearBeforeLoading = true}) {}
}
