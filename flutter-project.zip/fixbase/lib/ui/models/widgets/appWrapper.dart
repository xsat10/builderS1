import 'package:flutter/material.dart';

class AppWrapper extends StatelessWidget {
  final Widget firstPage;

  const AppWrapper({super.key, required this.firstPage});

  @override
  Widget build(BuildContext context) {
    return firstPage;
  }
}
