DARK LIGHT Chat UI Rework

- Global Chat visual updated toward WhatsApp-style dark chat: header, bubbles, composer, colors and spacing.
- Global composer attachment button now calls the existing attachment picker.
- Private Chat visual updated toward WhatsApp-style dark chat: user list, header, bubbles and composer.
- Existing text/media/VN behavior preserved.
- Private call/VC implementation files and call actions were not modified.
