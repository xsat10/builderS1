package com.tele.Izalmodz;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
