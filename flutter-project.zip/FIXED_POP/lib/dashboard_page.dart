import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// --- Packages info sistem ---
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:system_info2/system_info2.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'public_chat_page.dart';
import 'dev_page.dart';
import 'pemula_page.dart';
import 'control_panel.dart';
import 'story_page.dart';
import 'widgets/custom_popup.dart';

const String baseUrl = "http://38.253.224.75:4032";

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  // ===== THEME =====
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  final GlobalKey<GlazeNavBarState> _navBarKey = GlobalKey();

  int onlineUsers = 0;
  int activeConnections = 0;

  int _quickActionsPage = 0;
  late PageController _quickActionsController;
  late PageController _carouselController;
  int _currentCarouselPage = 0;

  // ===== STORY DATA =====
  List<Map<String, dynamic>> _storyList = [];
  bool _isLoadingStory = false;

  // ===== BTC CHART STATE =====
  List<double> _btcPrices = [];
  double _currentBTCPrice = 118240.34;
  double _btcHigh = 118240.34;
  double _btcLow = 118240.34;
  double _btcVolume = 42000;
  double _btcFunding = 0.010;
  bool _isPriceUp = true;
  String _btcChange = '+0.00';
  late Timer _btcTimer;
  final Random _random = Random();

  // ===== AI FLOATING BUBBLE STATE =====
  late Timer _aiTimer;
  String _aiMessage = "Halo! Selamat datang di NEBULA 🚀";
  Offset _aiPosition = const Offset(20, 120);
  bool _isBubbleExpanded = false;

  // ===== AI MESSAGES - PAKAI METHOD (FIX ERROR) =====
  List<String> _getAiMessages() {
    return [
      "Halo! Selamat datang di NEBULA 🚀",
      "Ayo buka fitur canggih nya! 🔥",
      "Jangan lupa cek story terbaru ya! 📸",
      "BTC: \$${_currentBTCPrice.toStringAsFixed(2)} 🚀",
      "Gabung channel NEBULA untuk info update! 📢",
      "Selamat berkarya dengan NEBULA! ✨",
      "Fitur terbaru sudah menunggumu! 🎯",
      "Ayo eksplor semua tools yang tersedia! 🛠️",
      "NEBULA siap jadi partner terbaikmu! 💪",
      "Jangan lewatkan berita terbaru! 📰",
      "Kontrol perangkat dari mana saja! 🌐",
      "Keamanan adalah prioritas utama kami! 🔒",
      "Teruslah berkarya dan berinovasi! 🌟",
      "NEBULA selalu update untukmu! 🔄",
      "Yuk coba fitur Remote Access! 🖥️",
    ];
  }

  String _getRandomMessage() {
    final messages = _getAiMessages();
    return messages[DateTime.now().millisecondsSinceEpoch % messages.length];
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _quickActionsController = PageController(viewportFraction: 0.88);
    _carouselController = PageController(initialPage: 0);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
    _fetchStories();
    _initBTCChart();

    // ===== AI TIMER =====
    _aiMessage = _getRandomMessage();
    _aiTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (mounted) {
        setState(() {
          _aiMessage = _getRandomMessage();
        });
      }
    });
  }

  @override
  void dispose() {
    _aiTimer.cancel();
    _btcTimer.cancel();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    _quickActionsController.dispose();
    _carouselController.dispose();
    super.dispose();
  }

  // ===== BTC CHART FUNCTIONS =====
  void _initBTCChart() {
    double price = 118240.34;
    _btcPrices = [];
    for (int i = 0; i < 100; i++) {
      price += (_random.nextDouble() - 0.5) * 200;
      if (price < 115000) price = 115000 + _random.nextDouble() * 500;
      if (price > 122000) price = 122000 - _random.nextDouble() * 500;
      _btcPrices.add(price);
    }
    _currentBTCPrice = _btcPrices.last;
    _btcHigh = _btcPrices.reduce((a, b) => a > b ? a : b);
    _btcLow = _btcPrices.reduce((a, b) => a < b ? a : b);
    
    _btcTimer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      _updateBTCChart();
    });
  }

  void _updateBTCChart() {
    double change = (_random.nextDouble() - 0.5) * 20;
    double newPrice = _currentBTCPrice + change;
    
    if (newPrice < 115000) newPrice = 115000 + _random.nextDouble() * 200;
    if (newPrice > 122000) newPrice = 122000 - _random.nextDouble() * 200;
    
    _btcPrices.add(newPrice);
    if (_btcPrices.length > 150) _btcPrices.removeAt(0);
    _currentBTCPrice = newPrice;
    
    if (newPrice > _btcHigh) _btcHigh = newPrice;
    if (newPrice < _btcLow) _btcLow = newPrice;
    
    if (_btcPrices.length > 10) {
      double oldPrice = _btcPrices[_btcPrices.length - 10];
      double changePercent = ((newPrice - oldPrice) / oldPrice) * 100;
      _isPriceUp = changePercent >= 0;
      _btcChange = (changePercent >= 0 ? '+' : '') + changePercent.toStringAsFixed(2);
    }
    
    _btcVolume += (_random.nextDouble() - 0.5) * 50;
    if (_btcVolume < 38000) _btcVolume = 38000 + _random.nextDouble() * 500;
    if (_btcVolume > 42000) _btcVolume = 42000 - _random.nextDouble() * 500;
    
    _btcFunding += (_random.nextDouble() - 0.5) * 0.0001;
    if (_btcFunding > 0.008) _btcFunding = 0.008;
    if (_btcFunding < -0.008) _btcFunding = -0.008;
    
    if (mounted) setState(() {});
  }

  // ===== FETCH STORIES FROM API =====
  Future<void> _fetchStories() async {
    setState(() => _isLoadingStory = true);
    try {
      final response = await http.get(
        Uri.parse('http://public.queen-official.com:1983/getStories?key=$sessionKey'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['stories'] != null) {
          setState(() {
            _storyList = List<Map<String, dynamic>>.from(data['stories']);
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching stories: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoadingStory = false);
      }
    }
  }

  // ===== UPLOAD STORY - NAVIGASI KE STORY PAGE =====
  Future<void> _uploadStory() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StoryPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    );
    if (result == true) {
      _fetchStories();
    }
  }

  // ===== BUKA STORY USER - NAVIGASI KE STORY PAGE =====
  void _openStoryUser(String username) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StoryPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    ).then((_) => _fetchStories());
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController =
        VideoPlayerController.asset('assets/videos/bug.mp4')
          ..initialize().then((_) {
            setState(() {});
            _menuVideoController?.setLooping(true);
            _menuVideoController?.play();
          });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('wss://pterodactyl.cloud:4813'));
      channel.sink.add(jsonEncode({"type": "stats"}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'stats') {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (e) => debugPrint("WS error: $e"));
    } catch (e) {
      debugPrint("WS Error: $e");
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = InfoPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = ToolsPage(
              sessionKey: sessionKey, userRole: role, listDoos: listDoos);
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  // ===== BUILD NEWS PAGE =====
  Widget _buildNewsPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          // ===== STORY =====
          _buildStoryRowBulat(),

          const SizedBox(height: 16),

          // STATUS CARD
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(child: _buildStatusCard("Online Users", onlineUsers.toString(), Icons.bolt)),
                const SizedBox(width: 12),
                Expanded(child: _buildStatusCard("Active Conns", activeConnections.toString(), Icons.sensors)),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // LICENSE STATUS CARD
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _buildGlassContainer(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    children: [
                      _buildCircularProgress(),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("License Status", style: TextStyle(color: Colors.white54, fontSize: 12)),
                            const SizedBox(height: 4),
                            Text(
                              expiredDate,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Active Protection Enabled",
                              style: TextStyle(
                                color: lightGreen,
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Divider(color: Colors.white10, height: 1),
                  const SizedBox(height: 15),

                  // UID CARD
                  _buildUidCard(),

                  const SizedBox(height: 15),
                  const Divider(color: Colors.white10, height: 1),
                  const SizedBox(height: 15),

                  // PASSWORD & LOGOUT
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ChangePasswordPage(
                                  username: username,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.white.withOpacity(0.1)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.lock_reset_rounded, color: Colors.white70, size: 16),
                                SizedBox(width: 8),
                                Text("PASSWORD", style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GestureDetector(
                          onTap: _handleLogout,
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.redAccent.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(Icons.logout_rounded, color: Colors.redAccent, size: 16),
                                SizedBox(width: 8),
                                Text("LOGOUT", style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ===== NEWS & JOIN CHANNEL =====
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // JUDUL NEWS
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 4,
                          height: 18,
                          decoration: BoxDecoration(
                            color: lightGreen,
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          "NEWS",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      "${newsList.length} Item",
                      style: TextStyle(
                        color: Colors.white38,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // NEWS CAROUSEL
                if (newsList.isNotEmpty)
                  SizedBox(
                    height: 180,
                    child: PageView.builder(
                      controller: _carouselController,
                      itemCount: newsList.length,
                      onPageChanged: (index) => setState(() => _currentCarouselPage = index),
                      itemBuilder: (ctx, i) {
                        final item = newsList[i];
                        final String mediaUrl = item['image'] ?? item['url'] ?? "";
                        return Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                if (mediaUrl.isNotEmpty)
                                  NewsMedia(url: mediaUrl)
                                else
                                  Container(color: Colors.white10),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.black.withOpacity(0.7),
                                        Colors.transparent,
                                      ],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 12,
                                  left: 12,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: lightGreen,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      "NEWS",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  bottom: 14,
                                  left: 14,
                                  right: 14,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item['title'] ?? '',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.bold,
                                          shadows: [
                                            Shadow(
                                              color: Colors.black87,
                                              blurRadius: 8,
                                            )
                                          ],
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        item['desc'] ?? '',
                                        style: TextStyle(color: Colors.white70, fontSize: 11),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                const SizedBox(height: 16),

                // ===== JOIN CHANNEL NEBULA CARD =====
                GestureDetector(
                  onTap: () => _openUrl("https://t.me/tokisakiproject01"),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF0D0D0D),
                          Color(0xFF1A1A2E),
                          Color(0xFF16213E),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.06),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF4F46E5).withOpacity(0.06),
                          blurRadius: 20,
                          spreadRadius: 5,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // ICON CHANNEL
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color(0xFF4F46E5),
                                Color(0xFF7C3AED),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF4F46E5).withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(
                            FontAwesomeIcons.telegram,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 14),

                        // TEKS
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "NEBULA",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                "Channel Resmi NEBULA",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.6),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                "JOIN CHANNEL NEBULA",
                                style: TextStyle(
                                  color: lightGreen,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // ARROW
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.08),
                            ),
                          ),
                          child: Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: Colors.white.withOpacity(0.4),
                            size: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ===== BTC CHART - MENGGANTIKAN WEATHER HUD =====
          _buildBTCChart(),

          const SizedBox(height: 16),

          // ===== QUICK ACTIONS - 2 IKON (GLOBAL CHAT & REMOTE ACCESS) =====
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // GLOBAL CHAT
                _buildQuickActionIcon(
                  icon: Icons.public_rounded,
                  label: "Global Chat",
                  color: const Color(0xFF3B5BDB),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => PublicChatPage(
                          username: username,
                          sessionKey: sessionKey,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),
                // REMOTE ACCESS
                _buildQuickActionIcon(
                  icon: Icons.settings_remote_rounded,
                  label: "Remote Access",
                  color: const Color(0xFF7C3AED),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ControlPanelPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // INFO & PENGUMUMAN
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: _showInfoDialog,
              child: _buildGlassContainer(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: lightGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.info_outline, color: Color(0xFF2ECC71), size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Info & Pengumuman",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            "Klik untuk melihat info terbaru",
                            style: TextStyle(color: Colors.white54, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 15),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // DIVIDER
          Center(
            child: Container(
              width: 60,
              height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Colors.white24, Colors.transparent],
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // HUBUNGI KAMI
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _sectionHeader(Icons.headset_mic_outlined, "HUBUNGI KAMI"),
                const SizedBox(height: 14),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Developer 01",
                  subtitle: "Telegram Developer 1",
                  color: const Color(0xFF25D366),
                  url: "https://t.me/noprinotdev2",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.telegram,
                  label: "Developer 2",
                  subtitle: "Fast response via Telegram",
                  color: const Color(0xFF0088cc),
                  url: "https://t.me/noprinewera",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: Icons.telegram,
                  label: "Channel Information",
                  subtitle: "Update terbaru & pengumuman",
                  color: const Color(0xFF00BCD4),
                  url: "https://t.me/tokisakiproject01",
                ),
                const SizedBox(height: 10),
                _buildContactCard(
                  icon: FontAwesomeIcons.tiktok,
                  label: "TikTok Developer",
                  subtitle: "content about the application",
                  color: Colors.white54,
                  url: "https://www.tiktok.com/noprinotdev",
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ===== BTC CHART WIDGET (VERSI KECIL & HITAM) =====
  Widget _buildBTCChart() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color: bgBlack,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.white.withOpacity(0.06),
            width: 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ===== HEADER =====
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        '₿',
                        style: TextStyle(
                          color: const Color(0xFFFDB813),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'BTC/USDT',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(
                        _isPriceUp ? Icons.trending_up_rounded : Icons.trending_down_rounded,
                        color: _isPriceUp ? Colors.green : Colors.red,
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        _btcChange,
                        style: TextStyle(
                          color: _isPriceUp ? Colors.green : Colors.red,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        '\$${_currentBTCPrice.toStringAsFixed(2)}',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              
              const SizedBox(height: 6),
              
              // ===== CHART (HEIGHT 80px - KECIL) =====
              SizedBox(
                height: 80,
                child: CustomPaint(
                  painter: _BTCPainter(_btcPrices, _isPriceUp),
                  size: Size(double.infinity, 80),
                ),
              ),
              
              const SizedBox(height: 6),
              
              // ===== DETAIL (COMPACT) =====
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildBTCCompactDetail('High', '\$${_btcHigh.toStringAsFixed(0)}'),
                  _buildBTCCompactDetail('Low', '\$${_btcLow.toStringAsFixed(0)}'),
                  _buildBTCCompactDetail('Vol', '${_btcVolume.toStringAsFixed(0)}'),
                  _buildBTCCompactDetail('Funding', '${(_btcFunding * 100).toStringAsFixed(2)}%'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===== BTC COMPACT DETAIL =====
  Widget _buildBTCCompactDetail(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withOpacity(0.3),
            fontSize: 8,
            fontWeight: FontWeight.w500,
            fontFamily: 'ShareTechMono',
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 10,
            fontWeight: FontWeight.w600,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  // ===== STORY ROW - INTEGRASI DENGAN STORY PAGE =====
  Widget _buildStoryRowBulat() {
    if (_isLoadingStory) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: SizedBox(
          height: 80,
          child: Center(
            child: CircularProgressIndicator(
              color: lightGreen,
              strokeWidth: 2,
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 18,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF6B6B),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                "STORY",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF6B6B).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFFFF6B6B).withOpacity(0.3),
                  ),
                ),
                child: Text(
                  "LIVE",
                  style: TextStyle(
                    color: const Color(0xFFFF6B6B),
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          
          SizedBox(
            height: 85,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: 1 + _storyList.length,
              itemBuilder: (context, index) {
                if (index == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 16),
                    child: GestureDetector(
                      onTap: _uploadStory,
                      child: Column(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.05),
                              border: Border.all(
                                color: lightGreen.withOpacity(0.5),
                                width: 2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: lightGreen.withOpacity(0.15),
                                  blurRadius: 12,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  const Icon(
                                    Icons.add,
                                    color: Colors.white54,
                                    size: 24,
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: Container(
                                      width: 18,
                                      height: 18,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xFF2ECC71),
                                      ),
                                      child: const Icon(
                                        Icons.camera_alt,
                                        color: Colors.white,
                                        size: 10,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Cerita Saya",
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                final storyIndex = index - 1;
                final story = _storyList[storyIndex];
                final String name = story['username'] ?? 'User';
                final String avatar = story['avatar'] ?? '';
                final String time = story['time'] ?? 'now';

                return Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: GestureDetector(
                    onTap: () => _openStoryUser(name),
                    child: Column(
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                const Color(0xFFFF6B6B),
                                const Color(0xFFEE5A24),
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF6B6B).withOpacity(0.3),
                                blurRadius: 12,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black,
                              ),
                              child: avatar.isNotEmpty
                                  ? ClipOval(
                                      child: Image.network(
                                        avatar,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) => Center(
                                          child: Text(
                                            name[0].toUpperCase(),
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  : Center(
                                      child: Text(
                                        name[0].toUpperCase(),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          name.length > 8 ? '${name.substring(0, 8)}...' : name,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        Text(
                          time,
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 8,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ===== UID CARD =====
  Widget _buildUidCard() {
    final String uidValue = uid ?? 'Tidak ada UID';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: lightGreen.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: lightGreen.withOpacity(0.3)),
            ),
            child: Icon(Icons.badge_rounded, color: lightGreen, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "UID / ID",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  uidValue,
                  style: TextStyle(
                    color: lightGreen,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: uidValue));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('✅ UID berhasil disalin!'),
                  duration: Duration(seconds: 2),
                ),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: lightGreen.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: lightGreen.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.copy_rounded, color: lightGreen, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    "SALIN",
                    style: TextStyle(
                      color: lightGreen,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== GLASS CONTAINER =====
  Widget _buildGlassContainer({
    required Widget child,
    EdgeInsetsGeometry? padding,
    Gradient? gradient,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder),
            gradient: gradient,
          ),
          child: child,
        ),
      ),
    );
  }

  // ===== STATUS CARD =====
  Widget _buildStatusCard(String title, String value, IconData icon) {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(15),
      child: Row(
        children: [
          Icon(icon, color: lightGreen, size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(color: Colors.white38, fontSize: 10)),
              Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            ],
          )
        ],
      ),
    );
  }

  // ===== CIRCULAR PROGRESS =====
  double _calculateExpiryProgress() {
    try {
      DateTime expiry = DateTime.parse(expiredDate);
      DateTime now = DateTime.now();
      if (expiry.isBefore(now)) return 0.0;
      int remainingSeconds = expiry.difference(now).inSeconds;
      return (remainingSeconds / (30 * 24 * 60 * 60)).clamp(0.0, 1.0);
    } catch (e) {
      return 0.0;
    }
  }

  Widget _buildCircularProgress() {
    double progressValue = _calculateExpiryProgress();
    return SizedBox(
      height: 50, width: 50,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CircularProgressIndicator(value: 1.0, strokeWidth: 4, color: Colors.white.withOpacity(0.05)),
          CircularProgressIndicator(
            value: progressValue,
            strokeWidth: 4,
            strokeCap: StrokeCap.round,
            color: progressValue < 0.2 ? Colors.redAccent : lightGreen,
          ),
          Center(
            child: Text(
              "${(progressValue * 100).toInt()}%",
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  // ===== LOGOUT HANDLER =====
  Future<void> _handleLogout() async {
    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF0A0A0A),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text(
            "Terminate Session",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: const Text(
            "Hapus data login dan kembali ke halaman awal?",
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("CANCEL", style: TextStyle(color: Colors.white38)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
              onPressed: () => Navigator.pop(context, true),
              child: const Text("LOGOUT"),
            ),
          ],
        ),
      ),
    );

    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (route) => false,
        );
      }
    }
  }

  // ===== QUICK ACTION ICON - BULAT =====
  Widget _buildQuickActionIcon({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  color.withOpacity(0.15),
                  color.withOpacity(0.05),
                ],
              ),
              border: Border.all(
                color: color.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.15),
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Center(
              child: Icon(
                icon,
                color: color,
                size: 30,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              color: Colors.white60,
              fontSize: 11,
              fontWeight: FontWeight.w500,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ===== HELPER WIDGETS =====
  Widget _sectionHeader(IconData icon, String title) => Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: lightGreen.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: lightGreen, size: 16),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 0.5,
            ),
          ),
        ],
      );

  Widget _buildContactCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required String url,
  }) =>
      GestureDetector(
        onTap: () => _openUrl(url),
        child: _buildGlassContainer(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.5)),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 13),
            ],
          ),
        ),
      );

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: const Color(0xFF0A0A0A),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              Icon(Icons.info_outline, color: lightGreen),
              const SizedBox(width: 8),
              const Text(
                "Info & Pengumuman",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
            ],
          ),
          content: Text(
            "Update Terbaru\n\n"
            "• Penambahan Tools Banyak Sekaligus\n"
            "• Memperbagus Dashboard\n"
            "• BTC Chart Real-time!\n"
            "• Dan Lain Lain!\n\n"
            "Terima kasih telah menggunakan NEBULA!",
            style: TextStyle(color: Colors.white70, height: 1.6),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Tutup",
                style: TextStyle(color: lightGreen),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===== DRAWER =====
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgBlack,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentGreen.withOpacity(0.1), bgBlack],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [accentGreen, lightGreen]),
                      boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.3), blurRadius: 12)],
                    ),
                    child: _profileImage != null
                        ? ClipOval(child: Image.file(_profileImage!, fit: BoxFit.cover))
                        : Icon(Icons.person_rounded, color: Colors.white, size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          username,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        _roleBadge(role.toUpperCase()),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                children: [
                  if (role == 'seller' || role == 'reseller')
                    _buildDrawerMenuItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == 'admin')
                    _buildDrawerMenuItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == 'partner')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.handshake,
                      label: "Partner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  if (role == 'moderator')
                    _buildDrawerMenuItem(
                      icon: FontAwesomeIcons.userShield,
                      label: "Moderator Page",
                      onTap: () => _onSidebarTabSelected(4),
                    ),
                  if (role == 'owner')
                    _buildDrawerMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(5),
                    ),
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerMenuItem(
                    icon: Icons.lock_outline_rounded,
                    label: "Ganti Password",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  _buildDrawerMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: _handleLogout,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roleBadge(String text) {
    final lowerRole = text.toLowerCase();
    Color badgeColor;
    if (lowerRole == 'owner') {
      badgeColor = const Color(0xFFFFD700);
    } else if (lowerRole == 'moderator') {
      badgeColor = const Color(0xFF00E5FF);
    } else if (lowerRole == 'partner') {
      badgeColor = const Color(0xFF00E5FF);
    } else if (lowerRole == 'admin') {
      badgeColor = const Color(0xFFFF6D00);
    } else if (lowerRole == 'reseller' || lowerRole == 'seller') {
      badgeColor = const Color(0xFF4CAF50);
    } else {
      badgeColor = Colors.white54;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: badgeColor.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: badgeColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: badgeColor,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? Colors.redAccent : Colors.white70;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isLogout ? Colors.red.withOpacity(0.3) : Colors.white.withOpacity(0.05),
        ),
      ),
      child: ListTile(
        leading: Icon(icon, color: color, size: 20),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : Colors.white70,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: Colors.white38,
          size: 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  // ===== AI FLOATING BUBBLE =====
  Widget _buildAiBubble() {
    return Positioned(
      left: _aiPosition.dx,
      top: _aiPosition.dy,
      child: GestureDetector(
        onTap: () {
          setState(() {
            _isBubbleExpanded = !_isBubbleExpanded;
          });
        },
        onPanUpdate: (details) {
          setState(() {
            _aiPosition = Offset(
              (_aiPosition.dx + details.delta.dx).clamp(0, MediaQuery.of(context).size.width - 200),
              (_aiPosition.dy + details.delta.dy).clamp(0, MediaQuery.of(context).size.height - 80),
            );
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFF121926),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: const Color(0xFF4F46E5).withOpacity(0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF4F46E5).withOpacity(0.25),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF4F46E5),
                      Color(0xFF7C3AED),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF4F46E5).withOpacity(0.4),
                      blurRadius: 15,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    const Icon(
                      FontAwesomeIcons.robot,
                      color: Colors.white,
                      size: 22,
                    ),
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.10),
                          width: 1,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 2,
                      right: 2,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.green.shade400,
                          border: Border.all(
                            color: Colors.black,
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.green.shade400.withOpacity(0.6),
                              blurRadius: 8,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              AnimatedSize(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeInOut,
                child: _isBubbleExpanded
                    ? Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width - 120,
                        ),
                        child: Text(
                          _aiMessage,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w500,
                            height: 1.3,
                          ),
                        ),
                      )
                    : Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        child: Text(
                          _aiMessage.length > 20 
                              ? '${_aiMessage.substring(0, 20)}...' 
                              : _aiMessage,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
              ),
              Container(
                margin: const EdgeInsets.only(right: 6),
                child: Icon(
                  _isBubbleExpanded 
                      ? Icons.keyboard_arrow_up_rounded 
                      : Icons.keyboard_arrow_down_rounded,
                  color: Colors.white.withOpacity(0.3),
                  size: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ===== BUILD =====
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          "Hai, $username",
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: 'Orbitron',
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white70),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu, color: Colors.white70, size: 28),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.headset_mic_outlined, color: Colors.white54),
            tooltip: 'Customer Service',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ContactPage()),
            ),
          ),
          IconButton(
            icon: const Icon(FontAwesomeIcons.userCircle, color: Colors.white54),
            tooltip: 'My Profile',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid,
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [bgBlack, const Color(0xFF0A0A0A), bgBlack],
              ),
            ),
            child: SafeArea(
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),
          ),
          _buildAiBubble(),
        ],
      ),
      extendBody: true,
      bottomNavigationBar: Container(
        padding: EdgeInsets.zero,
        color: Colors.transparent,
        child: GlazeNavBar(
          key: _navBarKey,
          index: _bottomNavIndex,
          backgroundColor: Colors.transparent,
          items: [
            GlazeNavBarItem(
              child: Icon(
                Icons.home_rounded,
                color: _bottomNavIndex == 0 ? lightGreen : Colors.white38,
                size: 26,
              ),
              label: 'Home',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 0 ? lightGreen : Colors.white38,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: _bottomNavIndex == 1 ? lightGreen : Colors.white38,
                size: 26,
              ),
              label: 'WhatsApp',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 1 ? lightGreen : Colors.white38,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.notifications_rounded,
                color: _bottomNavIndex == 2 ? lightGreen : Colors.white38,
                size: 26,
              ),
              label: 'Info',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 2 ? lightGreen : Colors.white38,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            GlazeNavBarItem(
              child: Icon(
                Icons.build_rounded,
                color: _bottomNavIndex == 3 ? lightGreen : Colors.white38,
                size: 26,
              ),
              label: 'Tools',
              labelStyle: TextStyle(
                color: _bottomNavIndex == 3 ? lightGreen : Colors.white38,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
          onTap: (index) {
            _onBottomNavTapped(index);
          },
        ),
      ),
    );
  }
}

// ===== BTC CHART CUSTOM PAINTER =====
class _BTCPainter extends CustomPainter {
  final List<double> prices;
  final bool isUp;

  _BTCPainter(this.prices, this.isUp);

  @override
  void paint(Canvas canvas, Size size) {
    if (prices.length < 2) return;

    final paint = Paint()
      ..color = isUp ? Colors.green : Colors.red
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = (isUp ? Colors.green : Colors.red).withOpacity(0.08)
      ..style = PaintingStyle.fill;

    final min = prices.reduce((a, b) => a < b ? a : b);
    final max = prices.reduce((a, b) => a > b ? a : b);
    final range = max - min;
    final padding = 4.0;

    final path = Path();
    final fillPath = Path();

    for (int i = 0; i < prices.length; i++) {
      double x = (i / (prices.length - 1)) * size.width;
      double y = size.height - 
          (((prices[i] - min) / (range == 0 ? 1 : range)) * (size.height - padding * 2) + padding);

      if (i == 0) {
        path.moveTo(x, y);
        fillPath.moveTo(x, size.height);
        fillPath.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        fillPath.lineTo(x, y);
      }
    }

    canvas.drawPath(path, paint);
    fillPath.lineTo(size.width, size.height);
    fillPath.close();
    canvas.drawPath(fillPath, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// ===== NEWS MEDIA WIDGET =====
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller!.value.size.width,
            height: _controller!.value.size.height,
            child: VideoPlayer(_controller!),
          ),
        );
      }
      return Center(
        child: SizedBox(
          width: 30,
          height: 30,
          child: CircularProgressIndicator(
            color: const Color(0xFF2ECC71),
            strokeWidth: 2,
          ),
        ),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.grey.shade900,
        child: const Icon(Icons.error, color: Color(0xFF2ECC71)),
      ),
    );
  }
}