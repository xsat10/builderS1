import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nova_core/widgets/nova_core_card_stack.dart';

Widget _h({required Color accent, String? title}) {
  return MaterialApp(
    home: Scaffold(
      body: Center(
        child: NovaCoreCardStack(
          cards: [
            NovaCoreStackCard(
              title: title ?? 'NovaCore',
              subtitle: 'SUB',
              badge: 'BADGE',
              accent: accent,
            ),
            NovaCoreStackCard(
              title: 'Developer',
              subtitle: 'SUB2',
              badge: 'BADGE2',
              accent: const Color(0xFF5579F6),
            ),
          ],
        ),
      ),
    ),
  );
}

void main() {
  testWidgets('deck mounts and cycles on tap', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(_h(accent: const Color(0xFFD9A441)));

    // Wait for all entrance/entrance animations to settle is not needed;
    // simply build the deck.
    await tester.pump(const Duration(milliseconds: 100));

    // Tap the deck to trigger a cycle.
    await tester.tap(find.byType(NovaCoreCardStack));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(milliseconds: 300));
  });

  testWidgets('deck survives drag and snap-back', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(_h(accent: const Color(0xFFD9A441)));
    await tester.pump(const Duration(milliseconds: 100));

    final deck = find.byType(NovaCoreCardStack);
    await tester.drag(deck, const Offset(80, 0));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(milliseconds: 300));
  });
}