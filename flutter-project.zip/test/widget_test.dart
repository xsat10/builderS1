import 'package:flutter_test/flutter_test.dart';
import 'package:nova_core/models/user.dart';

void main() {
  group('User Model', () {
    test('User fromJson parses correctly', () {
      final json = {
        'id': 'user_1',
        'email': 'test@example.com',
        'role': 'developer',
        'status': 'active',
        'parent': null,
      };
      final user = User.fromJson(json);
      expect(user.id, 'user_1');
      expect(user.email, 'test@example.com');
      expect(user.role, 'developer');
      expect(user.isDeveloper, true);
      expect(user.isPartner, false);
      expect(user.roleLabel, 'DEVELOPER');
    });

    test('User role identification', () {
      final member = User(id: '1', email: 'm@e.com', role: 'member');
      expect(member.isMember, true);
      expect(member.isDeveloper, false);

      final partner = User(id: '2', email: 'p@e.com', role: 'partner');
      expect(partner.isPartner, true);

      final reseller = User(id: '3', email: 'r@e.com', role: 'reseller');
      expect(reseller.isReseller, true);
    });

    test('User status check', () {
      final active = User(id: '1', email: 'a@e.com', role: 'member', status: 'active');
      expect(active.isActive, true);

      final suspended = User(id: '2', email: 's@e.com', role: 'member', status: 'suspended');
      expect(suspended.isActive, false);
    });

    test('User role labels', () {
      expect(User(id: '1', email: 'e@e.com', role: 'developer').roleLabel, 'DEVELOPER');
      expect(User(id: '2', email: 'e@e.com', role: 'partner').roleLabel, 'PARTNER');
      expect(User(id: '3', email: 'e@e.com', role: 'reseller').roleLabel, 'RESELLER');
      expect(User(id: '4', email: 'e@e.com', role: 'member').roleLabel, 'MEMBER');
    });
  });
}
