// dracin_page.dart
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:ui';

// ─── Palette ──────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A0F1A);
  static const surface   = Color(0xFF0D1525);
  static const card      = Color(0xFF111C30);
  static const cardInner = Color(0xFF162035);
  static const border    = Color(0xFF1C2E48);
  static const borderLit = Color(0xFF1E3A5F);
  static const steel     = Color(0xFF1A4F8A);
  static const blueMid   = Color(0xFF2370BE);
  static const blueLight = Color(0xFF4A94E8);
  static const chrome    = Color(0xFF7AB4E8);
  static const frost     = Color(0xFFADD4F5);
  static const red       = Color(0xFFEF4444);
  static const amber     = Color(0xFFF59E0B);
  static const green     = Color(0xFF22C55E);
  static const purple    = Color(0xFFA78BFA);
  static const pink      = Color(0xFFEC4899);
  static const teal      = Color(0xFF14B8A6);
  static const blue      = Color(0xFF3B82F6);
  static const text      = Color(0xFFDEEEFB);
  static const textSub   = Color(0xFF6A92B8);
  static const textDim   = Color(0xFF2E4E6E);
  static const white     = Color(0xFFFFFFFF);
}

// ═══════════════════════════════════════════════════════════════════════════
//  DRACIN API SERVICE  (dengan fallback multi-format)
// ═══════════════════════════════════════════════════════════════════════════
class DracinApiService {
  // Provider yang dipakai. Ganti kalau mau: dramabox, starshort, reelshort, dll.
  static const String provider = "dramabox";
  static const String baseUrl = "https://dracinapi.com";

  // Header default (kalau suatu saat butuh apiKey, isi di sini)
  static Map<String, String> get _headers => {
    'Accept': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
  };

  /// Helper: coba beberapa URL pattern sampai ada yang berhasil.
  static Future<dynamic> _tryEndpoints(List<Uri> uris) async {
    dynamic lastError;
    for (final uri in uris) {
      try {
        final res = await http
            .get(uri, headers: _headers)
            .timeout(const Duration(seconds: 12));
        if (res.statusCode == 200 && res.body.isNotEmpty) {
          return jsonDecode(res.body);
        }
        lastError = "HTTP ${res.statusCode} @ $uri";
      } catch (e) {
        lastError = "$e @ $uri";
      }
    }
    throw Exception("Semua endpoint gagal: $lastError");
  }

  /// Helper: ambil list dari berbagai kemungkinan key respons
  static List<dynamic> _extractList(dynamic data) {
    if (data is List) return data;
    if (data is Map) {
      for (final key in ['results', 'data', 'items', 'dramas', 'list', 'episodes']) {
        if (data[key] is List) return data[key];
      }
    }
    return [];
  }

  /// Helper: ambil objek dari berbagai kemungkinan key respons
  static Map<String, dynamic> _extractMap(dynamic data) {
    if (data is Map) {
      for (final key in ['drama', 'data', 'result', 'detail']) {
        if (data[key] is Map) return Map<String, dynamic>.from(data[key]);
      }
      return Map<String, dynamic>.from(data);
    }
    return {};
  }

  // ── SEARCH ─────────────────────────────────────────────────────────────
  static Future<List<dynamic>> search(String keyword, {int page = 1}) async {
    final uris = [
      Uri.parse("$baseUrl/$provider/api/v1/search").replace(queryParameters: {
        'keyword': keyword, 'q': keyword, 'page': '$page',
      }),
      Uri.parse("$baseUrl/api/v1/search").replace(queryParameters: {
        'provider': provider, 'keyword': keyword, 'page': '$page',
      }),
      Uri.parse("$baseUrl/search").replace(queryParameters: {
        'provider': provider, 'keyword': keyword, 'q': keyword, 'page': '$page',
      }),
    ];
    final data = await _tryEndpoints(uris);
    return _extractList(data);
  }

  // ── DETAIL ─────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> detail(String id) async {
    final uris = [
      Uri.parse("$baseUrl/$provider/api/v1/detail/$id"),
      Uri.parse("$baseUrl/api/v1/detail").replace(queryParameters: {
        'provider': provider, 'id': id,
      }),
      Uri.parse("$baseUrl/detail").replace(queryParameters: {
        'provider': provider, 'id': id,
      }),
    ];
    final data = await _tryEndpoints(uris);
    return _extractMap(data);
  }

  // ── EPISODES ───────────────────────────────────────────────────────────
  static Future<List<dynamic>> episodes(String id, {int page = 1}) async {
    final uris = [
      Uri.parse("$baseUrl/$provider/api/v1/episodes/$id").replace(
          queryParameters: {'page': '$page'}),
      Uri.parse("$baseUrl/api/v1/episodes").replace(queryParameters: {
        'provider': provider, 'id': id, 'page': '$page',
      }),
      Uri.parse("$baseUrl/episodes").replace(queryParameters: {
        'provider': provider, 'id': id, 'page': '$page',
      }),
    ];
    final data = await _tryEndpoints(uris);
    return _extractList(data);
  }

  // ── PLAY (HLS URL) ─────────────────────────────────────────────────────
  static Future<String> play(String id, int episode) async {
    final uris = [
      Uri.parse("$baseUrl/$provider/api/v1/play/$id/$episode"),
      Uri.parse("$baseUrl/api/v1/play").replace(queryParameters: {
        'provider': provider, 'id': id, 'episode': '$episode',
      }),
      Uri.parse("$baseUrl/play").replace(queryParameters: {
        'provider': provider, 'id': id, 'episode': '$episode',
      }),
    ];
    final data = await _tryEndpoints(uris);
    if (data is Map) {
      for (final key in ['streamUrl', 'hlsUrl', 'url', 'playUrl', 'stream']) {
        if (data[key] != null && data[key].toString().isNotEmpty) {
          return data[key].toString();
        }
      }
      // kadang nested: { data: { streamUrl: '...' } }
      final inner = _extractMap(data);
      for (final key in ['streamUrl', 'hlsUrl', 'url', 'playUrl', 'stream']) {
        if (inner[key] != null && inner[key].toString().isNotEmpty) {
          return inner[key].toString();
        }
      }
    }
    throw Exception("URL stream tidak ditemukan dalam respons.");
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  DRACIN PAGE
// ═══════════════════════════════════════════════════════════════════════════
class DracinPage extends StatefulWidget {
  const DracinPage({super.key});

  @override
  State<DracinPage> createState() => _DracinPageState();
}

class _DracinPageState extends State<DracinPage> with TickerProviderStateMixin {
  // Data state
  List<dynamic> _dramas = [];
  List<dynamic> _searchResults = [];
  bool _isLoading = true;
  bool _isSearching = false;
  String _searchQuery = "";
  int _currentPage = 0;
  bool _hasMore = true;
  String _errorMessage = "";

  // Detail state
  Map<String, dynamic>? _selectedDrama;
  List<dynamic> _episodes = [];
  bool _isLoadingDetail = false;

  // Controllers
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  final ScrollController _scrollController = ScrollController();

  // Animations
  late AnimationController _fadeController;
  late AnimationController _glowController;
  late AnimationController _rotateController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _glowAnimation;
  late Animation<double> _rotateAnimation;

  // Video background
  VideoPlayerController? _videoController;

  // Keyword default untuk mengisi halaman utama (karena tidak ada endpoint "list all")
  static const List<String> _defaultKeywords = ["CEO", "Cinta", "Revenge", "Sweet", "Boss"];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initVideoBackground();
    _fetchDramas();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      if (!_isLoading && _hasMore && !_isSearching) {
        _fetchDramas(page: _currentPage + 1);
      }
    }
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _glowController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2500))
      ..repeat(reverse: true);
    _rotateController =
        AnimationController(vsync: this, duration: const Duration(seconds: 20))
          ..repeat();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic));
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
        CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine));
    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _rotateController, curve: Curves.linear));
    _fadeController.forward();
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/background.mp4')
        ..initialize().then((_) {
          _videoController?.setLooping(true);
          _videoController?.setVolume(0.0);
          _videoController?.play();
          if (mounted) setState(() {});
        }).catchError((e) {});
    } catch (e) {}
  }

  Widget _buildAnimatedBackground() {
    return Stack(
      children: [
        if (_videoController != null && _videoController!.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _videoController!.value.size.width,
                height: _videoController!.value.size.height,
                child: Opacity(
                    opacity: 0.06, child: VideoPlayer(_videoController!)),
              ),
            ),
          )
        else
          Container(color: _C.bg),
        CustomPaint(painter: _GridPainter(), size: Size.infinite),
        AnimatedBuilder(
          animation: _rotateAnimation,
          builder: (context, _) {
            final size = MediaQuery.of(context).size;
            return Stack(
              children: [
                Positioned(
                  bottom: -size.height * 0.15,
                  right: -size.width * 0.2,
                  child: Transform.rotate(
                    angle: _rotateAnimation.value * pi * 2,
                    child: Container(
                      width: size.width * 0.7,
                      height: size.width * 0.7,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: _C.blueLight.withOpacity(0.05), width: 1),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: -size.height * 0.08,
                  left: -size.width * 0.15,
                  child: Transform.rotate(
                    angle: -_rotateAnimation.value * pi,
                    child: Container(
                      width: size.width * 0.5,
                      height: size.width * 0.5,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: _C.blueMid.withOpacity(0.06), width: 0.8),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
        Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.0,
              colors: [Colors.transparent, _C.bg.withOpacity(0.55)],
            ),
          ),
        ),
      ],
    );
  }

  // ── FETCH HOME LIST ────────────────────────────────────────────────────
  Future<void> _fetchDramas({int page = 0}) async {
    if (_isLoading && page != 0) return;
    setState(() {
      _isLoading = true;
      _errorMessage = "";
    });

    try {
      // Ambil dari keyword default yang dirotasi sesuai page
      final keyword = _defaultKeywords[page % _defaultKeywords.length];
      final data = await DracinApiService.search(keyword, page: (page ~/ _defaultKeywords.length) + 1);

      setState(() {
        if (page == 0) {
          _dramas = List.from(data);
        } else {
          // hindari duplikat sederhana berdasarkan id
          final existingIds = _dramas.map((e) => e['id'].toString()).toSet();
          _dramas.addAll(data.where((e) => !existingIds.contains(e['id'].toString())));
        }
        _currentPage = page;
        _hasMore = data.isNotEmpty && page < 10;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = "Gagal memuat data: $e";
        _isLoading = false;
      });
    }
  }

  // ── SEARCH ─────────────────────────────────────────────────────────────
  Future<void> _searchDramas(String query) async {
    if (query.isEmpty) {
      setState(() {
        _isSearching = false;
        _searchResults = [];
      });
      return;
    }
    setState(() {
      _isSearching = true;
      _searchQuery = query;
      _isLoading = true;
    });

    try {
      final data = await DracinApiService.search(query);
      setState(() {
        _searchResults = data;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _searchResults = [];
        _errorMessage = "Pencarian gagal: $e";
        _isLoading = false;
      });
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      _isSearching = false;
      _searchResults = [];
    });
    _searchFocusNode.unfocus();
  }

  // ── DETAIL ─────────────────────────────────────────────────────────────
  Future<void> _fetchDramaDetail(String dramaId) async {
    setState(() => _isLoadingDetail = true);
    try {
      final detail = await DracinApiService.detail(dramaId);
      List<dynamic> episodes = [];
      try {
        episodes = await DracinApiService.episodes(dramaId);
      } catch (_) {}

      setState(() {
        _selectedDrama = detail;
        _episodes = episodes;
        _isLoadingDetail = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = "Gagal memuat detail: $e";
        _isLoadingDetail = false;
      });
    }
  }

  void _showDramaDetail(Map<String, dynamic> drama) async {
    final id = (drama['id'] ?? drama['_id'] ?? drama['dramaId'] ?? '').toString();
    if (id.isEmpty) return;
    await _fetchDramaDetail(id);
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildDramaDetailSheet(),
    ).then((_) => setState(() {
      _selectedDrama = null;
      _episodes = [];
    }));
  }

  Widget _buildDramaDetailSheet() {
    if (_selectedDrama == null || _isLoadingDetail) {
      return Container(
        height: 400,
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: _C.card, borderRadius: BorderRadius.circular(28)),
        child: const Center(
            child: CircularProgressIndicator(color: _C.blueLight)),
      );
    }

    final drama = _selectedDrama!;
    final title = (drama['title'] ?? drama['name'] ?? 'Unknown').toString();
    final imageUrl =
        (drama['cover'] ?? drama['poster'] ?? drama['thumbnail'] ?? '').toString();
    final rating = (drama['rating'] ?? drama['score'] ?? 'N/A').toString();
    final year = (drama['year'] ?? drama['releaseDate'] ?? '').toString();
    final summary =
        (drama['desc'] ?? drama['synopsis'] ?? drama['description'] ?? 'No synopsis available.')
            .toString()
            .replaceAll(RegExp(r'<[^>]*>'), '');
    final genresRaw = (drama['genre'] ?? drama['genres'] ?? '').toString();
    final genres = genresRaw.isEmpty
        ? <String>[]
        : genresRaw.split(',').map((g) => g.trim()).where((g) => g.isNotEmpty).toList();

    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      margin: const EdgeInsets.all(16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              color: _C.surface.withOpacity(0.98),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: _C.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 240,
                  decoration: BoxDecoration(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(28)),
                    image: imageUrl.isNotEmpty
                        ? DecorationImage(
                            image: NetworkImage(imageUrl), fit: BoxFit.cover)
                        : null,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, _C.surface.withOpacity(0.95)],
                      ),
                    ),
                    child: SafeArea(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: Icon(Icons.close, color: _C.blueLight, size: 28),
                            onPressed: () => Navigator.pop(context),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            margin: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: _C.amber.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.star, size: 14, color: Colors.black),
                                const SizedBox(width: 4),
                                Text(rating,
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(
                                color: _C.text,
                                fontSize: 22,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 16,
                          children: [
                            if (year.isNotEmpty)
                              _buildInfoChip(Icons.calendar_today, year),
                            _buildInfoChip(Icons.tv, DracinApiService.provider),
                          ],
                        ),
                        const SizedBox(height: 16),
                        if (genres.isNotEmpty)
                          Wrap(
                            spacing: 8,
                            children: genres
                                .map<Widget>((genre) => Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: _C.blueMid.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(
                                            color: _C.blueLight.withOpacity(0.2)),
                                      ),
                                      child: Text(genre,
                                          style: TextStyle(
                                              color: _C.blueLight, fontSize: 10)),
                                    ))
                                .toList(),
                          ),
                        const SizedBox(height: 20),
                        Text("Sinopsis",
                            style: TextStyle(
                                color: _C.blueLight,
                                fontSize: 14,
                                fontWeight: FontWeight.w800)),
                        const SizedBox(height: 8),
                        Text(summary,
                            style: TextStyle(
                                color: _C.textSub, fontSize: 12, height: 1.5)),
                        const SizedBox(height: 24),
                        Row(
                          children: [
                            Container(
                                width: 3,
                                height: 18,
                                decoration: BoxDecoration(
                                    color: _C.blueLight,
                                    borderRadius: BorderRadius.circular(2))),
                            const SizedBox(width: 10),
                            Text("EPISODE",
                                style: TextStyle(
                                    color: _C.blueLight,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 3)),
                            const Spacer(),
                            Text("${_episodes.length} Tersedia",
                                style:
                                    TextStyle(color: _C.textSub, fontSize: 11)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (_episodes.isEmpty)
                          Container(
                              padding: const EdgeInsets.all(40),
                              alignment: Alignment.center,
                              child: Text("Belum ada episode",
                                  style: TextStyle(color: _C.textSub)))
                        else
                          ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _episodes.length,
                            itemBuilder: (context, index) {
                              final ep = _episodes[index];
                              final epNum = int.tryParse(
                                      (ep['number'] ?? ep['episode'] ?? '${index + 1}')
                                          .toString()) ??
                                  (index + 1);
                              return GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => DramaPlayerScreen(
                                                dramaId: (drama['id'] ??
                                                        drama['_id'] ??
                                                        drama['dramaId'] ??
                                                        '')
                                                    .toString(),
                                                episodeTitle:
                                                    "$title - Episode $epNum",
                                                episodeNumber: epNum,
                                              )));
                                },
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 8),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: _C.card,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: _C.border),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 45,
                                        height: 45,
                                        decoration: BoxDecoration(
                                            color: _C.blueMid.withOpacity(0.15),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Center(
                                            child: Text("$epNum",
                                                style: TextStyle(
                                                    color: _C.blueLight,
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.w800))),
                                      ),
                                      const SizedBox(width: 14),
                                      Expanded(
                                        child: Text("Episode $epNum",
                                            style: const TextStyle(
                                                color: _C.text,
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                            color: _C.blueMid.withOpacity(0.1),
                                            shape: BoxShape.circle),
                                        child: Icon(Icons.play_arrow,
                                            color: _C.blueLight, size: 20),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 12, color: _C.textSub),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(color: _C.textSub, fontSize: 11)),
    ]);
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: AnimatedBuilder(
        animation: _glowAnimation,
        builder: (context, _) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.blueLight.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: _C.blueLight.withOpacity(0.12 * _glowAnimation.value),
                  blurRadius: 20,
                  spreadRadius: 2)
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.blueMid.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _C.blueLight.withOpacity(0.2)),
                ),
                child: const Icon(Icons.live_tv, color: _C.blueLight, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                              colors: [_C.blueLight, _C.chrome, _C.blueMid])
                          .createShader(bounds),
                      child: const Text("C-DRAMA",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 3)),
                    ),
                    const SizedBox(height: 4),
                    Text(
                        _isSearching
                            ? "Hasil Pencarian"
                            : "${_dramas.length} Drama",
                        style: TextStyle(color: _C.textSub, fontSize: 11)),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  if (!_isSearching) {
                    setState(() {
                      _currentPage = 0;
                      _dramas = [];
                      _fetchDramas();
                    });
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: _C.blueMid.withOpacity(0.08),
                      shape: BoxShape.circle,
                      border: Border.all(color: _C.blueLight.withOpacity(0.2))),
                  child: Icon(Icons.refresh, color: _C.blueLight, size: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border)),
        child: TextField(
          controller: _searchController,
          focusNode: _searchFocusNode,
          style: TextStyle(color: _C.text, fontSize: 14),
          decoration: InputDecoration(
            hintText: "Cari drama China...",
            hintStyle: TextStyle(color: _C.textSub, fontSize: 13),
            prefixIcon: Icon(Icons.search, color: _C.blueLight, size: 20),
            suffixIcon: _searchController.text.isNotEmpty
                ? IconButton(
                    icon: Icon(Icons.clear, color: _C.blueLight, size: 18),
                    onPressed: _clearSearch)
                : null,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
          onChanged: (value) {
            if (value.isNotEmpty) _searchDramas(value);
            else _clearSearch();
          },
        ),
      ),
    );
  }

  Widget _buildDramaGrid() {
    final displayList = _isSearching ? _searchResults : _dramas;
    if (displayList.isEmpty && !_isLoading) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.movie, size: 64, color: _C.textSub.withOpacity(0.2)),
                const SizedBox(height: 16),
                Text(
                    _errorMessage.isNotEmpty
                        ? _errorMessage
                        : "Tidak ada data ditemukan",
                    style: TextStyle(color: _C.textSub, fontSize: 12),
                    textAlign: TextAlign.center),
                const SizedBox(height: 12),
                TextButton.icon(
                    onPressed: () {
                      if (_isSearching) {
                        _searchDramas(_searchQuery);
                      } else {
                        setState(() {
                          _currentPage = 0;
                          _dramas = [];
                        });
                        _fetchDramas();
                      }
                    },
                    icon: const Icon(Icons.refresh, color: _C.blueLight),
                    label: const Text("Coba Lagi",
                        style: TextStyle(color: _C.blueLight))),
              ]),
        ),
      );
    }
    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.65,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: displayList.length +
          (_hasMore && !_isSearching && !_isLoading ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == displayList.length && _hasMore && !_isSearching) {
          return const Center(
              child: Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(color: _C.blueLight)));
        }
        return _buildDramaCard(displayList[index]);
      },
    );
  }

  Widget _buildDramaCard(Map<String, dynamic> drama) {
    final title = (drama['title'] ?? drama['name'] ?? 'Unknown').toString();
    final imageUrl =
        (drama['cover'] ?? drama['poster'] ?? drama['thumbnail'] ?? '').toString();
    final rating = (drama['rating'] ?? drama['score'] ?? 'N/A').toString();

    return GestureDetector(
      onTap: () => _showDramaDetail(drama),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(
                children: [
                  imageUrl.isNotEmpty
                      ? Image.network(imageUrl,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Container(color: _C.surface))
                      : Container(color: _C.surface),
                  Container(
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.7)
                              ]))),
                  Positioned(
                    bottom: 8,
                    left: 8,
                    child: Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                          color: _C.amber.withOpacity(0.9),
                          borderRadius: BorderRadius.circular(8)),
                      child: Row(children: [
                        const Icon(Icons.star, size: 10, color: Colors.black),
                        const SizedBox(width: 2),
                        Text(rating,
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 10,
                                fontWeight: FontWeight.bold))
                      ]),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(title,
              style: const TextStyle(
                  color: _C.text, fontSize: 13, fontWeight: FontWeight.w700),
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
            height: 1,
            decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
              Colors.transparent,
              _C.blueLight.withOpacity(0.1),
              Colors.transparent
            ]))),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildFooterDot(_C.green),
            const SizedBox(width: 8),
            _buildFooterText("STREAMING"),
            const SizedBox(width: 20),
            Container(
                width: 1, height: 10, color: _C.textSub.withOpacity(0.06)),
            const SizedBox(width: 20),
            Icon(Icons.fingerprint,
                color: _C.textSub.withOpacity(0.12), size: 12),
            const SizedBox(width: 20),
            _buildFooterDot(_C.blueLight),
            const SizedBox(width: 8),
            _buildFooterText("C-DRAMA"),
          ],
        ),
        const SizedBox(height: 8),
        Text("ASTRAL • CHINESE DRAMA STREAMING",
            style: TextStyle(
                color: _C.textSub.withOpacity(0.1),
                fontSize: 8,
                letterSpacing: 3,
                fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _buildFooterDot(Color color) => Container(
      width: 5,
      height: 5,
      decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: color, blurRadius: 5)]));

  Widget _buildFooterText(String text) => Text(text,
      style: TextStyle(
          color: _C.textSub.withOpacity(0.25),
          fontSize: 8,
          fontWeight: FontWeight.w700,
          letterSpacing: 2.5));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                _buildSearchBar(),
                Expanded(
                  child: _isLoading && _dramas.isEmpty && !_isSearching
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: _C.blueLight, strokeWidth: 3))
                      : FadeTransition(
                          opacity: _fadeAnimation, child: _buildDramaGrid()),
                ),
                _buildFooter(),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _glowController.dispose();
    _rotateController.dispose();
    _scrollController.dispose();
    _videoController?.dispose();
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }
}

// ─── Grid Background Painter ──────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.border.withOpacity(0.22)
      ..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter old) => false;
}

// ═══════════════════════════════════════════════════════════════════════════
//  PLAYER SCREEN
// ═══════════════════════════════════════════════════════════════════════════
class DramaPlayerScreen extends StatefulWidget {
  final String dramaId;
  final String episodeTitle;
  final int episodeNumber;

  const DramaPlayerScreen({
    super.key,
    required this.dramaId,
    required this.episodeTitle,
    required this.episodeNumber,
  });

  @override
  State<DramaPlayerScreen> createState() => _DramaPlayerScreenState();
}

class _DramaPlayerScreenState extends State<DramaPlayerScreen> {
  WebViewController? _controller;
  bool _isLoading = true;
  String _errorMessage = '';
  String _streamUrl = '';

  @override
  void initState() {
    super.initState();
    _loadStream();
  }

  Future<void> _loadStream() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final url = await DracinApiService.play(
          widget.dramaId, widget.episodeNumber);

      if (url.isEmpty) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'URL stream kosong dari server.';
        });
        return;
      }

      _streamUrl = url;

      // Kalau HLS (.m3u8) pakai video_player biar smooth
      if (url.contains('.m3u8')) {
        _initVideoPlayer(url);
      } else {
        _initWebView(url);
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Gagal memuat stream:\n$e';
      });
    }
  }

  // ── Video Player untuk HLS ─────────────────────────────────────────────
  VideoPlayerController? _videoController;

  Future<void> _initVideoPlayer(String url) async {
    try {
      _videoController =
          VideoPlayerController.networkUrl(Uri.parse(url), httpHeaders: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        'Referer': 'https://dracinapi.com/',
      });
      await _videoController!.initialize();
      await _videoController!.play();
      if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      // fallback ke WebView kalau video_player gagal
      _initWebView(url);
    }
  }

  // ── WebView untuk URL non-HLS / embed ──────────────────────────────────
  void _initWebView(String url) {
    final html = '''
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { margin:0; background:#000; display:flex; align-items:center; justify-content:center; height:100vh; }
  video { width:100%; max-height:100vh; background:#000; }
  iframe { width:100%; height:100vh; border:0; }
</style>
</head>
<body>
  ${url.contains('.m3u8')
        ? '<video controls autoplay playsinline src="$url"></video>'
        : '<iframe src="$url" allowfullscreen allow="autoplay; encrypted-media"></iframe>'}
</body>
</html>
''';

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          if (mounted) setState(() => _isLoading = false);
        },
        onWebResourceError: (err) {
          if (mounted) {
            setState(() {
              _isLoading = false;
              _errorMessage = 'WebView error: ${err.description}';
            });
          }
        },
      ))
      ..loadHtmlString(html);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded,
              color: _C.blueLight, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.episodeTitle,
          style: const TextStyle(
              color: _C.text, fontSize: 14, fontWeight: FontWeight.w600),
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Stack(
        children: [
          // Konten utama
          if (_errorMessage.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline,
                        color: _C.red, size: 48),
                    const SizedBox(height: 12),
                    Text(_errorMessage,
                        style: const TextStyle(color: _C.textSub),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    TextButton.icon(
                        onPressed: _loadStream,
                        icon: const Icon(Icons.refresh, color: _C.blueLight),
                        label: const Text("Coba Lagi",
                            style: TextStyle(color: _C.blueLight))),
                  ],
                ),
              ),
            )
          else if (_videoController != null &&
              _videoController!.value.isInitialized)
            Center(
              child: AspectRatio(
                aspectRatio: _videoController!.value.aspectRatio,
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    VideoPlayer(_videoController!),
                    VideoProgressIndicator(_videoController!,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                            playedColor: _C.blueLight,
                            bufferedColor: _C.textSub,
                            backgroundColor: _C.border)),
                    Positioned(
                      bottom: 24,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            icon: Icon(
                                _videoController!.value.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: Colors.white,
                                size: 32),
                            onPressed: () {
                              setState(() {
                                _videoController!.value.isPlaying
                                    ? _videoController!.pause()
                                    : _videoController!.play();
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
          else if (_controller != null)
            WebViewWidget(controller: _controller!),

          // Loading overlay
          if (_isLoading)
            Container(
              color: Colors.black.withOpacity(0.7),
              child: const Center(
                  child: CircularProgressIndicator(color: _C.blueLight)),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }
}