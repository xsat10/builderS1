import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:http_parser/http_parser.dart' as http_parser;
import 'package:cached_network_image/cached_network_image.dart';
import 'api_config.dart';

// ─── Colors ───────────────────────────────────────────────────────────────────
const Color _kBg      = Color(0xFF0D1117);
const Color _kCard    = Color(0xFF161B22);
const Color _kBorder  = Color(0xFF30363D);
const Color _kCyan    = Color(0xFF00B0FF);
const Color _kBlue    = Color(0xFF1565C0);
const Color _kGreen   = Color(0xFF00E676);
const Color _kWhite   = Colors.white;
const Color _kWhite54 = Colors.white54;
const Color _kWhite24 = Colors.white24;
const Color _kRed     = Color(0xFFFF1744);
const Color _kPurple  = Color(0xFF7C4DFF);
const Color _kOrange  = Color(0xFFFF9100);

// ⚙️ SETTING: true = pakai dummy lokal, false = fetch dari server
const bool USE_DUMMY_STORIES = true;

// ─── Story Model ──────────────────────────────────────────────────────────────
class StoryItem {
  final String storyId;
  final String username;
  final String mediaUrl;
  final String mediaType; // 'image' or 'video'
  final String caption;
  final int likeCount;
  final int viewCount;
  final bool isLiked;
  final bool isOwner;
  final String createdAt;

  StoryItem({
    required this.storyId,
    required this.username,
    required this.mediaUrl,
    required this.mediaType,
    required this.caption,
    required this.likeCount,
    required this.viewCount,
    required this.isLiked,
    required this.isOwner,
    required this.createdAt,
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
    storyId:   j['story_id']?.toString() ?? '',
    username:  j['username']?.toString() ?? '',
    mediaUrl:  j['media_url']?.toString() ?? '',
    mediaType: j['media_type']?.toString() ?? 'image',
    caption:   j['caption']?.toString() ?? '',
    likeCount: j['like_count'] ?? 0,
    viewCount: j['view_count'] ?? 0,
    isLiked:   j['is_liked'] == true,
    isOwner:   j['is_owner'] == true,
    createdAt: j['created_at']?.toString() ?? '',
  );

  StoryItem copyWith({
    int? likeCount,
    int? viewCount,
    bool? isLiked,
  }) => StoryItem(
    storyId: storyId,
    username: username,
    mediaUrl: mediaUrl,
    mediaType: mediaType,
    caption: caption,
    likeCount: likeCount ?? this.likeCount,
    viewCount: viewCount ?? this.viewCount,
    isLiked: isLiked ?? this.isLiked,
    isOwner: isOwner,
    createdAt: createdAt,
  );
}

class UserStoryGroup {
  final String username;
  final List<StoryItem> stories;
  final bool hasUnviewed;

  UserStoryGroup({
    required this.username,
    required this.stories,
    required this.hasUnviewed,
  });

  String? get firstImageUrl {
    for (final s in stories) {
      if (s.mediaType == 'image' && s.mediaUrl.isNotEmpty) return s.mediaUrl;
    }
    return null;
  }

  String get firstMediaUrl => stories.isNotEmpty ? stories.first.mediaUrl : '';
  String get firstMediaType => stories.isNotEmpty ? stories.first.mediaType : 'image';
}

// ═══════════════════════════════════════════════════════════════════════════════
// 📦 DUMMY DATA — biar UI langsung kelihatan
// ═══════════════════════════════════════════════════════════════════════════════
class DummyStories {
  static List<StoryItem> get myStories => [];

  static List<UserStoryGroup> get otherStories => [
    UserStoryGroup(
      username: 'inixaka',
      hasUnviewed: true,
      stories: [
        StoryItem(
          storyId: 'd1',
          username: 'inixaka',
          mediaUrl: 'https://picsum.photos/seed/inixaka1/500/900',
          mediaType: 'image',
          caption: 'Hari ini cerah ☀️',
          likeCount: 12,
          viewCount: 0,
          isLiked: false,
          isOwner: false,
          createdAt: '2 jam lalu',
        ),
        StoryItem(
          storyId: 'd2',
          username: 'inixaka',
          mediaUrl: 'https://picsum.photos/seed/inixaka2/500/900',
          mediaType: 'image',
          caption: 'Ngopi dulu ☕',
          likeCount: 5,
          viewCount: 0,
          isLiked: false,
          isOwner: false,
          createdAt: '1 jam lalu',
        ),
      ],
    ),
    UserStoryGroup(
      username: 'budi',
      hasUnviewed: true,
      stories: [
        StoryItem(
          storyId: 'd3',
          username: 'budi',
          mediaUrl: 'https://picsum.photos/seed/budi1/500/900',
          mediaType: 'image',
          caption: 'Otw kerja 🚗',
          likeCount: 8,
          viewCount: 0,
          isLiked: false,
          isOwner: false,
          createdAt: '3 jam lalu',
        ),
      ],
    ),
    UserStoryGroup(
      username: 'sarah',
      hasUnviewed: false,
      stories: [
        StoryItem(
          storyId: 'd4',
          username: 'sarah',
          mediaUrl: 'https://picsum.photos/seed/sarah1/500/900',
          mediaType: 'image',
          caption: 'Weekend vibes 🌴',
          likeCount: 21,
          viewCount: 5,
          isLiked: false,
          isOwner: false,
          createdAt: '1 hari lalu',
        ),
      ],
    ),
    UserStoryGroup(
      username: 'andi',
      hasUnviewed: true,
      stories: [
        StoryItem(
          storyId: 'd5',
          username: 'andi',
          mediaUrl: 'https://picsum.photos/seed/andi1/500/900',
          mediaType: 'image',
          caption: 'Mabar yuk 🎮',
          likeCount: 3,
          viewCount: 0,
          isLiked: false,
          isOwner: false,
          createdAt: '30 menit lalu',
        ),
      ],
    ),
  ];
}

// ─── Story Page ───────────────────────────────────────────────────────────────
class StoryPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StoryPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StoryPage> createState() => _StoryPageState();
}

class _StoryPageState extends State<StoryPage> {
  List<StoryItem> _myStories = [];
  List<UserStoryGroup> _otherStories = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchStories();
  }

  // ═══════════════════════════════════════════════════════════
  // 📥 FETCH STORIES
  // ═══════════════════════════════════════════════════════════
  Future<void> _fetchStories() async {
    if (!mounted) return;
    setState(() { _loading = true; _error = null; });

    // ── MODE DUMMY (server belum siap) ──
    if (USE_DUMMY_STORIES) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      setState(() {
        _myStories = DummyStories.myStories;
        _otherStories = DummyStories.otherStories;
        _loading = false;
        _error = null;
      });
      return;
    }

    // ── MODE SERVER ──
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getStories?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 12));

      if (!mounted) return;

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final List allStories = data['stories'] ?? [];
          final items = allStories
              .map((e) => StoryItem.fromJson(e as Map<String, dynamic>))
              .toList();

          final mine = items.where((s) => s.username == widget.username).toList();

          final Map<String, List<StoryItem>> grouped = {};
          for (final s in items.where((s) => s.username != widget.username)) {
            grouped.putIfAbsent(s.username, () => []).add(s);
          }

          final others = grouped.entries.map((e) => UserStoryGroup(
            username: e.key,
            stories: e.value,
            hasUnviewed: e.value.any((s) => s.viewCount == 0),
          )).toList();

          setState(() {
            _myStories = mine;
            _otherStories = others;
            _loading = false;
          });
        } else {
          setState(() {
            _error = data['message'] ?? 'Gagal memuat story';
            _loading = false;
          });
        }
      } else {
        // Kalau server error, fallback ke dummy biar UI tetap jalan
        setState(() {
          _myStories = DummyStories.myStories;
          _otherStories = DummyStories.otherStories;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      if (!mounted) return;
      // Fallback ke dummy saat koneksi gagal
      setState(() {
        _myStories = DummyStories.myStories;
        _otherStories = DummyStories.otherStories;
        _loading = false;
        _error = null;
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 📤 UPLOAD STORY
  // ═══════════════════════════════════════════════════════════
  Future<void> _uploadStory({
    required File file,
    required String type,
    String caption = '',
  }) async {
    // Kalau mode dummy, langsung tambahin ke list lokal
    if (USE_DUMMY_STORIES) {
      final newStory = StoryItem(
        storyId: 'local_${DateTime.now().millisecondsSinceEpoch}',
        username: widget.username,
        mediaUrl: file.path,
        mediaType: type,
        caption: caption,
        likeCount: 0,
        viewCount: 0,
        isLiked: false,
        isOwner: true,
        createdAt: 'Baru saja',
      );
      setState(() {
        _myStories = [newStory, ..._myStories];
      });
      _showSnack('Story ditambahkan (mode lokal)', _kGreen);
      return;
    }

    // Mode server
    if (mounted) setState(() => _loading = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/uploadStory'));
      req.fields['key']        = widget.sessionKey;
      req.fields['caption']    = caption;
      req.fields['media_type'] = type;

      String mimeType;
      final ext = file.path.split('.').last.toLowerCase();
      if (type == 'video') {
        mimeType = ext == 'mov' ? 'video/quicktime' : 'video/mp4';
      } else {
        mimeType = ext == 'png'
            ? 'image/png'
            : ext == 'webp'
                ? 'image/webp'
                : 'image/jpeg';
      }

      req.files.add(await http.MultipartFile.fromPath(
        'media',
        file.path,
        contentType: http_parser.MediaType.parse(mimeType),
      ));

      final streamed = await req.send().timeout(const Duration(seconds: 180));
      final res = await http.Response.fromStream(streamed);

      if (!mounted) return;

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          _showSnack('Story berhasil diunggah!', _kGreen);
          _fetchStories();
        } else {
          _showSnack(data['message'] ?? 'Gagal upload', _kRed);
          if (mounted) setState(() => _loading = false);
        }
      } else {
        _showSnack('Server error ${res.statusCode}', _kRed);
        if (mounted) setState(() => _loading = false);
      }
    } catch (e) {
      _showSnack('Upload gagal: cek koneksi', _kRed);
      if (mounted) setState(() => _loading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 🗑️ DELETE STORY
  // ═══════════════════════════════════════════════════════════
  Future<void> _deleteStory(String storyId) async {
    if (USE_DUMMY_STORIES) {
      setState(() {
        _myStories = _myStories.where((s) => s.storyId != storyId).toList();
      });
      _showSnack('Story dihapus', _kCyan);
      return;
    }

    try {
      final res = await http.post(
        Uri.parse('$baseUrl/deleteStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': storyId}),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Story dihapus', _kCyan);
        _fetchStories();
      } else {
        _showSnack(data['message'] ?? 'Gagal hapus', _kRed);
      }
    } catch (_) {
      _showSnack('Gagal menghapus', _kRed);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 📸 PICK & UPLOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _pickAndUpload(ImageSource source, String type) async {
    final picker = ImagePicker();
    XFile? picked;
    if (type == 'image') {
      picked = await picker.pickImage(source: source, imageQuality: 80);
    } else {
      picked = await picker.pickVideo(source: source);
    }
    if (picked == null) return;

    String caption = '';
    if (mounted) {
      final ctrl = TextEditingController();
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: _kCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: _kBorder),
          ),
          title: const Text('Tambah Keterangan',
              style: TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 16)),
          content: TextField(
            controller: ctrl,
            style: const TextStyle(color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 14),
            decoration: const InputDecoration(
              hintText: 'Tulis sesuatu... (opsional)',
              hintStyle: TextStyle(color: _kWhite54),
              border: OutlineInputBorder(),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: _kBorder)),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: _kCyan)),
            ),
            maxLines: 3,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: _kWhite54)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _kCyan,
                foregroundColor: _kBg,
              ),
              onPressed: () {
                caption = ctrl.text.trim();
                Navigator.pop(context);
              },
              child: const Text('Unggah',
                  style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      );
    }

    _uploadStory(file: File(picked.path), type: type, caption: caption);
  }

  // ═══════════════════════════════════════════════════════════
  // 📋 BOTTOM SHEET
  // ═══════════════════════════════════════════════════════════
  void _showAddStorySheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _kCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                color: _kBorder,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Tambah Status',
                style: TextStyle(color: _kWhite, fontSize: 16,
                    fontWeight: FontWeight.bold, fontFamily: 'ShareTechMono')),
            const SizedBox(height: 20),
            _sheetOption(Icons.photo_camera_rounded, 'Foto dari Kamera', _kCyan, () {
              Navigator.pop(context);
              _pickAndUpload(ImageSource.camera, 'image');
            }),
            const SizedBox(height: 12),
            _sheetOption(Icons.photo_library_rounded, 'Foto dari Galeri', _kGreen, () {
              Navigator.pop(context);
              _pickAndUpload(ImageSource.gallery, 'image');
            }),
            const SizedBox(height: 12),
            _sheetOption(Icons.videocam_rounded, 'Video dari Kamera', _kPurple, () {
              Navigator.pop(context);
              _pickAndUpload(ImageSource.camera, 'video');
            }),
            const SizedBox(height: 12),
            _sheetOption(Icons.video_library_rounded, 'Video dari Galeri', _kOrange, () {
              Navigator.pop(context);
              _pickAndUpload(ImageSource.gallery, 'video');
            }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _sheetOption(IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 14),
            Text(label,
                style: TextStyle(color: color, fontFamily: 'ShareTechMono',
                    fontSize: 14, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📖 OPEN VIEWER
  // ═══════════════════════════════════════════════════════════
  void _openStoryViewer(
    List<StoryItem> stories,
    int startIndex, {
    bool canDelete = false,
  }) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _StoryViewer(
          stories: stories,
          startIndex: startIndex,
          sessionKey: widget.sessionKey,
          currentUser: widget.username,
          onDelete: canDelete ? _deleteStory : null,
        ),
      ),
    ).then((_) => _fetchStories());
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(color: _kWhite, fontFamily: 'ShareTechMono')),
        backgroundColor: color.withOpacity(0.85),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🎨 BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        foregroundColor: _kWhite,
        title: const Text('Story',
            style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 20,
                fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          if (USE_DUMMY_STORIES)
            Container(
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _kOrange.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _kOrange.withOpacity(0.6)),
              ),
              child: const Center(
                child: Text('DUMMY',
                    style: TextStyle(color: _kOrange, fontSize: 9,
                        fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _kCyan),
            onPressed: _fetchStories,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _kCyan))
          : _error != null
              ? _buildError()
              : RefreshIndicator(
                  color: _kCyan,
                  onRefresh: _fetchStories,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    children: [
                      const Padding(
                        padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: Text('STORY',
                            style: TextStyle(color: _kWhite54, fontSize: 12,
                                fontFamily: 'ShareTechMono', letterSpacing: 1.5)),
                      ),

                      // ── Story bar horizontal ──
                      _buildStoryBar(),

                      // ── Section story baru ──
                      if (_otherStories.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        const Padding(
                          padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                          child: Text('STORY TERBARU',
                              style: TextStyle(color: _kWhite54, fontSize: 12,
                                  fontFamily: 'ShareTechMono', letterSpacing: 1.5)),
                        ),
                        ..._otherStories.map(_buildOtherStoryTile),
                      ] else ...[
                        const SizedBox(height: 40),
                        const Center(
                          child: Text('Belum ada story dari pengguna lain',
                              style: TextStyle(color: _kWhite54,
                                  fontFamily: 'ShareTechMono', fontSize: 13)),
                        ),
                      ],

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, color: _kRed, size: 48),
          const SizedBox(height: 12),
          Text(_error!,
              style: const TextStyle(color: _kWhite54, fontFamily: 'ShareTechMono')),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _kCyan,
              foregroundColor: _kBg,
            ),
            onPressed: _fetchStories,
            child: const Text('Coba Lagi'),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📖 STORY BAR (horizontal)
  // ═══════════════════════════════════════════════════════════
  Widget _buildStoryBar() {
    return SizedBox(
      height: 100,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        children: [
          _buildMyStoryItem(),
          ..._otherStories.map((g) => _buildStoryBarItem(g)).toList(),
        ],
      ),
    );
  }

  Widget _buildMyStoryItem() {
    final hasStories = _myStories.isNotEmpty;
    final firstImage = _myStories.isNotEmpty
        ? _myStories.firstWhere(
            (s) => s.mediaType == 'image',
            orElse: () => _myStories.first,
          ).mediaUrl
        : null;

    return GestureDetector(
      onTap: hasStories
          ? () => _openStoryViewer(_myStories, 0, canDelete: true)
          : _showAddStorySheet,
      child: Container(
        width: 76,
        margin: const EdgeInsets.only(right: 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 66, height: 66,
                  padding: const EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: hasStories
                        ? LinearGradient(
                            colors: [_kCyan, _kBlue],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: hasStories ? null : _kWhite24,
                    boxShadow: hasStories
                        ? [BoxShadow(color: _kCyan.withOpacity(0.55), blurRadius: 12)]
                        : null,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kBg,
                      border: Border.all(color: _kBg, width: 2),
                    ),
                    padding: const EdgeInsets.all(2),
                    child: ClipOval(
                      child: (firstImage != null && firstImage.isNotEmpty)
                          ? (firstImage.startsWith('http')
                              ? CachedNetworkImage(
                                  imageUrl: firstImage,
                                  fit: BoxFit.cover,
                                  placeholder: (_, __) => Container(
                                    color: _kCard,
                                    child: const Icon(Icons.person, color: _kWhite54, size: 26),
                                  ),
                                  errorWidget: (_, __, ___) => Container(
                                    color: _kCard,
                                    child: const Icon(Icons.person, color: _kWhite54, size: 26),
                                  ),
                                )
                              : Image.file(File(firstImage),
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: _kCard,
                                    child: const Icon(Icons.person, color: _kWhite54, size: 26),
                                  )))
                          : const Icon(Icons.person, color: _kWhite54, size: 26),
                    ),
                  ),
                ),
                Positioned(
                  bottom: -2, right: -2,
                  child: Container(
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kCyan,
                      border: Border.all(color: _kBg, width: 2),
                      boxShadow: [
                        BoxShadow(color: _kCyan.withOpacity(0.9), blurRadius: 8),
                      ],
                    ),
                    child: Icon(Icons.add, color: _kBg, size: 14),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'Cerita Saya',
              style: TextStyle(
                color: _kWhite,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryBarItem(UserStoryGroup group) {
    final avatar = group.firstImageUrl;
    final hasUnviewed = group.hasUnviewed;

    return GestureDetector(
      onTap: () {
        // tandai sudah dilihat
        setState(() => group.stories.forEach((s) {
          // trigger rebuild
        }));
        _openStoryViewer(group.stories, 0);
      },
      child: Container(
        width: 76,
        margin: const EdgeInsets.only(right: 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 66, height: 66,
                  padding: const EdgeInsets.all(2.5),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: hasUnviewed
                        ? LinearGradient(
                            colors: [_kCyan, _kBlue],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: hasUnviewed ? null : _kWhite24,
                    boxShadow: hasUnviewed
                        ? [BoxShadow(color: _kCyan.withOpacity(0.55), blurRadius: 12)]
                        : null,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _kBg,
                      border: Border.all(color: _kBg, width: 2),
                    ),
                    padding: const EdgeInsets.all(2),
                    child: ClipOval(
                      child: (avatar != null && avatar.isNotEmpty)
                          ? CachedNetworkImage(
                              imageUrl: avatar,
                              fit: BoxFit.cover,
                              placeholder: (_, __) => Container(
                                color: _kCard,
                                child: const Icon(Icons.person, color: _kWhite54, size: 26),
                              ),
                              errorWidget: (_, __, ___) => Container(
                                color: _kCard,
                                child: const Icon(Icons.person, color: _kWhite54, size: 26),
                              ),
                            )
                          : const Icon(Icons.person, color: _kWhite54, size: 26),
                    ),
                  ),
                ),
                if (hasUnviewed)
                  Positioned(
                    top: 0, right: 0,
                    child: Container(
                      width: 12, height: 12,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _kRed,
                        border: Border.all(color: _kBg, width: 2),
                        boxShadow: [
                          BoxShadow(color: _kRed.withOpacity(0.8), blurRadius: 6),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              group.username,
              style: TextStyle(
                color: _kWhite,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                fontWeight: hasUnviewed ? FontWeight.w600 : FontWeight.normal,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOtherStoryTile(UserStoryGroup group) {
    final first = group.stories.first;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: InkWell(
        onTap: () => _openStoryViewer(group.stories, 0),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kBorder),
          ),
          child: Row(
            children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: group.hasUnviewed
                      ? LinearGradient(colors: [_kCyan, _kBlue])
                      : null,
                  color: group.hasUnviewed ? null : _kBorder,
                ),
                padding: const EdgeInsets.all(2),
                child: ClipOval(
                  child: first.mediaType == 'image'
                      ? CachedNetworkImage(
                          imageUrl: first.mediaUrl,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => Container(
                            color: _kBorder,
                            child: const Icon(Icons.person, color: _kWhite54, size: 24),
                          ),
                          errorWidget: (_, __, ___) => Container(
                            color: _kBorder,
                            child: const Icon(Icons.person, color: _kWhite54, size: 24),
                          ),
                        )
                      : Container(
                          color: _kBorder,
                          child: const Icon(Icons.play_circle_outline,
                              color: _kWhite54, size: 24),
                        ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(group.username,
                        style: const TextStyle(color: _kWhite,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'ShareTechMono', fontSize: 14)),
                    const SizedBox(height: 2),
                    Text('${group.stories.length} story',
                        style: const TextStyle(color: _kWhite54,
                            fontSize: 12, fontFamily: 'ShareTechMono')),
                  ],
                ),
              ),
              if (group.hasUnviewed)
                Container(
                  width: 10, height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _kCyan,
                    boxShadow: [
                      BoxShadow(color: _kCyan.withOpacity(0.5), blurRadius: 6),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// ─── STORY VIEWER ─────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
class _StoryViewer extends StatefulWidget {
  final List<StoryItem> stories;
  final int startIndex;
  final String sessionKey;
  final String currentUser;
  final void Function(String)? onDelete;

  const _StoryViewer({
    required this.stories,
    required this.startIndex,
    required this.sessionKey,
    required this.currentUser,
    this.onDelete,
  });

  @override
  State<_StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<_StoryViewer>
    with SingleTickerProviderStateMixin {
  late int _current;
  late AnimationController _progressCtrl;
  VideoPlayerController? _videoCtrl;
  ChewieController? _chewieCtrl;
  bool _videoReady = false;

  static const Duration _imageDuration = Duration(seconds: 20);

  @override
  void initState() {
    super.initState();
    _current = widget.startIndex;
    _progressCtrl = AnimationController(vsync: this);
    _loadCurrent();
    _recordView();
  }

  @override
  void dispose() {
    _progressCtrl.removeStatusListener(_onProgressEnd);
    _progressCtrl.dispose();
    _videoCtrl?.dispose();
    _chewieCtrl?.dispose();
    super.dispose();
  }

  Future<void> _recordView() async {
    if (USE_DUMMY_STORIES) return;
    final story = widget.stories[_current];
    try {
      await http.post(
        Uri.parse('$baseUrl/viewStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': story.storyId}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _loadCurrent() {
    _progressCtrl.stop();
    _progressCtrl.removeStatusListener(_onProgressEnd);
    _videoCtrl?.dispose();
    _chewieCtrl?.dispose();
    _videoCtrl = null;
    _chewieCtrl = null;
    _videoReady = false;

    final story = widget.stories[_current];
    if (story.mediaType == 'video') {
      _videoCtrl = VideoPlayerController.networkUrl(Uri.parse(story.mediaUrl))
        ..initialize().then((_) {
          if (!mounted) return;
          _chewieCtrl = ChewieController(
            videoPlayerController: _videoCtrl!,
            autoPlay: true,
            looping: false,
            showControls: false,
          );
          setState(() => _videoReady = true);
          final videoDur = _videoCtrl!.value.duration;
          final dur = videoDur.inSeconds < 3 ? const Duration(seconds: 3) : videoDur;
          _progressCtrl.duration = dur;
          _progressCtrl.addStatusListener(_onProgressEnd);
          _progressCtrl.forward(from: 0);
        });
    } else {
      _progressCtrl.duration = _imageDuration;
      _progressCtrl.addStatusListener(_onProgressEnd);
      _progressCtrl.forward(from: 0);
    }
  }

  void _onProgressEnd(AnimationStatus status) {
    if (status == AnimationStatus.completed) _next();
  }

  void _next() {
    if (_current < widget.stories.length - 1) {
      setState(() => _current++);
      _loadCurrent();
      _recordView();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_current > 0) {
      setState(() => _current--);
      _loadCurrent();
    }
  }

  Future<void> _toggleLike() async {
    if (USE_DUMMY_STORIES) {
      final s = widget.stories[_current];
      widget.stories[_current] = s.copyWith(
        isLiked: !s.isLiked,
        likeCount: s.isLiked ? s.likeCount - 1 : s.likeCount + 1,
      );
      setState(() {});
      return;
    }
    final story = widget.stories[_current];
    try {
      await http.post(
        Uri.parse('$baseUrl/likeStory'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': widget.sessionKey, 'story_id': story.storyId}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.stories[_current];
    final isOwner = story.isOwner || story.username == widget.currentUser;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (d) {
          final w = MediaQuery.of(context).size.width;
          if (d.globalPosition.dx < w / 3) {
            _prev();
          } else {
            _next();
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ── Media ──
            if (story.mediaType == 'video' && _videoReady && _chewieCtrl != null)
              Chewie(controller: _chewieCtrl!)
            else if (story.mediaType == 'video')
              const Center(child: CircularProgressIndicator(color: _kCyan))
            else ...[
              Positioned.fill(
                child: _buildImage(story.mediaUrl, fit: BoxFit.cover, dim: true),
              ),
              Center(
                child: _buildImage(story.mediaUrl, fit: BoxFit.contain, dim: false),
              ),
            ],

            // ── Gradient top ──
            Positioned(
              top: 0, left: 0, right: 0, height: 120,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                  ),
                ),
              ),
            ),

            // ── Progress bars ──
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              left: 8, right: 8,
              child: Row(
                children: List.generate(widget.stories.length, (i) {
                  return Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      height: 3,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(2),
                        child: i < _current
                            ? Container(color: _kWhite)
                            : i == _current
                                ? AnimatedBuilder(
                                    animation: _progressCtrl,
                                    builder: (_, __) => LinearProgressIndicator(
                                      value: _progressCtrl.value,
                                      backgroundColor: _kWhite.withOpacity(0.3),
                                      valueColor: const AlwaysStoppedAnimation(_kWhite),
                                    ),
                                  )
                                : Container(color: _kWhite.withOpacity(0.3)),
                      ),
                    ),
                  );
                }),
              ),
            ),

            // ── Header ──
            Positioned(
              top: MediaQuery.of(context).padding.top + 20,
              left: 12, right: 12,
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: _kBorder,
                    child: const Icon(Icons.person, color: _kWhite54, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(story.username,
                            style: const TextStyle(color: _kWhite,
                                fontWeight: FontWeight.bold, fontSize: 14,
                                fontFamily: 'ShareTechMono')),
                        Text(story.createdAt,
                            style: const TextStyle(color: _kWhite54,
                                fontSize: 11, fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: _kWhite),
                    onPressed: () => Navigator.pop(context),
                  ),
                  if (isOwner)
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: _kRed),
                      onPressed: () {
                        Navigator.pop(context);
                        widget.onDelete?.call(story.storyId);
                      },
                    ),
                ],
              ),
            ),

            // ── Bottom ──
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                padding: EdgeInsets.fromLTRB(
                  16, 24, 16, MediaQuery.of(context).padding.bottom + 16,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                  ),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: story.caption.isNotEmpty
                          ? Text(story.caption,
                              style: const TextStyle(
                                color: _kWhite,
                                fontFamily: 'ShareTechMono',
                                fontSize: 14,
                                shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                              ))
                          : const SizedBox.shrink(),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: _toggleLike,
                          child: Icon(
                            story.isLiked ? Icons.favorite : Icons.favorite_border,
                            color: story.isLiked ? _kRed : _kWhite,
                            size: 28,
                          ),
                        ),
                        Text('${story.likeCount}',
                            style: const TextStyle(color: _kWhite, fontSize: 12,
                                fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 8),
                        const Icon(Icons.visibility_outlined,
                            color: _kWhite, size: 24),
                        Text('${story.viewCount}',
                            style: const TextStyle(color: _kWhite, fontSize: 12,
                                fontFamily: 'ShareTechMono')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImage(String url, {required BoxFit fit, required bool dim}) {
    final isLocal = !url.startsWith('http');
    final colorOverlay = dim ? Colors.black.withOpacity(0.45) : null;

    if (isLocal) {
      return Image.file(
        File(url),
        fit: fit,
        color: colorOverlay,
        colorBlendMode: dim ? BlendMode.darken : null,
        errorBuilder: (_, __, ___) => Container(color: Colors.black),
      );
    }
    return CachedNetworkImage(
      imageUrl: url,
      fit: fit,
      color: colorOverlay,
      colorBlendMode: dim ? BlendMode.darken : null,
      placeholder: (_, __) => Container(
        color: Colors.black,
        child: const Center(
          child: CircularProgressIndicator(color: _kCyan, strokeWidth: 2),
        ),
      ),
      errorWidget: (_, __, ___) => Container(
        color: Colors.black,
        child: const Center(
          child: Icon(Icons.broken_image, color: _kWhite54, size: 64),
        ),
      ),
    );
  }
}