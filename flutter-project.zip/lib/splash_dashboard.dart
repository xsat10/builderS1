// splash_dashboard.dart - BE4X EXES (NEON BLUE EDITION + TAP LOGO)
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dashboard_page.dart';
import 'widgets/tap_logo_overlay.dart';

class SplashDashboardPage extends StatefulWidget {
  final Map<String, dynamic>? data;
  const SplashDashboardPage({super.key, this.data});

  @override
  State<SplashDashboardPage> createState() => _SplashDashboardPageState();
}

class _SplashDashboardPageState extends State<SplashDashboardPage>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  bool _navigated = false;
  bool _showHint = true;
  Timer? _hintTimer;

  // ─── NEON PALETTE (BIRU HITAM) ─────────────────────────
  static const Color bgDeep    = Color(0xFF020617);
  static const Color bgMid     = Color(0xFF061029);
  static const Color neonCyan  = Color(0xFF00E5FF);
  static const Color neonBlue  = Color(0xFF2979FF);
  static const Color neonSoft  = Color(0xFF7DD3FC);
  static const Color glowWhite = Color(0xFFE0F7FF);

  // ─── PATH GAMBAR TAP LOGO ─────────────────────────────
  static const String tapLogoImage = 'assets/images/tap_logo.jpg';

  final List<Map<String, dynamic>> _pages = [
    {
      'title': 'SELAMAT DATANG',
      'subtitle': 'VOR4X',
      'desc':
          'Aplikasi utilitas cyber serbaguna generasi baru yang menghadirkan performa tinggi, proteksi keamanan menyeluruh, sistem modular canggih, dan integrasi multi-server tanpa hambatan.',
      'badge': 'SISTEM UTAMA',
      'icon': Icons.rocket_launch_rounded,
      'image': tapLogoImage,
    },
    {
      'title': 'DEVELOPER',
      'subtitle': 'CORE ARCHITECT',
      'desc': 'DANZ',
      'badge': 'CORE ARCHITECT',
      'icon': Icons.code_rounded,
      'image': 'assets/images/phnx.jpg',
      'isHighlight': true,
      'isDeveloper': true,
    },
    {
      'title': 'PEMILIK PROJECT',
      'subtitle': 'EXECUTIVE OWNER',
      'desc': 'ZILXPEDIA',
      'badge': 'EXECUTIVE OWNER',
      'icon': Icons.person_rounded,
      'image': 'assets/images/home.png',
      'isHighlight': true,
      'isOwner': true,
    },
    {
      'title': 'SELAMAT DATANG',
      'subtitle': 'DASHBOARD ACCESS',
      'desc':
          'Selamat memasuki Dashboard VOR4X! Seluruh modul eksklusif, fitur otomasi, dan proteksi sistem telah siap untuk Anda operasikan secara maksimal.',
      'badge': 'DASHBOARD ACCESS',
      'icon': Icons.dashboard_rounded,
      'image': tapLogoImage,
    },
  ];

  // ─── HAPTIC ────────────────────────────────────────────
  void _tap() {
    HapticFeedback.lightImpact();
  }

  Future<void> _openTelegram() async {
    _tap();
    final url = Uri.parse('https://t.me/BE4XEXES');
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        await launchUrl(url, mode: LaunchMode.platformDefault);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal membuka Telegram')),
        );
      }
    }
  }

  void _goToDashboard() {
    if (_navigated) return;
    _tap();
    _navigated = true;
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.data?['username'] as String? ?? '',
          password: widget.data?['password'] as String? ?? '',
          role: widget.data?['role'] as String? ?? 'member',
          sessionKey: widget.data?['key'] as String? ?? '',
          expiredDate: widget.data?['expiredDate'] as String? ?? '2099-12-31',
          listBug: List<Map<String, dynamic>>.from(
              widget.data?['listBug'] ?? []),
          listDoos: List<Map<String, dynamic>>.from(
              widget.data?['listDoos'] ?? []),
          news: List<Map<String, dynamic>>.from(widget.data?['news'] ?? []),
        ),
        transitionDuration: const Duration(milliseconds: 600),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.95, end: 1.0).animate(
                CurvedAnimation(
                    parent: animation, curve: Curves.easeOutCubic),
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }

  void _goToPage(int index) {
    _tap();
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOutCubic,
    );
  }

  void _nextPage() {
    if (_currentPage == _pages.length - 1) {
      _goToDashboard();
    } else {
      _goToPage(_currentPage + 1);
    }
  }

  // ─── EASTER EGG: DEVELOPER ─────────────────────────────
  void _onDeveloperEgg() {
    HapticFeedback.heavyImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _EasterEggDialog(
        title: 'DEVELOPER MODE',
        subtitle: 'DANZ',
        icon: Icons.code_rounded,
        accent: neonCyan,
        logoAsset: tapLogoImage,
        message:
            'Kamu menemukan pintu rahasia developer BVOR4X!\n\n"Kode yang baik adalah kode yang bisa dibaca manusia, bukan hanya mesin."',
      ),
    );
  }

  // ─── EASTER EGG: OWNER ─────────────────────────────────
  void _onOwnerEgg() {
    HapticFeedback.heavyImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _EasterEggDialog(
        title: 'OWNER MODE',
        subtitle: 'ZILXPEDIA',
        icon: Icons.workspace_premium_rounded,
        accent: neonCyan,
        logoAsset: tapLogoImage,
        message:
            'Selamat datang, Pemilik!\n\nKamu menemukan kunci rahasia ZILXPEDIA.\n\n"Kekuatan sejati bukan dari jabatan, tapi dari visi."',
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOutCubic,
    );

    _fadeController.forward();

    _hintTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _showHint = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _pulseController.dispose();
    _fadeController.dispose();
    _hintTimer?.cancel();
    super.dispose();
  }

  Widget _tapButton({
    required VoidCallback onTap,
    required Widget child,
    BorderRadius? borderRadius,
  }) {
    return _PressableScale(
      onTap: onTap,
      borderRadius: borderRadius ?? BorderRadius.circular(14),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDeep,
      body: Stack(
        children: [
          // ─── BACKGROUND IMAGE ──────────────────────────────
          Positioned.fill(
            child: Image.asset(
              'assets/images/dashboard.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [bgDeep, bgMid, bgDeep],
                  ),
                ),
              ),
            ),
          ),

          // ─── DARK BLUE TINT ────────────────────────────────
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  bgDeep.withOpacity(0.75),
                  bgMid.withOpacity(0.55),
                  bgDeep.withOpacity(0.88),
                ],
              ),
            ),
          ),

          // ─── RADIAL NEON GLOW TOP ──────────────────────────
          Positioned(
            top: -140,
            left: -80,
            child: IgnorePointer(
              child: Container(
                width: 340,
                height: 340,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      neonCyan.withOpacity(0.35),
                      neonBlue.withOpacity(0.10),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ─── RADIAL NEON GLOW BOTTOM ───────────────────────
          Positioned(
            bottom: -160,
            right: -100,
            child: IgnorePointer(
              child: Container(
                width: 380,
                height: 380,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      neonBlue.withOpacity(0.30),
                      neonCyan.withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ─── GRID FUTURISTIK ───────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _GridPainter()),
            ),
          ),

          // ─── SCANLINE ──────────────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      neonCyan.withOpacity(0.04),
                      Colors.transparent,
                    ],
                    stops: const [0.45, 0.50, 0.55],
                  ),
                ),
              ),
            ),
          ),

          // ─── PAGE VIEW + TAP AREA ──────────────────────────
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onTap: _nextPage,
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() => _currentPage = index);
                  _fadeController.reset();
                  _fadeController.forward();
                },
                itemCount: _pages.length,
                itemBuilder: (context, index) {
                  final data = _pages[index];
                  return FadeTransition(
                    opacity: _fadeAnimation,
                    child: _buildPage(data, index),
                  );
                },
              ),
            ),
          ),

          // ─── TOMBOL LEWATI ─────────────────────────────────
          Positioned(
            top: 50,
            right: 16,
            child: _tapButton(
              onTap: _goToDashboard,
              borderRadius: BorderRadius.circular(14),
              child: AnimatedBuilder(
                animation: _pulseController,
                builder: (context, _) {
                  final p = _pulseController.value;
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 9),
                    decoration: BoxDecoration(
                      color: bgMid.withOpacity(0.45),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: neonCyan.withOpacity(0.55 + 0.35 * p),
                        width: 1.4,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: neonCyan.withOpacity(0.35 + 0.25 * p),
                          blurRadius: 14 + 8 * p,
                          spreadRadius: 1,
                        ),
                        BoxShadow(
                          color: neonBlue.withOpacity(0.20),
                          blurRadius: 22,
                          spreadRadius: -4,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          "LEWATI",
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            color: glowWhite,
                            fontSize: 12,
                            letterSpacing: 1.8,
                            fontWeight: FontWeight.w700,
                            shadows: [
                              Shadow(color: neonCyan, blurRadius: 10),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        Icon(
                          Icons.keyboard_double_arrow_right_rounded,
                          color: neonCyan.withOpacity(0.9),
                          size: 16,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),

          // ─── BOTTOM: DOTS + BUTTON ─────────────────────────
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  // DOTS
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _pages.length,
                      (index) => GestureDetector(
                        onTap: () => _goToPage(index),
                        behavior: HitTestBehavior.opaque,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 500),
                          margin: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 8),
                          width: _currentPage == index ? 32 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: _currentPage == index
                                ? neonCyan
                                : glowWhite.withOpacity(0.20),
                            border: Border.all(
                              color: _currentPage == index
                                  ? neonCyan
                                  : glowWhite.withOpacity(0.25),
                              width: 1,
                            ),
                            boxShadow: _currentPage == index
                                ? [
                                    BoxShadow(
                                      color: neonCyan.withOpacity(0.8),
                                      blurRadius: 14,
                                      spreadRadius: 2,
                                    ),
                                    BoxShadow(
                                      color: neonBlue.withOpacity(0.5),
                                      blurRadius: 22,
                                      spreadRadius: 1,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 22),

                  // BUTTON
                  AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      final isLast = _currentPage == _pages.length - 1;
                      final pulse = _pulseController.value;
                      return _tapButton(
                        onTap: () {
                          if (isLast) {
                            _goToDashboard();
                          } else {
                            _goToPage(_currentPage + 1);
                          }
                        },
                        borderRadius: BorderRadius.circular(18),
                        child: Container(
                          width: double.infinity,
                          height: 58,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            gradient: isLast
                                ? LinearGradient(
                                    colors: [
                                      Color.lerp(neonCyan, neonBlue,
                                          pulse * 0.5)!,
                                      Color.lerp(neonBlue, neonCyan,
                                          pulse * 0.5)!,
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  )
                                : LinearGradient(
                                    colors: [
                                      bgMid.withOpacity(0.60),
                                      bgDeep.withOpacity(0.50),
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                            border: Border.all(
                              color: isLast
                                  ? glowWhite.withOpacity(0.85)
                                  : neonCyan.withOpacity(
                                      0.55 + 0.30 * pulse),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: (isLast ? neonCyan : neonBlue)
                                    .withOpacity(0.35 + 0.25 * pulse),
                                blurRadius: 20 + 12 * pulse,
                                spreadRadius: 1,
                              ),
                              BoxShadow(
                                color: neonBlue.withOpacity(0.20),
                                blurRadius: 40,
                                spreadRadius: -6,
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                isLast ? 'MASUK DASHBOARD' : 'LANJUTKAN',
                                style: TextStyle(
                                  fontFamily: 'Orbitron',
                                  color: isLast ? bgDeep : glowWhite,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,
                                  shadows: isLast
                                      ? null
                                      : const [
                                          Shadow(
                                              color: neonCyan,
                                              blurRadius: 10),
                                        ],
                                ),
                              ),
                              if (!isLast) ...[
                                const SizedBox(width: 10),
                                const Icon(
                                  Icons.arrow_forward_rounded,
                                  color: neonCyan,
                                  size: 20,
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),

          // ─── HINT SWIPE ────────────────────────────────────
          if (_showHint)
            Positioned(
              bottom: 132,
              left: 0,
              right: 0,
              child: IgnorePointer(
                child: AnimatedOpacity(
                  opacity: _showHint ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 600),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: bgMid.withOpacity(0.50),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: neonCyan.withOpacity(0.45),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.25),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.touch_app_rounded,
                            color: neonCyan.withOpacity(0.9),
                            size: 16,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Tap atau geser untuk lanjut',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              color: glowWhite.withOpacity(0.9),
                              fontSize: 11,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPage(Map<String, dynamic> data, int index) {
    final bool isHighlight = data['isHighlight'] == true;
    final bool isDeveloper = data['isDeveloper'] == true;
    final bool isOwner = data['isOwner'] == true;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // ─── ICON NEON RING — TAP LOGO (easter egg) ────────
          TapLogoOverlay(
            logoAsset: tapLogoImage,
            size: 100,
            label: isDeveloper
                ? 'TAP'
                : isOwner
                    ? 'TAP'
                    : 'VOR4X',
            tapsToUnlock: isDeveloper || isOwner ? 3 : 5,
            neonColor: neonCyan,
            glowColor: neonBlue,
            onSecretTap: () {
              if (isDeveloper) {
                _onDeveloperEgg();
              } else if (isOwner) {
                _onOwnerEgg();
              } else {
                HapticFeedback.heavyImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: bgMid,
                    content: const Text(
                      '🎉 Easter egg! Coba tap halaman DEVELOPER & OWNER',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        color: glowWhite,
                      ),
                    ),
                    duration: const Duration(seconds: 2),
                  ),
                );
              }
            },
          ),

          const SizedBox(height: 22),

          // ─── BADGE ────────────────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: bgMid.withOpacity(0.45),
              border: Border.all(
                color: neonCyan.withOpacity(0.55),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.30),
                  blurRadius: 14,
                  spreadRadius: -2,
                ),
              ],
            ),
            child: Text(
              data['badge'],
              style: const TextStyle(
                fontFamily: 'Orbitron',
                color: glowWhite,
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.w700,
                shadows: [
                  Shadow(color: neonCyan, blurRadius: 12),
                ],
              ),
            ),
          ),

          const SizedBox(height: 26),

          // ─── TITLE ────────────────────────────────────────
          Text(
            data['title'],
            style: const TextStyle(
              fontFamily: 'Orbitron',
              color: glowWhite,
              fontSize: 28,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              height: 1.3,
              shadows: [
                Shadow(color: neonCyan, blurRadius: 24),
                Shadow(color: neonBlue, blurRadius: 40),
                Shadow(
                  color: Colors.black87,
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 14),

          // ─── SUBTITLE ─────────────────────────────────────
          Text(
            data['subtitle'],
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: neonSoft.withOpacity(0.95),
              fontSize: 14,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
              shadows: [
                Shadow(
                  color: neonCyan.withOpacity(0.7),
                  blurRadius: 12,
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 22),

          // ─── GARIS PEMBATAS NEON ──────────────────────────
          Container(
            width: 90,
            height: 2,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Colors.transparent,
                  neonCyan,
                  glowWhite,
                  neonCyan,
                  Colors.transparent,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.85),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),

          const SizedBox(height: 22),

          // ─── DESCRIPTION / HIGHLIGHT ──────────────────────
          if (isHighlight)
            GestureDetector(
              onTap: () {
                if (isDeveloper) {
                  _onDeveloperEgg();
                } else if (isOwner) {
                  _onOwnerEgg();
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: neonCyan.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: neonCyan.withOpacity(0.5),
                    width: 1,
                    style: BorderStyle.solid,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: neonCyan.withOpacity(0.25),
                      blurRadius: 18,
                      spreadRadius: -2,
                    ),
                  ],
                ),
                child: Text(
                  data['desc'],
                  style: const TextStyle(
                    fontFamily: 'Orbitron',
                    color: glowWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    shadows: [
                      Shadow(color: neonCyan, blurRadius: 20),
                      Shadow(color: neonBlue, blurRadius: 40),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            Text(
              data['desc'],
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: glowWhite.withOpacity(0.85),
                fontSize: 13,
                height: 1.8,
                letterSpacing: 0.5,
                shadows: [
                  Shadow(
                    color: neonBlue.withOpacity(0.55),
                    blurRadius: 10,
                  ),
                ],
              ),
              textAlign: TextAlign.center,
            ),

          const SizedBox(height: 18),

          // ─── INDIKATOR HALAMAN ────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: bgMid.withOpacity(0.40),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: neonCyan.withOpacity(0.40),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.20),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Text(
              "${index + 1} / ${_pages.length}",
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: neonCyan.withOpacity(0.95),
                fontSize: 10.5,
                letterSpacing: 1.5,
                fontWeight: FontWeight.w700,
                shadows: [
                  Shadow(
                    color: neonCyan.withOpacity(0.8),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
          ),

          // ─── TELEGRAM (HALAMAN TERAKHIR) ──────────────────
          if (index == _pages.length - 1) ...[
            const SizedBox(height: 28),
            _tapButton(
              onTap: _openTelegram,
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 14),
                decoration: BoxDecoration(
                  color: bgMid.withOpacity(0.45),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: neonCyan.withOpacity(0.55),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: neonCyan.withOpacity(0.35),
                      blurRadius: 20,
                      spreadRadius: -2,
                    ),
                    BoxShadow(
                      color: neonBlue.withOpacity(0.25),
                      blurRadius: 32,
                      spreadRadius: -4,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: neonCyan.withOpacity(0.18),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: neonCyan.withOpacity(0.6),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: neonCyan.withOpacity(0.5),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: const Icon(
                        FontAwesomeIcons.telegram,
                        color: glowWhite,
                        size: 18,
                        shadows: [
                          Shadow(color: neonCyan, blurRadius: 12),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'JOIN TELEGRAM VOR4X',
                      style: TextStyle(
                        color: glowWhite,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        letterSpacing: 1.5,
                        shadows: [
                          Shadow(color: neonCyan, blurRadius: 12),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: neonCyan.withOpacity(0.9),
                      size: 14,
                      shadows: [
                        Shadow(
                          color: neonCyan.withOpacity(0.8),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PRESSABLE SCALE
// ═══════════════════════════════════════════════════════════
class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  final BorderRadius borderRadius;
  final double pressedScale;

  const _PressableScale({
    required this.child,
    required this.onTap,
    required this.borderRadius,
    this.pressedScale = 0.96,
  });

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
      lowerBound: 0.0,
      upperBound: 1.0,
    );
    _scale = Tween<double>(begin: 1.0, end: widget.pressedScale).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _onTapDown(_) {
    setState(() => _pressed = true);
    _ctrl.forward();
    HapticFeedback.selectionClick();
  }

  void _onTapUp(_) {
    setState(() => _pressed = false);
    _ctrl.reverse();
  }

  void _onTapCancel() {
    setState(() => _pressed = false);
    _ctrl.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      onTap: widget.onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _scale,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Stack(
              alignment: Alignment.center,
              children: [
                child!,
                if (_pressed)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: ClipRRect(
                        borderRadius: widget.borderRadius,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: widget.borderRadius,
                            gradient: RadialGradient(
                              colors: [
                                const Color(0xFF00E5FF).withOpacity(0.35),
                                const Color(0xFF2979FF).withOpacity(0.15),
                                Colors.transparent,
                              ],
                              stops: const [0.0, 0.5, 1.0],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DIALOG EASTER EGG (dengan gambar tap_logo)
// ═══════════════════════════════════════════════════════════
class _EasterEggDialog extends StatelessWidget {
  final String title;
  final String subtitle;
  final String message;
  final IconData icon;
  final Color accent;
  final String? logoAsset;

  const _EasterEggDialog({
    required this.title,
    required this.subtitle,
    required this.message,
    required this.icon,
    required this.accent,
    this.logoAsset,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF080C1A),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: accent.withOpacity(0.6),
          width: 1.5,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.4),
              blurRadius: 40,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ─── LOGO BULET (pakai tap_logo.jpg) ──────────
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accent.withOpacity(0.4),
                    Colors.transparent,
                  ],
                ),
                border: Border.all(color: accent, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.7),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: ClipOval(
                child: logoAsset != null
                    ? Image.asset(
                        logoAsset!,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _fallbackIcon(),
                      )
                    : _fallbackIcon(),
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [accent, Colors.white, accent],
              ).createShader(bounds),
              child: Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                  letterSpacing: 2,
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 12,
                color: accent.withOpacity(0.85),
                letterSpacing: 1.5,
                shadows: [
                  Shadow(color: accent, blurRadius: 10),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xFFE8EDFF).withOpacity(0.85),
                fontSize: 12.5,
                height: 1.7,
                fontStyle: FontStyle.italic,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'MANTAP!',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    color: Color(0xFF080C1A),
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fallbackIcon() {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [accent.withOpacity(0.4), Colors.transparent],
        ),
      ),
      child: Icon(icon, color: Colors.white, size: 40),
    );
  }
}

// ─── GRID FUTURISTIK PAINTER ─────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 42.0;
    final paint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.06)
      ..strokeWidth = 1.0;

    for (double x = 0; x <= size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}