import 'package:flutter/material.dart';
import 'global_theme.dart';

class ColorSettingsPage extends StatefulWidget {
  const ColorSettingsPage({super.key});
  @override
  State<ColorSettingsPage> createState() => _ColorSettingsPageState();
}

class _ColorSettingsPageState extends State<ColorSettingsPage> {
  String _tab = 'all';

  List<Color> get _colors => _tab == 'signature'
      ? signatureColors
      : _tab == 'neon'
          ? neonColors
          : allColors;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (_, primary, __) {
        return Scaffold(
          backgroundColor: GlobalTheme.bgTop,
          body: SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 10),

                // HEADER
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Container(
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            GlobalTheme.primary,
                            GlobalTheme.glow,
                          ]),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: GlobalTheme.primary.withOpacity(0.6),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.palette,
                            color: Colors.white, size: 28),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('COLOR SETTINGS',
                                style: TextStyle(
                                  color: GlobalTheme.primary,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 3,
                                  shadows: [
                                    Shadow(
                                        color: GlobalTheme.primary,
                                        blurRadius: 14),
                                  ],
                                )),
                            const Text('Pilih gaya warna favoritmu',
                                style: TextStyle(
                                    color: Colors.white54,
                                    fontSize: 12)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            GlobalTheme.primary,
                            GlobalTheme.glow,
                          ]),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.visibility,
                                color: Colors.white, size: 14),
                            SizedBox(width: 6),
                            Text('LIVE',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // PREVIEW
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        GlobalTheme.glow,
                        GlobalTheme.primary,
                      ]),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [
                        BoxShadow(
                            color:
                                GlobalTheme.primary.withOpacity(0.6),
                            blurRadius: 30),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.25),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.palette,
                              color: Colors.white, size: 22),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text('👑 Warna Aktif',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  )),
                              SizedBox(height: 3),
                              Text('PREVIEW WARNA AKTIF',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 10,
                                    letterSpacing: 2,
                                  )),
                            ],
                          ),
                        ),
                        Container(
                          width: 20, height: 20,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // TAB
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      _tabBtn('🎨', 'ALL', 'all'),
                      _tabBtn('👑', 'SIGNATURE', 'signature'),
                      _tabBtn('⚡', 'NEON', 'neon'),
                    ],
                  ),
                ),

                Container(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  height: 1,
                  color: GlobalTheme.border,
                ),

                // GRID
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        Wrap(
                          spacing: 10,
                          runSpacing: 12,
                          children: _colors.map(_dot).toList(),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Icon(Icons.gradient,
                                color: GlobalTheme.primary, size: 16),
                            const SizedBox(width: 6),
                            Text('GRADIENT',
                                style: TextStyle(
                                  color: GlobalTheme.primary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                )),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 10,
                          runSpacing: 12,
                          children: gradientColors.map((g) {
                            return GestureDetector(
                              onTap: () =>
                                  GlobalTheme.setColor(g.first),
                              child: Container(
                                width: 48, height: 48,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(colors: g),
                                  border: Border.all(
                                      color:
                                          Colors.white.withOpacity(0.2)),
                                  boxShadow: [
                                    BoxShadow(
                                        color: g.first
                                            .withOpacity(0.6),
                                        blurRadius: 12),
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),

                // TOMBOL
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: GlobalTheme.actionButton(
                          icon: Icons.shuffle,
                          label: 'RANDOM',
                          onTap: GlobalTheme.randomColor,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GlobalTheme.actionButton(
                          icon: Icons.refresh,
                          label: 'RESET',
                          onTap: GlobalTheme.reset,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _dot(Color c) {
    final isSelected = GlobalTheme.primary == c;
    return GestureDetector(
      onTap: () => GlobalTheme.setColor(c),
      child: Container(
        width: 46, height: 46,
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected
                ? Colors.white
                : Colors.white.withOpacity(0.08),
            width: isSelected ? 3 : 1,
          ),
          boxShadow: [
            BoxShadow(
                color: c.withOpacity(0.5),
                blurRadius: 10,
                spreadRadius: 1),
          ],
        ),
        child: isSelected
            ? const Icon(Icons.check, color: Colors.white, size: 20)
            : null,
      ),
    );
  }

  Widget _tabBtn(String emoji, String label, String key) {
    final selected = _tab == key;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = key),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            gradient: selected
                ? LinearGradient(colors: [
                    GlobalTheme.glow,
                    GlobalTheme.primary,
                  ])
                : null,
            borderRadius: BorderRadius.circular(12),
            boxShadow: selected
                ? [
                    BoxShadow(
                        color:
                            GlobalTheme.primary.withOpacity(0.6),
                        blurRadius: 16)
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 14)),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                    color: selected ? Colors.white : Colors.white54,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  )),
            ],
          ),
        ),
      ),
    );
  }
}