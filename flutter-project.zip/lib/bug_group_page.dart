// bug_group_page.dart
// VERSI FINAL GABUNGAN — Video Splash + Bug Group System

import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'main.dart';
import 'global_theme.dart';

// ═══════════════════════════════════════════════════════════
// 🎯 ROLE SYSTEM
// ═══════════════════════════════════════════════════════════
const List<String> BUG_GROUP_ACCESS_ROLES = [
  'ceo', 'owner', 'admin', 'tangan_kanan', 'vip'
];

const Map<String, int> ROLE_LEVEL = {
  'ceo': 9, 'owner': 8, 'admin': 7, 'tangan_kanan': 6, 'vip': 5,
  'reseller': 4, 'full_up': 3, 'member_perbulan': 2,
  'member_perminggu': 2, 'member_perhari': 1
};

bool _canAccessBugGroup(String role) =>
    BUG_GROUP_ACCESS_ROLES.contains(role.toLowerCase());

int getRoleLevel(String role) => ROLE_LEVEL[role.toLowerCase()] ?? 0;

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

// ✅ Text shadow global
const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ═══════════════════════════════════════════════════════════
// 📦 MODELS
// ═══════════════════════════════════════════════════════════
class BugSystem {
  final String id, name, description, icon;
  final int count, delay;
  BugSystem({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    this.count = 0,
    this.delay = 0,
  });
}

class GroupItem {
  final String id, name, avatarUrl;
  final bool joined;
  final int memberCount;
  bool isExpanded;
  GroupItem({
    required this.id,
    required this.name,
    this.joined = false,
    this.avatarUrl = '',
    this.memberCount = 0,
    this.isExpanded = false,
  });
  GroupItem copyWith({bool? isExpanded}) => GroupItem(
        id: id,
        name: name,
        joined: joined,
        avatarUrl: avatarUrl,
        memberCount: memberCount,
        isExpanded: isExpanded ?? this.isExpanded,
      );
}

// ═══════════════════════════════════════════════════════════
// 🎬 VIDEO SPLASH OVERLAY (inline widget)
// ═══════════════════════════════════════════════════════════
class _VideoSplashOverlay extends StatefulWidget {
  final String statusText;
  final String subtitleText;
  final double progress;
  final Color accentColor;
  final String videoAsset;

  const _VideoSplashOverlay({
    required this.statusText,
    this.subtitleText = "",
    this.progress = 0.0,
    this.accentColor = const Color(0xFF00C9A7),
    this.videoAsset = 'assets/videos/splashd.mp4',
  });

  @override
  State<_VideoSplashOverlay> createState() => _VideoSplashOverlayState();
}

class _VideoSplashOverlayState extends State<_VideoSplashOverlay> {
  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoError = false;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset(widget.videoAsset);
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();

      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() {
        _videoController = controller;
        _videoReady = true;
      });
    } catch (e) {
      debugPrint("❌ Video splash error: $e");
      if (mounted) setState(() => _videoError = true);
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pct = (widget.progress * 100).clamp(0, 100).toStringAsFixed(0);
    final accent = widget.accentColor;
    final statusUpper = widget.statusText.toUpperCase();

    Color statusColor = Colors.white;
    if (statusUpper.contains("COMPLETE") || statusUpper.contains("SUCCESS")) {
      statusColor = const Color(0xFF00E6B8);
    } else if (statusUpper.contains("FAIL") || statusUpper.contains("ERROR")) {
      statusColor = const Color(0xFFFF6B6B);
    }

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // Background blur gelap
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
              child: Container(color: Colors.black.withOpacity(0.72)),
            ),
          ),

          // Konten utama
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 420),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: accent.withOpacity(0.75),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.45),
                      blurRadius: 30,
                      spreadRadius: 4,
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 24,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    color: const Color(0xFF0A0F18),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // ─── VIDEO AREA ───
                        AspectRatio(
                          aspectRatio: 16 / 9,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Container(color: Colors.black),
                              if (_videoReady &&
                                  _videoController != null &&
                                  _videoController!.value.isInitialized)
                                FittedBox(
                                  fit: BoxFit.cover,
                                  child: SizedBox(
                                    width:
                                        _videoController!.value.size.width,
                                    height:
                                        _videoController!.value.size.height,
                                    child: VideoPlayer(_videoController!),
                                  ),
                                )
                              else if (_videoError)
                                const Center(
                                  child: Icon(
                                    Icons.movie_outlined,
                                    color: Colors.white24,
                                    size: 60,
                                  ),
                                )
                              else
                                Center(
                                  child: CircularProgressIndicator(
                                    color: accent,
                                    strokeWidth: 2,
                                  ),
                                ),
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Colors.transparent,
                                          Colors.black.withOpacity(0.35),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        // ─── PROGRESS + STATUS ───
                        Padding(
                          padding: const EdgeInsets.fromLTRB(18, 16, 18, 22),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Stack(
                                children: [
                                  Container(
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color:
                                            Colors.white.withOpacity(0.18),
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                  FractionallySizedBox(
                                    widthFactor:
                                        widget.progress.clamp(0.0, 1.0),
                                    child: Container(
                                      height: 12,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(8),
                                        gradient: const LinearGradient(
                                          colors: [
                                            Color(0xFFFFB300),
                                            Color(0xFF00C9A7),
                                            Color(0xFF4FC3F7),
                                          ],
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: accent.withOpacity(0.6),
                                            blurRadius: 12,
                                            spreadRadius: 1,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "$pct%",
                                    style: TextStyle(
                                      color: accent,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 1,
                                      shadows: _ts,
                                    ),
                                  ),
                                  Text(
                                    statusUpper,
                                    style: TextStyle(
                                      color: statusColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 2,
                                      shadows: _ts,
                                    ),
                                  ),
                                ],
                              ),
                              if (widget.subtitleText.isNotEmpty) ...[
                                const SizedBox(height: 8),
                                Center(
                                  child: Text(
                                    widget.subtitleText,
                                    textAlign: TextAlign.center,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      letterSpacing: 0.5,
                                      fontFamily: 'Monospace',
                                      shadows: _ts,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🎯 MAIN WIDGET
// ═══════════════════════════════════════════════════════════
class BugGroupPage extends StatefulWidget {
  final String sessionKey;
  final String role;
  const BugGroupPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });
  @override
  State<BugGroupPage> createState() => _BugGroupPageState();
}

class _BugGroupPageState extends State<BugGroupPage>
    with SingleTickerProviderStateMixin {
  // ─── STATE ───
  bool _isSending = false;
  bool _isLoading = false;
  bool _isLoadingBugs = false;
  bool _hasSender = false;
  bool _allExpanded = false;
  GroupItem? _selectedGroup;
  BugSystem? _selectedBug;
  final TextEditingController _groupInputController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();
  List<GroupItem> _joinedGroups = [];
  List<GroupItem> _filteredGroups = [];
  List<BugSystem> _bugSystems = [];
  int _cooldownTime = 0;
  Timer? _cooldownTimer;
  Timer? _splashTimer;
  final ScrollController _scrollController = ScrollController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late AnimationController _pulseController;

  // Splash notifiers
  ValueNotifier<double>? _splashProgress;
  ValueNotifier<String>? _splashStatus;
  ValueNotifier<String>? _splashSubtitle;
  Color _splashAccent = const Color(0xFF00C9A7);

  static const String BASE_URL =
      "http://paultzy.pteroqhost.web.id5015";

  // ─── PALETTE ───
  Color get _bgPrimary => GlobalTheme.bgTop;
  Color get _accentPrimary => GlobalTheme.primary;
  Color get _accentGradientStart => GlobalTheme.primary;
  Color get _accentGradientEnd => GlobalTheme.lighten(GlobalTheme.primary, 0.20);

  final Color _glassSurface = const Color(0x4D151C2B);
  final Color _glassSurfaceLight = const Color(0x661E293B);
  final Color _glassBorder = const Color(0x33FFFFFF);
  final Color _glassBorderBright = const Color(0x4DFFFFFF);
  final Color _glassHighlight = const Color(0x1AFFFFFF);
  final Color _successGreen = const Color(0xFF00C9A7);
  final Color _warningOrange = const Color(0xFFFF6B6B);
  final Color _textPrimary = const Color(0xFFF8FAFC);
  final Color _textSecondary = const Color(0xFFB8C8DC);
  final Color _textTertiary = const Color(0xFF8A9BAF);

  // ═══════════════════════════════════════════════════════════
  // 🔄 LIFECYCLE
  // ═══════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.1, end: 0.4).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _checkSenderAndGroups();
    _fetchBugSystems();
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _splashTimer?.cancel();
    _animationController.dispose();
    _pulseController.dispose();
    _searchController.dispose();
    _groupInputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // 🎬 VIDEO SPLASH HELPERS
  // ═══════════════════════════════════════════════════════════
  void _showVideoSplash({
    required String statusText,
    String subtitle = "",
    Color? accent,
  }) {
    _splashAccent = accent ?? _accentPrimary;
    _splashProgress = ValueNotifier(0.0);
    _splashStatus = ValueNotifier(statusText);
    _splashSubtitle = ValueNotifier(subtitle);

    _splashTimer?.cancel();
    _splashTimer = Timer.periodic(const Duration(milliseconds: 80), (t) {
      if (_splashProgress == null) {
        t.cancel();
        return;
      }
      final current = _splashProgress!.value;
      if (current >= 0.9) {
        t.cancel();
        return;
      }
      _splashProgress!.value = current + 0.025;
    });

    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.transparent,
      barrierLabel: "splash",
      transitionDuration: const Duration(milliseconds: 250),
      pageBuilder: (ctx, _, __) {
        return ValueListenableBuilder<double>(
          valueListenable: _splashProgress!,
          builder: (_, progress, __) {
            return ValueListenableBuilder<String>(
              valueListenable: _splashStatus!,
              builder: (_, status, __) {
                return ValueListenableBuilder<String>(
                  valueListenable: _splashSubtitle!,
                  builder: (_, subtitle, __) {
                    return _VideoSplashOverlay(
                      statusText: status,
                      subtitleText: subtitle,
                      progress: progress,
                      accentColor: _splashAccent,
                    );
                  },
                );
              },
            );
          },
        );
      },
      transitionBuilder: (_, anim, __, child) {
        return FadeTransition(opacity: anim, child: child);
      },
    );
  }

  Future<void> _finishVideoSplash() async {
    _splashTimer?.cancel();
    if (_splashProgress != null) _splashProgress!.value = 1.0;
    if (_splashStatus != null) _splashStatus!.value = "COMPLETED";
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted && Navigator.canPop(context)) Navigator.pop(context);
    _splashProgress = null;
    _splashStatus = null;
    _splashSubtitle = null;
  }

  Future<void> _failVideoSplash(String message) async {
    _splashTimer?.cancel();
    if (_splashStatus != null) _splashStatus!.value = "FAILED";
    if (_splashSubtitle != null) _splashSubtitle!.value = message;
    await Future.delayed(const Duration(milliseconds: 900));
    if (mounted && Navigator.canPop(context)) Navigator.pop(context);
    _splashProgress = null;
    _splashStatus = null;
    _splashSubtitle = null;
  }

  // ═══════════════════════════════════════════════════════════
  // 🌐 NETWORK
  // ═══════════════════════════════════════════════════════════
  Future<void> _fetchBugSystems() async {
    if (!mounted) return;
    setState(() => _isLoadingBugs = true);

    try {
      final res = await http.get(
        Uri.parse("$BASE_URL/bugGroupSystems"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final bugSystems = data["bugSystems"] as List?;
          final newBugs = bugSystems?.map((b) => BugSystem(
                id: b["id"] ?? "",
                name: b["name"] ?? "",
                description: b["description"] ?? "",
                icon: b["icon"] ?? "🐛",
                count: b["count"] ?? 0,
                delay: b["delay"] ?? 0,
              )).toList() ??
              [];

          if (!mounted) return;
          setState(() {
            _bugSystems = newBugs;
            if (newBugs.isNotEmpty && _selectedBug == null) {
              _selectedBug = newBugs.first;
            }
          });
        }
      }
    } catch (e) {
      debugPrint("❌ Error fetching bug systems: $e");
    } finally {
      if (mounted) setState(() => _isLoadingBugs = false);
    }
  }

  Future<void> _checkSenderAndGroups() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    bool hasSender = false;

    try {
      final senderRes = await http.get(
        Uri.parse("$BASE_URL/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (senderRes.statusCode == 200) {
        final senderData = jsonDecode(senderRes.body);
        if (senderData["valid"] == true) {
          final connections = senderData["connections"] as List?;
          hasSender = connections != null && connections.isNotEmpty;
        }
      }

      if (hasSender) {
        final groupRes = await http.get(
          Uri.parse("$BASE_URL/myGroup?key=${widget.sessionKey}"),
          headers: {'Content-Type': 'application/json'},
        ).timeout(const Duration(seconds: 15));

        if (groupRes.statusCode == 200) {
          final groupData = jsonDecode(groupRes.body);
          if (groupData["valid"] == true) {
            final groups = groupData["groups"] as List?;
            final newGroups = groups?.map((g) => GroupItem(
                  id: g["id"] ?? "",
                  name: g["name"] ?? "-",
                  joined: true,
                  avatarUrl: g["avatar"] ?? "",
                  memberCount: g["memberCount"] ?? 0,
                  isExpanded: false,
                )).toList() ??
                [];

            if (!mounted) return;
            setState(() {
              _joinedGroups = newGroups;
              _filteredGroups = List.from(newGroups);
              if (newGroups.isNotEmpty && _selectedGroup == null) {
                _selectedGroup = newGroups.first;
              }
            });
          }
        }
      }
    } catch (e) {
      debugPrint("❌ Error checkSender: $e");
    } finally {
      if (mounted) {
        setState(() {
          _hasSender = hasSender;
          _isLoading = false;
        });
      }
    }
  }

  void _filterGroups(String query) {
    if (query.isEmpty) {
      setState(() {
        _filteredGroups = List.from(_joinedGroups);
      });
      return;
    }

    final filtered = _joinedGroups.where((group) {
      final name = group.name.toLowerCase();
      final id = group.id.toLowerCase();
      final searchLower = query.toLowerCase();
      return name.contains(searchLower) || id.contains(searchLower);
    }).toList();

    setState(() {
      _filteredGroups = filtered;
    });
  }

  void _toggleGroupExpansion(int index) {
    setState(() {
      _filteredGroups[index] = _filteredGroups[index].copyWith(
        isExpanded: !_filteredGroups[index].isExpanded,
      );
    });
  }

  void _toggleAllGroups() {
    setState(() {
      _allExpanded = !_allExpanded;
      for (int i = 0; i < _filteredGroups.length; i++) {
        _filteredGroups[i] = _filteredGroups[i].copyWith(
          isExpanded: _allExpanded,
        );
      }
    });
  }

  // ═══════════════════════════════════════════════════════════
  // 🚀 JOIN GROUP
  // ═══════════════════════════════════════════════════════════
  Future<void> _joinGroupFromInput() async {
    final input = _groupInputController.text.trim();
    if (input.isEmpty) {
      _showModernToast("Please enter group JID or link", isError: true);
      return;
    }

    _showVideoSplash(
      statusText: "JOINING",
      subtitle: input.length > 40 ? "${input.substring(0, 40)}..." : input,
      accent: _accentPrimary,
    );
    if (mounted) setState(() => _isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$BASE_URL/joinGroup"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'groupInput': input,
        }),
      ).timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) {
        await _failVideoSplash("Server error ${res.statusCode}");
        _showModernErrorDialog(
          title: "Server Error",
          message: "Status: ${res.statusCode}",
        );
        return;
      }

      Map<String, dynamic> data;
      try {
        data = jsonDecode(res.body) as Map<String, dynamic>;
      } catch (_) {
        await _failVideoSplash("Invalid response");
        _showModernErrorDialog(
          title: "Invalid Response",
          message: "Server response tidak valid",
        );
        return;
      }

      if (data["valid"] == true && data["success"] == true) {
        await _finishVideoSplash();
        _showModernSuccessDialog(
          title: "🎉 Group Joined",
          message: data["message"] ?? "Successfully joined group",
        );
        _groupInputController.clear();
        await _checkSenderAndGroups();
      } else {
        await _failVideoSplash("Join failed");
        _showModernErrorDialog(
          title: "Join Failed",
          message: data["message"]?.toString() ?? "Failed to join group",
        );
      }
    } on TimeoutException {
      await _failVideoSplash("Timeout");
      _showModernErrorDialog(
        title: "Timeout",
        message: "Server tidak merespon, coba lagi",
      );
    } catch (e) {
      await _failVideoSplash("Connection error");
      _showModernErrorDialog(
        title: "Connection Error",
        message: "Failed: $e",
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 🐛 SEND BUG
  // ═══════════════════════════════════════════════════════════
  void _startCooldownTimer(int seconds) {
    _cooldownTimer?.cancel();
    if (seconds <= 0) return;
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _cooldownTime--;
        if (_cooldownTime <= 0) {
          _cooldownTime = 0;
          timer.cancel();
        }
      });
    });
  }

  Future<void> _sendBugToGroup() async {
    // Validasi berlapis
    if (!_hasSender) {
      _showModernToast("No active sender available", isError: true);
      return;
    }
    if (_selectedGroup == null) {
      _showModernToast("Please select a group first", isError: true);
      return;
    }
    if (_selectedBug == null || _selectedBug!.id.isEmpty) {
      _showModernToast("Please select a valid bug system", isError: true);
      return;
    }
    if (_selectedGroup!.id.isEmpty) {
      _showModernToast("Invalid group ID", isError: true);
      return;
    }
    if (_cooldownTime > 0) {
      _showModernToast("⏳ Cooldown: ${_cooldownTime}s", isError: true);
      return;
    }

    // 🎬 VIDEO SPLASH
    _showVideoSplash(
      statusText: "FINALIZING",
      subtitle:
          "${_selectedBug!.name.toUpperCase()} → ${_selectedGroup!.id}",
      accent: _accentPrimary,
    );
    if (mounted) setState(() => _isSending = true);

    try {
      // ✅ Kirim JID LENGKAP (jangan split)
      final groupJid = Uri.encodeComponent(_selectedGroup!.id);
      final bugId = Uri.encodeComponent(_selectedBug!.id);
      final sessionKey = Uri.encodeComponent(widget.sessionKey);
      final url = Uri.parse(
        "$BASE_URL/sendBugGroup?key=$sessionKey&group=$groupJid&bugType=$bugId",
      );

      debugPrint("🚀 SEND BUG URL: $url");

      final res = await http.get(url).timeout(const Duration(seconds: 30));

      if (res.statusCode != 200) {
        await _failVideoSplash("Server error ${res.statusCode}");
        _showModernToast("Server error: ${res.statusCode}", isError: true);
        return;
      }

      Map<String, dynamic> data;
      try {
        data = jsonDecode(res.body) as Map<String, dynamic>;
      } catch (_) {
        await _failVideoSplash("Invalid response");
        _showModernToast("Invalid server response", isError: true);
        return;
      }

      debugPrint("📥 SEND BUG RESPONSE: $data");

      if (data["valid"] == false) {
        await _failVideoSplash("Invalid session");
        _showModernToast("Invalid session key", isError: true);
        return;
      }

      if (data["cooldown"] == true) {
        final waitTime = (data["wait"] is int)
            ? data["wait"] as int
            : int.tryParse("${data["wait"]}") ?? 0;
        if (mounted) setState(() => _cooldownTime = waitTime);
        _startCooldownTimer(waitTime);
        await _failVideoSplash("Cooldown ${waitTime}s");
        _showModernToast("⏳ Cooldown: ${waitTime}s", isError: true);
        return;
      }

      if (data["sended"] == true || data["success"] == true) {
        await _finishVideoSplash();
        _showModernSuccessDialog(
          title: "✅ ${_selectedBug!.name} Sent!",
          message:
              "Successfully sent ${_selectedBug!.name} to ${_selectedGroup!.name}",
        );
        return;
      }

      await _failVideoSplash(data["message"]?.toString() ?? "Failed");
      _showModernToast(
        data["message"]?.toString() ?? "Failed to send bug",
        isError: true,
      );
    } on TimeoutException {
      await _failVideoSplash("Timeout");
      _showModernToast("Request timeout, coba lagi", isError: true);
    } catch (e) {
      await _failVideoSplash("Connection failed");
      _showModernToast("Connection failed: $e", isError: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 🎨 GLASS CONTAINER
  // ═══════════════════════════════════════════════════════════
  Widget _glassContainer({
    required Widget child,
    EdgeInsets? padding,
    EdgeInsets? margin,
    double radius = 20,
    Color? borderColor,
    Gradient? gradientOverride,
    bool blur = true,
    bool bright = false,
  }) {
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: borderColor ?? (bright ? _glassBorderBright : _glassBorder),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 24,
            spreadRadius: 2,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: _accentPrimary.withOpacity(0.05),
            blurRadius: 40,
            spreadRadius: -5,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: blur
            ? BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  padding: padding,
                  decoration: BoxDecoration(
                    gradient: gradientOverride ??
                        LinearGradient(
                          colors: bright
                              ? [_glassSurfaceLight, _glassSurface]
                              : [
                                  _glassSurface,
                                  _glassSurface.withOpacity(0.75)
                                ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                    border: Border.all(color: _glassHighlight, width: 0.5),
                  ),
                  child: child,
                ),
              )
            : Container(
                padding: padding,
                decoration: BoxDecoration(
                  gradient: gradientOverride ??
                      LinearGradient(
                        colors: [
                          _glassSurface,
                          _glassSurface.withOpacity(0.75)
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                ),
                child: child,
              ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 💬 DIALOGS & TOAST
  // ═══════════════════════════════════════════════════════════
  void _showModernSuccessDialog(
      {required String title, required String message}) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _glassContainer(
            radius: 32,
            borderColor: _successGreen.withOpacity(0.4),
            bright: true,
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          _successGreen,
                          _successGreen.withOpacity(0.7)
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _successGreen.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 40,
                      shadows: _ts,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    title,
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 24,
                      fontWeight: FontWeight.w300,
                      letterSpacing: 0.5,
                      shadows: _ts,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    message,
                    style: TextStyle(
                      color: _textSecondary,
                      fontSize: 15,
                      fontWeight: FontWeight.w300,
                      height: 1.5,
                      shadows: _ts,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    height: 48,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(
                        colors: [_accentGradientStart, _accentGradientEnd],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _accentPrimary.withOpacity(0.4),
                          blurRadius: 16,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "AWESOME!",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1,
                          shadows: _ts,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showModernErrorDialog(
      {required String title, required String message}) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: _glassContainer(
            radius: 32,
            borderColor: _warningOrange.withOpacity(0.4),
            bright: true,
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          _warningOrange,
                          _warningOrange.withOpacity(0.7)
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _warningOrange.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.close_rounded,
                      color: Colors.white,
                      size: 40,
                      shadows: _ts,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    title,
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 24,
                      fontWeight: FontWeight.w300,
                      letterSpacing: 0.5,
                      shadows: _ts,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    message,
                    style: TextStyle(
                      color: _textSecondary,
                      fontSize: 15,
                      fontWeight: FontWeight.w300,
                      height: 1.5,
                      shadows: _ts,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  Container(
                    width: double.infinity,
                    height: 48,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white.withOpacity(0.08),
                      border: Border.all(color: _glassBorder, width: 1),
                    ),
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "TRY AGAIN",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1,
                          shadows: _ts,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showModernToast(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor:
            isError ? _warningOrange.withOpacity(0.85) : _glassSurfaceLight,
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.info_outline,
              color: _textPrimary,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: TextStyle(
                  color: _textPrimary,
                  fontSize: 14,
                  shadows: _ts,
                ),
              ),
            ),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        duration: const Duration(seconds: 3),
        elevation: 20,
        margin: const EdgeInsets.all(20),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🎴 WIDGETS
  // ═══════════════════════════════════════════════════════════
  Widget _buildBugSystemCard(BugSystem bug) {
    final bool isSelected = _selectedBug?.id == bug.id;

    return GestureDetector(
      onTap: () => setState(() => _selectedBug = bug),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        width: 210,
        margin: const EdgeInsets.only(right: 16, bottom: 8),
        child: _glassContainer(
          radius: 20,
          padding: const EdgeInsets.all(20),
          borderColor: isSelected
              ? _accentPrimary.withOpacity(0.6)
              : _glassBorder,
          gradientOverride: isSelected
              ? LinearGradient(
                  colors: [
                    _accentGradientStart.withOpacity(0.5),
                    _accentGradientEnd.withOpacity(0.5),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _glassBorder, width: 1),
                    ),
                    child: Center(
                      child: Text(bug.icon,
                          style: const TextStyle(fontSize: 22)),
                    ),
                  ),
                  if (isSelected)
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            _accentGradientStart,
                            _accentGradientEnd
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _accentPrimary.withOpacity(0.5),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.check_rounded,
                        color: Colors.white,
                        size: 16,
                        shadows: _ts,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                bug.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w500,
                  shadows: _ts,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                bug.description,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.85),
                  fontSize: 12,
                  fontWeight: FontWeight.w300,
                  shadows: _ts,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGroupCard(int index) {
    final GroupItem group = _filteredGroups[index];
    final bool isSelected = _selectedGroup?.id == group.id;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: _glassContainer(
        radius: 16,
        padding: EdgeInsets.zero,
        borderColor: isSelected
            ? _accentPrimary.withOpacity(0.5)
            : _glassBorder,
        child: Column(
          children: [
            GestureDetector(
              onTap: () => _toggleGroupExpansion(index),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: group.isExpanded
                          ? _accentPrimary.withOpacity(0.2)
                          : Colors.transparent,
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            _accentGradientStart,
                            _accentGradientEnd
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _accentPrimary.withOpacity(0.35),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.group_rounded,
                          color: Colors.white,
                          size: 22,
                          shadows: _ts,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  group.name,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    shadows: _ts,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _successGreen.withOpacity(0.18),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color:
                                          _successGreen.withOpacity(0.4)),
                                ),
                                child: Text(
                                  "JOINED",
                                  style: TextStyle(
                                    color: _successGreen,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 0.5,
                                    shadows: _ts,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(
                                Icons.people_alt_outlined,
                                color: _textTertiary,
                                size: 14,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                "${group.memberCount} members",
                                style: TextStyle(
                                  color: _textTertiary,
                                  fontSize: 13,
                                  shadows: _ts,
                                ),
                              ),
                              const Spacer(),
                              AnimatedRotation(
                                turns: group.isExpanded ? 0.5 : 0,
                                duration: const Duration(milliseconds: 300),
                                child: Icon(
                                  Icons.keyboard_arrow_down_rounded,
                                  color: _textTertiary,
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            AnimatedCrossFade(
              duration: const Duration(milliseconds: 350),
              crossFadeState: group.isExpanded
                  ? CrossFadeState.showFirst
                  : CrossFadeState.showSecond,
              firstChild: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.15),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _glassBorder, width: 1),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.fingerprint_outlined,
                            color: _textTertiary,
                            size: 16,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Group ID",
                                  style: TextStyle(
                                    color: _textTertiary,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                    shadows: _ts,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  group.id,
                                  style: TextStyle(
                                    color: _textSecondary,
                                    fontSize: 12,
                                    fontFamily: 'Monospace',
                                    shadows: _ts,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: isSelected
                            ? LinearGradient(
                                colors: [
                                  _accentGradientStart,
                                  _accentGradientEnd
                                ],
                              )
                            : LinearGradient(
                                colors: [
                                  Colors.white.withOpacity(0.08),
                                  Colors.white.withOpacity(0.04),
                                ],
                              ),
                        border: Border.all(
                          color: isSelected
                              ? Colors.transparent
                              : _glassBorder,
                          width: 1,
                        ),
                        boxShadow: isSelected
                            ? [
                                BoxShadow(
                                  color: _accentPrimary.withOpacity(0.4),
                                  blurRadius: 12,
                                  spreadRadius: 2,
                                  offset: const Offset(0, 3),
                                ),
                              ]
                            : [],
                      ),
                      child: TextButton(
                        onPressed: () {
                          setState(() {
                            _selectedGroup = group;
                          });
                        },
                        style: TextButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              isSelected
                                  ? Icons.check_circle_rounded
                                  : Icons.radio_button_unchecked,
                              color: Colors.white,
                              size: 16,
                              shadows: _ts,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              isSelected ? "SELECTED" : "SELECT GROUP",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.5,
                                shadows: _ts,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              secondChild: const SizedBox(height: 0),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.06),
              border: Border.all(color: _glassBorder, width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Icon(
              Icons.group_off_rounded,
              color: _textTertiary,
              size: 50,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "No Groups Available",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w300,
              letterSpacing: 0.5,
              shadows: _ts,
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              "Connect a WhatsApp sender and join groups to start sending bugs",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.75),
                fontSize: 14,
                fontWeight: FontWeight.w300,
                height: 1.6,
                shadows: _ts,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccessDenied() {
    final roleDisplay = getRoleDisplay(widget.role);
    final roleLevel = getRoleLevel(widget.role);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.35)),
          ),
          SafeArea(
            child: Center(
              child: _glassContainer(
                radius: 28,
                padding: const EdgeInsets.all(36),
                margin: const EdgeInsets.symmetric(horizontal: 24),
                borderColor: _warningOrange.withOpacity(0.4),
                bright: true,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _warningOrange.withOpacity(0.15),
                        border: Border.all(
                          color: _warningOrange.withOpacity(0.4),
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.lock_outline_rounded,
                        color: Colors.redAccent,
                        size: 48,
                        shadows: _ts,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      "AKSES DITOLAK",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2,
                        shadows: _ts,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Bug Group hanya untuk role:\nCEO, Owner, Admin, Tangan Kanan, dan VIP",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 14,
                        height: 1.6,
                        shadows: _ts,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: _warningOrange.withOpacity(0.12),
                        border: Border.all(
                            color: _warningOrange.withOpacity(0.3)),
                      ),
                      child: Text(
                        "Role Anda: $roleDisplay (Level $roleLevel)",
                        style: TextStyle(
                          color: _warningOrange,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          shadows: _ts,
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),
                    SizedBox(
                      width: 200,
                      height: 48,
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.arrow_back,
                            color: Colors.white, shadows: _ts),
                        label: const Text(
                          "KEMBALI",
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                            shadows: _ts,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _accentPrimary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🏗️ BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    if (!_canAccessBugGroup(widget.role)) {
      return _buildAccessDenied();
    }

    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          extendBody: true,
          extendBodyBehindAppBar: true,
          body: SafeArea(
            child: Column(
              children: [
                // ─── GLASS HEADER ───
                Container(
                  margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                  child: _glassContainer(
                    radius: 18,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    bright: true,
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                _accentGradientStart,
                                _accentGradientEnd
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _accentPrimary.withOpacity(0.35),
                                blurRadius: 12,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.groups_rounded,
                            color: Colors.white,
                            size: 22,
                            shadows: _ts,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Text(
                                    "Bug Groups",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w400,
                                      letterSpacing: 0.5,
                                      shadows: _ts,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(10),
                                      color: _successGreen.withOpacity(0.15),
                                      border: Border.all(
                                          color: _successGreen
                                              .withOpacity(0.3)),
                                    ),
                                    child: Text(
                                      getRoleDisplay(widget.role),
                                      style: TextStyle(
                                        color: _successGreen,
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 0.5,
                                        shadows: _ts,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 2),
                              Text(
                                _hasSender
                                    ? "${_joinedGroups.length} groups • ${widget.role}"
                                    : "⚠️ No sender connected",
                                style: TextStyle(
                                  color: _hasSender
                                      ? _successGreen
                                      : _warningOrange,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                  shadows: _ts,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.10),
                            border:
                                Border.all(color: _glassBorder, width: 1),
                          ),
                          child: IconButton(
                            onPressed:
                                _isLoading ? null : _checkSenderAndGroups,
                            icon: Icon(
                              _isLoading
                                  ? Icons.hourglass_top_rounded
                                  : Icons.refresh_rounded,
                              color: _textSecondary,
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // ─── MAIN CONTENT ───
                Expanded(
                  child: SingleChildScrollView(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // ─── JOIN GROUP ───
                        _glassContainer(
                          radius: 20,
                          padding: const EdgeInsets.all(20),
                          margin: const EdgeInsets.only(bottom: 16),
                          bright: true,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.add_circle_outline_rounded,
                                    color: _accentPrimary,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 10),
                                  const Text(
                                    "Join New Group",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      shadows: _ts,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  color: Colors.black.withOpacity(0.28),
                                  border: Border.all(
                                      color: _glassBorder, width: 1),
                                ),
                                child: TextField(
                                  controller: _groupInputController,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w300,
                                    shadows: _ts,
                                  ),
                                  decoration: InputDecoration(
                                    hintText:
                                        "Enter group JID or link...",
                                    hintStyle: TextStyle(
                                      color:
                                          Colors.white.withOpacity(0.5),
                                      fontSize: 13,
                                      fontWeight: FontWeight.w300,
                                    ),
                                    prefixIcon: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16, right: 12),
                                      child: Icon(
                                        Icons.link_rounded,
                                        color: _textTertiary,
                                        size: 20,
                                      ),
                                    ),
                                    border: InputBorder.none,
                                    contentPadding:
                                        const EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 14,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Container(
                                width: double.infinity,
                                height: 48,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(14),
                                  gradient: _isLoading
                                      ? LinearGradient(
                                          colors: [
                                            Colors.white.withOpacity(0.1),
                                            Colors.white.withOpacity(0.05),
                                          ],
                                        )
                                      : LinearGradient(
                                          colors: [
                                            _accentGradientStart,
                                            _accentGradientEnd
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                  boxShadow: _isLoading
                                      ? []
                                      : [
                                          BoxShadow(
                                            color: _accentPrimary
                                                .withOpacity(0.4),
                                            blurRadius: 16,
                                            spreadRadius: 2,
                                            offset: const Offset(0, 4),
                                          ),
                                        ],
                                ),
                                child: TextButton(
                                  onPressed: _isLoading
                                      ? null
                                      : _joinGroupFromInput,
                                  style: TextButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(14),
                                    ),
                                  ),
                                  child: _isLoading
                                      ? const SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : const Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Icon(
                                              Icons.add_rounded,
                                              color: Colors.white,
                                              size: 18,
                                              shadows: _ts,
                                            ),
                                            SizedBox(width: 8),
                                            Text(
                                              "JOIN GROUP",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14,
                                                fontWeight: FontWeight.w600,
                                                letterSpacing: 0.5,
                                                shadows: _ts,
                                              ),
                                            ),
                                          ],
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        // ─── GROUPS ───
                        if (_joinedGroups.isNotEmpty) ...[
                          _glassContainer(
                            radius: 16,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            margin: const EdgeInsets.only(bottom: 16),
                            child: Row(
                              children: [
                                const SizedBox(width: 8),
                                Icon(
                                  Icons.search_rounded,
                                  color: _textTertiary,
                                  size: 20,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: TextField(
                                    controller: _searchController,
                                    onChanged: _filterGroups,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w300,
                                      shadows: _ts,
                                    ),
                                    decoration: InputDecoration(
                                      hintText: "Search groups...",
                                      hintStyle: TextStyle(
                                        color: Colors.white
                                            .withOpacity(0.5),
                                        fontSize: 13,
                                        fontWeight: FontWeight.w300,
                                      ),
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                                if (_searchController.text.isNotEmpty)
                                  IconButton(
                                    onPressed: () {
                                      _searchController.clear();
                                      _filterGroups('');
                                    },
                                    icon: Icon(
                                      Icons.close_rounded,
                                      color: _textTertiary,
                                      size: 18,
                                    ),
                                  ),
                                IconButton(
                                  onPressed: _toggleAllGroups,
                                  icon: Icon(
                                    _allExpanded
                                        ? Icons.unfold_less
                                        : Icons.unfold_more,
                                    color: _accentPrimary,
                                    size: 20,
                                  ),
                                  tooltip: _allExpanded
                                      ? "Collapse All"
                                      : "Expand All",
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.list_alt_rounded,
                                      color: _accentPrimary,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 8),
                                    const Text(
                                      "Your Groups",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w400,
                                        shadows: _ts,
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color:
                                        Colors.white.withOpacity(0.10),
                                    borderRadius:
                                        BorderRadius.circular(16),
                                    border: Border.all(
                                        color: _glassBorder, width: 1),
                                  ),
                                  child: Text(
                                    "${_filteredGroups.length} groups",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500,
                                      shadows: _ts,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          _filteredGroups.isEmpty
                              ? Container(
                                  height: 150,
                                  margin: const EdgeInsets.only(top: 20),
                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.search_off_rounded,
                                          color: _textTertiary,
                                          size: 50,
                                        ),
                                        const SizedBox(height: 16),
                                        const Text(
                                          "No groups found",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w300,
                                            shadows: _ts,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              : ListView.builder(
                                  shrinkWrap: true,
                                  physics:
                                      const NeverScrollableScrollPhysics(),
                                  itemCount: _filteredGroups.length,
                                  itemBuilder: (context, index) {
                                    return _buildGroupCard(index);
                                  },
                                ),
                          const SizedBox(height: 24),
                          // ─── BUG SYSTEMS ───
                          if (_selectedGroup != null &&
                              _filteredGroups.isNotEmpty) ...[
                            _glassContainer(
                              radius: 20,
                              padding: const EdgeInsets.all(20),
                              margin: const EdgeInsets.only(bottom: 16),
                              bright: true,
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.bug_report_rounded,
                                        color: _accentPrimary,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              "Bug Systems",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18,
                                                fontWeight:
                                                    FontWeight.w400,
                                                shadows: _ts,
                                              ),
                                            ),
                                            const SizedBox(height: 2),
                                            Text(
                                              "Selected: ${_selectedGroup!.name}",
                                              style: TextStyle(
                                                color: _textTertiary,
                                                fontSize: 12,
                                                shadows: _ts,
                                              ),
                                              maxLines: 1,
                                              overflow:
                                                  TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 16),
                                  _isLoadingBugs
                                      ? Container(
                                          height: 120,
                                          alignment: Alignment.center,
                                          child:
                                              CircularProgressIndicator(
                                            color: _accentPrimary,
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : _bugSystems.isEmpty
                                          ? Container(
                                              height: 120,
                                              alignment:
                                                  Alignment.center,
                                              child: Text(
                                                "No bug systems available",
                                                style: TextStyle(
                                                  color: _textTertiary,
                                                  fontSize: 14,
                                                  shadows: _ts,
                                                ),
                                              ),
                                            )
                                          : SizedBox(
                                              height: 140,
                                              child: ListView.builder(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                itemCount:
                                                    _bugSystems.length,
                                                itemBuilder:
                                                    (context, index) {
                                                  return _buildBugSystemCard(
                                                      _bugSystems[index]);
                                                },
                                              ),
                                            ),
                                  const SizedBox(height: 20),
                                  // ─── SEND BUTTON ───
                                  Container(
                                    width: double.infinity,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(14),
                                      gradient: (_cooldownTime > 0 ||
                                              _selectedBug == null ||
                                              _isSending)
                                          ? LinearGradient(
                                              colors: [
                                                Colors.white
                                                    .withOpacity(0.1),
                                                Colors.white
                                                    .withOpacity(0.05),
                                              ],
                                            )
                                          : LinearGradient(
                                              colors: [
                                                _accentGradientStart,
                                                _accentGradientEnd
                                              ],
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                            ),
                                      boxShadow: (_cooldownTime > 0 ||
                                              _selectedBug == null ||
                                              _isSending)
                                          ? []
                                          : [
                                              BoxShadow(
                                                color: _accentPrimary
                                                    .withOpacity(0.4),
                                                blurRadius: 16,
                                                spreadRadius: 2,
                                                offset:
                                                    const Offset(0, 4),
                                              ),
                                            ],
                                      border: Border.all(
                                        color: (_cooldownTime > 0 ||
                                                _selectedBug == null ||
                                                _isSending)
                                            ? _glassBorder
                                            : Colors.transparent,
                                        width: 1,
                                      ),
                                    ),
                                    child: TextButton(
                                      onPressed: (_isSending ||
                                              _cooldownTime > 0 ||
                                              _selectedBug == null)
                                          ? null
                                          : _sendBugToGroup,
                                      style: TextButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(14),
                                        ),
                                      ),
                                      child: _isSending
                                          ? const SizedBox(
                                              width: 20,
                                              height: 20,
                                              child:
                                                  CircularProgressIndicator(
                                                strokeWidth: 2,
                                                color: Colors.white,
                                              ),
                                            )
                                          : Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .center,
                                              children: [
                                                Icon(
                                                  _cooldownTime > 0
                                                      ? Icons
                                                          .timer_outlined
                                                      : Icons.send_rounded,
                                                  color: Colors.white,
                                                  size: 20,
                                                  shadows: _ts,
                                                ),
                                                const SizedBox(width: 8),
                                                Text(
                                                  _cooldownTime > 0
                                                      ? "WAIT ${_cooldownTime}s"
                                                      : "SEND ${_selectedBug?.name?.toUpperCase() ?? 'BUG'}",
                                                  style:
                                                      const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.w600,
                                                    letterSpacing: 0.5,
                                                    shadows: _ts,
                                                  ),
                                                ),
                                              ],
                                            ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ] else ...[
                          _buildEmptyState(),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}