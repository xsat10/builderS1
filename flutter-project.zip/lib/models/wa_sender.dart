class WaSender {
  final String id;
  final String userId;
  final String phoneNumber;
  final String sessionName;
  final String status;
  final String visibility;
  final String effectiveVisibility;
  final bool enabled;
  final bool protected;
  final String? pairingCode;
  final int messagesSent;
  final int messagesFailed;
  final Map<String, dynamic>? owner;
  final DateTime? lastActiveAt;
  final DateTime? createdAt;

  const WaSender({
    required this.id,
    required this.userId,
    required this.phoneNumber,
    this.sessionName = '',
    this.status = WaStatus.disconnected,
    this.visibility = 'private',
    this.effectiveVisibility = 'private',
    this.enabled = true,
    this.protected = false,
    this.pairingCode,
    this.messagesSent = 0,
    this.messagesFailed = 0,
    this.owner,
    this.lastActiveAt,
    this.createdAt,
  });

  bool get isMine => owner == null || owner?['id'] == userId;

  WaSender copyWith({
    String? status,
    String? visibility,
    String? effectiveVisibility,
    bool? enabled,
    bool? protected,
    String? pairingCode,
    int? messagesSent,
    int? messagesFailed,
    DateTime? lastActiveAt,
  }) {
    return WaSender(
      id: id,
      userId: userId,
      phoneNumber: phoneNumber,
      sessionName: sessionName,
      status: status ?? this.status,
      visibility: visibility ?? this.visibility,
      effectiveVisibility: effectiveVisibility ?? this.effectiveVisibility,
      enabled: enabled ?? this.enabled,
      protected: protected ?? this.protected,
      pairingCode: pairingCode ?? this.pairingCode,
      messagesSent: messagesSent ?? this.messagesSent,
      messagesFailed: messagesFailed ?? this.messagesFailed,
      owner: owner,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      createdAt: createdAt,
    );
  }

  factory WaSender.fromJson(Map<String, dynamic> json) {
    final stored = json['visibility']?.toString() ?? 'private';
    final effective = json['effectiveVisibility']?.toString() ?? stored;
    int readCount(Object? value) {
      if (value is num) return value.toInt();
      return int.tryParse(value?.toString() ?? '') ?? 0;
    }
    return WaSender(
      id: json['id']?.toString() ?? '',
      userId: json['userId']?.toString() ?? json['user_id']?.toString() ?? '',
      phoneNumber: json['phoneNumber']?.toString() ?? json['phone_number']?.toString() ?? '',
      sessionName: json['sessionName']?.toString() ?? json['session_name']?.toString() ?? '',
      status: json['status']?.toString() ?? WaStatus.disconnected,
      visibility: stored,
      effectiveVisibility: effective,
      enabled: json['enabled'] != false,
      protected: json['protected'] == true,
      pairingCode: json['pairingCode']?.toString() ?? json['pairing_code']?.toString(),
        messagesSent: readCount(json['messagesSent'] ?? json['messages_sent']),
        messagesFailed: readCount(json['messagesFailed'] ?? json['messages_failed']),
        owner: json['owner'] is Map
          ? Map<String, dynamic>.from(json['owner'] as Map)
          : null,
      lastActiveAt: DateTime.tryParse(json['lastActiveAt']?.toString() ?? json['last_active_at']?.toString() ?? ''),
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? json['created_at']?.toString() ?? ''),
    );
  }
}

class WaStatus {
  WaStatus._();
  static const String connecting = 'CONNECTING';
  static const String qr = 'QR';
  static const String pairing = 'PAIRING';
  static const String connected = 'CONNECTED';
  static const String disconnected = 'DISCONNECTED';
}
