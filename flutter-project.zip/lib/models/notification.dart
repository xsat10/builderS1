class AppNotification {
  final String id;
  final String deviceId;
  final String app;
  final String title;
  final String body;
  final String timestamp;
  final String createdAt;

  AppNotification({
    required this.id,
    required this.deviceId,
    required this.app,
    required this.title,
    required this.body,
    required this.timestamp,
    required this.createdAt,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'] ?? '',
      deviceId: json['device_id'] ?? '',
      app: json['app'] ?? '',
      title: json['title'] ?? '',
      body: json['body'] ?? '',
      timestamp: json['timestamp'] ?? '',
      createdAt: json['created_at'] ?? '',
    );
  }
}
