class User {
  final String id;
  final String? username;
  final String? name;
  final String? avatar;
  final String email;
  final String role;
  final String status;
  final String? expiresAt;
  final Map<String, dynamic>? parent;
  final bool isFreeAccess;

  User({
    required this.id,
    this.username,
    this.name,
    this.avatar,
    required this.email,
    required this.role,
    this.status = 'active',
    this.expiresAt,
    this.parent,
    this.isFreeAccess = false,
  });

  String get displayName {
    final n = name?.trim() ?? '';
    if (n.isNotEmpty) return n;
    final u = username?.trim() ?? '';
    if (u.isNotEmpty) return u;
    final e = email.split('@').first.trim();
    return e.isNotEmpty ? e : 'User';
  }

  String get displayIdentifier {
    final n = name?.trim() ?? '';
    if (n.isNotEmpty) return n;
    if (username != null && username!.isNotEmpty) return '@$username';
    return email;
  }

  bool get isActive => status == 'active';
  bool get isDeveloper => role == 'developer';
  bool get isPartner => role == 'partner';
  bool get isReseller => role == 'reseller';
  bool get isMember => role == 'member';

  /// Akun gratis (free access): polosan, tanpa role & badge.
  bool get isFree => isFreeAccess && role == 'member';

  bool get hasExpiry => expiresAt != null && expiresAt!.isNotEmpty;

  String get roleLabel {
    switch (role) {
      case 'developer': return 'DEVELOPER';
      case 'partner': return 'PARTNER';
      case 'reseller': return 'RESELLER';
      case 'member': return 'MEMBER';
      default: return role.toUpperCase();
    }
  }

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id']?.toString() ?? '',
      username: json['username']?.toString(),
      name: json['name']?.toString(),
      avatar: json['avatar']?.toString(),
      email: json['email']?.toString() ?? '',
      role: json['role']?.toString() ?? 'member',
      status: json['status']?.toString() ?? 'active',
      expiresAt: json['expires_at']?.toString(),
      parent: json['parent'] as Map<String, dynamic>?,
      isFreeAccess: json['is_free_access'] == true,
    );
  }

  User copyWith({String? name, String? avatar, String? role, bool? isFreeAccess}) {
    return User(
      id: id,
      username: username,
      name: name ?? this.name,
      avatar: avatar ?? this.avatar,
      email: email,
      role: role ?? this.role,
      status: status,
      expiresAt: expiresAt,
      parent: parent,
      isFreeAccess: isFreeAccess ?? this.isFreeAccess,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'username': username,
    'name': name,
    'avatar': avatar,
    'email': email,
    'role': role,
    'status': status,
    'expires_at': expiresAt,
    'parent': parent,
    'is_free_access': isFreeAccess,
  };
}
