class MusicTrack {
  final String id;
  final String title;
  final String artist;
  final String spotifyUrl;
  final String audioUrl;
  final String? artwork;

  MusicTrack({
    required this.id,
    required this.title,
    required this.artist,
    required this.spotifyUrl,
    required this.audioUrl,
    this.artwork,
  });

  factory MusicTrack.fromJson(Map<String, dynamic> json) {
    return MusicTrack(
      id: json['id']?.toString() ?? '',
      title: json['title'] ?? '',
      artist: json['artist'] ?? '',
      spotifyUrl: json['spotifyUrl'] ?? json['spotify_url'] ?? '',
      audioUrl: json['audioUrl'] ?? json['url'] ?? json['audio_url'] ?? '',
      artwork: (json['artwork'] ?? json['image_url'] ?? json['coverUrl']) as String?,
    );
  }
}
