class Device {
  final String id;
  final String ownerId;
  final String name;
  final String model;
  final String androidVersion;
  final String novaVersion;
  String status;
  double battery;
  double cpu;
  double ram;
  double storage;
  String network;
  final String? lastHeartbeat;
  final String? revokedAt;
  final String createdAt;
  final String updatedAt;
  bool screenSharing;
  bool notifications;
  bool location;
  bool camera;
  bool microphone;

  Device({
    required this.id,
    required this.ownerId,
    required this.name,
    required this.model,
    required this.androidVersion,
    required this.novaVersion,
    required this.status,
    this.battery = 0,
    this.cpu = 0,
    this.ram = 0,
    this.storage = 0,
    this.network = 'unknown',
    this.lastHeartbeat,
    this.revokedAt,
    required this.createdAt,
    required this.updatedAt,
    this.screenSharing = false,
    this.notifications = false,
    this.location = false,
    this.camera = false,
    this.microphone = false,
  });

  bool get isOnline => status == 'online';

  factory Device.fromJson(Map<String, dynamic> json) {
    return Device(
      id: json['id'] ?? '',
      ownerId: json['owner_id'] ?? '',
      name: json['name'] ?? '',
      model: json['model'] ?? '',
      androidVersion: json['android_version'] ?? '',
      novaVersion: json['nova_version'] ?? '',
      status: json['status'] ?? 'offline',
      battery: (json['battery'] ?? 0).toDouble(),
      cpu: (json['cpu'] ?? 0).toDouble(),
      ram: (json['ram'] ?? 0).toDouble(),
      storage: (json['storage'] ?? 0).toDouble(),
      network: json['network'] ?? 'unknown',
      lastHeartbeat: json['last_heartbeat'],
      revokedAt: json['revoked_at'],
      createdAt: json['created_at'] ?? '',
      updatedAt: json['updated_at'] ?? '',
      screenSharing: json['screen_sharing'] ?? false,
      notifications: json['notifications'] ?? false,
      location: json['location'] ?? false,
      camera: json['camera'] ?? false,
      microphone: json['microphone'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'owner_id': ownerId,
    'name': name,
    'model': model,
    'android_version': androidVersion,
    'nova_version': novaVersion,
    'status': status,
    'battery': battery,
    'cpu': cpu,
    'ram': ram,
    'storage': storage,
    'network': network,
    'last_heartbeat': lastHeartbeat,
    'revoked_at': revokedAt,
    'created_at': createdAt,
    'updated_at': updatedAt,
  };
}
