class WaFunction {
  final String id;
  final String name;
  final String description;
  final String kind;
  final bool enabled;

  const WaFunction({
    required this.id,
    required this.name,
    this.description = '',
    this.kind = 'any',
    this.enabled = true,
  });

  factory WaFunction.fromJson(Map<String, dynamic> json) {
    return WaFunction(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? json['id']?.toString() ?? '',
      description: json['description']?.toString() ?? json['message']?.toString() ?? '',
      kind: json['kind']?.toString() ?? 'any',
      enabled: json['enabled'] == true || json['enabled'] == 'true' || json['active'] == true || json['active'] == 'true',
    );
  }
}
