class NewsItem {
  final String id;
  final String title;
  final String description;
  final String? buttonText;
  final String? buttonUrl;
  final String? imageUrl;
  final String? backgroundImageUrl;
  final bool showButton;
  final int sortOrder;

  NewsItem({
    required this.id,
    required this.title,
    required this.description,
    this.buttonText,
    this.buttonUrl,
    this.imageUrl,
    this.backgroundImageUrl,
    this.showButton = false,
    this.sortOrder = 0,
  });

  factory NewsItem.fromJson(Map<String, dynamic> json) {
    return NewsItem(
      id: json['id']?.toString() ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      buttonText: (json['buttonText'] ?? json['button_text']) as String?,
      buttonUrl: (json['buttonUrl'] ?? json['button_url']) as String?,
      imageUrl: (json['image_url'] ?? json['imageUrl']) as String?,
      backgroundImageUrl: (json['background_image_url'] ?? json['backgroundImageUrl']) as String?,
      showButton: json['showButton'] == true || json['show_button'] == true,
      sortOrder: (json['sortOrder'] ?? json['sort_order'] ?? 0) as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
    'title': title,
    'description': description,
    'button_text': buttonText,
    'button_url': buttonUrl,
    'image_url': imageUrl,
    'background_image_url': backgroundImageUrl,
    'show_button': showButton,
    'sort_order': sortOrder,
  };
}
