class Story {
  final String id;
  final String userId;
  final String contentType; // text, photo, video, photo_text, video_text
  final String? textContent;
  final String? mediaUrl;
  final String? bgColor;
  final DateTime createdAt;
  final DateTime expiresAt;
  final StoryUser? user;

  Story({
    required this.id,
    required this.userId,
    required this.contentType,
    this.textContent,
    this.mediaUrl,
    this.bgColor,
    required this.createdAt,
    required this.expiresAt,
    this.user,
  });

  bool get isExpired => DateTime.now().isAfter(expiresAt);
  bool get hasMedia => contentType.contains('photo') || contentType.contains('video');
  bool get hasText => contentType.contains('text') || (textContent?.isNotEmpty ?? false);
  bool get isVideo => contentType.contains('video');
  bool get isPhoto => contentType.contains('photo');

  factory Story.fromJson(Map<String, dynamic> json) {
    return Story(
      id: json['id']?.toString() ?? '',
      userId: json['user_id']?.toString() ?? '',
      contentType: json['content_type']?.toString() ?? 'text',
      textContent: json['text_content']?.toString(),
      mediaUrl: json['media_url']?.toString(),
      bgColor: json['bg_color']?.toString(),
      createdAt: DateTime.tryParse(json['created_at']?.toString() ?? '') ?? DateTime.now(),
      expiresAt: DateTime.tryParse(json['expires_at']?.toString() ?? '') ?? DateTime.now().add(const Duration(hours: 12)),
      user: json['user'] != null ? StoryUser.fromJson(json['user'] as Map<String, dynamic>) : null,
    );
  }
}

class StoryUser {
  final String id;
  final String? username;
  final String? name;
  final String? avatar;
  final String? role;

  StoryUser({
    required this.id,
    this.username,
    this.name,
    this.avatar,
    this.role,
  });

  String get displayName {
    final n = name?.trim() ?? '';
    if (n.isNotEmpty) return n;
    final u = username?.trim() ?? '';
    if (u.isNotEmpty) return u;
    return 'User';
  }

  factory StoryUser.fromJson(Map<String, dynamic> json) {
    return StoryUser(
      id: json['id']?.toString() ?? '',
      username: json['username']?.toString(),
      name: json['name']?.toString(),
      avatar: json['avatar']?.toString(),
      role: json['role']?.toString(),
    );
  }
}
