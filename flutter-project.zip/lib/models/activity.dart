class Activity {
  final String id;
  final String userId;
  final String deviceId;
  final String action;
  final String status;
  final String message;
  final String createdAt;

  Activity({
    required this.id,
    required this.userId,
    required this.deviceId,
    required this.action,
    required this.status,
    required this.message,
    required this.createdAt,
  });

  factory Activity.fromJson(Map<String, dynamic> json) {
    return Activity(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      deviceId: json['device_id'] ?? '',
      action: json['action'] ?? '',
      status: json['status'] ?? '',
      message: json['message'] ?? '',
      createdAt: json['created_at'] ?? '',
    );
  }

  String get actionLabel {
    switch (action) {
      case 'pair': return 'Device paired';
      case 'connect': return 'Device connected';
      case 'disconnect': return 'Device disconnected';
      case 'revoke': return 'Access revoked';
      case 'heartbeat': return 'Status update';
      case 'flashlight': return 'Flashlight toggled';
      case 'vibrate': return 'Device vibrated';
      case 'notification': return 'Notification sent';
      case 'screen_start': return 'Screen sharing started';
      case 'screen_stop': return 'Screen sharing stopped';
      case 'screenshot': return 'Screenshot taken';
      case 'camera_start': return 'Camera started';
      case 'camera_stop': return 'Camera stopped';
      case 'camera_switch': return 'Camera switched';
      case 'microphone_start': return 'Microphone started';
      case 'microphone_stop': return 'Microphone stopped';
      case 'location': return 'Location requested';
      case 'status': return 'Status requested';
      case 'sync': return 'Sync requested';
      case 'permission': return 'Permission changed';
      case 'wa_send': return 'WhatsApp message sent';
      default:
        if (action.startsWith('Tool:')) return action;
        return action;
    }
  }
}
