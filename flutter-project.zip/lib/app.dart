import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/device_provider.dart';
import 'providers/app_refresh_provider.dart';
import 'models/device.dart';
import 'services/api_service.dart';
import 'theme.dart';
import 'widgets/neo_bottom_nav.dart';
import 'widgets/neo_block_loader.dart';
import 'widgets/neo_button.dart';
import 'widgets/neo_create_account_dialog.dart';
import 'widgets/neo_glass_overlay.dart';
import 'widgets/neo_feature_config.dart';
import 'widgets/transition_state.dart';
import 'widgets/roman_sheet.dart';
import 'screens/home_screen.dart';
import 'screens/control_screen.dart';
import 'screens/login_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/intro_screen.dart';
import 'screens/pre_login_screen.dart';
import 'screens/fingerprint_screen.dart';
import 'screens/partner_screen.dart';
import 'screens/reseller_screen.dart';
import 'screens/user_management_screen.dart';
import 'screens/device_detail_screen.dart';
import 'screens/news_management_screen.dart';
import 'screens/feature_management_screen.dart';
import 'screens/sender_management_screen.dart';
import 'screens/activity_screen.dart';
import 'screens/whatsapp_screen.dart';
import 'screens/tools_screen.dart';
import 'screens/manage_screen.dart';
import 'screens/pairing_screen.dart';
import 'screens/device_screen.dart';
import 'screens/touch_image_screen.dart';
import 'screens/profile_screen.dart';
import 'widgets/neo_drawer.dart';
import 'widgets/neo_theme_picker.dart';
import 'providers/theme_provider.dart';

/// Transformasi warm pink pastel (bubble-gum) global via ColorFiltered.
/// Matrix warm pink-plum (bubble-gum): menarik seluruh warna (navy → plum-warm).
const List<double> _bubbleMatrix = [
  1.18, 0.04, 0.03, 0.0, 30,  // R: naik → merah muda
  0.03, 1.08, 0.03, 0.0, 8,   // G: sedikit naik
  -0.12, -0.06, 0.82, 0.0, 34, // B: gain turun + offset → ungu-warm
  0.0, 0.0, 0.0, 1.0, 0.0,    // A
];

class NovaGuardControlApp extends StatefulWidget {
  const NovaGuardControlApp({super.key});

  @override
  State<NovaGuardControlApp> createState() => _NovaGuardControlAppState();
}

class _NovaGuardControlAppState extends State<NovaGuardControlApp> {
  final ThemeMode _themeMode = ThemeMode.dark;

  @override
  Widget build(BuildContext context) {
    final tp = context.watch<NeoThemeProvider>();
    final p = tp.palette;
    final light = tp.isBubbleGum;
    return MaterialApp(
      title: 'NovaCore BUG x RAT',
      debugShowCheckedModeBanner: false,
      theme: NeoTheme.lightTheme.copyWith(
        scaffoldBackgroundColor: p.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: p.primary,
          brightness: Brightness.light,
          surface: p.surface,
        ),
      ),
      darkTheme: NeoTheme.darkTheme.copyWith(
        scaffoldBackgroundColor: p.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: p.primary,
          brightness: Brightness.dark,
          surface: p.surface,
        ),
      ),
      themeMode: light ? ThemeMode.light : ThemeMode.dark,
      builder: (context, child) => tp.isBubbleGum
          ? ColorFiltered(
              colorFilter: const ColorFilter.matrix(_bubbleMatrix),
              child: child!,
            )
          : child!,
      initialRoute: '/',
      onGenerateRoute: (settings) {
        Widget page;
        switch (settings.name) {
           case '/':
             page = const FingerprintScreen();
          case '/prelogin':
            page = const PreLoginScreen();
          case '/splash':
            page = const IntroScreen();
          case '/video':
            page = const IntroScreen();
          case '/intro':
            page = const IntroScreen();
          case '/welcome':
            page = const WelcomeScreen();
          case '/login':
            page = const LoginScreen();
          case '/home':
            page = const _MainShell();
          case '/device-detail':
            page = const DeviceDetailScreen();
          case '/users':
            page = const UserManagementScreen();
          case '/partners':
            page = const PartnerScreen();
          case '/resellers':
            page = const ResellerScreen();
          case '/news-management':
            page = const NewsManagementScreen();
          case '/features':
            page = const FeatureManagementScreen();
          default:
            page = const IntroScreen();
        }
        return _buildRoute(page);
      },
    );
  }
}

class _BootCheck extends StatefulWidget {
  const _BootCheck();

  @override
  State<_BootCheck> createState() => _BootCheckState();
}

class _BootCheckState extends State<_BootCheck> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final auth = context.read<AuthProvider>();
      bool ok = auth.authenticated;
      if (!ok) {
        await auth.tryAutoLogin();
        ok = auth.authenticated;
      }
      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pushReplacementNamed('/intro');
      } else {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoColors.darkBg,
      body: Center(
        child: NeoBlockLoader(
          blockSize: 8,
          c0: NeoColors.black,
          c1: NeoColors.yellow,
        ),
      ),
    );
  }
}

class _MainShell extends StatefulWidget {
  const _MainShell();

  @override
  State<_MainShell> createState() => _MainShellState();
}

Route _buildRoute(Widget page) {
  return PageRouteBuilder(
    pageBuilder: (context, animation, secondaryAnimation) => page,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      const begin = Offset(0.0, 0.02);
      const end = Offset.zero;
      const curve = Curves.easeOut;
      var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
      return SlideTransition(position: animation.drive(tween), child: child);
    },
    transitionDuration: const Duration(milliseconds: 200),
  );
}

class _MainShellState extends State<_MainShell> with TickerProviderStateMixin {
  int _currentIndex = 0;
  int _exitIndex = 0;
  int _enterIndex = 0;
  final List<int> _tabHistory = [];
  final List<int> _subStack = [];
  bool _transitioning = false;
  bool _handlingBlocked = false;
  bool _screenDialogShowing = false;
  String? _lastPermDeviceId;
  DateTime? _lastPermTime;
  StreamSubscription<Map<String, dynamic>>? _screenPermSub;
  StreamSubscription<Map<String, dynamic>>? _statusEventSub;
  late final AnimationController _sceneCtrl;

  @override
  void initState() {
    super.initState();
    context.read<AuthProvider>().addListener(_onAuthChanged);
    _sceneCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 240),
    );
    _sceneCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() => _transitioning = false);
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _screenPermSub = context
          .read<DeviceProvider>()
          .socket
          .screenPermissionStream
          .listen(_onScreenPermission);
      _statusEventSub = context.read<DeviceProvider>().statusEventStream.listen(
        _onStatusEvent,
      );
    });
  }

  @override
  void dispose() {
    _screenPermSub?.cancel();
    _statusEventSub?.cancel();
    context.read<AuthProvider>().removeListener(_onAuthChanged);
    _sceneCtrl.dispose();
    super.dispose();
  }

  void _onStatusEvent(Map<String, dynamic> data) {
    if (!mounted) return;
    final myId = context.read<AuthProvider>().user?.id;
    final ownerId = data['ownerId'] as String?;
    if (myId == null || ownerId != myId) return;
    final name = data['name'] as String? ?? 'Device';
    final status = data['status'] as String? ?? '';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          status == 'online' ? '$name sedang online' : '$name sedang offline',
        ),
        backgroundColor: status == 'online' ? NeoColors.green : NeoColors.grey,
      ),
    );
  }

  void _onScreenPermission(Map<String, dynamic> data) {
    if (!mounted || _screenDialogShowing) return;
    if (data['granted'] == false) return;
    if (_currentIndex == FeatureConfig.deviceDetailIndex ||
        (_transitioning && _enterIndex == FeatureConfig.deviceDetailIndex)) {
      return;
    }
    final deviceId = data['deviceId'] as String?;
    if (deviceId == null) return;

    final now = DateTime.now();
    if (deviceId == _lastPermDeviceId &&
        _lastPermTime != null &&
        now.difference(_lastPermTime!) < const Duration(seconds: 8)) {
      return;
    }
    _lastPermDeviceId = deviceId;
    _lastPermTime = now;

    final dp = context.read<DeviceProvider>();
    final device = dp.devices.where((d) => d.id == deviceId).firstOrNull;
    if (device == null) return;

    _screenDialogShowing = true;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: NeoGlassOverlay(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'LIVE SCREEN',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: NeoColors.primaryText),
              ),
              const SizedBox(height: 12),
              Text(
                '${device.name} memberikan izin live screen.\nBuka live screen sekarang?',
                textAlign: TextAlign.center,
                style: TextStyle(color: NeoColors.secondaryText),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: NeoButton(
                      label: 'NANTI',
                      height: 40,
                      fontSize: 13,
                      bgColor: NeoColors.surfaceElevated,
                      textColor: NeoColors.primaryText,
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: NeoButton(
                      label: 'BUKA LIVE SCREEN',
                      height: 40,
                      fontSize: 13,
                      onPressed: () {
                        Navigator.pop(ctx);
                        _openLiveScreen(device);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ).whenComplete(() => _screenDialogShowing = false);
  }

  void _openLiveScreen(Device device) {
    if (!mounted) return;
    final dp = context.read<DeviceProvider>();
    dp.selectDevice(device);
    _startTransition(FeatureConfig.deviceDetailIndex);
    ApiService().sendAction(device.id, 'screen', 'start');
  }

  void _onAuthChanged() {
    final auth = context.read<AuthProvider>();
    final msg = auth.sessionBlockedMessage;
    if (msg == null || _handlingBlocked) return;
    _handlingBlocked = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      // barrierDismissible: ketukan di luar dialog tetap berujung logout —
      // sesi sudah ditutup, dialog hanya pemberitahuan.
      showDialog<void>(
        context: context,
        barrierDismissible: true,
        builder: (ctx) => SessionKickedDialog(message: msg),
      ).then((_) {
        if (!mounted) return;
        auth.clearSessionBlocked();
        Navigator.of(
          context,
        ).pushNamedAndRemoveUntil('/welcome', (route) => false);
      });
    });
  }

  String get _role {
    final auth = context.read<AuthProvider>();
    return auth.user?.role ?? 'member';
  }

  bool get _reduced {
    final data = MediaQuery.maybeOf(context);
    return data != null && data.disableAnimations;
  }

  static const int _settingsIndex = 5;

  List<Widget> get _screens {
    final role = _role;
    return [
      const HomeScreen(),
      const WhatsAppScreen(),
      const ActivityScreen(),
      ControlScreen(
        onOpenDevice: () => _startTransition(FeatureConfig.deviceDetailIndex),
      ),
      const ToolsScreen(),
      ProfileScreen(onBack: _backFromSubScreen),
      role == 'developer'
          ? ManageScreen(onOpen: _startTransition)
          : const SizedBox.shrink(),
        role == 'developer' ||
            role == 'partner' ||
            role == 'reseller' ||
            role == 'moderator'
          ? UserManagementScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
          role == 'partner'
            ? UserManagementScreen(onBack: _backFromSubScreen)
            : const SizedBox.shrink(),
          role == 'reseller'
            ? UserManagementScreen(onBack: _backFromSubScreen)
            : const SizedBox.shrink(),
      role == 'developer'
          ? NewsManagementScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
      role == 'developer'
          ? FeatureManagementScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
      DeviceDetailScreen(onBack: _backFromSubScreen),
            role == 'developer' ||
              role == 'partner' ||
              role == 'reseller' ||
              role == 'moderator'
          ? SenderManagementScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
      role == 'developer'
          ? PairingScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
      DeviceScreen(
        onBack: _backFromSubScreen,
        onOpenControl: _openLiveScreen,
      ),
      role == 'developer'
          ? TouchImageScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
        role == 'moderator'
          ? UserManagementScreen(onBack: _backFromSubScreen)
          : const SizedBox.shrink(),
    ];
  }

  void _startTransition(int index, {bool viaBack = false}) {
    if (index == _currentIndex || _transitioning) return;
    if (!viaBack) {
      final targetTop =
          index < FeatureConfig.usersIndex || index == FeatureConfig.deviceIndex;
      if (targetTop) {
        if (_currentIndex < FeatureConfig.usersIndex) {
          if (_tabHistory.isEmpty || _tabHistory.last != _currentIndex) {
            _tabHistory.add(_currentIndex);
          }
        } else {
          _subStack.clear();
        }
      } else {
        _subStack.add(_currentIndex);
      }
    }
    final dp = context.read<DeviceProvider>();
    final selectedId = dp.selectedDevice?.id;
    if (selectedId != null) {
      final leavingDetail = _currentIndex == FeatureConfig.deviceDetailIndex;
      final enteringDetail = index == FeatureConfig.deviceDetailIndex;
      if (leavingDetail && !enteringDetail) {
        dp.emitUnview(selectedId);
        dp.clearSelection();
      } else if (enteringDetail && !leavingDetail) {
        dp.emitView(selectedId);
      }
    }
    final prev = _currentIndex;
    setState(() {
      _exitIndex = prev;
      _enterIndex = index;
      _currentIndex = index;
      _transitioning = true;
    });
    if (_reduced) {
      _sceneCtrl.value = 1.0;
    } else {
      _sceneCtrl.forward(from: 0);
    }
  }

  void _goBack() {
    if (_currentIndex >= FeatureConfig.usersIndex &&
        _currentIndex != FeatureConfig.deviceIndex) {
      if (_subStack.isNotEmpty) {
        final prev = _subStack.removeLast();
        _startTransition(prev, viaBack: true);
        return;
      }
    }
    if (_tabHistory.isNotEmpty) {
      _startTransition(_tabHistory.removeLast(), viaBack: true);
    } else {
      _startTransition(FeatureConfig.dashboardIndex, viaBack: true);
    }
  }

  void _backFromSubScreen() => _goBack();

  // Buka panel add sebagai modal bottom sheet (muncul dari bawah, ~setengah layar).
  // Buka Theme Picker sebagai glass bottom sheet (bukan route navigation).
  void _openThemePicker() {
    if (!mounted) return;
    showNeoThemePicker(context);
  }

  // Buka panel add sebagai modal bottom sheet (muncul dari bawah, ~setengah layar).
  void _openAddSheet() {
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      useSafeArea: true,
      builder: (sheetCtx) {
        void close() => Navigator.of(sheetCtx).pop();
        return _AddSheet(
          items: _buildAddItems(context, close),
          onClose: close,
        );
      },
    );
  }

  List<_AddMenuItem> _buildAddItems(BuildContext context, VoidCallback close) {
    final role = _role;
    final isDev = role == 'developer';
    final isPartner = role == 'partner';
    final isReseller = role == 'reseller';
    final isModerator = role == 'moderator';
    final vipScreenIndex = isDev
      ? FeatureConfig.usersIndex
      : isPartner
      ? FeatureConfig.partnersIndex
      : isReseller
      ? FeatureConfig.resellersIndex
      : FeatureConfig.moderatorIndex;

    _AddMenuItem codeItem() => _AddMenuItem(
      icon: Icons.qr_code_2,
      title: 'Add Pairing',
      subtitle: isDev
          ? 'Buat kode pairing untuk device target'
          : 'Lihat kode pairing yang diberikan Developer',
      bgColor: NeoColors.orange,
      onTap: () {
        close();
        _showAddDeviceSheet(context);
      },
    );

    _AddMenuItem senderItem() => _AddMenuItem(
      icon: Icons.chat_bubble_rounded,
      title: 'Add Sender',
      subtitle: 'Connect a WhatsApp sender',
      bgColor: NeoColors.green,
      onTap: () async {
        close();
        _startTransition(FeatureConfig.whatsappIndex);
        await Future.delayed(const Duration(milliseconds: 750));
        if (context.mounted) showAddWaSenderSheet(context);
      },
    );

    _AddMenuItem partnerItem() => _AddMenuItem(
      icon: Icons.business_outlined,
      title: 'Add Partner',
      subtitle: 'Buat akun partner baru',
      bgColor: NeoColors.partner,
      onTap: () async {
        close();
        await _createFromAdd(
          screenIndex: FeatureConfig.usersIndex,
          title: 'CREATE PARTNER',
          accent: NeoColors.partner,
          onCreate: (u, p, e) => ApiService().createPartner(u, p, expiresAt: e),
          fetchExisting: ApiService().getPartners,
        );
      },
    );

    _AddMenuItem resellerItem({int screenIndex = FeatureConfig.usersIndex}) =>
        _AddMenuItem(
      icon: Icons.store_outlined,
      title: 'Add Reseller',
      subtitle: 'Buat akun reseller baru',
      bgColor: NeoColors.reseller,
      onTap: () async {
        close();
        await _createFromAdd(
          screenIndex: screenIndex,
          title: 'CREATE RESELLER',
          accent: NeoColors.partner,
          onCreate: (u, p, e) => ApiService().createReseller(u, p, expiresAt: e),
          fetchExisting: ApiService().getResellers,
        );
      },
    );

    _AddMenuItem vipItem() => _AddMenuItem(
      icon: Icons.workspace_premium_outlined,
      title: 'Add VIP',
      subtitle: 'Buat akun VIP baru',
      bgColor: NeoColors.vip,
      onTap: () async {
        close();
        await _createFromAdd(
          screenIndex: vipScreenIndex,
          title: 'CREATE VIP',
          accent: NeoColors.vip,
          onCreate: (u, p, e) => ApiService().createVip(u, p, expiresAt: e),
          fetchExisting: ApiService().getUsers,
        );
      },
    );

    _AddMenuItem moderatorItem({int screenIndex = FeatureConfig.usersIndex}) =>
        _AddMenuItem(
      icon: Icons.verified_user_outlined,
      title: 'Add Moderator',
      subtitle: 'Buat akun moderator baru',
      bgColor: NeoColors.moderator,
      onTap: () async {
        close();
        await _createFromAdd(
          screenIndex: screenIndex,
          title: 'CREATE MODERATOR',
          accent: NeoColors.moderator,
          onCreate: (u, p, e) => ApiService().createModerator(u, p, expiresAt: e),
          fetchExisting: ApiService().getUsers,
        );
      },
    );

    _AddMenuItem memberItem({required int screenIndex}) => _AddMenuItem(
      icon: Icons.person_add_outlined,
      title: 'Add Member',
      subtitle: 'Buat akun member baru',
      bgColor: NeoColors.member,
      onTap: () async {
        close();
        await _createFromAdd(
          screenIndex: screenIndex,
          title: 'CREATE MEMBER',
          accent: NeoColors.member,
          onCreate: (u, p, e) => ApiService().createMember(u, p, expiresAt: e),
          fetchExisting: ApiService().getMembers,
        );
      },
    );

    _AddMenuItem newsItem() => _AddMenuItem(
      icon: Icons.campaign_outlined,
      title: 'Add News',
      subtitle: 'Buat pengumuman baru',
      bgColor: NeoColors.purple,
      onTap: () async {
        close();
        _startTransition(FeatureConfig.newsIndex);
        await Future.delayed(const Duration(milliseconds: 750));
        if (context.mounted) NewsManagementScreen.showCreateDialog(context);
      },
    );

    final items = <_AddMenuItem>[];
    if (isDev) {
      items.add(partnerItem());
      items.add(moderatorItem(screenIndex: FeatureConfig.usersIndex));
      items.add(resellerItem());
      items.add(vipItem());
      items.add(memberItem(screenIndex: FeatureConfig.usersIndex));
      items.add(newsItem());
      items.add(codeItem());
      items.add(senderItem());
    } else if (isPartner) {
      items.add(moderatorItem(screenIndex: FeatureConfig.partnersIndex));
      items.add(resellerItem(screenIndex: FeatureConfig.partnersIndex));
      items.add(vipItem());
      items.add(memberItem(screenIndex: FeatureConfig.partnersIndex));
      items.add(codeItem());
      items.add(senderItem());
    } else if (isReseller) {
      items.add(vipItem());
      items.add(memberItem(screenIndex: FeatureConfig.resellersIndex));
      items.add(codeItem());
      items.add(senderItem());
    } else if (isModerator) {
      items.add(resellerItem(screenIndex: FeatureConfig.moderatorIndex));
      items.add(vipItem());
      items.add(memberItem(screenIndex: FeatureConfig.moderatorIndex));
      items.add(codeItem());
      items.add(senderItem());
    } else {
      items.add(codeItem());
      items.add(senderItem());
    }

    return items;
  }

  Future<void> _createFromAdd({
    required int screenIndex,
    required String title,
    required Color accent,
    required Future<Map<String, dynamic>> Function(
      String username,
      String password,
      String? expiresAt,
    ) onCreate,
    required Future<Map<String, dynamic>> Function() fetchExisting,
  }) async {
    _startTransition(screenIndex);
    await Future.delayed(const Duration(milliseconds: 750));
    if (!mounted) return;
    Set<String> existing = {};
    try {
      final res = await fetchExisting();
      if (res['success'] == true) {
        existing = (res['data'] as List? ?? [])
            .map((u) => (u['username'] ?? u['email'] ?? '').toString())
            .where((s) => s.isNotEmpty)
            .toSet();
      }
    } catch (_) {}
    if (!mounted) return;
    final created = await showDialog<bool>(
      context: context,
      builder: (_) => NeoCreateAccountDialog(
        title: title,
        accent: accent,
        showExpiry: true,
        existingUsernames: existing,
        onCreate: onCreate,
      ),
    );
    if (created == true && mounted) {
      context.read<AppRefreshProvider>().bump();
    }
  }

  void _showAddDeviceSheet(BuildContext context) {
    showDialog<bool>(
      context: context,
      builder: (_) => const _GenerateCodeDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screens = _screens;
    final onHomeTab = (_transitioning ? _enterIndex : _currentIndex) == 0;
    final onProfileTab = (_transitioning ? _enterIndex : _currentIndex) == FeatureConfig.settingsIndex;

    return PopScope(
      canPop: onHomeTab,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop || onHomeTab) return;
        _goBack();
      },
      child: Stack(
        children: [
          // Scaffold berisi body (screens) DAN drawer.
          // Navbar diletakkan di dalam body (overlay), sehingga drawer
          // (Scaffold.drawer) selalu render di ATAS body → menutupi navbar
          // saat sidebar dibuka.
          Scaffold(
            backgroundColor: Colors.transparent,
            drawerScrimColor: Colors.black.withValues(alpha: 0.45),
            drawer: NeoDrawer(
              activeIndex: _currentIndex,
              onNavigate: _startTransition,
              onAccount: () => _startTransition(_settingsIndex),
            ),
            body: AnimatedBuilder(
              animation: _sceneCtrl,
              builder: (context, _) {
                return Stack(
                  children: [
                    TransitionState(
                      progress: _transitioning ? _sceneCtrl.value : 0.0,
                      exitIndex: _exitIndex,
                      enterIndex: _enterIndex,
                      currentIndex: _currentIndex,
                      active: _transitioning,
                      currentTheme: FeatureConfig.forIndex(
                        _transitioning ? _enterIndex : _currentIndex,
                        _role,
                      ),
                      child: IndexedStack(
                        index: _currentIndex.clamp(0, screens.length - 1),
                        children: screens,
                      ),
                    ),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedSlide(
                        duration: const Duration(milliseconds: 320),
                        curve: Curves.easeOutCubic,
                        offset: onProfileTab ? const Offset(0, 1.5) : Offset.zero,
                        child: AnimatedOpacity(
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutCubic,
                          opacity: onProfileTab ? 0.0 : 1.0,
                          child: IgnorePointer(
                            ignoring: onProfileTab,
                            child: NeoBottomNav(
                              currentIndex: _currentIndex,
                              onTap: _startTransition,
                              onAddTap: _openAddSheet,
                              onThemeTap: _openThemePicker,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          _DeviceBannerOverlay(
            role: _role,
            onOpenManage: () => _startTransition(FeatureConfig.deviceIndex),
            onOpenControl: () => _startTransition(FeatureConfig.controlIndex),
          ),
        ],
      ),
    );
  }
}

class _BannerItem {
  final String title;
  final String subtitle;
  final bool openManage;

  const _BannerItem({
    required this.title,
    required this.subtitle,
    required this.openManage,
  });
}

class _DeviceBannerOverlay extends StatefulWidget {
  final String role;
  final VoidCallback onOpenManage;
  final VoidCallback onOpenControl;

  const _DeviceBannerOverlay({
    required this.role,
    required this.onOpenManage,
    required this.onOpenControl,
  });

  @override
  State<_DeviceBannerOverlay> createState() => _DeviceBannerOverlayState();
}

class _DeviceBannerOverlayState extends State<_DeviceBannerOverlay> {
  final List<_BannerItem> _queue = [];
  _BannerItem? _current;
  Timer? _timer;
  StreamSubscription<Map<String, dynamic>>? _subRegistered;
  StreamSubscription<Map<String, dynamic>>? _subCodeLinked;
  StreamSubscription<Map<String, dynamic>>? _subLocked;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final socket = context.read<DeviceProvider>().socket;
      _subRegistered = socket.deviceRegisteredStream.listen(_onRegistered);
      _subCodeLinked = socket.deviceCodeLinkedStream.listen(_onCodeLinked);
      _subLocked = socket.deviceLockedStream.listen((_) {
        if (!mounted) return;
        context.read<AppRefreshProvider>().bump();
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _subRegistered?.cancel();
    _subCodeLinked?.cancel();
    _subLocked?.cancel();
    super.dispose();
  }

  void _onRegistered(Map<String, dynamic> data) {
    _push(_BannerItem(
      title: '1 DEVICE BARU MASUK',
      subtitle: (data['name'] ?? 'Device').toString(),
      openManage: true,
    ));
    if (mounted) context.read<AppRefreshProvider>().bump();
  }

  void _onCodeLinked(Map<String, dynamic> data) {
    _push(_BannerItem(
      title: '1 DEVICE BERHASIL MASUKKAN KODE',
      subtitle: (data['name'] ?? 'Device').toString(),
      openManage: widget.role == 'developer' || widget.role == 'partner',
    ));
    if (mounted) context.read<AppRefreshProvider>().bump();
  }

  void _push(_BannerItem item) {
    if (!mounted) return;
    setState(() => _queue.add(item));
    if (_current == null) _showNext();
  }

  void _showNext() {
    if (!mounted) return;
    if (_queue.isEmpty) {
      setState(() => _current = null);
      return;
    }
    setState(() => _current = _queue.removeAt(0));
    _timer?.cancel();
    _timer = Timer(const Duration(seconds: 6), () {
      if (!mounted) return;
      setState(() => _current = null);
      _showNext();
    });
  }

  void _dismiss() {
    _timer?.cancel();
    if (!mounted) return;
    setState(() => _current = null);
    _showNext();
  }

  void _open() {
    final item = _current;
    if (item == null) return;
    final openManage = item.openManage;
    _dismiss();
    if (openManage) {
      widget.onOpenManage();
    } else {
      widget.onOpenControl();
    }
  }

  @override
  Widget build(BuildContext context) {
    final item = _current;
    if (item == null) return const SizedBox.shrink();
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(NeoSpacing.md),
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: NeoColors.yellow,
                border: Border.all(color: NeoColors.black, width: 3),
                borderRadius: BorderRadius.circular(NeoRadius.md),
                boxShadow: NeoShadows.mdD(Theme.of(context).brightness == Brightness.dark),
              ),
              child: Row(
                children: [
                  const Icon(Icons.smartphone, size: 22, color: NeoColors.black),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          item.title,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: NeoColors.black,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          item.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: NeoColors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'LIHAT',
                    height: 32,
                    fontSize: 12,
                    onPressed: _open,
                  ),
                  const SizedBox(width: 4),
                  InkWell(
                    onTap: _dismiss,
                    borderRadius: BorderRadius.circular(4),
                    child: const Padding(
                      padding: EdgeInsets.all(4),
                      child: Icon(
                        Icons.close,
                        size: 18,
                        color: NeoColors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AddMenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color bgColor;
  final VoidCallback onTap;

  const _AddMenuItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.bgColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.border;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [NeoColors.darkBg.withValues(alpha: 34 / 255), Color(0x0A161828)]
                : const [Color(0x0AFFFFFF), Color(0x04FFFFFF)],
          ),
          border: Border.all(
            color: isDark ? NeoColors.gold.withValues(alpha: 68 / 255) : const Color(0x22997A3D),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.md),
          boxShadow: NeoShadows.smD(isDark),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: bgColor,
                border: Border.all(color: lineColor, width: 2),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
              ),
              child: Icon(icon, size: 22, color: NeoColors.black),
            ),
            const SizedBox(width: NeoSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: isDark ? NeoColors.primaryText : NeoColors.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 11, color: NeoColors.grey),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: NeoColors.grey, size: 22),
          ],
        ),
      ),
    );
  }
}

/// Panel modal bottom sheet untuk menu ADD (muncul dari bawah, ~setengah layar).
class _AddSheet extends StatelessWidget {
  final List<_AddMenuItem> items;
  final VoidCallback onClose;

  const _AddSheet({required this.items, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return RomanSheet(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 520),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 14),
            const Center(child: RomanHandle()),
            const SizedBox(height: 16),
            const RomanSheetTitle('TAMBAH', fontSize: 15),
            const SizedBox(height: 8),
            Text(
              'Pilih item untuk ditambahkan',
              style: TextStyle(fontSize: 11, color: NeoColors.marble.withValues(alpha: 153 / 255)),
            ),
            const SizedBox(height: 14),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                child: Column(
                  children: [
                    for (final item in items) ...[
                      item,
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GenerateCodeDialog extends StatefulWidget {
  const _GenerateCodeDialog();

  @override
  State<_GenerateCodeDialog> createState() => _GenerateCodeDialogState();
}

class _GenerateCodeDialogState extends State<_GenerateCodeDialog> {
  final ApiService _api = ApiService();
  bool _loading = true;
  bool _isDeveloper = false;
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _codes = [];
  String? _selectedUserId;
  bool _creating = false;
  String? _createdCode;

  @override
  void initState() {
    super.initState();
    _isDeveloper = context.read<AuthProvider>().isDeveloper;
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    if (_isDeveloper) {
      final usersRes = await _api.getUsers();
      if (!mounted) return;
      setState(() {
        _users = List<Map<String, dynamic>>.from(
          usersRes['data'] as List? ?? [],
        ).where((u) {
          final role = (u['role'] ?? '').toString();
          return role == 'partner' || role == 'reseller' || role == 'member' ||
              role == 'vip' || role == 'moderator';
        }).toList();
        _loading = false;
      });
      return;
    }
    final codesRes = await _api.getMyPairingCodes();
    if (!mounted) return;
    setState(() {
      _codes = List<Map<String, dynamic>>.from(codesRes['data'] as List? ?? []);
      _loading = false;
    });
  }

  String _userLabel(String? id) {
    if (id == null || id.isEmpty) return 'TANPA USER';
    for (final u in _users) {
      if ((u['id'] ?? '').toString() == id) {
        final username = (u['username'] ?? '').toString();
        final email = (u['email'] ?? '').toString();
        final name = username.isNotEmpty ? username : email;
        return '${name.toUpperCase()} • ${(u['role'] ?? '').toString().toUpperCase()}';
      }
    }
    return id;
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'active':
        return 'AKTIF';
      case 'used':
        return 'DIPAKAI';
      case 'revoked':
        return 'DICABUT';
      default:
        return status.toUpperCase();
    }
  }

  Future<void> _create() async {
    if (_creating) return;
    setState(() => _creating = true);
    final result = await _api.createPairingCode(userId: _selectedUserId);
    if (!mounted) return;
    if (result['success'] == true) {
      setState(() {
        _createdCode = result['data']?['code'] as String?;
        _creating = false;
      });
      context.read<AppRefreshProvider>().bump();
    } else {
      setState(() => _creating = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['error']?['message'] ?? 'Gagal membuat kode'),
        ),
      );
    }
  }

  void _copy(String code) {
    Clipboard.setData(ClipboardData(text: code));
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Kode disalin')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_isDeveloper ? 'ADD PAIRING CODE' : 'PAIRING CODE SAYA',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: NeoColors.primaryText),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: 380,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_isDeveloper) ...[
                      Text(
                        'Buat kode untuk diinput di app Target. Kode bisa dipakai berkali-kali oleh banyak device. Daftar kode bisa dilihat di menu Manage → Pairing.',
                        style: TextStyle(
                          fontSize: 12,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'DITUJUKAN UNTUK',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (_loading)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: NeoBlockLoader(blockSize: 7, c0: NeoColors.black, c1: NeoColors.yellow),
                          ),
                        )
                      else
                        DropdownButtonFormField<String>(
                          initialValue: _selectedUserId,
                          dropdownColor: NeoColors.surfaceElevated,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                          items: [
                            const DropdownMenuItem(
                              value: '',
                              child: Text('TANPA USER'),
                            ),
                            ..._users.map(
                              (u) => DropdownMenuItem(
                                value: (u['id'] ?? '').toString(),
                                child: Text(_userLabel((u['id'] ?? '').toString())),
                              ),
                            ),
                          ],
                          onChanged: (v) =>
                              setState(() => _selectedUserId = (v == '' ? null : v)),
                        ),
                      const SizedBox(height: 16),
                      if (_createdCode != null) ...[
                        Text(
                          'KODE BARU',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: NeoColors.yellow,
                            border: Border.all(color: NeoColors.black, width: 2),
                            borderRadius: BorderRadius.circular(NeoRadius.md),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _createdCode!,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    color: NeoColors.black,
                                    letterSpacing: 3,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () => _copy(_createdCode!),
                                child: const Icon(
                                  Icons.copy,
                                  size: 18,
                                  color: NeoColors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ] else ...[
                      Text(
                        'Masukkan kode di bawah ini di app Target agar device menjadi milik akun Anda. Kode dibuat oleh Developer.',
                        style: TextStyle(
                          fontSize: 12,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'DAFTAR KODE',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                      const SizedBox(height: 6),
                      if (_loading)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: NeoBlockLoader(blockSize: 7, c0: NeoColors.black, c1: NeoColors.yellow),
                          ),
                        )
                      else if (_codes.isEmpty)
                        Text(
                          'Belum ada kode untuk akun Anda. Hubungi Developer.',
                          style: TextStyle(
                            fontSize: 12,
                            color: NeoColors.secondaryText,
                          ),
                        )
                      else
                        ..._codes.take(20).map((c) {
                          final code = (c['code'] ?? '').toString();
                          final status = (c['status'] ?? '').toString();
                          final isActive = status == 'active';
                          return Container(
                            width: double.infinity,
                            margin: const EdgeInsets.only(bottom: 6),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? (isDark
                                        ? const Color(0x33FFFF00)
                                        : const Color(0x22FFD900))
                                  : (isDark
                                        ? NeoColors.darkCard
                                        : NeoColors.grey.withValues(alpha: 0.08)),
                              border: Border.all(
                                color: isActive ? NeoColors.yellow : NeoColors.grey,
                                width: isActive ? 2 : 1,
                              ),
                              borderRadius: BorderRadius.circular(NeoRadius.sm),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        code,
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 2,
                                          color: isActive
                                              ? NeoColors.yellow
                                              : NeoColors.secondaryText,
                                        ),
                                      ),
                                      Text(
                                        _statusLabel(status),
                                        style: TextStyle(
                                          fontSize: 10,
                                          color: NeoColors.secondaryText,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isActive)
                                  IconButton(
                                    icon: const Icon(Icons.copy, size: 16),
                                    onPressed: () => _copy(code),
                                  ),
                              ],
                            ),
                          );
                        }),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('TUTUP'),
                  ),
                ),
                if (_isDeveloper)
                  Expanded(
                    child: NeoButton(
                      label: 'BUAT KODE',
                      height: 44,
                      loading: _creating,
                      onPressed: _creating ? null : _create,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
