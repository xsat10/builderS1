import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

// ─── 🎯 ROLE SYSTEM BARU (TANPA LEVEL) ──────────────────────────────────────
const List<String> ROLE_HIERARCHY = [
  'developers',    // Tertinggi
  'ceo',
  'owner',
  'admin',
  'tangan_kanan',
  'vip',
  'reseller',
  'full_up',
  'member_perbulan',
  'member_perminggu',
  'member_perhari'  // Terendah
];

// Role yang bisa membuat akun lain (CREATE) - TURUN TEMURUN
const Map<String, List<String>> CAN_CREATE_ROLES = {
  'developers': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'ceo': ['owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'owner': ['admin', 'tangan_kanan', 'vip', 'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'admin': ['tangan_kanan', 'vip', 'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'tangan_kanan': ['vip', 'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'vip': [], // VIP tidak bisa create
  'reseller': ['full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'],
  'full_up': [],
  'member_perbulan': [],
  'member_perminggu': [],
  'member_perhari': []
};

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
bool canCreateRole(String creatorRole, String targetRole) {
  final allowed = CAN_CREATE_ROLES[creatorRole.toLowerCase()] ?? [];
  return allowed.contains(targetRole.toLowerCase());
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'DEVELOPERS';
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

String getRoleDuration(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'Permanen';
    case 'ceo': return 'Permanen';
    case 'owner': return 'Permanen';
    case 'admin': return 'Permanen';
    case 'tangan_kanan': return 'Permanen';
    case 'vip': return 'Permanen';
    case 'reseller': return 'Permanen';
    case 'full_up': return 'Permanen';
    case 'member_perbulan': return '30 Hari';
    case 'member_perminggu': return '7 Hari';
    case 'member_perhari': return '1 Hari';
    default: return '-';
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return const Color(0xFFFF00FF);
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF1744);
    case 'admin': return const Color(0xFFF59E0B);
    case 'tangan_kanan': return const Color(0xFF8B5CF6);
    case 'vip': return const Color(0xFFEC4899);
    case 'reseller': return const Color(0xFF22C55E);
    case 'full_up': return const Color(0xFF10B981);
    case 'member_perbulan': return const Color(0xFF3B82F6);
    case 'member_perminggu': return const Color(0xFFF97316);
    case 'member_perhari': return const Color(0xFF6B7280);
    default: return Colors.white;
  }
}

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  // ─── ROLE OPTIONS UNTUK RESELLER ──────────────────────────────────────────
  // Reseller hanya bisa membuat 4 role ini
  final List<String> RESELLER_ROLES = [
    'full_up',
    'member_perbulan',
    'member_perminggu',
    'member_perhari'
  ];

  String selectedRole = 'member_perhari';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();

  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'full_up';
  bool isLoading = false;

  // ─── TEMA WARNA CYAN ────────────────────────────────────────────────────────
  final Color bgDark = const Color(0xFF0B1A1A);
  final Color primaryCyan = const Color(0xFF00ACC1);
  final Color accentCyan = const Color(0xFF18FFFF);
  final Color primaryWhite = Colors.white;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  // ─── API ──────────────────────────────────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('https://paultzy.pteroqhost.web.id5015/listUsers?key=${widget.keyToken}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  // ─── CEK IZIN CREATE RESELLER ─────────────────────────────────────────────
  bool _canCreateRole(String targetRole) {
    return RESELLER_ROLES.contains(targetRole);
  }

  // ─── CREATE ACCOUNT ──────────────────────────────────────────────────────
  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final dayInt = int.tryParse(d);
    if (dayInt == null || dayInt <= 0) {
      _alert("Peringatan", "Durasi harus berupa angka positif.");
      return;
    }

    // Reseller hanya bisa membuat maksimal 30 hari
    if (dayInt > 30) {
      _alert("Peringatan", "Reseller hanya bisa membuat akun maksimal 30 hari.");
      return;
    }

    // 🔥 Role dari DROPDOWN
    final targetRole = newUserRole;

    // CEK IZIN: Reseller hanya bisa buat 4 role
    if (!_canCreateRole(targetRole)) {
      _alert("Perhatian", 
          "RESELLER hanya bisa membuat:\n"
          "• FULL UP\n"
          "• MEMBER BULANAN\n"
          "• MEMBER MINGGUAN\n"
          "• MEMBER HARIAN",
          );
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
         https://paultzy.pteroqhost.web.id5015/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d&role=$targetRole"));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        final roleDisplay = getRoleDisplay(targetRole);
        _alert("Sukses", "✅ Akun berhasil dibuat sebagai $roleDisplay!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'full_up';
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) {
          msg += " (Max 30 hari untuk Reseller)";
        }
        _alert("Gagal", "❌ $msg");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  // ─── EDIT USER ────────────────────────────────────────────────────────────
  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final dayInt = int.tryParse(d);
    if (dayInt == null || dayInt <= 0) {
      _alert("Peringatan", "Durasi harus berupa angka positif.");
      return;
    }

    if (dayInt > 30) {
      _alert("Peringatan", "Reseller hanya bisa menambah maksimal 30 hari.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "https://paultzy.pteroqhost.web.id5015/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "✅ Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal mengubah durasi.'}");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  // ─── ALERT ────────────────────────────────────────────────────────────────
  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentCyan.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: accentCyan),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite)),
          ],
        ),
        content: Text(message, style: TextStyle(color: Colors.white70)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryCyan, accentCyan]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── KOMPONEN UI ──────────────────────────────────────────────────────────

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: Colors.white38),
          labelStyle: TextStyle(color: accentCyan),
          prefixIcon: Icon(icon, color: accentCyan),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentCyan, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 25),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryCyan.withOpacity(0.1),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: primaryCyan.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: accentCyan),
              ),
              SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  // 🔥 FIX: Hapus getRoleLevel, hanya pakai roleDisplay, duration, dan roleColor
  Widget _buildUserItem(Map user) {
    final roleDisplay = getRoleDisplay(user['role'] ?? 'member_perhari');
    final duration = getRoleDuration(user['role'] ?? 'member_perhari');
    final roleColor = getRoleColor(user['role'] ?? 'member_perhari');
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: accentCyan),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: primaryCyan.withOpacity(0.15),
                        border: Border.all(color: primaryCyan.withOpacity(0.2)),
                      ),
                      child: Text(
                        roleDisplay,
                        style: TextStyle(
                          color: accentCyan,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    SizedBox(width: 6),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white.withOpacity(0.05),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Text(
                        duration,
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 9,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2),
                Text(
                  "EXP: ${user['expiredDate']}",
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == page ? accentCyan : Colors.transparent,
            foregroundColor: currentPage == page ? primaryWhite : Colors.white54,
            padding: EdgeInsets.symmetric(horizontal: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide(color: borderGlass),
            ),
          ),
          child: Text("$page", style: TextStyle(fontSize: 12)),
        );
      }),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryCyan.withOpacity(0.1), bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // ─── HEADER ──────────────────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.storefront, color: accentCyan, size: 40),
                    SizedBox(width: 10),
                    Text(
                      "RESELLER",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 3,
                        shadows: [Shadow(color: primaryCyan.withOpacity(0.8), blurRadius: 10)],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: primaryCyan.withOpacity(0.08),
                    border: Border.all(color: primaryCyan.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.info_outline, color: accentCyan, size: 14),
                      SizedBox(width: 6),
                      Text(
                        "Max 30 Hari · 4 Role",
                        style: TextStyle(
                          color: accentCyan,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),

                // ─── INFO CARD ──────────────────────────────────────────────
                Container(
                  padding: EdgeInsets.all(16),
                  margin: EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: cardGlass,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderGlass),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.info_outline, color: accentCyan, size: 16),
                          SizedBox(width: 8),
                          Text(
                            "RESELLER PERMISSIONS",
                            style: TextStyle(
                              color: accentCyan,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        "✅ Bisa membuat (pilih dari dropdown):\n"
                        "   • FULL UP (Permanen)\n"
                        "   • MEMBER BULANAN (30 Hari)\n"
                        "   • MEMBER MINGGUAN (7 Hari)\n"
                        "   • MEMBER HARIAN (1 Hari)\n\n"
                        "⚠️ Maksimal durasi: 30 Hari\n"
                        "⚠️ Tidak bisa membuat role di atas Reseller",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),

                // ─── CREATE ACCOUNT ─────────────────────────────────────────
                _buildGlassCard(
                  title: "CREATE MEMBER",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(
                      label: "Username Baru",
                      controller: createUsernameController,
                      icon: FontAwesomeIcons.user,
                    ),
                    _buildInput(
                      label: "Password",
                      controller: createPasswordController,
                      icon: FontAwesomeIcons.lock,
                    ),
                    _buildInput(
                      label: "Durasi (Hari)",
                      controller: createDayController,
                      icon: FontAwesomeIcons.calendarDay,
                      type: TextInputType.number,
                      hint: "Maksimal 30 hari",
                    ),
                    // 🔥 DROPDOWN PILIH ROLE
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderGlass),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: newUserRole,
                          dropdownColor: bgDark,
                          style: TextStyle(color: primaryWhite),
                          items: RESELLER_ROLES.map((role) {
                            final display = getRoleDisplay(role);
                            final color = getRoleColor(role);
                            return DropdownMenuItem(
                              value: role,
                              child: Row(
                                children: [
                                  Container(
                                    width: 10,
                                    height: 10,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: color,
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  Text(display),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() => newUserRole = val);
                            }
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 4),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white.withOpacity(0.03),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.white38, size: 12),
                          SizedBox(width: 6),
                          Text(
                            "Pilih role yang ingin dibuat dari dropdown",
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 10,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [primaryCyan, accentCyan]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(color: primaryCyan.withOpacity(0.4), blurRadius: 10, offset: Offset(0, 4))
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _createAccount,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: isLoading
                            ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: primaryWhite))
                            : Text("CREATE ACCOUNT", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),

                // ─── EXTEND DURATION ────────────────────────────────────────
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: editUsernameController,
                      icon: FontAwesomeIcons.userEdit,
                      hint: "Username member yang ingin diperpanjang",
                    ),
                    _buildInput(
                      label: "Tambah Hari",
                      controller: editDayController,
                      icon: FontAwesomeIcons.calendarPlus,
                      type: TextInputType.number,
                      hint: "Maksimal 30 hari",
                    ),
                    SizedBox(height: 4),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white.withOpacity(0.03),
                        border: Border.all(color: Colors.white.withOpacity(0.05)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, color: Colors.white38, size: 12),
                          SizedBox(width: 6),
                          Text(
                            "Hanya bisa extend akun member yang kamu buat",
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 10,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [primaryCyan, accentCyan]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(color: primaryCyan.withOpacity(0.4), blurRadius: 10, offset: Offset(0, 4))
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: isLoading ? null : _editUser,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: isLoading
                            ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: primaryWhite))
                            : Text("ADD DAYS", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),

                // ─── MEMBER LIST ─────────────────────────────────────────────
                _buildGlassCard(
                  title: "MEMBER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderGlass),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: bgDark,
                          style: TextStyle(color: primaryWhite),
                          items: RESELLER_ROLES.map((role) {
                            final display = getRoleDisplay(role);
                            final color = getRoleColor(role);
                            return DropdownMenuItem(
                              value: role,
                              child: Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: color,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Text(display),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    if (filteredList.isEmpty && !isLoading)
                      Container(
                        padding: EdgeInsets.all(32),
                        child: Center(
                          child: Column(
                            children: [
                              Icon(Icons.people_outline, color: Colors.white38, size: 48),
                              SizedBox(height: 12),
                              Text(
                                "Belum ada member dengan role ini",
                                style: TextStyle(color: Colors.white54),
                              ),
                            ],
                          ),
                        ),
                      )
                    else if (isLoading)
                      Center(child: CircularProgressIndicator(color: accentCyan))
                    else
                      Column(
                        children: [
                          ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                          SizedBox(height: 20),
                          _buildPagination(),
                        ],
                      ),
                  ],
                ),

                // ─── FOOTER ──────────────────────────────────────────────────
                SizedBox(height: 20),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 1,
                        width: 30,
                        color: primaryCyan.withOpacity(0.3),
                      ),
                      SizedBox(width: 12),
                      Text(
                        "X-SPYDER RESELLER",
                        style: TextStyle(
                          color: primaryCyan.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                      SizedBox(width: 12),
                      Container(
                        height: 1,
                        width: 30,
                        color: primaryCyan.withOpacity(0.3),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}