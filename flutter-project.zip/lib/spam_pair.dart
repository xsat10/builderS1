// spam_pair.dart - FULLY FIXED VERSION
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';

// ─── 🎯 ROLE SYSTEM BARU ──────────────────────────────────────────────────────
const List<String> SPAM_ACCESS_ROLES = [
  'developers',  // TAMBAHKAN
  'ceo', 
  'owner', 
  'admin', 
  'tangan_kanan', 
  'vip'
];

const Map<String, int> ROLE_LEVEL = {
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1
};

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
bool _canAccessSpam(String role) {
  return SPAM_ACCESS_ROLES.contains(role.toLowerCase());
}

int getRoleLevel(String role) {
  return ROLE_LEVEL[role.toLowerCase()] ?? 0;
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

class SpamPairPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const SpamPairPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
  }) : super(key: key);

  @override
  State<SpamPairPage> createState() => _SpamPairPageState();
}

class _SpamPairPageState extends State<SpamPairPage> with TickerProviderStateMixin {
  
  // ─── STATIC CONST COLORS ────────────────────────────────────────────────────
  static const Color _darkBg = Color(0xFF080C1A);
  static const Color _cardBg = Color(0xFF0E1A2B);
  static const Color _cardElevated = Color(0xFF14233A);
  static const Color _primaryColor = Color(0xFF3B9EFF);
  static const Color _secondaryColor = Color(0xFF2DD36F);
  static const Color _accentColor = Color(0xFFC084FC);
  static const Color _telegramColor = Color(0xFF56AEF5);
  static const Color _whatsappColor = Color(0xFF2DD4BF);
  static const Color _textPrimary = Color(0xFFF0F6FF);
  static const Color _textSecondary = Color(0xFF8AB4D6);
  static const Color _textMuted = Color(0xFF4A6A8A);
  static const Color _borderColor = Color(0xFF1E3350);
  static const Color _successColor = Color(0xFF2DD36F);
  static const Color _warningColor = Color(0xFFFBBF24);
  static const Color _errorColor = Color(0xFFF87171);
  static const Color _infoColor = Color(0xFF3B9EFF);

  // ─── API URLs ──────────────────────────────────────────────────────────────
  static String get SAVE_API_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/telegram/save-api";
  static String get GET_APIS_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/telegram/apis";
  static String get DELETE_API_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/telegram/delete-api";
  static String get UPDATE_API_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/telegram/update-api";
  static String get SPAM_HISTORY_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/spam/history";
  static String get TELEGRAM_SPAM_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/telegram/spam-otp";
  static String get WHATSAPP_SPAM_URL => "http://pallmarketplace.ptdlpanel.my.id:11660/api/spam/whatsapp";
  
  // ─── State Variables ──────────────────────────────────────────────────────
  int _selectedMenu = 0;
  bool _isLoading = false;
  String _statusMessage = "";
  bool _statusSuccess = false;
  bool _isConnectionTested = false;
  
  final TextEditingController _waPhoneController = TextEditingController();
  final TextEditingController _waDelayController = TextEditingController(text: "1000");
  final TextEditingController _waCountController = TextEditingController(text: "3");
  
  final TextEditingController _telegramPhoneController = TextEditingController();
  final TextEditingController _telegramDelayController = TextEditingController(text: "3000");
  final TextEditingController _telegramCountController = TextEditingController(text: "2");
  
  final TextEditingController _apiIdController = TextEditingController();
  final TextEditingController _apiHashController = TextEditingController();
  final TextEditingController _apiAliasController = TextEditingController();
  
  String _resultCode = "";
  String _debugOtp = "";
  List<String> _allDebugOtps = [];
  
  List<Map<String, dynamic>> _telegramApis = [];
  int _selectedApiIndex = -1;
  
  List<Map<String, dynamic>> _spamHistory = [];

  // ─── Gradients ──────────────────────────────────────────────────────────────
  final LinearGradient _primaryGradient = const LinearGradient(
    colors: [Color(0xFF3B9EFF), Color(0xFFC084FC)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  final LinearGradient _successGradient = const LinearGradient(
    colors: [Color(0xFF2DD36F), Color(0xFF34D399)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  final LinearGradient _telegramGradient = const LinearGradient(
    colors: [Color(0xFF229ED9), Color(0xFF56AEF5)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  final LinearGradient _whatsappGradient = const LinearGradient(
    colors: [Color(0xFF25D366), Color(0xFF2DD4BF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  final LinearGradient _dangerGradient = const LinearGradient(
    colors: [Color(0xFFF87171), Color(0xFFEF4444)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ─── Animations ──────────────────────────────────────────────────────────────
  late AnimationController _pulseCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _glowCtrl;
  
  late Animation<double> _pulse;
  late Animation<double> _float;
  late Animation<double> _entrance;
  late Animation<double> _glow;

  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);
    
    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    
    _pulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    
    _float = Tween<double>(begin: -6, end: 6).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );
    
    _entrance = CurvedAnimation(
      parent: _entranceCtrl,
      curve: Curves.easeOutCubic,
    );
    
    _glow = Tween<double>(begin: 0.3, end: 0.7).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
    
    _initializeApp();
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _waPhoneController.dispose();
    _waDelayController.dispose();
    _waCountController.dispose();
    _telegramPhoneController.dispose();
    _telegramDelayController.dispose();
    _telegramCountController.dispose();
    _apiIdController.dispose();
    _apiHashController.dispose();
    _apiAliasController.dispose();
    _pulseCtrl.dispose();
    _floatCtrl.dispose();
    _entranceCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  void _initializeApp() {
    _testBackendConnection();
    _loadTelegramApis();
    _loadSpamHistory();
    
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted && !_isLoading) {
        _loadTelegramApis();
        _loadSpamHistory();
      }
    });
  }

  Future<void> _testBackendConnection() async {
    setState(() => _isLoading = true);
    _statusMessage = "🔄 Menguji koneksi ke backend...";
    
    try {
      final response = await http.get(
        Uri.parse("http://pallmarketplace.ptdlpanel.my.id:11660/health"),
        headers: _buildHeaders(),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        setState(() {
          _isConnectionTested = true;
          _statusSuccess = true;
          _statusMessage = "✅ Tersambung ke backend X-SPYDER";
        });
        _showSnackBar("✅ Tersambung ke backend X-SPYDER", _successColor);
      } else {
        throw Exception("Server merespons ${response.statusCode}");
      }
    } catch (e) {
      setState(() {
        _isConnectionTested = false;
        _statusSuccess = false;
        _statusMessage = "⚠️ Gagal terkoneksi: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal terkoneksi: ${e.toString().replaceAll('Exception: ', '')}", _warningColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadTelegramApis() async {
    try {
      final response = await http.get(
        Uri.parse("$GET_APIS_URL?username=${widget.username}&session_key=${widget.sessionKey}"),
        headers: _buildHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _telegramApis = List<Map<String, dynamic>>.from(data['apis'] ?? []);
            _selectedApiIndex = _telegramApis.isNotEmpty ? 0 : -1;
          });
        }
      }
    } catch (e) {
      print("Error loading APIs: $e");
    }
  }

  Future<void> _addTelegramApi() async {
    if (_apiIdController.text.isEmpty || _apiHashController.text.isEmpty) {
      _showSnackBar("API ID dan Hash harus diisi", _errorColor);
      return;
    }

    if (!RegExp(r'^\d+$').hasMatch(_apiIdController.text)) {
      _showSnackBar("API ID harus berupa angka", _errorColor);
      return;
    }

    setState(() {
      _isLoading = true;
      _statusMessage = "🔄 Menambahkan API Telegram...";
    });

    try {
      final payload = {
        "api_id": _apiIdController.text.trim(),
        "api_hash": _apiHashController.text.trim(),
        "alias": _apiAliasController.text.trim().isEmpty 
            ? "API-${_telegramApis.length + 1}" 
            : _apiAliasController.text.trim(),
        "username": widget.username,
        "session_key": widget.sessionKey,
      };

      final response = await http.post(
        Uri.parse(SAVE_API_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success'] == true) {
        setState(() {
          _statusSuccess = true;
          _statusMessage = "✅ API berhasil ditambahkan";
        });
        
        await _loadTelegramApis();
        
        _apiIdController.clear();
        _apiHashController.clear();
        _apiAliasController.clear();
        
        _showSnackBar("✅ API berhasil ditambahkan", _successColor);
        
        Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) {
            setState(() {
              _selectedMenu = 1;
            });
          }
        });
      } else {
        throw Exception(data['message'] ?? "Gagal menambahkan API");
      }
    } catch (e) {
      setState(() {
        _statusSuccess = false;
        _statusMessage = "❌ Gagal: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal: ${e.toString().replaceAll('Exception: ', '')}", _errorColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _removeTelegramApi(int index) async {
    if (index < 0 || index >= _telegramApis.length) return;

    final api = _telegramApis[index];
    final confirmed = await _showConfirmationDialog(
      title: "Hapus API",
      message: "Yakin menghapus API '${api['alias']}'?",
      confirmColor: _errorColor,
    );

    if (confirmed != true) return;

    setState(() {
      _isLoading = true;
      _statusMessage = "🔄 Menghapus API...";
    });

    try {
      final payload = {
        "api_id": api['id'],
        "username": widget.username,
        "session_key": widget.sessionKey,
      };

      final response = await http.delete(
        Uri.parse(DELETE_API_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success'] == true) {
        setState(() {
          _statusSuccess = true;
          _statusMessage = "✅ API berhasil dihapus";
        });
        
        await _loadTelegramApis();
        _showSnackBar("✅ API berhasil dihapus", _successColor);
      } else {
        throw Exception(data['message'] ?? "Gagal menghapus API");
      }
    } catch (e) {
      setState(() {
        _statusSuccess = false;
        _statusMessage = "❌ Gagal: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal: ${e.toString().replaceAll('Exception: ', '')}", _errorColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _toggleApiStatus(int index) async {
    if (index < 0 || index >= _telegramApis.length) return;

    final api = _telegramApis[index];
    final newStatus = !(api['is_active'] ?? true);

    setState(() {
      _isLoading = true;
      _statusMessage = "🔄 Memperbarui status API...";
    });

    try {
      final payload = {
        "api_id": api['id'],
        "is_active": newStatus,
        "username": widget.username,
        "session_key": widget.sessionKey,
      };

      final response = await http.put(
        Uri.parse(UPDATE_API_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success'] == true) {
        setState(() {
          _statusSuccess = true;
          _statusMessage = newStatus ? "✅ API diaktifkan" : "✅ API dinonaktifkan";
        });
        
        await _loadTelegramApis();
        _showSnackBar(newStatus ? "API diaktifkan" : "API dinonaktifkan", _successColor);
      } else {
        throw Exception(data['message'] ?? "Gagal memperbarui API");
      }
    } catch (e) {
      setState(() {
        _statusSuccess = false;
        _statusMessage = "❌ Gagal: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal: ${e.toString().replaceAll('Exception: ', '')}", _errorColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _executeWhatsAppSpam() async {
    if (_waPhoneController.text.isEmpty) {
      _showSnackBar("Masukkan nomor WhatsApp terlebih dahulu", _errorColor);
      return;
    }

    String phone = _formatPhoneNumber(_waPhoneController.text);
    
    if (!_isValidInternationalPhone(phone)) {
      _showSnackBar("Format nomor internasional tidak valid", _errorColor);
      return;
    }

    final count = int.tryParse(_waCountController.text) ?? 3;
    if (count <= 0 || count > 20) {
      _showSnackBar("Jumlah spam hanya 1-20", _errorColor);
      return;
    }

    final delay = int.tryParse(_waDelayController.text) ?? 1000;
    if (delay < 500 || delay > 10000) {
      _showSnackBar("Delay hanya 500-10000 ms", _errorColor);
      return;
    }

    setState(() {
      _isLoading = true;
      _statusMessage = "🚀 Memulai spam WhatsApp...";
      _statusSuccess = false;
      _resultCode = "";
      _allDebugOtps.clear();
    });

    try {
      final payload = {
        "phone": phone,
        "delay": delay,
        "count": count,
        "username": widget.username,
        "session_key": widget.sessionKey,
        "anti_flood": count <= 5,
      };

      final response = await http.post(
        Uri.parse(WHATSAPP_SPAM_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success'] == true) {
        setState(() {
          _resultCode = data['pairing_code'] ?? data['code'] ?? data['debug_code'] ?? "Tidak ada kode";
          _statusSuccess = true;
          _statusMessage = "✅ Berhasil! ${data['message'] ?? 'Kode pairing dikirim ke $phone'}";
          if (data['all_debug_otps'] != null) {
            _allDebugOtps = List<String>.from(data['all_debug_otps']);
          }
        });
        
        await _saveSpamHistory("WhatsApp", phone, _resultCode);
        _showSnackBar("Spam WhatsApp berhasil", _successColor);
      } else {
        throw Exception(data['message'] ?? "Gagal mengirim spam WhatsApp");
      }
    } catch (e) {
      setState(() {
        _statusSuccess = false;
        _statusMessage = "❌ Gagal: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal: ${e.toString().replaceAll('Exception: ', '')}", _errorColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _executeTelegramSpam() async {
    if (_telegramPhoneController.text.isEmpty) {
      _showSnackBar("Masukkan nomor Telegram terlebih dahulu", _errorColor);
      return;
    }

    if (_telegramApis.isEmpty) {
      _showSnackBar("Tambahkan API Telegram terlebih dahulu di tab API", _errorColor);
      return;
    }

    if (_selectedApiIndex < 0 || _selectedApiIndex >= _telegramApis.length) {
      _showSnackBar("Pilih API Telegram terlebih dahulu", _errorColor);
      return;
    }

    String phone = _formatPhoneNumber(_telegramPhoneController.text);
    
    if (!_isValidInternationalPhone(phone)) {
      _showSnackBar("Format nomor internasional tidak valid", _errorColor);
      return;
    }

    final count = int.tryParse(_telegramCountController.text) ?? 2;
    if (count <= 0 || count > 20) {
      _showSnackBar("Jumlah spam hanya 1-20", _errorColor);
      return;
    }

    final delay = int.tryParse(_telegramDelayController.text) ?? 3000;
    if (delay < 1000 || delay > 10000) {
      _showSnackBar("Delay hanya 1000-10000 ms", _errorColor);
      return;
    }

    setState(() {
      _isLoading = true;
      _statusMessage = "🚀 Memulai spam Telegram...";
      _statusSuccess = false;
      _debugOtp = "";
      _allDebugOtps.clear();
    });

    try {
      final selectedApi = _telegramApis[_selectedApiIndex];
      final payload = {
        "phone_number": phone,
        "api_id": selectedApi['id'],
        "delay": delay,
        "count": count,
        "username": widget.username,
        "session_key": widget.sessionKey,
        "anti_flood": true,
      };

      final response = await http.post(
        Uri.parse(TELEGRAM_SPAM_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 40));

      final data = jsonDecode(response.body);
      
      if (response.statusCode == 200 && data['success'] == true) {
        setState(() {
          _debugOtp = data['debug_otp'] ?? data['all_debug_otps']?.first ?? "Tidak ada OTP";
          _statusSuccess = true;
          _statusMessage = "✅ ${data['message'] ?? 'OTP berhasil dikirim'} (API: ${selectedApi['alias']})";
          if (data['all_debug_otps'] != null) {
            _allDebugOtps = List<String>.from(data['all_debug_otps']);
          }
        });
        
        await _saveSpamHistory("Telegram", phone, _debugOtp);
        _showSnackBar("Spam Telegram berhasil", _successColor);
      } else {
        throw Exception(data['message'] ?? "Gagal mengirim spam Telegram");
      }
    } catch (e) {
      setState(() {
        _statusSuccess = false;
        _statusMessage = "❌ Gagal: ${e.toString().replaceAll('Exception: ', '')}";
      });
      _showSnackBar("Gagal: ${e.toString().replaceAll('Exception: ', '')}", _errorColor);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadSpamHistory() async {
    try {
      final response = await http.get(
        Uri.parse("$SPAM_HISTORY_URL?username=${widget.username}&session_key=${widget.sessionKey}"),
        headers: _buildHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _spamHistory = List<Map<String, dynamic>>.from(data['history'] ?? []);
          });
        }
      }
    } catch (e) {
      print("Error loading history: $e");
    }
  }

  Future<void> _saveSpamHistory(String type, String phone, String code) async {
    try {
      final payload = {
        "type": type,
        "phone": phone,
        "code": code,
        "username": widget.username,
        "session_key": widget.sessionKey,
        "timestamp": DateTime.now().toIso8601String(),
      };

      await http.post(
        Uri.parse(SPAM_HISTORY_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 5));
      
      await _loadSpamHistory();
    } catch (e) {
      print("Error saving history: $e");
    }
  }

  Future<void> _clearHistory() async {
    final confirmed = await _showConfirmationDialog(
      title: "Hapus Riwayat",
      message: "Yakin menghapus semua riwayat spam?",
      confirmColor: _errorColor,
    );

    if (confirmed != true) return;

    try {
      final response = await http.delete(
        Uri.parse("$SPAM_HISTORY_URL/clear?username=${widget.username}&session_key=${widget.sessionKey}"),
        headers: _buildHeaders(),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _spamHistory.clear();
          });
          _showSnackBar("Riwayat berhasil dihapus", _successColor);
        }
      }
    } catch (e) {
      _showSnackBar("Gagal menghapus riwayat: $e", _errorColor);
    }
  }

  bool _isValidInternationalPhone(String phone) {
    if (phone.length < 12) return false;
    if (!phone.startsWith('+')) return false;
    final digits = phone.substring(1);
    if (!RegExp(r'^\d+$').hasMatch(digits)) return false;
    return true;
  }

  String _formatPhoneNumber(String input) {
    String digits = input.replaceAll(RegExp(r'[^\d]'), '');
    
    if (digits.isEmpty) return '';
    
    if (digits.startsWith('0')) {
      return '+62${digits.substring(1)}';
    }
    
    if (digits.startsWith('62')) {
      return '+$digits';
    }
    
    if (input.startsWith('+')) {
      return input;
    }
    
    if (!digits.startsWith('+')) {
      return '+$digits';
    }
    
    return digits;
  }

  Map<String, String> _buildHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${widget.sessionKey}',
      'X-X-SPYDER-User': widget.username,
      'X-RAUDEN-Timestamp': DateTime.now().millisecondsSinceEpoch.toString(),
    };
  }

  // ─── Neo UI Components ──────────────────────────────────────────────────────

  Widget _buildNeoConnectionStatus() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_cardBg, _cardElevated],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _isConnectionTested ? _successColor.withOpacity(0.3) : _warningColor.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: (_isConnectionTested ? _successColor : _warningColor).withOpacity(0.05),
              blurRadius: 30,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: _isConnectionTested ? _successGradient : LinearGradient(
                      colors: [_warningColor, _warningColor.withOpacity(0.7)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: (_isConnectionTested ? _successColor : _warningColor).withOpacity(0.3),
                        blurRadius: 12 * _pulse.value,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Icon(
                      _isConnectionTested ? Icons.check_circle : Icons.wifi_find_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Server Connection",
                        style: TextStyle(
                          color: _textPrimary,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.3,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _isConnectionTested ? "Connected to X-SPYDER backend" : "Connecting...",
                        style: TextStyle(
                          color: _textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: (_isConnectionTested ? _successColor : _warningColor).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: (_isConnectionTested ? _successColor : _warningColor).withOpacity(0.2),
                    ),
                  ),
                  child: Text(
                    _isConnectionTested ? "ONLINE" : "OFFLINE",
                    style: TextStyle(
                      color: _isConnectionTested ? _successColor : _warningColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _darkBg.withOpacity(0.3),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _borderColor.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  _buildNeoStatusChip("Server", _isConnectionTested ? "Online" : "Offline", 
                      _isConnectionTested ? _successColor : _errorColor),
                  const SizedBox(width: 8),
                  _buildNeoStatusChip("API", "${_telegramApis.length}", _telegramColor),
                  const SizedBox(width: 8),
                  _buildNeoStatusChip("History", "${_spamHistory.length}", _infoColor),
                  const SizedBox(width: 8),
                  _buildNeoStatusChip("Role", getRoleDisplay(widget.role), _primaryColor),
                  if (_canAccessSpam(widget.role))
                    const SizedBox(width: 8),
                  if (_canAccessSpam(widget.role))
                    _buildNeoStatusChip("Access", "✅", _successColor),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeoStatusChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 4,
            height: 4,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            "$label: $value",
            style: TextStyle(
              color: _textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNeoMenuSelector() {
    return Container(
      height: 72,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_cardBg, _cardElevated],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          _buildNeoMenuButton(
            index: 0,
            icon: FontAwesomeIcons.whatsapp,
            label: "WhatsApp",
            gradient: _whatsappGradient,
          ),
          Container(width: 1, height: 30, color: _borderColor.withOpacity(0.3)),
          _buildNeoMenuButton(
            index: 1,
            icon: Icons.telegram,
            label: "Telegram",
            gradient: _telegramGradient,
          ),
          Container(width: 1, height: 30, color: _borderColor.withOpacity(0.3)),
          _buildNeoMenuButton(
            index: 2,
            icon: Icons.api,
            label: "API",
            gradient: _primaryGradient,
          ),
        ],
      ),
    );
  }

  Widget _buildNeoMenuButton({
    required int index,
    required dynamic icon,
    required String label,
    required LinearGradient gradient,
  }) {
    final isSelected = _selectedMenu == index;
    
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedMenu = index),
        borderRadius: BorderRadius.circular(20),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOutCubic,
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            gradient: isSelected ? gradient : null,
            borderRadius: BorderRadius.circular(16),
            color: isSelected ? null : Colors.transparent,
            boxShadow: isSelected ? [
              BoxShadow(
                color: gradient.colors.first.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 4),
              ),
            ] : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : _textSecondary,
                size: 22,
              ),
              const SizedBox(height: 3),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : _textSecondary,
                  fontSize: 10,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  letterSpacing: isSelected ? 0.5 : 0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeoFormHeader({
    required dynamic icon,
    required String title,
    required String subtitle,
    required LinearGradient gradient,
  }) {
    return Row(
      children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: gradient.colors.first.withOpacity(0.3),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Center(
            child: Icon(icon, color: Colors.white, size: 24),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: _textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.3,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
        // Role Badge
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: _canAccessSpam(widget.role) ? _successColor.withOpacity(0.1) : _errorColor.withOpacity(0.1),
            border: Border.all(
              color: _canAccessSpam(widget.role) ? _successColor.withOpacity(0.3) : _errorColor.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Text(
            _canAccessSpam(widget.role) ? "✅ ACCESS" : "⛔ LOCKED",
            style: TextStyle(
              color: _canAccessSpam(widget.role) ? _successColor : _errorColor,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNeoPhoneInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    required Color color,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: _textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: _darkBg.withOpacity(0.3),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _borderColor.withOpacity(0.4)),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Center(
                  child: Text(
                    "+",
                    style: TextStyle(
                      color: color,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              Container(width: 1, height: 28, color: _borderColor.withOpacity(0.3)),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: TextField(
                    controller: controller,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9\+]')),
                    ],
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                    decoration: InputDecoration(
                      hintText: hint,
                      hintStyle: TextStyle(
                        color: _textMuted,
                        fontSize: 13,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "Format: +[kode negara][nomor]  Contoh: +62, +1, +44",
          style: TextStyle(
            color: _textMuted,
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  Widget _buildNeoNumberInput({
    required TextEditingController controller,
    required String label,
    required dynamic icon,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _darkBg.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderColor.withOpacity(0.4)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
              ),
              child: Center(
                child: Icon(icon, color: color, size: 18),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  TextField(
                    controller: controller,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      isDense: true,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeoActionButton({
    required String label,
    required Color color,
    required VoidCallback onPressed,
    required dynamic icon,
    required bool isLoading,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 0,
          shadowColor: color.withOpacity(0.3),
        ).copyWith(
          backgroundColor: WidgetStateProperty.all(color),
          overlayColor: WidgetStateProperty.all(Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isLoading)
              SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2.5,
                ),
              )
            else
              Icon(icon, size: 20),
            const SizedBox(width: 12),
            Text(
              isLoading ? "PROCESSING..." : label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeoInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required dynamic icon,
    bool isNumeric = false,
    bool obscureText = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: _textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: _darkBg.withOpacity(0.3),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _borderColor.withOpacity(0.4)),
          ),
          child: Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 16),
                child: Icon(icon, color: _textMuted, size: 20),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                  child: TextField(
                    controller: controller,
                    keyboardType: isNumeric ? TextInputType.number : TextInputType.text,
                    obscureText: obscureText,
                    inputFormatters: isNumeric
                        ? [FilteringTextInputFormatter.digitsOnly]
                        : null,
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    decoration: InputDecoration(
                      hintText: hint,
                      hintStyle: TextStyle(
                        color: _textMuted,
                        fontSize: 13,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildNeoResultCard() {
    if (_statusMessage.isEmpty) return const SizedBox();
    
    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: _statusSuccess 
              ? [_successColor.withOpacity(0.08), _successColor.withOpacity(0.02)]
              : [_errorColor.withOpacity(0.08), _errorColor.withOpacity(0.02)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _statusSuccess ? _successColor.withOpacity(0.3) : _errorColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _statusSuccess ? _successColor.withOpacity(0.1) : _errorColor.withOpacity(0.1),
                ),
                child: Icon(
                  _statusSuccess ? Icons.check_circle : Icons.error,
                  color: _statusSuccess ? _successColor : _errorColor,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _statusMessage,
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              IconButton(
                icon: Icon(Icons.close, size: 18),
                color: _textMuted,
                onPressed: () {
                  setState(() {
                    _statusMessage = "";
                  });
                },
              ),
            ],
          ),
          
          if ((_resultCode.isNotEmpty || _allDebugOtps.isNotEmpty) && _statusSuccess)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _selectedMenu == 0 ? "PAIRING CODE" : "OTP CODE",
                    style: TextStyle(
                      color: _textSecondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _darkBg.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _borderColor.withOpacity(0.3)),
                    ),
                    child: Column(
                      children: [
                        if (_resultCode.isNotEmpty)
                          Row(
                            children: [
                              Expanded(
                                child: SelectableText(
                                  _resultCode,
                                  style: TextStyle(
                                    color: _primaryColor,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'monospace',
                                    letterSpacing: 2,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.copy, size: 20),
                                color: _primaryColor,
                                onPressed: () {
                                  Clipboard.setData(ClipboardData(text: _resultCode)).then((_) {
                                    _showSnackBar("Copied to clipboard", _successColor);
                                  });
                                },
                              ),
                            ],
                          ),
                        if (_allDebugOtps.isNotEmpty) ...[
                          if (_resultCode.isNotEmpty) const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _allDebugOtps.map((otp) {
                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                decoration: BoxDecoration(
                                  color: _telegramColor.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: _telegramColor.withOpacity(0.2)),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      otp,
                                      style: TextStyle(
                                        color: _telegramColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    IconButton(
                                      icon: Icon(Icons.copy, size: 14),
                                      color: _telegramColor,
                                      padding: EdgeInsets.zero,
                                      constraints: const BoxConstraints(),
                                      onPressed: () {
                                        Clipboard.setData(ClipboardData(text: otp)).then((_) {
                                          _showSnackBar("OTP copied", _successColor);
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildNeoInfoCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_cardBg, _cardElevated],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _infoColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(Icons.info, color: _infoColor, size: 22),
              ),
              const SizedBox(width: 12),
              Text(
                "IMPORTANT INFO",
                style: TextStyle(
                  color: _infoColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Column(
            children: [
              _buildNeoInfoItem("Use international format: +[country][number]", Icons.check, _successColor),
              _buildNeoInfoItem("Maximum 20 spam per execution", Icons.warning, _warningColor),
              _buildNeoInfoItem("Delay: 500-10000ms for WhatsApp", FontAwesomeIcons.whatsapp, _whatsappColor),
              _buildNeoInfoItem("Delay: 1000-10000ms for Telegram", Icons.telegram, _telegramColor),
              if (!_canAccessSpam(widget.role))
                _buildNeoInfoItem("⛔ Role Anda tidak memiliki akses ke Spam Pair", Icons.lock, _errorColor),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNeoInfoItem(String text, dynamic icon, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: _textSecondary,
                fontSize: 13,
                height: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNeoApiCard(Map<String, dynamic> api, int index) {
    final isActive = api['is_active'] ?? true;
    final isSelected = index == _selectedApiIndex;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isSelected 
              ? [_primaryColor.withOpacity(0.05), _cardBg]
              : [_cardBg, _cardElevated],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? _primaryColor : _borderColor,
          width: isSelected ? 2 : 1,
        ),
        boxShadow: isSelected ? [
          BoxShadow(
            color: _primaryColor.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ] : null,
      ),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: isActive 
                ? LinearGradient(
                    colors: [_primaryColor.withOpacity(0.2), _primaryColor.withOpacity(0.05)],
                  )
                : LinearGradient(
                    colors: [_errorColor.withOpacity(0.2), _errorColor.withOpacity(0.05)],
                  ),
          ),
          child: Center(
            child: Text(
              (index + 1).toString(),
              style: TextStyle(
                color: isActive ? _primaryColor : _errorColor,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ),
        ),
        title: Text(
          api['alias'] ?? "API-${index + 1}",
          style: TextStyle(
            color: isActive ? _textPrimary : _textSecondary,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          "ID: ${api['api_id']} • Used: ${api['used_count'] ?? 0}x",
          style: TextStyle(
            color: _textSecondary,
            fontSize: 11,
          ),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(
                isActive ? Icons.toggle_on : Icons.toggle_off,
                color: isActive ? _successColor : _errorColor,
                size: 32,
              ),
              onPressed: () => _toggleApiStatus(index),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
            const SizedBox(width: 4),
            Container(
              decoration: BoxDecoration(
                color: _errorColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: IconButton(
                icon: Icon(Icons.delete_outline, color: _errorColor, size: 20),
                onPressed: () => _removeTelegramApi(index),
                padding: const EdgeInsets.all(6),
                constraints: const BoxConstraints(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeoHistoryItem(Map<String, dynamic> entry) {
    final isWhatsApp = entry['type'] == 'WhatsApp';
    final time = DateTime.parse(entry['timestamp']);
    final timeStr = "${time.day.toString().padLeft(2, '0')}/${time.month.toString().padLeft(2, '0')} ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}";
    final code = entry['code'] ?? '';
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_cardBg, _cardElevated],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor.withOpacity(0.3)),
      ),
      child: ListTile(
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: isWhatsApp ? _whatsappGradient : _telegramGradient,
          ),
          child: Center(
            child: Icon(
              isWhatsApp ? FontAwesomeIcons.whatsapp : Icons.telegram,
              color: Colors.white,
              size: 20,
            ),
          ),
        ),
        title: Text(
          entry['phone'],
          style: TextStyle(
            color: _textPrimary,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(
          "${isWhatsApp ? "WhatsApp" : "Telegram"} • $timeStr",
          style: TextStyle(
            color: _textSecondary,
            fontSize: 11,
          ),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _darkBg.withOpacity(0.3),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isWhatsApp ? _whatsappColor : _telegramColor,
              width: 1,
            ),
          ),
          child: Text(
            code.length > 6 ? "${code.substring(0, 6)}..." : code,
            style: TextStyle(
              color: isWhatsApp ? _whatsappColor : _telegramColor,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              fontFamily: 'monospace',
            ),
          ),
        ),
      ),
    );
  }

  // ─── WhatsApp Form ──────────────────────────────────────────────────────────
  Widget _buildNeoWhatsAppForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildNeoFormHeader(
          icon: FontAwesomeIcons.whatsapp,
          title: "WHATSAPP SPAM",
          subtitle: "Send pairing code to WhatsApp number",
          gradient: _whatsappGradient,
        ),
        const SizedBox(height: 20),
        
        _buildNeoPhoneInput(
          controller: _waPhoneController,
          label: "WhatsApp Number",
          hint: "Example: +6281234567890",
          color: _whatsappColor,
        ),
        
        const SizedBox(height: 20),
        
        Text(
          "SETTINGS",
          style: TextStyle(
            color: _textSecondary,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        
        Row(
          children: [
            Expanded(
              child: _buildNeoNumberInput(
                controller: _waDelayController,
                label: "DELAY (ms)",
                icon: Icons.timer,
                color: _whatsappColor,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildNeoNumberInput(
                controller: _waCountController,
                label: "COUNT",
                icon: Icons.repeat,
                color: _whatsappColor,
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 24),
        
        _buildNeoActionButton(
          label: _canAccessSpam(widget.role) ? "START WHATSAPP SPAM" : "⛔ ACCESS DENIED",
          color: _canAccessSpam(widget.role) ? _whatsappColor : _textMuted,
          onPressed: _canAccessSpam(widget.role) ? _executeWhatsAppSpam : () {
            _showSnackBar("Akses ditolak. Role Anda: ${getRoleDisplay(widget.role)}", _errorColor);
          },
          icon: _canAccessSpam(widget.role) ? Icons.send : Icons.lock,
          isLoading: _isLoading,
        ),
      ],
    );
  }

  // ─── Telegram Form ──────────────────────────────────────────────────────────
  Widget _buildNeoTelegramForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildNeoFormHeader(
          icon: Icons.telegram,
          title: "TELEGRAM SPAM",
          subtitle: "Send OTP spam to Telegram number",
          gradient: _telegramGradient,
        ),
        const SizedBox(height: 20),
        
        if (_telegramApis.isNotEmpty) ...[
          _buildNeoApiSelector(),
          const SizedBox(height: 20),
        ],
        
        _buildNeoPhoneInput(
          controller: _telegramPhoneController,
          label: "Telegram Number",
          hint: "Example: +6281234567890",
          color: _telegramColor,
        ),
        
        const SizedBox(height: 20),
        
        Text(
          "SETTINGS",
          style: TextStyle(
            color: _textSecondary,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 12),
        
        Row(
          children: [
            Expanded(
              child: _buildNeoNumberInput(
                controller: _telegramDelayController,
                label: "DELAY (ms)",
                icon: Icons.timer,
                color: _telegramColor,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildNeoNumberInput(
                controller: _telegramCountController,
                label: "COUNT",
                icon: Icons.repeat,
                color: _telegramColor,
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 24),
        
        _buildNeoActionButton(
          label: _telegramApis.isEmpty 
              ? "ADD API FIRST" 
              : (_canAccessSpam(widget.role) ? "START TELEGRAM SPAM" : "⛔ ACCESS DENIED"),
          color: _telegramApis.isEmpty 
              ? _textMuted 
              : (_canAccessSpam(widget.role) ? _telegramColor : _textMuted),
          onPressed: _telegramApis.isEmpty 
              ? () => setState(() => _selectedMenu = 2) 
              : (_canAccessSpam(widget.role) ? _executeTelegramSpam : () {
                  _showSnackBar("Akses ditolak. Role Anda: ${getRoleDisplay(widget.role)}", _errorColor);
                }),
          icon: _telegramApis.isEmpty 
              ? Icons.add 
              : (_canAccessSpam(widget.role) ? Icons.telegram : Icons.lock),
          isLoading: _isLoading,
        ),
      ],
    );
  }

  Widget _buildNeoApiSelector() {
    return Container(
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor.withOpacity(0.4)),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "SELECT API",
            style: TextStyle(
              color: _textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: _darkBg.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _borderColor.withOpacity(0.3)),
            ),
            child: DropdownButton<int>(
              value: _selectedApiIndex,
              dropdownColor: _darkBg,
              underline: const SizedBox(),
              isExpanded: true,
              items: List.generate(_telegramApis.length, (index) {
                final api = _telegramApis[index];
                final isActive = api['is_active'] ?? true;
                return DropdownMenuItem<int>(
                  value: index,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isActive ? _telegramColor.withOpacity(0.1) : _errorColor.withOpacity(0.1),
                          ),
                          child: Center(
                            child: Text(
                              (index + 1).toString(),
                              style: TextStyle(
                                color: isActive ? _telegramColor : _errorColor,
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                api['alias'] ?? "API-${index + 1}",
                                style: TextStyle(
                                  color: isActive ? _textPrimary : _textSecondary,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                "Used: ${api['used_count'] ?? 0}x",
                                style: TextStyle(
                                  color: _textSecondary,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              onChanged: (value) {
                if (value != null) {
                  setState(() => _selectedApiIndex = value);
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  // ─── API Manager Form ──────────────────────────────────────────────────────
  Widget _buildNeoApiManagerForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildNeoFormHeader(
          icon: Icons.api,
          title: "API MANAGEMENT",
          subtitle: "Manage Telegram API credentials",
          gradient: _primaryGradient,
        ),
        const SizedBox(height: 20),
        
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_cardBg, _cardElevated],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _borderColor.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "ADD NEW API",
                style: TextStyle(
                  color: _textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.3,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Get credentials from my.telegram.org",
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 20),
              
              _buildNeoInputField(
                controller: _apiIdController,
                label: "API ID",
                hint: "Enter API ID (numeric)",
                icon: Icons.vpn_key,
                isNumeric: true,
              ),
              const SizedBox(height: 16),
              
              _buildNeoInputField(
                controller: _apiHashController,
                label: "API HASH",
                hint: "Enter 32-character API Hash",
                icon: Icons.fingerprint,
                obscureText: true,
              ),
              const SizedBox(height: 16),
              
              _buildNeoInputField(
                controller: _apiAliasController,
                label: "ALIAS (optional)",
                hint: "Name for this API",
                icon: Icons.title,
              ),
              const SizedBox(height: 24),
              
              _buildNeoActionButton(
                label: "ADD API",
                color: _primaryColor,
                onPressed: _addTelegramApi,
                icon: Icons.add,
                isLoading: _isLoading,
              ),
            ],
          ),
        ),
        
        if (_telegramApis.isNotEmpty) ...[
          const SizedBox(height: 24),
          Row(
            children: [
              Text(
                "REGISTERED APIS",
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  "${_telegramApis.length} API",
                  style: TextStyle(
                    color: _primaryColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ..._telegramApis.asMap().entries.map((entry) {
            final index = entry.key;
            final api = entry.value;
            return _buildNeoApiCard(api, index);
          }).toList(),
        ],
      ],
    );
  }

  // ─── History Modal ──────────────────────────────────────────────────────────
  Future<void> _showNeoHistory() async {
    await _loadSpamHistory();
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.85,
          ),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_darkBg, _cardBg],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: _borderColor.withOpacity(0.3)),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _borderColor,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.history, color: _primaryColor, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    "SPAM HISTORY",
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: Icon(Icons.close, color: _textSecondary),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              
              if (_spamHistory.isNotEmpty)
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _infoColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        "Total: ${_spamHistory.length} entries",
                        style: TextStyle(
                          color: _infoColor,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: _clearHistory,
                      icon: Icon(Icons.delete_sweep, color: _errorColor, size: 16),
                      label: Text(
                        "Clear All",
                        style: TextStyle(color: _errorColor, fontSize: 12),
                      ),
                      style: TextButton.styleFrom(
                        backgroundColor: _errorColor.withOpacity(0.05),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ],
                ),
              
              const SizedBox(height: 12),
              
              Expanded(
                child: _spamHistory.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.history_toggle_off, color: _textMuted, size: 56),
                            const SizedBox(height: 16),
                            Text(
                              "No history yet",
                              style: TextStyle(
                                color: _textSecondary,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Your spam activities will appear here",
                              style: TextStyle(
                                color: _textMuted,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _spamHistory.length,
                        reverse: true,
                        itemBuilder: (context, index) {
                          final entry = _spamHistory[_spamHistory.length - 1 - index];
                          return _buildNeoHistoryItem(entry);
                        },
                      ),
              ),
              
              const SizedBox(height: 16),
              
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    elevation: 0,
                  ),
                  child: const Text(
                    "CLOSE",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ✅ FIXED: Menggunakan parameter confirmColor, bukan _errorColor
  Future<bool?> _showConfirmationDialog({
    required String title,
    required String message,
    required Color confirmColor,
  }) async {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _borderColor.withOpacity(0.5), width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _warningColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.warning, color: _warningColor, size: 20),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: TextStyle(
                color: _textPrimary,
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: TextStyle(
            color: _textSecondary,
            fontSize: 14,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            style: TextButton.styleFrom(
              foregroundColor: _textSecondary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text("CANCEL"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: confirmColor, // ✅ PERBAIKAN: Gunakan confirmColor
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 0,
            ),
            child: const Text(
              "CONFIRM",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Main Build ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkBg,
      body: _canAccessSpam(widget.role) 
          ? _buildMainContent() 
          : _buildAccessDenied(),
    );
  }

  // ─── Access Denied Widget ──────────────────────────────────────────────────
  Widget _buildAccessDenied() {
    return Scaffold(
      backgroundColor: _darkBg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _errorColor.withOpacity(0.1),
                border: Border.all(
                  color: _errorColor.withOpacity(0.3),
                  width: 2,
                ),
              ),
              child: const Icon(
                Icons.lock_outline_rounded,
                color: Color(0xFFF87171),
                size: 48,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              "AKSES DITOLAK",
              style: TextStyle(
                color: _textPrimary,
                fontSize: 24,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Spam Pair hanya untuk role:\nCEO, Owner, Admin, Tangan Kanan, dan VIP",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 14,
                  height: 1.6,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: _warningColor.withOpacity(0.1),
                border: Border.all(color: _warningColor.withOpacity(0.2)),
              ),
              child: Text(
                "Role Anda: ${getRoleDisplay(widget.role)} (Level ${getRoleLevel(widget.role)})",
                style: TextStyle(
                  color: _warningColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: 200,
              height: 48,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                label: const Text(
                  "KEMBALI",
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Main Content ──────────────────────────────────────────────────────────
  Widget _buildMainContent() {
    return SafeArea(
      child: FadeTransition(
        opacity: _entrance,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics(),
          ),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: _cardBg.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _borderColor.withOpacity(0.3)),
                    ),
                    child: IconButton(
                      icon: Icon(Icons.arrow_back_ios_new_rounded, color: _textPrimary, size: 18),
                      onPressed: () => Navigator.pop(context),
                      padding: const EdgeInsets.all(10),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (rect) => _primaryGradient.createShader(rect),
                          child: Text(
                            "X-SPYDER SPAM",
                            style: TextStyle(
                              color: _textPrimary,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              "Professional Spam Management System",
                              style: TextStyle(
                                color: _textSecondary,
                                fontSize: 11,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: _successColor.withOpacity(0.1),
                                border: Border.all(color: _successColor.withOpacity(0.2)),
                              ),
                              child: Text(
                                getRoleDisplay(widget.role),
                                style: TextStyle(
                                  color: _successColor,
                                  fontSize: 8,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: _primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _primaryColor.withOpacity(0.2)),
                    ),
                    child: IconButton(
                      icon: Icon(Icons.history, color: _primaryColor, size: 22),
                      onPressed: _showNeoHistory,
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              _buildNeoConnectionStatus(),
              
              const SizedBox(height: 24),
              
              _buildNeoMenuSelector(),
              
              const SizedBox(height: 24),
              
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_cardBg, _cardElevated],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _borderColor.withOpacity(0.3)),
                ),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 350),
                  switchInCurve: Curves.easeOutCubic,
                  switchOutCurve: Curves.easeInCubic,
                  child: [
                    _buildNeoWhatsAppForm(),
                    _buildNeoTelegramForm(),
                    _buildNeoApiManagerForm(),
                  ][_selectedMenu],
                ),
              ),
              
              _buildNeoResultCard(),
              
              const SizedBox(height: 24),
              
              _buildNeoInfoCard(),
              
              const SizedBox(height: 20),
              
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 2,
                      width: 30,
                      decoration: BoxDecoration(
                        gradient: _primaryGradient,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      "X-SPYDER TEAM © 2026",
                      style: TextStyle(
                        color: _textMuted,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      height: 2,
                      width: 30,
                      decoration: BoxDecoration(
                        gradient: _primaryGradient,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}