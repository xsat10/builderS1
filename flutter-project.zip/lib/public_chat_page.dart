import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PublicChatPage extends StatefulWidget {
  final String sessionKey, username, role;
  const PublicChatPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override State<PublicChatPage> createState()=>_PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> with SingleTickerProviderStateMixin {
  static const cyan=Color(0xFF00F5FF), blue=Color(0xFF0066FF), bg=Color(0xFF050914);
  final _message=TextEditingController(), _scroll=ScrollController(), _name=TextEditingController(), _bio=TextEditingController();
  final _picker=ImagePicker();
  final List<ChatMessage> _messages=[];
  final String _baseUrl='http://127.0.0.1:3000';
  Timer? _poll,_onlinePoll; String? _lastId; int _online=0; bool _sending=false; ChatMessage? _replying; bool _editing=false;
  String _chatName='',_chatBio='';

  @override void initState(){super.initState(); _loadProfile(); _loadMessages(); _poll=Timer.periodic(const Duration(seconds:3),(_)=>_checkNew()); _onlinePoll=Timer.periodic(const Duration(seconds:10),(_)=>_onlineUsers());}
  @override void dispose(){_poll?.cancel();_onlinePoll?.cancel();_message.dispose();_scroll.dispose();_name.dispose();_bio.dispose();super.dispose();}

  Future<void> _loadProfile() async { final p=await SharedPreferences.getInstance(); setState((){_chatName=p.getString('global_chat_name_${widget.username}')??widget.username;_chatBio=p.getString('global_chat_bio_${widget.username}')??'Profil Global Chat';}); _name.text=_chatName;_bio.text=_chatBio; }
  Future<void> _saveProfile() async {
    final name=_name.text.trim().isEmpty?widget.username:_name.text.trim(), bio=_bio.text.trim();
    final p=await SharedPreferences.getInstance(); await p.setString('global_chat_name_${widget.username}',name); await p.setString('global_chat_bio_${widget.username}',bio);
    setState((){_chatName=name;_chatBio=bio;}); 
    try{await http.post(Uri.parse('$_baseUrl/updatePublicChatProfile'),headers:{'Content-Type':'application/json'},body:jsonEncode({'key':widget.sessionKey,'chatName':name,'chatBio':bio}));}catch(_){}
    if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profil Global Chat disimpan')));
  }
  Future<void> _loadMessages() async { try{final r=await http.get(Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}')); if(r.statusCode==200){final j=jsonDecode(r.body); if(j['valid']==true){final list=(j['messages'] as List).map((e)=>ChatMessage.fromJson(e)).toList(); setState((){_messages..clear()..addAll(list);_lastId=_messages.isEmpty?null:_messages.first.id;});}}}catch(_){} _scrollBottom(); }
  Future<void> _checkNew() async { if(_lastId==null)return; try{final r=await http.get(Uri.parse('$_baseUrl/getPublicChat?key=${widget.sessionKey}&after=$_lastId'));if(r.statusCode==200){final j=jsonDecode(r.body);if(j['valid']==true&&j['messages'] is List){for(final e in (j['messages'] as List)){final m=ChatMessage.fromJson(e);if(!_messages.any((x)=>x.id==m.id))setState(()=>_messages.insert(0,m));}}}}catch(_){}}
  Future<void> _onlineUsers() async {try{final r=await http.get(Uri.parse('$_baseUrl/getOnlineUsers?key=${widget.sessionKey}'));if(r.statusCode==200){final j=jsonDecode(r.body);if(j['valid']==true)setState(()=>_online=j['count']??0);}}catch(_){}}

  Future<void> _send() async {
    final text=_message.text.trim(); if(text.isEmpty)return; setState(()=>_sending=true);
    try{
      final r=await http.post(Uri.parse('$_baseUrl/${_editing?'editPublicChat':'sendPublicChat'}'),headers:{'Content-Type':'application/json'},body:jsonEncode({'key':widget.sessionKey,'message':text,if(_editing)'messageId':_replying?.id,if(!_editing&&_replying!=null)'replyToId':_replying!.id,if(!_editing&&_replying!=null)'replyToUsername':_replying!.displayName}));
      final j=jsonDecode(r.body);
      if(j['valid']==true){_message.clear();setState((){_editing=false;_replying=null;});await _loadMessages();}else{_snack(j['message']??'Gagal menyimpan pesan');}
    }catch(_){_snack('Server Global Chat tidak dapat dihubungi');}finally{if(mounted)setState(()=>_sending=false);}
  }
  Future<void> _sendPhoto() async {
    final x=await _picker.pickImage(source:ImageSource.gallery,imageQuality:82,maxWidth:1600); if(x==null)return;
    setState(()=>_sending=true);
    try{
      final req=http.MultipartRequest('POST',Uri.parse('$_baseUrl/sendPublicChatImage'));
      req.fields['key']=widget.sessionKey; if(_replying!=null)req.fields['replyToId']=_replying!.id;
      req.files.add(await http.MultipartFile.fromPath('image',x.path)); final r=await req.send(); final body=await r.stream.bytesToString(); final j=jsonDecode(body);
      if(j['valid']==true){setState(()=>_replying=null);await _loadMessages();}else _snack(j['message']??'Gagal mengirim foto');
    }catch(_){_snack('Upload foto gagal atau endpoint foto belum tersedia');}finally{if(mounted)setState(()=>_sending=false);}
  }
  Future<void> _delete(ChatMessage m) async { if(m.username!=widget.username && widget.role.toLowerCase()!='owner' && widget.role.toLowerCase()!='pemilik'){_snack('Tidak punya izin menghapus pesan ini');return;} try{final r=await http.post(Uri.parse('$_baseUrl/deletePublicChat'),headers:{'Content-Type':'application/json'},body:jsonEncode({'key':widget.sessionKey,'messageId':m.id}));final j=jsonDecode(r.body);if(j['valid']==true)setState(()=>_messages.removeWhere((x)=>x.id==m.id));else _snack(j['message']??'Gagal menghapus');}catch(_){_snack('Gagal menghapus pesan');}}
  void _edit(ChatMessage m){if(m.username!=widget.username){_snack('Hanya bisa edit pesan sendiri');return;}setState((){_editing=true;_replying=m;_message.text=m.message;});}
  void _snack(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}

  void _scrollBottom(){WidgetsBinding.instance.addPostFrameCallback((_){if(_scroll.hasClients)_scroll.animateTo(0,duration:const Duration(milliseconds:220),curve:Curves.easeOut);});}

  @override Widget build(BuildContext context)=>DefaultTabController(length:2,child:Scaffold(
    backgroundColor:bg,
    appBar:AppBar(backgroundColor:bg,elevation:0,title:const Text('GLOBAL CHAT',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.2)),bottom:const TabBar(indicatorColor:cyan,labelColor:cyan,unselectedLabelColor:Colors.white54,tabs:[Tab(text:'CHAT GLOBAL'),Tab(text:'PROFIL')]),),
    body:TabBarView(children:[_chatView(),_profileView()]),
  ));

  Widget _chatView()=>Column(children:[
    Container(padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),decoration:BoxDecoration(color:Colors.white.withOpacity(.035),border:Border(bottom:BorderSide(color:cyan.withOpacity(.12)))),child:Row(children:[const Icon(Icons.public,color:cyan,size:18),const SizedBox(width:8),Text('$_online online',style:const TextStyle(color:Colors.white70)),const Spacer(),const Text('FOTO • TANPA VIDEO',style:TextStyle(color:Colors.white38,fontSize:10,fontWeight:FontWeight.bold))])),
    Expanded(child:_messages.isEmpty?const Center(child:Text('Belum ada pesan',style:TextStyle(color:Colors.white38))):ListView.builder(controller:_scroll,reverse:true,padding:const EdgeInsets.all(14),itemCount:_messages.length,itemBuilder:(c,i)=>_bubble(_messages[i]))),
    if(_replying!=null)Container(padding:const EdgeInsets.all(10),color:cyan.withOpacity(.07),child:Row(children:[const Icon(Icons.reply,color:cyan,size:18),const SizedBox(width:8),Expanded(child:Text(_editing?'Mengedit pesan':'Membalas ${_replying!.displayName}: ${_replying!.message}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70,fontSize:12))),IconButton(onPressed:()=>setState((){_replying=null;_editing=false;_message.clear();}),icon:const Icon(Icons.close,color:Colors.white54))])),
    SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(10,8,10,10),child:Row(children:[
      IconButton(onPressed:_sending?null:_sendPhoto,icon:const Icon(Icons.photo_outlined,color:cyan)),
      Expanded(child:Container(decoration:BoxDecoration(color:Colors.white.withOpacity(.05),borderRadius:BorderRadius.circular(25),border:Border.all(color:Colors.white10)),child:TextField(controller:_message,style:const TextStyle(color:Colors.white),minLines:1,maxLines:4,decoration:const InputDecoration(hintText:'Tulis pesan...',hintStyle:TextStyle(color:Colors.white38),border:InputBorder.none,contentPadding:EdgeInsets.symmetric(horizontal:16,vertical:11)),onSubmitted:(_)=>_send()))),
      const SizedBox(width:7),IconButton(onPressed:_sending?null:_send,icon:Icon(_editing?Icons.check_circle:Icons.send_rounded,color:cyan))
    ])))
  ]);

  Widget _bubble(ChatMessage m){final me=m.username==widget.username;return GestureDetector(onLongPress:()=>_menu(m),child:Align(alignment:me?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(12),constraints:BoxConstraints(maxWidth:MediaQuery.of(context).size.width*.80),decoration:BoxDecoration(color:me?cyan.withOpacity(.12):Colors.white.withOpacity(.055),borderRadius:BorderRadius.circular(18),border:Border.all(color:me?cyan.withOpacity(.28):Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(m.displayName,style:TextStyle(color:me?cyan:Colors.white,fontWeight:FontWeight.bold,fontSize:12)),if(m.replyToMessage.isNotEmpty)Container(margin:const EdgeInsets.only(top:6,bottom:6),padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Colors.black26,border:Border(left:BorderSide(color:cyan,width:2))),child:Text('↪ ${m.replyToUsername}: ${m.replyToMessage}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white54,fontSize:10))),
    if(m.imageUrl.isNotEmpty)ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.network(m.imageUrl,height:180,width:double.infinity,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Padding(padding:EdgeInsets.all(12),child:Text('Foto tidak dapat dimuat',style:TextStyle(color:Colors.white54))))),
    if(m.message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:4),child:Text(m.message,style:const TextStyle(color:Colors.white,fontSize:14,height:1.35))),
    const SizedBox(height:4),Text('${m.formattedTime}${m.edited?' • diedit':''}',style:const TextStyle(color:Colors.white38,fontSize:9))
  ]))));}

  void _menu(ChatMessage m)=>showModalBottomSheet(context:context,backgroundColor:bg,shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(22))),builder:(_)=>SafeArea(child:Wrap(children:[
    ListTile(leading:const Icon(Icons.reply,color:cyan),title:const Text('Balas pesan',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(context);setState(()=>_replying=m);}),
    if(m.username==widget.username)ListTile(leading:const Icon(Icons.edit,color:cyan),title:const Text('Edit pesan',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(context);_edit(m);}),
    if(m.username==widget.username||widget.role.toLowerCase()=='owner'||widget.role.toLowerCase()=='pemilik')ListTile(leading:const Icon(Icons.delete_outline,color:Colors.redAccent),title:const Text('Hapus pesan',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(context);_delete(m);}),
  ])));

  Widget _profileView()=>SingleChildScrollView(padding:const EdgeInsets.all(22),child:Column(children:[
    const SizedBox(height:20),Container(width:90,height:90,decoration:BoxDecoration(shape:BoxShape.circle,color:cyan.withOpacity(.1),border:Border.all(color:cyan.withOpacity(.5)),boxShadow:[BoxShadow(color:cyan.withOpacity(.2),blurRadius:24)]),child:Center(child:Text((_chatName.isEmpty?widget.username:_chatName)[0].toUpperCase(),style:const TextStyle(color:cyan,fontSize:34,fontWeight:FontWeight.w900)))),
    const SizedBox(height:14),const Text('PROFIL GLOBAL CHAT',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,letterSpacing:1)),const SizedBox(height:22),
    _field('Nama Global Chat',_name),const SizedBox(height:12),_field('Bio Global Chat',_bio,maxLines:3),const SizedBox(height:20),
    SizedBox(width:double.infinity,height:50,child:ElevatedButton.icon(onPressed:_saveProfile,icon:const Icon(Icons.save_rounded),label:const Text('SIMPAN PROFIL'),style:ElevatedButton.styleFrom(backgroundColor:cyan,foregroundColor:Colors.black,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15))))),
    const SizedBox(height:12),const Text('Profil ini khusus Global Chat dan tidak mengubah Profil Utama.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white38,fontSize:11)),
  ]));
  Widget _field(String label,TextEditingController c,{int maxLines=1})=>TextField(controller:c,maxLines:maxLines,style:const TextStyle(color:Colors.white),decoration:InputDecoration(labelText:label,labelStyle:const TextStyle(color:cyan),filled:true,fillColor:Colors.white.withOpacity(.045),border:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(14)),borderSide:BorderSide(color:Colors.white12)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(14)),borderSide:BorderSide(color:Colors.white12))));
}

class ChatMessage {
 final String id,username,role,message,timestamp,formattedTime,imageUrl,replyToUsername,replyToMessage; final bool edited;
 ChatMessage({required this.id,required this.username,required this.role,required this.message,required this.timestamp,required this.formattedTime,required this.imageUrl,required this.replyToUsername,required this.replyToMessage,required this.edited});
 factory ChatMessage.fromJson(Map<String,dynamic> j)=>ChatMessage(id:'${j['id']??''}',username:'${j['username']??''}',role:'${j['role']??'member'}',message:'${j['message']??''}',timestamp:'${j['timestamp']??''}',formattedTime:'${j['formattedTime']??''}',imageUrl:'${j['imageUrl']??j['image']??''}',replyToUsername:'${j['replyToUsername']??''}',replyToMessage:'${j['replyToMessage']??''}',edited:j['edited']==true);
 String get displayName=>username;
}
