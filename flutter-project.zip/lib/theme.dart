import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/neo_skin.dart';

/// Jembatan global antara NeoThemeProvider dan token warna statis
/// (NeoColors/NeoGlass). Provider memanggil `activate(palette)` sehingga
/// seluruh getter warna membacakan palette theme aktif secara live.
class NeoThemeBind {
  static NeoPalette _active = NeoSkin.goldEmerald;
  static NeoPalette get palette => _active;
  static void activate(NeoPalette p) => _active = p;
}

/// Token warna global NovaCore.
///
/// - Nama yang bersifat *theme* (background, gold, border, text, ...) adalah
///   getter dinamis yang mengikuti palet aktif (NeoThemeBind).
/// - Nama yang bersifat *semantik/status/brand* (black, white, yellow, pink,
///   blue, green, orange, purple, grey, role colors) dipertahankan sebagai
///   konstanta agar makna warnanya tidak berubah.
class NeoColors {
  NeoColors._();

  // --- Semantic / status / decorative (tetap) ---
  static const Color black = Color(0xFF111111);
  static const Color white = Color(0xFFFFFFFF);
  static const Color yellow = Color(0xFFFFD900);
  static const Color pink = Color(0xFFFF5C8A);
  static const Color blue = Color(0xFF5B8CFF);
  static const Color green = Color(0xFF55E878);
  static const Color orange = Color(0xFFFF9F43);
  static const Color purple = Color(0xFF9B6BFF);
  static const Color grey = Color(0xFF888888);

  static const Color cream = Color(0xFFFFF9E8);

  // --- Brand role (tetap) ---
  static const Color developer = Color(0xFF9B6BFF);
  static const Color partner = Color(0xFFFF9F43);
  static const Color reseller = Color(0xFF36C5F0);
  static const Color member = Color(0xFFFF6B8A);
  static const Color vip = Color(0xFFFFD700);
  static const Color moderator = Color(0xFF3DD3A5);

  // --- Theme tokens (dinamis) ---
  static NeoPalette get _p => NeoThemeBind.palette;

  static Color get background => _p.background;
  static Color get backgroundSecondary => _p.backgroundSecondary;
  static Color get backgroundOverlay => _p.backgroundOverlay;

  static Color get surface => _p.surface;
  static Color get surfaceElevated => _p.surfaceElevated;
  static Color get surfaceGlass => _p.surfaceGlass;
  static Color get surfaceGlassStrong => _p.surfaceGlassStrong;

  static Color get gold => _p.primary;
  static Color get goldBright => _p.selected;
  static Color get goldDeep => _p.buttonPressed;

  static Color get primaryText => _p.textPrimary;
  static Color get secondaryText => _p.textSecondary;
  static Color get textMuted => _p.textMuted;
  static Color get textOnAccent => _p.textOnAccent;

  static Color get icon => _p.icon;
  static Color get iconMuted => _p.iconMuted;

  static Color get border => _p.border;
  static Color get borderSubtle => _p.borderSubtle;
  static Color get borderStrong => _p.borderStrong;
  static Color get line => _p.borderStrong;

  static Color get divider => _p.divider;

  static Color get ink => _p.ink;

  static Color get darkBg => _p.background;
  static Color get darkCard => _p.surfaceGlass;

  // --- Roman decorative ---
  static Color get marble => _p.textPrimary;
  static Color get royalPurple => _p.secondary;
  static Color get burgundy => _p.danger;

  // --- Status (semantik, mengikuti tema) ---
  static Color get success => _p.success;
  static Color get warning => _p.warning;
  static Color get danger => _p.danger;
  static Color get info => _p.info;

  static Color roleColor(String role) {
    switch (role) {
      case 'developer':
        return developer;
      case 'partner':
        return partner;
      case 'reseller':
        return reseller;
      case 'member':
        return member;
      case 'vip':
        return vip;
      case 'moderator':
        return moderator;
      default:
        return grey;
    }
  }

  static const Map<String, IconData> roleIcon = {
    'developer': Icons.code,
    'partner': Icons.handshake,
    'reseller': Icons.storefront,
    'member': Icons.person,
    'vip': Icons.workspace_premium,
    'moderator': Icons.verified_user,
  };

  static const Map<String, String> roleTitle = {
    'developer': 'SUPER ADMIN',
    'partner': 'MERCHANT',
    'reseller': 'AGENT',
    'member': 'USER',
    'vip': 'VIP',
    'moderator': 'MODERATOR',
  };
}

/// Token glass NovaCore — ikut palet aktif.
class NeoGlass {
  NeoGlass._();

  static NeoPalette get _p => NeoThemeBind.palette;

  static Color get surfaceTint => _p.surfaceGlass.withValues(alpha: 0.4);
  static Color get surfaceLight => _p.surfaceGlass;
  static Color get surfaceMedium => _p.surfaceGlassStrong;
  static Color get borderSubtle => _p.borderSubtle;
  static Color get borderGold => _p.border;
  static Color get borderGoldStrong => _p.borderStrong;
  static Color get highlightTop => _p.surfaceGlassStrong;
  static Color get highlightLeft => _p.surfaceGlass.withValues(alpha: 0.5);
  static Color get scrim => const Color(0x73000000);

  static const double blurSigma = 18;
  static const double blurSigmaHeavy = 28;
  static const double borderWidth = 1.0;
  static const double borderWidthStrong = 1.2;

  static const double radiusSm = 12;
  static const double radiusMd = 16;
  static const double radiusLg = 20;
  static const double radiusXl = 28;

  static ImageFilter get blur =>
      ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma);
  static ImageFilter get blurHeavy =>
      ImageFilter.blur(sigmaX: blurSigmaHeavy, sigmaY: blurSigmaHeavy);

  static BoxDecoration surface({
    BorderRadius? borderRadius,
    Color? tint,
    double? opacity,
  }) {
    return BoxDecoration(
      color: (tint ?? Colors.white).withValues(alpha: opacity ?? 0.06),
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidth),
      boxShadow: [
        BoxShadow(
          color: _p.shadow,
          blurRadius: 24,
          offset: const Offset(0, 8),
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration card({BorderRadius? borderRadius}) {
    return BoxDecoration(
      color: surfaceLight,
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidthStrong),
      boxShadow: [
        BoxShadow(
          color: _p.shadow,
          blurRadius: 28,
          offset: const Offset(0, 12),
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration input({bool focused = false}) {
    return BoxDecoration(
      color: _p.inputBackground,
      borderRadius: BorderRadius.circular(radiusSm),
      border: Border.all(
        color: focused ? _p.inputFocus : borderSubtle,
        width: focused ? borderWidthStrong : borderWidth,
      ),
    );
  }
}

class NeoSpacing {
  NeoSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;
}

class NeoRadius {
  NeoRadius._();
  static const double sm = 6;
  static const double md = 8;
  static const double lg = 10;
  static const double xl = 12;
  static Border get border => Border.all(color: NeoColors.border, width: 1.2);
  static Border borderColor(Color c) => Border.all(color: c, width: 1.2);
  static Border borderThin(Color c) => Border.all(color: c, width: 1);
}

class NeoShadows {
  NeoShadows._();
  static const List<BoxShadow> sm = [
    BoxShadow(
      color: Color(0x33000000),
      offset: Offset(0, 4),
      blurRadius: 14,
      spreadRadius: -4,
    ),
  ];
  static const List<BoxShadow> md = [
    BoxShadow(
      color: Color(0x3D000000),
      offset: Offset(0, 8),
      blurRadius: 24,
      spreadRadius: -6,
    ),
  ];
  static const List<BoxShadow> lg = [
    BoxShadow(
      color: Color(0x49000000),
      offset: Offset(0, 16),
      blurRadius: 40,
      spreadRadius: -8,
    ),
  ];

  static List<BoxShadow> smD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x29000000) : const Color(0x33000000),
      offset: const Offset(0, 4),
      blurRadius: 14,
      spreadRadius: -4,
    ),
  ];
  static List<BoxShadow> mdD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x30000000) : const Color(0x3D000000),
      offset: const Offset(0, 8),
      blurRadius: 24,
      spreadRadius: -6,
    ),
  ];
  static List<BoxShadow> lgD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x36000000) : const Color(0x49000000),
      offset: const Offset(0, 16),
      blurRadius: 40,
      spreadRadius: -8,
    ),
  ];
}

extension NeoShadowX on List<BoxShadow> {
  List<BoxShadow> forDark(bool dark) => dark ? this : this;
}

/// ThemeData aplikasi — diturunkan dari palet aktif sehingga seluruh
/// komponen Material (ColorScheme, input, dialog, bottom sheet, snackbar)
/// ikut berganti skin.
class NeoTheme {
  static NeoPalette get _p => NeoThemeBind.palette;

  static const double borderWidth = 1.2;
  static const Offset shadowOffset = Offset(0, 8);

  static Border border() =>
      Border.all(color: NeoColors.border, width: borderWidth);
  static Border borderColor(Color c) =>
      Border.all(color: c, width: borderWidth);

  static BoxDecoration cardDecoration({Color bg = NeoColors.white}) {
    return BoxDecoration(
      color: bg.withValues(alpha: 0.15),
      border: Border.all(color: _p.borderStrong, width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: [
        BoxShadow(
          color: _p.shadow,
          offset: const Offset(0, 12),
          blurRadius: 28,
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration cardDecorationDark({Color bg = NeoColors.white}) {
    return BoxDecoration(
      color: bg.withValues(alpha: bg == NeoColors.darkCard ? 1 : 0.15),
      border: Border.all(color: _p.border, width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: [
        BoxShadow(
          color: _p.shadow,
          offset: const Offset(0, 12),
          blurRadius: 28,
          spreadRadius: -6,
        ),
      ],
    );
  }

  static const double xl = 16;
  static const EdgeInsets screenPadding = EdgeInsets.all(NeoSpacing.lg);

  static ThemeData get darkTheme => _buildTheme(dark: true);
  static ThemeData get lightTheme => _buildTheme(dark: false);

  static ThemeData _buildTheme({required bool dark}) {
    final p = _p;
    final base = dark
        ? GoogleFonts.spaceGroteskTextTheme(ThemeData.dark().textTheme)
        : GoogleFonts.spaceGroteskTextTheme();
    final textTheme = base.copyWith(
      displayLarge: TextStyle(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        color: p.textPrimary,
      ),
      displayMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w800,
        color: p.textPrimary,
      ),
      headlineLarge: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: p.textPrimary,
      ),
      headlineMedium: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: p.textPrimary,
      ),
      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: p.textPrimary,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: p.textPrimary,
      ),
      labelLarge: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: p.textPrimary,
      ),
      titleMedium: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: p.textSecondary,
      ),
    );

    final scheme = ColorScheme.fromSeed(
      seedColor: p.primary,
      brightness: dark ? Brightness.dark : Brightness.light,
      primary: p.primary,
      secondary: p.secondary,
      surface: p.surface,
      background: p.background,
      error: p.danger,
    ).copyWith(
      onPrimary: p.textOnAccent,
      onSecondary: p.textOnAccent,
      tertiary: p.accent,
      outline: p.border,
      outlineVariant: p.borderSubtle,
    );

    final inputDecoration = InputDecorationTheme(
      filled: true,
      fillColor: p.inputBackground,
      hintStyle: TextStyle(color: p.inputHint, fontSize: 13),
      labelStyle: TextStyle(
        color: p.textSecondary,
        fontSize: 12,
        fontWeight: FontWeight.w700,
      ),
      prefixIconColor: p.iconMuted,
      suffixIconColor: p.iconMuted,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.inputBorder, width: 1.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: p.inputFocus, width: 1.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFFF5C7A), width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFFF5C7A), width: 1.4),
      ),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: dark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: p.background,
      cardColor: p.surface,
      splashColor: p.primary.withValues(alpha: 0.10),
      highlightColor: p.primary.withValues(alpha: 0.06),
      dividerColor: p.divider,
      canvasColor: p.surface,
      colorScheme: scheme,
      inputDecorationTheme: inputDecoration,
      iconTheme: IconThemeData(color: p.icon),
      dividerTheme: DividerThemeData(color: p.divider, thickness: 1),
      textTheme: textTheme,
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: p.surfaceElevated,
        contentTextStyle: TextStyle(
          fontFamily: 'serif',
          fontSize: 13,
          color: p.textPrimary,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: p.border, width: 1),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: p.buttonBackground,
          foregroundColor: p.buttonText,
          disabledBackgroundColor: p.buttonDisabled,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: p.buttonBackground,
          foregroundColor: p.buttonText,
          disabledBackgroundColor: p.buttonDisabled,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: p.primary,
          textStyle: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }

  /// Warna aksen tombol untuk satu tema — kompatibel dengan kode lama.
  static Color accentFor(String skinId) =>
      NeoSkin.byId[skinId]?.primary ?? NeoThemeBind.palette.primary;
}