import 'dart:convert';
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart'; // <-- PENTING!

enum GameMode { easy, medium, hard }

class PlayerScore {
  final String username;
  int easyScore;
  int mediumScore;
  int hardScore;
  int totalCorrect;
  int totalGames;

  PlayerScore({
    required this.username,
    this.easyScore = 0,
    this.mediumScore = 0,
    this.hardScore = 0,
    this.totalCorrect = 0,
    this.totalGames = 0,
  });

  int get totalScore => easyScore + mediumScore + hardScore;

  Map<String, dynamic> toJson() => {
    'username': username,
    'easyScore': easyScore,
    'mediumScore': mediumScore,
    'hardScore': hardScore,
    'totalCorrect': totalCorrect,
    'totalGames': totalGames,
  };

  factory PlayerScore.fromJson(Map<String, dynamic> json) => PlayerScore(
    username: json['username'] ?? '',
    easyScore: json['easyScore'] ?? 0,
    mediumScore: json['mediumScore'] ?? 0,
    hardScore: json['hardScore'] ?? 0,
    totalCorrect: json['totalCorrect'] ?? 0,
    totalGames: json['totalGames'] ?? 0,
  );
}

class SoalDatabase {
  static final List<Map<String, dynamic>> soalEasy = [
    {
      'soal': 'Apa kepanjangan dari HTML?',
      'jawaban': 'hypertext markup language',
      'hint': 'Hyper... Markup...',
      'category': 'web',
    },
    {
      'soal': 'CSS digunakan untuk?',
      'jawaban': 'styling',
      'hint': 'Membuat tampilan cantik',
      'category': 'web',
    },
    {
      'soal': 'JavaScript adalah bahasa pemrograman yang berjalan di?',
      'jawaban': 'browser',
      'hint': 'Tempat browsing',
      'category': 'javascript',
    },
    {
      'soal': 'PHP kepanjangan dari?',
      'jawaban': 'php hypertext preprocessor',
      'hint': 'P H P',
      'category': 'backend',
    },
    {
      'soal': 'Database relation biasanya menggunakan?',
      'jawaban': 'sql',
      'hint': 'Structured Query Language',
      'category': 'database',
    },
    {
      'soal': 'Python adalah bahasa pemrograman yang dikenal dengan?',
      'jawaban': 'sederhana',
      'hint': 'Simple',
      'category': 'python',
    },
    {
      'soal': 'Framework PHP yang paling populer?',
      'jawaban': 'laravel',
      'hint': 'Lara...',
      'category': 'php',
    },
    {
      'soal': 'Git digunakan untuk?',
      'jawaban': 'version control',
      'hint': 'Mengelola versi kode',
      'category': 'tools',
    },
    {
      'soal': 'Perintah untuk clone repository git?',
      'jawaban': 'git clone',
      'hint': 'git [nama perintah]',
      'category': 'git',
    },
    {
      'soal': 'Localhost biasanya menggunakan port?',
      'jawaban': '80',
      'hint': 'Port default HTTP',
      'category': 'networking',
    },
    {
      'soal': 'Apa itu API?',
      'jawaban': 'application programming interface',
      'hint': 'Application... Interface',
      'category': 'api',
    },
    {
      'soal': 'JSON kepanjangan dari?',
      'jawaban': 'javascript object notation',
      'hint': 'JavaScript Object...',
      'category': 'data',
    },
    {
      'soal': 'Flutter menggunakan bahasa?',
      'jawaban': 'dart',
      'hint': 'D A R T',
      'category': 'mobile',
    },
    {
      'soal': 'ReactJS adalah library untuk?',
      'jawaban': 'frontend',
      'hint': 'Tampilan depan',
      'category': 'javascript',
    },
    {
      'soal': 'Node.js menjalankan JavaScript di?',
      'jawaban': 'server',
      'hint': 'Backend',
      'category': 'backend',
    },
    {
      'soal': 'MongoDB adalah database?',
      'jawaban': 'nosql',
      'hint': 'No SQL',
      'category': 'database',
    },
    {
      'soal': 'Perintah untuk install package di Python?',
      'jawaban': 'pip install',
      'hint': 'pip [nama perintah]',
      'category': 'python',
    },
    {
      'soal': 'Docker digunakan untuk?',
      'jawaban': 'container',
      'hint': 'Containerization',
      'category': 'devops',
    },
    {
      'soal': 'AWS adalah layanan?',
      'jawaban': 'cloud',
      'hint': 'Amazon Web Services',
      'category': 'cloud',
    },
    {
      'soal': 'Linux adalah sistem operasi?',
      'jawaban': 'open source',
      'hint': 'Source terbuka',
      'category': 'os',
    },
    {
      'soal': 'Perintah untuk melihat file di Linux?',
      'jawaban': 'ls',
      'hint': 'L S',
      'category': 'linux',
    },
    {
      'soal': 'Apa itu compiler?',
      'jawaban': 'penerjemah kode',
      'hint': 'Menerjemahkan ke bahasa mesin',
      'category': 'basic',
    },
    {
      'soal': 'Variable di JavaScript dideklarasikan dengan?',
      'jawaban': 'let',
      'hint': 'LET',
      'category': 'javascript',
    },
    {
      'soal': 'Looping for digunakan untuk?',
      'jawaban': 'perulangan',
      'hint': 'Mengulang kode',
      'category': 'basic',
    },
    {
      'soal': 'Array digunakan untuk menyimpan?',
      'jawaban': 'banyak data',
      'hint': 'Multiple values',
      'category': 'basic',
    },
    {
      'soal': 'Function digunakan untuk?',
      'jawaban': 'mengelompokkan kode',
      'hint': 'Code reuse',
      'category': 'basic',
    },
    {
      'soal': 'HTTP status code 200 artinya?',
      'jawaban': 'ok',
      'hint': 'Success',
      'category': 'web',
    },
    {
      'soal': 'HTTP status code 404 artinya?',
      'jawaban': 'not found',
      'hint': 'Tidak ditemukan',
      'category': 'web',
    },
    {
      'soal': 'HTTP status code 500 artinya?',
      'jawaban': 'internal server error',
      'hint': 'Server error',
      'category': 'web',
    },
    {
      'soal': 'Apa itu debugging?',
      'jawaban': 'mencari bug',
      'hint': 'Mencari error',
      'category': 'basic',
    },
  ];

  static final List<Map<String, dynamic>> soalMedium = [
    {
      'soal': 'Apa output dari: console.log(typeof [])?',
      'jawaban': 'object',
      'hint': 'Array adalah object di JS',
      'category': 'javascript',
    },
    {
      'soal': 'Apa itu CORS?',
      'jawaban': 'cross origin resource sharing',
      'hint': 'Cross... Resource Sharing',
      'category': 'security',
    },
    {
      'soal': 'Apa itu SQL Injection?',
      'jawaban': 'serangan database',
      'hint': 'Memasukkan query SQL',
      'category': 'security',
    },
    {
      'soal': 'XSS adalah singkatan dari?',
      'jawaban': 'cross site scripting',
      'hint': 'Cross Site...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu CSRF?',
      'jawaban': 'cross site request forgery',
      'hint': 'Cross Site Request...',
      'category': 'security',
    },
    {
      'soal': 'Perbedaan == dan === di JavaScript?',
      'jawaban': 'strict equality',
      'hint': '=== cek tipe data',
      'category': 'javascript',
    },
    {
      'soal': 'Apa itu hoisting di JavaScript?',
      'jawaban': 'mengangkat deklarasi',
      'hint': 'Deklarasi diangkat ke atas',
      'category': 'javascript',
    },
    {
      'soal': 'Apa itu closure di JavaScript?',
      'jawaban': 'fungsi dalam fungsi',
      'hint': 'Function inside function',
      'category': 'javascript',
    },
    {
      'soal': 'Apa itu promise di JavaScript?',
      'jawaban': 'async operation',
      'hint': 'Janji asynchronous',
      'category': 'javascript',
    },
    {
      'soal': 'Apa itu OOP?',
      'jawaban': 'object oriented programming',
      'hint': 'Object Oriented...',
      'category': 'paradigm',
    },
    {
      'soal': 'Apa itu inheritance di OOP?',
      'jawaban': 'pewarisan',
      'hint': 'Mewarisi sifat',
      'category': 'oop',
    },
    {
      'soal': 'Apa itu polymorphism?',
      'jawaban': 'banyak bentuk',
      'hint': 'Poly = banyak, morph = bentuk',
      'category': 'oop',
    },
    {
      'soal': 'Apa itu encapsulation?',
      'jawaban': 'pembungkusan',
      'hint': 'Menyembunyikan data',
      'category': 'oop',
    },
    {
      'soal': 'Apa itu abstraction?',
      'jawaban': 'penyembunyian detail',
      'hint': 'Hide complexity',
      'category': 'oop',
    },
    {
      'soal': 'Apa itu REST API?',
      'jawaban': 'representational state transfer',
      'hint': 'Representational State...',
      'category': 'api',
    },
    {
      'soal': 'Apa itu JWT?',
      'jawaban': 'json web token',
      'hint': 'JSON Web...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu OAuth?',
      'jawaban': 'open authorization',
      'hint': 'Open Authorization',
      'category': 'security',
    },
    {
      'soal': 'Apa itu HTTPS?',
      'jawaban': 'hypertext transfer protocol secure',
      'hint': 'HTTP Secure',
      'category': 'security',
    },
    {
      'soal': 'Apa itu SSL?',
      'jawaban': 'secure sockets layer',
      'hint': 'Secure Sockets...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu TLS?',
      'jawaban': 'transport layer security',
      'hint': 'Transport Layer...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu Docker Compose?',
      'jawaban': 'orchestration container',
      'hint': 'Mengatur banyak container',
      'category': 'devops',
    },
    {
      'soal': 'Apa itu Kubernetes?',
      'jawaban': 'container orchestration',
      'hint': 'Mengelola container',
      'category': 'devops',
    },
    {
      'soal': 'Apa itu CI/CD?',
      'jawaban': 'continuous integration continuous deployment',
      'hint': 'Continuous Integration/Deployment',
      'category': 'devops',
    },
    {
      'soal': 'Apa itu Microservices?',
      'jawaban': 'arsitektur layanan kecil',
      'hint': 'Small services',
      'category': 'architecture',
    },
    {
      'soal': 'Apa itu GraphQL?',
      'jawaban': 'query language',
      'hint': 'Graph Query Language',
      'category': 'api',
    },
  ];

  static final List<Map<String, dynamic>> soalHard = [
    // ===== EXPLOIT & HACKING (HARD) =====
    {
      'soal': 'Tools untuk melakukan SQL Injection otomatis?',
      'jawaban': 'sqlmap',
      'hint': 'SQL map',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Buffer Overflow?',
      'jawaban': 'kelebihan buffer',
      'hint': 'Memory overflow',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Reverse Shell?',
      'jawaban': 'koneksi balik dari target',
      'hint': 'Target connect ke attacker',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Bind Shell?',
      'jawaban': 'membuka port di target',
      'hint': 'Target buka port',
      'category': 'exploit',
    },
    {
      'soal': 'Tools untuk melakukan port scanning?',
      'jawaban': 'nmap',
      'hint': 'Network Mapper',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu Metasploit?',
      'jawaban': 'framework exploit',
      'hint': 'Framework untuk exploit',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Payload dalam hacking?',
      'jawaban': 'muatan exploit',
      'hint': 'Muatannya exploit',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Exploit?',
      'jawaban': 'celah keamanan',
      'hint': 'Vulnerability',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu 0-day?',
      'jawaban': 'celah belum diketahui',
      'hint': 'Zero day',
      'category': 'exploit',
    },
    {
      'soal': 'Tools untuk melakukan brute force?',
      'jawaban': 'hydra',
      'hint': 'Hydra tool',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Wireshark?',
      'jawaban': 'packet analyzer',
      'hint': 'Menganalisis packet',
      'category': 'networking',
    },
    {
      'soal': 'Apa itu Burp Suite?',
      'jawaban': 'web proxy tool',
      'hint': 'Tools proxy web',
      'category': 'web',
    },
    {
      'soal': 'Apa itu John the Ripper?',
      'jawaban': 'password cracker',
      'hint': 'Tool crack password',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu ARP Spoofing?',
      'jawaban': 'serangan jaringan lokal',
      'hint': 'ARP poisoning',
      'category': 'network',
    },
    {
      'soal': 'Apa itu Deauth Attack?',
      'jawaban': 'memutus koneksi wifi',
      'hint': 'De-authentication',
      'category': 'wifi',
    },
    {
      'soal': 'Apa itu Phishing?',
      'jawaban': 'pencurian data login',
      'hint': 'Fake login page',
      'category': 'social',
    },
    {
      'soal': 'Apa itu Man in The Middle?',
      'jawaban': 'penyadapan tengah',
      'hint': 'MITM',
      'category': 'network',
    },
    {
      'soal': 'Apa itu DDoS?',
      'jawaban': 'distributed denial of service',
      'hint': 'Distributed...',
      'category': 'attack',
    },
    {
      'soal': 'Apa itu Botnet?',
      'jawaban': 'jaringan komputer zombie',
      'hint': 'Robot network',
      'category': 'attack',
    },
    {
      'soal': 'Apa itu Ransomware?',
      'jawaban': 'virus tebusan',
      'hint': 'Ransom = tebusan',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Trojan?',
      'jawaban': 'malware menyamar',
      'hint': 'Kuda Troya',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Worm?',
      'jawaban': 'malware menyebar sendiri',
      'hint': 'Self-replicating',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Keylogger?',
      'jawaban': 'perekam ketikan',
      'hint': 'Merekam keyboard',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Rootkit?',
      'jawaban': 'sembunyi di sistem',
      'hint': 'Hide in root',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Backdoor?',
      'jawaban': 'pintu rahasia',
      'hint': 'Pintu belakang',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Privilege Escalation?',
      'jawaban': 'naikkan hak akses',
      'hint': 'Naikkan level user',
      'category': 'exploit',
    },
    {
      'soal': 'Apa itu Social Engineering?',
      'jawaban': 'rekayasa sosial',
      'hint': 'Manipulasi manusia',
      'category': 'social',
    },
    {
      'soal': 'Apa itu Footprinting?',
      'jawaban': 'pengumpulan informasi',
      'hint': 'Mengumpulkan jejak',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu Scanning?',
      'jawaban': 'memindai target',
      'hint': 'Scan port',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu Enumeration?',
      'jawaban': 'pengumpulan data detail',
      'hint': 'Mengumpulkan info detail',
      'category': 'recon',
    },
    {
      'soal': 'Tools untuk WiFi hacking?',
      'jawaban': 'aircrack ng',
      'hint': 'Aircrack-ng',
      'category': 'wifi',
    },
    {
      'soal': 'Apa itu WPA2?',
      'jawaban': 'wifi protected access 2',
      'hint': 'WiFi Protected Access 2',
      'category': 'wifi',
    },
    {
      'soal': 'Apa itu WPS?',
      'jawaban': 'wifi protected setup',
      'hint': 'WiFi Protected Setup',
      'category': 'wifi',
    },
    {
      'soal': 'Apa itu Kali Linux?',
      'jawaban': 'os untuk hacking',
      'hint': 'OS pentesting',
      'category': 'tools',
    },
    {
      'soal': 'Apa itu Parrot OS?',
      'jawaban': 'os security',
      'hint': 'OS untuk security',
      'category': 'tools',
    },
    {
      'soal': 'Apa itu Nmap script?',
      'jawaban': 'automation scanning',
      'hint': 'Script untuk Nmap',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu Zenmap?',
      'jawaban': 'nmap gui',
      'hint': 'Nmap dengan GUI',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu OpenVAS?',
      'jawaban': 'vulnerability scanner',
      'hint': 'Scanner kerentanan',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu Nessus?',
      'jawaban': 'vulnerability scanner',
      'hint': 'Scanner kerentanan',
      'category': 'recon',
    },
    {
      'soal': 'Apa itu OWASP?',
      'jawaban': 'open web application security project',
      'hint': 'Open Web...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu CVE?',
      'jawaban': 'common vulnerabilities and exposures',
      'hint': 'Common...',
      'category': 'security',
    },
    {
      'soal': 'Apa itu CVSS?',
      'jawaban': 'common vulnerability scoring system',
      'hint': 'Scoring system',
      'category': 'security',
    },
    {
      'soal': 'Apa itu IDS?',
      'jawaban': 'intrusion detection system',
      'hint': 'Deteksi intrusi',
      'category': 'security',
    },
    {
      'soal': 'Apa itu IPS?',
      'jawaban': 'intrusion prevention system',
      'hint': 'Cegah intrusi',
      'category': 'security',
    },
    {
      'soal': 'Apa itu Firewall?',
      'jawaban': 'pembatas jaringan',
      'hint': 'Network barrier',
      'category': 'security',
    },
    {
      'soal': 'Apa itu Honeypot?',
      'jawaban': 'perangkap hacker',
      'hint': 'Jebakan',
      'category': 'security',
    },
    {
      'soal': 'Apa itu Sandbox?',
      'jawaban': 'lingkungan terisolasi',
      'hint': 'Isolated environment',
      'category': 'security',
    },
    {
      'soal': 'Apa itu Malware?',
      'jawaban': 'malicious software',
      'hint': 'Software jahat',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Spyware?',
      'jawaban': 'software mata mata',
      'hint': 'Mata-mata',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Adware?',
      'jawaban': 'software iklan',
      'hint': 'Iklan',
      'category': 'malware',
    },
    {
      'soal': 'Apa itu Cryptojacking?',
      'jawaban': 'penambangan crypto ilegal',
      'hint': 'Mining tanpa izin',
      'category': 'malware',
    },
  ];

  static List<Map<String, dynamic>> getAllSoal(GameMode mode) {
    switch (mode) {
      case GameMode.easy:
        return soalEasy;
      case GameMode.medium:
        return soalMedium;
      case GameMode.hard:
        return soalHard;
    }
  }

  static Map<String, dynamic> getRandomSoal(GameMode mode) {
    final list = getAllSoal(mode);
    final random = Random();
    return list[random.nextInt(list.length)];
  }
}

// ========== COLOR PALETTE ==========
class AsahOtakColors {
  static const Color navyDeep = Color(0xFF0A1929);
  static const Color navyMedium = Color(0xFF1E2F4A);
  static const Color navyLight = Color(0xFF2A3F5F);
  static const Color navyBlue = Color(0xFF1E3A8A);
  static const Color cyanTech = Color(0xFF4A9EFF);
  static const Color successGreen = Color(0xFF10B981);
  static const Color warningOrange = Color(0xFFF59E0B);
  static const Color redError = Color(0xFFEF4444);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color pink = Color(0xFFEC4899);
  
  static const Color easy = Color(0xFF10B981);  // Hijau
  static const Color medium = Color(0xFFF59E0B); // Oranye
  static const Color hard = Color(0xFFEF4444);   // Merah
  
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFFB0B8C5);
}

// ========== MAIN PAGE ==========
class AsahOtakPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const AsahOtakPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<AsahOtakPage> createState() => _AsahOtakPageState();
}

class _AsahOtakPageState extends State<AsahOtakPage> with TickerProviderStateMixin {
  // ========== GAME STATE ==========
  GameMode? _selectedMode;
  Map<String, dynamic>? _currentQuestion;
  String _userAnswer = '';
  bool _showAnswer = false;
  bool _isCorrect = false;
  int _score = 0;
  int _totalQuestions = 0;
  int _hintsUsed = 0;
  
  // ========== TIMER ==========
  Timer? _timer;
  int _timeLeft = 0;
  bool _isTimeOut = false;
  double _timerProgress = 1.0;
  
  // ========== LEADERBOARD ==========
  List<PlayerScore> _leaderboard = [];
  bool _showLeaderboard = false;
  
  // ========== ANIMATION ==========
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadLeaderboard();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    
    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  // ========== LEADERBOARD FUNCTIONS ==========
  Future<void> _loadLeaderboard() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? data = prefs.getString('asah_otak_leaderboard');
      
      if (data != null) {
        final List<dynamic> jsonList = jsonDecode(data);
        setState(() {
          _leaderboard = jsonList
              .map((e) => PlayerScore.fromJson(e))
              .where((p) => p.username.isNotEmpty)
              .toList();
        });
      }
    } catch (e) {
      debugPrint('Error loading leaderboard: $e');
    }
  }

  Future<void> _saveLeaderboard() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = _leaderboard.map((p) => p.toJson()).toList();
      await prefs.setString('asah_otak_leaderboard', jsonEncode(data));
    } catch (e) {
      debugPrint('Error saving leaderboard: $e');
    }
  }

  void _updateLeaderboard() {
    bool found = false;
    
    for (int i = 0; i < _leaderboard.length; i++) {
      if (_leaderboard[i].username == widget.username) {
        // Update existing player
        setState(() {
          if (_selectedMode == GameMode.easy) {
            _leaderboard[i].easyScore = max(_leaderboard[i].easyScore, _score);
          } else if (_selectedMode == GameMode.medium) {
            _leaderboard[i].mediumScore = max(_leaderboard[i].mediumScore, _score);
          } else if (_selectedMode == GameMode.hard) {
            _leaderboard[i].hardScore = max(_leaderboard[i].hardScore, _score);
          }
          _leaderboard[i].totalCorrect += _isCorrect ? 1 : 0;
          _leaderboard[i].totalGames += 1;
        });
        found = true;
        break;
      }
    }
    
    if (!found) {
      // Add new player
      setState(() {
        final newPlayer = PlayerScore(username: widget.username);
        if (_selectedMode == GameMode.easy) {
          newPlayer.easyScore = _score;
        } else if (_selectedMode == GameMode.medium) {
          newPlayer.mediumScore = _score;
        } else if (_selectedMode == GameMode.hard) {
          newPlayer.hardScore = _score;
        }
        newPlayer.totalCorrect = _isCorrect ? 1 : 0;
        newPlayer.totalGames = 1;
        _leaderboard.add(newPlayer);
      });
    }
    
    // Sort leaderboard by total score
    _leaderboard.sort((a, b) => b.totalScore.compareTo(a.totalScore));
    _saveLeaderboard();
  }

  // ========== TIMER FUNCTIONS ==========
  void _startTimer(int seconds) {
    _timer?.cancel();
    setState(() {
      _timeLeft = seconds;
      _timerProgress = 1.0;
      _isTimeOut = false;
    });
    
    final startTime = DateTime.now().millisecondsSinceEpoch;
    
    _timer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (!mounted) return;
      
      final elapsed = (DateTime.now().millisecondsSinceEpoch - startTime) / 1000;
      final remaining = seconds - elapsed;
      
      setState(() {
        _timeLeft = remaining > 0 ? remaining.toInt() : 0;
        _timerProgress = remaining / seconds;
      });
      
      if (remaining <= 0 && !_showAnswer) {
        _handleTimeOut();
        timer.cancel();
      }
    });
  }

  void _stopTimer() {
    _timer?.cancel();
  }

  void _handleTimeOut() {
    if (_showAnswer) return;
    
    _stopTimer();
    
    setState(() {
      _isTimeOut = true;
      _showAnswer = true;
      _isCorrect = false;
    });
    
    _showSnackBar('⏰ Waktu habis!', isError: true);
    _updateLeaderboard();
  }

  // ========== GAME FUNCTIONS ==========
  void _startGame(GameMode mode) {
    int timeLimit;
    switch (mode) {
      case GameMode.easy:
        timeLimit = 300; // 5 menit
        break;
      case GameMode.medium:
        timeLimit = 180; // 3 menit
        break;
      case GameMode.hard:
        timeLimit = 50; // 50 detik
        break;
    }
    
    setState(() {
      _selectedMode = mode;
      _score = 0;
      _totalQuestions = 0;
      _hintsUsed = 0;
      _showAnswer = false;
      _userAnswer = '';
    });
    
    _nextQuestion();
  }

  void _nextQuestion() {
    if (_selectedMode == null) return;
    
    _stopTimer();
    
    setState(() {
      _currentQuestion = SoalDatabase.getRandomSoal(_selectedMode!);
      _showAnswer = false;
      _userAnswer = '';
      _isTimeOut = false;
    });
    
    int timeLimit;
    switch (_selectedMode!) {
      case GameMode.easy:
        timeLimit = 300;
        break;
      case GameMode.medium:
        timeLimit = 180;
        break;
      case GameMode.hard:
        timeLimit = 50;
        break;
    }
    
    _startTimer(timeLimit);
  }

  void _checkAnswer() {
    if (_showAnswer) return;
    
    _stopTimer();
    
    final correctAnswer = _currentQuestion!['jawaban'].toString().toLowerCase().trim();
    final userAnswer = _userAnswer.toLowerCase().trim();
    
    final isCorrect = userAnswer == correctAnswer;
    
    setState(() {
      _showAnswer = true;
      _isCorrect = isCorrect;
      
      if (isCorrect) {
        _score++;
        _totalQuestions++;
        _showSnackBar('✅ Benar! +1 poin', isSuccess: true);
      } else {
        _totalQuestions++;
        _showSnackBar('❌ Salah! Jawaban: ${_currentQuestion!['jawaban']}', isError: true);
      }
    });
    
    _updateLeaderboard();
  }

  void _useHint() {
    if (_showAnswer) return;
    
    final hint = _currentQuestion!['hint'] as String;
    
    setState(() {
      _hintsUsed++;
    });
    
    _showSnackBar('💡 $hint', isSuccess: false);
  }

  void _resetGame() {
    _stopTimer();
    setState(() {
      _selectedMode = null;
      _score = 0;
      _totalQuestions = 0;
      _hintsUsed = 0;
      _showAnswer = false;
      _userAnswer = '';
    });
  }

  void _showSnackBar(String message, {bool isSuccess = false, bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isSuccess ? Icons.check_circle : 
              isError ? Icons.error : Icons.info,
              color: Colors.white,
            ),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isSuccess ? AsahOtakColors.successGreen : 
                        isError ? AsahOtakColors.redError : AsahOtakColors.navyBlue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  // ========== GET TIMER COLOR ==========
  Color _getTimerColor() {
    if (_timeLeft > 20) return AsahOtakColors.successGreen;
    if (_timeLeft > 10) return AsahOtakColors.warningOrange;
    return AsahOtakColors.redError;
  }

  // ========== GET USER SCORE ==========
  int _getUserScore(GameMode mode) {
    for (var player in _leaderboard) {
      if (player.username == widget.username) {
        switch (mode) {
          case GameMode.easy:
            return player.easyScore;
          case GameMode.medium:
            return player.mediumScore;
          case GameMode.hard:
            return player.hardScore;
        }
      }
    }
    return 0;
  }

  int _getUserTotalGames() {
    for (var player in _leaderboard) {
      if (player.username == widget.username) {
        return player.totalGames;
      }
    }
    return 0;
  }

  // ========== BUILD ==========
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AsahOtakColors.navyDeep,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AsahOtakColors.navyBlue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AsahOtakColors.navyBlue.withOpacity(0.3)),
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          title: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AsahOtakColors.navyBlue, AsahOtakColors.cyanTech],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.psychology, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              const Text(
                'ASAH OTAK - CODING',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          bottom: const TabBar(
            indicatorColor: AsahOtakColors.cyanTech,
            labelColor: AsahOtakColors.cyanTech,
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(icon: Icon(Icons.gamepad), text: 'GAME'),
              Tab(icon: Icon(Icons.leaderboard), text: 'LEADERBOARD'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildGameTab(),
            _buildLeaderboardTab(),
          ],
        ),
      ),
    );
  }

  // ========== GAME TAB ==========
  Widget _buildGameTab() {
    if (_selectedMode == null) {
      return _buildModeSelection();
    }
    
    if (_currentQuestion == null) {
      return _buildLoading();
    }
    
    return _buildGamePlay();
  }

  // ========== MODE SELECTION ==========
  Widget _buildModeSelection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 20),
          
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AsahOtakColors.purple, AsahOtakColors.pink],
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Text(
                    '🧠 PILIH LEVEL 🧠',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              );
            },
          ),
          
          const SizedBox(height: 40),
          
          _buildModeCard(
            mode: GameMode.easy,
            title: 'EASY',
            subtitle: '5 Menit • Soal Dasar',
            color: AsahOtakColors.easy,
            icon: Icons.sentiment_satisfied,
            onTap: () => _startGame(GameMode.easy),
          ),
          
          const SizedBox(height: 20),
          
          _buildModeCard(
            mode: GameMode.medium,
            title: 'MEDIUM',
            subtitle: '3 Menit • Soal Menengah',
            color: AsahOtakColors.medium,
            icon: Icons.sentiment_neutral,
            onTap: () => _startGame(GameMode.medium),
          ),
          
          const SizedBox(height: 20),
          
          _buildModeCard(
            mode: GameMode.hard,
            title: 'HARD',
            subtitle: '50 Detik • Soal Exploit',
            color: AsahOtakColors.hard,
            icon: Icons.sentiment_very_dissatisfied,
            onTap: () => _startGame(GameMode.hard),
          ),
          
          const SizedBox(height: 40),
          
          // Stats
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AsahOtakColors.navyMedium,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AsahOtakColors.cyanTech.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                const Text(
                  'STATISTIK',
                  style: TextStyle(
                    color: AsahOtakColors.cyanTech,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatItem('EASY', _getUserScore(GameMode.easy), AsahOtakColors.easy),
                    _buildStatItem('MEDIUM', _getUserScore(GameMode.medium), AsahOtakColors.medium),
                    _buildStatItem('HARD', _getUserScore(GameMode.hard), AsahOtakColors.hard),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Total Soal Terjawab: ${_getUserTotalGames()}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeCard({
    required GameMode mode,
    required String title,
    required String subtitle,
    required Color color,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.2), color.withOpacity(0.1)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color, width: 2),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(icon, color: color, size: 30),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: color,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: color),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(
            color: color,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.white54),
        ),
      ],
    );
  }

  // ========== LOADING UI ==========
  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AsahOtakColors.navyBlue, AsahOtakColors.cyanTech],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.psychology,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 20),
          const Text(
            'MEMUAT SOAL...',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  // ========== GAMEPLAY UI ==========
  Widget _buildGamePlay() {
    final soal = _currentQuestion!['soal'] as String;
    final category = _currentQuestion!['category'] as String;
    final timerColor = _getTimerColor();
    
    Color modeColor;
    String modeText;
    switch (_selectedMode!) {
      case GameMode.easy:
        modeColor = AsahOtakColors.easy;
        modeText = 'EASY';
        break;
      case GameMode.medium:
        modeColor = AsahOtakColors.medium;
        modeText = 'MEDIUM';
        break;
      case GameMode.hard:
        modeColor = AsahOtakColors.hard;
        modeText = 'HARD';
        break;
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // ========== HEADER ==========
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AsahOtakColors.navyMedium, AsahOtakColors.navyLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: modeColor.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Mode
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: modeColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: modeColor),
                  ),
                  child: Text(
                    modeText,
                    style: TextStyle(color: modeColor, fontWeight: FontWeight.bold),
                  ),
                ),
                
                // Score
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AsahOtakColors.cyanTech.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AsahOtakColors.cyanTech),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.star, color: AsahOtakColors.cyanTech, size: 16),
                      const SizedBox(width: 4),
                      Text(
                        '$_score',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ========== TIMER ==========
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AsahOtakColors.navyMedium,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: timerColor),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'WAKTU',
                      style: TextStyle(color: timerColor, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '$_timeLeft detik',
                      style: TextStyle(
                        color: timerColor,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: _timerProgress,
                  backgroundColor: Colors.white12,
                  valueColor: AlwaysStoppedAnimation<Color>(timerColor),
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(3),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ========== QUESTION ==========
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AsahOtakColors.navyMedium, AsahOtakColors.navyLight],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: _isTimeOut 
                        ? AsahOtakColors.redError
                        : modeColor.withOpacity(0.2 * _glowAnimation.value),
                    width: 1.5,
                  ),
                ),
                child: Column(
                  children: [
                    // Category
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: modeColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '#$category',
                        style: TextStyle(color: modeColor, fontSize: 12),
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Question text
                    Text(
                      soal,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        height: 1.4,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    
                    if (_isTimeOut) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: AsahOtakColors.redError.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: AsahOtakColors.redError),
                        ),
                        child: const Text(
                          '⏰ WAKTU HABIS!',
                          style: TextStyle(
                            color: AsahOtakColors.redError,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },
          ),

          const SizedBox(height: 20),

          // ========== ANSWER INPUT ==========
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AsahOtakColors.navyMedium,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AsahOtakColors.navyBlue.withOpacity(0.3)),
            ),
            child: Column(
              children: [
                // Input field
                Container(
                  decoration: BoxDecoration(
                    color: AsahOtakColors.navyDeep,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: modeColor.withOpacity(0.2)),
                  ),
                  child: TextField(
                    onChanged: (value) => _userAnswer = value,
                    enabled: !_showAnswer && !_isTimeOut,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    decoration: InputDecoration(
                      hintText: 'Masukkan jawaban...',
                      hintStyle: TextStyle(color: AsahOtakColors.textSecondary.withOpacity(0.5)),
                      prefixIcon: Icon(Icons.edit, color: modeColor, size: 20),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Action buttons
                Row(
                  children: [
                    // Hint button
                    Expanded(
                      child: _buildActionButton(
                        icon: Icons.lightbulb,
                        label: 'PETUNJUK',
                        color: AsahOtakColors.warningOrange,
                        onTap: _useHint,
                        enabled: !_showAnswer && !_isTimeOut,
                      ),
                    ),
                    const SizedBox(width: 12),
                    
                    // Submit button
                    Expanded(
                      child: _buildActionButton(
                        icon: Icons.send,
                        label: 'JAWAB',
                        color: modeColor,
                        onTap: _checkAnswer,
                        enabled: !_showAnswer && !_isTimeOut,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Stats
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Soal: $_totalQuestions',
                      style: const TextStyle(color: Colors.white54),
                    ),
                    Text(
                      'Petunjuk: $_hintsUsed',
                      style: const TextStyle(color: Colors.white54),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ========== RESULT CARD ==========
          if (_showAnswer)
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: _isCorrect 
                          ? [AsahOtakColors.successGreen.withOpacity(0.2), AsahOtakColors.successGreen.withOpacity(0.1)]
                          : [AsahOtakColors.redError.withOpacity(0.2), AsahOtakColors.redError.withOpacity(0.1)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _isCorrect ? AsahOtakColors.successGreen : AsahOtakColors.redError,
                      width: 1.5,
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Icon(
                            _isCorrect ? Icons.check_circle : Icons.cancel,
                            color: _isCorrect ? AsahOtakColors.successGreen : AsahOtakColors.redError,
                            size: 24,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _isCorrect ? 'BENAR!' : 'SALAH!',
                                  style: TextStyle(
                                    color: _isCorrect ? AsahOtakColors.successGreen : AsahOtakColors.redError,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                if (!_isCorrect)
                                  Text(
                                    'Jawaban: ${_currentQuestion!['jawaban']}',
                                    style: const TextStyle(color: Colors.white),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      
                      // Next button
                      Container(
                        width: double.infinity,
                        height: 50,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [AsahOtakColors.cyanTech, AsahOtakColors.navyBlue],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ElevatedButton(
                          onPressed: _nextQuestion,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text(
                            'SOAL BERIKUTNYA',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 8),
                      
                      // Reset button
                      TextButton(
                        onPressed: _resetGame,
                        child: const Text(
                          'GANTI MODE',
                          style: TextStyle(color: AsahOtakColors.cyanTech),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    required bool enabled,
  }) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: enabled 
              ? [color, color.withOpacity(0.7)] 
              : [Colors.grey, Colors.grey.shade700],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ElevatedButton(
        onPressed: enabled ? onTap : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  // ========== LEADERBOARD TAB ==========
  Widget _buildLeaderboardTab() {
    if (_leaderboard.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.emoji_events, size: 80, color: AsahOtakColors.cyanTech.withOpacity(0.3)),
            const SizedBox(height: 20),
            const Text(
              'Belum ada data leaderboard',
              style: TextStyle(color: Colors.white54, fontSize: 16),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {});
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AsahOtakColors.cyanTech,
              ),
              child: const Text('REFRESH'),
            ),
          ],
        ),
      );
    }

    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AsahOtakColors.navyMedium,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const TabBar(
              indicatorColor: AsahOtakColors.cyanTech,
              labelColor: AsahOtakColors.cyanTech,
              unselectedLabelColor: Colors.white54,
              tabs: [
                Tab(text: 'EASY'),
                Tab(text: 'MEDIUM'),
                Tab(text: 'HARD'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              children: [
                _buildLeaderboardForMode(GameMode.easy),
                _buildLeaderboardForMode(GameMode.medium),
                _buildLeaderboardForMode(GameMode.hard),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboardForMode(GameMode mode) {
    List<PlayerScore> sortedList;
    Color modeColor;
    String modeName;
    
    switch (mode) {
      case GameMode.easy:
        sortedList = List.from(_leaderboard)..sort((a, b) => b.easyScore.compareTo(a.easyScore));
        modeColor = AsahOtakColors.easy;
        modeName = 'EASY';
        break;
      case GameMode.medium:
        sortedList = List.from(_leaderboard)..sort((a, b) => b.mediumScore.compareTo(a.mediumScore));
        modeColor = AsahOtakColors.medium;
        modeName = 'MEDIUM';
        break;
      case GameMode.hard:
        sortedList = List.from(_leaderboard)..sort((a, b) => b.hardScore.compareTo(a.hardScore));
        modeColor = AsahOtakColors.hard;
        modeName = 'HARD';
        break;
    }

    // Filter yang score > 0
    sortedList = sortedList.where((p) {
      switch (mode) {
        case GameMode.easy:
          return p.easyScore > 0;
        case GameMode.medium:
          return p.mediumScore > 0;
        case GameMode.hard:
          return p.hardScore > 0;
      }
    }).toList();

    if (sortedList.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.leaderboard, size: 60, color: modeColor.withOpacity(0.3)),
            const SizedBox(height: 16),
            Text(
              'Belum ada pemain di mode $modeName',
              style: const TextStyle(color: Colors.white54),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sortedList.length,
      itemBuilder: (context, index) {
        final player = sortedList[index];
        int score;
        
        switch (mode) {
          case GameMode.easy:
            score = player.easyScore;
            break;
          case GameMode.medium:
            score = player.mediumScore;
            break;
          case GameMode.hard:
            score = player.hardScore;
            break;
        }
        
        final isCurrentUser = player.username == widget.username;
        
        Color rankColor;
        IconData rankIcon;
        
        if (index == 0) {
          rankColor = AsahOtakColors.easy;
          rankIcon = Icons.emoji_events;
        } else if (index == 1) {
          rankColor = AsahOtakColors.medium;
          rankIcon = Icons.military_tech;
        } else if (index == 2) {
          rankColor = AsahOtakColors.hard;
          rankIcon = Icons.military_tech;
        } else {
          rankColor = modeColor;
          rankIcon = Icons.fiber_manual_record;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isCurrentUser ? modeColor.withOpacity(0.1) : AsahOtakColors.navyMedium,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isCurrentUser ? modeColor : modeColor.withOpacity(0.3),
              width: isCurrentUser ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              // Rank
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: rankColor.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: index < 3
                      ? Icon(rankIcon, color: rankColor, size: 20)
                      : Text(
                          '${index + 1}',
                          style: TextStyle(color: rankColor, fontWeight: FontWeight.bold),
                        ),
                ),
              ),
              
              const SizedBox(width: 12),
              
              // Username
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      player.username,
                      style: TextStyle(
                        color: isCurrentUser ? modeColor : Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Total: ${player.totalScore} | Games: ${player.totalGames}',
                      style: const TextStyle(color: Colors.white54, fontSize: 10),
                    ),
                  ],
                ),
              ),
              
              // Score
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: modeColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: modeColor),
                ),
                child: Text(
                  '$score',
                  style: TextStyle(
                    color: modeColor,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}