import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'change_password_page.dart';

// ─── 🎯 ROLE SYSTEM BARU ──────────────────────────────────────────────────────
const Map<String, int> ROLE_LEVEL = {
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1
};

const List<String> GLOBAL_SENDER_ROLES = [
  'ceo',
  'owner',
  'admin',
  'tangan_kanan',
  'vip'
];

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
int getRoleLevel(String role) {
  return ROLE_LEVEL[role.toLowerCase()] ?? 0;
}

bool canAccessGlobalSender(String role) {
  return GLOBAL_SENDER_ROLES.contains(role.toLowerCase());
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

String getRoleDuration(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'Permanen';
    case 'owner': return 'Permanen';
    case 'admin': return 'Permanen';
    case 'tangan_kanan': return 'Permanen';
    case 'vip': return 'Permanen';
    case 'reseller': return 'Permanen';
    case 'full_up': return 'Permanen';
    case 'member_perbulan': return '30 Hari';
    case 'member_perminggu': return '7 Hari';
    case 'member_perhari': return '1 Hari';
    default: return '-';
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF1744);
    case 'admin': return const Color(0xFFF59E0B);
    case 'tangan_kanan': return const Color(0xFF8B5CF6);
    case 'vip': return const Color(0xFFEC4899);
    case 'reseller': return const Color(0xFF22C55E);
    case 'full_up': return const Color(0xFF10B981);
    case 'member_perbulan': return const Color(0xFF3B82F6);
    case 'member_perminggu': return const Color(0xFFF97316);
    case 'member_perhari': return const Color(0xFF6B7280);
    default: return Colors.white;
  }
}

// ─── Neo Design System ──────────────────────────────────────────────────────────
class _C {
  // Base colors - lebih deep & elegant
  static const bg        = Color(0xFF080C1A);
  static const surface   = Color(0xFF0E1A2B);
  static const card      = Color(0xFF14233A);
  static const cardInner = Color(0xFF192D47);
  static const border    = Color(0xFF1E3350);
  static const borderLit = Color(0xFF2A4A70);

  // Primary gradient colors
  static const steel     = Color(0xFF1A5A8A);
  static const blueMid   = Color(0xFF2D8FE8);
  static const blueLight = Color(0xFF56AEF5);
  static const blueGlow  = Color(0xFF3B9EFF);
  static const chrome    = Color(0xFF7AB4E8);
  static const frost     = Color(0xFFADD4F5);

  // Status colors
  static const red       = Color(0xFFF87171);
  static const amber     = Color(0xFFFBBF24);
  static const green     = Color(0xFF2DD36F);
  static const purple    = Color(0xFFC084FC);
  static const pink      = Color(0xFFF472B6);
  static const teal      = Color(0xFF2DD4BF);
  static const blue      = Color(0xFF3B82F6);

  // Text colors - lebih layered
  static const text      = Color(0xFFF0F6FF);
  static const textSub   = Color(0xFF8AB4D6);
  static const textDim   = Color(0xFF4A6A8A);
  static const textMuted = Color(0xFF2A4A6A);
  static const white     = Color(0xFFFFFFFF);

  // Gradients
  static const LinearGradient primaryGrad = LinearGradient(
    colors: [steel, blueMid, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient secondaryGrad = LinearGradient(
    colors: [blueMid, blueGlow],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient accentGrad = LinearGradient(
    colors: [purple, pink],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient cardGrad = LinearGradient(
    colors: [card, cardInner],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  // ─── GETTER UNTUK ROLE ─────────────────────────────────────────────────────
  bool get canAccessGlobal => canAccessGlobalSender(widget.role);
  int get roleLevel => getRoleLevel(widget.role);
  String get roleDisplay => getRoleDisplay(widget.role);
  String get roleDuration => getRoleDuration(widget.role);
  Color get roleColor => getRoleColor(widget.role);

  // ── Animation Controllers ──
  late AnimationController _entranceCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _cardEntranceCtrl;

  late Animation<double> _entrance;
  late Animation<double> _pulse;
  late Animation<double> _float;
  late Animation<double> _glow;
  late Animation<double> _cardEntrance;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();

    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _cardEntranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _entrance = CurvedAnimation(
      parent: _entranceCtrl,
      curve: Curves.easeOutCubic,
    );

    _pulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _float = Tween<double>(begin: -8, end: 8).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );

    _glow = Tween<double>(begin: 0.3, end: 0.7).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    _cardEntrance = CurvedAnimation(
      parent: _cardEntranceCtrl,
      curve: Curves.easeOutCubic,
    );

    _entranceCtrl.forward();
    _cardEntranceCtrl.forward();
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _floatCtrl.dispose();
    _glowCtrl.dispose();
    _cardEntranceCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: _C.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: _C.primaryGrad,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.camera_alt, color: Colors.white, size: 20),
              ),
              title: const Text(
                "Camera",
                style: TextStyle(
                  color: _C.text,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: const Text(
                "Take a photo with your camera",
                style: TextStyle(color: _C.textSub, fontSize: 12),
              ),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: _C.secondaryGrad,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.photo_library, color: Colors.white, size: 20),
              ),
              title: const Text(
                "Gallery",
                style: TextStyle(
                  color: _C.text,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: const Text(
                "Choose from your gallery",
                style: TextStyle(color: _C.textSub, fontSize: 12),
              ),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildNeoAppBar(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_C.bg, _C.surface, _C.bg],
          ),
        ),
        child: FadeTransition(
          opacity: _entrance,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
            child: Column(
              children: [
                const SizedBox(height: 12),
                _buildNeoAvatarSection(),
                const SizedBox(height: 20),
                _buildNeoNameSection(),
                const SizedBox(height: 32),
                _buildNeoInfoGrid(),
                const SizedBox(height: 16),
                _buildNeoSessionCard(),
                const SizedBox(height: 32),
                _buildNeoActionButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Neo App Bar ──────────────────────────────────────────────────────────
  PreferredSizeWidget _buildNeoAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: Container(
        margin: const EdgeInsets.only(left: 8),
        child: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _C.surface.withOpacity(0.6),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.border.withOpacity(0.3)),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: _C.blueLight,
              size: 18,
            ),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      title: ShaderMask(
        shaderCallback: (rect) => const LinearGradient(
          colors: [_C.text, _C.blueLight],
        ).createShader(rect),
        child: const Text(
          "PROFILE",
          style: TextStyle(
            color: _C.text,
            fontWeight: FontWeight.w800,
            letterSpacing: 2.5,
            fontSize: 17,
          ),
        ),
      ),
      centerTitle: true,
    );
  }

  // ─── Neo Avatar Section ───────────────────────────────────────────────────
  Widget _buildNeoAvatarSection() {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, _float.value),
        child: Center(
          child: Stack(
            children: [
              // Glow background
              AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) => Container(
                  width: 140,
                  height: 140,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        roleColor.withOpacity(0.2 * _glow.value),
                        Colors.transparent,
                      ],
                      radius: 0.8,
                    ),
                  ),
                ),
              ),
              // Avatar
              GestureDetector(
                onTap: _showImageSourceDialog,
                child: AnimatedBuilder(
                  animation: _pulseCtrl,
                  builder: (_, __) => Container(
                    width: 130,
                    height: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [roleColor, roleColor.withOpacity(0.7)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: roleColor.withOpacity(0.3 * _pulse.value),
                          blurRadius: 30 * _pulse.value,
                          spreadRadius: 4 * _pulse.value,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: _profileImage != null
                          ? Image.file(
                              _profileImage!,
                              fit: BoxFit.cover,
                            )
                          : Container(
                              color: _C.bg.withOpacity(0.3),
                              child: Icon(
                                FontAwesomeIcons.userAstronaut,
                                size: 55,
                                color: _C.white.withOpacity(0.9),
                              ),
                            ),
                    ),
                  ),
                ),
              ),
              // Camera badge
              Positioned(
                bottom: 4,
                right: 4,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [roleColor, roleColor.withOpacity(0.7)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(color: _C.bg, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: roleColor.withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.camera_alt,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Neo Name Section ────────────────────────────────────────────────────
  Widget _buildNeoNameSection() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (rect) => const LinearGradient(
            colors: [_C.text, _C.blueLight],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(rect),
          child: Text(
            widget.username,
            style: const TextStyle(
              color: _C.text,
              fontSize: 24,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [roleColor, roleColor.withOpacity(0.7)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: roleColor.withOpacity(0.2),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Text(
                roleDisplay,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            if (canAccessGlobal)
              Container(
                margin: const EdgeInsets.only(left: 8),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: const Color(0xFFFFD700).withOpacity(0.15),
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.3)),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.public, color: Color(0xFFFFD700), size: 12),
                    SizedBox(width: 4),
                    Text(
                      'GLOBAL',
                      style: TextStyle(
                        color: Color(0xFFFFD700),
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            if (roleLevel > 0)
              Container(
                margin: const EdgeInsets.only(left: 8),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.purple.withOpacity(0.12),
                  border: Border.all(color: Colors.purple.withOpacity(0.2)),
                ),
                child: Text(
                  'LV.$roleLevel',
                  style: const TextStyle(
                    color: Colors.purpleAccent,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: _C.border.withOpacity(0.2),
            border: Border.all(color: _C.border.withOpacity(0.3)),
          ),
          child: Text(
            roleDuration,
            style: TextStyle(
              color: _C.textSub,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  // ─── Neo Info Grid ──────────────────────────────────────────────────────
  Widget _buildNeoInfoGrid() {
    return FadeTransition(
      opacity: _cardEntrance,
      child: GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 1.3,
        children: [
          _buildNeoInfoCard(
            icon: Icons.person_outline_rounded,
            label: "USERNAME",
            value: _censorText(widget.username),
            gradient: LinearGradient(
              colors: [roleColor, roleColor.withOpacity(0.7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          _buildNeoInfoCard(
            icon: Icons.lock_outline_rounded,
            label: "PASSWORD",
            value: _censorText(widget.password, isPassword: true),
            gradient: _C.accentGrad,
          ),
          _buildNeoInfoCard(
            icon: Icons.verified_user_rounded,
            label: "ROLE",
            value: roleDisplay,
            gradient: LinearGradient(
              colors: [roleColor, roleColor.withOpacity(0.7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          _buildNeoInfoCard(
            icon: Icons.calendar_today_rounded,
            label: "EXPIRY",
            value: widget.expiredDate,
            gradient: const LinearGradient(
              colors: [_C.amber, _C.red],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNeoInfoCard({
    required IconData icon,
    required String label,
    required String value,
    required Gradient gradient,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: _C.cardGrad,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: _C.border.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: gradient,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: roleColor.withOpacity(0.15),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: _C.textSub,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              color: _C.text,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: -0.2,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  // ─── Neo Session Card ──────────────────────────────────────────────────
  Widget _buildNeoSessionCard() {
    return FadeTransition(
      opacity: _cardEntrance,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.card, _C.cardInner],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _C.border.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
              color: _C.border.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [roleColor, roleColor.withOpacity(0.7)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.vpn_key_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 12),
                const Text(
                  "SESSION KEY",
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.green.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.circle, color: _C.green, size: 6),
                      const SizedBox(width: 4),
                      const Text(
                        "ACTIVE",
                        style: TextStyle(
                          color: _C.green,
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.bg.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border.withOpacity(0.3)),
              ),
              child: SelectableText(
                widget.sessionKey,
                style: TextStyle(
                  color: roleColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'monospace',
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Neo Action Button ──────────────────────────────────────────────────
  Widget _buildNeoActionButton() {
    return FadeTransition(
      opacity: _cardEntrance,
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: ElevatedButton.icon(
          icon: const Icon(
            Icons.lock_reset_rounded,
            color: Colors.white,
            size: 20,
          ),
          label: const Text(
            "CHANGE PASSWORD",
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: roleColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 0,
          ).copyWith(
            backgroundColor: WidgetStateProperty.all(roleColor),
            overlayColor: WidgetStateProperty.all(Colors.white.withOpacity(0.1)),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChangePasswordPage(
                  username: widget.username,
                  sessionKey: widget.sessionKey,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}