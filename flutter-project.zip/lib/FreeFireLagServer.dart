import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FreeFireLagServerPage extends StatefulWidget {
  const FreeFireLagServerPage({super.key});

  @override
  State<FreeFireLagServerPage> createState() => _FreeFireLagServerPageState();
}

class _FreeFireLagServerPageState extends State<FreeFireLagServerPage> {
  bool _isAttacking = false;
  int _packetCount = 0;
  int _packetPerSecond = 0;
  Timer? _attackTimer;
  Timer? _statsTimer;
  Timer? _logTimer;
  final List<String> _attackLogs = [];
  final ScrollController _scrollController = ScrollController();

  final List<Map<String, dynamic>> _servers = [
    {'name': 'SG Server 1', 'ip': '203.116.115.10'},
    {'name': 'SG Server 2', 'ip': '203.116.115.11'},
    {'name': 'ID Server 1', 'ip': '47.246.0.10'},
    {'name': 'ID Server 2', 'ip': '47.246.0.11'},
    {'name': 'MY Server 1', 'ip': '103.219.76.10'},
    {'name': 'MY Server 2', 'ip': '103.219.76.11'},
  ];

  void _startAttack() {
    if (_isAttacking) return;

    setState(() {
      _isAttacking = true;
      _packetCount = 0;
      _packetPerSecond = 0;
      _attackLogs.clear();
    });

    HapticFeedback.heavyImpact();

    // Simulasi packet
    _attackTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      setState(() {
        _packetCount += Random().nextInt(150) + 50;
        _packetPerSecond += Random().nextInt(100) + 30;
      });
    });

    // Reset PPS setiap detik
    _statsTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      setState(() {
        _packetPerSecond = 0;
      });
    });

    // Log setiap 700ms
    _logTimer = Timer.periodic(const Duration(milliseconds: 700), (timer) {
      if (!_isAttacking) { timer.cancel(); return; }
      final server = _servers[Random().nextInt(_servers.length)];
      _attackLogs.insert(0, '${DateTime.now().toLocal().toString().substring(11, 19)} → ${server['name']} (${server['ip']})');
      if (_attackLogs.length > 25) _attackLogs.removeLast();
      if (_scrollController.hasClients) {
        _scrollController.animateTo(0, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _stopAttack() {
    if (!_isAttacking) return;
    setState(() => _isAttacking = false);
    HapticFeedback.lightImpact();
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _attackTimer = null;
    _statsTimer = null;
    _logTimer = null;
  }

  @override
  void dispose() {
    _attackTimer?.cancel();
    _statsTimer?.cancel();
    _logTimer?.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        title: const Text(
          '🎯 FF LAG SERVER',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: Colors.red.shade900,
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: (_isAttacking ? Colors.red : Colors.green).withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: (_isAttacking ? Colors.red : Colors.green).withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _isAttacking ? Colors.red : Colors.green,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: (_isAttacking ? Colors.red : Colors.green).withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _isAttacking ? 'ON' : 'OFF',
                  style: TextStyle(
                    color: _isAttacking ? Colors.red : Colors.green,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.red.shade900, Colors.orange.shade900],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withOpacity(0.2)),
                  ),
                  child: Icon(
                    _isAttacking ? Icons.whatshot : Icons.flash_off,
                    size: 32,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _isAttacking ? '🔥 ATTACKING...' : '⚡ READY',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _isAttacking
                            ? '${_servers.length} server targets'
                            : 'Tekan START untuk memulai',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            color: const Color(0xFF1A1A1A),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStat('📦 PACKETS', '$_packetCount', Colors.cyan),
                _buildStat('⚡ PPS', '$_packetPerSecond', Colors.green),
                _buildStat('🎯 TARGET', '${_servers.length}', Colors.yellow),
              ],
            ),
          ),

          if (_isAttacking)
            Container(
              height: 3,
              color: Colors.grey.shade900,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: MediaQuery.of(context).size.width * ((_packetCount % 10000) / 10000),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.red, Colors.orange, Colors.yellow],
                  ),
                ),
              ),
            ),

          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              color: const Color(0xFF111111),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '📡 LIVE LOGS',
                        style: TextStyle(
                          color: Colors.white54,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                      Text(
                        '${_attackLogs.length} entries',
                        style: TextStyle(color: Colors.white38, fontSize: 10),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _attackLogs.isEmpty
                        ? Center(
                            child: Text(
                              _isAttacking ? '⏳ Menunggu packet...' : '💤 Belum ada aktivitas',
                              style: TextStyle(color: Colors.white38, fontSize: 12),
                            ),
                          )
                        : ListView.builder(
                            controller: _scrollController,
                            reverse: true,
                            itemCount: _attackLogs.length,
                            itemBuilder: (context, index) {
                              final log = _attackLogs[index];
                              final isNew = index == 0;
                              return Container(
                                margin: const EdgeInsets.symmetric(vertical: 1.5),
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: isNew ? Colors.red.withOpacity(0.12) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(4),
                                  border: isNew ? Border.all(color: Colors.red.withOpacity(0.2)) : null,
                                ),
                                child: Row(
                                  children: [
                                    if (isNew)
                                      Container(
                                        width: 6,
                                        height: 6,
                                        margin: const EdgeInsets.only(right: 8),
                                        decoration: const BoxDecoration(
                                          color: Colors.red,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    Text(
                                      log,
                                      style: TextStyle(
                                        color: isNew ? Colors.orange : Colors.white54,
                                        fontSize: 11,
                                        fontFamily: 'monospace',
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),

          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              border: Border(top: BorderSide(color: Colors.grey.shade800)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isAttacking ? null : _startAttack,
                    icon: const Icon(Icons.play_arrow, size: 28),
                    label: const Text(
                      'START',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade700,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 8,
                      shadowColor: Colors.red.withOpacity(0.4),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isAttacking ? _stopAttack : null,
                    icon: const Icon(Icons.stop, size: 28),
                    label: const Text(
                      'STOP',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1.5),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isAttacking ? Colors.grey.shade700 : Colors.grey.shade900,
                      foregroundColor: _isAttacking ? Colors.white : Colors.white38,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
          ),
        ),
        Text(
          label,
          style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }
}