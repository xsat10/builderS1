/// ===============================================================
/// NAVBAR VISUAL REFERENCE
/// ===============================================================
///
/// TARGET DESIGN:
/// Compact floating glass bottom navigation.
///
/// IMPORTANT:
/// This file is a DESIGN REFERENCE, not necessarily production code.
///
/// DO NOT reproduce the current large U-shaped notch.
///
/// ---------------------------------------------------------------
/// LAYOUT
/// ---------------------------------------------------------------
///
/// Screen:
/// ┌──────────────────────────────────────────┐
/// │                                          │
/// │                 CONTENT                  │
/// │                                          │
/// │                                          │
/// ├──────────────────────────────────────────┤
/// │       HOME     GRADIENTS    BADGES       │
/// │         ●                               │
/// │      active                              │
/// └──────────────────────────────────────────┘
///
/// Navbar:
/// - compact
/// - bottom aligned
/// - approximately 70-80 logical pixels tall
/// - floating circular active button
/// - active button extends above navbar
/// - small curved cutout around active button
/// - NO large U-shaped hole
///
/// ACTIVE BUTTON:
/// - circular
/// - approximately 56-64 logical pixels
/// - centered horizontally inside selected navigation item
/// - elevated above navbar
/// - icon centered inside circle
///
/// NOTCH:
/// - must closely follow the circumference of active button
/// - shallow and compact
/// - smooth Bézier curves
/// - symmetric left/right
/// - must NOT descend halfway into navbar
///
/// LABEL:
/// - inactive items have icon + label
/// - active item icon is inside floating circle
/// - label remains aligned below/near active item
///
/// ---------------------------------------------------------------
/// FORBIDDEN RESULT
/// ---------------------------------------------------------------
///
/// NEVER produce:
///
///       _________        _________
///               \        /
///                \      /
///                 \____/
///
/// where the notch occupies a huge portion of navbar.
///
/// This is the WRONG DESIGN.
///
/// ---------------------------------------------------------------
/// DESIRED RESULT
/// ---------------------------------------------------------------
///
///          ( ACTIVE )
///             ●
///        ____/   \____
///       |             |
///       |   navigation|
///       |_____________|
///
/// The floating circle should visually "sit" in a
/// small pocket/notch, not inside a giant U-shaped cavity.
///
/// ---------------------------------------------------------------
/// IMPLEMENTATION REQUIREMENTS
/// ---------------------------------------------------------------
///
/// 1. Preserve existing navigation functionality.
/// 2. Preserve selected index.
/// 3. Preserve badges.
/// 4. Preserve animation.
/// 5. Preserve theme support.
/// 6. Make geometry responsive to item count.
/// 7. Do not use arbitrary fixed geometry that causes oversized notch.
/// 8. Calculate notch relative to floating button diameter.
/// 9. Floating button and notch must use the same center position.
/// 10. Verify Android rendering.
/// 11. Verify iOS rendering.
/// 12. Verify with 4 and 5 navigation items.
///
/// ===============================================================

import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Theme data for [GlazeNavBar].
///
/// Use this to customize the appearance of all [GlazeNavBar] widgets
/// in your app through the theme system.
///
/// Example:
/// ```dart
/// MaterialApp(
///   theme: ThemeData(
///     extensions: [
///       GlazeNavBarThemeData(
///         color: Colors.purple,
///         glassBlur: 25,
///       ),
///     ],
///   ),
/// )
/// ```
@immutable
class GlazeNavBarThemeData extends ThemeExtension<GlazeNavBarThemeData> {
  /// Creates a theme data for [GlazeNavBar].
  const GlazeNavBarThemeData({
    this.color,
    this.buttonBackgroundColor,
    this.backgroundColor,
    this.gradient,
    this.buttonGradient,
    this.glassBorderColor,
    this.buttonBorderColor,
    this.glassBlur,
    this.glassOpacity,
    this.glassBorderRadius,
    this.glassBorderWidth,
    this.buttonBorderWidth,
    this.height,
    this.iconPadding,
    this.animationDuration,
    this.animationCurve,
  });

  /// Creates a light theme for [GlazeNavBar].
  ///
  /// This theme uses light colors suitable for light mode apps.
  ///
  /// Example:
  /// ```dart
  /// MaterialApp(
  ///   theme: ThemeData.light().copyWith(
  ///     extensions: [GlazeNavBarThemeData.light()],
  ///   ),
  /// )
  /// ```
  factory GlazeNavBarThemeData.light() {
    return const GlazeNavBarThemeData(
      color: Color(0xFF4A90E2), // Vibrant blue
      buttonBackgroundColor: Color(0xFF5BA3F5), // Lighter blue for button
      backgroundColor: Color(0xFFFFFFFF), // Solid white background
      glassBorderColor: Color(0x66FFFFFF), // More visible border
      buttonBorderColor: Color(0xFFFFFFFF), // White border for button
      glassBlur: 15,
      glassOpacity: 0.35, // More opaque for better visibility
      glassBorderRadius: 0,
      glassBorderWidth: 2.0, // Thicker border
      buttonBorderWidth: 3.0,
      height: 75.0,
      iconPadding: 12.0,
      animationDuration: Duration(milliseconds: 600),
      animationCurve: Curves.easeOut,
    );
  }

  /// Creates a dark theme for [GlazeNavBar].
  ///
  /// This theme uses dark colors suitable for dark mode apps.
  ///
  /// Example:
  /// ```dart
  /// MaterialApp(
  ///   darkTheme: ThemeData.dark().copyWith(
  ///     extensions: [GlazeNavBarThemeData.dark()],
  ///   ),
  /// )
  /// ```
  factory GlazeNavBarThemeData.dark() {
    return const GlazeNavBarThemeData(
      color: Color(0xFF1E1E1E),
      buttonBackgroundColor: Color(0xFF2D2D2D),
      backgroundColor: Color(0xFF1E1E1E),
      glassBorderColor: Color(0x33FFFFFF),
      buttonBorderColor: Color(0x4DFFFFFF),
      glassBlur: 25,
      glassOpacity: 0.15,
      glassBorderRadius: 0,
      glassBorderWidth: 1.0,
      buttonBorderWidth: 2.5,
      height: 75.0,
      iconPadding: 12.0,
      animationDuration: Duration(milliseconds: 600),
      animationCurve: Curves.easeOut,
    );
  }

  /// The primary color of the navigation bar.
  final Color? color;

  /// Background color of the floating button.
  final Color? buttonBackgroundColor;

  /// Background color behind the navigation bar.
  final Color? backgroundColor;

  /// Gradient for the navigation bar (overrides [color]).
  final Gradient? gradient;

  /// Gradient for the floating button.
  final Gradient? buttonGradient;

  /// Border color for the glass effect.
  final Color? glassBorderColor;

  /// Border color for the floating button.
  final Color? buttonBorderColor;

  /// Blur intensity for the glass effect.
  final double? glassBlur;

  /// Opacity of the glass background.
  final double? glassOpacity;

  /// Border radius for the glass effect.
  final double? glassBorderRadius;

  /// Border width for the glass effect.
  final double? glassBorderWidth;

  /// Border width for the floating button.
  final double? buttonBorderWidth;

  /// Height of the navigation bar.
  final double? height;

  /// Padding around the floating icon.
  final double? iconPadding;

  /// Duration of animations.
  final Duration? animationDuration;

  /// Curve for animations.
  final Curve? animationCurve;

  @override
  GlazeNavBarThemeData copyWith({
    Color? color,
    Color? buttonBackgroundColor,
    Color? backgroundColor,
    Gradient? gradient,
    Gradient? buttonGradient,
    Color? glassBorderColor,
    Color? buttonBorderColor,
    double? glassBlur,
    double? glassOpacity,
    double? glassBorderRadius,
    double? glassBorderWidth,
    double? buttonBorderWidth,
    double? height,
    double? iconPadding,
    Duration? animationDuration,
    Curve? animationCurve,
  }) {
    return GlazeNavBarThemeData(
      color: color ?? this.color,
      buttonBackgroundColor:
          buttonBackgroundColor ?? this.buttonBackgroundColor,
      backgroundColor: backgroundColor ?? this.backgroundColor,
      gradient: gradient ?? this.gradient,
      buttonGradient: buttonGradient ?? this.buttonGradient,
      glassBorderColor: glassBorderColor ?? this.glassBorderColor,
      buttonBorderColor: buttonBorderColor ?? this.buttonBorderColor,
      glassBlur: glassBlur ?? this.glassBlur,
      glassOpacity: glassOpacity ?? this.glassOpacity,
      glassBorderRadius: glassBorderRadius ?? this.glassBorderRadius,
      glassBorderWidth: glassBorderWidth ?? this.glassBorderWidth,
      buttonBorderWidth: buttonBorderWidth ?? this.buttonBorderWidth,
      height: height ?? this.height,
      iconPadding: iconPadding ?? this.iconPadding,
      animationDuration: animationDuration ?? this.animationDuration,
      animationCurve: animationCurve ?? this.animationCurve,
    );
  }

  @override
  GlazeNavBarThemeData lerp(GlazeNavBarThemeData? other, double t) {
    if (other is! GlazeNavBarThemeData) return this;
    return GlazeNavBarThemeData(
      color: Color.lerp(color, other.color, t),
      buttonBackgroundColor:
          Color.lerp(buttonBackgroundColor, other.buttonBackgroundColor, t),
      backgroundColor: Color.lerp(backgroundColor, other.backgroundColor, t),
      gradient: Gradient.lerp(gradient, other.gradient, t),
      buttonGradient: Gradient.lerp(buttonGradient, other.buttonGradient, t),
      glassBorderColor: Color.lerp(glassBorderColor, other.glassBorderColor, t),
      buttonBorderColor:
          Color.lerp(buttonBorderColor, other.buttonBorderColor, t),
      glassBlur: lerpDouble(glassBlur, other.glassBlur, t),
      glassOpacity: lerpDouble(glassOpacity, other.glassOpacity, t),
      glassBorderRadius:
          lerpDouble(glassBorderRadius, other.glassBorderRadius, t),
      glassBorderWidth: lerpDouble(glassBorderWidth, other.glassBorderWidth, t),
      buttonBorderWidth:
          lerpDouble(buttonBorderWidth, other.buttonBorderWidth, t),
      height: lerpDouble(height, other.height, t),
      iconPadding: lerpDouble(iconPadding, other.iconPadding, t),
      animationDuration: t < 0.5 ? animationDuration : other.animationDuration,
      animationCurve: t < 0.5 ? animationCurve : other.animationCurve,
    );
  }

  /// Resolves the theme data with fallbacks from [ThemeData].
  ///
  /// This method provides sensible defaults based on the current theme
  /// brightness (light or dark mode) when specific values are not set.
  ///
  /// The resolved values will automatically adapt to the app's theme mode.
  GlazeNavBarThemeData resolve(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    // Get default theme based on brightness
    final defaults =
        isDark ? GlazeNavBarThemeData.dark() : GlazeNavBarThemeData.light();

    return GlazeNavBarThemeData(
      color: color ?? defaults.color ?? colorScheme.surface,
      buttonBackgroundColor: buttonBackgroundColor ??
          defaults.buttonBackgroundColor ??
          colorScheme.primaryContainer,
      backgroundColor: backgroundColor ?? defaults.backgroundColor,
      gradient: gradient ?? defaults.gradient,
      buttonGradient: buttonGradient ?? defaults.buttonGradient,
      glassBorderColor: glassBorderColor ??
          defaults.glassBorderColor ??
          colorScheme.outline.withValues(alpha: isDark ? 0.2 : 0.3),
      buttonBorderColor: buttonBorderColor ??
          defaults.buttonBorderColor ??
          colorScheme.outline.withValues(alpha: isDark ? 0.3 : 0.5),
      glassBlur: glassBlur ?? defaults.glassBlur,
      glassOpacity: glassOpacity ?? defaults.glassOpacity,
      glassBorderRadius: glassBorderRadius ?? defaults.glassBorderRadius,
      glassBorderWidth: glassBorderWidth ?? defaults.glassBorderWidth,
      buttonBorderWidth: buttonBorderWidth ?? defaults.buttonBorderWidth,
      height: height ?? defaults.height,
      iconPadding: iconPadding ?? defaults.iconPadding,
      animationDuration: animationDuration ?? defaults.animationDuration,
      animationCurve: animationCurve ?? defaults.animationCurve,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other.runtimeType != runtimeType) return false;
    return other is GlazeNavBarThemeData &&
        other.color == color &&
        other.buttonBackgroundColor == buttonBackgroundColor &&
        other.backgroundColor == backgroundColor &&
        other.gradient == gradient &&
        other.buttonGradient == buttonGradient &&
        other.glassBorderColor == glassBorderColor &&
        other.buttonBorderColor == buttonBorderColor &&
        other.glassBlur == glassBlur &&
        other.glassOpacity == glassOpacity &&
        other.glassBorderRadius == glassBorderRadius &&
        other.glassBorderWidth == glassBorderWidth &&
        other.buttonBorderWidth == buttonBorderWidth &&
        other.height == height &&
        other.iconPadding == iconPadding &&
        other.animationDuration == animationDuration &&
        other.animationCurve == animationCurve;
  }

  @override
  int get hashCode => Object.hash(
        color,
        buttonBackgroundColor,
        backgroundColor,
        gradient,
        buttonGradient,
        glassBorderColor,
        buttonBorderColor,
        glassBlur,
        glassOpacity,
        glassBorderRadius,
        glassBorderWidth,
        buttonBorderWidth,
        height,
        iconPadding,
        animationDuration,
        animationCurve,
      );
}

/// An inherited widget that provides [GlazeNavBarThemeData] to its descendants.
///
/// This allows you to theme [GlazeNavBar] widgets in a subtree without
/// using [ThemeExtension].
class GlazeNavBarTheme extends InheritedTheme {
  /// Creates a [GlazeNavBarTheme].
  const GlazeNavBarTheme({
    super.key,
    required this.data,
    required super.child,
  });

  /// The theme data for [GlazeNavBar] widgets.
  final GlazeNavBarThemeData data;

  /// Returns the [GlazeNavBarThemeData] from the closest [GlazeNavBarTheme]
  /// ancestor, or from the [ThemeData.extensions] if no ancestor is found.
  ///
  /// Returns `null` if no theme data is available.
  static GlazeNavBarThemeData? maybeOf(BuildContext context) {
    final theme =
        context.dependOnInheritedWidgetOfExactType<GlazeNavBarTheme>();
    return theme?.data ?? Theme.of(context).extension<GlazeNavBarThemeData>();
  }

  /// Returns the [GlazeNavBarThemeData] from the closest [GlazeNavBarTheme]
  /// ancestor, from [ThemeData.extensions], or a default theme if none is found.
  static GlazeNavBarThemeData of(BuildContext context) {
    return maybeOf(context) ?? const GlazeNavBarThemeData();
  }

  @override
  bool updateShouldNotify(GlazeNavBarTheme oldWidget) => data != oldWidget.data;

  @override
  Widget wrap(BuildContext context, Widget child) {
    return GlazeNavBarTheme(data: data, child: child);
  }
}

import 'package:flutter/material.dart';

class GlazeNavBarItem {
  final Widget child;
  final String? label;
  final TextStyle? labelStyle;
  final int? badgeCount;
  final Color? badgeColor;
  final Color? badgeTextColor;
  final Color? activeBadgeColor;
  final Color? activeBadgeTextColor;
  final bool showBadge;

  const GlazeNavBarItem({
    required this.child,
    this.label,
    this.labelStyle,
    this.badgeCount,
    this.badgeColor,
    this.badgeTextColor,
    this.activeBadgeColor,
    this.activeBadgeTextColor,
    this.showBadge = false,
  });
}

import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

import 'glaze_nav_bar_item.dart';
import 'glaze_nav_bar_theme.dart';
import 'src/nav_bar_item_widget.dart';
import 'src/nav_custom_clipper.dart';

export 'glaze_nav_bar_item.dart';
export 'glaze_nav_bar_theme.dart';

typedef _LetIndexPage = bool Function(int value);

/// A stunning glassmorphic bottom navigation bar with gradient support,
/// smooth animations, and modern design.
///
/// The bar consists of a curved shape with a floating button that
/// moves to the selected item with smooth animations.
///
/// Example usage:
/// ```dart
/// GlazeNavBar(
///   items: [
///     GlazeNavBarItem(child: Icon(Icons.home), label: 'Home'),
///     GlazeNavBarItem(child: Icon(Icons.search), label: 'Search'),
///     GlazeNavBarItem(child: Icon(Icons.settings), label: 'Settings'),
///   ],
///   onTap: (index) => setState(() => _currentIndex = index),
/// )
/// ```
class GlazeNavBar extends StatefulWidget {
  final List<GlazeNavBarItem> items;
  final int index;
  final Color? color;
  final Color? buttonBackgroundColor;
  final Gradient? gradient;
  final Gradient? buttonGradient;
  final Color? backgroundColor;
  final ValueChanged<int>? onTap;
  final _LetIndexPage letIndexChange;
  final Curve? animationCurve;
  final Duration? animationDuration;
  final double? height;
  final double? maxWidth;
  final double? iconPadding;
  final bool hasLabel;
  final double? glassBlur;
  final double? glassOpacity;
  final double? glassBorderRadius;
  final double? glassBorderWidth;
  final Color? glassBorderColor;
  final Color? buttonBorderColor;
  final double? buttonBorderWidth;

  GlazeNavBar({
    Key? key,
    required this.items,
    this.index = 0,
    this.color,
    this.buttonBackgroundColor,
    this.backgroundColor,
    this.onTap,
    this.gradient,
    this.buttonGradient,
    _LetIndexPage? letIndexChange,
    this.animationCurve,
    this.animationDuration,
    this.iconPadding,
    this.maxWidth,
    this.glassBlur,
    this.glassOpacity,
    this.glassBorderRadius,
    this.glassBorderWidth,
    this.glassBorderColor,
    this.buttonBorderColor,
    this.buttonBorderWidth,
    this.height,
  })  : letIndexChange = letIndexChange ?? ((_) => true),
        assert(items.isNotEmpty),
        assert(0 <= index && index < items.length),
        assert(maxWidth == null || 0 <= maxWidth),
        hasLabel = items.any((item) => item.label != null),
        super(key: key);

  @override
  GlazeNavBarState createState() => GlazeNavBarState();
}

class GlazeNavBarState extends State<GlazeNavBar>
    with SingleTickerProviderStateMixin {
  late double _startingPos;
  late int _endingIndex;
  late double _pos;
  late Widget _icon;
  late AnimationController _animationController;
  late int _length;
  double _buttonHide = 0;

  @override
  void initState() {
    super.initState();
    _icon = widget.items[widget.index].child;
    _length = widget.items.length;
    _pos = widget.index / _length;
    _startingPos = widget.index / _length;
    _endingIndex = widget.index;
    _animationController = AnimationController(vsync: this, value: _pos);
    _animationController.addListener(() {
      setState(() {
        _pos = _animationController.value.clamp(0.0, 1.0);
        final endingPos = _endingIndex / widget.items.length;
        final middle = (endingPos + _startingPos) / 2;
        if ((endingPos - _pos).abs() < (_startingPos - _pos).abs()) {
          _icon = widget.items[_endingIndex].child;
        }
        // Prevent division by zero and NaN values
        final denominator = _startingPos - middle;
        if (denominator.abs() < 0.0001) {
          _buttonHide = 1.0;
        } else {
          _buttonHide =
              (1 - ((middle - _pos) / denominator).abs()).abs().clamp(0.0, 1.0);
        }
      });
    });
  }

  @override
  void didUpdateWidget(GlazeNavBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index != widget.index) {
      final newPosition = widget.index / _length;
      _startingPos = _pos;
      _endingIndex = widget.index;
      final theme = GlazeNavBarTheme.of(context).resolve(context);
      _animationController.animateTo(
        newPosition,
        duration: widget.animationDuration ?? theme.animationDuration!,
        curve: widget.animationCurve ?? theme.animationCurve!,
      );
    }
    if (!_animationController.isAnimating) {
      _icon = widget.items[_endingIndex].child;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Resolve theme data
    final theme = GlazeNavBarTheme.of(context).resolve(context);

    // Resolve values
    final effectiveColor = widget.color ?? theme.color!;
    final effectiveButtonBackgroundColor =
        widget.buttonBackgroundColor ?? theme.buttonBackgroundColor;
    final effectiveBackgroundColor =
        widget.backgroundColor ?? theme.backgroundColor!;
    final effectiveGradient = widget.gradient ?? theme.gradient;
    final effectiveButtonGradient =
        widget.buttonGradient ?? theme.buttonGradient;
    final effectiveGlassBorderColor =
        widget.glassBorderColor ?? theme.glassBorderColor!;
    final effectiveButtonBorderColor =
        widget.buttonBorderColor ?? theme.buttonBorderColor!;
    final effectiveGlassBlur = widget.glassBlur ?? theme.glassBlur!;
    final effectiveGlassOpacity = widget.glassOpacity ?? theme.glassOpacity!;
    final effectiveGlassBorderRadius =
        widget.glassBorderRadius ?? theme.glassBorderRadius!;
    final effectiveGlassBorderWidth =
        widget.glassBorderWidth ?? theme.glassBorderWidth!;
    final effectiveButtonBorderWidth =
        widget.buttonBorderWidth ?? theme.buttonBorderWidth!;
    final effectiveHeight = widget.height ?? theme.height!;
    final effectiveIconPadding = widget.iconPadding ?? theme.iconPadding!;

    final textDirection = Directionality.of(context);
    return SizedBox(
      height: effectiveHeight,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final maxWidth = min(
            constraints.maxWidth,
            widget.maxWidth ?? constraints.maxWidth,
          );
          return Align(
            alignment: textDirection == TextDirection.ltr
                ? Alignment.bottomLeft
                : Alignment.bottomRight,
            child: Container(
              color: effectiveBackgroundColor,
              width: maxWidth,
              child: ClipRect(
                clipper: NavCustomClipper(
                  deviceHeight: MediaQuery.sizeOf(context).height,
                ),
                child: Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.bottomCenter,
                  children: <Widget>[
                    // Floating button
                    Positioned(
                      bottom: effectiveHeight - 105.0,
                      left: textDirection == TextDirection.rtl
                          ? null
                          : (_pos * maxWidth).clamp(0.0, maxWidth),
                      right: textDirection == TextDirection.rtl
                          ? (_pos * maxWidth).clamp(0.0, maxWidth)
                          : null,
                      width: maxWidth / _length,
                      child: Center(
                        child: Transform.translate(
                          offset: Offset(
                              0,
                              ((_buttonHide.isNaN ? 1.0 : _buttonHide) - 1) *
                                  80),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: effectiveButtonGradient,
                              color: effectiveButtonGradient == null
                                  ? (effectiveButtonBackgroundColor ??
                                      effectiveColor)
                                  : null,
                              border: Border.all(
                                color: effectiveButtonBorderColor,
                                width: effectiveButtonBorderWidth,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.1),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Material(
                              color: Colors.transparent,
                              type: MaterialType.circle,
                              child: Padding(
                                padding: EdgeInsets.all(effectiveIconPadding),
                                child: _buildFloatingIcon(),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Glassmorphism Background
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: ClipPath(
                        clipper: _NavBarClipper(
                          startingLoc: _pos,
                          itemsLength: _length,
                          hasLabel: widget.hasLabel,
                          textDirection: Directionality.of(context),
                          height: effectiveHeight,
                          isAndroid: Theme.of(context).platform ==
                              TargetPlatform.android,
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: effectiveGlassBlur,
                            sigmaY: effectiveGlassBlur,
                          ),
                          child: Container(
                            width: maxWidth,
                            height: effectiveHeight,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                effectiveGlassBorderRadius,
                              ),
                              gradient: effectiveGradient as LinearGradient? ??
                                  LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      effectiveColor.withValues(
                                          alpha: effectiveGlassOpacity),
                                      effectiveColor.withValues(
                                          alpha: effectiveGlassOpacity * 0.5),
                                    ],
                                    stops: const [0.1, 1],
                                  ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Border stroke on top of glassmorphism
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: IgnorePointer(
                        child: CustomPaint(
                          size: Size(maxWidth, effectiveHeight),
                          painter: _NavBarBorderPainter(
                            startingLoc: _pos,
                            itemsLength: _length,
                            hasLabel: widget.hasLabel,
                            textDirection: Directionality.of(context),
                            borderColor: effectiveGlassBorderColor,
                            borderWidth: effectiveGlassBorderWidth,
                            isAndroid: Theme.of(context).platform ==
                                TargetPlatform.android,
                          ),
                        ),
                      ),
                    ),
                    // Navigation items
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: SizedBox(
                        height: effectiveHeight,
                        child: Row(
                          children: widget.items.map((item) {
                            return NavBarItemWidget(
                              onTap: _buttonTap,
                              position: _pos,
                              length: _length,
                              index: widget.items.indexOf(item),
                              label: item.label,
                              labelStyle: item.labelStyle,
                              badgeCount: item.badgeCount,
                              badgeColor: item.badgeColor,
                              badgeTextColor: item.badgeTextColor,
                              activeBadgeColor: item.activeBadgeColor,
                              activeBadgeTextColor: item.activeBadgeTextColor,
                              showBadge: item.showBadge,
                              child: item.child,
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  /// Builds the floating button icon with badge if applicable.
  Widget _buildFloatingIcon() {
    final item = widget.items[_endingIndex];

    // If no badge count and showBadge is false, return just the icon
    if ((item.badgeCount == null || item.badgeCount == 0) && !item.showBadge) {
      return _icon;
    }

    // Get active colors (floating button is always the active item)
    final bgColor = item.activeBadgeColor ?? item.badgeColor ?? Colors.red;
    final txtColor =
        item.activeBadgeTextColor ?? item.badgeTextColor ?? Colors.white;

    if (item.showBadge && (item.badgeCount == null || item.badgeCount == 0)) {
      // Show dot badge
      return Badge(
        alignment: Alignment.topRight,
        backgroundColor: bgColor,
        smallSize: 8,
        child: _icon,
      );
    }

    // Show count badge
    return Badge.count(
      count: item.badgeCount!,
      alignment: Alignment.topRight,
      textColor: txtColor,
      backgroundColor: bgColor,
      child: _icon,
    );
  }

  /// Programmatically sets the current page index.
  void setPage(int index) {
    _buttonTap(index);
  }

  void _buttonTap(int index) {
    if (!widget.letIndexChange(index) || _animationController.isAnimating) {
      return;
    }
    if (widget.onTap != null) {
      widget.onTap!(index);
    }
    final newPosition = index / _length;
    final theme = GlazeNavBarTheme.of(context).resolve(context);
    setState(() {
      _startingPos = _pos;
      _endingIndex = index;
      _animationController.animateTo(
        newPosition,
        duration: widget.animationDuration ?? theme.animationDuration!,
        curve: widget.animationCurve ?? theme.animationCurve!,
      );
    });
  }
}

/// Custom clipper for the navigation bar glass effect.
class _NavBarClipper extends CustomClipper<Path> {
  final double startingLoc;
  final int itemsLength;
  final bool hasLabel;
  final TextDirection textDirection;
  final double height;
  final bool isAndroid;

  _NavBarClipper({
    required this.startingLoc,
    required this.itemsLength,
    required this.hasLabel,
    required this.textDirection,
    required this.height,
    required this.isAndroid,
  });

  @override
  Path getClip(Size size) {
    // Guard against invalid size
    if (size.width <= 0 || size.height <= 0) {
      return Path()..addRect(Rect.zero);
    }

    const s = 0.2;
    final span = 1.0 / itemsLength;
    final l = startingLoc + (span - s) / 2;
    // Clamp loc to valid range to prevent geometry errors
    final loc =
        (textDirection == TextDirection.rtl ? 0.8 - l : l).clamp(0.0, 1.0 - s);
    final bottom =
        hasLabel ? (isAndroid ? 0.55 : 0.45) : (isAndroid ? 0.6 : 0.5);

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width * (loc - 0.05).clamp(0.0, 1.0), 0)
      ..cubicTo(
        size.width * (loc + s * 0.2).clamp(0.0, 1.0),
        size.height * 0.05,
        size.width * loc.clamp(0.0, 1.0),
        size.height * bottom,
        size.width * (loc + s * 0.5).clamp(0.0, 1.0),
        size.height * bottom,
      )
      ..cubicTo(
        size.width * (loc + s).clamp(0.0, 1.0),
        size.height * bottom,
        size.width * (loc + s * 0.8).clamp(0.0, 1.0),
        size.height * 0.05,
        size.width * (loc + s + 0.05).clamp(0.0, 1.0),
        0,
      )
      ..lineTo(size.width, 0)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    return path;
  }

  @override
  bool shouldReclip(_NavBarClipper oldClipper) {
    return startingLoc != oldClipper.startingLoc ||
        itemsLength != oldClipper.itemsLength ||
        hasLabel != oldClipper.hasLabel ||
        isAndroid != oldClipper.isAndroid;
  }
}

/// Custom painter for drawing border on the navigation bar.
class _NavBarBorderPainter extends CustomPainter {
  final double startingLoc;
  final int itemsLength;
  final bool hasLabel;
  final TextDirection textDirection;
  final Color borderColor;
  final double borderWidth;
  final bool isAndroid;

  _NavBarBorderPainter({
    required this.startingLoc,
    required this.itemsLength,
    required this.hasLabel,
    required this.textDirection,
    required this.borderColor,
    required this.borderWidth,
    required this.isAndroid,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Guard against invalid size
    if (size.width <= 0 || size.height <= 0) return;

    const s = 0.2;
    final span = 1.0 / itemsLength;
    final l = startingLoc + (span - s) / 2;
    // Clamp loc to valid range to prevent geometry errors
    final loc =
        (textDirection == TextDirection.rtl ? 0.8 - l : l).clamp(0.0, 1.0 - s);
    final bottom =
        hasLabel ? (isAndroid ? 0.55 : 0.45) : (isAndroid ? 0.6 : 0.5);

    final paint = Paint()
      ..color = borderColor
      ..strokeWidth = borderWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width * (loc - 0.05).clamp(0.0, 1.0), 0)
      ..cubicTo(
        size.width * (loc + s * 0.2).clamp(0.0, 1.0),
        size.height * 0.05,
        size.width * loc.clamp(0.0, 1.0),
        size.height * bottom,
        size.width * (loc + s * 0.5).clamp(0.0, 1.0),
        size.height * bottom,
      )
      ..cubicTo(
        size.width * (loc + s).clamp(0.0, 1.0),
        size.height * bottom,
        size.width * (loc + s * 0.8).clamp(0.0, 1.0),
        size.height * 0.05,
        size.width * (loc + s + 0.05).clamp(0.0, 1.0),
        0,
      )
      ..lineTo(size.width, 0);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_NavBarBorderPainter oldDelegate) {
    return startingLoc != oldDelegate.startingLoc ||
        itemsLength != oldDelegate.itemsLength ||
        hasLabel != oldDelegate.hasLabel ||
        borderColor != oldDelegate.borderColor ||
        borderWidth != oldDelegate.borderWidth ||
        isAndroid != oldDelegate.isAndroid;
  }
}