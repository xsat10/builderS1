import 'dart:math';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'providers/theme_provider.dart';

// ╔══════════════════════════════════════════════════════════════════════════╗
// ║                    NOVACORE TEMPLATE — POLOSAN BASE                    ║
// ║              Theme · Cards · Stories · Chat · Ring · Spotify            ║
// ╚══════════════════════════════════════════════════════════════════════════╝

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 1: THEME / COLORS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class NcColors {
  NcColors._();

  static const Color background = Color(0xFF0B0D1F);
  static const Color surface = Color(0x1FFFFFFF);
  static const Color surfaceElevated = Color(0xFF1E1E2E);
  static const Color primaryText = Color(0xFFFFFFFF);
  static const Color secondaryText = Color(0xFFB8B8CF);
  static const Color border = Color(0x33FFFFFF);
  static const Color line = Color(0x44FFD98A);

  static const Color cream = Color(0xFFFFF9E8);
  static const Color black = Color(0xFF111111);
  static const Color yellow = Color(0xFFFFD900);
  static const Color pink = Color(0xFFFF5C8A);
  static const Color blue = Color(0xFF5B8CFF);
  static const Color green = Color(0xFF55E878);
  static const Color orange = Color(0xFFFF9F43);
  static const Color purple = Color(0xFF9B6BFF);
  static const Color white = Color(0xFFFFFFFF);
  static const Color grey = Color(0xFF888888);
  static const Color darkBg = Color(0xFF0B0D1F);
  static const Color darkCard = Color(0x22FFFFFF);

  static const Color gold = Color(0xFFFFD98A);
  static const Color goldBright = Color(0xFFF3D98A);
  static const Color goldDeep = Color(0xFFC6A15B);
  static const Color marble = Color(0xFFF2F0E6);
  static const Color royalPurple = Color(0xFF5B3E96);
  static const Color burgundy = Color(0xFF6B1F2A);

  static const Color developer = Color(0xFF9B6BFF);
  static const Color partner = Color(0xFFFF9F43);
  static const Color reseller = Color(0xFF36C5F0);
  static const Color member = Color(0xFFFF6B8A);
  static const Color vip = Color(0xFFFFD700);
  static const Color moderator = Color(0xFF3DD3A5);

  static Color roleColor(String role) {
    switch (role) {
      case 'developer': return developer;
      case 'partner': return partner;
      case 'reseller': return reseller;
      case 'member': return member;
      case 'vip': return vip;
      case 'moderator': return moderator;
      default: return grey;
    }
  }

  static const Map<String, IconData> roleIcon = {
    'developer': Icons.code,
    'partner': Icons.handshake,
    'reseller': Icons.storefront,
    'member': Icons.person,
    'vip': Icons.workspace_premium,
    'moderator': Icons.verified_user,
  };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ GLASSMORPHISM TOKENS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class NcGlass {
  NcGlass._();

  static const Color surfaceTint = Color(0x0AFFFFFF);
  static const Color surfaceLight = Color(0x14FFFFFF);
  static const Color surfaceMedium = Color(0x1FFFFFFF);
  static const Color borderSubtle = Color(0x1AFFFFFF);
  static const Color borderGold = Color(0x44FFD98A);
  static const Color borderGoldStrong = Color(0x66FFD98A);
  static const Color highlightTop = Color(0x22FFFFFF);
  static const Color highlightLeft = Color(0x0DFFFFFF);
  static const Color scrim = Color(0x73000000);

  static const double blurSigma = 18;
  static const double blurSigmaHeavy = 28;
  static const double borderWidth = 1.0;
  static const double borderWidthStrong = 1.2;
  static const double radiusSm = 12;
  static const double radiusMd = 16;
  static const double radiusLg = 20;
  static const double radiusXl = 28;

  static ImageFilter get blur =>
      ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma);
  static ImageFilter get blurHeavy =>
      ImageFilter.blur(sigmaX: blurSigmaHeavy, sigmaY: blurSigmaHeavy);

  static BoxDecoration surface({BorderRadius? borderRadius, Color? tint, double? opacity}) {
    return BoxDecoration(
      color: (tint ?? Colors.white).withValues(alpha: opacity ?? 0.06),
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidth),
      boxShadow: const [
        BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 8), spreadRadius: -6),
      ],
    );
  }

  static BoxDecoration card({BorderRadius? borderRadius}) {
    return BoxDecoration(
      color: surfaceLight,
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidthStrong),
      boxShadow: const [
        BoxShadow(color: Color(0x3D000000), blurRadius: 28, offset: Offset(0, 12), spreadRadius: -6),
      ],
    );
  }

  static BoxDecoration input({bool focused = false}) {
    return BoxDecoration(
      color: surfaceTint,
      borderRadius: BorderRadius.circular(radiusSm),
      border: Border.all(
        color: focused ? NcColors.gold : borderSubtle,
        width: focused ? borderWidthStrong : borderWidth,
      ),
    );
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SPACING / RADIUS / SHADOW
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class NcSpacing {
  NcSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;
}

class NcRadius {
  NcRadius._();
  static const double sm = 6;
  static const double md = 8;
  static const double lg = 10;
  static const double xl = 12;
  static Border get border => Border.all(color: NcColors.border, width: 1.2);
  static Border borderColor(Color c) => Border.all(color: c, width: 1.2);
}

class NcShadows {
  NcShadows._();
  static const List<BoxShadow> sm = [
    BoxShadow(color: Color(0x33000000), offset: Offset(0, 4), blurRadius: 14, spreadRadius: -4),
  ];
  static const List<BoxShadow> md = [
    BoxShadow(color: Color(0x3D000000), offset: Offset(0, 8), blurRadius: 24, spreadRadius: -6),
  ];
  static const List<BoxShadow> lg = [
    BoxShadow(color: Color(0x49000000), offset: Offset(0, 16), blurRadius: 40, spreadRadius: -8),
  ];
}

class NcTheme {
  NcTheme._();
  static const double xl = 16;

  static BoxDecoration cardDecoration({Color bg = NcColors.white}) {
    return BoxDecoration(
      color: bg.withValues(alpha: 0.15),
      border: Border.all(color: const Color(0x66FFD98A), width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: const [
        BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6),
      ],
    );
  }

  static BoxDecoration cardDecorationDark({Color bg = NcColors.darkCard}) {
    return BoxDecoration(
      color: bg,
      border: Border.all(color: const Color(0x44FFD98A), width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: const [
        BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6),
      ],
    );
  }

  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: NcColors.background,
    colorScheme: const ColorScheme.dark(
      primary: NcColors.primaryText,
      secondary: NcColors.gold,
      surface: Color(0xFF14142A),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      contentTextStyle: const TextStyle(fontFamily: 'serif', fontSize: 13, color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    textTheme: GoogleFonts.spaceGroteskTextTheme(ThemeData.dark().textTheme).copyWith(
      displayLarge: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: NcColors.primaryText),
      displayMedium: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: NcColors.primaryText),
      headlineLarge: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: NcColors.primaryText),
      headlineMedium: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: NcColors.primaryText),
      bodyLarge: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: NcColors.primaryText),
      bodyMedium: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: NcColors.primaryText),
      labelLarge: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: NcColors.primaryText),
      titleMedium: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: NcColors.secondaryText),
    ),
  );

  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: NcColors.cream,
    colorScheme: const ColorScheme.light(
      primary: NcColors.black,
      secondary: NcColors.goldDeep,
      surface: NcColors.cream,
    ),
    textTheme: GoogleFonts.spaceGroteskTextTheme().copyWith(
      displayLarge: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: NcColors.black),
      displayMedium: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: NcColors.black),
      headlineLarge: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: NcColors.black),
      headlineMedium: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: NcColors.black),
      bodyLarge: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: NcColors.black),
      bodyMedium: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: NcColors.black),
      labelLarge: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: NcColors.black),
      titleMedium: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: NcColors.grey),
    ),
  );
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 2: CARD WIDGETS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// GlassCard — transparan polos ala iOS/iPadOS (tanpa blur).
class NcGlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color tint;
  final double opacity;
  final Gradient? borderGradient;
  final Color borderLightColor;
  final BorderRadius? borderRadius;
  final double borderWidth;
  final List<BoxShadow>? boxShadow;
  final VoidCallback? onTap;

  const NcGlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(NcSpacing.lg),
    this.tint = Colors.white,
    this.opacity = 0.03,
    this.borderGradient,
    this.borderLightColor = const Color(0x66FFD98A),
    this.borderRadius,
    this.borderWidth = 1.2,
    this.boxShadow,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bubble = context.watch<NeoThemeProvider>().isBubbleGum;
    final cardTint = bubble
        ? context.read<NeoThemeProvider>().palette.surface
        : tint;
    final palette = context.read<NeoThemeProvider>().palette;
    final radius = borderRadius ?? BorderRadius.circular(NcRadius.xl);
    final gradient = borderGradient ?? const LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0x66FFD98A), Color(0x33FFFFFF), Color(0x33C6A15B)],
    );
    final activeGradient = bubble
        ? LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              palette.primary.withValues(alpha: 0.72),
              palette.accent.withValues(alpha: 0.42),
              palette.secondary.withValues(alpha: 0.55),
            ],
          )
        : gradient;
    final shadow = boxShadow ?? [
      BoxShadow(color: Colors.black.withValues(alpha: 0.35), blurRadius: 24, offset: const Offset(0, 12), spreadRadius: -6),
    ];

    Widget content = Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(borderRadius: radius, gradient: activeGradient),
      child: Container(
        padding: const EdgeInsets.all(1.2),
        decoration: BoxDecoration(
          borderRadius: radius,
          color: Colors.transparent,
          boxShadow: [
            BoxShadow(
              color: bubble ? const Color(0x66FF78B5) : Colors.white,
              blurRadius: 2,
              spreadRadius: 0,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius.topLeft.x - 1.2),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: cardTint.withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(radius.topLeft.x - 1.2),
              border: Border(
                top: BorderSide(
                  color: bubble ? palette.primary : borderLightColor,
                  width: 1,
                ),
                left: BorderSide(
                  color: bubble ? palette.primary : borderLightColor,
                  width: 0.6,
                ),
              ),
            ),
            child: child,
          ),
        ),
      ),
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(onTap: onTap, borderRadius: radius, child: Container(decoration: BoxDecoration(borderRadius: radius, boxShadow: shadow), child: content)),
      );
    }
    return Container(decoration: BoxDecoration(borderRadius: radius, boxShadow: shadow), child: content);
  }
}

/// NeoCard — Liquid Glass card seragam.
class NcCard extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  final EdgeInsetsGeometry padding;
  final double? width;
  final EdgeInsetsGeometry? margin;

  const NcCard({super.key, required this.child, this.bgColor = NcColors.white, this.padding = const EdgeInsets.all(NcSpacing.lg), this.width, this.margin});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bubble = context.watch<NeoThemeProvider>().isBubbleGum;
    final palette = context.read<NeoThemeProvider>().palette;
    final cardSurface = bubble ? palette.surface : bgColor;
    return Container(
      width: width, margin: margin, clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: bubble
              ? [
                  cardSurface.withValues(alpha: 0.88),
                  cardSurface.withValues(alpha: 0.62),
                ]
              : isDark
                  ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
                  : [bgColor.withValues(alpha: 0.9), bgColor.withValues(alpha: 0.75)],
        ),
        borderRadius: BorderRadius.circular(NcRadius.xl),
        border: Border.all(
          color: bubble ? palette.primary.withValues(alpha: 0.65) : Colors.transparent,
          width: bubble ? 1.1 : 0,
        ),
        boxShadow: const [BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6)],
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}

/// StatCard — kartu statistik dengan accent color.
class NcStatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color accentColor;
  final VoidCallback? onTap;

  const NcStatCard({super.key, required this.label, required this.value, this.accentColor = NcColors.yellow, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bubble = context.watch<NeoThemeProvider>().isBubbleGum;
    final palette = context.read<NeoThemeProvider>().palette;
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Container(width: 6, height: 6, color: accentColor),
          const SizedBox(width: 6),
          Expanded(child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: isDark ? NcColors.secondaryText : NcColors.grey, letterSpacing: 1), maxLines: 2, overflow: TextOverflow.ellipsis)),
        ]),
        const SizedBox(height: NcSpacing.sm),
        Row(children: [
          Expanded(child: Text(value, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: accentColor), maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (onTap != null) Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(color: accentColor, border: Border.all(color: isDark ? NcColors.line : NcColors.black, width: 1.5), borderRadius: BorderRadius.circular(4)),
            child: const Icon(Icons.arrow_outward, size: 14, color: NcColors.black),
          ),
        ]),
      ],
    );
    return Container(
      clipBehavior: Clip.antiAlias, padding: const EdgeInsets.all(NcSpacing.lg),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: bubble
              ? [
                  palette.surface.withValues(alpha: 0.88),
                  palette.surface.withValues(alpha: 0.62),
                ]
              : isDark
                  ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
                  : [NcColors.white.withValues(alpha: 0.9), NcColors.white.withValues(alpha: 0.7)],
        ),
        borderRadius: BorderRadius.circular(NcRadius.xl),
        border: Border.all(
          color: bubble
              ? palette.primary.withValues(alpha: 0.65)
              : isDark
                  ? const Color(0x44FFD98A)
                  : const Color(0x66FFD98A),
          width: 1.2,
        ),
        boxShadow: const [BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6)],
      ),
      child: onTap == null ? content : GestureDetector(onTap: onTap, child: content),
    );
  }
}

/// DeviceCard — kartu device dengan stat cells.
class NcDeviceCard extends StatelessWidget {
  final String deviceName;
  final String model;
  final String androidVersion;
  final String network;
  final bool isOnline;
  final double battery;
  final double cpu;
  final double ram;
  final VoidCallback? onTap;

  const NcDeviceCard({super.key, required this.deviceName, required this.model, required this.androidVersion, required this.network, this.isOnline = false, this.battery = 0, this.cpu = 0, this.ram = 0, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final statusColor = isOnline ? NcColors.green : NcColors.grey;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        clipBehavior: Clip.antiAlias, padding: const EdgeInsets.all(NcSpacing.md),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: isDark
                ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
                : [NcColors.white.withValues(alpha: 0.9), NcColors.white.withValues(alpha: 0.7)],
          ),
          border: Border.all(color: const Color(0x44FFD98A), width: 1),
          borderRadius: BorderRadius.circular(NcRadius.lg),
          boxShadow: [BoxShadow(color: NcColors.black.withValues(alpha: 0.25), offset: const Offset(0, 8), blurRadius: 20, spreadRadius: -6)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 8, height: 8, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle, border: Border.all(color: NcColors.black, width: 1))),
              const SizedBox(width: NcSpacing.xs),
              Expanded(child: Text(isOnline ? 'ONLINE' : 'OFFLINE', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1, color: statusColor), overflow: TextOverflow.ellipsis)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: NcColors.black, borderRadius: BorderRadius.circular(3)),
                child: Text(network.toUpperCase(), style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, letterSpacing: 1, color: NcColors.white)),
              ),
            ]),
            const SizedBox(height: NcSpacing.sm),
            Text(deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.cinzel(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 1, color: isDark ? NcColors.primaryText : NcColors.black)),
            const SizedBox(height: 2),
            Text('$model • Android $androidVersion', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: isDark ? NcColors.secondaryText : NcColors.grey)),
            const SizedBox(height: NcSpacing.sm),
            Row(children: [
              Expanded(child: _StatCell(label: 'BAT', value: '${battery.toInt()}%', accent: _cellColor(battery), isDark: isDark)),
              const SizedBox(width: NcSpacing.sm),
              Expanded(child: _StatCell(label: 'CPU', value: '${cpu.toInt()}%', accent: _cellColor(cpu), isDark: isDark)),
              const SizedBox(width: NcSpacing.sm),
              Expanded(child: _StatCell(label: 'RAM', value: '${ram.toInt()}%', accent: _cellColor(ram), isDark: isDark)),
            ]),
          ],
        ),
      ),
    );
  }

  Color _cellColor(double v) {
    if (v < 15) return NcColors.pink;
    if (v < 40) return NcColors.orange;
    return NcColors.green;
  }
}

class _StatCell extends StatelessWidget {
  final String label, value;
  final Color accent;
  final bool isDark;
  const _StatCell({required this.label, required this.value, required this.accent, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(color: const Color(0x0FFFFFFF), border: Border.all(color: const Color(0x22FFFFFF), width: 1), borderRadius: BorderRadius.circular(10)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1), decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(3)), child: Text(label, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: NcColors.black))),
        const SizedBox(width: 6),
        Flexible(child: Text(value, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: isDark ? NcColors.primaryText : NcColors.black))),
      ]),
    );
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 3: ROLE RING
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class NcRoles {
  NcRoles._();
  static const Map<String, Color> _colors = {
    'developer': Color(0xFF9B6BFF),
    'partner': Color(0xFFFF9F43),
    'reseller': Color(0xFF36C5F0),
    'moderator': Color(0xFF3DD3A5),
    'vip': Color(0xFFFFD700),
  };
  static Color colorOf(String role) => _colors[role] ?? const Color(0xFFC9A55A);
}

class NcRoleRing extends StatefulWidget {
  final String role;
  final double size;
  final Widget? child;
  final EdgeInsetsGeometry padding;
  final bool active;

  const NcRoleRing({super.key, this.role = 'member', this.size = 68, this.child, this.padding = const EdgeInsets.all(3), this.active = true});

  @override
  State<NcRoleRing> createState() => _NcRoleRingState();
}

class _NcRoleRingState extends State<NcRoleRing> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400));
    if (_RingSpec.of(widget.role).fire > 0) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant NcRoleRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    final animate = _RingSpec.of(widget.role).fire > 0;
    if (animate && !_ctrl.isAnimating) _ctrl.repeat();
    else if (!animate && _ctrl.isAnimating) _ctrl.stop();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final spec = _RingSpec.of(widget.role);
    return SizedBox(
      width: widget.size, height: widget.size,
      child: Stack(children: [
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, _) => CustomPaint(painter: _RoleRingPainter(spec: spec, accent: NcRoles.colorOf(widget.role), progress: _ctrl.value, active: widget.active)),
          ),
        ),
        if (widget.child != null) Positioned.fill(child: Padding(padding: widget.padding, child: widget.child)),
      ]),
    );
  }
}

class _RingSpec {
  final int strokes;
  final bool dots, diamonds, ticks;
  final double fire;
  final int comets;
  final double alpha;

  const _RingSpec({required this.strokes, required this.dots, required this.diamonds, required this.ticks, required this.fire, required this.comets, required this.alpha});

  static _RingSpec of(String role) {
    switch (role) {
      case 'developer': return const _RingSpec(strokes: 3, dots: true, diamonds: true, ticks: true, fire: 1.0, comets: 3, alpha: 1.0);
      case 'partner':   return const _RingSpec(strokes: 2, dots: true, diamonds: true, ticks: true, fire: 0.85, comets: 2, alpha: 0.96);
      case 'moderator': return const _RingSpec(strokes: 2, dots: true, diamonds: true, ticks: false, fire: 0.65, comets: 2, alpha: 0.92);
      case 'reseller':  return const _RingSpec(strokes: 2, dots: true, diamonds: false, ticks: false, fire: 0.50, comets: 1, alpha: 0.88);
      case 'vip':       return const _RingSpec(strokes: 1, dots: false, diamonds: false, ticks: false, fire: 0.28, comets: 1, alpha: 0.85);
      default:          return const _RingSpec(strokes: 1, dots: false, diamonds: false, ticks: false, fire: 0.0, comets: 0, alpha: 0.55);
    }
  }
}

class _RoleRingPainter extends CustomPainter {
  final _RingSpec spec;
  final Color accent;
  final double progress;
  final bool active;

  _RoleRingPainter({required this.spec, required this.accent, this.progress = 0, this.active = true});

  static const _gold = Color(0xFFE5C365);
  static const _goldBright = Color(0xFFF3D98A);
  static const _silver = Color(0xFFCFCFCF);

  double _flame(double p, [double ph = 0]) {
    final x = p * 2 * pi + ph;
    final w1 = 0.5 + 0.5 * sin(x);
    final w2 = 0.5 + 0.5 * sin(x * 2.37 + 1.31);
    return (w1 * 0.6 + w2 * 0.4).clamp(0.0, 1.0);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 0.5;
    final fire = spec.fire;
    final fl = _flame(progress);
    final base = !active ? _silver : (spec.strokes > 1 || spec.dots || spec.diamonds || spec.ticks ? _gold : (fire > 0 ? _gold : _silver));

    if (fire > 0) {
      final gazeR = r + 2 + 8 * fire;
      final gaze = Paint()..shader = RadialGradient(colors: [accent.withValues(alpha: 0.30 * fire * (0.6 + 0.4 * fl)), accent.withValues(alpha: 0.12 * fire * (0.5 + 0.5 * fl)), accent.withValues(alpha: 0)]).createShader(Rect.fromCircle(center: c, radius: gazeR));
      canvas.drawCircle(c, gazeR, gaze);
    }

    if (fire > 0) {
      final neonLayers = fire >= 1.0 ? 3 : (fire >= 0.5 ? 2 : 1);
      for (var i = 1; i <= neonLayers; i++) {
        final neon = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..maskFilter = MaskFilter.blur(BlurStyle.normal, 2.0 * i + 1.0)..color = accent.withValues(alpha: fire * (0.16 - 0.05 * i) * (0.7 + 0.3 * fl));
        canvas.drawCircle(c, r + i * 2.0, neon);
      }
    }

    for (var i = 0; i < spec.strokes; i++) {
      final inset = i == 0 ? 1.2 : (1.2 + 3.2 * i);
      final paint = Paint()..style = PaintingStyle.stroke..strokeWidth = i == 0 ? 1.5 : 1.0..color = base.withValues(alpha: i == 0 ? spec.alpha : spec.alpha * 0.5);
      canvas.drawCircle(c, r - inset, paint);
    }

    final ringR = r - 1.2;
    if (spec.dots) {
      final dot = Paint()..color = accent.withValues(alpha: 0.95);
      for (final a in [0.0, 90.0, 180.0, 270.0]) canvas.drawCircle(_polarDeg(c, ringR, a), 1.35, dot);
    }
    if (spec.diamonds) {
      final half = 1.7;
      final gem = Paint()..color = _goldBright.withValues(alpha: 0.95);
      for (final a in [45.0, 135.0, 225.0, 315.0]) {
        canvas.save();
        canvas.translate(_polarDeg(c, ringR, a).dx, _polarDeg(c, ringR, a).dy);
        canvas.rotate(pi / 4);
        canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: half * 2, height: half * 2), gem);
        canvas.restore();
      }
    }
    if (spec.ticks) {
      final tick = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.3..color = accent.withValues(alpha: 0.8);
      for (var k = 0; k < 8; k++) {
        final a = 22.5 + k * 45.0;
        canvas.drawLine(_polarDeg(c, r - 3.4, a), _polarDeg(c, r - 0.6, a), tick);
      }
    }

    if (fire > 0) {
      final speed = 0.55 + 0.8 * fire;
      final t = progress * 2 * pi * speed;
      for (var i = 0; i < spec.comets; i++) {
        final baseAngle = spec.comets > 1 ? i * (2 * pi / spec.comets) : 0.0;
        final head = -pi / 2 + t + baseAngle;
        final flick = _flame(progress, i * 2.1 + 0.5);
        final bright = (0.55 + 0.45 * fire) * (0.7 + 0.3 * flick);
        final headSweep = 1.15 + 1.05 * fire;

        _arc(canvas, c, r - 1.2, head - headSweep * 3.4, headSweep * 3.4, accent.withValues(alpha: 0.16 * bright), 0.7);
        _arc(canvas, c, r - 1.2, head - headSweep * 2.1, headSweep * 2.1, accent.withValues(alpha: 0.36 * bright), 1.0 + 0.8 * fire);
        _arc(canvas, c, r - 1.2, head - headSweep, headSweep, accent.withValues(alpha: 0.78 * bright), 1.5 + 1.6 * fire);
        _arc(canvas, c, r - 1.2, head - 0.30, 0.30, Color.lerp(accent, Colors.white, 0.6)!.withValues(alpha: 0.9 * bright), 1.2 + 1.0 * fire);

        final tip = _polarRad(c, r - 1.2, head);
        canvas.drawCircle(tip, 1.6 + 1.5 * fire, Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.2)..color = accent.withValues(alpha: 0.55 * bright));
        canvas.drawCircle(tip, 0.9 + 0.9 * fire, Paint()..color = Color.lerp(accent, Colors.white, 0.7)!.withValues(alpha: 0.95 * bright));

        final spkCount = (3 + 7 * fire).round();
        for (var s = 1; s <= spkCount; s++) {
          final a = head - 0.16 * s * (1 - flick * 0.35);
          final jit = sin(head * 57.29578 + s * 12.9898) * 0.8;
          final pos = _polarRad(c, r - 1.2 + jit * 0.4, a);
          final fade = 1 - s / (spkCount + 1);
          canvas.drawCircle(pos, 0.4 + 0.6 * fade * fire, Paint()..color = accent.withValues(alpha: 0.5 * bright * fade));
        }
      }
    }
  }

  void _arc(Canvas canvas, Offset center, double radius, double start, double sweep, Color color, double width) {
    final paint = Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = width..color = color;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, sweep, false, paint);
  }

  Offset _polarDeg(Offset center, double radius, double angleDeg) => _polarRad(center, radius, angleDeg * pi / 180);
  Offset _polarRad(Offset center, double radius, double angleRad) => center + Offset(cos(angleRad) * radius, sin(angleRad) * radius);

  @override
  bool shouldRepaint(covariant _RoleRingPainter old) => old.spec != spec || old.accent != accent || old.active != active || (old.progress - progress).abs() > 0.0001;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 4: STORIES STYLES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// Section header gaya "NOVA STORIES" dengan garis emas kiri.
class NcSectionHeader extends StatelessWidget {
  final String text;
  const NcSectionHeader(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 3, height: 18,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          borderRadius: BorderRadius.circular(2),
        ),
      ),
      const SizedBox(width: 10),
      Text(text, style: GoogleFonts.cinzel(fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2.5, color: const Color(0xFFC9A55A))),
    ]);
  }
}

/// Story circle untuk representasi avatar role ring.
class NcStoryCircle extends StatelessWidget {
  final String name;
  final String? avatarUrl;
  final String role;
  final bool active;
  final VoidCallback? onTap;

  const NcStoryCircle({super.key, required this.name, this.avatarUrl, this.role = 'member', this.active = false, this.onTap});

  @override
  Widget build(BuildContext context) {
    final hasAvatar = avatarUrl != null && avatarUrl!.isNotEmpty;
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        NcRoleRing(
          role: role, size: 68, active: active,
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF1A1E38),
              image: hasAvatar ? DecorationImage(image: NetworkImage(avatarUrl!), fit: BoxFit.cover) : null,
            ),
            child: hasAvatar ? null : Center(child: Text(name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?', style: GoogleFonts.cinzel(fontSize: 22, fontWeight: FontWeight.w700, color: const Color(0xFFC9A55A)))),
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(width: 72, child: Text(name, style: GoogleFonts.inter(fontSize: 10, color: Colors.white.withValues(alpha: 0.6)), overflow: TextOverflow.ellipsis, maxLines: 1, textAlign: TextAlign.center)),
      ]),
    );
  }
}

/// Story viewer fullscreen — progress bars + caption + user info.
class NcStoryViewer extends StatelessWidget {
  final String? mediaUrl;
  final String? textContent;
  final String userName;
  final String? userAvatar;
  final Color bgColor;
  final VoidCallback? onClose;

  const NcStoryViewer({super.key, this.mediaUrl, this.textContent, required this.userName, this.userAvatar, this.bgColor = const Color(0xFF1A1E38), this.onClose});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(fit: StackFit.expand, children: [
        Container(color: bgColor, child: mediaUrl != null ? Image.network(mediaUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image, color: Colors.white38, size: 48))) : null),
        Positioned(top: 0, left: 0, right: 0, height: 120, child: Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withValues(alpha: 0.6), Colors.transparent])))),
        Positioned(bottom: 0, left: 0, right: 0, height: 160, child: Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black.withValues(alpha: 0.6), Colors.transparent])))),
        if (textContent != null && textContent!.isNotEmpty)
          Positioned(bottom: MediaQuery.of(context).padding.bottom + 24, left: 16, right: 16, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.5), borderRadius: BorderRadius.circular(12)),
            child: Text(textContent!, style: GoogleFonts.cinzel(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white, height: 1.35), textAlign: TextAlign.center),
          )),
        Positioned(top: MediaQuery.of(context).padding.top + 8, left: 16, right: 16, child: Row(children: [
          CircleAvatar(radius: 16, backgroundColor: const Color(0xFFC9A55A), backgroundImage: userAvatar != null ? NetworkImage(userAvatar!) : null, child: userAvatar == null ? Text(userName.isNotEmpty ? userName.substring(0, 1).toUpperCase() : '?', style: GoogleFonts.cinzel(fontSize: 14, fontWeight: FontWeight.w700, color: const Color(0xFF0D0D2B))) : null),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(userName, style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white)),
            Text('Baru saja', style: GoogleFonts.inter(fontSize: 11, color: Colors.white60)),
          ])),
          GestureDetector(onTap: onClose ?? () => Navigator.pop(context), child: const Padding(padding: EdgeInsets.all(2), child: Icon(Icons.close, color: Colors.white, size: 24))),
        ])),
      ]),
    );
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 5: PUBLIC CHAT STYLES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// Chat bubble polosan.
class NcChatBubble extends StatelessWidget {
  final String senderName;
  final String message;
  final bool isMe;
  final String? senderRole;
  final String? timeAgo;
  final VoidCallback? onReply;

  const NcChatBubble({super.key, required this.senderName, required this.message, this.isMe = false, this.senderRole, this.timeAgo, this.onReply});

  @override
  Widget build(BuildContext context) {
    final roleColor = NcColors.roleColor(senderRole ?? 'member');
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isMe) ...[
            CircleAvatar(radius: 14, backgroundColor: roleColor.withValues(alpha: 0.2), child: Text(senderName.isNotEmpty ? senderName.substring(0, 1).toUpperCase() : '?', style: GoogleFonts.cinzel(fontSize: 11, color: roleColor))),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: GestureDetector(
              onTap: onReply,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isMe ? const Color(0xFFC9A55A).withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.only(topLeft: const Radius.circular(14), topRight: const Radius.circular(14), bottomLeft: Radius.circular(isMe ? 14 : 4), bottomRight: Radius.circular(isMe ? 4 : 14)),
                  border: isMe ? Border.all(color: const Color(0x44FFD98A), width: 1) : null,
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (!isMe) Text(senderName, style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w700, color: roleColor)),
                  if (!isMe) const SizedBox(height: 2),
                  Text(message, style: GoogleFonts.inter(fontSize: 13, color: Colors.white.withValues(alpha: 0.9))),
                  if (timeAgo != null) ...[
                    const SizedBox(height: 4),
                    Text(timeAgo!, style: GoogleFonts.inter(fontSize: 9, color: Colors.white.withValues(alpha: 0.35))),
                  ],
                ]),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Reply preview bar.
class NcReplyPreview extends StatelessWidget {
  final String sender;
  final String text;
  final VoidCallback? onCancel;

  const NcReplyPreview({super.key, required this.sender, required this.text, this.onCancel});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFC9A55A).withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border(left: BorderSide(color: const Color(0xFFC9A55A).withValues(alpha: 0.4), width: 3)),
      ),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Membalas $sender', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: const Color(0xFFC9A55A))),
          const SizedBox(height: 2),
          Text(text.length > 60 ? '${text.substring(0, 60)}...' : text, style: GoogleFonts.inter(fontSize: 12, color: Colors.white.withValues(alpha: 0.5)), maxLines: 1, overflow: TextOverflow.ellipsis),
        ])),
        GestureDetector(onTap: onCancel, child: const Icon(Icons.close, color: Colors.white38, size: 18)),
      ]),
    );
  }
}

/// Day separator pill.
class NcDaySeparator extends StatelessWidget {
  final String label;
  const NcDaySeparator(this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.35), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withValues(alpha: 0.08))),
          child: Text(label, style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.white.withValues(alpha: 0.7))),
        ),
      ),
    );
  }
}

/// Chat input bar polosan.
class NcChatInputBar extends StatelessWidget {
  final TextEditingController? controller;
  final VoidCallback? onSend;
  final VoidCallback? onAttach;
  final String hintText;

  const NcChatInputBar({super.key, this.controller, this.onSend, this.onAttach, this.hintText = 'Ketik pesan...'});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(color: const Color(0xFF0D0D2B).withValues(alpha: 0.85), border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.06)))),
      child: Row(children: [
        GestureDetector(
          onTap: onAttach,
          child: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.add, color: Color(0xFFC9A55A), size: 22)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.06), borderRadius: BorderRadius.circular(20)),
            child: TextField(
              controller: controller,
              style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(hintText: hintText, hintStyle: GoogleFonts.inter(color: Colors.white.withValues(alpha: 0.3)), border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero),
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => onSend?.call(),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: onSend,
          child: Container(padding: const EdgeInsets.all(8), decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)])), child: const Icon(Icons.send, color: Color(0xFF0D0D2B), size: 18)),
        ),
      ]),
    );
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 6: SPOTIFY / TOOL STYLES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const Color _spBg = Color(0xFF180E26);
const Color _spCard = Color(0xFF241733);
const Color _spAccent = Color(0xFFE5C365);
const Color _spTextMain = Color(0xFFFBF5E6);
const Color _spTextSub = Color(0xFFBB8C2E);

/// Tool card style — input + button, bisa dipakai untuk spotify downloader / tool lain.
class NcToolCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final TextEditingController? controller;
  final String? hintText;
  final String buttonText;
  final VoidCallback? onButtonPressed;
  final bool loading;

  const NcToolCard({super.key, required this.icon, required this.title, required this.subtitle, this.controller, this.hintText, required this.buttonText, this.onButtonPressed, this.loading = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: _spCard, borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Color(0x221A1A1A), blurRadius: 8, offset: Offset(3, 3))]),
      child: Column(children: [
        Icon(icon, size: 48, color: _spAccent),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(color: _spTextSub, fontSize: 12), textAlign: TextAlign.center),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: _spTextSub, fontSize: 10), textAlign: TextAlign.center),
        const SizedBox(height: 12),
        if (controller != null) ...[
          TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hintText, hintStyle: const TextStyle(color: _spTextSub, fontSize: 11),
              filled: true, fillColor: const Color(0xFFF0F0F0),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              prefixIcon: const Icon(Icons.link, color: _spAccent),
            ),
            style: const TextStyle(color: _spTextMain, fontSize: 12),
          ),
          const SizedBox(height: 12),
        ],
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: loading ? null : onButtonPressed,
            style: ElevatedButton.styleFrom(backgroundColor: _spAccent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: loading
                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: _spTextMain, strokeWidth: 2))
                : Text(buttonText, style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5)),
          ),
        ),
      ]),
    );
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ▌ SECTION 7: HOME / COMMON WIDGETS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/// Roman divider — garis emas tipis pemisah section.
class NcRomanDivider extends StatelessWidget {
  const NcRomanDivider({super.key});

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final line = skin.isBubbleGum
        ? palette.primary.withValues(alpha: 0.35)
        : const Color(0x22FFD98A);
    final mark = skin.isBubbleGum
        ? palette.accent.withValues(alpha: 0.70)
        : const Color(0x44FFD98A);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: NcSpacing.lg),
      child: Row(children: [
        Expanded(child: Divider(height: 1, thickness: 1, color: line)),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Icon(Icons.diamond, size: 8, color: mark)),
        Expanded(child: Divider(height: 1, thickness: 1, color: line)),
      ]),
    );
  }
}

/// Stat pill untuk home (online user, device, dll).
class NcStatPill extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const NcStatPill({super.key, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(color: const Color(0x0FFFFFFF), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x22FFFFFF), width: 1)),
      child: Column(children: [
        Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 1, color: NcColors.secondaryText)),
      ]),
    );
  }
}

/// Public chat banner card untuk home.
class NcChatBanner extends StatelessWidget {
  final VoidCallback? onTap;
  const NcChatBanner({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final ink = palette.onBackground1;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: skin.isBubbleGum
                ? [palette.primary, palette.accent]
                : const [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: (skin.isBubbleGum ? palette.primary : const Color(0xFFC9A55A)).withValues(alpha: 0.25), blurRadius: 20, spreadRadius: 2)],
        ),
        child: Row(children: [
          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: ink.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)), child: Icon(Icons.public, color: ink, size: 24)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('NOVACORE CHAT', style: GoogleFonts.cinzel(fontSize: 16, fontWeight: FontWeight.w800, color: ink, letterSpacing: 2)),
            const SizedBox(height: 3),
            Text('Ngobrol real-time dengan semua user', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w500, color: ink.withValues(alpha: 0.65))),
          ])),
          Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(10)), child: Icon(Icons.arrow_forward_rounded, color: skin.isBubbleGum ? palette.accent : const Color(0xFFE8D5A3), size: 18)),
        ]),
      ),
    );
  }
}

/// Attach bar untuk chat (foto, video, dokumen, stiker).
class NcAttachBar extends StatelessWidget {
  final VoidCallback? onPhoto;
  final VoidCallback? onVideo;
  final VoidCallback? onDocument;
  final VoidCallback? onSticker;

  const NcAttachBar({super.key, this.onPhoto, this.onVideo, this.onDocument, this.onSticker});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.06)))),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        _AttachItem(icon: Icons.photo_outlined, label: 'Foto', color: const Color(0xFF6BB9FF), onTap: onPhoto),
        _AttachItem(icon: Icons.videocam_outlined, label: 'Video', color: const Color(0xFFC88BFF), onTap: onVideo),
        _AttachItem(icon: Icons.description_outlined, label: 'Dokumen', color: const Color(0xFFFFB35C), onTap: onDocument),
        _AttachItem(icon: Icons.mood_outlined, label: 'Stiker', color: const Color(0xFFFF7BB3), onTap: onSticker),
      ]),
    );
  }
}

class _AttachItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  const _AttachItem({required this.icon, required this.label, required this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(children: [
        Container(width: 48, height: 48, decoration: BoxDecoration(gradient: LinearGradient(colors: [color, color.withValues(alpha: 0.5)]), shape: BoxShape.circle), child: Icon(icon, size: 22, color: Colors.white)),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: NcColors.secondaryText)),
      ]),
    );
  }
}

/// Block / ban banner.
class NcBlockedBanner extends StatelessWidget {
  final String? blockedByName;
  const NcBlockedBanner({super.key, this.blockedByName});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.redAccent.withValues(alpha: 0.4))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.block, color: Colors.redAccent, size: 28),
        const SizedBox(height: 8),
        Text(blockedByName == null ? 'Anda telah diblokir' : 'Anda telah diblokir oleh $blockedByName', textAlign: TextAlign.center, style: GoogleFonts.inter(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

/// Preview strip role ring untuk showcase semua role.
class NcRingPreviewStrip extends StatelessWidget {
  const NcRingPreviewStrip({super.key});

  static const List<_RolePreview> _roles = [
    _RolePreview('member', 'I'),
    _RolePreview('vip', 'II'),
    _RolePreview('reseller', 'III'),
    _RolePreview('moderator', 'IV'),
    _RolePreview('partner', 'V'),
    _RolePreview('developer', 'VI'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [const Color(0xFF1A1126).withValues(alpha: 0.92), const Color(0xFF241733).withValues(alpha: 0.8)]),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0x66E5C365), width: 1),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: _roles.map((r) => Column(children: [
        NcRoleRing(role: r.role, size: 52, padding: const EdgeInsets.all(4)),
        const SizedBox(height: 6),
        Text(r.numeral, style: GoogleFonts.cinzel(fontSize: 10, fontWeight: FontWeight.w700, color: NcRoles.colorOf(r.role))),
      ])).toList()),
    );
  }
}

class _RolePreview {
  final String role, numeral;
  const _RolePreview(this.role, this.numeral);
}
