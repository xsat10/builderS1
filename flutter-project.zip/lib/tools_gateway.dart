// tools_gateway.dart - FINAL + AI TOOLS + WALLPAPER

import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

import 'global_theme.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_page.dart';
import 'hentai.dart';

// ⬇️ IMPORT VOR4X AI
import 'vor4x_ai_page.dart';

// ═══════════════════════════════════════════════════════════════
// ROLE SYSTEM
// ═══════════════════════════════════════════════════════════════
const Map<String, int> ROLE_LEVEL = {
  'developers': 10, 'ceo': 9, 'owner': 8, 'admin': 7,
  'tangan_kanan': 6, 'vip': 5, 'reseller': 4, 'full_up': 3,
  'member_perbulan': 2, 'member_perminggu': 2, 'member_perhari': 1,
};

const List<String> GLOBAL_SENDER_ROLES = [
  'developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip',
];

bool canAccessGlobalSender(String role) =>
    GLOBAL_SENDER_ROLES.contains(role.toLowerCase());

int getRoleLevel(String role) => ROLE_LEVEL[role.toLowerCase()] ?? 0;

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'DEVELOPERS';
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULLUP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return const Color(0xFFFF00FF);
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF1744);
    case 'admin': return const Color(0xFFF59E0B);
    case 'tangan_kanan': return const Color(0xFF8B5CF6);
    case 'vip': return const Color(0xFFEC4899);
    case 'reseller': return const Color(0xFF22C55E);
    case 'full_up': return const Color(0xFF10B981);
    case 'member_perbulan': return const Color(0xFF3B82F6);
    case 'member_perminggu': return const Color(0xFFF97316);
    case 'member_perhari': return const Color(0xFF6B7280);
    default: return Colors.white;
  }
}

const Map<String, List<String>> TOOL_ACCESS = {
  'panel': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller'],
  'ddos': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan'],
  'network': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller'],
  'osint': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up'],
  'downloader': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up'],
  'utilities': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up'],
  'watchs': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up'],
  'ratcontrol': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip'],
  'adulthub': ['developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip', 'reseller', 'full_up'],
  'aitools': [
    'developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip',
    'reseller', 'full_up', 'member_perbulan', 'member_perminggu', 'member_perhari'
  ],
};

bool canAccessTool(String toolId, String userRole) {
  final allowed = TOOL_ACCESS[toolId] ?? [];
  if (allowed.isEmpty) return true;
  return allowed.contains(userRole.toLowerCase());
}

// ═══════════════════════════════════════════════════════════════
// 🎨 PALETTE
// ═══════════════════════════════════════════════════════════════
class Pal {
  Pal._();

  static Color get blue       => GlobalTheme.primary;
  static Color get cyan       => GlobalTheme.lighten(GlobalTheme.primary, 0.15);
  static Color get accent     => GlobalTheme.darken(GlobalTheme.primary, 0.20);

  static Color get bg         => GlobalTheme.bgTop;
  static Color get surface    => GlobalTheme.cardBg;
  static Color get card       => GlobalTheme.cardBg;
  static Color get border     => GlobalTheme.darken(GlobalTheme.primary, 0.70);
  static Color get borderLit  => GlobalTheme.darken(GlobalTheme.primary, 0.50);

  static const Color text     = Color(0xFFE2E8F0);
  static const Color textSub  = Color(0xFFCBD8E8);
  static const Color textDim  = Color(0xFF64748B);

  // Solid card colors
  static const Color cardSolid     = Color(0xFF0A193C);
  static const Color cardSolidAlt  = Color(0xFF061530);
  static const Color cardSolidDeep = Color(0xFF030B24);

  // Accent palette per kategori
  static const Color cyanA    = Color(0xFF22D3EE);
  static const Color violetA  = Color(0xFF8B5CF6);
  static const Color roseA    = Color(0xFFF43F5E);
  static const Color amberA   = Color(0xFFF59E0B);
  static const Color emeraldA = Color(0xFF10B981);
  static const Color skyA     = Color(0xFF0EA5E9);
  static const Color fuchsiaA = Color(0xFFD946EF);
  static const Color limeA    = Color(0xFF84CC16);
  static const Color orangeA  = Color(0xFFF97316);
}

const List<Shadow> _textShadow = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ═══════════════════════════════════════════════════════════════
// ICONS
// ═══════════════════════════════════════════════════════════════
class Ic {
  Ic._();
  static const IconData cloud = IconData(0xe1e0, fontFamily: 'MaterialIcons');
  static const IconData bolt = IconData(0xe19b, fontFamily: 'MaterialIcons');
  static const IconData wifi = IconData(0xe63c, fontFamily: 'MaterialIcons');
  static const IconData search = IconData(0xe8b6, fontFamily: 'MaterialIcons');
  static const IconData download = IconData(0xe170, fontFamily: 'MaterialIcons');
  static const IconData construction = IconData(0xe18e, fontFamily: 'MaterialIcons');
  static const IconData playCircle = IconData(0xe1c4, fontFamily: 'MaterialIcons');
  static const IconData devices = IconData(0xe1b1, fontFamily: 'MaterialIcons');
  static const IconData lock = IconData(0xe897, fontFamily: 'MaterialIcons');
  static const IconData dns = IconData(0xe875, fontFamily: 'MaterialIcons');
  static const IconData newspaper = IconData(0xe3e5, fontFamily: 'MaterialIcons');
  static const IconData wifiOff = IconData(0xe648, fontFamily: 'MaterialIcons');
  static const IconData router = IconData(0xe8bc, fontFamily: 'MaterialIcons');
  static const IconData badge = IconData(0xea67, fontFamily: 'MaterialIcons');
  static const IconData travelExplore = IconData(0xe95a, fontFamily: 'MaterialIcons');
  static const IconData personSearch = IconData(0xf106, fontFamily: 'MaterialIcons');
  static const IconData alternateEmail = IconData(0xe0e6, fontFamily: 'MaterialIcons');
  static const IconData videoLibrary = IconData(0xe239, fontFamily: 'MaterialIcons');
  static const IconData cameraAlt = IconData(0xe04c, fontFamily: 'MaterialIcons');
  static const IconData qrCode2 = IconData(0xe86a, fontFamily: 'MaterialIcons');
  static const IconData security = IconData(0xe32a, fontFamily: 'MaterialIcons');
  static const IconData networkCheck = IconData(0xe651, fontFamily: 'MaterialIcons');
  static const IconData animation = IconData(0xe1d3, fontFamily: 'MaterialIcons');
  static const IconData favorite = IconData(0xe25b, fontFamily: 'MaterialIcons');
  static const IconData shield = IconData(0xe32a, fontFamily: 'MaterialIcons');
  static const IconData checkCircle = IconData(0xe86c, fontFamily: 'MaterialIcons');
  static const IconData lockOutline = IconData(0xe899, fontFamily: 'MaterialIcons');
  static const IconData lockOpen = IconData(0xe898, fontFamily: 'MaterialIcons');
  static const IconData arrowForward = IconData(0xe5c8, fontFamily: 'MaterialIcons');
  static const IconData searchOff = IconData(0xea76, fontFamily: 'MaterialIcons');
  static const IconData close = IconData(0xe5cd, fontFamily: 'MaterialIcons');
  static const IconData verifiedUser = IconData(0xe8e8, fontFamily: 'MaterialIcons');
  static const IconData autoAwesome = IconData(0xe65f, fontFamily: 'MaterialIcons');
  static const IconData smartToy = IconData(0xf06a, fontFamily: 'MaterialIcons');
  static const IconData psychology = IconData(0xea4a, fontFamily: 'MaterialIcons');

  static const IconData apps = IconData(0xe5c3, fontFamily: 'MaterialIcons');
  static const IconData trendingUp = IconData(0xe8e5, fontFamily: 'MaterialIcons');
  static const IconData fingerprint = IconData(0xe90d, fontFamily: 'MaterialIcons');
  static const IconData stars = IconData(0xe65f, fontFamily: 'MaterialIcons');
  static const IconData chevronRight = IconData(0xe5cc, fontFamily: 'MaterialIcons');
}

// ═══════════════════════════════════════════════════════════════
// DATA MODEL
// ═══════════════════════════════════════════════════════════════
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
  });
}

class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;

  _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
  });
}

// ═══════════════════════════════════════════════════════════════
// CATEGORY LIST
// ═══════════════════════════════════════════════════════════════
const List<_ToolCategory> _categories = [
  _ToolCategory(id: 'panel', title: 'Manage Server', subtitle: 'Server Control', icon: Ic.cloud, accent: Pal.skyA),
  _ToolCategory(id: 'ddos', title: 'DDoS', subtitle: 'Take Down', icon: Ic.bolt, accent: Pal.orangeA),
  _ToolCategory(id: 'network', title: 'Network', subtitle: 'WiFi Arsenal', icon: Ic.wifi, accent: Pal.emeraldA),
  _ToolCategory(id: 'osint', title: 'OSiNT', subtitle: 'Deep Search', icon: Ic.search, accent: Pal.violetA),
  _ToolCategory(id: 'downloader', title: 'Downloader', subtitle: 'Media Saver', icon: Ic.download, accent: Pal.cyanA),
  _ToolCategory(id: 'utilities', title: 'Utilities', subtitle: 'Extra Tools', icon: Ic.construction, accent: Pal.amberA),
  _ToolCategory(id: 'watchs', title: 'Watch Video', subtitle: 'Stream & Watch', icon: Ic.playCircle, accent: Pal.roseA),
  _ToolCategory(id: 'ratcontrol', title: 'RAT Control', subtitle: 'Remote Access', icon: Ic.devices, accent: Pal.fuchsiaA),
  _ToolCategory(id: 'adulthub', title: 'Adult Hub', subtitle: '18+ Only', icon: Ic.lock, accent: Pal.limeA),
  _ToolCategory(id: 'aitools', title: 'AI Tools', subtitle: 'Smart Assistant', icon: Ic.autoAwesome, accent: Pal.cyanA),
];

// ═══════════════════════════════════════════════════════════════
// TOOLS PAGE
// ═══════════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  bool _sessionReady = true;

  bool get canAccessGlobal =>
      GLOBAL_SENDER_ROLES.contains(widget.userRole.toLowerCase());
  String get roleDisplay => getRoleDisplay(widget.userRole);
  Color get roleColor => getRoleColor(widget.userRole);

  int get _accessibleCount =>
      _categories.where((c) => canAccessTool(c.id, widget.userRole)).length;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))..repeat();
    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _headerFade = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(
      begin: const Offset(0, -0.15),
      end: Offset.zero,
    ).animate(
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _showAccessDenied(String toolName) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Ic.lockOutline, color: Colors.white, size: 16),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            'Akses ditolak untuk $toolName. Role Anda: $roleDisplay',
            style: const TextStyle(
                color: Colors.white, fontWeight: FontWeight.w600),
          ),
        ),
      ]),
      backgroundColor: Colors.red.shade800,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      duration: const Duration(seconds: 3),
    ));
  }

  void _onCategoryTap(String id) {
    if (!canAccessTool(id, widget.userRole)) {
      _showAccessDenied(_categories.firstWhere((c) => c.id == id).title);
      return;
    }
    switch (id) {
      case 'panel': _showSheet(_panelItems()); break;
      case 'ddos': _showSheet(_ddosItems()); break;
      case 'network': _showSheet(_networkItems()); break;
      case 'osint': _showSheet(_osintItems()); break;
      case 'downloader': _showSheet(_downloaderItems()); break;
      case 'utilities': _showSheet(_utilityItems()); break;
      case 'watchs': _showSheet(_watchsItems()); break;
      case 'ratcontrol': _showSheet(_ratcontrolItems()); break;
      case 'adulthub': _showSheet(_adulthubItems()); break;
      case 'aitools': _showSheet(_aitoolsItems()); break;
    }
  }

  List<_ToolItem> _panelItems() => [
    _ToolItem(icon: Ic.dns, label: 'Manage Server', accent: Pal.skyA,
        onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey))),
  ];

  List<_ToolItem> _ddosItems() => [
    _ToolItem(icon: Ic.bolt, label: 'Attack Panel', accent: Pal.orangeA,
        onTap: () => _push(AttackPanel(
            sessionKey: widget.sessionKey, listDoos: widget.listDoos))),
  ];

  List<_ToolItem> _networkItems() => [
    _ToolItem(icon: Ic.newspaper, label: 'Spam NGL', accent: Pal.emeraldA,
        onTap: () => _push(const NglPage())),
    _ToolItem(icon: Ic.wifiOff, label: 'WiFi Killer (Internal)', accent: Pal.emeraldA,
        onTap: () => _push(const WifiKillerPage())),
    if (canAccessGlobal)
      _ToolItem(icon: Ic.router, label: 'WiFi Killer (External)', accent: Pal.emeraldA,
          onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey))),
  ];

  List<_ToolItem> _osintItems() => [
    _ToolItem(icon: Ic.badge, label: 'NIK Detail', accent: Pal.violetA,
        onTap: () => _push(const NikCheckerPage())),
    _ToolItem(icon: Ic.travelExplore, label: 'Domain OSINT', accent: Pal.violetA,
        onTap: () => _push(const DomainOsintPage())),
    _ToolItem(icon: Ic.personSearch, label: 'Phone Lookup', accent: Pal.violetA,
        onTap: () => _push(const PhoneLookupPage())),
    _ToolItem(icon: Ic.alternateEmail, label: 'Email OSINT', accent: Pal.violetA,
        onTap: () => _push(const EmailOsintPage())),
  ];

  List<_ToolItem> _downloaderItems() => [
    _ToolItem(icon: Ic.videoLibrary, label: 'TikTok Downloader', accent: Pal.cyanA,
        onTap: () => _push(const TiktokDownloaderPage())),
    _ToolItem(icon: Ic.cameraAlt, label: 'Instagram Downloader', accent: Pal.cyanA,
        onTap: () => _push(const InstagramDownloaderPage())),
  ];

  List<_ToolItem> _utilityItems() => [
    _ToolItem(icon: Ic.qrCode2, label: 'QR Generator', accent: Pal.amberA,
        onTap: () => _push(const QrGeneratorPage())),
    _ToolItem(icon: Ic.security, label: 'IP Scanner', accent: Pal.amberA,
        onTap: () => _push(const IpScannerPage())),
    _ToolItem(icon: Ic.networkCheck, label: 'Port Scanner', accent: Pal.amberA,
        onTap: () => _push(const PortScannerPage())),
  ];

  List<_ToolItem> _watchsItems() => [
    _ToolItem(icon: Ic.animation, label: 'Anime', accent: Pal.roseA,
        onTap: () => _push(const HomeAnimePage())),
    _ToolItem(icon: Ic.playCircle, label: 'Dracin', accent: Pal.roseA,
        onTap: () => _push(const DracinPage())),
  ];

  List<_ToolItem> _ratcontrolItems() => [
    _ToolItem(icon: Ic.devices, label: 'RAT Panel', accent: Pal.fuchsiaA,
        onTap: () => _push(const DeviceDashboardPage())),
  ];

  List<_ToolItem> _adulthubItems() => [
    _ToolItem(icon: Ic.favorite, label: 'Hentai', accent: Pal.limeA,
        onTap: () => _push(const HomeHentaiPage())),
  ];

  List<_ToolItem> _aitoolsItems() => [
    _ToolItem(icon: Ic.autoAwesome, label: 'VOR4X AI', accent: Pal.cyanA,
        onTap: () => _push(const Vor4xAiPage())),
    _ToolItem(icon: Ic.smartToy, label: 'VOR4X AI (Beta)', accent: Pal.skyA,
        onTap: () => _push(const Vor4xAiPage())),
  ];

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          extendBody: true,
          extendBodyBehindAppBar: true,
          body: Stack(
            children: [
              // ═══════════════════════════════════════════════
              // 🖼️ WALLPAPER BACKGROUND — dashboard.png
              // ═══════════════════════════════════════════════
              Positioned.fill(
                child: Image.asset(
                  'assets/images/dashboard.png',   // ⬅️ WALLPAPER
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: Pal.bg,
                  ),
                ),
              ),

              // ⬇️ OVERLAY GRADIENT — biar teks kebaca
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFF020814).withOpacity(0.72),
                        const Color(0xFF0D47A1).withOpacity(0.28),
                        const Color(0xFF020814).withOpacity(0.85),
                      ],
                      stops: const [0.0, 0.5, 1.0],
                    ),
                  ),
                ),
              ),

              // ⬇️ GRID + GLOW OVERLAY (tambahan dekoratif)
              Positioned.fill(
                child: IgnorePointer(
                  child: _AnimatedBg(controller: _bgCtrl),
                ),
              ),

              // ⬇️ KONTEN UTAMA
              SafeArea(
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: FadeTransition(
                        opacity: _headerFade,
                        child: SlideTransition(
                          position: _headerSlide,
                          child: _buildHeroHeader(),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(child: _buildStatsBar()),
                    SliverToBoxAdapter(child: _buildSectionTitle()),
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
                      sliver: SliverGrid(
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.78,
                        ),
                        delegate: SliverChildBuilderDelegate(
                          (_, i) => _StaggerItem(
                            index: i,
                            child: _ModernCategoryCard(
                              category: _categories[i],
                              userRole: widget.userRole,
                              onTap: () => _onCategoryTap(_categories[i].id),
                            ),
                          ),
                          childCount: _categories.length,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HERO HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _buildHeroHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Pal.cardSolid,
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color: Pal.blue.withOpacity(0.5), width: 1),
                  boxShadow: [
                    BoxShadow(color: Pal.blue.withOpacity(0.35), blurRadius: 12),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Pal.cyan,
                        boxShadow: [
                          BoxShadow(color: Pal.cyan, blurRadius: 6, spreadRadius: 1),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'VOR4X · TOOLS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        shadows: _textShadow,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Pal.cardSolid,
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color: roleColor.withOpacity(0.7), width: 1),
                  boxShadow: [
                    BoxShadow(color: roleColor.withOpacity(0.35), blurRadius: 10),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Ic.verifiedUser, color: roleColor, size: 11),
                    const SizedBox(width: 5),
                    Text(
                      roleDisplay,
                      style: TextStyle(
                        color: roleColor,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                        shadows: _textShadow,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 22),

          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [Colors.white, Pal.cyan, Pal.blue],
              stops: const [0.0, 0.55, 1.0],
            ).createShader(bounds),
            child: const Text(
              'Pusat Akses\nMenu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.w900,
                height: 1.05,
                letterSpacing: -0.8,
              ),
            ),
          ),

          const SizedBox(height: 10),

          Text(
            'Koleksi tools canggih & utility harian\nuntuk kebutuhan operasional.',
            style: TextStyle(
              color: Colors.white.withOpacity(0.70),
              fontSize: 13,
              height: 1.5,
              fontWeight: FontWeight.w500,
              shadows: _textShadow,
            ),
          ),

          const SizedBox(height: 18),

          Row(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Container(
                      height: 6,
                      decoration: BoxDecoration(
                        color: Pal.cardSolidDeep,
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.08),
                          width: 0.8,
                        ),
                      ),
                    ),
                    FractionallySizedBox(
                      widthFactor: _accessibleCount / _categories.length,
                      child: Container(
                        height: 6,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [Pal.cyan, Pal.blue]),
                          borderRadius: BorderRadius.circular(100),
                          boxShadow: [
                            BoxShadow(color: Pal.cyan.withOpacity(0.7), blurRadius: 10),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: Pal.cardSolid,
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color: Pal.cyan.withOpacity(0.5), width: 1),
                ),
                child: Text(
                  '$_accessibleCount/${_categories.length}',
                  style: TextStyle(
                    color: Pal.cyan,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                    shadows: _textShadow,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatsBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: _StatPill(
              icon: Ic.fingerprint,
              label: 'ROLE',
              value: roleDisplay,
              accent: roleColor,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatPill(
              icon: Ic.apps,
              label: 'MODULES',
              value: '${_categories.length}',
              accent: Pal.cyan,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatPill(
              icon: Ic.trendingUp,
              label: 'STATUS',
              value: _sessionReady ? 'READY' : 'SYNC',
              accent: Pal.emeraldA,
              dot: _sessionReady,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 22, 20, 12),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 22,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Pal.cyan, Pal.blue],
              ),
              borderRadius: BorderRadius.circular(100),
              boxShadow: [
                BoxShadow(color: Pal.cyan.withOpacity(0.7), blurRadius: 10),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Text(
            'KATEGORI',
            style: TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.5,
              shadows: _textShadow,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Pal.cardSolid,
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Pal.cyan.withOpacity(0.4), width: 1),
            ),
            child: Text(
              '${_categories.length} Modules',
              style: TextStyle(
                color: Pal.cyan.withOpacity(0.9),
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                shadows: _textShadow,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STAT PILL
// ═══════════════════════════════════════════════════════════════
class _StatPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color accent;
  final bool dot;

  const _StatPill({
    required this.icon,
    required this.label,
    required this.value,
    required this.accent,
    this.dot = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: Pal.cardSolid,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Pal.cardSolidAlt.withOpacity(0.8), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: accent.withOpacity(0.15),
            blurRadius: 16,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: accent, size: 12, shadows: _textShadow),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.55),
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                    shadows: _textShadow,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Flexible(
                child: Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3,
                    shadows: _textShadow,
                  ),
                ),
              ),
              if (dot) ...[
                const SizedBox(width: 5),
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent,
                    boxShadow: [
                      BoxShadow(color: accent, blurRadius: 6, spreadRadius: 1),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// MODERN CATEGORY CARD — SOLID
// ═══════════════════════════════════════════════════════════════
class _ModernCategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final String userRole;
  final VoidCallback onTap;

  const _ModernCategoryCard({
    required this.category,
    required this.userRole,
    required this.onTap,
  });

  @override
  State<_ModernCategoryCard> createState() => _ModernCategoryCardState();
}

class _ModernCategoryCardState extends State<_ModernCategoryCard>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;
  bool _isLocked = false;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.25, end: 0.55)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
    _isLocked = !canAccessTool(widget.category.id, widget.userRole);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    final accent = _isLocked ? Pal.textDim : cat.accent;
    final isAI = cat.id == 'aitools';

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedBuilder(
          animation: _glow,
          builder: (_, __) => Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(
                    _pressed ? 0.45 : _glow.value * 0.25,
                  ),
                  blurRadius: _pressed ? 26 : 18,
                  spreadRadius: _pressed ? 2 : 0,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.55),
                  blurRadius: 16,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Container(
              decoration: BoxDecoration(
                color: _isLocked ? Pal.cardSolidDeep : Pal.cardSolid,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: _pressed
                      ? accent.withOpacity(0.9)
                      : accent.withOpacity(isAI ? 0.55 : 0.30),
                  width: _pressed ? 1.8 : 1.2,
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    left: 20,
                    right: 20,
                    child: Container(
                      height: 2,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            accent.withOpacity(0.6),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),

                  if (isAI && !_isLocked)
                    Positioned(
                      top: -30,
                      right: -30,
                      child: Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              accent.withOpacity(0.35),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),

                  Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                color: Pal.cardSolidAlt,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: accent.withOpacity(isAI ? 0.7 : 0.45),
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: accent.withOpacity(isAI ? 0.55 : 0.30),
                                    blurRadius: isAI ? 18 : 12,
                                  ),
                                ],
                              ),
                              child: Icon(
                                cat.icon,
                                color: accent,
                                size: 24,
                                shadows: _textShadow,
                              ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (isAI && !_isLocked) ...[
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2),
                                    margin: const EdgeInsets.only(right: 4),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFFFF1744),
                                          Color(0xFFFF9100),
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(100),
                                      boxShadow: [
                                        BoxShadow(
                                          color: const Color(0xFFFF1744)
                                              .withOpacity(0.6),
                                          blurRadius: 8,
                                        ),
                                      ],
                                    ),
                                    child: const Text(
                                      'NEW',
                                      style: TextStyle(
                                        fontSize: 7,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.8,
                                        color: Colors.white,
                                        shadows: _textShadow,
                                      ),
                                    ),
                                  ),
                                ],
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 7, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: _isLocked
                                        ? const Color(0xFF2A0A12)
                                        : Pal.cardSolidDeep,
                                    borderRadius: BorderRadius.circular(100),
                                    border: Border.all(
                                      color: _isLocked
                                          ? Colors.red.withOpacity(0.55)
                                          : accent.withOpacity(0.55),
                                      width: 1,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        _isLocked ? Ic.lockOutline : Ic.lockOpen,
                                        size: 9,
                                        color: _isLocked
                                            ? Colors.red.shade300
                                            : accent,
                                      ),
                                      const SizedBox(width: 3),
                                      Text(
                                        _isLocked ? 'LOCK' : 'OPEN',
                                        style: TextStyle(
                                          fontSize: 8,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: 0.8,
                                          color: _isLocked
                                              ? Colors.red.shade300
                                              : accent,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              cat.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: _isLocked ? Pal.textDim : Colors.white,
                                fontSize: 13.5,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.2,
                                shadows: _textShadow,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              cat.subtitle,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: _isLocked
                                    ? Pal.textDim
                                    : Colors.white.withOpacity(0.65),
                                fontSize: 10.5,
                                height: 1.35,
                                fontWeight: FontWeight.w500,
                                shadows: _textShadow,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// TOOL SHEET
// ═══════════════════════════════════════════════════════════════
class _ToolSheet extends StatefulWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  State<_ToolSheet> createState() => _ToolSheetState();
}

class _ToolSheetState extends State<_ToolSheet> {
  late List<_ToolItem> _filtered;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _filtered = widget.items;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearch(String q) {
    setState(() {
      if (q.trim().isEmpty) {
        _filtered = widget.items;
      } else {
        _filtered = widget.items
            .where((it) => it.label.toLowerCase().contains(q.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.78,
      ),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Pal.cardSolid,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(
            top: BorderSide(color: Pal.blue.withOpacity(0.6), width: 1.3),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.7),
              blurRadius: 30,
              offset: const Offset(0, -10),
            ),
            BoxShadow(
              color: Pal.blue.withOpacity(0.25),
              blurRadius: 40,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 14, bottom: 10),
              child: Container(
                width: 48,
                height: 4,
                decoration: BoxDecoration(
                  color: Pal.blue,
                  borderRadius: BorderRadius.circular(100),
                  boxShadow: [
                    BoxShadow(
                        color: Pal.blue.withOpacity(0.7), blurRadius: 10),
                  ],
                ),
              ),
            ),
            Container(
              height: 1,
              margin: const EdgeInsets.symmetric(horizontal: 24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Pal.blue.withOpacity(0.6),
                    Pal.cyan.withOpacity(0.6),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.3, 0.7, 1.0],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (widget.items.length > 2)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: Pal.cardSolidDeep,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: Pal.cardSolidAlt.withOpacity(0.9), width: 1),
                  ),
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: _onSearch,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 14),
                    cursorColor: Pal.cyan,
                    decoration: InputDecoration(
                      hintText: 'Cari tools...',
                      hintStyle: TextStyle(
                        color: Colors.white.withOpacity(0.45),
                        fontSize: 13,
                      ),
                      prefixIcon: const Icon(Ic.search,
                          color: Pal.textSub, size: 20),
                      suffixIcon: _searchCtrl.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Ic.close,
                                  color: Pal.textSub, size: 18),
                              onPressed: () {
                                _searchCtrl.clear();
                                _onSearch('');
                              },
                            )
                          : null,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 14),
                    ),
                  ),
                ),
              ),
            Flexible(
              child: _filtered.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Ic.searchOff,
                              size: 42,
                              color: Color(0x59FFFFFF)),
                          SizedBox(height: 10),
                          Text(
                            'Tidak ada tools ditemukan',
                            style: TextStyle(
                                color: Pal.textSub,
                                fontSize: 13,
                                shadows: _textShadow),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      itemCount: _filtered.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 10),
                      itemBuilder: (ctx, i) => _StaggerItem(
                        index: i,
                        child: _ToolRow(
                          item: _filtered[i],
                          onTap: () {
                            Navigator.pop(ctx);
                            _filtered[i].onTap();
                          },
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// TOOL ROW
// ═══════════════════════════════════════════════════════════════
class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final color = item.accent;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _pressed ? Pal.cardSolidAlt : Pal.cardSolidDeep,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _pressed
                ? color.withOpacity(0.75)
                : Pal.cardSolidAlt.withOpacity(0.9),
            width: _pressed ? 1.5 : 1,
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: color.withOpacity(0.30),
                    blurRadius: 16,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Row(children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Pal.cardSolidAlt,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: color.withOpacity(_pressed ? 0.8 : 0.45),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                    color: color.withOpacity(0.30), blurRadius: 10),
              ],
            ),
            child: Icon(item.icon, color: color, size: 20, shadows: _textShadow),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              item.label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
                shadows: _textShadow,
              ),
            ),
          ),
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: Pal.cardSolidAlt,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: color.withOpacity(_pressed ? 0.8 : 0.35),
                width: 1,
              ),
            ),
            child: Icon(
              Ic.arrowForward,
              color: _pressed ? Colors.white : color,
              size: 14,
            ),
          ),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STAGGER
// ═══════════════════════════════════════════════════════════════
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 400 + (index * 60).clamp(0, 500)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(
          offset: Offset(0, 20 * (1 - v)),
          child: ch,
        ),
      ),
      child: child,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// ANIMATED BG — GRID + GLOW OVERLAY (di atas wallpaper)
// ═══════════════════════════════════════════════════════════════
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // ⚠️ JANGAN gambar warna solid — biar wallpaper tetap terlihat
    // Hanya grid + glow dekoratif

    // Grid pattern
    final grid = Paint()
      ..color = const Color(0x0AFFFFFF)
      ..strokeWidth = 0.4;
    const step = 48.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final p = GlobalTheme.primary;
    final r = (p.r * 255).round();
    final g = (p.g * 255).round();
    final b = (p.b * 255).round();

    // Glow 1 — pojok kiri atas
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          Color.fromRGBO(r, g, b, 0.08 + math.sin(t * math.pi * 2) * 0.025),
          Colors.transparent,
        ],
        radius: 0.9,
        focal: const Alignment(-0.2, -0.3),
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.3, 0),
        radius: size.width,
      ));
    canvas.drawCircle(Offset(size.width * 0.3, 0), size.width * 1.2, glow);

    // Glow 2 — pojok kanan bawah
    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          Color.fromRGBO(r, g, b, 0.06 + math.cos(t * math.pi * 2) * 0.025),
          Colors.transparent,
        ],
        radius: 0.5,
        focal: const Alignment(0.2, 0.3),
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.85, size.height * 0.8),
        radius: size.width * 0.45,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.85, size.height * 0.8),
      size.width * 0.45,
      glow2,
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ═══════════════════════════════════════════════════════════════
// PAGE TRANSITION
// ═══════════════════════════════════════════════════════════════
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 400),
      reverseTransitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(
          opacity: Tween<double>(begin: 0.6, end: 1.0)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
          child: child,
        ),
      ),
    );