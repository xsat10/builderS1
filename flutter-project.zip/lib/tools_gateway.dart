import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'FreeFireLagServer.dart';
import 'hentai_page.dart' as hentai;

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with TickerProviderStateMixin {
  late String sessionKey;
  late String userRole;
  late List<Map<String, dynamic>> listDoos;

  late AnimationController _glowController;
  late AnimationController _shimmerController;
  late AnimationController _entranceController;

  // ============ TEMA HITAM TOTAL SEPERTI DASHBOARD ============
  final Color bgDark = const Color(0xFF050505); // HITAM TOTAL
  final Color cardBg = const Color(0xFF0D0D0D);
  final Color accentGreen = const Color(0xFF2ECC71); // HIJAU
  final Color lightGreen = const Color(0xFFA8E6CF);
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.08);
  final Color modalDark = const Color(0xFF0D0D0D);
  final Color accentBlue = const Color(0xFF1E88E5);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    userRole = widget.userRole;
    listDoos = widget.listDoos;

    _glowController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _shimmerController = AnimationController(
      duration: const Duration(seconds: 2, milliseconds: 200),
      vsync: this,
    )..repeat();

    _entranceController = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    )..forward();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _shimmerController.dispose();
    _entranceController.dispose();
    super.dispose();
  }

  Widget _buildStaggeredEntry({
    required int index,
    required Widget child,
  }) {
    final int total = 7;
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildGlowBorder({
    required Widget child,
    double borderRadius = 22,
    double borderWidth = 1.6,
  }) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.all(borderWidth),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: SweepGradient(
              transform: GradientRotation(_glowController.value * 6.2832),
              colors: [
                accentGreen.withOpacity(0.0),
                accentGreen.withOpacity(0.0),
                lightGreen,
                accentGreen,
                accentGreen,
                accentGreen.withOpacity(0.0),
                accentGreen.withOpacity(0.0),
              ],
              stops: const [0.0, 0.35, 0.45, 0.5, 0.55, 0.65, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: accentGreen.withOpacity(0.15),
                blurRadius: 10,
                spreadRadius: 0.5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius - borderWidth),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildShimmerText(String text, {double fontSize = 22}) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        final double t = _shimmerController.value;
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment(-2.0 + 4.0 * t, -0.3),
              end: Alignment(-1.0 + 4.0 * t, 0.3),
              colors: const [
                Colors.white,
                Colors.white,
                Colors.white70,
                Colors.white,
                Colors.white,
              ],
              stops: const [0.0, 0.40, 0.5, 0.60, 1.0],
            ).createShader(bounds);
          },
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: fontSize,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            ),
          ),
        );
      },
    );
  }

  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: GestureDetector(
        onTap: onTap,
        child: _buildGlowBorder(
          borderRadius: 22,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  accentGreen.withOpacity(0.15),
                  bgDark,
                ],
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: cardGlass,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderGlass),
                  ),
                  child: Icon(icon, color: accentGreen, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 16,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: accentGrey,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: cardGlass,
                    shape: BoxShape.circle,
                    border: Border.all(color: borderGlass),
                  ),
                  child: Icon(Icons.chevron_right_rounded,
                      color: accentGreen, size: 20),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============ POPUP MODAL HITAM ============
  void _showCategoryPopup({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required List<Widget> children,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (BuildContext ctx) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: accentGreen.withOpacity(0.3), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: accentGreen.withOpacity(0.15),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: accentGreen.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: accentGreen, size: 36),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    title,
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: primaryWhite.withOpacity(0.6),
                      fontSize: 13,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 24),
                  ...children,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderGlass),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(icon, color: accentGreen, size: 20),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
                Icon(Icons.arrow_forward_ios, color: accentGreen.withOpacity(0.38), size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: primaryWhite),
            const SizedBox(width: 8),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: primaryWhite,
              ),
            ),
          ],
        ),
        backgroundColor: accentGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isOwner = userRole.toLowerCase() == "owner";

    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: Column(
          children: [
            // === HEADER ===
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: cardGlass,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: borderGlass),
                      boxShadow: [
                        BoxShadow(
                          color: accentGreen.withOpacity(0.2),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(Icons.grid_view_rounded,
                        color: accentGreen, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildShimmerText("Tools Gateway", fontSize: 22),
                        const SizedBox(height: 4),
                        Text(
                          "Select your weapon",
                          style: TextStyle(
                            color: accentGrey,
                            fontSize: 13,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isOwner)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: cardGlass,
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                            color: accentGreen.withOpacity(0.6)),
                        boxShadow: [
                          BoxShadow(
                            color: accentGreen.withOpacity(0.15),
                            blurRadius: 8,
                            spreadRadius: 0.5,
                          ),
                        ],
                      ),
                      child: Text(
                        "OWNER",
                        style: TextStyle(
                          color: accentGreen,
                          fontSize: 12,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // === CATEGORY LIST ===
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  _buildStaggeredEntry(
                    index: 0,
                    child: _buildToolCard(
                      icon: Icons.flash_on,
                      title: "DDoS Tools",
                      subtitle: "L4/L7 Stress Test Attack",
                      onTap: () => _showDDoSTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 1,
                    child: _buildToolCard(
                      icon: Icons.wifi_tethering,
                      title: "Network Tools",
                      subtitle: "WiFi Killer & Spam NGL",
                      onTap: () => _showNetworkTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 2,
                    child: _buildToolCard(
                      icon: Icons.travel_explore,
                      title: "OSINT Tools",
                      subtitle: "NIK Checker, Domain, IP",
                      onTap: () => _showOSINTTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 3,
                    child: _buildToolCard(
                      icon: Icons.download_rounded,
                      title: "Media Downloader",
                      subtitle: "TikTok & Instagram No Watermark",
                      onTap: () => _showDownloaderTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 4,
                    child: _buildToolCard(
                      icon: Icons.auto_fix_high,
                      title: "Generator Tools",
                      subtitle: "QR Generator & Utilities",
                      onTap: () => _showUtilityTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 5,
                    child: _buildToolCard(
                      icon: Icons.movie_filter,
                      title: "Watch",
                      subtitle: "Anime & Hentai Media",
                      onTap: () => _showWatchTools(context),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildStaggeredEntry(
                    index: 6,
                    child: _buildToolCard(
                      icon: Icons.rocket_launch,
                      title: "Quick Access",
                      subtitle: "Favorites",
                      onTap: () => _showComingSoon(context),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============ CATEGORY METHODS ============

  void _showDDoSTools(BuildContext context) {
    _showCategoryPopup(
      context: context,
      icon: Icons.flash_on,
      title: "DDoS Tools",
      subtitle: "L4/L7 Stress Test Attack",
      children: [
        _buildToolItem(
          context: context,
          icon: FontAwesomeIcons.fire,
          label: "Lag Free Fire",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const FreeFireLagServerPage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.flash_on,
          label: "Attack Panel",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPanel(
                  sessionKey: sessionKey,
                  listDoos: listDoos,
                ),
              ),
            );
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.dns,
          label: "Manage Server",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    final List<Widget> children = [
      _buildToolItem(
        context: context,
        icon: Icons.newspaper_outlined,
        label: "Spam NGL",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => NglPage()));
        },
      ),
      _buildToolItem(
        context: context,
        icon: Icons.wifi_off,
        label: "WiFi Killer (Internal)",
        onTap: () {
          Navigator.pop(context);
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => WifiKillerPage()));
        },
      ),
    ];

    if (userRole == "vip" || userRole == "owner") {
      children.add(
        _buildToolItem(
          context: context,
          icon: Icons.router,
          label: "WiFi Killer (External)",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => WifiInternalPage(sessionKey: sessionKey),
              ),
            );
          },
        ),
      );
    }

    _showCategoryPopup(
      context: context,
      icon: Icons.wifi_tethering,
      title: "Network Tools",
      subtitle: "WiFi Killer & Spam NGL",
      children: children,
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showCategoryPopup(
      context: context,
      icon: Icons.travel_explore,
      title: "OSINT Tools",
      subtitle: "NIK Checker, Domain, IP",
      children: [
        _buildToolItem(
          context: context,
          icon: Icons.badge,
          label: "NIK Detail",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.domain,
          label: "Domain OSINT",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.person_search,
          label: "Phone Lookup",
          onTap: () => _showComingSoon(context),
        ),
        _buildToolItem(
          context: context,
          icon: Icons.email,
          label: "Email OSINT",
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showCategoryPopup(
      context: context,
      icon: Icons.download_rounded,
      title: "Media Downloader",
      subtitle: "TikTok & Instagram No Watermark",
      children: [
        _buildToolItem(
          context: context,
          icon: Icons.video_library,
          label: "TikTok Downloader",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.camera_alt,
          label: "Instagram Downloader",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showCategoryPopup(
      context: context,
      icon: Icons.auto_fix_high,
      title: "Generator Tools",
      subtitle: "QR Generator & Utilities",
      children: [
        _buildToolItem(
          context: context,
          icon: Icons.qr_code,
          label: "QR Generator",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.security,
          label: "IP Scanner",
          onTap: () => _showComingSoon(context),
        ),
        _buildToolItem(
          context: context,
          icon: Icons.network_check,
          label: "Port Scanner",
          onTap: () => _showComingSoon(context),
        ),
      ],
    );
  }

  void _showWatchTools(BuildContext context) {
    _showCategoryPopup(
      context: context,
      icon: Icons.movie_filter,
      title: "Watch",
      subtitle: "Anime & Hentai Media",
      children: [
        _buildToolItem(
          context: context,
          icon: Icons.live_tv,
          label: "Anime Streaming",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const HomeAnimePage()));
          },
        ),
        _buildToolItem(
          context: context,
          icon: Icons.local_fire_department,
          label: "Hentai Media",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const hentai.HomeScreen()));
          },
        ),
      ],
    );
  }
}