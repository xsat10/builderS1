import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class FloatingBagger {
  static const platform = MethodChannel('com.x.xeternalz/floating_bagger');

  static Future<bool> requestOverlayPermission() async {
    final status = await Permission.systemAlertWindow.request();
    return status.isGranted;
  }

  static Future<bool> checkOverlayPermission() async {
    return await Permission.systemAlertWindow.isGranted;
  }

  static Future<void> startService({
    required String username,
    required String password,
    required String sessionKey,
    required String role,
    required String expiredDate,
  }) async {
    try {
      final hasPermission = await requestOverlayPermission();
      if (!hasPermission) {
        throw Exception('Izin overlay tidak diberikan');
      }

      await platform.invokeMethod('startFloatingService', {
        'username': username,
        'password': password,
        'sessionKey': sessionKey,
        'role': role,
        'expiredDate': expiredDate,
      });
    } catch (e) {
      print('Error starting floating service: $e');
      rethrow;
    }
  }

  static Future<void> stopService() async {
    try {
      await platform.invokeMethod('stopFloatingService');
    } catch (e) {
      print('Error stopping floating service: $e');
    }
  }
}