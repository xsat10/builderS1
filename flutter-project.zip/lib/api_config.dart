const String baseUrl = "http://felix-private.web.id:11834"; 
const String wsUrl = "wss://felix-private.web.id:11834";