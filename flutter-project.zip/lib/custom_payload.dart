// lib/custom_payload.dart
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'bug_sender.dart';

// ═══════════════════════════════════════════════════════════
// 🎯 ROLE SYSTEM
// ═══════════════════════════════════════════════════════════
const List<String> CUSTOM_PAYLOAD_ACCESS_ROLES = [
  'developers', 'ceo', 'owner', 'admin',
  'tangan_kanan', 'vip', 'reseller'
];

const Map<String, int> ROLE_LEVEL = {
  'developers': 10,
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1,
};

bool canAccessCustomPayload(String role) =>
    CUSTOM_PAYLOAD_ACCESS_ROLES.contains(role.toLowerCase());

int getRoleLevel(String role) => ROLE_LEVEL[role.toLowerCase()] ?? 0;

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'DEVELOPERS';
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

// ═══════════════════════════════════════════════════════════
// 🎨 PALET WARNA — Biru / Putih / Neon
// ═══════════════════════════════════════════════════════════
class _C {
  static const Color blue = Color(0xFF2196F3);
  static const Color blueLight = Color(0xFF64B5F6);
  static const Color blueDark = Color(0xFF0D47A1);
  static const Color cyan = Color(0xFF00D4FF);
  static const Color cyanLight = Color(0xFF80DEEA);
  static const Color ice = Color(0xFFE3F2FD);
  static const Color white = Color(0xFFFFFFFF);

  static const Color bgDeep = Color(0xFF03060D);
  static const Color bgNavy = Color(0xFF061225);
  static const Color card = Color(0xFF0A1A3A);
  static const Color cardBorder = Color(0xFF1E3A6E);

  static const Color success = Color(0xFF00E5A0);
  static const Color warning = Color(0xFFFFB547);
  static const Color danger = Color(0xFFFF4D6A);

  static const Color text = Color(0xFFFFFFFF);
  static const Color textSec = Color(0xFFB0C4DE);
  static const Color textMuted = Color(0xFF6B7B8F);

  static const List<List<Color>> bugPalette = [
    [Color(0xFF2196F3), Color(0xFF00D4FF)],
    [Color(0xFF0D47A1), Color(0xFF2196F3)],
    [Color(0xFF00D4FF), Color(0xFF80DEEA)],
    [Color(0xFF64B5F6), Color(0xFF2196F3)],
    [Color(0xFF03A9F4), Color(0xFF00BCD4)],
  ];

  static List<Color> bugGradient(int i) => bugPalette[i % bugPalette.length];
}

// ═══════════════════════════════════════════════════════════
// 🏠 CUSTOM PAYLOAD PAGE
// ═══════════════════════════════════════════════════════════
class CustomPayloadPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const CustomPayloadPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.listBug,
  });

  @override
  State<CustomPayloadPage> createState() => _CustomPayloadPageState();
}

class _CustomPayloadPageState extends State<CustomPayloadPage>
    with TickerProviderStateMixin {
  // Controllers
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _delayController =
      TextEditingController(text: '1000');
  final TextEditingController _countController =
      TextEditingController(text: '1');

  final List<Map<String, dynamic>> _selectedBugs = [];
  bool _isSending = false;

  // Animations
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late AnimationController _scanLineController;
  late Animation<double> _pulseAnimation;

  // Video
  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;
  bool _isSoundOn = false;

  // Getters
  bool get canAccessPayload => canAccessCustomPayload(widget.role);
  String get roleDisplay => getRoleDisplay(widget.role);
  int get roleLevel => getRoleLevel(widget.role);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _scanLineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();

    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      final controller =
          VideoPlayerController.asset('assets/videos/background.mp4');
      await controller.initialize();
      if (!mounted) {
        controller.dispose();
        return;
      }
      controller.setLooping(true);
      controller.setVolume(0.0);
      controller.setPlaybackSpeed(1.0);
      await controller.play();
      setState(() {
        _videoController = controller;
        _isVideoInitialized = true;
      });
    } catch (e) {
      debugPrint('Video init error: $e');
    }
  }

  void _toggleSound() {
    final ctrl = _videoController;
    if (ctrl == null || !_isVideoInitialized) return;
    setState(() {
      _isSoundOn = !_isSoundOn;
      ctrl.setVolume(_isSoundOn ? 0.7 : 0.0);
    });
  }

  @override
  void dispose() {
    _targetController.dispose();
    _delayController.dispose();
    _countController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _scanLineController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  // ─── HELPERS ─────────────────────────────────────────────
  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleaned.isEmpty) return null;
    return cleaned.startsWith('+') ? cleaned.substring(1) : cleaned;
  }

  void _toast(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            fontFamily: 'ShareTechMono',
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        duration: const Duration(seconds: 2),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  Future<bool> _hasSender() async {
    try {
      final res = await http.get(
        Uri.parse(
          'http://paultzy.pteroqhost.web.id5015/mySender?key=${widget.sessionKey}',
        ),
        headers: {'Content-Type': 'application/json'},
      );
      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      return data['valid'] == true &&
          data['connections'] != null &&
          (data['connections'] as List).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ─── DIALOG ──────────────────────────────────────────────
  void _showDialog(
    String title,
    String message,
    IconData icon,
    Color color, {
    VoidCallback? onPressed,
    String buttonLabel = 'MENGERTI',
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        insetPadding: const EdgeInsets.all(40),
        child: Container(
          width: 360,
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_C.card, _C.bgNavy],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.5), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 50,
                offset: const Offset(0, 20),
              ),
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 30,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      color.withOpacity(0.25),
                      color.withOpacity(0.08),
                    ],
                  ),
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: color.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: color.withOpacity(0.35),
                      blurRadius: 24,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Icon(icon, color: color, size: 36),
              ),
              const SizedBox(height: 28),
              Text(
                title,
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: _C.text,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.0,
                  shadows: [
                    Shadow(color: color.withOpacity(0.5), blurRadius: 12),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),
              Text(
                message,
                style: const TextStyle(
                  fontFamily: 'ShareTechMono',
                  color: _C.textSec,
                  fontSize: 14,
                  height: 1.65,
                  letterSpacing: 0.2,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    if (onPressed != null) onPressed();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: color,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Text(
                    buttonLabel,
                    style: const TextStyle(
                      fontFamily: 'Orbitron',
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SEND SEQUENTIAL PAYLOAD ─────────────────────────────
  Future<void> _sendSequentialPayload() async {
    final hasSender = await _hasSender();
    if (!hasSender) {
      _showDialog(
        'Sender Required',
        'Kamu belum punya sender aktif. Tambahkan sender terlebih dahulu sebelum mengirim payload.',
        Icons.wifi_find_rounded,
        _C.warning,
        buttonLabel: 'TAMBAH SENDER',
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BugSenderPage(
                sessionKey: widget.sessionKey,
                username: widget.username,
                role: widget.role,
              ),
            ),
          );
        },
      );
      return;
    }

    final target = _formatPhoneNumber(_targetController.text.trim());
    if (target == null || target.length < 10) {
      _toast('Format nomor tidak valid', _C.warning);
      return;
    }
    if (_selectedBugs.isEmpty) {
      _toast('Pilih minimal satu bug', _C.warning);
      return;
    }

    final delay = int.tryParse(_delayController.text) ?? 1000;
    final count = int.tryParse(_countController.text) ?? 1;
    if (delay < 0 || delay > 60000) {
      _toast('Delay harus 0-60000 ms', _C.warning);
      return;
    }
    if (count < 1 || count > 100) {
      _toast('Count harus 1-100', _C.warning);
      return;
    }

    setState(() => _isSending = true);

    try {
      final payload = {
        'key': widget.sessionKey,
        'target': target,
        'delay': delay,
        'count': count,
        'bugs': _selectedBugs.map((b) => b['bug_id']).toList(),
        'mode': 'sequential',
        'sequence_order': _selectedBugs.map((b) => b['bug_id']).toList(),
      };

      final response = await http
          .post(
            Uri.parse(
                'http://paultzy.pteroqhost.web.id5015/api/custom-payload'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final bugCount = _selectedBugs.length;
          _targetController.clear();
          setState(() => _selectedBugs.clear());
          _showSuccessSheet(target, count, delay, bugCount);
        } else {
          _toast(data['message'] ?? 'Gagal mengirim', _C.danger);
        }
      } else {
        _toast('Server error ${response.statusCode}', _C.danger);
      }
    } catch (e) {
      _toast('Koneksi error: $e', _C.danger);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showSuccessSheet(String target, int count, int delay, int bugCount) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _SuccessSheet(
        target: target,
        count: count,
        delay: delay,
        bugCount: bugCount,
        onClose: () => Navigator.pop(context),
      ),
    );
  }

  void _openBugPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) => _BugPickerSheet(
          allBugs: widget.listBug,
          selectedBugs: _selectedBugs,
          bugGradient: _C.bugGradient,
          onAdd: (bug, index) {
            if (!_selectedBugs.any((s) => s['bug_id'] == bug['bug_id'])) {
              setState(() {
                _selectedBugs.add({
                  'bug_id': bug['bug_id'],
                  'bug_name': bug['bug_name'],
                  'colorIndex': index,
                });
              });
              setSheetState(() {});
            }
          },
          onRemove: (bugId) {
            setState(() {
              _selectedBugs.removeWhere((s) => s['bug_id'] == bugId);
            });
            setSheetState(() {});
          },
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    if (!canAccessPayload) return _buildAccessDenied();

    return Scaffold(
      backgroundColor: _C.bgDeep,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // ── BACKGROUND: dashboard.png ──
          Positioned.fill(
            child: Image.asset(
              'assets/images/dashboard.png',
              fit: BoxFit.cover,
              opacity: const AlwaysStoppedAnimation(0.28),
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [_C.bgDeep, _C.bgNavy, _C.bgDeep],
                  ),
                ),
              ),
            ),
          ),
          // Blue overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.blue.withOpacity(0.20),
                    _C.bgDeep.withOpacity(0.70),
                    _C.bgDeep.withOpacity(0.88),
                  ],
                ),
              ),
            ),
          ),
          // Glow animated
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _glowController,
              builder: (_, __) => Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0.7, -0.7),
                    radius: 1.4,
                    colors: [
                      _C.cyan
                          .withOpacity(0.14 + _glowController.value * 0.06),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── CONTENT ──
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
                    child: Column(
                      children: [
                        _buildVideoBanner(),
                        const SizedBox(height: 12),
                        _buildTargetCard(),
                        const SizedBox(height: 12),
                        _buildBugQueueCard(),
                        const SizedBox(height: 12),
                        _buildConfigRow(),
                        const SizedBox(height: 16),
                        _buildSendButton(),
                        const SizedBox(height: 10),
                        _buildStatusBar(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── ACCESS DENIED ───────────────────────────────────────
  Widget _buildAccessDenied() {
    return Scaffold(
      backgroundColor: _C.bgDeep,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_C.bgDeep, _C.bgNavy, _C.bgDeep],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _C.blue.withOpacity(0.22),
                      _C.cyan.withOpacity(0.10),
                    ],
                  ),
                  border: Border.all(
                    color: _C.cyan.withOpacity(0.5),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.5),
                      blurRadius: 30,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.lock_outline_rounded,
                  color: _C.cyan,
                  size: 48,
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'AKSES DITOLAK',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                  shadows: [
                    Shadow(color: _C.cyan, blurRadius: 20),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                  'Custom Payload hanya untuk role:\nCEO, Owner, Admin, Tangan Kanan, VIP, dan Reseller',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _C.textSec,
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: _C.cyan.withOpacity(0.14),
                  border: Border.all(color: _C.cyan.withOpacity(0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.4),
                      blurRadius: 14,
                    ),
                  ],
                ),
                child: Text(
                  'Role Anda: $roleDisplay (Level $roleLevel)',
                  style: const TextStyle(
                    color: _C.cyan,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: 200,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  label: const Text(
                    'KEMBALI',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    shadowColor: _C.blue.withOpacity(0.5),
                    elevation: 8,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HEADER ──────────────────────────────────────────────
  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                _C.bgNavy.withOpacity(0.92),
                _C.bgNavy.withOpacity(0.75),
              ],
            ),
            border: Border(
              bottom: BorderSide(
                color: _C.blueLight.withOpacity(0.30),
                width: 1,
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: _C.blue.withOpacity(0.20),
                blurRadius: 20,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              // Back button
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: LinearGradient(
                      colors: [
                        _C.blue.withOpacity(0.22),
                        _C.cyan.withOpacity(0.08),
                      ],
                    ),
                    border: Border.all(
                      color: _C.blueLight.withOpacity(0.45),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.blue.withOpacity(0.35),
                        blurRadius: 14,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: _C.ice,
                    size: 18,
                  ),
                ),
              ),
              const SizedBox(width: 14),

              // Title
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (b) => const LinearGradient(
                        colors: [_C.white, _C.cyan],
                      ).createShader(b),
                      child: const Text(
                        'CUSTOM PAYLOAD',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Text(
                          'Mode Sekuensial',
                          style: TextStyle(
                            color: _C.textSec,
                            fontSize: 10.5,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: _C.cyan.withOpacity(0.14),
                            border: Border.all(
                                color: _C.cyan.withOpacity(0.5)),
                            boxShadow: [
                              BoxShadow(
                                color: _C.cyan.withOpacity(0.4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Text(
                            roleDisplay,
                            style: const TextStyle(
                              color: _C.cyan,
                              fontSize: 8,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Bug counter
              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) => Transform.scale(
                  scale: _selectedBugs.isEmpty ? 1.0 : _pulseAnimation.value,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _C.blue.withOpacity(0.28),
                          _C.cyan.withOpacity(0.08),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: _selectedBugs.isEmpty
                            ? _C.blueLight.withOpacity(0.30)
                            : _C.cyan,
                        width: 1,
                      ),
                      boxShadow: _selectedBugs.isNotEmpty
                          ? [
                              BoxShadow(
                                color: _C.cyan.withOpacity(0.75),
                                blurRadius: 22,
                              ),
                            ]
                          : [
                              BoxShadow(
                                color: _C.blue.withOpacity(0.30),
                                blurRadius: 14,
                              ),
                            ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '${_selectedBugs.length}',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            color: _selectedBugs.isEmpty
                                ? _C.textMuted
                                : _C.cyan,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            shadows: _selectedBugs.isNotEmpty
                                ? [
                                    const Shadow(
                                      color: _C.cyan,
                                      blurRadius: 12,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                        const Text(
                          'BUG',
                          style: TextStyle(
                            color: _C.ice,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── VIDEO BANNER ────────────────────────────────────────
  Widget _buildVideoBanner() {
    return VisibilityDetector(
      key: const Key('video-banner'),
      onVisibilityChanged: (info) {
        if (info.visibleFraction > 0.1) {
          _videoController?.play();
        } else {
          _videoController?.pause();
        }
      },
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _C.ice.withOpacity(0.60), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _C.blue.withOpacity(0.55),
              blurRadius: 45,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: _C.cyan.withOpacity(0.30),
              blurRadius: 30,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_isVideoInitialized && _videoController != null)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController!.value.size.width,
                    height: _videoController!.value.size.height,
                    child: VideoPlayer(_videoController!),
                  ),
                )
              else
                Container(
                  color: _C.bgDeep,
                  child: const Center(
                    child: CircularProgressIndicator(color: _C.cyan),
                  ),
                ),

              // Overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      _C.bgDeep.withOpacity(0.95),
                      _C.bgDeep.withOpacity(0.55),
                      Colors.transparent,
                      _C.blue.withOpacity(0.10),
                    ],
                    stops: const [0.0, 0.3, 0.7, 1.0],
                  ),
                ),
              ),

              // Sound button
              Positioned(
                top: 12,
                left: 12,
                child: GestureDetector(
                  onTap: _toggleSound,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      color: _C.bgDeep.withOpacity(0.78),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _isSoundOn
                            ? _C.cyan
                            : _C.cyanLight.withOpacity(0.7),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (_isSoundOn ? _C.cyan : _C.cyanLight)
                              .withOpacity(0.45),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _isSoundOn
                              ? Icons.volume_up_rounded
                              : Icons.volume_off_rounded,
                          color: _isSoundOn ? _C.cyan : _C.cyanLight,
                          size: 13,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          _isSoundOn ? 'SUARA ON' : 'SUARA OFF',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            color: _isSoundOn ? _C.cyan : _C.cyanLight,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Playing badge
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 11, vertical: 6),
                  decoration: BoxDecoration(
                    color: _C.bgDeep.withOpacity(0.72),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.cyan.withOpacity(0.7)),
                    boxShadow: [
                      BoxShadow(
                        color: _C.cyan.withOpacity(0.4),
                        blurRadius: 14,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.cyan,
                          boxShadow: [
                            BoxShadow(
                                color: _C.cyan, blurRadius: 10),
                          ],
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        'PLAYING',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          color: _C.cyan,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // VOR4X label
              const Positioned(
                bottom: 14,
                left: 18,
                child: Row(
                  children: [
                    Icon(Icons.circle, color: _C.cyan, size: 8),
                    SizedBox(width: 10),
                    Text(
                      'VOR4X',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(color: _C.cyan, blurRadius: 12),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── TARGET CARD ─────────────────────────────────────────
  Widget _buildTargetCard() {
    return _glassCard(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_C.ice, _C.blueLight, _C.blueDark],
              ),
              border: Border.all(
                color: _C.ice.withOpacity(0.7),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.blue.withOpacity(0.85),
                  blurRadius: 16,
                ),
                BoxShadow(
                  color: _C.cyan.withOpacity(0.35),
                  blurRadius: 32,
                ),
              ],
            ),
            child: const Icon(
              Icons.phone_android_rounded,
              color: _C.bgDeep,
              size: 20,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'NOMOR TARGET',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    color: _C.ice,
                    fontSize: 10,
                    letterSpacing: 1.6,
                    shadows: [
                      Shadow(color: _C.cyan, blurRadius: 8),
                    ],
                  ),
                ),
                TextField(
                  controller: _targetController,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(
                    fontFamily: 'ShareTechMono',
                    color: _C.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                  cursorColor: _C.cyan,
                  decoration: InputDecoration(
                    hintText: '62xxxxxxxxxx',
                    hintStyle: TextStyle(
                      color: _C.textSec.withOpacity(0.45),
                      fontSize: 15,
                      letterSpacing: 1,
                    ),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.only(top: 6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUG QUEUE CARD ──────────────────────────────────────
  Widget _buildBugQueueCard() {
    return _glassCard(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _C.blue.withOpacity(0.28),
                      _C.cyan.withOpacity(0.10),
                    ],
                  ),
                  border: Border.all(
                    color: _C.cyan.withOpacity(0.5),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _C.cyan.withOpacity(0.45),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.bug_report_rounded,
                  color: _C.cyan,
                  size: 15,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                'ANTRIAN PAYLOAD',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: _C.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                  shadows: [
                    Shadow(color: _C.cyan, blurRadius: 10),
                  ],
                ),
              ),
              const Spacer(),
              if (_selectedBugs.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() => _selectedBugs.clear()),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _C.danger.withOpacity(0.20),
                          _C.danger.withOpacity(0.06),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: _C.danger.withOpacity(0.5)),
                      boxShadow: [
                        BoxShadow(
                          color: _C.danger.withOpacity(0.3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: const Text(
                      'RESET',
                      style: TextStyle(
                        color: Color(0xFFFF7A8F),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          if (_selectedBugs.isNotEmpty) ...[
            const SizedBox(height: 12),
            SizedBox(
              height: 50,
              child: ReorderableListView.builder(
                scrollDirection: Axis.horizontal,
                buildDefaultDragHandles: false,
                itemCount: _selectedBugs.length,
                onReorder: (oldIndex, newIndex) {
                  setState(() {
                    if (newIndex > oldIndex) newIndex--;
                    final item = _selectedBugs.removeAt(oldIndex);
                    _selectedBugs.insert(newIndex, item);
                  });
                },
                proxyDecorator: (child, index, animation) => child,
                itemBuilder: (ctx, i) {
                  final bug = _selectedBugs[i];
                  final colors = _C.bugGradient(bug['colorIndex'] ?? i);
                  return ReorderableDragStartListener(
                    key: ValueKey(bug['bug_id']),
                    index: i,
                    child: Container(
                      margin: EdgeInsets.only(
                          right:
                              i < _selectedBugs.length - 1 ? 8 : 0),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                          colors[0].withOpacity(0.30),
                          colors[1].withOpacity(0.10),
                        ]),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(
                          color: colors[0].withOpacity(0.55),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: colors[0].withOpacity(0.40),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(colors: colors),
                              boxShadow: [
                                BoxShadow(
                                  color: colors[0].withOpacity(0.6),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                '${i + 1}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            bug['bug_name'] ?? 'Bug',
                            style: const TextStyle(
                              color: _C.white,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                              shadows: [
                                Shadow(
                                    color: _C.cyan, blurRadius: 6),
                              ],
                            ),
                          ),
                          const SizedBox(width: 5),
                          GestureDetector(
                            onTap: () => setState(
                                () => _selectedBugs.removeAt(i)),
                            child: const Icon(
                              Icons.close,
                              color: _C.ice,
                              size: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Tahan & geser untuk ubah urutan',
              style: TextStyle(
                color: _C.textSec,
                fontSize: 9.5,
                letterSpacing: 0.3,
              ),
            ),
          ],

          const SizedBox(height: 12),
          GestureDetector(
            onTap: _openBugPicker,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _C.blue.withOpacity(0.20),
                    _C.cyan.withOpacity(0.08),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _C.cyan.withOpacity(0.5),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.cyan.withOpacity(0.25),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(
                    Icons.add_circle_outline_rounded,
                    color: _C.cyan,
                    size: 17,
                  ),
                  SizedBox(width: 7),
                  Text(
                    'TAMBAH PAYLOAD',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: _C.cyan,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                      shadows: [
                        Shadow(color: _C.cyan, blurRadius: 10),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CONFIG ROW ──────────────────────────────────────────
  Widget _buildConfigRow() {
    return Row(
      children: [
        Expanded(
          child: _buildConfigTile(
            label: 'DELAY',
            sub: 'Interval (ms)',
            controller: _delayController,
            colors: const [_C.blueLight, _C.blue],
            icon: Icons.timer_outlined,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildConfigTile(
            label: 'COUNT',
            sub: 'Pengulangan',
            controller: _countController,
            colors: const [_C.cyan, _C.cyanLight],
            icon: Icons.repeat_rounded,
          ),
        ),
      ],
    );
  }

  Widget _buildConfigTile({
    required String label,
    required String sub,
    required TextEditingController controller,
    required List<Color> colors,
    required IconData icon,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors[0].withOpacity(0.22),
                colors[1].withOpacity(0.08),
              ],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: colors[0].withOpacity(0.5),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: colors[0].withOpacity(0.28),
                blurRadius: 20,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: colors[0], size: 15),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: colors[0],
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                          color: colors[0].withOpacity(0.7),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Text(
                sub,
                style: const TextStyle(
                  color: _C.textSec,
                  fontSize: 10,
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: colors[0],
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                  shadows: [
                    Shadow(
                      color: colors[0].withOpacity(0.7),
                      blurRadius: 12,
                    ),
                  ],
                ),
                cursorColor: colors[0],
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SEND BUTTON ─────────────────────────────────────────
  Widget _buildSendButton() {
    return GestureDetector(
      onTap: _isSending ? null : _sendSequentialPayload,
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (_, __) => Transform.scale(
          scale: _isSending ? 1.0 : _pulseAnimation.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            height: 58,
            decoration: BoxDecoration(
              gradient: _isSending
                  ? LinearGradient(
                      colors: [
                        _C.blue.withOpacity(0.35),
                        _C.cyan.withOpacity(0.25),
                      ],
                    )
                  : const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF2196F3),
                        Color(0xFF0D47A1),
                        Color(0xFF00D4FF),
                      ],
                    ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _C.ice.withOpacity(0.7),
                width: 1.2,
              ),
              boxShadow: _isSending
                  ? []
                  : [
                      BoxShadow(
                        color: _C.blue.withOpacity(
                            0.65 + _pulseController.value * 0.25),
                        blurRadius:
                            30 + _pulseController.value * 15,
                        spreadRadius: 2,
                        offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: _C.cyan.withOpacity(0.35),
                        blurRadius: 30,
                      ),
                    ],
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: _isSending
                    ? const Row(
                        key: ValueKey('loading'),
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 12),
                          Text(
                            'MENGIRIM...',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      )
                    : const Row(
                        key: ValueKey('idle'),
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.rocket_launch_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 12),
                          Text(
                            'KIRIM PAYLOAD',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                              shadows: [
                                Shadow(
                                  color: Color(0xFF00D4FF),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── STATUS BAR ──────────────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _C.blue.withOpacity(0.10),
            _C.cyan.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: _C.blueLight.withOpacity(0.4),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isSending
                  ? _C.warning
                  : _selectedBugs.isEmpty
                      ? _C.textMuted
                      : _C.cyan,
              boxShadow: !_isSending && _selectedBugs.isNotEmpty
                  ? [
                      BoxShadow(
                        color: _C.cyan.withOpacity(0.7),
                        blurRadius: 10,
                      ),
                    ]
                  : _isSending
                      ? [
                          BoxShadow(
                            color: _C.warning.withOpacity(0.6),
                            blurRadius: 10,
                          ),
                        ]
                      : null,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _isSending
                  ? 'Mengirim payload...'
                  : _selectedBugs.isEmpty
                      ? 'Belum ada bug dipilih'
                      : '${_selectedBugs.length} bug  •  ${_delayController.text}ms  •  ${_countController.text}x',
              style: const TextStyle(
                color: _C.ice,
                fontSize: 11.5,
                letterSpacing: 0.3,
              ),
            ),
          ),
          if (_selectedBugs.isNotEmpty && !_isSending)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
              decoration: BoxDecoration(
                color: _C.cyan.withOpacity(0.14),
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                  color: _C.cyan.withOpacity(0.5),
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.cyan.withOpacity(0.45),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: const Text(
                'READY',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: _C.cyan,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.4,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ─── GLASS CARD ──────────────────────────────────────────
  Widget _glassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                _C.blue.withOpacity(0.14),
                _C.cyan.withOpacity(0.05),
                _C.bgNavy.withOpacity(0.55),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _C.blueLight.withOpacity(0.35),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.35),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
              BoxShadow(
                color: _C.blue.withOpacity(0.15),
                blurRadius: 20,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🐛 BUG PICKER SHEET
// ═══════════════════════════════════════════════════════════
class _BugPickerSheet extends StatelessWidget {
  final List<Map<String, dynamic>> allBugs;
  final List<Map<String, dynamic>> selectedBugs;
  final List<Color> Function(int) bugGradient;
  final void Function(Map<String, dynamic>, int) onAdd;
  final void Function(String) onRemove;

  const _BugPickerSheet({
    required this.allBugs,
    required this.selectedBugs,
    required this.bugGradient,
    required this.onAdd,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.55,
      ),
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [_C.card, _C.bgNavy],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: _C.cyan.withOpacity(0.4),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: _C.cyan.withOpacity(0.20),
            blurRadius: 40,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 60,
            offset: const Offset(0, 20),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: _C.blueLight.withOpacity(0.5),
              borderRadius: BorderRadius.circular(2),
              boxShadow: [
                BoxShadow(
                  color: _C.cyan.withOpacity(0.5),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        _C.blue.withOpacity(0.28),
                        _C.cyan.withOpacity(0.10),
                      ],
                    ),
                    border: Border.all(
                      color: _C.cyan.withOpacity(0.5),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _C.cyan.withOpacity(0.45),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.bug_report_rounded,
                    color: _C.cyan,
                    size: 13,
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'PILIH PAYLOAD',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    color: _C.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    shadows: [
                      Shadow(color: _C.cyan, blurRadius: 10),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: const Icon(
                    Icons.close_rounded,
                    color: _C.ice,
                    size: 20,
                  ),
                ),
              ],
            ),
          ),
          Divider(
            color: _C.cardBorder.withOpacity(0.6),
            height: 1,
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              itemCount: allBugs.length,
              itemBuilder: (ctx, i) {
                final bug = allBugs[i];
                final isSelected = selectedBugs
                    .any((s) => s['bug_id'] == bug['bug_id']);
                final colors = bugGradient(i);
                return GestureDetector(
                  onTap: () {
                    if (isSelected) {
                      onRemove(bug['bug_id']);
                    } else {
                      onAdd(bug, i);
                    }
                  },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 9),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 11),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isSelected
                            ? [
                                colors[0].withOpacity(0.22),
                                colors[1].withOpacity(0.08),
                              ]
                            : [
                                _C.blue.withOpacity(0.06),
                                _C.cyan.withOpacity(0.02),
                              ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected
                            ? _C.cyan
                            : _C.blueLight.withOpacity(0.28),
                        width: isSelected ? 1.4 : 1.0,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: _C.cyan.withOpacity(0.5),
                                blurRadius: 18,
                              ),
                            ]
                          : null,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: colors,
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            border: Border.all(
                              color: _C.ice.withOpacity(0.5),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: colors[0].withOpacity(0.5),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.security_rounded,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                bug['bug_name'] ?? 'Unknown',
                                style: TextStyle(
                                  color: isSelected
                                      ? _C.white
                                      : _C.ice,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  shadows: isSelected
                                      ? [
                                          const Shadow(
                                            color: _C.cyan,
                                            blurRadius: 8,
                                          ),
                                        ]
                                      : null,
                                ),
                              ),
                              Text(
                                bug['bug_id'] ?? '',
                                style: TextStyle(
                                  color: _C.textSec.withOpacity(0.6),
                                  fontSize: 10,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isSelected
                                ? LinearGradient(colors: colors)
                                : null,
                            color: isSelected
                                ? null
                                : _C.blue.withOpacity(0.10),
                            border: isSelected
                                ? null
                                : Border.all(
                                    color: _C.blueLight.withOpacity(0.4),
                                  ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: colors[0].withOpacity(0.6),
                                      blurRadius: 10,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Icon(
                            isSelected ? Icons.check : Icons.add,
                            color: isSelected ? Colors.white : _C.ice,
                            size: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// ✅ SUCCESS SHEET
// ═══════════════════════════════════════════════════════════
class _SuccessSheet extends StatelessWidget {
  final String target;
  final int count;
  final int delay;
  final int bugCount;
  final VoidCallback onClose;

  const _SuccessSheet({
    required this.target,
    required this.count,
    required this.delay,
    required this.bugCount,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.fromLTRB(28, 30, 28, 26),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [_C.card, _C.bgNavy],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: _C.success.withOpacity(0.5),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: _C.success.withOpacity(0.25),
            blurRadius: 40,
            spreadRadius: 3,
          ),
          BoxShadow(
            color: _C.cyan.withOpacity(0.15),
            blurRadius: 80,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 60,
            offset: const Offset(0, 20),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_C.success, _C.cyan],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.success.withOpacity(0.55),
                  blurRadius: 28,
                  spreadRadius: 4,
                ),
                BoxShadow(
                  color: _C.cyan.withOpacity(0.35),
                  blurRadius: 50,
                ),
              ],
            ),
            child: const Icon(
              Icons.check_rounded,
              color: Colors.white,
              size: 38,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'PAYLOAD TERKIRIM',
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: _C.white,
              fontSize: 20,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
              shadows: [
                Shadow(color: _C.success, blurRadius: 14),
              ],
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Sekuens berhasil dikirim',
            style: TextStyle(
              color: _C.textSec,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _C.bgDeep.withOpacity(0.5),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: _C.blueLight.withOpacity(0.35),
              ),
            ),
            child: Column(
              children: [
                _infoRow(
                    Icons.phone_iphone_rounded, 'Target', target),
                _infoRow(Icons.bug_report_rounded, 'Payload',
                    '$bugCount bug'),
                _infoRow(Icons.repeat_rounded, 'Ulangan', '${count}x'),
                _infoRow(Icons.timer_outlined, 'Interval', '${delay}ms'),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: onClose,
              style: ElevatedButton.styleFrom(
                backgroundColor: _C.success,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                shadowColor: _C.success.withOpacity(0.5),
              ),
              child: const Text(
                'SELESAI',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '© VOR4X 2026 • Powered by @ZIL • @DANZ',
            style: TextStyle(
              color: _C.textSec,
              fontSize: 10,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.success.withOpacity(0.14),
              border: Border.all(
                color: _C.success.withOpacity(0.4),
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.success.withOpacity(0.35),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Icon(icon, color: _C.success, size: 12),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: _C.ice,
                fontSize: 12.5,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: _C.white,
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              shadows: [
                Shadow(color: _C.cyan, blurRadius: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }
}