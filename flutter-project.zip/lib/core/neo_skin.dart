import 'package:flutter/material.dart';

/// Identitas theme NovaCore.
///
/// Hanya 3 theme yang ditampilkan di Theme Picker:
/// - goldEmerald   (GOLD & EMERALD)
/// - amethystViolet (AMETHYST & VIOLET)
/// - neonCyber     (NEON CYBER)
///
/// `midnight` & `bubbleGum` dipertahankan sebagai alias kompatibilitas
/// (storage lama) agar tidak menyebabkan error maupun kehilangan data,
/// tetapi TIDAK muncul di Theme Picker.
class NeoSkinId {
  NeoSkinId._();

  static const String goldEmerald = 'goldEmerald';
  static const String amethystViolet = 'amethystViolet';
  static const String neonCyber = 'neonCyber';

  // --- Kompatibilitas lama ---
  static const String midnight = 'midnight';
  static const String bubbleGum = 'bubbleGum';

  static const List<String> pickerOrder = [
    goldEmerald,
    amethystViolet,
    neonCyber,
  ];

  static bool isPickerSkin(String id) => pickerOrder.contains(id);
}

/// Palette NovaCore — token visual global yang dipakai seluruh UI.
class NeoPalette {
  final String id;
  final String label;
  final String subtitle;

  // --- Background ---
  final Color background;
  final Color backgroundSecondary;
  final Color backgroundOverlay;

  // --- Surface ---
  final Color surface;
  final Color surfaceElevated;
  final Color surfaceGlass;
  final Color surfaceGlassStrong;

  // --- Brand ---
  final Color primary;
  final Color secondary;
  final Color accent;

  // --- Text ---
  final Color textPrimary;
  final Color textSecondary;
  final Color textMuted;
  final Color textOnAccent;

  // --- Icon ---
  final Color icon;
  final Color iconMuted;

  // --- Border ---
  final Color border;
  final Color borderSubtle;
  final Color borderStrong;

  // --- Selected ---
  final Color selected;
  final Color selectedBackground;
  final Color selectedBorder;
  final Color selectedText;

  // --- Input ---
  final Color inputBackground;
  final Color inputBorder;
  final Color inputFocus;
  final Color inputHint;

  // --- Button ---
  final Color buttonBackground;
  final Color buttonText;
  final Color buttonPressed;
  final Color buttonDisabled;

  // --- Navbar ---
  final Color navbarBackground;
  final Color navbarBorder;
  final Color navbarActive;
  final Color navbarInactive;
  final Color navbarIndicator;

  // --- Glow / Shadow ---
  final Color glow;
  final Color glowSecondary;
  final Color shadow;

  // --- Status / Semantic ---
  final Color success;
  final Color warning;
  final Color danger;
  final Color info;

  final Color divider;

  // Tinta untuk teks/ikon di-atas primary/gold (theme-aware, default ~bisa tua).
  final Color ink;

  // Kompatibilitas dengan kode lama (tulisan di-atas primary/aplikasi).
  final Color onBackground1;

  const NeoPalette({
    required this.id,
    required this.label,
    this.subtitle = '',
    required this.background,
    required this.backgroundSecondary,
    required this.backgroundOverlay,
    required this.surface,
    required this.surfaceElevated,
    required this.surfaceGlass,
    required this.surfaceGlassStrong,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.textPrimary,
    required this.textSecondary,
    required this.textMuted,
    required this.textOnAccent,
    required this.icon,
    required this.iconMuted,
    required this.border,
    required this.borderSubtle,
    required this.borderStrong,
    required this.selected,
    required this.selectedBackground,
    required this.selectedBorder,
    required this.selectedText,
    required this.inputBackground,
    required this.inputBorder,
    required this.inputFocus,
    required this.inputHint,
    required this.buttonBackground,
    required this.buttonText,
    required this.buttonPressed,
    required this.buttonDisabled,
    required this.navbarBackground,
    required this.navbarBorder,
    required this.navbarActive,
    required this.navbarInactive,
    required this.navbarIndicator,
    required this.glow,
    required this.glowSecondary,
    required this.shadow,
    required this.success,
    required this.warning,
    required this.danger,
    required this.info,
    required this.divider,
    required this.ink,
    required this.onBackground1,
  });
}

class NeoSkin {
  NeoSkin._();

  static const NeoPalette goldEmerald = NeoPalette(
    id: NeoSkinId.goldEmerald,
    label: 'GOLD & EMERALD',
    subtitle: 'Royal · Luxury · Warm Gold',
    background: Color(0xFF0B1D16),
    backgroundSecondary: Color(0xFF081511),
    backgroundOverlay: Color(0xFF102B21),
    surface: Color(0xFF11291F),
    surfaceElevated: Color(0xFF17352A),
    surfaceGlass: Color(0x14FFFFFF),
    surfaceGlassStrong: Color(0x26FFFFFF),
    primary: Color(0xFFFFD98A),
    secondary: Color(0xFF3DD3A5),
    accent: Color(0xFF2ECC71),
    textPrimary: Color(0xFFFFF9EA),
    textSecondary: Color(0xFFC6DCD3),
    textMuted: Color(0xFF8AA69B),
    textOnAccent: Color(0xFF15251E),
    icon: Color(0xFFFFE9B0),
    iconMuted: Color(0xFF9DB8AC),
    border: Color(0x66FFD98A),
    borderSubtle: Color(0x1AFFFFFF),
    borderStrong: Color(0x99FFD98A),
    selected: Color(0xFFFFD98A),
    selectedBackground: Color(0x22FFD98A),
    selectedBorder: Color(0x66FFD98A),
    selectedText: Color(0xFFFFF3C4),
    inputBackground: Color(0x0DFFFFFF),
    inputBorder: Color(0x33FFFFFF),
    inputFocus: Color(0xFFFFD98A),
    inputHint: Color(0x80FBF5E6),
    buttonBackground: Color(0xFFFFD98A),
    buttonText: Color(0xFF21180A),
    buttonPressed: Color(0xFFC6A15B),
    buttonDisabled: Color(0x22FFFFFF),
    navbarBackground: Color(0xE60F241C),
    navbarBorder: Color(0x55FFD98A),
    navbarActive: Color(0xFFFFD98A),
    navbarInactive: Color(0xFFAEC5B8),
    navbarIndicator: Color(0xFFFFD98A),
    glow: Color(0xFFFFD98A),
    glowSecondary: Color(0xFF3DD3A5),
    shadow: Color(0x66000000),
    success: Color(0xFF3DD3A5),
    warning: Color(0xFFFFC24D),
    danger: Color(0xFFFF5C7A),
    info: Color(0xFF5BC8FF),
    divider: Color(0x22FFFFFF),
    ink: Color(0xFF0D0D2B),
    onBackground1: Color(0xFFFFF3C4),
  );

  static const NeoPalette amethystViolet = NeoPalette(
    id: NeoSkinId.amethystViolet,
    label: 'AMETHYST & VIOLET',
    subtitle: 'Elegant · Mystic · Deep Purple',
    background: Color(0xFF150B26),
    backgroundSecondary: Color(0xFF100820),
    backgroundOverlay: Color(0xFF1C0F33),
    surface: Color(0xFF1C1133),
    surfaceElevated: Color(0xFF261544),
    surfaceGlass: Color(0x14FFFFFF),
    surfaceGlassStrong: Color(0x24FFFFFF),
    primary: Color(0xFFA78BFA),
    secondary: Color(0xFF8B5CF6),
    accent: Color(0xFFC4B5FD),
    textPrimary: Color(0xFFF4EFFF),
    textSecondary: Color(0xFFCFC4E9),
    textMuted: Color(0xFF9A8CBF),
    textOnAccent: Color(0xFF180E2B),
    icon: Color(0xFFC4B5FD),
    iconMuted: Color(0xFF9A8CBF),
    border: Color(0x66B794FA),
    borderSubtle: Color(0x1AFFFFFF),
    borderStrong: Color(0x99C4B5FD),
    selected: Color(0xFFC4B5FD),
    selectedBackground: Color(0x22B794FA),
    selectedBorder: Color(0x66B794FA),
    selectedText: Color(0xFFFFF6FF),
    inputBackground: Color(0x0DFFFFFF),
    inputBorder: Color(0x33FFFFFF),
    inputFocus: Color(0xFFA78BFA),
    inputHint: Color(0x80E8DFFF),
    buttonBackground: Color(0xFFA78BFA),
    buttonText: Color(0xFF180E2B),
    buttonPressed: Color(0xFF7C5CE0),
    buttonDisabled: Color(0x22FFFFFF),
    navbarBackground: Color(0xE61D1231),
    navbarBorder: Color(0x55A78BFA),
    navbarActive: Color(0xFFC4B5FD),
    navbarInactive: Color(0xFFB9AAD9),
    navbarIndicator: Color(0xFFA78BFA),
    glow: Color(0xFFA78BFA),
    glowSecondary: Color(0xFF7C5CE0),
    shadow: Color(0x66000000),
    success: Color(0xFF3DD3A5),
    warning: Color(0xFFFFC24D),
    danger: Color(0xFFFF5C7A),
    info: Color(0xFF5BC8FF),
    divider: Color(0x22FFFFFF),
    ink: Color(0xFF1B1030),
    onBackground1: Color(0xFFF4EFFF),
  );

  static const NeoPalette neonCyber = NeoPalette(
    id: NeoSkinId.neonCyber,
    label: 'NEON CYBER',
    subtitle: 'Futuristic · Cyber · High-Tech',
    background: Color(0xFF05070B),
    backgroundSecondary: Color(0xFF04070D),
    backgroundOverlay: Color(0xFF0A0F16),
    surface: Color(0xFF0B0F16),
    surfaceElevated: Color(0xFF141B26),
    surfaceGlass: Color(0x14FFFFFF),
    surfaceGlassStrong: Color(0x22FFFFFF),
    primary: Color(0xFF00E5FF),
    secondary: Color(0xFF7C5CFF),
    accent: Color(0xFFFF2FB3),
    textPrimary: Color(0xFFEAF4FF),
    textSecondary: Color(0xFFA7BCCC),
    textMuted: Color(0xFF5D7188),
    textOnAccent: Color(0xFF001722),
    icon: Color(0xFF00E5FF),
    iconMuted: Color(0xFF5D7188),
    border: Color(0x6600E5FF),
    borderSubtle: Color(0x1AFFFFFF),
    borderStrong: Color(0x9900E5FF),
    selected: Color(0xFF00E5FF),
    selectedBackground: Color(0x1F00E5FF),
    selectedBorder: Color(0x6600E5FF),
    selectedText: Color(0xFFBFF6FF),
    inputBackground: Color(0x0AFFFFFF),
    inputBorder: Color(0x26FFFFFF),
    inputFocus: Color(0xFF00E5FF),
    inputHint: Color(0x80B8E8F5),
    buttonBackground: Color(0xFF00E5FF),
    buttonText: Color(0xFF00131A),
    buttonPressed: Color(0xFF008FBF),
    buttonDisabled: Color(0x1FFFFFFF),
    navbarBackground: Color(0xEB06090F),
    navbarBorder: Color(0x5500E5FF),
    navbarActive: Color(0xFF00E5FF),
    navbarInactive: Color(0xFF7793AC),
    navbarIndicator: Color(0xFF00E5FF),
    glow: Color(0xFF00E5FF),
    glowSecondary: Color(0xFFFF2FB3),
    shadow: Color(0x66000000),
    success: Color(0xFF3DD3A5),
    warning: Color(0xFFFFC24D),
    danger: Color(0xFFFF5C7A),
    info: Color(0xFF5BC8FF),
    divider: Color(0x1FFFFFFF),
    ink: Color(0xFF05070D),
    onBackground1: Color(0xFFEAF4FF),
  );

  // --- Kompatibilitas lama (tidak muncul di Theme Picker) ---
  static const NeoPalette midnight = NeoPalette(
    id: NeoSkinId.midnight,
    label: 'MIDNIGHT',
    subtitle: '',
    background: Color(0xFF0B0D1F),
    backgroundSecondary: Color(0xFF080A18),
    backgroundOverlay: Color(0xFF14142A),
    surface: Color(0xFF14142A),
    surfaceElevated: Color(0xFF1D1D38),
    surfaceGlass: Color(0x14FFFFFF),
    surfaceGlassStrong: Color(0x24FFFFFF),
    primary: Color(0xFF9B6BFF),
    secondary: Color(0xFFFFB84D),
    accent: Color(0xFF36C5F0),
    textPrimary: Color(0xFFFFFFFF),
    textSecondary: Color(0xFFB8B8CF),
    textMuted: Color(0xFF8A8AA6),
    textOnAccent: Color(0xFF100B20),
    icon: Color(0xFFC9B8FF),
    iconMuted: Color(0xFF8A8AA6),
    border: Color(0x449B6BFF),
    borderSubtle: Color(0x1AFFFFFF),
    borderStrong: Color(0x999B6BFF),
    selected: Color(0xFF9B6BFF),
    selectedBackground: Color(0x229B6BFF),
    selectedBorder: Color(0x449B6BFF),
    selectedText: Color(0xFFF4EEFF),
    inputBackground: Color(0x0DFFFFFF),
    inputBorder: Color(0x33FFFFFF),
    inputFocus: Color(0xFF9B6BFF),
    inputHint: Color(0x80E8DFFF),
    buttonBackground: Color(0xFF9B6BFF),
    buttonText: Color(0xFF100B20),
    buttonPressed: Color(0xFF6B3FD6),
    buttonDisabled: Color(0x22FFFFFF),
    navbarBackground: Color(0xE614142A),
    navbarBorder: Color(0x449B6BFF),
    navbarActive: Color(0xFF9B6BFF),
    navbarInactive: Color(0xFFA9A9C3),
    navbarIndicator: Color(0xFF9B6BFF),
    glow: Color(0xFF9B6BFF),
    glowSecondary: Color(0xFF36C5F0),
    shadow: Color(0x66000000),
    success: Color(0xFF3DD3A5),
    warning: Color(0xFFFFC24D),
    danger: Color(0xFFFF5C7A),
    info: Color(0xFF5BC8FF),
    divider: Color(0x22FFFFFF),
    ink: Color(0xFF0D0D2B),
    onBackground1: Color(0xFFFFFFFF),
  );

  static const NeoPalette bubbleGum = NeoPalette(
    id: NeoSkinId.bubbleGum,
    label: 'BUBBLE GUM',
    subtitle: '',
    background: Color(0xFF241126),
    backgroundSecondary: Color(0xFF1C0C1F),
    backgroundOverlay: Color(0xFF3A1D3D),
    surface: Color(0xFF3A1D3D),
    surfaceElevated: Color(0xFF4A2547),
    surfaceGlass: Color(0x14FFFFFF),
    surfaceGlassStrong: Color(0x24FFFFFF),
    primary: Color(0xFFFF78B5),
    secondary: Color(0xFFFFB86B),
    accent: Color(0xFFB98CFF),
    textPrimary: Color(0xFFFFEAF5),
    textSecondary: Color(0xFFE8C9D8),
    textMuted: Color(0xFFB497A8),
    textOnAccent: Color(0xFF2B1020),
    icon: Color(0xFFFFA8CE),
    iconMuted: Color(0xFFB497A8),
    border: Color(0x66FF78B5),
    borderSubtle: Color(0x1AFFFFFF),
    borderStrong: Color(0x99FF9EC9),
    selected: Color(0xFFFF78B5),
    selectedBackground: Color(0x22FF78B5),
    selectedBorder: Color(0x66FF78B5),
    selectedText: Color(0xFFFFF0F7),
    inputBackground: Color(0x0DFFFFFF),
    inputBorder: Color(0x33FFFFFF),
    inputFocus: Color(0xFFFF78B5),
    inputHint: Color(0x80FFE3EF),
    buttonBackground: Color(0xFFFF78B5),
    buttonText: Color(0xFF2B1020),
    buttonPressed: Color(0xFFE0559A),
    buttonDisabled: Color(0x22FFFFFF),
    navbarBackground: Color(0xE63A1D3D),
    navbarBorder: Color(0x66FF9EC9),
    navbarActive: Color(0xFFFF78B5),
    navbarInactive: Color(0xFFE0B5C8),
    navbarIndicator: Color(0xFFFF78B5),
    glow: Color(0xFFFF78B5),
    glowSecondary: Color(0xFFB98CFF),
    shadow: Color(0x66000000),
    success: Color(0xFF3DD3A5),
    warning: Color(0xFFFFC24D),
    danger: Color(0xFFFF5C7A),
    info: Color(0xFF5BC8FF),
    divider: Color(0x26FFFFFF),
    ink: Color(0xFF0D0D2B),
    onBackground1: Color(0xFFFFEAF5),
  );

  static const Map<String, NeoPalette> byId = <String, NeoPalette>{
    NeoSkinId.goldEmerald: goldEmerald,
    NeoSkinId.amethystViolet: amethystViolet,
    NeoSkinId.neonCyber: neonCyber,
    NeoSkinId.midnight: midnight,
    NeoSkinId.bubbleGum: bubbleGum,
  };

  static const NeoPalette defaultPalette = goldEmerald;

  static String defaultId = NeoSkinId.goldEmerald;

  static NeoPalette of(String id) => byId[id] ?? defaultPalette;
}