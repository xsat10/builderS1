import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// HAPUS import 'api_config.dart'; 
// HAPUS import 'dashboard_page.dart'; (tidak digunakan)

class CEOPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const CEOPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<CEOPage> createState() => _CEOPageState();
}

class _CEOPageState extends State<CEOPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _daysController = TextEditingController();
  final TextEditingController _targetDeleteController = TextEditingController();

  String _selectedRole = 'owner';
  bool _isLoading = false;
  String _message = '';
  bool _isSuccess = false;

  // Base URL API - TAMBAHKAN INI
  final String _baseUrl = 'http://paultzy.pteroqhost.web.id5015';

  // Role yang bisa dibuat oleh CEO (turun temurun)
  final List<String> _availableRoles = [
    'owner',
    'admin',
    'tangan_kanan',
    'vip',
    'reseller',
    'full_up',
    'member_perbulan',
    'member_perminggu',
    'member_perhari',
  ];

  String getRoleDisplay(String role) {
    switch (role.toLowerCase()) {
      case 'developers': return 'DEVELOPERS';
      case 'ceo': return 'CEO';
      case 'owner': return 'OWNER';
      case 'admin': return 'ADMIN';
      case 'tangan_kanan': return 'TANGAN KANAN';
      case 'vip': return 'VIP';
      case 'reseller': return 'RESELLER';
      case 'full_up': return 'FULL UP';
      case 'member_perbulan': return 'MEMBER BULANAN';
      case 'member_perminggu': return 'MEMBER MINGGUAN';
      case 'member_perhari': return 'MEMBER HARIAN';
      default: return role.toUpperCase();
    }
  }

  Color getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case 'developers': return const Color(0xFFFF00FF);
      case 'ceo': return const Color(0xFFFFD700);
      case 'owner': return const Color(0xFFFF1744);
      case 'admin': return const Color(0xFFF59E0B);
      case 'tangan_kanan': return const Color(0xFF8B5CF6);
      case 'vip': return const Color(0xFFEC4899);
      case 'reseller': return const Color(0xFF22C55E);
      case 'full_up': return const Color(0xFF10B981);
      case 'member_perbulan': return const Color(0xFF3B82F6);
      case 'member_perminggu': return const Color(0xFFF97316);
      case 'member_perhari': return const Color(0xFF6B7280);
      default: return Colors.white;
    }
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _daysController.dispose();
    _targetDeleteController.dispose();
    super.dispose();
  }

  Future<void> _createAccount() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();
    final days = int.tryParse(_daysController.text.trim()) ?? 0;

    if (username.isEmpty || password.isEmpty || days <= 0) {
      setState(() {
        _message = '❌ Isi semua field dengan benar!';
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _message = '';
    });

    try {
      // PERBAIKI: Gunakan _baseUrl bukan ApiConfig.baseUrl
      final url = Uri.parse(
        '$_baseUrl/userAdd?key=${widget.sessionKey}&username=$username&password=$password&role=$_selectedRole&day=$days'
      );

      final response = await http.get(url).timeout(
        const Duration(seconds: 15),
      );

      final data = jsonDecode(response.body);

      if (mounted) {
        setState(() {
          _isLoading = false;
          if (data['created'] == true) {
            _isSuccess = true;
            _message = '✅ Akun berhasil dibuat!';
            _usernameController.clear();
            _passwordController.clear();
            _daysController.clear();
          } else {
            _isSuccess = false;
            _message = '❌ ${data['message'] ?? 'Gagal membuat akun'}';
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _isSuccess = false;
          _message = '❌ Error: ${e.toString()}';
        });
      }
    }
  }

  Future<void> _deleteAccount() async {
    final target = _targetDeleteController.text.trim();

    if (target.isEmpty) {
      setState(() {
        _message = '❌ Masukkan username target!';
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _message = '';
    });

    try {
      // PERBAIKI: Gunakan _baseUrl bukan ApiConfig.baseUrl
      final url = Uri.parse(
        '$_baseUrl/deleteUser?key=${widget.sessionKey}&username=$target'
      );

      final response = await http.get(url).timeout(
        const Duration(seconds: 15),
      );

      final data = jsonDecode(response.body);

      if (mounted) {
        setState(() {
          _isLoading = false;
          if (data['deleted'] == true) {
            _isSuccess = true;
            _message = '✅ Akun berhasil dihapus!';
            _targetDeleteController.clear();
          } else {
            _isSuccess = false;
            _message = '❌ ${data['message'] ?? 'Gagal menghapus akun'}';
          }
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _isSuccess = false;
          _message = '❌ Error: ${e.toString()}';
        });
      }
    }
  }

  // ─── BUILD (SAMA SEPERTI SEBELUMNYA) ──────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E17),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0E17),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFFFD700),
              ),
              child: const Center(
                child: Icon(
                  Icons.workspace_premium_rounded,
                  color: Colors.black,
                  size: 20,
                ),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'CEO PAGE',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
              ),
            ),
          ],
        ),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: const Color(0xFFFFD700).withOpacity(0.15),
              border: Border.all(
                color: const Color(0xFFFFD700).withOpacity(0.3),
              ),
            ),
            child: const Text(
              'CEO',
              style: TextStyle(
                color: Color(0xFFFFD700),
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ─── INFO CARD ──────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFFFFD700).withOpacity(0.15),
                    const Color(0xFFFFA000).withOpacity(0.05),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFFFFD700).withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.info_outline_rounded,
                    color: Color(0xFFFFD700),
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'CEO Privilege',
                          style: TextStyle(
                            color: Color(0xFFFFD700),
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(
                          'Dapat membuat akun dari OWNER sampai MEMBER HARIAN',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.6),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ─── DELETE USER ────────────────────────────────────────────
            _buildSectionTitle('DELETE USER', Icons.delete_outline_rounded, Colors.red),
            const SizedBox(height: 8),
            _buildDeleteUserCard(),
            const SizedBox(height: 24),

            // ─── CREATE ACCOUNT ──────────────────────────────────────────
            _buildSectionTitle('CREATE ACCOUNT', Icons.person_add_alt_1_rounded, Colors.green),
            const SizedBox(height: 8),
            _buildCreateAccountCard(),
            const SizedBox(height: 24),

            // ─── MESSAGE ──────────────────────────────────────────────
            if (_message.isNotEmpty)
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: _isSuccess
                      ? Colors.green.withOpacity(0.12)
                      : Colors.red.withOpacity(0.12),
                  border: Border.all(
                    color: _isSuccess
                        ? Colors.green.withOpacity(0.3)
                        : Colors.red.withOpacity(0.3),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _isSuccess ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                      color: _isSuccess ? Colors.green : Colors.red,
                      size: 20,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _message,
                        style: TextStyle(
                          color: _isSuccess ? Colors.green : Colors.red,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 20),

            // ─── FOOTER ──────────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: const Color(0xFF1A1F2E),
                border: Border.all(
                  color: const Color(0xFFFFD700).withOpacity(0.1),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFFFFD700),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFFD700).withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'CEO · ${widget.username}',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 11,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon, Color color) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.12),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Center(child: Icon(icon, color: color, size: 16)),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  Widget _buildDeleteUserCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF131B2A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFF2A3A52).withOpacity(0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Username Target',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _targetDeleteController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan username target',
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF0A0E17),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              prefixIcon: const Icon(Icons.person_outline_rounded, color: Colors.white38),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isLoading ? null : _deleteAccount,
              icon: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    )
                  : const Icon(Icons.delete_forever_rounded, size: 18),
              label: Text(_isLoading ? 'Menghapus...' : 'DELETE ACCOUNT'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade900,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateAccountCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF131B2A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFF2A3A52).withOpacity(0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Username',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _usernameController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan username',
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF0A0E17),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              prefixIcon: const Icon(Icons.person_outline_rounded, color: Colors.white38),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Password',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _passwordController,
            obscureText: true,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan password',
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF0A0E17),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              prefixIcon: const Icon(Icons.lock_outline_rounded, color: Colors.white38),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Role',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF0A0E17),
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedRole,
                dropdownColor: const Color(0xFF131B2A),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                ),
                icon: const Icon(Icons.arrow_drop_down_rounded, color: Colors.white54),
                isExpanded: true,
                items: _availableRoles.map((role) {
                  return DropdownMenuItem<String>(
                    value: role,
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: getRoleColor(role),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Text(getRoleDisplay(role)),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _selectedRole = value);
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'ADD DAYS',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _daysController,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan jumlah hari (contoh: 30)',
              hintStyle: const TextStyle(color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF0A0E17),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              prefixIcon: const Icon(Icons.calendar_today_rounded, color: Colors.white38),
              suffixText: 'HARI',
              suffixStyle: const TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _createAccount,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00E676),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 0,
                disabledBackgroundColor: Colors.grey.shade800,
              ),
              child: _isLoading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: Colors.black,
                        strokeWidth: 2,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_circle_outline_rounded, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'CREATE ACCOUNT',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}