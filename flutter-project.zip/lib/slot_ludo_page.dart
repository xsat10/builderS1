import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

// ─── PALETTE RAINBOW CYBER ──────────────────────────────────────────────
class _C {
  static const bg          = Color(0xFF0A0015);
  static const surface     = Color(0xFF15002A);
  static const card        = Color(0xFF1A0A2E);
  static const border      = Color(0xFF5B2D8E);
  static const purple      = Color(0xFF7C3AED);
  static const purpleL     = Color(0xFFA78BFA);
  static const pink        = Color(0xFFE879F9);
  static const cyan        = Color(0xFF67E8F9);
  static const green       = Color(0xFF34D399);
  static const yellow      = Color(0xFFFBBF24);
  static const orange      = Color(0xFFFB923C);
  static const red         = Color(0xFFF87171);
  static const gold        = Color(0xFFFFD700);
  static const text        = Color(0xFFF3E8FF);
  static const textSub     = Color(0xFFD4C4F0);
  static const textDim     = Color(0xFF8B7AAA);
  static const white       = Color(0xFFFFFFFF);
  static const List<Color> rainbow = [purple, pink, cyan, green, yellow, orange, red, purpleL];
}

// ─── SLOT MACHINE ──────────────────────────────────────────────────────────
class SlotMachineTools extends StatefulWidget {
  final String username;
  const SlotMachineTools({super.key, required this.username});

  @override
  State<SlotMachineTools> createState() => _SlotMachineToolsState();
}

class _SlotMachineToolsState extends State<SlotMachineTools>
    with SingleTickerProviderStateMixin {
  final math.Random _random = math.Random();
  final List<String> _icons = ["🍒", "🍊", "🍋", "🍉", "⭐", "💎", "7️⃣", "🎰"];

  String _reel1 = "🎰", _reel2 = "🎰", _reel3 = "🎰";
  int _score = 100, _bet = 10;
  bool _isSpinning = false;
  String _resultMessage = "Tekan SPIN untuk mulai!";

  late AnimationController _pulseCtrl, _rotateCtrl, _shakeCtrl;
  late Animation<double> _pulseAnim, _shakeAnim;

  Timer? _clockTimer;
  String _timeWIB = '--:--:--', _timeWITA = '--:--:--', _timeWIT = '--:--:--';
  bool _showColon = true;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
    _rotateCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _shakeAnim = Tween<double>(begin: 0, end: 10).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn));
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateClock();
      setState(() => _showColon = !_showColon);
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _pulseCtrl.dispose();
    _rotateCtrl.dispose();
    _shakeCtrl.dispose();
    super.dispose();
  }

  void _updateClock() {
    final now = DateTime.now().toUtc();
    final wib = now.add(const Duration(hours: 7));
    final wita = now.add(const Duration(hours: 8));
    final wit = now.add(const Duration(hours: 9));
    setState(() {
      _timeWIB = _formatTime(wib);
      _timeWITA = _formatTime(wita);
      _timeWIT = _formatTime(wit);
    });
  }

  String _formatTime(DateTime time) => '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}';

  void _spin() {
    if (_isSpinning) return;
    if (_score < _bet) {
      setState(() => _resultMessage = "❌ Saldo tidak cukup!");
      return;
    }
    setState(() { _isSpinning = true; _resultMessage = "🔄 Memutar..."; _score -= _bet; });
    int spinCount = 0;
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (spinCount >= 15) { timer.cancel(); _stopSpin(); }
      else {
        setState(() {
          _reel1 = _icons[_random.nextInt(_icons.length)];
          _reel2 = _icons[_random.nextInt(_icons.length)];
          _reel3 = _icons[_random.nextInt(_icons.length)];
        });
        spinCount++;
      }
    });
  }

  void _stopSpin() {
    final int winAmount = _calculateWin();
    setState(() {
      _isSpinning = false;
      if (winAmount > 0) {
        _score += winAmount;
        _resultMessage = "🎉 MENANG! +$winAmount koin! 🎉";
        _shakeCtrl.forward(from: 0);
      } else if (_reel1 == _reel2 && _reel2 == _reel3) {
        _score += _bet * 5;
        _resultMessage = "✨ JACKPOT! +${_bet * 5} koin! ✨";
        _shakeCtrl.forward(from: 0);
      } else {
        _resultMessage = "😢 Coba lagi!";
      }
    });
  }

  int _calculateWin() {
    if (_reel1 == "7️⃣" && _reel2 == "7️⃣" && _reel3 == "7️⃣") return _bet * 10;
    if (_reel1 == "💎" && _reel2 == "💎" && _reel3 == "💎") return _bet * 8;
    if (_reel1 == "⭐" && _reel2 == "⭐" && _reel3 == "⭐") return _bet * 6;
    if (_reel1 == _reel2 && _reel2 == _reel3) return _bet * 3;
    if (_reel1 == _reel2 || _reel2 == _reel3 || _reel1 == _reel3) return _bet * 1;
    return 0;
  }

  void _changeBet(int amount) {
    if (_isSpinning) return;
    int newBet = _bet + amount;
    if (newBet >= 5 && newBet <= 50) setState(() => _bet = newBet);
  }

  void _takeFreeCoins() {
    if (_isSpinning) return;
    setState(() { _score += 50; _resultMessage = "🎁 +50 koin gratis! 🎁"; });
  }

  void _shareScore() {
    Share.share("🎰 SLOT MACHINE 🎰\n💰 Koin: $_score\n🎲 Bet: $_bet\n🎯 Hasil: $_reel1 $_reel2 $_reel3");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        title: const Text("Slot Machine", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        backgroundColor: _C.purple,
        centerTitle: true,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.share, color: _C.gold), onPressed: _shareScore),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDigitalClock(),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildReel(_reel1),
                  const SizedBox(width: 10),
                  _buildReel(_reel2),
                  const SizedBox(width: 10),
                  _buildReel(_reel3),
                ],
              ),
              const SizedBox(height: 20),
              Text("💰 $_score", style: const TextStyle(color: _C.gold, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              const SizedBox(height: 10),
              Text("Bet: $_bet", style: const TextStyle(color: _C.textSub, fontSize: 14, fontFamily: 'ShareTechMono')),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: _spin,
                child: AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, __) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [_C.gold, _C.orange]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.3), blurRadius: 20 + _pulseAnim.value * 10)],
                    ),
                    child: _isSpinning
                        ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                        : const Text("SPIN", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18, fontFamily: 'Orbitron')),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildSmallBtn("- BET", () => _changeBet(-5)),
                  const SizedBox(width: 10),
                  _buildSmallBtn("FREE", _takeFreeCoins),
                  const SizedBox(width: 10),
                  _buildSmallBtn("+ BET", () => _changeBet(5)),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.border),
                ),
                child: Text(_resultMessage, style: const TextStyle(color: _C.textSub, fontSize: 13, fontFamily: 'ShareTechMono')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDigitalClock() => Container(
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
    decoration: BoxDecoration(
      color: _C.card.withOpacity(0.4),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _C.rainbow[DateTime.now().second % _C.rainbow.length].withOpacity(0.2), width: 1),
    ),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _clockItem('WIB', _timeWIB, _C.purpleL),
        _clockItem('WITA', _timeWITA, _C.pink),
        _clockItem('WIT', _timeWIT, _C.cyan),
      ],
    ),
  );

  Widget _clockItem(String label, String time, Color color) => Column(
    children: [
      Text(label, style: TextStyle(color: _C.textDim.withOpacity(0.5), fontSize: 8, fontWeight: FontWeight.w600, fontFamily: 'Orbitron')),
      Text(time, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'Orbitron', shadows: [Shadow(color: color.withOpacity(0.3), blurRadius: 12)])),
    ],
  );

  Widget _buildReel(String icon) => Container(
    width: 70, height: 70,
    decoration: BoxDecoration(
      color: _C.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _C.gold.withOpacity(0.3)),
    ),
    child: Center(child: Text(icon, style: const TextStyle(fontSize: 40))),
  );

  Widget _buildSmallBtn(String label, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: _C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
      ),
      child: Text(label, style: const TextStyle(color: _C.textSub, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
    ),
  );
}

// ─── LUDO KING ──────────────────────────────────────────────────────────────
class LudoKingTools extends StatefulWidget {
  final String username;
  const LudoKingTools({super.key, required this.username});

  @override
  State<LudoKingTools> createState() => _LudoKingToolsState();
}

class _LudoKingToolsState extends State<LudoKingTools>
    with SingleTickerProviderStateMixin {
  final math.Random _random = math.Random();
  int _diceValue = 1;
  bool _isRolling = false;
  String _result = "Tap dadu untuk mulai!";
  int _playerPos = 0, _aiPos = 0;
  bool _isPlayerTurn = true;

  late AnimationController _pulseCtrl, _rotateCtrl;
  late Animation<double> _pulseAnim;

  Timer? _clockTimer;
  String _timeWIB = '--:--:--', _timeWITA = '--:--:--', _timeWIT = '--:--:--';
  bool _showColon = true;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat(reverse: true);
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
    _rotateCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateClock();
      setState(() => _showColon = !_showColon);
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _pulseCtrl.dispose();
    _rotateCtrl.dispose();
    super.dispose();
  }

  void _updateClock() {
    final now = DateTime.now().toUtc();
    final wib = now.add(const Duration(hours: 7));
    final wita = now.add(const Duration(hours: 8));
    final wit = now.add(const Duration(hours: 9));
    setState(() {
      _timeWIB = _formatTime(wib);
      _timeWITA = _formatTime(wita);
      _timeWIT = _formatTime(wit);
    });
  }

  String _formatTime(DateTime time) => '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}';

  void _rollDice() {
    if (_isRolling) return;
    setState(() { _isRolling = true; });
    int rollCount = 0;
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (rollCount >= 10) {
        timer.cancel();
        final int value = _random.nextInt(6) + 1;
        setState(() {
          _diceValue = value;
          _isRolling = false;
          _processTurn(value);
        });
      } else {
        setState(() { _diceValue = _random.nextInt(6) + 1; });
        rollCount++;
      }
    });
  }

  void _processTurn(int value) {
    if (_isPlayerTurn) {
      _playerPos = (_playerPos + value).clamp(0, 30);
      if (_playerPos >= 30) {
        setState(() { _result = "🎉 YOU WIN! 🎉"; _playerPos = 0; _aiPos = 0; });
        return;
      }
      _isPlayerTurn = false;
      setState(() => _result = "Giliran AI...");
      Future.delayed(const Duration(seconds: 1), _aiTurn);
    }
  }

  void _aiTurn() {
    if (_isRolling) return;
    final value = _random.nextInt(6) + 1;
    _aiPos = (_aiPos + value).clamp(0, 30);
    if (_aiPos >= 30) {
      setState(() { _result = "💀 AI WINS!"; _playerPos = 0; _aiPos = 0; _isPlayerTurn = true; });
      return;
    }
    setState(() {
      _isPlayerTurn = true;
      _result = "Giliran kamu!";
    });
  }

  void _resetGame() {
    setState(() { _playerPos = 0; _aiPos = 0; _isPlayerTurn = true; _result = "Game direset!"; });
  }

  void _shareGame() {
    Share.share("🎲 LUDO KING 🎲\nPlayer: $_playerPos/30\nAI: $_aiPos/30\nStatus: $_result");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        title: const Text("Ludo King", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        backgroundColor: _C.purple,
        centerTitle: true,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.share, color: _C.gold), onPressed: _shareGame),
          IconButton(icon: const Icon(Icons.refresh, color: _C.gold), onPressed: _resetGame),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDigitalClock(),
              const SizedBox(height: 20),
              Text(_result, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildPlayerCard("Kamu", _playerPos, _C.purpleL),
                  _buildPlayerCard("AI", _aiPos, _C.red),
                ],
              ),
              const SizedBox(height: 20),
              AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, __) => Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.3), blurRadius: 20 + _pulseAnim.value * 10)],
                  ),
                  child: Center(child: Text("$_diceValue", style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: _C.purple))),
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: _isPlayerTurn ? _rollDice : null,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [_C.gold, _C.orange]),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: _C.gold.withOpacity(0.3), blurRadius: 20)],
                  ),
                  child: _isRolling
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                      : Text(_isPlayerTurn ? "GULIR" : "Tunggu...", style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Orbitron')),
                ),
              ),
              const SizedBox(height: 16),
              LinearProgressIndicator(
                value: _playerPos / 30,
                backgroundColor: _C.border,
                color: _C.purpleL,
                minHeight: 8,
                borderRadius: BorderRadius.circular(4),
              ),
              const SizedBox(height: 4),
              LinearProgressIndicator(
                value: _aiPos / 30,
                backgroundColor: _C.border,
                color: _C.red,
                minHeight: 8,
                borderRadius: BorderRadius.circular(4),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDigitalClock() => Container(
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
    decoration: BoxDecoration(
      color: _C.card.withOpacity(0.4),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _C.rainbow[DateTime.now().second % _C.rainbow.length].withOpacity(0.2), width: 1),
    ),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _clockItem('WIB', _timeWIB, _C.purpleL),
        _clockItem('WITA', _timeWITA, _C.pink),
        _clockItem('WIT', _timeWIT, _C.cyan),
      ],
    ),
  );

  Widget _clockItem(String label, String time, Color color) => Column(
    children: [
      Text(label, style: TextStyle(color: _C.textDim.withOpacity(0.5), fontSize: 8, fontWeight: FontWeight.w600, fontFamily: 'Orbitron')),
      Text(time, style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'Orbitron', shadows: [Shadow(color: color.withOpacity(0.3), blurRadius: 12)])),
    ],
  );

  Widget _buildPlayerCard(String label, int pos, Color color) => Container(
    width: 120,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: _C.card,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Column(
      children: [
        Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        const SizedBox(height: 8),
        Text("$pos/30", style: TextStyle(color: _C.text, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
      ],
    ),
  );
}