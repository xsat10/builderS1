import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:url_launcher/url_launcher.dart';

// ==================== COLORS ====================
const Color navyBlue = Color(0xFF1E3A8A);
const Color navyDeep = Color(0xFF0A1929);
const Color navyMedium = Color(0xFF1E2F4A);
const Color navyLight = Color(0xFF2A3F5F);
const Color icyBlue = Color(0xFF7FD1E0);
const Color icyBlueLight = Color(0xFFB0E0F0);
const Color goldAccent = Color(0xFFD4AF37);
const Color darkBg = navyDeep;

class BuyPage extends StatefulWidget {
  const BuyPage({super.key});

  @override
  State<BuyPage> createState() => _BuyPageState();
}

class _BuyPageState extends State<BuyPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late List<Animation<double>> _fadeAnimations;
  late List<Animation<double>> _scaleAnimations;
  late List<Animation<Offset>> _slideAnimations;

  final List<Map<String, dynamic>> priceList = const [
    {
      "title": "Member Account",
      "icon": Icons.person,
      "color": Color(0xFF7FD1E0),
      "tag": "BASIC ACCOUNT",
      "daily": "3K IDR / Perhari",
      "weekly": "15K IDR / Perminggu",
      "monthly": "20K IDR / Perbulan",
      "permanent": "40K IDR / Permanent",
      "featured": false,
      "benefits": [
        "Bisa Memakai Bug Menu",
        "Free Full Update Untuk ( Permanen )",
        "Masuk Gb Xeternalz Untuk ( Permanen )",
        "Dapat Mengakses Fitur/Tools",
      ],
    },
    {
      "title": "Role Reseller Account",
      "icon": Icons.people,
      "color": Color(0xFF4A9EFF),
      "tag": "BUSINESS",
      "permanent": "60K IDR / Permanent",
      "featured": false,
      "benefits": [
        "Bisa Menjual Account Member",
        "Dapat Akses Create Account Buyer",
        "Bisa Memakai All Feature & Bug",
        "Paling Rekomendasi Untuk Pemula",
        "Free Full Update Sampai Kpn Pun",
      ],
    },
    {
      "title": "Role Admin Account",
      "icon": Icons.admin_panel_settings,
      "color": Color(0xFFD4AF37),
      "tag": "RECOMMENDED & BEST SELLER",
      "permanent": "80K IDR / Permanent",
      "featured": true,
      "benefits": [
        "Dapat Mengakses Sender Global",
        "Bisa Menjual Role Ress & Member", 
        "Bisa Memakai All Freature & Bug",
        "Free Full Update Sampai Kpn Pun",
      ],
    },
    {
      "title": "Role Owner Account",
      "icon": Icons.star,
      "color": Color(0xFFFF6B6B),
      "tag": "VVIP & BUSSINESS ROLE",
      "permanent": "100K IDR / Permanent",
      "featured": false,
      "benefits": [
        "Bisa Menjual Role Admin Kebawah",
        "Masuk Group Khusus Owner",
        "Bisa Acc Trx Create Account",
        "Dapat Mengakses Sender Global",
        "Bisa Memakai All Feature & Bug",
        "Free Full Update Sampai Kpn Pun",
      ],
    },
    {
      "title": "Role Moderator Account",
      "icon": Icons.gavel,
      "color": Color(0xFF9CA3AF),
      "tag": "VVIP & THE BEST & BUSINESS ALL ROLE",
      "permanent": "130K IDR / Permanent",
      "featured": false,
      "benefits": [
        "Bisa Menjual Role Owner Kebawah",
        "Bisa Memakai Sender Global",
        "Dapat Mengakses Sender Global",
        "Masuk Group Khusus Di Telegram & Wa",
        "Bisa Acc Trx Create Account",
        "Dan Mengakses Semua Fitur",
      ],
    },
  ];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _fadeAnimations = List.generate(priceList.length, (index) {
      return Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeInOut,
          ),
        ),
      );
    });

    _scaleAnimations = List.generate(priceList.length, (index) {
      return Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeOutBack,
          ),
        ),
      );
    });

    _slideAnimations = List.generate(priceList.length, (index) {
      return Tween<Offset>(
        begin: const Offset(0, 0.3),
        end: Offset.zero,
      ).animate(
        CurvedAnimation(
          parent: _controller,
          curve: Interval(
            index * 0.12,
            0.3 + index * 0.12,
            curve: Curves.easeOutCubic,
          ),
        ),
      );
    });

    _controller.forward();
  }

  // ── BUKA LINKTREE ──
  Future<void> _openStore() async {
    final uri = Uri.parse("https://linktr.ee/xyzzcystore");

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(uri, mode: LaunchMode.platformDefault);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [darkBg, navyMedium],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        leading: Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: icyBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: icyBlue.withOpacity(0.3)),
              ),
              child: const Icon(
                Icons.shopping_cart,
                color: icyBlue,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              "PRICE LIST ACCOUNT & ROLE",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [darkBg, navyDeep],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: priceList.length,
          itemBuilder: (context, index) {
            return AnimatedBuilder(
              animation: _controller,
              child: _buildAccountCard(priceList[index], index),
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeAnimations[index].value,
                  child: Transform.scale(
                    scale: _scaleAnimations[index].value,
                    child: Transform.translate(
                      offset: _slideAnimations[index].value,
                      child: child,
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildAccountCard(Map<String, dynamic> item, int index) {
    final Color cardColor = item['color'] as Color;
    final bool isFeatured = item['featured'] as bool;
    final List<String> benefits = item['benefits'] as List<String>;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [navyMedium, navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: cardColor.withOpacity(isFeatured ? 0.6 : 0.3),
          width: isFeatured ? 2 : 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: cardColor.withOpacity(isFeatured ? 0.3 : 0.15),
            blurRadius: isFeatured ? 25 : 15,
            spreadRadius: isFeatured ? 4 : 2,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            // Background pattern
            Positioned(
              top: -20,
              right: -20,
              child: Icon(
                item['icon'] as IconData,
                color: Colors.white.withOpacity(0.04),
                size: 120,
              ),
            ),

            // Featured Badge
            if (isFeatured)
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [goldAccent, goldAccent.withOpacity(0.7)],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.star, color: Colors.white, size: 12),
                      SizedBox(width: 4),
                      Text(
                        'RECOMMENDED',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // Content
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: cardColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: cardColor.withOpacity(0.3),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          item['icon'] as IconData,
                          color: cardColor,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] as String,
                              style: TextStyle(
                                color: cardColor,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['tag'] as String,
                                style: TextStyle(
                                  color: cardColor.withOpacity(0.7),
                                  fontSize: 11,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ── BENEFITS (4 KOLOM) ──
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: navyDeep.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: cardColor.withOpacity(0.15),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.check_circle,
                              color: cardColor,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "BENEFITS & FEATURES",
                              style: TextStyle(
                                color: cardColor.withOpacity(0.8),
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // GRID 4 KOLOM
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 4,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                            childAspectRatio: 1.8,
                          ),
                          itemCount: benefits.length,
                          itemBuilder: (context, idx) {
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                              decoration: BoxDecoration(
                                color: cardColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: cardColor.withOpacity(0.15),
                                  width: 0.5,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  benefits[idx],
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Harga
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: navyDeep.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: cardColor.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        // Daily & Weekly (jika ada)
                        if (item.containsKey('daily') && item.containsKey('weekly'))
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.calendar_today,
                                            color: icyBlue,
                                            size: 14,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "DAILY",
                                            style: TextStyle(
                                              color: icyBlueLight.withOpacity(0.7),
                                              fontSize: 11,
                                              fontFamily: 'ShareTechMono',
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        item['daily'] as String,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: 1,
                                  height: 40,
                                  color: Colors.white.withOpacity(0.1),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.calendar_view_week,
                                            color: icyBlue,
                                            size: 14,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "WEEKLY",
                                            style: TextStyle(
                                              color: icyBlueLight.withOpacity(0.7),
                                              fontSize: 11,
                                              fontFamily: 'ShareTechMono',
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        item['weekly'] as String,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Orbitron',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),

                        // Monthly & Permanent
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.calendar_month,
                                        color: icyBlue,
                                        size: 14,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "MONTHLY",
                                        style: TextStyle(
                                          color: icyBlueLight.withOpacity(0.7),
                                          fontSize: 11,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item.containsKey('monthly') 
                                      ? item['monthly'] as String 
                                      : "Not available",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              width: 1,
                              height: 40,
                              color: Colors.white.withOpacity(0.1),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.all_inclusive,
                                        color: cardColor,
                                        size: 14,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "PERMANENT",
                                        style: TextStyle(
                                          color: cardColor.withOpacity(0.7),
                                          fontSize: 11,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['permanent'] as String,
                                    style: TextStyle(
                                      color: cardColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Orbitron',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── TOMBOL KE LINKTREE ──
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _openStore,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: cardColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.storefront,
                            color: Colors.white,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            "Buy Now Via Store",
                            style: const TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Info tambahan
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.security_rounded,
                          color: Colors.white54,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          '100% Trusted & Verified',
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          width: 3,
                          height: 3,
                          decoration: const BoxDecoration(
                            color: Colors.white54,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Icon(
                          Icons.verified_rounded,
                          color: Colors.green,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'Instant Delivery',
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}