/// lib/anime_home.dart
// FULL ANIME MODULE + TAP LOGO OVERLAY
// BE4X EXES 2026

import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import 'widgets/tap_logo_overlay.dart';   // ✅ TAMBAH INI

// ═══════════════════════════════════════════════════════════════
// 🌐 KONFIGURASI API
// ═══════════════════════════════════════════════════════════════
const String _ANIME_BASE = 'https://api.jikan.moe/v4';

// ═══════════════════════════════════════════════════════════════
// 🎨 PALETTE
// ═══════════════════════════════════════════════════════════════
class _Pal {
  _Pal._();
  static const bg = Color(0xFF070B14);
  static const surface = Color(0xFF101726);
  static const card = Color(0xFF182238);
  static const blue = Color(0xFF3B82F6);
  static const cyan = Color(0xFF06B6D4);
  static const emerald = Color(0xFF00E5A0);
  static const gold = Color(0xFFFFD93D);
  static const rose = Color(0xFFFF6B6B);
  static const text = Color(0xFFE2E8F0);
  static const textSub = Color(0xFFCBD8E8);
  static const textDim = Color(0xFF64748B);
}

const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ═══════════════════════════════════════════════════════════════
// 📦 MODEL
// ═══════════════════════════════════════════════════════════════
class AnimeItem {
  final int id;
  final String title;
  final String image;
  final String? synopsis;
  final double? score;
  final String? type;
  final String? status;
  final int? episodes;
  final String? rating;

  AnimeItem({
    required this.id,
    required this.title,
    required this.image,
    this.synopsis,
    this.score,
    this.type,
    this.status,
    this.episodes,
    this.rating,
  });

  factory AnimeItem.fromJson(Map<String, dynamic> j) {
    final images = j['images']?['jpg'] ?? j['images']?['webp'] ?? {};
    return AnimeItem(
      id: j['mal_id'] ?? 0,
      title: j['title'] ?? j['title_english'] ?? 'Unknown',
      image: images['image_url'] ?? images['large_image_url'] ?? '',
      synopsis: j['synopsis'],
      score: (j['score'] as num?)?.toDouble(),
      type: j['type'],
      status: j['status'],
      episodes: j['episodes'],
      rating: j['rating'],
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// 🏠 HOME ANIME PAGE
// ═══════════════════════════════════════════════════════════════
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  late AnimationController _bgCtrl;

  List<AnimeItem> _animeList = [];
  bool _loading = true;
  String? _error;
  int _tabIndex = 0;

  final List<String> _tabs = ['TOP', 'AIRING', 'UPCOMING', 'MOVIE'];

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    _loadAnime();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  String get _endpoint {
    switch (_tabIndex) {
      case 0: return '/top/anime?limit=24';
      case 1: return '/seasons/now?limit=24';
      case 2: return '/seasons/upcoming?limit=24';
      case 3: return '/top/anime?type=movie&limit=24';
      default: return '/top/anime?limit=24';
    }
  }

  Future<void> _loadAnime() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await http
          .get(Uri.parse('$_ANIME_BASE$_endpoint'))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['data'] as List)
            .map((e) => AnimeItem.fromJson(e))
            .toList();
        if (mounted) setState(() => _animeList = list);
      } else {
        if (mounted) setState(() => _error = 'Server error: ${res.statusCode}');
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'Koneksi bermasalah');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _searchAnime(String q) async {
    if (q.trim().isEmpty) {
      _loadAnime();
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await http
          .get(Uri.parse(
              '$_ANIME_BASE/anime?q=${Uri.encodeComponent(q)}&limit=24'))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['data'] as List)
            .map((e) => AnimeItem.fromJson(e))
            .toList();
        if (mounted) setState(() => _animeList = list);
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'Gagal search');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _onTabChange(int i) {
    setState(() {
      _tabIndex = i;
      _searchCtrl.clear();
    });
    _loadAnime();
  }

  void _openDetail(AnimeItem item) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AnimeDetailPage(anime: item)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TapLogoOverlay(
      logoAsset: 'assets/images/logo.png',   // ⚠️ SESUAIKAN nama file logo lu
      child: Scaffold(
        backgroundColor: _Pal.bg,
        body: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF070B14),
                      Color(0xFF0F1729),
                      Color(0xFF070B14),
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _bgCtrl,
                builder: (_, __) => CustomPaint(
                  painter: _BgPainter(_bgCtrl.value),
                ),
              ),
            ),
            SafeArea(
              child: Column(
                children: [
                  _buildAppBar(),
                  _buildSearchBar(),
                  _buildTabs(),
                  Expanded(child: _buildBody()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white.withOpacity(0.15)),
              ),
              child: const Icon(Icons.arrow_back_ios_new,
                  color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ANIME HUB',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: _ts,
                    )),
                SizedBox(height: 2),
                Text('Stream & Watch',
                    style: TextStyle(
                      color: _Pal.cyan,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1,
                      shadows: _ts,
                    )),
              ],
            ),
          ),
          GestureDetector(
            onTap: _loadAnime,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _Pal.blue.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _Pal.blue.withOpacity(0.4)),
              ),
              child: const Icon(Icons.refresh_rounded,
                  color: _Pal.blue, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Row(
          children: [
            const SizedBox(width: 14),
            const Icon(Icons.search, color: _Pal.textSub, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchCtrl,
                onSubmitted: _searchAnime,
                textInputAction: TextInputAction.search,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                cursorColor: _Pal.cyan,
                decoration: InputDecoration(
                  hintText: 'Cari anime...',
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 13,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.only(bottom: 12),
                ),
              ),
            ),
            if (_searchCtrl.text.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.close, color: _Pal.textSub, size: 18),
                onPressed: () {
                  _searchCtrl.clear();
                  _loadAnime();
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final active = _tabIndex == i;
          return GestureDetector(
            onTap: () => _onTabChange(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                gradient: active
                    ? const LinearGradient(colors: [_Pal.blue, _Pal.cyan])
                    : null,
                color: active ? null : Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: active
                      ? Colors.transparent
                      : Colors.white.withOpacity(0.15),
                ),
                boxShadow: active
                    ? [
                        BoxShadow(
                            color: _Pal.blue.withOpacity(0.5),
                            blurRadius: 14,
                            offset: const Offset(0, 4))
                      ]
                    : null,
              ),
              child: Text(
                _tabs[i],
                style: TextStyle(
                  color: active ? Colors.white : _Pal.textSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                  shadows: _ts,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: _Pal.cyan, strokeWidth: 2),
      );
    }
    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded,
                color: _Pal.textDim, size: 48),
            const SizedBox(height: 12),
            Text(_error!,
                style: const TextStyle(
                    color: _Pal.textSub, fontSize: 13, shadows: _ts)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadAnime,
              style: ElevatedButton.styleFrom(
                backgroundColor: _Pal.blue,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('COBA LAGI',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      shadows: _ts)),
            ),
          ],
        ),
      );
    }
    if (_animeList.isEmpty) {
      return const Center(
        child: Text('Anime tidak ditemukan',
            style: TextStyle(
                color: _Pal.textSub, fontSize: 13, shadows: _ts)),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      physics: const BouncingScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.62,
      ),
      itemCount: _animeList.length,
      itemBuilder: (ctx, i) => _AnimeCard(
        anime: _animeList[i],
        onTap: () => _openDetail(_animeList[i]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// 🎴 ANIME CARD
// ═══════════════════════════════════════════════════════════════
class _AnimeCard extends StatelessWidget {
  final AnimeItem anime;
  final VoidCallback onTap;

  const _AnimeCard({required this.anime, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.network(
                anime.image,
                fit: BoxFit.cover,
                loadingBuilder: (_, child, prog) => prog == null
                    ? child
                    : Container(color: _Pal.card),
                errorBuilder: (_, __, ___) => Container(
                  color: _Pal.card,
                  child: const Icon(Icons.broken_image,
                      color: _Pal.textDim, size: 30),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(8, 20, 8, 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.9),
                      ],
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        anime.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          height: 1.2,
                          shadows: _ts,
                        ),
                      ),
                      if (anime.score != null) ...[
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            const Icon(Icons.star_rounded,
                                color: _Pal.gold, size: 10),
                            const SizedBox(width: 2),
                            Text(anime.score!.toStringAsFixed(1),
                                style: const TextStyle(
                                  color: _Pal.gold,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  shadows: _ts,
                                )),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              if (anime.type != null)
                Positioned(
                  top: 6,
                  left: 6,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _Pal.blue.withOpacity(0.85),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(anime.type!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 7,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          shadows: _ts,
                        )),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// 📄 ANIME DETAIL PAGE
// ═══════════════════════════════════════════════════════════════
class AnimeDetailPage extends StatelessWidget {
  final AnimeItem anime;
  const AnimeDetailPage({super.key, required this.anime});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Pal.bg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: 340,
            pinned: true,
            backgroundColor: _Pal.bg,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.arrow_back_ios_new,
                    color: Colors.white, size: 16),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(anime.image, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          Container(color: _Pal.card)),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          _Pal.bg.withOpacity(0.9),
                          _Pal.bg,
                        ],
                        stops: const [0.3, 0.8, 1.0],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(anime.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        height: 1.2,
                        shadows: _ts,
                      )),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      if (anime.type != null)
                        _buildChip(Icons.movie_outlined, anime.type!,
                            _Pal.blue),
                      if (anime.episodes != null)
                        _buildChip(Icons.list_alt, '${anime.episodes} eps',
                            _Pal.cyan),
                      if (anime.score != null)
                        _buildChip(Icons.star_rounded,
                            anime.score!.toStringAsFixed(1), _Pal.gold),
                      if (anime.status != null)
                        _buildChip(Icons.info_outline, anime.status!,
                            _Pal.emerald),
                      if (anime.rating != null)
                        _buildChip(Icons.verified_user, anime.rating!,
                            _Pal.rose),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text('SINOPSIS',
                      style: TextStyle(
                        color: _Pal.cyan,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        shadows: _ts,
                      )),
                  const SizedBox(height: 8),
                  Text(
                    anime.synopsis ?? 'Sinopsis belum tersedia.',
                    style: const TextStyle(
                      color: _Pal.textSub,
                      fontSize: 13,
                      height: 1.6,
                      shadows: _ts,
                    ),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AnimePlayerPage(anime: anime),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _Pal.blue,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 24),
                          SizedBox(width: 8),
                          Text('TONTON SEKARANG',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                                shadows: _ts,
                              )),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 5),
          Text(label,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                shadows: _ts,
              )),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// ▶️ ANIME PLAYER PAGE
// ═══════════════════════════════════════════════════════════════
class AnimePlayerPage extends StatefulWidget {
  final AnimeItem anime;
  const AnimePlayerPage({super.key, required this.anime});

  @override
  State<AnimePlayerPage> createState() => _AnimePlayerPageState();
}

class _AnimePlayerPageState extends State<AnimePlayerPage> {
  VideoPlayerController? _ctrl;
  bool _initialized = false;
  bool _loading = true;
  String? _error;

  static const String _sampleVideo =
      'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse(_sampleVideo));
      await c.initialize();
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() {
        _ctrl = c;
        _initialized = true;
        _loading = false;
      });
      c.setLooping(false);
      c.play();
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Gagal memuat video';
        });
      }
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new,
              color: Colors.white, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(widget.anime.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w800,
              shadows: _ts,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis),
      ),
      body: Center(
        child: _loading
            ? const CircularProgressIndicator(color: _Pal.cyan)
            : _error != null
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline,
                          color: _Pal.textDim, size: 48),
                      const SizedBox(height: 12),
                      Text(_error!,
                          style: const TextStyle(
                              color: _Pal.textSub, shadows: _ts)),
                    ],
                  )
                : _initialized && _ctrl != null
                    ? AspectRatio(
                        aspectRatio: _ctrl!.value.aspectRatio,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            VideoPlayer(_ctrl!),
                            VideoProgressIndicator(_ctrl!,
                                allowScrubbing: true,
                                colors: const VideoProgressColors(
                                  playedColor: _Pal.cyan,
                                  bufferedColor: Colors.white24,
                                  backgroundColor: Colors.white10,
                                )),
                            GestureDetector(
                              onTap: () {
                                setState(() {
                                  _ctrl!.value.isPlaying
                                      ? _ctrl!.pause()
                                      : _ctrl!.play();
                                });
                              },
                              child: AnimatedOpacity(
                                opacity: _ctrl!.value.isPlaying ? 0.0 : 1.0,
                                duration: const Duration(milliseconds: 200),
                                child: Container(
                                  width: 64,
                                  height: 64,
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.5),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Colors.white
                                            .withOpacity(0.5),
                                        width: 2),
                                  ),
                                  child: const Icon(
                                      Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 36),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : const SizedBox.shrink(),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// 🎨 BG PAINTER
// ═══════════════════════════════════════════════════════════════
class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = const Color(0x08FFFFFF)
      ..strokeWidth = 0.3;
    const step = 48.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}