import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../services/sound_service.dart';

/// Block Blast — game susun kotak viral, clone lengkap dengan drag & drop,
/// pembersihan baris/kolom otomatis, skor, dan deteksi game over.
class BlockBlastGame extends StatefulWidget {
  const BlockBlastGame({super.key});

  @override
  State<BlockBlastGame> createState() => _BlockBlastGameState();
}

const int _boardSize = 8;

/// Padding grid (GridView) dan margin sel — dipakai agar pemetaan drop
/// tepat sama dengan tampilan sel, sehingga balok tidak "mengambang" /
/// mendarat bergeser dari posisi preview.
const double _gridPad = 4.0;
const double _cellMargin = 1.5;

class _Piece {
  final List<List<int>> shape;
  final Color color;
  final String id;
  _Piece(this.shape, this.color) : id = UniqueKey().toString();
}

final List<List<List<int>>> _shapePool = [
  [[1]],
  [[1, 1]],
  [[1], [1]],
  [[1, 1, 1]],
  [[1], [1], [1]],
  [[1, 1, 1, 1]],
  [[1], [1], [1], [1]],
  [[1, 1], [1, 1]],
  [[1, 0], [1, 1]],
  [[0, 1], [1, 1]],
  [[1, 1], [1, 0]],
  [[1, 1], [0, 1]],
  [[1, 0], [1, 0], [1, 1]],
  [[0, 1], [0, 1], [1, 1]],
  [[1, 1], [1, 0], [1, 0]],
  [[1, 1], [0, 1], [0, 1]],
  [[1, 1, 1], [0, 1, 0]],
  [[0, 1, 1], [1, 1, 0]],
  [[1, 1, 0], [0, 1, 1]],
  [[0, 1, 0], [1, 1, 1], [0, 1, 0]],
  [[1, 1, 1], [1, 1, 1]],
];

final List<Color> _colorPool = [
  const Color(0xFFFFD98A),
  const Color(0xFFFF5C8A),
  const Color(0xFF5B8CFF),
  const Color(0xFF55E878),
  const Color(0xFFFF9F43),
  const Color(0xFF9B6BFF),
];

class _BlockBlastGameState extends State<BlockBlastGame> {
  late List<List<Color?>> _board;
  late List<_Piece?> _tray;
  int _score = 0;
  int _best = 0;
  bool _gameOver = false;

  final GlobalKey _boardKey = GlobalKey();
  double _cellSize = 0;

  // Piece yang sedang ditarik + posisi jari (untuk preview yang SNAP ke grid,
  // bukan "mengambang"). Direset saat drop selesai / keluar board.
  _Piece? _dragPiece;
  Offset? _dragOffset;

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    setState(() {
      _board = List.generate(_boardSize, (_) => List.filled(_boardSize, null));
      _tray = List.generate(3, (_) => _randomPiece());
      _score = 0;
      _gameOver = false;
      _dragPiece = null;
      _dragOffset = null;
    });
  }

  _Piece _randomPiece() {
    final rng = Random();
    final shape = _shapePool[rng.nextInt(_shapePool.length)];
    final color = _colorPool[rng.nextInt(_colorPool.length)];
    return _Piece(shape, color);
  }

  bool _canPlacePiece(_Piece piece, int startRow, int startCol) {
    final rows = piece.shape.length;
    final cols = piece.shape[0].length;

    if (startRow < 0 || startCol < 0 || startRow + rows > _boardSize || startCol + cols > _boardSize) {
      return false;
    }
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        if (piece.shape[r][c] == 1) {
          if (_board[startRow + r][startCol + c] != null) {
            return false;
          }
        }
      }
    }
    return true;
  }

  bool _canPlaceAnywhere(_Piece piece) {
    final rows = piece.shape.length;
    final cols = piece.shape[0].length;

    for (int r = 0; r <= _boardSize - rows; r++) {
      for (int c = 0; c <= _boardSize - cols; c++) {
        if (_canPlacePiece(piece, r, c)) {
          return true;
        }
      }
    }
    return false;
  }

  void _checkGameOver() {
    for (final p in _tray) {
      if (p != null && _canPlaceAnywhere(p)) {
        return;
      }
    }
    setState(() => _gameOver = true);
  }

  /// Hitung target sel (top-left) dari posisi drop global. Mengembalikan null
  /// jika piece tidak muat/kollisi. Sel top-left piece "menempel" ke sel yang
  /// ditunjuk jari (dengan snap kecil ±1) sehingga tidak pernah mengambang /
  /// bergeser setengah sel.
  ({int row, int col})? _computePlacement(_Piece piece, Offset dropOffset) {
    if (_cellSize <= 0) return null;
    final RenderBox? box =
        _boardKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return null;

    final localPos = box.globalToLocal(dropOffset);
    // Origin grid = padding GridView (_gridPad). Konsisten dengan tampilan sel.
    final gx = localPos.dx - _gridPad;
    final gy = localPos.dy - _gridPad;

    final baseCol = (gx / _cellSize).floor();
    final baseRow = (gy / _cellSize).floor();

    // Snap ke grid: prioritaskan sel tepat di bawah jari, lalu offset kecil
    // ±1 jika sel tersebut penuh / di luar batas.
    for (int dr = 0; dr >= -1; dr--) {
      for (int dc = 0; dc >= -1; dc--) {
        if (_canPlacePiece(piece, baseRow + dr, baseCol + dc)) {
          return (row: baseRow + dr, col: baseCol + dc);
        }
      }
    }
    for (int dr = 0; dr <= 1; dr++) {
      for (int dc = 0; dc <= 1; dc++) {
        if (_canPlacePiece(piece, baseRow + dr, baseCol + dc)) {
          return (row: baseRow + dr, col: baseCol + dc);
        }
      }
    }
    return null;
  }

  /// True jika sel (r,c) berada dalam area yang akan ditempati piece ketika
  /// diletakkan di (placeRow, placeCol). Dipakai untuk preview snap-to-grid.
  bool _isInPiece(_Piece piece, int placeRow, int placeCol, int r, int c) {
    if (r < placeRow || r >= placeRow + piece.shape.length) return false;
    if (c < placeCol || c >= placeCol + piece.shape[0].length) return false;
    return piece.shape[r - placeRow][c - placeCol] == 1;
  }

  void _handleDrop(_Piece piece, Offset dropOffset) {
    final target = _computePlacement(piece, dropOffset);
    if (target == null) {
      SoundService.playBlockImpossible();
      return;
    }

    SoundService.playBlockTap();
    setState(() {
      final targetRow = target.row;
      final targetCol = target.col;
      int placedCount = 0;
      for (int r = 0; r < piece.shape.length; r++) {
        for (int c = 0; c < piece.shape[0].length; c++) {
          if (piece.shape[r][c] == 1) {
            _board[targetRow + r][targetCol + c] = piece.color;
            placedCount++;
          }
        }
      }

      _score += placedCount * 10;
      final idx = _tray.indexWhere((element) => element?.id == piece.id);
      if (idx != -1) {
        _tray[idx] = null;
      }

      _clearCompletedLines();

      if (_tray.every((element) => element == null)) {
        _tray = List.generate(3, (_) => _randomPiece());
      }

      _checkGameOver();
    });
  }

  void _clearCompletedLines() {
    final rowsToClear = <int>[];
    final colsToClear = <int>[];

    for (int r = 0; r < _boardSize; r++) {
      if (_board[r].every((cell) => cell != null)) {
        rowsToClear.add(r);
      }
    }

    for (int c = 0; c < _boardSize; c++) {
      bool full = true;
      for (int r = 0; r < _boardSize; r++) {
        if (_board[r][c] == null) {
          full = false;
          break;
        }
      }
      if (full) colsToClear.add(c);
    }

    final totalLines = rowsToClear.length + colsToClear.length;
    if (totalLines > 0) {
      for (final r in rowsToClear) {
        for (int c = 0; c < _boardSize; c++) {
          _board[r][c] = null;
        }
      }
      for (final c in colsToClear) {
        for (int r = 0; r < _boardSize; r++) {
          _board[r][c] = null;
        }
      }

      final bonusMultiplier = totalLines > 1 ? totalLines : 1;
      _score += totalLines * 100 * bonusMultiplier;
    }
    if (_score > _best) {
      _best = _score;
    }
  }

  Widget _shapePreview(List<List<int>> shape, Color color, double tileSize) {
    final rows = shape.length;
    final cols = shape[0].length;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        rows,
        (r) => Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(
            cols,
            (c) => Container(
              width: tileSize,
              height: tileSize,
              margin: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                color: shape[r][c] == 1 ? color : Colors.transparent,
                borderRadius: BorderRadius.circular(3),
                boxShadow: shape[r][c] == 1
                    ? [
                        BoxShadow(
                          color: color.withValues(alpha: 0.5),
                          blurRadius: 4,
                        )
                      ]
                    : null,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTrayItem(_Piece? piece) {
    if (piece == null) {
      return const SizedBox(width: 70, height: 70);
    }
    final preview = _shapePreview(piece.shape, piece.color, 16);
    return SizedBox(
      width: 70,
      height: 70,
      child: Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Draggable<_Piece>(
            data: piece,
            onDragStarted: () => SoundService.playBlockTap(),
            // Feedback DIHAPUS: tidak ada balok "mengambang" mengikuti jari.
            // Preview yang tampil adalah preview yang snap ke grid di papan
            // (lihat _PreviewCell), sehingga selalu menempel pada sel.
            feedback: const SizedBox.shrink(),
            dragAnchorStrategy: pointerDragAnchorStrategy,
            childWhenDragging: Opacity(opacity: 0.25, child: preview),
            child: preview,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: NeoColors.primaryText,
        title: Row(
          children: [
            Icon(Icons.extension_rounded, color: NeoColors.purple, size: 20),
            SizedBox(width: 8),
            Text(
              'BLOCK BLAST ARENA',
              style: TextStyle(
                color: NeoColors.primaryText,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: NeoColors.gold),
            onPressed: _newGame,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _scoreCard('SKOR', _score),
                _scoreCard('TERBAIK', _best),
              ],
            ),
            const SizedBox(height: 16),

            // Papan permainan
            Expanded(
              child: Center(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final boardDim = min(
                      constraints.maxWidth - 24,
                      constraints.maxHeight - 24,
                    );
                    _cellSize = (boardDim - _gridPad * 2) / _boardSize;

                    return DragTarget<_Piece>(
                      onWillAcceptWithDetails: (_) => true,
                      onMove: (details) {
                        final p = details.data;
                        if (p.id != _dragPiece?.id ||
                            details.offset != _dragOffset) {
                          setState(() {
                            _dragPiece = p;
                            _dragOffset = details.offset;
                          });
                        }
                      },
                      onLeave: (_) {
                        setState(() {
                          _dragPiece = null;
                          _dragOffset = null;
                        });
                      },
                      onAcceptWithDetails: (details) {
                        _handleDrop(details.data, details.offset);
                        setState(() {
                          _dragPiece = null;
                          _dragOffset = null;
                        });
                      },
                      builder: (ctx, candidate, rejected) {
                        // Hitung target sel yang "menempel" ke grid untuk
                        // preview (piece tidak pernah ngambang).
                        final dropPiece = _dragPiece;
                        final dropOffset = _dragOffset;
                        final placement = dropPiece != null && dropOffset != null
                            ? _computePlacement(dropPiece, dropOffset)
                            : null;
                        return Container(
                          key: _boardKey,
                          width: boardDim,
                          height: boardDim,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.04),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: const Color(0x44FFD98A),
                              width: 1.5,
                            ),
                          ),
                          child: GridView.builder(
                            physics: const NeverScrollableScrollPhysics(),
                            padding: const EdgeInsets.all(_gridPad),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: _boardSize,
                            ),
                            itemCount: _boardSize * _boardSize,
                            itemBuilder: (ctx, index) {
                              final r = index ~/ _boardSize;
                              final c = index % _boardSize;
                              // Preview snap-to-grid: warnai sel yang akan
                              // ditempati piece yang sedang ditarik.
                              final previewColor =
                                  placement != null && dropPiece != null
                                      ? (_isInPiece(
                                          dropPiece,
                                          placement.row,
                                          placement.col,
                                          r,
                                          c,
                                        )
                                          ? dropPiece.color
                                              .withValues(alpha: 0.55)
                                          : null)
                                      : null;
                              final color =
                                  previewColor ?? _board[r][c];
                              return Container(
                                margin: const EdgeInsets.all(_cellMargin),
                                decoration: BoxDecoration(
                                  color: color ??
                                      Colors.white.withValues(alpha: 0.04),
                                  borderRadius: BorderRadius.circular(4),
                                  boxShadow: color != null
                                      ? [
                                          BoxShadow(
                                            color: color.withValues(alpha: 0.45),
                                            blurRadius: 6,
                                          )
                                        ]
                                      : null,
                                  border: previewColor != null
                                      ? Border.all(
                                          color:
                                              previewColor.withValues(alpha: 1),
                                          width: 1.5,
                                        )
                                      : null,
                                ),
                              );
                            },
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Tray 3 balok
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.04),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0x44FFD98A), width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: _tray.map(_buildTrayItem).toList(),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
      bottomSheet: _gameOver
          ? Container(
              width: double.infinity,
              color: const Color(0xF0141628),
              padding: const EdgeInsets.fromLTRB(28, 28, 28, 16),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'GAME OVER',
                      style: TextStyle(
                        color: NeoColors.pink,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Skor Akhir: $_score',
                      style: TextStyle(color: NeoColors.primaryText, fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 16),
                    NeoButton(
                      label: 'MAIN LAGI',
                      bgColor: NeoColors.gold,
                      textColor: const Color(0xFF1A1100),
                      onPressed: _newGame,
                    ),
                  ],
                ),
              ),
            )
          : null,
    );
  }

  Widget _scoreCard(String label, int value) {
    return Container(
      width: 130,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0x44FFD98A), width: 1),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              color: NeoColors.secondaryText,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '$value',
            style: TextStyle(
              color: NeoColors.gold,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

