import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../services/sound_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CATUR ARENA — Roman Liquid Glass Theme
// Mode: VS AI (Magnus-level engine) & 2 PLAYER (hotseat)
// Engine: iterative deepening + alpha-beta + quiescence + transposition table
//        + MVV-LVA ordering + killer moves + history heuristic + PST
//        + mobility + king safety + passed pawns + center control.
// Promosi pion: dialog pilihan (Queen / Rook / Bishop / Knight).
// Semua langkah dipastikan legal (king tidak pernah dibiarkan dalam skak).
// ─────────────────────────────────────────────────────────────────────────────

enum CaturMode { ai, twoPlayer }

class CaturPage extends StatefulWidget {
  const CaturPage({super.key});
  @override
  State<CaturPage> createState() => _CaturPageState();
}

class _CaturPageState extends State<CaturPage> {
  late List<List<String>> board;
  List<int>? selected;
  List<List<int>> validMoves = [];
  bool whiteTurn = true;
  String statusMsg = 'Giliran Kamu (Putih)';
  bool gameOver = false;
  bool aiThinking = false;
  CaturMode mode = CaturMode.ai;
  int whiteCaptures = 0;
  int blackCaptures = 0;

  // ── engine settings
  static const int _maxDepth = 6;
  static const int _nodeBudget = 500000;
  static const int _timeBudgetMs = 2000;
  int _nodesSearched = 0;
  final Stopwatch _searchWatch = Stopwatch();
  bool _aborted = false;

  // ── time control (int milliseconds for precision)
  int _timeControl = 0;
  int whiteRemainingMs = 0;
  int blackRemainingMs = 0;
  Timer? _clock;

  int _aiGeneration = 0;
  bool playerIsWhite = true;

  // ── promotion state
  bool _awaitingPromotion = false;
  int? _promoFromR, _promoFromC, _promoToR, _promoToC;
  bool _promoIsWhite = true;

  // ── castling rights
  bool _whiteKingMoved = false;
  bool _blackKingMoved = false;
  bool _whiteRookAMoved = false; // a-file rook (col 0)
  bool _whiteRookHMoved = false; // h-file rook (col 7)
  bool _blackRookAMoved = false;
  bool _blackRookHMoved = false;

  // ── en passant target (row, col) or null
  int? _epTargetR, _epTargetC;

  // ── transposition table
  final Map<int, _TTEntry> _tt = {};

  // ── killer moves: [depth][slot]
  final List<List<Move>> _killers = List.generate(64, (_) => [Move(-1,-1,-1,-1), Move(-1,-1,-1,-1)]);

  // ── history heuristic [from][to]
  final List<List<int>> _history = List.generate(64, (_) => List.filled(64, 0));

  // ── riwayat posisi (hash Zobrist) utk deteksi pengulangan / anti "bolak balik"
  final List<int> _positionHistory = [];
  final List<int> _repIndex = [];

  // ── Zobrist keys
  late List<List<List<int>>> _zobristPieces;
  int _zobristSide = 0;

  static int _rand32() => Random().nextInt(0x7FFFFFFF);

  @override
  void initState() {
    super.initState();
    _initZobrist();
    _initBoard();
  }

  void _initZobrist() {
    _zobristPieces = List.generate(12, (_) =>
        List.generate(8, (_) => List.generate(8, (_) => _rand32())));
    _zobristSide = _rand32();
  }

  int _zobristIndex(String p) {
    switch (p) {
      case 'P': return 0; case 'N': return 1; case 'B': return 2;
      case 'R': return 3; case 'Q': return 4; case 'K': return 5;
      case 'p': return 6; case 'n': return 7; case 'b': return 8;
      case 'r': return 9; case 'q': return 10; case 'k': return 11;
    }
    return -1;
  }

  int _computeHash(List<List<String>> b, bool isWhite) {
    int hash = 0;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final p = b[r][c];
        if (p.isNotEmpty) {
          final idx = _zobristIndex(p);
          if (idx >= 0) hash ^= _zobristPieces[idx][r][c];
        }
      }
    }
    if (!isWhite) hash ^= _zobristSide;
    return hash;
  }

  @override
  void dispose() {
    _clock?.cancel();
    super.dispose();
  }

  int _slotsFor(int min) => min <= 0 ? 0 : min * 60 * 1000;

  void _restartClock() {
    _clock?.cancel();
    if (_timeControl <= 0) return;
    whiteRemainingMs = _slotsFor(_timeControl);
    blackRemainingMs = _slotsFor(_timeControl);
    _clock = Timer.periodic(const Duration(milliseconds: 100), (_) => _tick());
  }

  void _tick() {
    if (!mounted) return;
    if (gameOver) return;
    setState(() {
      if (whiteTurn) {
        if (whiteRemainingMs > 0) whiteRemainingMs = (whiteRemainingMs - 100).clamp(0, 999999999);
      } else {
        if (blackRemainingMs > 0) blackRemainingMs = (blackRemainingMs - 100).clamp(0, 999999999);
      }
    });
    if (whiteTurn && whiteRemainingMs <= 0) {
      _timeout(false);
    } else if (!whiteTurn && blackRemainingMs <= 0) {
      _timeout(true);
    }
  }

  void _timeout(bool whiteWinner) {
    _clock?.cancel();
    setState(() {
      gameOver = true;
      aiThinking = false;
      if (mode == CaturMode.twoPlayer) {
        statusMsg = whiteWinner
            ? '🏆 Putih Menang! (Waktu Hitam Habis)'
            : '🏆 Hitam Menang! (Waktu Putih Habis)';
      } else {
        final playerWon = whiteWinner == playerIsWhite;
        statusMsg = playerWon
            ? '🏆 Kamu Menang! (Waktu AI Habis)'
            : '⏱️ Waktu Habis! AI Menang.';
      }
    });
  }

  void _initBoard() {
    setState(() {
      board = [
        ['r','n','b','q','k','b','n','r'],
        ['p','p','p','p','p','p','p','p'],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['','','','','','','',''],
        ['P','P','P','P','P','P','P','P'],
        ['R','N','B','Q','K','B','N','R'],
      ];
      selected = null;
      validMoves = [];
      whiteTurn = true;
      gameOver = false;
      aiThinking = false;
      whiteCaptures = 0;
      blackCaptures = 0;
      _awaitingPromotion = false;
      _whiteKingMoved = false;
      _blackKingMoved = false;
      _whiteRookAMoved = false;
      _whiteRookHMoved = false;
      _blackRookAMoved = false;
      _blackRookHMoved = false;
      _epTargetR = null;
      _epTargetC = null;
      _tt.clear();
      for (final row in _history) { row.fillRange(0, row.length, 0); }
      _positionHistory.clear();
      _repIndex.clear();
      _aiGeneration++;
      if (mode == CaturMode.ai) { playerIsWhite = Random().nextBool(); }
      statusMsg = mode == CaturMode.ai
          ? (playerIsWhite
              ? 'Giliran Kamu (Putih) 🐺 • VS AI'
              : 'Giliran AI (Putih) • Kamu (Hitam) 🐺')
          : 'Giliran Putih • 2 Player';
    });
    _restartClock();
    if (mode == CaturMode.ai && !playerIsWhite) {
      _scheduleAi();
    }
  }

  void _setTimeControl(int minutes) {
    if (minutes == _timeControl) return;
    _timeControl = minutes;
    _initBoard();
  }

  void _setMode(CaturMode m) {
    if (m == mode) return;
    mode = m;
    _initBoard();
  }

  bool _isWhite(String p) => p.isNotEmpty && p == p.toUpperCase() && p != p.toLowerCase();
  bool _isBlack(String p) => p.isNotEmpty && p == p.toLowerCase();
  bool _isEmpty(String p) => p.isEmpty;
  bool _inBounds(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;

  // ── pseudo-legal moves (belum filter skak)
  List<List<int>> _pseudoMoves(List<List<String>> b, int r, int c) {
    final piece = b[r][c];
    if (piece.isEmpty) return [];
    final moves = <List<int>>[];
    final up = piece == piece.toUpperCase();
    final dir = up ? -1 : 1;
    final enemy = up ? _isBlack : _isWhite;
    final ally = up ? _isWhite : _isBlack;

    void addIfValid(int nr, int nc) {
      if (_inBounds(nr, nc) && !ally(b[nr][nc])) moves.add([nr, nc]);
    }

    void slide(List<List<int>> dirs) {
      for (final d in dirs) {
        int nr = r + d[0], nc = c + d[1];
        while (_inBounds(nr, nc)) {
          if (ally(b[nr][nc])) break;
          moves.add([nr, nc]);
          if (enemy(b[nr][nc])) break;
          nr += d[0]; nc += d[1];
        }
      }
    }

    switch (piece.toUpperCase()) {
      case 'P':
        if (_inBounds(r + dir, c) && _isEmpty(b[r + dir][c])) {
          moves.add([r + dir, c]);
          final startRow = up ? 6 : 1;
          if (r == startRow && _isEmpty(b[r + dir * 2][c])) {
            moves.add([r + dir * 2, c]);
          }
        }
        for (final dc in [-1, 1]) {
          if (_inBounds(r + dir, c + dc) && enemy(b[r + dir][c + dc])) {
            moves.add([r + dir, c + dc]);
          }
          // En passant
          if (_epTargetR != null && _epTargetC != null &&
              r + dir == _epTargetR && c + dc == _epTargetC) {
            moves.add([_epTargetR!, _epTargetC!]);
          }
        }
        break;
      case 'N':
        for (final d in [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
          addIfValid(r + d[0], c + d[1]);
        }
        break;
      case 'B':
        slide([[-1,-1],[-1,1],[1,-1],[1,1]]);
        break;
      case 'R':
        slide([[-1,0],[1,0],[0,-1],[0,1]]);
        break;
      case 'Q':
        slide([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]);
        break;
      case 'K':
        for (final d in [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
          addIfValid(r + d[0], c + d[1]);
        }
        break;
    }
    return moves;
  }

  List<int> _kingPos(List<List<String>> b, bool white) {
    final k = white ? 'K' : 'k';
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (b[r][c] == k) return [r, c];
      }
    }
    return [-1, -1];
  }

  bool _isSquareAttacked(List<List<String>> b, int r, int c, bool byWhite) {
    for (int rr = 0; rr < 8; rr++) {
      for (int cc = 0; cc < 8; cc++) {
        final p = b[rr][cc];
        if (p.isEmpty) continue;
        if ((byWhite && !_isWhite(p)) || (!byWhite && !_isBlack(p))) continue;
        for (final m in _pseudoMoves(b, rr, cc)) {
          if (m[0] == r && m[1] == c) return true;
        }
      }
    }
    return false;
  }

  bool _inCheck(List<List<String>> b, bool white) {
    final kp = _kingPos(b, white);
    if (kp[0] < 0) return false;
    return _isSquareAttacked(b, kp[0], kp[1], !white);
  }

  List<List<String>> _copy(List<List<String>> b) =>
      List.generate(8, (i) => List<String>.from(b[i]));

  bool _canCastle(List<List<String>> b, bool white, bool kingside) {
    final row = white ? 7 : 0;
    final king = white ? 'K' : 'k';
    final rook = white ? 'R' : 'r';
    if (b[row][4] != king) return false;
    // Check castling rights
    if (white) {
      if (kingside && _whiteKingMoved) return false;
      if (!kingside && _whiteKingMoved) return false;
      if (kingside && _whiteRookHMoved) return false;
      if (!kingside && _whiteRookAMoved) return false;
    } else {
      if (kingside && _blackKingMoved) return false;
      if (!kingside && _blackKingMoved) return false;
      if (kingside && _blackRookHMoved) return false;
      if (!kingside && _blackRookAMoved) return false;
    }
    final rookCol = kingside ? 7 : 0;
    if (b[row][rookCol] != rook) return false;
    if (_inCheck(b, white)) return false;
    final emptyCols = kingside ? [5, 6] : [1, 2, 3];
    for (final c in emptyCols) {
      if (b[row][c].isNotEmpty) return false;
    }
    final pathCols = kingside ? [4, 5, 6] : [4, 3, 2];
    for (final c in pathCols) {
      if (_isSquareAttacked(b, row, c, !white)) return false;
    }
    return true;
  }

  // All legal moves for side (king never left in check)
  List<Move> _legalMoves(List<List<String>> b, bool white) {
    final res = <Move>[];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final p = b[r][c];
        if (p.isEmpty) continue;
        if ((white && !_isWhite(p)) || (!white && !_isBlack(p))) continue;
        final targets = _pseudoMoves(b, r, c).map((m) => [m[0], m[1]]).toList();
        if (p.toUpperCase() == 'K') {
          if (_canCastle(b, white, true)) targets.add([r, 6]);
          if (_canCastle(b, white, false)) targets.add([r, 2]);
        }
        for (final t in targets) {
          final nb = _copy(b);
          nb[t[0]][t[1]] = nb[r][c];
          nb[r][c] = '';
          if (nb[t[0]][t[1]].toUpperCase() == 'K' && (t[1] - c).abs() == 2) {
            if (t[1] > c) { nb[r][5] = nb[r][7]; nb[r][7] = ''; }
            else { nb[r][3] = nb[r][0]; nb[r][0] = ''; }
          }
          if (nb[t[0]][t[1]].toUpperCase() == 'P' && ((white && t[0] == 0) || (!white && t[0] == 7))) {
            nb[t[0]][t[1]] = white ? 'Q' : 'q';
          }
          if (_inCheck(nb, white)) continue;
          final move = Move(r, c, t[0], t[1]);
          // Set en passant target for this move
          if (p.toUpperCase() == 'P' && (t[0] - r).abs() == 2) {
            move.epTargetR = (r + t[0]) ~/ 2;
            move.epTargetC = c;
          }
          res.add(move);
        }
      }
    }
    return res;
  }

  // Pseudo-legal moves only (for search speed; no castling legality check)
  List<Move> _pseudoLegalMoves(List<List<String>> b, bool white) {
    final res = <Move>[];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final p = b[r][c];
        if (p.isEmpty) continue;
        if ((white && !_isWhite(p)) || (!white && !_isBlack(p))) continue;
        for (final t in _pseudoMoves(b, r, c)) {
          res.add(Move(r, c, t[0], t[1]));
        }
      }
    }
    return res;
  }

  // ── evaluation (positive = white better)
  int _eval(List<List<String>> b) {
    int score = 0;
    int whiteMobility = 0, blackMobility = 0;
    int whiteBishops = 0, blackBishops = 0;

    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final p = b[r][c];
        if (p.isEmpty) continue;
        final v = _pieceValue(p);
        final pst = _pst(p.toUpperCase(), _isWhite(p) ? r : 7 - r, c);
        if (_isWhite(p)) {
          score += v + pst;
          if (p == 'B') whiteBishops++;
          // Mobility: count pseudo-legal moves
          whiteMobility += _pseudoMoves(b, r, c).length;
        } else {
          score -= (v + pst);
          if (p == 'b') blackBishops++;
          blackMobility += _pseudoMoves(b, r, c).length;
        }
      }
    }

    // Mobility bonus
    score += (whiteMobility - blackMobility) * 5;

    // Bishop pair bonus
    if (whiteBishops >= 2) score += 30;
    if (blackBishops >= 2) score -= 30;

    // Passed pawns
    score += _passedPawnBonus(b, true);
    score -= _passedPawnBonus(b, false);

    // King safety
    score += _kingSafety(b, true);
    score -= _kingSafety(b, false);

    // Center control
    score += _centerControl(b, true) * 8;
    score -= _centerControl(b, false) * 8;

    return score;
  }

  int _pieceValue(String p) {
    switch (p.toUpperCase()) {
      case 'P': return 100;
      case 'N': return 320;
      case 'B': return 330;
      case 'R': return 500;
      case 'Q': return 900;
      case 'K': return 20000;
    }
    return 0;
  }

  // ── piece-square tables
  static const List<List<int>> _pawnPst = [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [ 50, 50, 50, 50, 50, 50, 50, 50],
    [ 10, 10, 20, 30, 30, 20, 10, 10],
    [  5,  5, 10, 25, 25, 10,  5,  5],
    [  0,  0,  0, 20, 20,  0,  0,  0],
    [  5, -5,-10,  0,  0,-10, -5,  5],
    [  5, 10, 10,-20,-20, 10, 10,  5],
    [  0,  0,  0,  0,  0,  0,  0,  0],
  ];
  static const List<List<int>> _knightPst = [
    [-50,-40,-30,-30,-30,-30,-40,-50],
    [-40,-20,  0,  0,  0,  0,-20,-40],
    [-30,  0, 10, 15, 15, 10,  0,-30],
    [-30,  5, 15, 20, 20, 15,  5,-30],
    [-30,  0, 15, 20, 20, 15,  0,-30],
    [-30,  5, 10, 15, 15, 10,  5,-30],
    [-40,-20,  0,  5,  5,  0,-20,-40],
    [-50,-40,-30,-30,-30,-30,-40,-50],
  ];
  static const List<List<int>> _bishopPst = [
    [-20,-10,-10,-10,-10,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5, 10, 10,  5,  0,-10],
    [-10,  5,  5, 10, 10,  5,  5,-10],
    [-10,  0, 10, 10, 10, 10,  0,-10],
    [-10, 10, 10, 10, 10, 10, 10,-10],
    [-10,  5,  0,  0,  0,  0,  5,-10],
    [-20,-10,-10,-10,-10,-10,-10,-20],
  ];
  static const List<List<int>> _rookPst = [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [  5, 10, 10, 10, 10, 10, 10,  5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [  0,  0,  0,  5,  5,  0,  0,  0],
  ];
  static const List<List<int>> _queenPst = [
    [-20,-10,-10, -5, -5,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5,  5,  5,  5,  0,-10],
    [ -5,  0,  5,  5,  5,  5,  0, -5],
    [  0,  0,  5,  5,  5,  5,  0, -5],
    [-10,  5,  5,  5,  5,  5,  0,-10],
    [-10,  0,  5,  0,  0,  0,  0,-10],
    [-20,-10,-10, -5, -5,-10,-10,-20],
  ];
  static const List<List<int>> _kingMiddlegamePst = [
    [-50,-40,-30,-20,-20,-30,-40,-50],
    [-30,-20,-10,  0,  0,-10,-20,-30],
    [-30,-10, 20, 30, 30, 20,-10,-30],
    [-30,-10, 30, 40, 40, 30,-10,-30],
    [-30,-10, 30, 40, 40, 30,-10,-30],
    [-30,-10, 20, 30, 30, 20,-10,-30],
    [-30,-30,  0,  0,  0,  0,-30,-30],
    [-50,-30,-30,-30,-30,-30,-30,-50],
  ];

  int _pst(String p, int r, int c) {
    switch (p) {
      case 'P': return _pawnPst[r][c];
      case 'N': return _knightPst[r][c];
      case 'B': return _bishopPst[r][c];
      case 'R': return _rookPst[r][c];
      case 'Q': return _queenPst[r][c];
      case 'K': return _kingMiddlegamePst[r][c];
    }
    return 0;
  }

  // ── passed pawn bonus
  int _passedPawnBonus(List<List<String>> b, bool white) {
    int bonus = 0;
    for (int c = 0; c < 8; c++) {
      for (int r = 0; r < 8; r++) {
        final p = b[r][c];
        if (p != 'P' && p != 'p') continue;
        final isW = p == 'P';
        if (isW != white) continue;
        final dir = isW ? -1 : 1;
        bool passed = true;
        for (int dr = dir; isW ? dr >= 0 : dr <= 7; dr += dir) {
          if (dr == r) continue;
          if (!_inBounds(dr, c)) continue;
          for (final dc in [-1, 0, 1]) {
            final nc = c + dc;
            if (!_inBounds(dr, nc)) continue;
            final op = b[dr][nc];
            if (isW && op == 'p') { passed = false; break; }
            if (!isW && op == 'P') { passed = false; break; }
          }
          if (!passed) break;
        }
        if (passed) {
          final rank = isW ? (7 - r) : r;
          bonus += 10 + rank * 15;
        }
      }
    }
    return bonus;
  }

  // ── king safety: penalty for open files near king
  int _kingSafety(List<List<String>> b, bool white) {
    final kp = _kingPos(b, white);
    if (kp[0] < 0) return 0;
    int penalty = 0;
    final pawns = white ? 'P' : 'p';
    for (final dc in [-1, 0, 1]) {
      final c = kp[1] + dc;
      if (!_inBounds(kp[0], c)) continue;
      bool hasPawn = false;
      for (int r = 0; r < 8; r++) {
        if (b[r][c] == pawns) { hasPawn = true; break; }
      }
      if (!hasPawn) penalty -= 20;
    }
    return penalty;
  }

  // ── center control: how many pieces attack e4/d4/e5/d5
  int _centerControl(List<List<String>> b, bool white) {
    int count = 0;
    const center = [[3,3],[3,4],[4,3],[4,4]];
    for (final sq in center) {
      if (_isSquareAttacked(b, sq[0], sq[1], white)) count++;
    }
    return count;
  }

  // ── MVV-LVA score for move ordering
  int _mvvLva(List<List<String>> b, Move m) {
    final victim = b[m.tr][m.tc];
    final attacker = b[m.fr][m.fc];
    if (victim.isEmpty) return 0;
    return _pieceValue(victim) * 10 - _pieceValue(attacker);
  }

  // ── move ordering
  void _orderMoves(List<Move> moves, List<List<String>> b, int depth) {
    for (final m in moves) {
      m._score = 0;
      final target = b[m.tr][m.tc];
      if (target.isNotEmpty) m._score += _mvvLva(b, m) + 10000;
      // Promotion
      final piece = b[m.fr][m.fc];
      if (piece.toUpperCase() == 'P' && (m.tr == 0 || m.tr == 7)) m._score += 9000;
      // Killer moves
      if (depth < 64) {
        for (final k in _killers[depth]) {
          if (k.fr == m.fr && k.fc == m.fc && k.tr == m.tr && k.tc == m.tc) {
            m._score += 8000;
            break;
          }
        }
      }
      // History heuristic
      final fromIdx = m.fr * 8 + m.fc;
      final toIdx = m.tr * 8 + m.tc;
      if (fromIdx < 64 && toIdx < 64) m._score += _history[fromIdx][toIdx];
    }
    moves.sort((a, b) => b._score.compareTo(a._score));
  }

  // ── quiescence search: search captures until position is quiet
  int _quiescence(List<List<String>> b, int alpha, int beta, bool isMax) {
    if (_aborted || _nodesSearched > _nodeBudget || _searchWatch.elapsedMilliseconds > _timeBudgetMs) {
      _aborted = true;
      return _eval(b);
    }
    _nodesSearched++;

    final standPat = _eval(b);
    if (isMax) {
      if (standPat >= beta) return beta;
      if (standPat > alpha) alpha = standPat;
    } else {
      if (standPat <= alpha) return alpha;
      if (standPat < beta) beta = standPat;
    }

    final moves = _pseudoLegalMoves(b, isMax);
    // Only captures
    final captures = moves.where((m) => b[m.tr][m.tc].isNotEmpty).toList();
    if (captures.isEmpty) return isMax ? alpha : beta;

    _orderMoves(captures, b, 0);

    for (final m in captures) {
      final nb = _copy(b);
      _apply(nb, m);
      if (_inCheck(nb, isMax)) continue;
      final v = _quiescence(nb, alpha, beta, !isMax);
      if (isMax) {
        if (v > alpha) alpha = v;
        if (alpha >= beta) return beta;
      } else {
        if (v < beta) beta = v;
        if (beta <= alpha) return alpha;
      }
    }
    return isMax ? alpha : beta;
  }

  // ── alpha-beta with TT
  int _abSearch(List<List<String>> b, int depth, int alpha, int beta, bool isMax, int ply) {
    if (_aborted || _nodesSearched > _nodeBudget || _searchWatch.elapsedMilliseconds > _timeBudgetMs) {
      _aborted = true;
      return _eval(b);
    }
    _nodesSearched++;

    final hash = _computeHash(b, isMax);

    final ttEntry = _tt[hash];
    if (ttEntry != null && ttEntry.depth >= depth) {
      if (ttEntry.flag == 0) return ttEntry.score; // exact
      if (ttEntry.flag == 1 && ttEntry.score >= beta) return ttEntry.score; // lower bound
      if (ttEntry.flag == -1 && ttEntry.score <= alpha) return ttEntry.score; // upper bound
    }

    // Deteksi pengulangan posisi: hukuman 0 kalau posisi sudah 2x terjadi
    // (sudah 1x di permainan + 1x di line pencarian). Ini mencegah AI
    // "bolak balik" / mengulang langkah yang sama.
    int rep = 0;
    for (final h in _positionHistory) {
      if (h == hash) rep++;
    }
    for (final h in _repIndex) {
      if (h == hash) rep++;
    }
    if (rep >= 2) {
      // Hukuman pengulangan (nilai kecil): pengulangan = remis, dan siapa yang
      // mengulang posisi dihukum sedikit. Ini membuat AI menghindari "bolak
      // balik" kuda/benteng di posisi tenang — ia lebih memilih mengembangkan.
      return isMax ? -75 : 75;
    }

    _repIndex.add(hash);

    final moves = _legalMoves(b, isMax);
    if (moves.isEmpty) {
      _repIndex.removeLast();
      if (_inCheck(b, isMax)) return isMax ? -100000 - ply : 100000 + ply;
      return 0; // stalemate
    }
    if (depth <= 0) {
      _repIndex.removeLast();
      return _quiescence(b, alpha, beta, isMax);
    }

    _orderMoves(moves, b, ply < 64 ? ply : 63);

    int bestScore = isMax ? -100000000 : 100000000;
    int flag = isMax ? -1 : 1; // assume upper/lower bound

    for (int i = 0; i < moves.length; i++) {
      final m = moves[i];
      final nb = _copy(b);
      final savedEpR = _epTargetR, savedEpC = _epTargetC;
      _apply(nb, m);
      final afterEpR = _epTargetR, afterEpC = _epTargetC;
      _epTargetR = savedEpR; _epTargetC = savedEpC;
      if (_inCheck(nb, isMax)) continue;

      int v;
      // Late move reductions
      bool isCapture;
      if (isMax) {
        isCapture = _isBlack(b[m.tr][m.tc]);
      } else {
        isCapture = _isWhite(b[m.tr][m.tc]);
      }
      if (i >= 4 && depth >= 3 && !isCapture && !_inCheck(nb, !isMax)) {
        _epTargetR = afterEpR; _epTargetC = afterEpC;
        v = _abSearch(nb, depth - 2, alpha, beta, !isMax, ply + 1);
        _epTargetR = savedEpR; _epTargetC = savedEpC;
        if (v > (isMax ? alpha : beta)) {
          _epTargetR = afterEpR; _epTargetC = afterEpC;
          v = _abSearch(nb, depth - 1, alpha, beta, !isMax, ply + 1);
          _epTargetR = savedEpR; _epTargetC = savedEpC;
        }
      } else {
        // PVS: zero-window search for non-first moves
        if (i > 0) {
          _epTargetR = afterEpR; _epTargetC = afterEpC;
          v = _abSearch(nb, depth - 1, alpha, alpha + 1, !isMax, ply + 1);
          _epTargetR = savedEpR; _epTargetC = savedEpC;
          if (v > alpha && v < beta) {
            _epTargetR = afterEpR; _epTargetC = afterEpC;
            v = _abSearch(nb, depth - 1, alpha, beta, !isMax, ply + 1);
            _epTargetR = savedEpR; _epTargetC = savedEpC;
          }
        } else {
          _epTargetR = afterEpR; _epTargetC = afterEpC;
          v = _abSearch(nb, depth - 1, alpha, beta, !isMax, ply + 1);
          _epTargetR = savedEpR; _epTargetC = savedEpC;
        }
      }

      if (isMax) {
        if (v > bestScore) bestScore = v;
        if (v > alpha) { alpha = v; flag = 0; }
        if (alpha >= beta) {
          // Update killer & history
          if (depth < 64 && m._score < 8000) {
            final kIdx = ply < 64 ? ply : 63;
            _killers[kIdx][1] = _killers[kIdx][0];
            _killers[kIdx][0] = m;
          }
          final fromIdx = m.fr * 8 + m.fc;
          final toIdx = m.tr * 8 + m.tc;
          if (fromIdx < 64 && toIdx < 64) _history[fromIdx][toIdx] += depth * depth;
          flag = 1; // lower bound
          break;
        }
      } else {
        if (v < bestScore) bestScore = v;
        if (v < beta) { beta = v; flag = 0; }
        if (beta <= alpha) {
          if (depth < 64 && m._score < 8000) {
            final kIdx = ply < 64 ? ply : 63;
            _killers[kIdx][1] = _killers[kIdx][0];
            _killers[kIdx][0] = m;
          }
          final fromIdx = m.fr * 8 + m.fc;
          final toIdx = m.tr * 8 + m.tc;
          if (fromIdx < 64 && toIdx < 64) _history[fromIdx][toIdx] += depth * depth;
          flag = -1; // upper bound (score terlalu bagus utk hitam ko di bawah alpha)
          break;
        }
      }
    }

    _repIndex.removeLast();

    // TT store
    _tt[hash] = _TTEntry(bestScore, depth, flag);

    return bestScore;
  }

  void _apply(List<List<String>> b, Move m) {
    final piece = b[m.fr][m.fc];
    // En passant capture in search
    if (piece.toUpperCase() == 'P' && m.tc == (_epTargetC ?? -1) && m.tr == (_epTargetR ?? -2)) {
      final capturedRow = _isWhite(piece) ? m.tr + 1 : m.tr - 1;
      if (_inBounds(capturedRow, m.tc)) b[capturedRow][m.tc] = '';
    }
    b[m.tr][m.tc] = piece;
    b[m.fr][m.fc] = '';
    // Castling
    if (piece.toUpperCase() == 'K' && (m.tc - m.fc).abs() == 2) {
      if (m.tc > m.fc) { b[m.tr][5] = b[m.tr][7]; b[m.tr][7] = ''; }
      else { b[m.tr][3] = b[m.tr][0]; b[m.tr][0] = ''; }
    }
    // Auto-promote for AI (always queen)
    if (b[m.tr][m.tc].toUpperCase() == 'P') {
      if (m.tr == 0) { b[m.tr][m.tc] = 'Q'; }
      else if (m.tr == 7) { b[m.tr][m.tc] = 'q'; }
    }
    // Propagate en passant target
    _epTargetR = m.epTargetR;
    _epTargetC = m.epTargetC;
  }

  Move? _findBestMove() {
    final aiWhite = !playerIsWhite;
    final allMoves = _legalMoves(board, aiWhite);
    if (allMoves.isEmpty) return null;

    _nodesSearched = 0;
    _aborted = false;
    _searchWatch..reset()..start();
    _tt.clear();
    for (final row in _history) { row.fillRange(0, row.length, 0); }

    Move bestMove = allMoves.first;

    // Iterative deepening
    for (int depth = 1; depth <= _maxDepth; depth++) {
      _orderMoves(allMoves, board, 0);
      Move? iterationBest;
      int iterationScore = aiWhite ? -100000000 : 100000000;

      for (final m in allMoves) {
        if (_aborted) break;
        final nb = _copy(board);
        final savedEpR = _epTargetR, savedEpC = _epTargetC;
        _apply(nb, m);
        final afterEpR = _epTargetR, afterEpC = _epTargetC;
        _epTargetR = savedEpR; _epTargetC = savedEpC;
        if (_inCheck(nb, aiWhite)) continue;

        int v;
        // PVS at root
        if (m != allMoves.first) {
          _epTargetR = afterEpR; _epTargetC = afterEpC;
          v = _abSearch(nb, depth - 1, iterationScore, iterationScore + 1, !aiWhite, 1);
          _epTargetR = savedEpR; _epTargetC = savedEpC;
          if ((aiWhite && v > iterationScore) || (!aiWhite && v < iterationScore)) {
            _epTargetR = afterEpR; _epTargetC = afterEpC;
            v = _abSearch(nb, depth - 1, aiWhite ? iterationScore : -100000000, aiWhite ? 100000000 : iterationScore, !aiWhite, 1);
            _epTargetR = savedEpR; _epTargetC = savedEpC;
          }
        } else {
          _epTargetR = afterEpR; _epTargetC = afterEpC;
          v = _abSearch(nb, depth - 1, -100000000, 100000000, !aiWhite, 1);
          _epTargetR = savedEpR; _epTargetC = savedEpC;
        }

        if (!_aborted) {
          if ((aiWhite && v > iterationScore) || (!aiWhite && v < iterationScore)) {
            iterationScore = v;
            iterationBest = m;
          }
        }
      }

      if (!_aborted && iterationBest != null) {
        bestMove = iterationBest;
      }

      // Time check: if we've used more than 70% of budget, stop
      if (_searchWatch.elapsedMilliseconds > _timeBudgetMs * 0.7) break;
    }

    return bestMove;
  }

  void _onTap(int r, int c) {
    if (!_inBounds(r, c) || !mounted) return;
    if (gameOver || aiThinking || _awaitingPromotion) return;
    if (mode == CaturMode.ai && whiteTurn != playerIsWhite) return;

    final piece = board[r][c];

    if (selected != null) {
      final isValid = validMoves.any((m) => m[0] == r && m[1] == c);
      if (isValid) {
        final fr = selected![0], fc = selected![1];
        final movingPiece = board[fr][fc];

        // Check if this is a pawn promotion
        if (movingPiece == 'P' && r == 0) {
          _showPromotionDialog(fr, fc, r, c, true);
          return;
        }
        if (movingPiece == 'p' && r == 7) {
          _showPromotionDialog(fr, fc, r, c, false);
          return;
        }

        _movePiece(fr, fc, r, c);
        setState(() {
          selected = null;
          validMoves = [];
          whiteTurn = !whiteTurn;
          if (mode == CaturMode.ai) {
            statusMsg = 'AI sedang berpikir...';
            aiThinking = true;
          } else {
            statusMsg = whiteTurn ? 'Giliran Putih • 2 Player' : 'Giliran Hitam • 2 Player';
          }
          _resolveGameStatus();
        });
        if (mode == CaturMode.ai && !gameOver) _scheduleAi();
        return;
      }
    }

    if (piece.isNotEmpty &&
        ((mode == CaturMode.ai && _isWhite(piece) == playerIsWhite) ||
         (mode == CaturMode.twoPlayer &&
          ((whiteTurn && _isWhite(piece)) || (!whiteTurn && _isBlack(piece)))))) {
      setState(() {
        selected = [r, c];
        validMoves = _legalMoves(board, _isWhite(piece))
            .where((m) => m.fr == r && m.fc == c)
            .map((m) => [m.tr, m.tc])
            .toList();
      });
    } else {
      setState(() { selected = null; validMoves = []; });
    }
  }

  void _showPromotionDialog(int fr, int fc, int tr, int tc, bool isWhite) {
    _awaitingPromotion = true;
    _promoFromR = fr;
    _promoFromC = fc;
    _promoToR = tr;
    _promoToC = tc;
    _promoIsWhite = isWhite;

    final pieces = isWhite
        ? [('♕', 'Q', 'Menteri'), ('♖', 'R', 'Benteng'), ('♗', 'B', 'Gajah'), ('♘', 'N', 'Kuda')]
        : [('♛', 'q', 'Menteri'), ('♜', 'r', 'Benteng'), ('♝', 'b', 'Gajah'), ('♞', 'n', 'Kuda')];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1C1B2E), Color(0xFF12101F)],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0x66FFD98A), width: 1.2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'PROMOSI PION',
              style: TextStyle(
                color: NeoColors.gold,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Pilih bidak yang diinginkan',
              style: TextStyle(color: NeoColors.secondaryText, fontSize: 12),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: pieces.map((p) {
                return GestureDetector(
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _completePromotion(p.$2);
                  },
                  child: Container(
                    width: 72,
                    height: 84,
                    decoration: BoxDecoration(
                      color: const Color(0x10FFD98A),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0x44FFD98A), width: 1),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          p.$1,
                          style: TextStyle(
                            fontSize: 36,
                            color: isWhite ? Colors.white : const Color(0xFF0B0A16),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          p.$3,
                          style: TextStyle(
                            color: NeoColors.gold,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    ).then((_) {
      // If dismissed without choosing, default to queen
      if (mounted && _awaitingPromotion) {
        _completePromotion(isWhite ? 'Q' : 'q');
      }
    });
  }

  void _completePromotion(String piece) {
    if (!mounted || !_awaitingPromotion) return;
    final fr = _promoFromR!, fc = _promoFromC!;
    final tr = _promoToR!, tc = _promoToC!;
    final isWhite = _promoIsWhite;
    _awaitingPromotion = false;

    final target = board[tr][tc];
    if (target.isNotEmpty) {
      if (isWhite) { blackCaptures++; } else { whiteCaptures++; }
    }
    board[tr][tc] = piece;
    board[fr][fc] = '';
    _positionHistory.add(_computeHash(board, !isWhite));

    setState(() {
      selected = null;
      validMoves = [];
      whiteTurn = !whiteTurn;
      if (mode == CaturMode.ai) {
        statusMsg = 'AI sedang berpikir...';
        aiThinking = true;
      } else {
        statusMsg = whiteTurn ? 'Giliran Putih • 2 Player' : 'Giliran Hitam • 2 Player';
      }
      _resolveGameStatus();
    });
    if (mode == CaturMode.ai && !gameOver) _scheduleAi();
  }

  void _scheduleAi() {
    final gen = _aiGeneration;
    final aiWhite = !playerIsWhite;
    setState(() {
      aiThinking = true;
      statusMsg = aiWhite ? 'AI (Putih) sedang berpikir...' : 'AI (Hitam) sedang berpikir...';
    });
    Future.delayed(const Duration(milliseconds: 400), () {
      if (!mounted || gen != _aiGeneration) return;
      _aiMove();
    });
  }

  void _movePiece(int fr, int fc, int tr, int tc) {
    final piece = board[fr][fc];
    final target = board[tr][tc];

    // En passant capture
    if (piece.toUpperCase() == 'P' && _epTargetR != null && _epTargetC != null &&
        tr == _epTargetR && tc == _epTargetC) {
      final capturedRow = _isWhite(piece) ? tr + 1 : tr - 1;
      final captured = board[capturedRow][tc];
      if (captured.isNotEmpty) {
        if (_isWhite(piece)) { blackCaptures++; } else { whiteCaptures++; }
      }
      board[capturedRow][tc] = '';
    } else if (target.isNotEmpty) {
      if (_isWhite(piece)) { blackCaptures++; } else { whiteCaptures++; }
    }

    board[tr][tc] = piece;
    board[fr][fc] = '';

    // Set en passant target on double pawn push
    _epTargetR = null;
    _epTargetC = null;
    if (piece.toUpperCase() == 'P' && (tr - fr).abs() == 2) {
      _epTargetR = (fr + tr) ~/ 2;
      _epTargetC = fc;
    }

    // Castling
    if (piece.toUpperCase() == 'K' && (tc - fc).abs() == 2) {
      if (tc > fc) { board[fr][5] = board[fr][7]; board[fr][7] = ''; }
      else { board[fr][3] = board[fr][0]; board[fr][0] = ''; }
    }

    // Update castling rights
    if (piece == 'K') { _whiteKingMoved = true; }
    if (piece == 'k') { _blackKingMoved = true; }
    if (piece == 'R' && fr == 7 && fc == 0) { _whiteRookAMoved = true; }
    if (piece == 'R' && fr == 7 && fc == 7) { _whiteRookHMoved = true; }
    if (piece == 'r' && fr == 0 && fc == 0) { _blackRookAMoved = true; }
    if (piece == 'r' && fr == 0 && fc == 7) { _blackRookHMoved = true; }
    // Rook captured
    if (tr == 7 && tc == 0) { _whiteRookAMoved = true; }
    if (tr == 7 && tc == 7) { _whiteRookHMoved = true; }
    if (tr == 0 && tc == 0) { _blackRookAMoved = true; }
    if (tr == 0 && tc == 7) { _blackRookHMoved = true; }

    _positionHistory.add(_computeHash(board, !_isWhite(piece)));
  }

  void _resolveGameStatus() {
    final side = whiteTurn;
    if (gameOver) return;
    final moves = _legalMoves(board, side);
    final isCheck = _inCheck(board, side);
    if (moves.isEmpty) {
      gameOver = true;
      _clock?.cancel();
      if (isCheck) {
        SoundService.playChessCheckmate();
        final winnerWhite = !side;
        if (mode == CaturMode.twoPlayer) {
          statusMsg = winnerWhite ? '🏆 Putih Menang! Skakmat.' : '🏆 Hitam Menang! Skakmat.';
        } else {
          final playerWon = winnerWhite == playerIsWhite;
          statusMsg = playerWon ? '🏆 Kamu Menang! Skakmat.' : '🏆 AI Menang! Skakmat.';
        }
      } else {
        statusMsg = '🤝 Remis (Pat)';
      }
    } else if (isCheck) {
      SoundService.playChessCheck();
      if (!statusMsg.contains('SEKAK')) {
        statusMsg += ' • ⚠️ SEKAK!';
      }
    } else {
      SoundService.playChessMove();
    }
  }

  void _aiMove() {
    if (gameOver || !mounted) return;
    Move? m;
    try {
      m = _findBestMove();
    } catch (_) {
      m = null;
    }
    if (m == null) {
      _clock?.cancel();
      setState(() {
        gameOver = true;
        statusMsg = _inCheck(board, !playerIsWhite)
            ? '🏆 Kamu Menang! AI Skakmat.'
            : '🤝 Remis (Pat)';
        aiThinking = false;
      });
      return;
    }
    final move = m;
    setState(() {
      try {
        _movePiece(move.fr, move.fc, move.tr, move.tc);
        // Auto-promote AI pawns
        if (board[move.tr][move.tc] == 'P' && move.tr == 0) board[move.tr][move.tc] = 'Q';
        if (board[move.tr][move.tc] == 'p' && move.tr == 7) board[move.tr][move.tc] = 'q';
      } catch (_) {
        gameOver = true;
        statusMsg = 'Permainan diakhiri (error internal).';
      }
      whiteTurn = playerIsWhite;
      aiThinking = false;
      if (!gameOver) {
        statusMsg = playerIsWhite
            ? 'Giliran Kamu (Putih) 🐺 • VS AI'
            : 'Giliran Kamu (Hitam) 🐺 • VS AI';
      }
      _resolveGameStatus();
      if (!gameOver) selected = null;
    });
  }

  String _pieceEmoji(String p) {
    const map = {
      'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
      'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟\uFE0F',
    };
    return map[p] ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: NeoColors.primaryText,
        title: Row(
          children: [
            Icon(Icons.grid_4x4_rounded, color: NeoColors.gold, size: 20),
            SizedBox(width: 8),
            Text(
              'CATUR ARENA',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 1.5,
                color: NeoColors.primaryText,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: NeoColors.gold),
            onPressed: _initBoard,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),

            // Mode selector
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0x33FFD98A), width: 1),
              ),
              child: Row(
                children: [
                  _modeTab(CaturMode.ai, '🤖 VS AI', 'AI Hard'),
                  _modeTab(CaturMode.twoPlayer, '👥 2 PLAYER', 'Local'),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Time control
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0x33FFD98A), width: 1),
              ),
              child: Row(
                children: [
                  _timeTab(0, '∞ TANPA BATAS'),
                  _timeTab(3, "3'"),
                  _timeTab(5, "5'"),
                  _timeTab(10, "10'"),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // Status
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                border: Border.all(color: const Color(0x44FFD98A), width: 1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: Text(
                  statusMsg,
                  style: TextStyle(
                    color: NeoColors.gold,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Clocks
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _ClockChip(
                    label: '♔ PUTIH',
                    time: _fmtClock(whiteRemainingMs),
                    active: whiteTurn && !gameOver,
                    color: NeoColors.gold,
                    captures: whiteCaptures,
                  ),
                  _ClockChip(
                    label: '♚ HITAM',
                    time: _fmtClock(blackRemainingMs),
                    active: !whiteTurn && !gameOver,
                    color: NeoColors.pink,
                    captures: blackCaptures,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Board
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0x66FFD98A), width: 1.5),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(color: Color(0x44FFD98A), blurRadius: 24),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
                        itemCount: 64,
                        itemBuilder: (_, idx) {
                          final idxR = idx ~/ 8;
                          final idxC = idx % 8;
                          final r = _mirrorBoard ? 7 - idxR : idxR;
                          final c = _mirrorBoard ? 7 - idxC : idxC;
                          final isSelected = selected != null && selected![0] == r && selected![1] == c;
                          final isValidMove = validMoves.any((m) => m[0] == r && m[1] == c);
                          final piece = board[r][c];
                          final inCheckHighlight = _showCheckHighlight(r, c);

                          final isDarkSq = (r + c) % 2 == 1;
                          Color bg = isDarkSq ? const Color(0xFF1E172E) : const Color(0xFF382A50);
                          if (inCheckHighlight) bg = const Color(0x33FF3B5C);
                          if (isSelected) bg = const Color(0x99FFD98A);
                          if (isValidMove) bg = const Color(0x66FFD98A);

                          return GestureDetector(
                            onTap: () => _onTap(r, c),
                            child: Container(
                              color: bg,
                              child: Stack(
                                children: [
                                  if (isValidMove && piece.isEmpty)
                                    Center(
                                      child: Container(
                                        width: 10,
                                        height: 10,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: NeoColors.gold,
                                          boxShadow: [BoxShadow(color: Color(0xFFFFD98A), blurRadius: 6)],
                                        ),
                                      ),
                                    ),
                                  if (isValidMove && piece.isNotEmpty)
                                    Positioned.fill(
                                      child: Container(
                                        margin: const EdgeInsets.all(2),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(color: const Color(0xFFFF5C8A), width: 2.5),
                                        ),
                                      ),
                                    ),
                                  Center(
                                    child: Text(
                                      _pieceEmoji(piece),
                                      style: TextStyle(
                                        fontSize: 26,
                                        color: _isWhite(piece)
                                            ? Colors.white
                                            : const Color(0xFF0B0A16),
                                        shadows: [
                                          Shadow(
                                            color: _isWhite(piece)
                                                ? const Color(0x99FFD98A)
                                                : const Color(0x55E8ECFF),
                                            blurRadius: _isWhite(piece) ? 8 : 3,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),

            if (gameOver)
              Padding(
                padding: const EdgeInsets.all(20),
                child: NeoButton(
                  label: 'MAIN LAGI',
                  bgColor: NeoColors.gold,
                  textColor: const Color(0xFF1A1100),
                  height: 48,
                  fontSize: 14,
                  onPressed: _initBoard,
                ),
              ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  bool get _mirrorBoard => mode == CaturMode.ai && !playerIsWhite;

  bool _showCheckHighlight(int r, int c) {
    if (gameOver) return false;
    final side = whiteTurn;
    final kp = _kingPos(board, side);
    if (kp[0] != r || kp[1] != c) return false;
    return _inCheck(board, side);
  }

  Widget _modeTab(CaturMode m, String label, String sub) {
    final active = mode == m;
    final color = active ? NeoColors.gold : NeoColors.secondaryText;
    return Expanded(
      child: GestureDetector(
        onTap: () => _setMode(m),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? const Color(0x22FFD98A) : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: active ? const Color(0x66FFD98A) : Colors.transparent),
          ),
          child: Column(
            children: [
              Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 13)),
              const SizedBox(height: 2),
              Text(sub, style: TextStyle(color: NeoColors.secondaryText, fontSize: 9, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }

  String _fmtClock(int ms) {
    if (_timeControl <= 0) return '∞';
    final totalSec = ms ~/ 1000;
    final m = totalSec ~/ 60;
    final sec = totalSec % 60;
    return '$m:${sec.toString().padLeft(2, '0')}';
  }

  Widget _timeTab(int minutes, String label) {
    final active = _timeControl == minutes;
    final color = active ? NeoColors.gold : NeoColors.secondaryText;
    return Expanded(
      child: GestureDetector(
        onTap: () => _setTimeControl(minutes),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: active ? const Color(0x22FFD98A) : Colors.transparent,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: active ? const Color(0x66FFD98A) : Colors.transparent),
          ),
          child: Center(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
            ),
          ),
        ),
      ),
    );
  }
}

class _ClockChip extends StatelessWidget {
  final String label;
  final String time;
  final bool active;
  final Color color;
  final int captures;
  const _ClockChip({
    required this.label,
    required this.time,
    required this.active,
    required this.color,
    required this.captures,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: active ? color.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: active ? color : const Color(0x22FFFFFF), width: active ? 2 : 1),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.w800, letterSpacing: 1, color: active ? color : NeoColors.secondaryText)),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(time, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, fontFamily: 'monospace', color: active ? color : NeoColors.primaryText)),
          ),
          const SizedBox(height: 2),
          Text('+$captures', style: TextStyle(fontSize: 9, color: NeoColors.secondaryText)),
        ],
      ),
    );
  }
}

class Move {
  final int fr, fc, tr, tc;
  int _score = 0;
  int? epTargetR, epTargetC; // en passant target AFTER this move
  Move(this.fr, this.fc, this.tr, this.tc);
}

class _TTEntry {
  final int score;
  final int depth;
  final int flag; // 0=exact, 1=lower, -1=upper
  const _TTEntry(this.score, this.depth, this.flag);
}
