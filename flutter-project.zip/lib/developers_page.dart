import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:ui'; // 👈 untuk BackdropFilter (efek kaca)

class DevelopersPage extends StatelessWidget {
  final String sessionKey;
  final String username;

  const DevelopersPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  // 🎨 Warna tema BIRU
  static const Color kBgBiru     = Color(0xFF030B1F);
  static const Color kCardBiru   = Color(0xFF07183D);
  static const Color kBorderBiru = Color(0xFF1E5FC7);
  static const Color kBlueNeon   = Color(0xFF00D4FF);
  static const Color kBlueGlow   = Color(0xFF2979FF);
  static const Color kWhite      = Colors.white;
  static const Color kWhite54    = Colors.white54;

  // 🔧 Konstanta transparansi & ukuran
  static const double kWallpaperOpacity = 0.35;
  static const double kCardOpacity      = 0.25;
  static const double kCardBlur         = 12.0;
  static const double kAvatarSize       = 170.0;

  @override
  Widget build(BuildContext context) {
    final developers = [
      {
        'nama': 'ZILXPDIA',
        'jabatan': 'PEMILIK- Developer',
        'foto': 'assets/images/home.png',
        'tele': 'https://t.me/r4pzzxi',
      },
      {
        'nama': 'RAPS',
        'jabatan': 'CREATOR- Developer',
        'foto': 'assets/images/phnx.jpg',
        'tele': 'https://t.me/@r4pzzxi',
      },
    ];

    // 🔥 4 KOTAK FRIENDS 🔥
    final friendList = [
      {
        'nama': 'QORZZ',
        'jabatan': 'My Friend ZILXPEDIA',
        'foto': 'assets/images/logo.jpg',
      },
      {
        'nama': 'arya wira',
        'jabatan': 'My Friend ZILXPEDIA',
        'foto': 'assets/images/reze.png',
      },
      {
        'nama': 'leo',
        'jabatan': 'My Friend ZILXPEDIA',
        'foto': 'assets/images/logo_dev.jpg',
      },
      {
        'nama': 'bara',
        'jabatan': 'My Friend ZILXPEDIA',
        'foto': 'assets/images/logo_devs.jpg',
      },
    ];

    // 📱 Ukuran avatar responsive
    final screenW = MediaQuery.of(context).size.width;
    final avatarSize = screenW < 340
        ? 120.0
        : screenW < 380
            ? 140.0
            : kAvatarSize;

    return Scaffold(
      backgroundColor: kBgBiru,
      body: Stack(
        children: [
          // ═══ 1. BACKGROUND GRADIENT DASAR ═══
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [kBgBiru, Color(0xFF000000)],
              ),
            ),
          ),

          // ═══ 2. WALLPAPER dashboard.png (TEMBUS) ═══
          Positioned.fill(
            child: IgnorePointer(
              child: Opacity(
                opacity: kWallpaperOpacity,
                child: Image.asset(
                  'assets/images/dashboard.png',
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ),
          ),

          // ═══ 3. OVERLAY GELAP TIPIS ═══
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.25),
                      Colors.black.withOpacity(0.55),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ═══ 4. KONTEN UTAMA ═══
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ═══ HEADER DEVELOPER ═══
                  Row(
                    children: [
                      Container(
                        width: 4, height: 40,
                        decoration: BoxDecoration(
                          color: kBlueNeon,
                          borderRadius: BorderRadius.circular(2),
                          boxShadow: [
                            BoxShadow(
                              color: kBlueNeon.withOpacity(0.9),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Opacity(
                        opacity: 0.95,
                        child: Image.asset(
                          'assets/images/dashboard.png',
                          width: 40, height: 40,
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const SizedBox(
                              width: 40, height: 40),
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('DEVELOPER',
                                style: TextStyle(
                                  color: kWhite,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 3,
                                  shadows: [
                                    Shadow(
                                        color: kBlueNeon,
                                        blurRadius: 14),
                                  ],
                                )),
                            SizedBox(height: 2),
                            Text('Tim di balik VOR4X EXCECUTOR',
                                style: TextStyle(
                                    color: kWhite54, fontSize: 11)),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // ═══ KARTU DEVELOPER (GLASS) ═══
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: developers.map((dev) {
                      return Expanded(
                        child: _glassCard(
                          margin:
                              const EdgeInsets.symmetric(horizontal: 4),
                          radius: 20,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 22),
                          child: Column(
                            children: [
                              // 🔵 AVATAR BULAT BESAR + GLOW
                              _avatarCircle(
                                imagePath: dev['foto']!,
                                size: avatarSize,
                              ),
                              const SizedBox(height: 16),

                              // NAMA
                              Text(dev['nama']!,
                                  style: const TextStyle(
                                    color: kWhite,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 0.5,
                                    shadows: [
                                      Shadow(
                                          color: kBlueNeon,
                                          blurRadius: 8),
                                    ],
                                  ),
                                  textAlign: TextAlign.center),
                              const SizedBox(height: 4),

                              // JABATAN
                              Text(dev['jabatan']!,
                                  style: const TextStyle(
                                    color: kWhite54,
                                    fontSize: 10,
                                    letterSpacing: 0.3,
                                  ),
                                  textAlign: TextAlign.center),
                              const SizedBox(height: 16),

                              // TOMBOL TELEGRAM
                              GestureDetector(
                                onTap: () async {
                                  final url = Uri.parse(dev['tele']!);
                                  if (await canLaunchUrl(url)) {
                                    await launchUrl(url,
                                        mode: LaunchMode
                                            .externalApplication);
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10),
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xFF0072FF)
                                            .withOpacity(0.75),
                                        const Color(0xFF00D4FF)
                                            .withOpacity(0.75),
                                      ],
                                    ),
                                    borderRadius:
                                        BorderRadius.circular(12),
                                    border: Border.all(
                                      color:
                                          kBlueNeon.withOpacity(0.6),
                                      width: 1,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            kBlueGlow.withOpacity(0.7),
                                        blurRadius: 18,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                  child: const Center(
                                    child: Icon(Icons.send,
                                        color: kWhite, size: 16),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 30),

                  // ═══ HEADER "MY FRIENDS" ═══
                  Row(
                    children: [
                      const Icon(Icons.people_alt_rounded,
                          color: kBlueNeon, size: 22),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('My Friends',
                              style: TextStyle(
                                color: kWhite,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                                shadows: [
                                  Shadow(
                                      color: kBlueNeon,
                                      blurRadius: 10),
                                ],
                              )),
                          SizedBox(height: 2),
                          Text('Para penolong di balik VOR4X',
                              style: TextStyle(
                                  color: kWhite54, fontSize: 11)),
                        ],
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ═══ KARTU FRIENDS (GRID 2x2) - VERSI FIX ═══
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: friendList.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.68, // 👈 Tinggi ke atas
                    ),
                    itemBuilder: (context, index) {
                      final friend = friendList[index];
                      return _glassCard(
                        margin: EdgeInsets.zero,
                        radius: 16,
                        padding: EdgeInsets.zero, // 👈 Gambar mentok ke atas
                        child: Column(
                          children: [
                            // 📸 BAGIAN GAMBAR (DI ATAS)
                            Expanded(
                              flex: 4, // 👈 Gambar ambil porsi besar
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  ClipRRect(
                                    borderRadius:
                                        const BorderRadius.only(
                                      topLeft: Radius.circular(15),
                                      topRight: Radius.circular(15),
                                    ),
                                    child: Image.asset(
                                      friend['foto']!,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) =>
                                          Container(
                                        color: kCardBiru
                                            .withOpacity(0.5),
                                        child: const Center(
                                          child: Icon(
                                              Icons.person,
                                              color: kBlueNeon,
                                              size: 40),
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Ikon di pojok kanan atas gambar
                                  Positioned(
                                    top: 8, right: 8,
                                    child: Container(
                                      width: 28, height: 28,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: kBlueGlow
                                            .withOpacity(0.45),
                                        border: Border.all(
                                            color: kBlueNeon,
                                            width: 1.5),
                                      ),
                                      child: const Icon(
                                          Icons.people_alt_rounded,
                                          color: kWhite, size: 14),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            
                            // 📝 BAGIAN TEKS (DI BAWAH)
                            Expanded(
                              flex: 2, // 👈 Teks ambil porsi kecil
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 6),
                                decoration: BoxDecoration(
                                  // Background biru gelap solid, bukan gambar
                                  color: kCardBiru.withOpacity(0.9),
                                  borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(15),
                                    bottomRight: Radius.circular(15),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      friend['nama']!,
                                      style: const TextStyle(
                                        color: kWhite,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.5,
                                      ),
                                      textAlign: TextAlign.center,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      friend['jabatan']!,
                                      style: const TextStyle(
                                        color: kWhite54,
                                        fontSize: 9.5,
                                      ),
                                      textAlign: TextAlign.center,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════
  // 🔵 AVATAR BULAT BESAR + GLOW PULSE
  // ═══════════════════════════════════════════════
  Widget _avatarCircle({
    required String imagePath,
    required double size,
  }) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: kBlueNeon, width: 4),
        boxShadow: [
          BoxShadow(
            color: kBlueNeon.withOpacity(1.0),
            blurRadius: 35,
            spreadRadius: 4,
          ),
          BoxShadow(
            color: kBlueGlow.withOpacity(0.8),
            blurRadius: 60,
            spreadRadius: 6,
          ),
        ],
      ),
      child: ClipOval(
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          width: double.infinity,
          height: double.infinity,
          alignment: Alignment.center,
          errorBuilder: (_, __, ___) => Container(
            color: kCardBiru,
            child: const Center(
              child: Icon(Icons.person, color: kBlueNeon, size: 60),
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════
  // 🧊 WIDGET GLASS CARD (Transparan + Blur)
  // ═══════════════════════════════════════════════
  Widget _glassCard({
    required Widget child,
    EdgeInsets margin = EdgeInsets.zero,
    EdgeInsets padding = const EdgeInsets.all(12),
    double radius = 16,
  }) {
    return Container(
      margin: margin,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(
              sigmaX: kCardBlur, sigmaY: kCardBlur),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: kCardBiru.withOpacity(kCardOpacity),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(
                color: kBlueNeon.withOpacity(0.35),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: kBlueGlow.withOpacity(0.25),
                  blurRadius: 22,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}