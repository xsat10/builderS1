import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class JadwalSholat extends StatefulWidget {
  const JadwalSholat({super.key});

  @override
  State<JadwalSholat> createState() => _JadwalSholatState();
}

class _JadwalSholatState extends State<JadwalSholat> {
  Map<String, String> jadwal = {};
  String nextSholat = "";
  bool loading = true;
  String idKota = "1301"; // Default Surabaya
  String namaKota = "Surabaya";

  @override
  void initState() {
    super.initState();
    loadJadwal();
  }

  // LOGIKA AMBIL JADWAL
  Future<void> loadJadwal() async {
    setState(() => loading = true);
    final now = DateTime.now();
    try {
      final url = Uri.parse(
        "https://api.myquran.com/v2/sholat/jadwal/$idKota/${now.year}/${now.month}/${now.day}",
      );
      final response = await http.get(url);
      final data = jsonDecode(response.body);
      final j = data["data"]["jadwal"];

      setState(() {
        jadwal = {
          "Subuh": j["subuh"],
          "Dzuhur": j["dzuhur"],
          "Ashar": j["ashar"],
          "Maghrib": j["maghrib"],
          "Isya": j["isya"],
        };
        nextSholat = getNextPrayer(jadwal);
        loading = false;
      });
    } catch (e) {
      print("Error: $e");
      setState(() => loading = false);
    }
  }

  // CARI SHOLAT BERIKUTNYA
  String getNextPrayer(Map<String, String> jadwal) {
    final now = TimeOfDay.now();
    for (var entry in jadwal.entries) {
      final parts = entry.value.split(":");
      final prayerTime = TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
      if (prayerTime.hour > now.hour || (prayerTime.hour == now.hour && prayerTime.minute > now.minute)) {
        return entry.key;
      }
    }
    return "Subuh";
  }

  // MODAL CARI LOKASI (SESUAI VIDEO)
  void _showSearchLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF2A2A2A),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) {
        String query = "";
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.7,
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10))),
                  const SizedBox(height: 20),
                  TextField(
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: "Cari Kota/Kabupaten...",
                      hintStyle: const TextStyle(color: Colors.white24),
                      prefixIcon: const Icon(Icons.search, color: Color(0xFF00E5FF)),
                      filled: true,
                      fillColor: const Color(0xFF2A2A2A),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                    ),
                    onChanged: (val) => setModalState(() => query = val),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: FutureBuilder<List<dynamic>>(
                      future: _searchKota(query),
                      builder: (context, snapshot) {
                        if (query.length < 3) return const Center(child: Text("Ketik minimal 3 huruf", style: TextStyle(color: Colors.white24)));
                        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFF00E5FF)));
                        return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            final item = snapshot.data![index];
                            return ListTile(
                              leading: const Icon(Icons.location_on, color: Color(0xFF00E5FF)),
                              title: Text(item['lokasi'], style: const TextStyle(color: Colors.white)),
                              onTap: () {
                                setState(() {
                                  idKota = item['id'];
                                  namaKota = item['lokasi'];
                                });
                                loadJadwal();
                                Navigator.pop(context);
                              },
                            );
                          },
                        );
                      },
                    ),
                  )
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<List<dynamic>> _searchKota(String q) async {
    if (q.length < 3) return [];
    final res = await http.get(Uri.parse("https://api.myquran.com/v2/sholat/kota/cari/$q"));
    return jsonDecode(res.body)['data'] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF00E5FF)));

    return buildJadwalSholat(
      kota: namaKota,
      jadwal: jadwal,
      sholatSelanjutnya: nextSholat,
      onGanti: _showSearchLocation,
    );
  }

  // UI TEMA ABU KEHITAMAN (DARK GREY)
  Widget buildJadwalSholat({
    required String kota,
    required Map<String, String> jadwal,
    required String sholatSelanjutnya,
    required VoidCallback onGanti,
  }) {
    final Map<String, Gradient> gradientSholat = {
      "Subuh": LinearGradient(colors: [Colors.indigo, Colors.indigo.shade700]),
      "Dzuhur": LinearGradient(colors: [Colors.orange, Colors.deepOrange]),
      "Ashar": LinearGradient(colors: [Colors.red, Colors.red.shade700]),
      "Maghrib": LinearGradient(colors: [Colors.purple, Colors.purple.shade700]),
      "Isya": LinearGradient(colors: [Colors.blueGrey, Colors.black87]),
    };

    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E), // Warna Abu Kehitaman (Quick Actions)
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF2A2A2A), Color(0xFF1E1E1E)]),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.mosque, color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Jadwal Sholat Islamic Religion", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Text(kota, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12)),
                    ],
                  ),
                ],
              ),
              GestureDetector(
                onTap: onGanti,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
                  child: const Text("GANTI", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
                ),
              )
            ],
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: jadwal.entries.map((entry) {
                bool isNext = entry.key == sholatSelanjutnya;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: isNext ? 125 : 100,
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
                  decoration: BoxDecoration(
                    gradient: gradientSholat[entry.key],
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: isNext ? [BoxShadow(color: (gradientSholat[entry.key] as LinearGradient).colors.first.withOpacity(0.3), blurRadius: 10)] : [],
                  ),
                  child: Column(
                    children: [
                      if (isNext) const Text("SELANJUTNYA", style: TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.bold)),
                      Text(entry.key.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(entry.value, style: TextStyle(fontSize: isNext ? 22 : 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}