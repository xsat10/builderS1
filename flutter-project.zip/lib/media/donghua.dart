import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';

const kPrimary = Color(0xFFE53935);
const kPrimaryDark = Color(0xFFB71C1C);
const kBg = Color(0xFF0A0A0A);
const kSurface = Color(0xFF141414);
const kCard = Color(0xFF1E1E1E);
const kCardHover = Color(0xFF2A2A2A);
const kWhite = Color(0xFFFFFFFF);
const kWhite70 = Color(0xB3FFFFFF);
const kWhite40 = Color(0x66FFFFFF);
const kAccent = Color(0xFFFF6B6B);

const kBase = 'https://www.sankavollerei.com/anime/donghub';

class AnimeItem {
  final String title;
  final String slug;
  final String poster;
  final String? episode;
  final String? type;
  final String? status;
  final String? sub;
  final String? synopsis;

  AnimeItem({
    required this.title,
    required this.slug,
    required this.poster,
    this.episode,
    this.type,
    this.status,
    this.sub,
    this.synopsis,
  });

  factory AnimeItem.fromJson(Map<String, dynamic> j) {
    String rawTitle = j['title'] ?? '';
    String cleanTitle = rawTitle.split('\t').first.trim();
    return AnimeItem(
      title: cleanTitle,
      slug: j['slug'] ?? '',
      poster: j['poster'] ?? '',
      episode: j['episode']?.toString(),
      type: j['type']?.toString(),
      status: j['status']?.toString(),
      sub: j['sub']?.toString(),
      synopsis: j['synopsis']?.toString(),
    );
  }
}

class SliderItem {
  final String title;
  final String slug;
  final String poster;
  final String synopsis;

  SliderItem({
    required this.title,
    required this.slug,
    required this.poster,
    required this.synopsis,
  });

  factory SliderItem.fromJson(Map<String, dynamic> j) => SliderItem(
        title: j['title'] ?? '',
        slug: j['slug'] ?? '',
        poster: j['poster'] ?? '',
        synopsis: j['synopsis'] ?? '',
      );
}

class AnimeDetail {
  final String title;
  final String poster;
  final String rating;
  final String synopsis;
  final Map<String, dynamic> info;
  final List<Map<String, dynamic>> genres;
  final List<Map<String, dynamic>> episodes;

  AnimeDetail({
    required this.title,
    required this.poster,
    required this.rating,
    required this.synopsis,
    required this.info,
    required this.genres,
    required this.episodes,
  });

  factory AnimeDetail.fromJson(Map<String, dynamic> j) => AnimeDetail(
        title: j['title'] ?? '',
        poster: j['poster'] ?? '',
        rating: j['rating'] ?? '',
        synopsis: j['synopsis'] ?? '',
        info: Map<String, dynamic>.from(j['info'] ?? {}),
        genres: List<Map<String, dynamic>>.from(j['genres'] ?? []),
        episodes: List<Map<String, dynamic>>.from(j['episodes'] ?? []),
      );
}

class EpisodeData {
  final String title;
  final String releaseDate;
  final Map<String, dynamic> navigation;
  final List<Map<String, dynamic>> streams;
  final Map<String, dynamic> animeInfo;
  final List<Map<String, dynamic>> relatedEpisodes;
  final List<Map<String, dynamic>> recommendedSeries;

  EpisodeData({
    required this.title,
    required this.releaseDate,
    required this.navigation,
    required this.streams,
    required this.animeInfo,
    required this.relatedEpisodes,
    required this.recommendedSeries,
  });

  factory EpisodeData.fromJson(Map<String, dynamic> j) => EpisodeData(
        title: j['title'] ?? '',
        releaseDate: j['release_date'] ?? '',
        navigation: Map<String, dynamic>.from(j['navigation'] ?? {}),
        streams: List<Map<String, dynamic>>.from(j['streams'] ?? []),
        animeInfo: Map<String, dynamic>.from(j['anime_info'] ?? {}),
        relatedEpisodes:
            List<Map<String, dynamic>>.from(j['related_episodes'] ?? []),
        recommendedSeries:
            List<Map<String, dynamic>>.from(j['recommended_series'] ?? []),
      );
}

class AnPlayApi {
  static Future<Map<String, dynamic>> _get(String url) async {
    final res = await http.get(Uri.parse(url));
    return jsonDecode(res.body);
  }

  static Future<Map<String, dynamic>> home({int page = 1}) =>
      _get('$kBase/home?page=$page');

  static Future<List<AnimeItem>> latest() async {
    final d = await _get('$kBase/latest');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<List<AnimeItem>> popular() async {
    final d = await _get('$kBase/popular');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<List<AnimeItem>> movie() async {
    final d = await _get('$kBase/movie');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<Map<String, List<AnimeItem>>> schedule() async {
    final d = await _get('$kBase/schedule');
    final raw = d['data'] as Map<String, dynamic>;
    return raw.map((day, list) => MapEntry(
          day,
          (list as List).map((e) => AnimeItem.fromJson(e)).toList(),
        ));
  }

  static Future<List<AnimeItem>> search(String q) async {
    final d = await _get('$kBase/search/${Uri.encodeComponent(q)}');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<List<AnimeItem>> genre(String genre) async {
    final d = await _get('$kBase/genre/$genre');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<List<AnimeItem>> list(
      {String sub = '', String order = ''}) async {
    final d =
        await _get('$kBase/list?sub=$sub&order=$order');
    return (d['data'] as List).map((e) => AnimeItem.fromJson(e)).toList();
  }

  static Future<AnimeDetail> detail(String slug) async {
    final d = await _get('$kBase/detail/$slug');
    return AnimeDetail.fromJson(d['data']);
  }

  static Future<EpisodeData> episode(String slug) async {
    final d = await _get('$kBase/episode/$slug');
    return EpisodeData.fromJson(d['data']);
  }
}

class AnPlayPage extends StatefulWidget {
  const AnPlayPage({super.key});

  @override
  State<AnPlayPage> createState() => _AnPlayPageState();
}

class _AnPlayPageState extends State<AnPlayPage>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  late TabController _tabController;

  final _pages = const [
    _AnPlayHome(),
    _AnPlayLatest(),
    _AnPlayPopular(),
    _AnPlayMovies(),
    _AnPlaySchedule(),
    _AnPlaySearch(),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kBg,
        colorScheme: const ColorScheme.dark(
          primary: kPrimary,
          secondary: kAccent,
          surface: kSurface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kBg,
          elevation: 0,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: kSurface,
          selectedItemColor: kPrimary,
          unselectedItemColor: kWhite40,
          showUnselectedLabels: true,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle:
              TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
          unselectedLabelStyle: TextStyle(fontSize: 10),
        ),
      ),
      child: Scaffold(
        body: IndexedStack(
          index: _selectedIndex,
          children: _pages,
        ),
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: kPrimaryDark, width: 1)),
          ),
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: (i) => setState(() => _selectedIndex = i),
            items: const [
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.house, size: 16),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.clockRotateLeft, size: 16),
                label: 'Terbaru',
              ),
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.fire, size: 16),
                label: 'Populer',
              ),
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.film, size: 16),
                label: 'Movie',
              ),
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.calendarDays, size: 16),
                label: 'Jadwal',
              ),
              BottomNavigationBarItem(
                icon: FaIcon(FontAwesomeIcons.magnifyingGlass, size: 16),
                label: 'Cari',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AnPlayHome extends StatefulWidget {
  const _AnPlayHome();

  @override
  State<_AnPlayHome> createState() => _AnPlayHomeState();
}

class _AnPlayHomeState extends State<_AnPlayHome> {
  Map<String, dynamic>? _data;
  bool _loading = true;
  String? _error;
  final PageController _sliderController = PageController();
  int _currentSlide = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.home();
      setState(() {
        _data = d['data'];
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : CustomScrollView(
                  slivers: [
                    _AnPlaySliverAppBar(),
                    if (_data?['slider'] != null)
                      SliverToBoxAdapter(
                        child: _SliderSection(
                          items: (_data!['slider'] as List)
                              .map((e) => SliderItem.fromJson(e))
                              .toList(),
                        ),
                      ),
                    _SectionHeader(
                        title: 'Populer Sekarang',
                        icon: FontAwesomeIcons.fire),
                    if (_data?['popular'] != null)
                      _HorizontalAnimeList(
                        items: (_data!['popular'] as List)
                            .map((e) => AnimeItem.fromJson(e))
                            .toList(),
                      ),
                    _SectionHeader(
                        title: 'Update Terbaru',
                        icon: FontAwesomeIcons.clockRotateLeft),
                    if (_data?['latest'] != null)
                      _HorizontalAnimeList(
                        items: (_data!['latest'] as List)
                            .map((e) => AnimeItem.fromJson(e))
                            .toList(),
                      ),
                    const SliverPadding(padding: EdgeInsets.only(bottom: 20)),
                  ],
                ),
    );
  }
}

class _AnPlaySliverAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: kBg,
      expandedHeight: 0,
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: kPrimary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const FaIcon(FontAwesomeIcons.play,
                size: 14, color: kWhite),
          ),
          const SizedBox(width: 10),
          RichText(
            text: const TextSpan(
              children: [
                TextSpan(
                  text: 'An',
                  style: TextStyle(
                    color: kWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.5,
                  ),
                ),
                TextSpan(
                  text: 'Play',
                  style: TextStyle(
                    color: kPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.5,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          IconButton(
            icon: const FaIcon(FontAwesomeIcons.list, size: 18, color: kWhite70),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const _AnPlayListPage()),
            ),
          ),
          IconButton(
            icon: const FaIcon(FontAwesomeIcons.bell, size: 18, color: kWhite70),
            onPressed: () {},
          ),
        ],
      ),
    );
  }
}

class _SliderSection extends StatefulWidget {
  final List<SliderItem> items;
  const _SliderSection({required this.items});

  @override
  State<_SliderSection> createState() => _SliderSectionState();
}

class _SliderSectionState extends State<_SliderSection> {
  final PageController _ctrl = PageController();
  int _current = 0;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: Stack(
        children: [
          PageView.builder(
            controller: _ctrl,
            onPageChanged: (i) => setState(() => _current = i),
            itemCount: widget.items.length,
            itemBuilder: (_, i) {
              final item = widget.items[i];
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => _AnPlayDetailPage(slug: item.slug),
                  ),
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      item.poster,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: kCard),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, kBg],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 16,
                      left: 16,
                      right: 80,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            style: const TextStyle(
                              color: kWhite,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            item.synopsis,
                            style: const TextStyle(
                                color: kWhite70, fontSize: 11),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 16,
                      right: 16,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: kPrimary,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const FaIcon(FontAwesomeIcons.play,
                            size: 12, color: kWhite),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          Positioned(
            bottom: 8,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                widget.items.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: _current == i ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: _current == i ? kPrimary : kWhite40,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;

  const _SectionHeader({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
        child: Row(
          children: [
            Container(
              width: 3,
              height: 18,
              decoration: BoxDecoration(
                color: kPrimary,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 10),
            FaIcon(icon, size: 14, color: kPrimary),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                color: kWhite,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HorizontalAnimeList extends StatelessWidget {
  final List<AnimeItem> items;
  const _HorizontalAnimeList({required this.items});

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 195,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          itemCount: items.length,
          itemBuilder: (_, i) => _AnimeCard(item: items[i]),
        ),
      ),
    );
  }
}

class _AnimeCard extends StatelessWidget {
  final AnimeItem item;
  const _AnimeCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => _AnPlayDetailPage(slug: item.slug),
        ),
      ),
      child: Container(
        width: 120,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Stack(
                children: [
                  Image.network(
                    item.poster,
                    width: 120,
                    height: 150,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 120,
                      height: 150,
                      color: kCard,
                      child: const FaIcon(FontAwesomeIcons.image,
                          color: kWhite40),
                    ),
                  ),
                  if (item.episode != null && item.episode!.isNotEmpty)
                    Positioned(
                      bottom: 6,
                      left: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: kPrimary,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'Ep ${item.episode}',
                          style: const TextStyle(
                              color: kWhite,
                              fontSize: 9,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  if (item.sub != null && item.sub!.isNotEmpty)
                    Positioned(
                      top: 6,
                      right: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          item.sub!,
                          style: const TextStyle(
                              color: kAccent,
                              fontSize: 9,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              item.title,
              style: const TextStyle(
                  color: kWhite, fontSize: 11, fontWeight: FontWeight.w600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            if (item.type != null)
              Text(
                item.type!,
                style: const TextStyle(color: kWhite40, fontSize: 10),
              ),
          ],
        ),
      ),
    );
  }
}

class _AnPlayLatest extends StatefulWidget {
  const _AnPlayLatest();

  @override
  State<_AnPlayLatest> createState() => _AnPlayLatestState();
}

class _AnPlayLatestState extends State<_AnPlayLatest> {
  List<AnimeItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.latest();
      setState(() {
        _items = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title: const _AppBarTitle(
            title: 'Terbaru', icon: FontAwesomeIcons.clockRotateLeft),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : _AnimeGridList(items: _items),
    );
  }
}

class _AnPlayPopular extends StatefulWidget {
  const _AnPlayPopular();

  @override
  State<_AnPlayPopular> createState() => _AnPlayPopularState();
}

class _AnPlayPopularState extends State<_AnPlayPopular> {
  List<AnimeItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.popular();
      setState(() {
        _items = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title: const _AppBarTitle(
            title: 'Populer', icon: FontAwesomeIcons.fire),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : _AnimeGridList(items: _items),
    );
  }
}

class _AnPlayMovies extends StatefulWidget {
  const _AnPlayMovies();

  @override
  State<_AnPlayMovies> createState() => _AnPlayMoviesState();
}

class _AnPlayMoviesState extends State<_AnPlayMovies> {
  List<AnimeItem> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.movie();
      setState(() {
        _items = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title:
            const _AppBarTitle(title: 'Movie', icon: FontAwesomeIcons.film),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : _AnimeGridList(items: _items),
    );
  }
}

class _AnPlaySchedule extends StatefulWidget {
  const _AnPlaySchedule();

  @override
  State<_AnPlaySchedule> createState() => _AnPlayScheduleState();
}

class _AnPlayScheduleState extends State<_AnPlaySchedule> {
  Map<String, List<AnimeItem>> _schedule = {};
  bool _loading = true;
  String? _error;
  String _selectedDay = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.schedule();
      setState(() {
        _schedule = d;
        _selectedDay = d.keys.isNotEmpty ? d.keys.first : '';
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title: const _AppBarTitle(
            title: 'Jadwal Tayang', icon: FontAwesomeIcons.calendarDays),
        automaticallyImplyLeading: false,
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : Column(
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      child: Row(
                        children: _schedule.keys.map((day) {
                          final sel = day == _selectedDay;
                          return GestureDetector(
                            onTap: () =>
                                setState(() => _selectedDay = day),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 4),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: sel ? kPrimary : kCard,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: sel ? kPrimary : kWhite40,
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                day,
                                style: TextStyle(
                                  color: sel ? kWhite : kWhite70,
                                  fontWeight: sel
                                      ? FontWeight.w700
                                      : FontWeight.w400,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    Expanded(
                      child: _schedule[_selectedDay]?.isEmpty ?? true
                          ? const Center(
                              child: Text('Tidak ada jadwal',
                                  style: TextStyle(color: kWhite40)))
                          : ListView.builder(
                              padding: const EdgeInsets.all(12),
                              itemCount:
                                  _schedule[_selectedDay]!.length,
                              itemBuilder: (_, i) {
                                final item =
                                    _schedule[_selectedDay]![i];
                                return _ScheduleCard(item: item);
                              },
                            ),
                    ),
                  ],
                ),
    );
  }
}

class _ScheduleCard extends StatelessWidget {
  final AnimeItem item;
  const _ScheduleCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => _AnPlayDetailPage(slug: item.slug),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(12),
          border: const Border(left: BorderSide(color: kPrimary, width: 3)),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.network(
                item.poster,
                width: 60,
                height: 80,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Container(width: 60, height: 80, color: kSurface),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: const TextStyle(
                        color: kWhite,
                        fontWeight: FontWeight.w700,
                        fontSize: 13),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  if (item.episode != null && item.episode!.isNotEmpty)
                    Row(
                      children: [
                        const FaIcon(FontAwesomeIcons.clock,
                            size: 10, color: kPrimary),
                        const SizedBox(width: 4),
                        Text(
                          item.episode!,
                          style: const TextStyle(
                              color: kPrimary, fontSize: 11),
                        ),
                      ],
                    ),
                  if (item.sub != null && item.sub!.isNotEmpty)
                    Text('Ep ${item.sub}',
                        style: const TextStyle(
                            color: kWhite40, fontSize: 11)),
                ],
              ),
            ),
            const FaIcon(FontAwesomeIcons.chevronRight,
                size: 12, color: kWhite40),
          ],
        ),
      ),
    );
  }
}

class _AnPlaySearch extends StatefulWidget {
  const _AnPlaySearch();

  @override
  State<_AnPlaySearch> createState() => _AnPlaySearchState();
}

class _AnPlaySearchState extends State<_AnPlaySearch> {
  final _ctrl = TextEditingController();
  List<AnimeItem> _results = [];
  bool _loading = false;
  bool _searched = false;
  String? _error;

  final List<String> _genres = [
    'action', 'adventure', 'comedy', 'drama', 'fantasy',
    'horror', 'mystery', 'romance', 'sci-fi', 'supernatural',
  ];
  String? _selectedGenre;
  List<AnimeItem> _genreResults = [];
  bool _loadingGenre = false;

  Future<void> _search() async {
    if (_ctrl.text.trim().isEmpty) return;
    setState(() {
      _loading = true;
      _searched = true;
      _error = null;
      _selectedGenre = null;
    });
    try {
      final d = await AnPlayApi.search(_ctrl.text.trim());
      setState(() {
        _results = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _loadGenre(String genre) async {
    setState(() {
      _selectedGenre = genre;
      _loadingGenre = true;
    });
    try {
      final d = await AnPlayApi.genre(genre);
      setState(() {
        _genreResults = d;
        _loadingGenre = false;
      });
    } catch (e) {
      setState(() => _loadingGenre = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        automaticallyImplyLeading: false,
        title: const _AppBarTitle(
            title: 'Cari', icon: FontAwesomeIcons.magnifyingGlass),
      ),
      body: Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: kWhite40.withOpacity(0.2)),
                    ),
                    child: TextField(
                      controller: _ctrl,
                      style: const TextStyle(color: kWhite),
                      decoration: const InputDecoration(
                        hintText: 'Cari donghua...',
                        hintStyle: TextStyle(color: kWhite40),
                        prefixIcon: Padding(
                          padding: EdgeInsets.all(12),
                          child: FaIcon(FontAwesomeIcons.magnifyingGlass,
                              size: 16, color: kWhite40),
                        ),
                        border: InputBorder.none,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 14),
                      ),
                      onSubmitted: (_) => _search(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _search,
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kPrimary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const FaIcon(FontAwesomeIcons.magnifyingGlass,
                        size: 16, color: kWhite),
                  ),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Row(
              children: [
                const Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: FaIcon(FontAwesomeIcons.tag,
                      size: 12, color: kWhite40),
                ),
                ..._genres.map((g) {
                  final sel = g == _selectedGenre;
                  return GestureDetector(
                    onTap: () => _loadGenre(g),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: sel ? kPrimary : kCard,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        g[0].toUpperCase() + g.substring(1),
                        style: TextStyle(
                          color: sel ? kWhite : kWhite70,
                          fontSize: 11,
                          fontWeight: sel
                              ? FontWeight.w700
                              : FontWeight.w400,
                        ),
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _loading || _loadingGenre
                ? const _LoadingWidget()
                : _error != null
                    ? _ErrorWidget(
                        onRetry: _search, message: _error!)
                    : _selectedGenre != null
                        ? _AnimeGridList(items: _genreResults)
                        : !_searched
                            ? const _SearchEmptyState()
                            : _results.isEmpty
                                ? const Center(
                                    child: Text(
                                      'Tidak ada hasil',
                                      style:
                                          TextStyle(color: kWhite40),
                                    ),
                                  )
                                : _AnimeGridList(items: _results),
          ),
        ],
      ),
    );
  }
}

class _SearchEmptyState extends StatelessWidget {
  const _SearchEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: kCard,
              shape: BoxShape.circle,
            ),
            child: const FaIcon(FontAwesomeIcons.film,
                size: 40, color: kPrimary),
          ),
          const SizedBox(height: 16),
          const Text('Cari Donghua Favoritmu',
              style: TextStyle(
                  color: kWhite,
                  fontSize: 16,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Ketik judul atau pilih genre di atas',
              style: TextStyle(color: kWhite40, fontSize: 13)),
        ],
      ),
    );
  }
}

class _AnPlayListPage extends StatefulWidget {
  const _AnPlayListPage();

  @override
  State<_AnPlayListPage> createState() => _AnPlayListPageState();
}

class _AnPlayListPageState extends State<_AnPlayListPage> {
  List<AnimeItem> _items = [];
  bool _loading = true;
  String? _error;
  String _sub = '';
  String _order = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = await AnPlayApi.list(sub: _sub, order: _order);
      setState(() {
        _items = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title: const _AppBarTitle(
            title: 'Daftar Anime', icon: FontAwesomeIcons.list),
        actions: [
          PopupMenuButton<String>(
            icon: const FaIcon(FontAwesomeIcons.sliders,
                size: 16, color: kWhite70),
            color: kCard,
            onSelected: (v) {
              setState(() => _order = v);
              _load();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: '',
                child: Text('Default',
                    style: TextStyle(color: kWhite)),
              ),
              const PopupMenuItem(
                value: 'title',
                child: Text('A-Z', style: TextStyle(color: kWhite)),
              ),
              const PopupMenuItem(
                value: 'update',
                child: Text('Update',
                    style: TextStyle(color: kWhite)),
              ),
            ],
          ),
        ],
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : _AnimeGridList(items: _items),
    );
  }
}

class _AnimeGridList extends StatelessWidget {
  final List<AnimeItem> items;
  const _AnimeGridList({required this.items});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 0.58,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) => _AnimeCard(item: items[i]),
    );
  }
}

class _AnPlayDetailPage extends StatefulWidget {
  final String slug;
  const _AnPlayDetailPage({required this.slug});

  @override
  State<_AnPlayDetailPage> createState() => _AnPlayDetailPageState();
}

class _AnPlayDetailPageState extends State<_AnPlayDetailPage> {
  AnimeDetail? _detail;
  bool _loading = true;
  String? _error;
  bool _showAllEpisodes = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.detail(widget.slug);
      setState(() {
        _detail = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : CustomScrollView(
                  slivers: [
                    SliverAppBar(
                      expandedHeight: 280,
                      pinned: true,
                      backgroundColor: kBg,
                      leading: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          margin: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.arrow_back,
                              color: kWhite),
                        ),
                      ),
                      flexibleSpace: FlexibleSpaceBar(
                        background: Stack(
                          fit: StackFit.expand,
                          children: [
                            Image.network(
                              _detail!.poster,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  Container(color: kCard),
                            ),
                            Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [Colors.transparent, kBg],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _detail!.title,
                              style: const TextStyle(
                                color: kWhite,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: _detail!.genres.map((g) {
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: kPrimary.withOpacity(0.15),
                                    borderRadius:
                                        BorderRadius.circular(12),
                                    border: Border.all(
                                        color: kPrimary, width: 1),
                                  ),
                                  child: Text(
                                    g['name'] ?? '',
                                    style: const TextStyle(
                                        color: kPrimary,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600),
                                  ),
                                );
                              }).toList(),
                            ),
                            const SizedBox(height: 16),
                            _InfoGrid(info: _detail!.info),
                            const SizedBox(height: 16),
                            const Text(
                              'Sinopsis',
                              style: TextStyle(
                                color: kWhite,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _detail!.synopsis,
                              style: const TextStyle(
                                  color: kWhite70,
                                  fontSize: 13,
                                  height: 1.5),
                            ),
                            const SizedBox(height: 20),
                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Episode (${_detail!.episodes.length})',
                                  style: const TextStyle(
                                    color: kWhite,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => setState(() =>
                                      _showAllEpisodes =
                                          !_showAllEpisodes),
                                  child: Text(
                                    _showAllEpisodes
                                        ? 'Sembunyikan'
                                        : 'Lihat Semua',
                                    style: const TextStyle(
                                        color: kPrimary,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            ..._buildEpisodeList(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }

  List<Widget> _buildEpisodeList() {
    final eps = _detail!.episodes;
    final show = _showAllEpisodes ? eps : eps.take(10).toList();
    return show
        .map((ep) => _EpisodeTile(
              episode: ep,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => _AnPlayEpisodePage(
                    slug: ep['slug'] ?? '',
                  ),
                ),
              ),
            ))
        .toList();
  }
}

class _InfoGrid extends StatelessWidget {
  final Map<String, dynamic> info;
  const _InfoGrid({required this.info});

  @override
  Widget build(BuildContext context) {
    final entries = [
      ['Status', info['status']],
      ['Type', info['type']],
      ['Studio', info['studio']],
      ['Network', info['network']],
      ['Episodes', info['episodes']],
      ['Country', info['country']],
      ['Released', info['released']],
    ];
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Wrap(
        spacing: 16,
        runSpacing: 8,
        children: entries
            .where((e) => e[1] != null && e[1].toString().isNotEmpty)
            .map((e) => SizedBox(
                  width: (MediaQuery.of(context).size.width - 64) / 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        e[0] ?? '',
                        style: const TextStyle(
                            color: kWhite40, fontSize: 10),
                      ),
                      Text(
                        e[1]?.toString() ?? '-',
                        style: const TextStyle(
                            color: kWhite,
                            fontSize: 12,
                            fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ))
            .toList(),
      ),
    );
  }
}

class _EpisodeTile extends StatelessWidget {
  final Map<String, dynamic> episode;
  final VoidCallback onTap;

  const _EpisodeTile({required this.episode, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: kPrimary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Text(
                  episode['episode'] ?? '',
                  style: const TextStyle(
                      color: kPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 13),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    episode['title'] ?? '',
                    style: const TextStyle(
                        color: kWhite,
                        fontSize: 12,
                        fontWeight: FontWeight.w500),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    episode['date'] ?? '',
                    style:
                        const TextStyle(color: kWhite40, fontSize: 10),
                  ),
                ],
              ),
            ),
            const FaIcon(FontAwesomeIcons.play,
                size: 12, color: kWhite40),
          ],
        ),
      ),
    );
  }
}

class _AnPlayEpisodePage extends StatefulWidget {
  final String slug;
  const _AnPlayEpisodePage({required this.slug});

  @override
  State<_AnPlayEpisodePage> createState() => _AnPlayEpisodePageState();
}

class _AnPlayEpisodePageState extends State<_AnPlayEpisodePage> {
  EpisodeData? _data;
  bool _loading = true;
  String? _error;
  int _selectedServer = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await AnPlayApi.episode(widget.slug);
      setState(() {
        _data = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        title: Text(
          _data?.title ?? 'Streaming',
          style: const TextStyle(
              color: kWhite,
              fontSize: 14,
              fontWeight: FontWeight.w700),
          overflow: TextOverflow.ellipsis,
        ),
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: const Icon(Icons.arrow_back, color: kWhite),
        ),
      ),
      body: _loading
          ? const _LoadingWidget()
          : _error != null
              ? _ErrorWidget(onRetry: _load, message: _error!)
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_data!.streams.isNotEmpty)
                        _VideoPlayerSection(
                          streams: _data!.streams,
                          selectedIndex: _selectedServer,
                          onServerChanged: (i) =>
                              setState(() => _selectedServer = i),
                        ),
                      _EpisodeNavigation(navigation: _data!.navigation),
                      _AnimeInfoCard(info: _data!.animeInfo),
                      if (_data!.relatedEpisodes.isNotEmpty)
                        _RelatedEpisodes(
                          episodes: _data!.relatedEpisodes,
                        ),
                      if (_data!.recommendedSeries.isNotEmpty)
                        _RecommendedSection(
                          series: _data!.recommendedSeries,
                        ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
    );
  }
}

class _VideoPlayerSection extends StatelessWidget {
  final List<Map<String, dynamic>> streams;
  final int selectedIndex;
  final Function(int) onServerChanged;

  const _VideoPlayerSection({
    required this.streams,
    required this.selectedIndex,
    required this.onServerChanged,
  });

  @override
  Widget build(BuildContext context) {
    final stream = streams[selectedIndex];
    final url = stream['url'] ?? '';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 220,
          child: WebViewWidget(
            controller: WebViewController()
              ..setJavaScriptMode(JavaScriptMode.unrestricted)
              ..loadRequest(Uri.parse(url)),
          ),
        ),
        Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const FaIcon(FontAwesomeIcons.server,
                      size: 12, color: kPrimary),
                  const SizedBox(width: 6),
                  const Text('Pilih Server',
                      style: TextStyle(
                          color: kWhite,
                          fontWeight: FontWeight.w700,
                          fontSize: 13)),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: List.generate(streams.length, (i) {
                  final sel = i == selectedIndex;
                  return GestureDetector(
                    onTap: () => onServerChanged(i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: sel ? kPrimary : kCard,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: sel ? kPrimary : kWhite40,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FaIcon(
                            sel
                                ? FontAwesomeIcons.circlePlay
                                : FontAwesomeIcons.server,
                            size: 12,
                            color: sel ? kWhite : kWhite70,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            streams[i]['server'] ?? 'Server ${i + 1}',
                            style: TextStyle(
                              color: sel ? kWhite : kWhite70,
                              fontSize: 12,
                              fontWeight: sel
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _EpisodeNavigation extends StatelessWidget {
  final Map<String, dynamic> navigation;
  const _EpisodeNavigation({required this.navigation});

  @override
  Widget build(BuildContext context) {
    final prev = navigation['prev_slug'];
    final next = navigation['next_slug'];
    final all = navigation['all_slug'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: _NavBtn(
              label: 'Sebelumnya',
              icon: FontAwesomeIcons.chevronLeft,
              enabled: prev != null,
              onTap: prev != null
                  ? () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              _AnPlayEpisodePage(slug: prev),
                        ),
                      )
                  : null,
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: all != null
                ? () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            _AnPlayDetailPage(slug: all),
                      ),
                    )
                : null,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const FaIcon(FontAwesomeIcons.list,
                  size: 14, color: kWhite70),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _NavBtn(
              label: 'Selanjutnya',
              icon: FontAwesomeIcons.chevronRight,
              iconRight: true,
              enabled: next != null,
              onTap: next != null
                  ? () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              _AnPlayEpisodePage(slug: next),
                        ),
                      )
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}

class _NavBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool iconRight;
  final bool enabled;
  final VoidCallback? onTap;

  const _NavBtn({
    required this.label,
    required this.icon,
    this.iconRight = false,
    required this.enabled,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: enabled ? kPrimary : kCard,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!iconRight) ...[
              FaIcon(icon,
                  size: 12,
                  color: enabled ? kWhite : kWhite40),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                color: enabled ? kWhite : kWhite40,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            if (iconRight) ...[
              const SizedBox(width: 6),
              FaIcon(icon,
                  size: 12,
                  color: enabled ? kWhite : kWhite40),
            ],
          ],
        ),
      ),
    );
  }
}

class _AnimeInfoCard extends StatelessWidget {
  final Map<String, dynamic> info;
  const _AnimeInfoCard({required this.info});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              info['thumbnail'] ?? '',
              width: 80,
              height: 110,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(width: 80, height: 110, color: kSurface),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  info['title'] ?? '',
                  style: const TextStyle(
                      color: kWhite,
                      fontWeight: FontWeight.w700,
                      fontSize: 14),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                _InfoRow(FontAwesomeIcons.circleCheck,
                    info['status'] ?? ''),
                _InfoRow(FontAwesomeIcons.film, info['type'] ?? ''),
                _InfoRow(
                    FontAwesomeIcons.layerGroup, info['episodes'] ?? ''),
                _InfoRow(FontAwesomeIcons.earthAsia,
                    info['country'] ?? ''),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 4,
                  runSpacing: 4,
                  children: (info['genres'] as List? ?? [])
                      .take(3)
                      .map((g) => Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: kPrimary.withOpacity(0.15),
                              borderRadius:
                                  BorderRadius.circular(10),
                            ),
                            child: Text(
                              g['name'] ?? '',
                              style: const TextStyle(
                                  color: kPrimary, fontSize: 10),
                            ),
                          ))
                      .toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoRow(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    if (text.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: Row(
        children: [
          FaIcon(icon, size: 10, color: kPrimary),
          const SizedBox(width: 6),
          Expanded(
            child: Text(text,
                style:
                    const TextStyle(color: kWhite70, fontSize: 11),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }
}

class _RelatedEpisodes extends StatelessWidget {
  final List<Map<String, dynamic>> episodes;
  const _RelatedEpisodes({required this.episodes});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Row(
            children: const [
              FaIcon(FontAwesomeIcons.clockRotateLeft,
                  size: 12, color: kPrimary),
              SizedBox(width: 8),
              Text('Episode Terkait',
                  style: TextStyle(
                      color: kWhite,
                      fontWeight: FontWeight.w700,
                      fontSize: 14)),
            ],
          ),
        ),
        ...episodes.map((ep) => _RelatedEpTile(episode: ep)),
      ],
    );
  }
}

class _RelatedEpTile extends StatelessWidget {
  final Map<String, dynamic> episode;
  const _RelatedEpTile({required this.episode});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              _AnPlayEpisodePage(slug: episode['slug'] ?? ''),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.network(
                episode['thumbnail'] ?? '',
                width: 60,
                height: 40,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Container(width: 60, height: 40, color: kSurface),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(episode['title'] ?? '',
                      style: const TextStyle(
                          color: kWhite, fontSize: 12),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Text(episode['posted_date'] ?? '',
                      style: const TextStyle(
                          color: kWhite40, fontSize: 10)),
                ],
              ),
            ),
            const FaIcon(FontAwesomeIcons.play,
                size: 12, color: kWhite40),
          ],
        ),
      ),
    );
  }
}

class _RecommendedSection extends StatelessWidget {
  final List<Map<String, dynamic>> series;
  const _RecommendedSection({required this.series});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
          child: Row(
            children: const [
              FaIcon(FontAwesomeIcons.star, size: 12, color: kPrimary),
              SizedBox(width: 8),
              Text('Rekomendasi',
                  style: TextStyle(
                      color: kWhite,
                      fontWeight: FontWeight.w700,
                      fontSize: 14)),
            ],
          ),
        ),
        SizedBox(
          height: 170,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: series.length,
            itemBuilder: (_, i) {
              final s = series[i];
              final slug = s['slug'] ?? '';
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => _AnPlayDetailPage(slug: slug),
                  ),
                ),
                child: Container(
                  width: 110,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          s['thumbnail'] ?? '',
                          width: 110,
                          height: 130,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            width: 110,
                            height: 130,
                            color: kCard,
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        s['title'] ?? '',
                        style: const TextStyle(
                            color: kWhite, fontSize: 10),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _LoadingWidget extends StatelessWidget {
  const _LoadingWidget();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: kPrimary, strokeWidth: 2),
          SizedBox(height: 12),
          Text('Memuat...', style: TextStyle(color: kWhite40, fontSize: 13)),
        ],
      ),
    );
  }
}

class _ErrorWidget extends StatelessWidget {
  final VoidCallback onRetry;
  final String message;

  const _ErrorWidget({required this.onRetry, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const FaIcon(FontAwesomeIcons.circleExclamation,
                size: 48, color: kPrimary),
            const SizedBox(height: 16),
            const Text('Gagal Memuat Data',
                style: TextStyle(
                    color: kWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(message,
                style:
                    const TextStyle(color: kWhite40, fontSize: 11),
                textAlign: TextAlign.center,
                maxLines: 3),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: onRetry,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  color: kPrimary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FaIcon(FontAwesomeIcons.rotateRight,
                        size: 14, color: kWhite),
                    SizedBox(width: 8),
                    Text('Coba Lagi',
                        style: TextStyle(
                            color: kWhite,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AppBarTitle extends StatelessWidget {
  final String title;
  final IconData icon;

  const _AppBarTitle({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        FaIcon(icon, size: 16, color: kPrimary),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
              color: kWhite, fontWeight: FontWeight.w800, fontSize: 18),
        ),
      ],
    );
  }
}

extension _FaExt on FontAwesomeIcons {
  static const IconData dragonIcon = FontAwesomeIcons.film;
}