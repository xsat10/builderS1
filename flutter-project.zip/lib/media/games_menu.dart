import 'dart:math';
import 'package:flutter/material.dart';

// ==================== 1. PUZZLE GAME (SLIDING PUZZLE 3x3) ====================
class PuzzleGame extends StatefulWidget {
  const PuzzleGame({super.key});

  @override
  State<PuzzleGame> createState() => _PuzzleGameState();
}

class _PuzzleGameState extends State<PuzzleGame> {
  late List<int> tiles;
  int emptyIndex = 8;
  bool solved = false;

  @override
  void initState() {
    super.initState();
    _shuffle();
  }

  void _shuffle() {
    tiles = List.generate(9, (i) => i);
    emptyIndex = 8;
    final random = Random();
    for (int i = 0; i < 200; i++) {
      final possibleMoves = _getPossibleMoves(emptyIndex);
      if (possibleMoves.isNotEmpty) {
        final move = possibleMoves[random.nextInt(possibleMoves.length)];
        _swap(emptyIndex, move);
        emptyIndex = move;
      }
    }
    solved = false;
  }

  List<int> _getPossibleMoves(int index) {
    final moves = <int>[];
    if (index ~/ 3 > 0) moves.add(index - 3);
    if (index ~/ 3 < 2) moves.add(index + 3);
    if (index % 3 > 0) moves.add(index - 1);
    if (index % 3 < 2) moves.add(index + 1);
    return moves;
  }

  void _swap(int i, int j) {
    final temp = tiles[i];
    tiles[i] = tiles[j];
    tiles[j] = temp;
  }

  void _onTileTap(int index) {
    if (solved) return;
    final moves = _getPossibleMoves(emptyIndex);
    if (moves.contains(index)) {
      setState(() {
        _swap(emptyIndex, index);
        emptyIndex = index;
        _checkWin();
      });
    }
  }

  void _checkWin() {
    bool win = true;
    for (int i = 0; i < 8; i++) {
      if (tiles[i] != i) {
        win = false;
        break;
      }
    }
    if (win) {
      solved = true;
      _showWinDialog();
    }
  }

  void _showWinDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 Selamat!'),
        content: const Text('Anda berhasil menyelesaikan puzzle!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _shuffle();
              setState(() {});
            },
            child: const Text('Main Lagi'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Puzzle Game'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Susun gambar menjadi urutan 1-8 (kosong di kanan bawah)', style: TextStyle(color: Colors.white70)),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 1),
              itemCount: 9,
              itemBuilder: (ctx, i) {
                final value = tiles[i];
                if (value == 8) {
                  return Container(margin: const EdgeInsets.all(4), color: Colors.transparent);
                }
                return GestureDetector(
                  onTap: () => _onTileTap(i),
                  child: Container(
                    margin: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.red[900],
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 4)],
                    ),
                    child: Center(
                      child: Text(
                        (value + 1).toString(),
                        style: const TextStyle(fontSize: 32, color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: ElevatedButton(
              onPressed: () {
                _shuffle();
                setState(() {});
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Acak Ulang', style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== 2. TEKA TEKI (KUIS) ====================
class TekaTekiGame extends StatefulWidget {
  const TekaTekiGame({super.key});

  @override
  State<TekaTekiGame> createState() => _TekaTekiGameState();
}

class _TekaTekiGameState extends State<TekaTekiGame> {
  int currentIndex = 0;
  int score = 0;
  bool showResult = false;

  final List<Map<String, dynamic>> questions = [
    {'question': 'Hewan apa yang bisa terbang dan suka makan pisang?', 'answer': 'kelelawar', 'options': ['Burung', 'Kelelawar', 'Kupu-kupu', 'Elang']},
    {'question': 'Apa nama ibu kota Indonesia?', 'answer': 'jakarta', 'options': ['Surabaya', 'Bandung', 'Jakarta', 'Medan']},
    {'question': 'Siapa penemu lampu pijar?', 'answer': 'thomas edison', 'options': ['Nikola Tesla', 'Albert Einstein', 'Thomas Edison', 'Alexander Graham Bell']},
    {'question': 'Planet terdekat dengan matahari adalah?', 'answer': 'merkurus', 'options': ['Venus', 'Bumi', 'Mars', 'Merkurus']},
    {'question': 'Apa bahasa pemrograman yang digunakan untuk Flutter?', 'answer': 'dart', 'options': ['Java', 'Kotlin', 'Dart', 'Swift']},
  ];

  void checkAnswer(String selected) {
    if (selected.toLowerCase() == questions[currentIndex]['answer']) {
      score++;
    }
    if (currentIndex + 1 < questions.length) {
      setState(() {
        currentIndex++;
      });
    } else {
      setState(() {
        showResult = true;
      });
    }
  }

  void reset() {
    setState(() {
      currentIndex = 0;
      score = 0;
      showResult = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Teka Teki'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: showResult
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Skor Anda: $score/${questions.length}', style: const TextStyle(color: Colors.white, fontSize: 28)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: reset,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('Main Lagi', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('Soal ${currentIndex + 1}/${questions.length}', style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 20),
                  Text(questions[currentIndex]['question'], style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 30),
                  ...(questions[currentIndex]['options'] as List<String>).map((opt) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => checkAnswer(opt),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red[800]),
                            child: Text(opt, style: const TextStyle(color: Colors.white)),
                          ),
                        ),
                      )),
                ],
              ),
            ),
    );
  }
}

// ==================== 3. TES IQ (SOAL PILIHAN GANDA) ====================
class IQTestGame extends StatefulWidget {
  const IQTestGame({super.key});

  @override
  State<IQTestGame> createState() => _IQTestGameState();
}

class _IQTestGameState extends State<IQTestGame> {
  int current = 0;
  int score = 0;
  bool done = false;

  final List<Map<String, dynamic>> soal = [
    {'soal': 'Jika 1 = 3, 2 = 3, 3 = 5, 4 = 4, 5 = 4, maka 6 = ?', 'jawaban': '3', 'opsi': ['2', '3', '4', '5']},
    {'soal': 'Manakah yang bukan hewan?', 'jawaban': 'Mobil', 'opsi': ['Kucing', 'Anjing', 'Mobil', 'Burung']},
    {'soal': 'Lanjutkan deret: 2, 4, 6, 8, ?', 'jawaban': '10', 'opsi': ['9', '10', '12', '14']},
    {'soal': 'Jika hari ini Selasa, 3 hari lagi hari?', 'jawaban': 'Jumat', 'opsi': ['Rabu', 'Kamis', 'Jumat', 'Sabtu']},
    {'soal': 'Apa lawan kata dari "terang"?', 'jawaban': 'gelap', 'opsi': ['Gelap', 'Redup', 'Pudar', 'Suram']},
  ];

  void jawab(String pilih) {
    if (pilih == soal[current]['jawaban']) score++;
    if (current + 1 < soal.length) {
      setState(() => current++);
    } else {
      setState(() => done = true);
    }
  }

  void reset() {
    setState(() {
      current = 0;
      score = 0;
      done = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tes IQ'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: done
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Skor IQ Anda: ${(score / soal.length * 100).toInt()}', style: const TextStyle(color: Colors.white, fontSize: 28)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: reset,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('Ulangi Tes', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('Soal ${current + 1}/${soal.length}', style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 20),
                  Text(soal[current]['soal'], style: const TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 30),
                  ...(soal[current]['opsi'] as List<String>).map((o) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => jawab(o),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red[800]),
                            child: Text(o, style: const TextStyle(color: Colors.white)),
                          ),
                        ),
                      )),
                ],
              ),
            ),
    );
  }
}

// ==================== 4. ULAR TANGGA (VERSI SULIT) ====================
class UlarTanggaGame extends StatefulWidget {
  const UlarTanggaGame({super.key});

  @override
  State<UlarTanggaGame> createState() => _UlarTanggaGameState();
}

class _UlarTanggaGameState extends State<UlarTanggaGame> {
  int playerPosition = 1;
  bool isRolling = false;
  final Random random = Random();

  // Papan 100 kotak dengan lebih banyak ular dan tangga
  final Map<int, int> snakesLadders = {
    3: 22,   // tangga
    5: 8,    // tangga
    11: 26,  // tangga
    20: 29,  // tangga
    27: 74,  // tangga
    35: 55,  // tangga
    50: 66,  // tangga
    71: 92,  // tangga
    88: 99,  // tangga
    16: 6,   // ular
    46: 25,  // ular
    49: 11,  // ular
    62: 19,  // ular
    64: 60,  // ular
    74: 53,  // ular
    89: 68,  // ular
    92: 73,  // ular
    95: 75,  // ular
    98: 78,  // ular
  };

  void rollDice() async {
    if (isRolling) return;
    setState(() => isRolling = true);
    await Future.delayed(const Duration(milliseconds: 300));
    final dice = random.nextInt(6) + 1;
    int newPos = playerPosition + dice;
    if (newPos > 100) newPos = playerPosition;
    setState(() => playerPosition = newPos);
    if (snakesLadders.containsKey(playerPosition)) {
      await Future.delayed(const Duration(milliseconds: 500));
      setState(() => playerPosition = snakesLadders[playerPosition]!);
    }
    if (playerPosition == 100) {
      _showWinDialog();
    }
    setState(() => isRolling = false);
  }

  void _showWinDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 Menang!'),
        content: const Text('Selamat Anda mencapai finish!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => playerPosition = 1);
            },
            child: const Text('Main Lagi'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ular Tangga (Sulit)'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: Column(
        children: [
          const SizedBox(height: 20),
          Text('Posisi: $playerPosition', style: const TextStyle(color: Colors.white, fontSize: 24)),
          const SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 10, childAspectRatio: 1),
              itemCount: 100,
              itemBuilder: (ctx, i) {
                int nomor = i + 1;
                bool isPlayer = playerPosition == nomor;
                return Container(
                  margin: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white24),
                    color: snakesLadders.containsKey(nomor) ? Colors.yellow[800] : (isPlayer ? Colors.red : Colors.grey[900]),
                  ),
                  child: Center(
                    child: Text(
                      nomor.toString(),
                      style: const TextStyle(color: Colors.white70, fontSize: 10),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: ElevatedButton(
              onPressed: isRolling ? null : rollDice,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15)),
              child: Text(isRolling ? 'Melempar...' : 'Lempar Dadu', style: const TextStyle(color: Colors.white, fontSize: 18)),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== 5. MEMECAHKAN MISTERI (DETEKTIF) ====================
class MysteryGame extends StatefulWidget {
  const MysteryGame({super.key});

  @override
  State<MysteryGame> createState() => _MysteryGameState();
}

class _MysteryGameState extends State<MysteryGame> {
  int step = 0;
  String message = 'Seorang detektif menerima laporan pencurian di museum. Kamu diminta menyelidiki.';
  final List<Map<String, dynamic>> steps = [
    {'text': 'Di tempat kejadian, kamu menemukan selembar kertas bertuliskan "R. 12". Apa yang akan kamu lakukan?', 'options': ['Cari ruang 12', 'Tanyakan saksi', 'Periksa CCTV'], 'next': [1, 2, 3]},
    {'text': 'Kamu pergi ke ruang 12 dan menemukan jejak kaki. Jejak itu mengarah ke pintu belakang. Lanjutkan?', 'options': ['Ikuti jejak', 'Kembali ke TKP'], 'next': [4, 0]},
    {'text': 'Saksi mengatakan melihat orang bertopeng. Deskripsi: tinggi, jaket hitam. Apa langkahmu?', 'options': ['Cari orang berjaket hitam', 'Cek CCTV lagi'], 'next': [4, 5]},
    {'text': 'CCTV menunjukkan pelaku keluar pukul 02.00. Kamu menemukan mobil hitam di parkiran. Periksa mobil?', 'options': ['Periksa', 'Tunggu'], 'next': [6, 0]},
    {'text': 'Jejak membawamu ke taman. Ada tas berisi barang curian. Kasus terpecahkan!', 'options': ['Selesai'], 'next': [-1]},
    {'text': 'CCTV menunjukkan pelaku menggunakan topeng serigala. Kamu menemukan topeng di tempat sampah. Kasus terpecahkan!', 'options': ['Selesai'], 'next': [-1]},
    {'text': 'Di dalam mobil, kamu menemukan KTP pelaku. Polisi menangkapnya. Misi berhasil!', 'options': ['Selesai'], 'next': [-1]},
  ];

  void choose(int nextIndex) {
    if (nextIndex == -1) {
      _showWin();
    } else {
      setState(() {
        step = nextIndex;
        message = steps[step]['text'];
      });
    }
  }

  void _showWin() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('🕵️‍♂️ Kasus Terpecahkan!'),
        content: const Text('Selamat, Anda berhasil memecahkan misteri!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentStep = steps[step];
    return Scaffold(
      appBar: AppBar(title: const Text('Memecahkan Misteri'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.psychology, size: 60, color: Colors.white70),
            const SizedBox(height: 20),
            Text(message, style: const TextStyle(color: Colors.white, fontSize: 18)),
            const SizedBox(height: 40),
            ...List.generate(currentStep['options'].length, (i) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => choose(currentStep['next'][i]),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red[800]),
                  child: Text(currentStep['options'][i], style: const TextStyle(color: Colors.white)),
                ),
              ),
            )),
          ],
        ),
      ),
    );
  }
}

// ==================== 6. GAME CATUR (dengan 3 level) ====================
class ChessGame extends StatefulWidget {
  const ChessGame({super.key});

  @override
  State<ChessGame> createState() => _ChessGameState();
}

class _ChessGameState extends State<ChessGame> {
  String _difficulty = 'Easy'; // Easy, Hard, Master
  List<List<String?>> board = List.generate(8, (_) => List.filled(8, null));
  bool _isPlayerTurn = true;
  bool _gameOver = false;
  String _message = '';
  int? _selectedRow, _selectedCol;
  final Random _random = Random();

  // Initial board setup (simplified: only pawns and royals for demo)
  // But for a real game, we need full pieces. I'll implement a complete set.
  // To keep it reasonable, I'll implement all pieces but with simple move validation.
  // Let's define piece representation: 'K' king, 'Q' queen, 'R' rook, 'B' bishop, 'N' knight, 'P' pawn
  // Lowercase for black, uppercase for white.

  @override
  void initState() {
    super.initState();
    _initBoard();
  }

  void _initBoard() {
    // Clear board
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        board[i][j] = null;
      }
    }
    // Pawns
    for (int i = 0; i < 8; i++) {
      board[1][i] = 'p'; // black pawns
      board[6][i] = 'P'; // white pawns
    }
    // Major pieces (black)
    board[0][0] = 'r'; board[0][7] = 'r';
    board[0][1] = 'n'; board[0][6] = 'n';
    board[0][2] = 'b'; board[0][5] = 'b';
    board[0][3] = 'q'; board[0][4] = 'k';
    // White
    board[7][0] = 'R'; board[7][7] = 'R';
    board[7][1] = 'N'; board[7][6] = 'N';
    board[7][2] = 'B'; board[7][5] = 'B';
    board[7][3] = 'Q'; board[7][4] = 'K';
    _isPlayerTurn = true;
    _gameOver = false;
    _message = 'Pilih bidak putih';
    _selectedRow = null;
    _selectedCol = null;
  }

  bool _isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
    String? piece = board[fromRow][fromCol];
    if (piece == null) return false;
    bool isWhite = piece.toUpperCase() == piece;
    String type = piece.toLowerCase();
    int deltaRow = toRow - fromRow;
    int deltaCol = toCol - fromCol;
    int absDeltaRow = deltaRow.abs();
    int absDeltaCol = deltaCol.abs();

    // Target square must be empty or contain opponent piece
    String? target = board[toRow][toCol];
    if (target != null) {
      bool targetIsWhite = target.toUpperCase() == target;
      if (targetIsWhite == isWhite) return false; // can't capture own piece
    }

    switch (type) {
      case 'p': // pawn
        int direction = isWhite ? -1 : 1;
        if (deltaCol == 0 && target == null) {
          if (deltaRow == direction) return true;
          if ((fromRow == (isWhite ? 6 : 1)) && deltaRow == 2 * direction && board[fromRow + direction][fromCol] == null) return true;
        } else if (absDeltaCol == 1 && deltaRow == direction && target != null) return true;
        return false;
      case 'n': // knight
        return (absDeltaRow == 2 && absDeltaCol == 1) || (absDeltaRow == 1 && absDeltaCol == 2);
      case 'b': // bishop
        if (absDeltaRow != absDeltaCol) return false;
        int stepRow = deltaRow.sign, stepCol = deltaCol.sign;
        for (int i = 1; i < absDeltaRow; i++) {
          if (board[fromRow + i * stepRow][fromCol + i * stepCol] != null) return false;
        }
        return true;
      case 'r': // rook
        if (fromRow != toRow && fromCol != toCol) return false;
        if (fromRow == toRow) {
          int step = deltaCol.sign;
          for (int i = step; i != deltaCol; i += step) {
            if (board[fromRow][fromCol + i] != null) return false;
          }
        } else {
          int step = deltaRow.sign;
          for (int i = step; i != deltaRow; i += step) {
            if (board[fromRow + i][fromCol] != null) return false;
          }
        }
        return true;
      case 'q': // queen
        bool diagonal = absDeltaRow == absDeltaCol;
        bool straight = fromRow == toRow || fromCol == toCol;
        if (!diagonal && !straight) return false;
        int stepRow = deltaRow.sign, stepCol = deltaCol.sign;
        if (straight) stepCol = deltaCol == 0 ? 0 : deltaCol.sign;
        if (diagonal) stepCol = deltaCol.sign;
        int steps = diagonal ? absDeltaRow : (fromRow == toRow ? absDeltaCol : absDeltaRow);
        for (int i = 1; i < steps; i++) {
          if (board[fromRow + i * stepRow][fromCol + i * stepCol] != null) return false;
        }
        return true;
      case 'k': // king
        return absDeltaRow <= 1 && absDeltaCol <= 1;
      default:
        return false;
    }
  }

  bool _isCheck(bool isWhite) {
    // Find king position
    int kingRow = -1, kingCol = -1;
    String kingChar = isWhite ? 'K' : 'k';
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        if (board[i][j] == kingChar) {
          kingRow = i; kingCol = j; break;
        }
      }
    }
    if (kingRow == -1) return false;
    // Check if any opponent piece can capture king
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        String? piece = board[i][j];
        if (piece != null && (piece.toUpperCase() == piece) != isWhite) {
          if (_isValidMove(i, j, kingRow, kingCol)) return true;
        }
      }
    }
    return false;
  }

  bool _hasLegalMoves(bool isWhite) {
    for (int i = 0; i < 8; i++) {
      for (int j = 0; j < 8; j++) {
        String? piece = board[i][j];
        if (piece != null && (piece.toUpperCase() == piece) == isWhite) {
          for (int ti = 0; ti < 8; ti++) {
            for (int tj = 0; tj < 8; tj++) {
              if (_isValidMove(i, j, ti, tj)) {
                // Simulate move
                String? captured = board[ti][tj];
                board[ti][tj] = board[i][j];
                board[i][j] = null;
                bool stillInCheck = _isCheck(isWhite);
                // Undo
                board[i][j] = board[ti][tj];
                board[ti][tj] = captured;
                if (!stillInCheck) return true;
              }
            }
          }
        }
      }
    }
    return false;
  }

  void _makeMove(int fromRow, int fromCol, int toRow, int toCol) {
    String? piece = board[fromRow][fromCol];
    if (piece == null) return;
    bool isWhite = piece.toUpperCase() == piece;
    if ((isWhite && !_isPlayerTurn) || (!isWhite && _isPlayerTurn)) return;
    if (!_isValidMove(fromRow, fromCol, toRow, toCol)) return;

    // Simulate move to check if it leaves own king in check
    String? captured = board[toRow][toCol];
    board[toRow][toCol] = board[fromRow][fromCol];
    board[fromRow][fromCol] = null;
    if (_isCheck(isWhite)) {
      // Undo
      board[fromRow][fromCol] = board[toRow][toCol];
      board[toRow][toCol] = captured;
      setState(() {
        _message = 'Langkah tidak valid (raja dalam bahaya)';
      });
      return;
    }
    setState(() {
      _selectedRow = null;
      _selectedCol = null;
    });
    // Check for promotion
    if ((piece == 'P' && toRow == 0) || (piece == 'p' && toRow == 7)) {
      _promotePawn(toRow, toCol, isWhite);
    }
    // Check for checkmate/stalemate
    _isPlayerTurn = !_isPlayerTurn;
    if (!_hasLegalMoves(!isWhite)) {
      if (_isCheck(!isWhite)) {
        _gameOver = true;
        _message = isWhite ? 'Putih menang!' : 'Hitam menang!';
      } else {
        _gameOver = true;
        _message = 'Stalemate! Seri.';
      }
    } else {
      _message = isWhite ? 'Giliran hitam' : 'Giliran putih';
      if (!_isPlayerTurn && !_gameOver) {
        _aiMove();
      }
    }
  }

  void _promotePawn(int row, int col, bool isWhite) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Promosi Pion'),
        content: const Text('Pilih bidak:'),
        actions: [
          TextButton(onPressed: () => _setPromotion(row, col, isWhite ? 'Q' : 'q'), child: const Text('Menteri')),
          TextButton(onPressed: () => _setPromotion(row, col, isWhite ? 'R' : 'r'), child: const Text('Benteng')),
          TextButton(onPressed: () => _setPromotion(row, col, isWhite ? 'B' : 'b'), child: const Text('Gajah')),
          TextButton(onPressed: () => _setPromotion(row, col, isWhite ? 'N' : 'n'), child: const Text('Kuda')),
        ],
      ),
    );
  }

  void _setPromotion(int row, int col, String piece) {
    setState(() {
      board[row][col] = piece;
    });
    Navigator.pop(context);
  }

  void _aiMove() {
    if (_gameOver) return;
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_gameOver || _isPlayerTurn) return;
      List<Map<String, int>> moves = [];
      for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
          String? piece = board[i][j];
          if (piece != null && (piece.toUpperCase() != piece)) { // black pieces
            for (int ti = 0; ti < 8; ti++) {
              for (int tj = 0; tj < 8; tj++) {
                if (_isValidMove(i, j, ti, tj)) {
                  // Simulate to check if it leaves king in check
                  String? captured = board[ti][tj];
                  board[ti][tj] = board[i][j];
                  board[i][j] = null;
                  bool safe = !_isCheck(false);
                  board[i][j] = board[ti][tj];
                  board[ti][tj] = captured;
                  if (safe) moves.add({'fromRow': i, 'fromCol': j, 'toRow': ti, 'toCol': tj});
                }
              }
            }
          }
        }
      }
      if (moves.isEmpty) {
        if (_isCheck(false)) {
          _gameOver = true;
          setState(() => _message = 'Putih menang!');
        } else {
          _gameOver = true;
          setState(() => _message = 'Stalemate!');
        }
        return;
      }
      Map<String, int>? selected;
      if (_difficulty == 'Easy') {
        selected = moves[_random.nextInt(moves.length)];
      } else if (_difficulty == 'Hard') {
        // Prioritize capturing pieces
        List<Map<String, int>> captures = [];
        for (var m in moves) {
          String? target = board[m['toRow']!][m['toCol']!];
          if (target != null) captures.add(m);
        }
        selected = captures.isNotEmpty ? captures[_random.nextInt(captures.length)] : moves[_random.nextInt(moves.length)];
      } else { // Master
        // Simple evaluation: capture highest value piece
        Map<String, int> pieceValue = {'q': 9, 'r': 5, 'b': 3, 'n': 3, 'p': 1, 'k': 100};
        int bestScore = -1;
        for (var m in moves) {
          String? target = board[m['toRow']!][m['toCol']!];
          int score = 0;
          if (target != null) {
            String type = target.toLowerCase();
            score = pieceValue[type] ?? 0;
          }
          if (score > bestScore) {
            bestScore = score;
            selected = m;
          }
        }
        if (selected == null) selected = moves[_random.nextInt(moves.length)];
      }
      if (selected != null) {
        _makeMove(selected['fromRow']!, selected['fromCol']!, selected['toRow']!, selected['toCol']!);
      }
    });
  }

  void _onSquareTap(int row, int col) {
    if (_gameOver) return;
    if (_selectedRow == null) {
      String? piece = board[row][col];
      if (piece != null && (piece.toUpperCase() == piece) == _isPlayerTurn) {
        setState(() {
          _selectedRow = row;
          _selectedCol = col;
        });
      }
    } else {
      _makeMove(_selectedRow!, _selectedCol!, row, col);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Catur'),
        backgroundColor: Colors.red[900],
        actions: [
          DropdownButton<String>(
            value: _difficulty,
            dropdownColor: Colors.grey[900],
            icon: const Icon(Icons.settings, color: Colors.white),
            onChanged: (value) {
              setState(() {
                _difficulty = value!;
                _initBoard();
              });
            },
            items: const [
              DropdownMenuItem(value: 'Easy', child: Text('Easy', style: TextStyle(color: Colors.white))),
              DropdownMenuItem(value: 'Hard', child: Text('Hard', style: TextStyle(color: Colors.white))),
              DropdownMenuItem(value: 'Master', child: Text('Master', style: TextStyle(color: Colors.white))),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: () => setState(() => _initBoard()),
          ),
        ],
      ),
      backgroundColor: Colors.black,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_message, style: const TextStyle(color: Colors.white, fontSize: 16)),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
              itemCount: 64,
              itemBuilder: (ctx, i) {
                int row = i ~/ 8;
                int col = i % 8;
                bool isDark = (row + col) % 2 == 1;
                String? piece = board[row][col];
                bool selected = (_selectedRow == row && _selectedCol == col);
                return GestureDetector(
                  onTap: () => _onSquareTap(row, col),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isDark ? Colors.brown[800] : Colors.grey[300],
                      border: selected ? Border.all(color: Colors.redAccent, width: 3) : null,
                    ),
                    child: Center(
                      child: Text(
                        _pieceSymbol(piece),
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _pieceSymbol(String? piece) {
    if (piece == null) return '';
    switch (piece) {
      case 'K': return '♔'; case 'k': return '♚';
      case 'Q': return '♕'; case 'q': return '♛';
      case 'R': return '♖'; case 'r': return '♜';
      case 'B': return '♗'; case 'b': return '♝';
      case 'N': return '♘'; case 'n': return '♞';
      case 'P': return '♙'; case 'p': return '♟';
      default: return '';
    }
  }
}

// ==================== 7. TEBAK/SAMBUNG KATA ====================
class WordGame extends StatefulWidget {
  const WordGame({super.key});

  @override
  State<WordGame> createState() => _WordGameState();
}

class _WordGameState extends State<WordGame> {
  final List<String> words = ['API', 'FLUTTER', 'DART', 'JAVA', 'PYTHON', 'HTML', 'CSS', 'KOTLIN'];
  String currentWord = '';
  String userInput = '';
  int score = 0;
  bool gameOver = false;

  @override
  void initState() {
    super.initState();
    _nextWord();
  }

  void _nextWord() {
    if (words.isEmpty) {
      setState(() => gameOver = true);
      return;
    }
    setState(() {
      currentWord = words.removeAt(Random().nextInt(words.length));
      userInput = '';
    });
  }

  void _checkAnswer() {
    if (userInput.trim().toLowerCase() == currentWord.toLowerCase()) {
      score++;
      _nextWord();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Salah! Coba lagi.'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tebak Kata'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: gameOver
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Skor akhir: $score', style: const TextStyle(color: Colors.white, fontSize: 28)),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        score = 0;
                        gameOver = false;
                        words.addAll(['API', 'FLUTTER', 'DART', 'JAVA', 'PYTHON', 'HTML', 'CSS', 'KOTLIN']);
                        _nextWord();
                      });
                    },
                    child: const Text('Main Lagi'),
                  ),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('Tebak kata: ???', style: const TextStyle(color: Colors.white, fontSize: 24)),
                  const SizedBox(height: 20),
                  TextField(
                    onChanged: (val) => userInput = val,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Masukkan jawaban',
                      hintStyle: const TextStyle(color: Colors.white38),
                      filled: true,
                      fillColor: Colors.grey[900],
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _checkAnswer,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('Kirim Jawaban'),
                  ),
                ],
              ),
            ),
    );
  }
}

// ==================== 8. TEKA TEKI SILANG ====================
class CrosswordGame extends StatefulWidget {
  const CrosswordGame({super.key});

  @override
  State<CrosswordGame> createState() => _CrosswordGameState();
}

class _CrosswordGameState extends State<CrosswordGame> {
  final List<Map<String, String>> clues = [
    {'clue': 'Bahasa pemrograman untuk Flutter', 'answer': 'DART'},
    {'clue': 'Sistem operasi mobile Google', 'answer': 'ANDROID'},
    {'clue': 'Framework UI dari Google', 'answer': 'FLUTTER'},
    {'clue': 'Bahasa markup untuk web', 'answer': 'HTML'},
  ];
  int currentIndex = 0;
  String userAnswer = '';
  int score = 0;

  void _checkAnswer() {
    if (userAnswer.trim().toUpperCase() == clues[currentIndex]['answer']) {
      score++;
      if (currentIndex + 1 < clues.length) {
        setState(() => currentIndex++);
        userAnswer = '';
      } else {
        _showFinish();
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Jawaban salah!'), backgroundColor: Colors.red),
      );
    }
  }

  void _showFinish() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Selesai!'),
        content: Text('Skor Anda: $score/${clues.length}'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Teka Teki Silang'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text('Pertanyaan ${currentIndex + 1}/${clues.length}', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 20),
            Text(clues[currentIndex]['clue']!, style: const TextStyle(color: Colors.white, fontSize: 20)),
            const SizedBox(height: 20),
            TextField(
              onChanged: (val) => userAnswer = val,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Jawaban',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: Colors.grey[900],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _checkAnswer,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Jawab'),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== 9. KUIS PEMROGRAMAN (MULTI BAHASA) ====================
class ProgrammingQuiz extends StatefulWidget {
  const ProgrammingQuiz({super.key});

  @override
  State<ProgrammingQuiz> createState() => _ProgrammingQuizState();
}

class _ProgrammingQuizState extends State<ProgrammingQuiz> {
  String selectedCategory = 'JavaScript';
  int currentQuestion = 0;
  int score = 0;
  bool quizStarted = false;
  bool quizFinished = false;
  List<Map<String, dynamic>> questions = [];

  final Map<String, List<Map<String, dynamic>>> questionBank = {
    'JavaScript': [
      {'question': 'Apa output dari `console.log(typeof [])`?', 'options': ['array', 'object', 'undefined', 'null'], 'answer': 'object'},
      {'question': 'Fungsi untuk menjalankan kode setelah interval waktu tertentu?', 'options': ['setInterval', 'setTimeout', 'requestAnimationFrame', 'callLater'], 'answer': 'setTimeout'},
      {'question': 'Manakah yang termasuk operator perbandingan?', 'options': ['=', '==', '++', '?'], 'answer': '=='},
    ],
    'HTML': [
      {'question': 'Tag untuk membuat paragraf?', 'options': ['<p>', '<div>', '<span>', '<h1>'], 'answer': '<p>'},
      {'question': 'Atribut untuk menampilkan tooltip?', 'options': ['title', 'alt', 'href', 'src'], 'answer': 'title'},
      {'question': 'Tag untuk menyisipkan gambar?', 'options': ['<img>', '<image>', '<src>', '<pic>'], 'answer': '<img>'},
    ],
    'Python': [
      {'question': 'Tipe data untuk nilai True/False?', 'options': ['bool', 'int', 'str', 'float'], 'answer': 'bool'},
      {'question': 'Fungsi untuk mencetak ke layar?', 'options': ['print', 'console.log', 'echo', 'write'], 'answer': 'print'},
      {'question': 'Simbol untuk komentar satu baris?', 'options': ['#', '//', '/*', '<!--'], 'answer': '#'},
    ],
  };

  void startQuiz() {
    setState(() {
      quizStarted = true;
      quizFinished = false;
      currentQuestion = 0;
      score = 0;
      questions = List.from(questionBank[selectedCategory]!);
    });
  }

  void answerQuestion(String selected) {
    if (selected == questions[currentQuestion]['answer']) {
      score++;
    }
    if (currentQuestion + 1 < questions.length) {
      setState(() => currentQuestion++);
    } else {
      setState(() => quizFinished = true);
    }
  }

  void resetQuiz() {
    setState(() {
      quizStarted = false;
      quizFinished = false;
      selectedCategory = 'JavaScript';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kuis Pemrograman'), backgroundColor: Colors.red[900]),
      backgroundColor: Colors.black,
      body: !quizStarted
          ? Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text('Pilih kategori:', style: TextStyle(color: Colors.white, fontSize: 18)),
                  const SizedBox(height: 20),
                  DropdownButton<String>(
                    value: selectedCategory,
                    dropdownColor: Colors.grey[900],
                    style: const TextStyle(color: Colors.white),
                    onChanged: (value) => setState(() => selectedCategory = value!),
                    items: const [
                      DropdownMenuItem(value: 'JavaScript', child: Text('JavaScript')),
                      DropdownMenuItem(value: 'HTML', child: Text('HTML')),
                      DropdownMenuItem(value: 'Python', child: Text('Python')),
                    ],
                  ),
                  const SizedBox(height: 40),
                  ElevatedButton(
                    onPressed: startQuiz,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    child: const Text('Mulai Kuis'),
                  ),
                ],
              ),
            )
          : quizFinished
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Skor Anda: $score/${questions.length}', style: const TextStyle(color: Colors.white, fontSize: 28)),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: resetQuiz,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                        child: const Text('Kuis Lagi'),
                      ),
                    ],
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text('Soal ${currentQuestion + 1}/${questions.length}', style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 20),
                      Text(questions[currentQuestion]['question'], style: const TextStyle(color: Colors.white, fontSize: 18)),
                      const SizedBox(height: 30),
                      ...(questions[currentQuestion]['options'] as List<String>).map((opt) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () => answerQuestion(opt),
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.red[800]),
                                child: Text(opt, style: const TextStyle(color: Colors.white)),
                              ),
                            ),
                          )),
                    ],
                  ),
                ),
    );
  }
}