import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

const _bg = Color(0xFF0A0A0A);
const _bgCard = Color(0xFF111111);
const _bgInput = Color(0xFF1A1A1A);
const _border = Color(0xFF2A2A2A);
const _accent = Color(0xFF10A37F);
const _accentDim = Color(0xFF0D8A6C);
const _userBubble = Color(0xFF1E3A2F);
const _textPrimary = Color(0xFFECECEC);
const _textSecondary = Color(0xFF8E8EA0);
const _textMuted = Color(0xFF4D4D60);
const _codeBg = Color(0xFF161B22);
const _codeText = Color(0xFFE6EDF3);
const _red = Color(0xFFEF4444);
const _sidebarBg = Color(0xFF0F0F0F);

class XNeuronChatPage extends StatefulWidget {
  final String sessionKey;

  const XNeuronChatPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<XNeuronChatPage> createState() => _XNeuronChatPageState();
}

class _XNeuronChatPageState extends State<XNeuronChatPage>
    with TickerProviderStateMixin {
  final TextEditingController _messageCtrl = TextEditingController();
  final ScrollController _chatScroll = ScrollController();
  final FocusNode _inputFocus = FocusNode();

  final List<XMessage> _messages = [];
  bool _isLoading = false;
  bool _showSidebar = false;
  String? _currentSessionId;
  String? _currentSessionTitle;
  List<XSession> _sessions = [];

  File? _pendingFile;
  String? _pendingFileType;
  String? _pendingFileName;
  bool _isUploading = false;

  late AnimationController _typingController;
  late AnimationController _sidebarController;
  late Animation<Offset> _sidebarAnim;

  @override
  void initState() {
    super.initState();

    _typingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();

    _sidebarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _sidebarAnim = Tween<Offset>(
      begin: const Offset(-1, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _sidebarController, curve: Curves.easeOutCubic));

    _loadSessions();
    _loadConfig();
    _messageCtrl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _messageCtrl.dispose();
    _chatScroll.dispose();
    _inputFocus.dispose();
    _typingController.dispose();
    _sidebarController.dispose();
    super.dispose();
  }

  String get _key => widget.sessionKey;
  String baseUrl = "";

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse("https://raw.githubusercontent.com/XyzzcyOfficial/XyzzcyOfficial/refs/heads/main/srvr1.json"));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadSessions() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/xneuron/sessions?key=$_key'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _sessions = (data['sessions'] as List)
                .map((s) => XSession.fromJson(s))
                .toList();
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _createNewSession() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/xneuron/new-session?key=$_key'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _currentSessionId = data['sessionId'];
            _currentSessionTitle = 'Chat baru';
            _messages.clear();
            _showSidebar = false;
          });
          _sidebarController.reverse();
          await _loadSessions();
        }
      }
    } catch (_) {
      _snack('Gagal buat sesi baru', error: true);
    }
  }

  Future<void> _loadSession(String sessionId, String title) async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/xneuron/history?key=$_key&session=$sessionId'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final history = data['chatHistory'] as List;
          setState(() {
            _currentSessionId = sessionId;
            _currentSessionTitle = title;
            _messages.clear();
            for (final m in history) {
              _messages.add(XMessage(
                text: m['message'] ?? '',
                isAI: m['isAI'] == true,
                timestamp: DateTime.tryParse(m['timestamp'] ?? '') ?? DateTime.now(),
                source: m['source'],
                imageUrl: m['imagePath'],
              ));
            }
            _showSidebar = false;
          });
          _sidebarController.reverse();
          _scrollToBottom();
        }
      }
    } catch (_) {
      _snack('Gagal load sesi', error: true);
    }
  }

  Future<void> _deleteSession(String sessionId) async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/xneuron/delete?key=$_key&session=$sessionId'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          if (_currentSessionId == sessionId) {
            setState(() {
              _currentSessionId = null;
              _currentSessionTitle = null;
              _messages.clear();
            });
          }
          await _loadSessions();
          _snack('Sesi dihapus');
        }
      }
    } catch (_) {
      _snack('Gagal hapus sesi', error: true);
    }
  }

  Future<void> _sendMessage() async {
    final text = _messageCtrl.text.trim();
    if ((text.isEmpty && _pendingFile == null) || _isLoading) return;

    final hasFile = _pendingFile != null;
    final file = _pendingFile;
    final fileName = _pendingFileName;
    final fileType = _pendingFileType;

    HapticFeedback.lightImpact();

    setState(() {
      _messages.add(XMessage(
        text: text.isEmpty ? '(Media dikirim)' : text,
        isAI: false,
        timestamp: DateTime.now(),
        localFile: file,
        fileType: fileType,
        fileName: fileName,
      ));
      _isLoading = true;
      _pendingFile = null;
      _pendingFileType = null;
      _pendingFileName = null;
    });
    _messageCtrl.clear();
    _scrollToBottom();

    try {
      Map<String, dynamic> data;

      if (hasFile && file != null) {
        final uri = Uri.parse('$baseUrl/xneuron/send');
        final request = http.MultipartRequest('POST', uri)
          ..fields['key'] = _key
          ..fields['session'] = _currentSessionId!
          ..fields['message'] = text.isEmpty ? '(Media dikirim)' : text
          ..files.add(await http.MultipartFile.fromPath('media', file.path));
        final streamed = await request.send().timeout(const Duration(seconds: 60));
        final res = await http.Response.fromStream(streamed);
        data = jsonDecode(res.body);
      } else {
        final uri = Uri.parse(
          '$baseUrl/xneuron/send?key=$_key&session=$_currentSessionId&message=${Uri.encodeComponent(text)}',
        );
        final res = await http.get(uri).timeout(const Duration(seconds: 60));
        data = jsonDecode(res.body);
      }

      if (data['status'] == true) {
        setState(() {
          _messages.add(XMessage(
            text: data['data']?['message'] ?? '(kosong)',
            isAI: true,
            timestamp: DateTime.now(),
            source: data['data']?['source'],
            imageUrl: data['data']?['imageUrl'],
          ));
        });
        _scrollToBottom();
        if (_messages.where((m) => !m.isAI).length == 1) {
          final title = text.isNotEmpty
              ? text.substring(0, text.length > 30 ? 30 : text.length)
              : 'Media';
          setState(() => _currentSessionTitle = title);
          await _loadSessions();
        }
      } else {
        _snack(data['message'] ?? 'Gagal dapat respons', error: true);
      }
    } catch (e) {
      _snack('Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (picked != null) {
      setState(() {
        _pendingFile = File(picked.path);
        _pendingFileType = 'image';
        _pendingFileName = picked.name;
      });
    }
  }

Future<void> _pickFile() async {
    final picker = ImagePicker();
    final picked = await picker.pickMedia();
    if (picked != null) {
      setState(() {
        _pendingFile = File(picked.path);
        _pendingFileType = 'file';
        _pendingFileName = picked.name;
      });
    }
  }
  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _toggleSidebar() {
    setState(() => _showSidebar = !_showSidebar);
    if (_showSidebar) {
      _sidebarController.forward();
    } else {
      _sidebarController.reverse();
    }
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(
          error ? Icons.error_outline : Icons.check_circle_outline,
          color: error ? _red : _accent,
          size: 16,
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(msg,
              style: const TextStyle(color: _textPrimary, fontSize: 13)),
        ),
      ]),
      backgroundColor: _bgCard,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: error ? _red.withOpacity(0.4) : _accent.withOpacity(0.4)),
      ),
      elevation: 0,
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: _currentSessionId == null
                    ? _buildWelcomeScreen()
                    : _buildChatArea(),
              ),
              if (_currentSessionId != null) _buildInputBar(),
            ],
          ),

          if (_showSidebar)
            GestureDetector(
              onTap: _toggleSidebar,
              child: Container(color: Colors.black.withOpacity(0.5)),
            ),
          SlideTransition(
            position: _sidebarAnim,
            child: _buildSidebar(),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      height: MediaQuery.of(context).padding.top + 52,
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      decoration: const BoxDecoration(
        color: _bg,
        border: Border(bottom: BorderSide(color: _border, width: 0.8)),
      ),
      child: Row(
        children: [
          _IconBtn(
            icon: Icons.menu_rounded,
            onTap: _toggleSidebar,
          ),
          const SizedBox(width: 4),

          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: _accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _accent.withOpacity(0.5)),
                  ),
                  child: const Icon(Icons.psychology_rounded,
                      color: _accent, size: 16),
                ),
                const SizedBox(width: 8),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'X-Neuron',
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                    if (_currentSessionTitle != null)
                      Text(
                        _currentSessionTitle!,
                        style: const TextStyle(
                          color: _textMuted,
                          fontSize: 10,
                          fontFamily: 'monospace',
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                  ],
                ),
              ],
            ),
          ),

          _IconBtn(
            icon: Icons.add_rounded,
            onTap: _createNewSession,
            tooltip: 'New Chat',
          ),
          const SizedBox(width: 4),
        ],
      ),
    );
  }

  Widget _buildSidebar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.78,
      child: Container(
        decoration: const BoxDecoration(
          color: _sidebarBg,
          border: Border(right: BorderSide(color: _border, width: 0.8)),
        ),
        child: Column(
          children: [
            SizedBox(height: MediaQuery.of(context).padding.top + 12),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _accent.withOpacity(0.4)),
                    ),
                    child: const Icon(Icons.psychology_rounded, color: _accent, size: 14),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'X-NEURON',
                    style: TextStyle(
                      color: _textPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: _createNewSession,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _accent.withOpacity(0.35)),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.add_rounded, size: 13, color: _accent),
                          SizedBox(width: 4),
                          Text('Baru',
                              style: TextStyle(
                                  color: _accent,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Divider(color: _border, height: 1),
            ),

            Expanded(
              child: _sessions.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.chat_bubble_outline_rounded,
                              color: _textMuted, size: 32),
                          const SizedBox(height: 12),
                          const Text('Belum ada sesi',
                              style: TextStyle(color: _textMuted, fontSize: 12)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(10, 8, 10, 20),
                      itemCount: _sessions.length,
                      itemBuilder: (context, i) {
                        final s = _sessions[i];
                        final isActive = s.sessionId == _currentSessionId;
                        return _SidebarSessionTile(
                          session: s,
                          isActive: isActive,
                          onTap: () => _loadSession(s.sessionId, s.title),
                          onDelete: () => _deleteSession(s.sessionId),
                        );
                      },
                    ),
            ),

            Padding(
              padding: EdgeInsets.only(
                  left: 16, right: 16, bottom: MediaQuery.of(context).padding.bottom + 16),
              child: Row(
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _accent.withOpacity(0.1),
                      border: Border.all(color: _accent.withOpacity(0.3)),
                    ),
                    child: const Icon(Icons.person_rounded, color: _accent, size: 14),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'X-Neuron AI',
                    style: TextStyle(color: _textSecondary, fontSize: 12),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: _accent.withOpacity(0.3)),
                    ),
                    child: const Text('Online',
                        style: TextStyle(
                            color: _accent,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeScreen() {
    final suggestions = [
      ('💡', 'Buatkan aku fungsi sorting quicksort di python'),
      ('🔍', 'Jelaskan cara kerja jwt authentication'),
      ('🌐', 'Translate teks ini ke bahasa Indonesia'),
      ('❗', 'Debug code ini dan kasih solusinya'),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 40),
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _accent.withOpacity(0.5), width: 2),
            ),
            child: const Icon(Icons.psychology_rounded, color: _accent, size: 36),
          ),
          const SizedBox(height: 20),
          const Text(
            'Halo, gw X-Neuron!',
            style: TextStyle(
              color: _textPrimary,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'AI asisten buatan XyzzcyOfficial.\nBisa bantuin lu coding, nulis, analyze, dan banyak lagi',
            style: TextStyle(color: _textSecondary, fontSize: 14, height: 1.5),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 36),

          GestureDetector(
            onTap: _createNewSession,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _accent,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                      color: _accent.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 6))
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_rounded, color: Colors.white, size: 20),
                  SizedBox(width: 8),
                  Text(
                    'Mulai Chat',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),

          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Coba tanyain ini:',
              style: TextStyle(
                color: _textSecondary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const SizedBox(height: 12),
          ...suggestions.map((s) => _SuggestionCard(
                emoji: s.$1,
                text: s.$2,
                onTap: () async {
                  await _createNewSession();
                  if (_currentSessionId != null) {
                    _messageCtrl.text = s.$2;
                    setState(() {});
                  }
                },
              )),
        ],
      ),
    );
  }

  Widget _buildChatArea() {
    return Column(
      children: [
        Expanded(
          child: _messages.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.chat_bubble_outline_rounded,
                          color: _textMuted, size: 32),
                      const SizedBox(height: 10),
                      const Text('Kirim pesan untuk mulai',
                          style: TextStyle(color: _textMuted, fontSize: 13)),
                    ],
                  ),
                )
              : ListView.builder(
                  controller: _chatScroll,
                  padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
                  itemCount: _messages.length + (_isLoading ? 1 : 0),
                  itemBuilder: (context, i) {
                    if (_isLoading && i == _messages.length) {
                      return _TypingBubble(controller: _typingController);
                    }
                    return _MessageRow(
                      message: _messages[i],
                      animate: i == _messages.length - 1,
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildInputBar() {
    return Container(
      decoration: const BoxDecoration(
        color: _bg,
        border: Border(top: BorderSide(color: _border, width: 0.8)),
      ),
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 10,
        bottom: MediaQuery.of(context).padding.bottom + 10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_pendingFile != null) _buildFilePreview(),

          Container(
            decoration: BoxDecoration(
              color: _bgInput,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _inputFocus.hasFocus
                    ? _accent.withOpacity(0.5)
                    : _border,
              ),
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _messageCtrl,
                          focusNode: _inputFocus,
                          style: const TextStyle(
                            color: _textPrimary,
                            fontSize: 14,
                            height: 1.4,
                          ),
                          cursorColor: _accent,
                          minLines: 1,
                          maxLines: 6,
                          decoration: const InputDecoration(
                            hintText: 'Tanya sesuatu...',
                            hintStyle: TextStyle(color: _textMuted, fontSize: 14),
                            contentPadding:
                                EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                            border: InputBorder.none,
                          ),
                          onSubmitted: (_) =>
                              _messageCtrl.text.trim().isNotEmpty ? _sendMessage() : null,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 6, bottom: 6),
                        child: _SendButton(
                          enabled: (_messageCtrl.text.trim().isNotEmpty ||
                                  _pendingFile != null) &&
                              !_isLoading,
                          isLoading: _isLoading,
                          onTap: _sendMessage,
                        ),
                      ),
                    ],
                  ),
                ),

                Container(
                  decoration: BoxDecoration(
                    border: Border(top: BorderSide(color: _border.withOpacity(0.5), width: 0.5)),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      _InputActionBtn(
                        icon: Icons.image_outlined,
                        label: 'Gambar',
                        onTap: _pickImage,
                      ),
                      const SizedBox(width: 4),
                      _InputActionBtn(
                        icon: Icons.attach_file_rounded,
                        label: 'File',
                        onTap: _pickFile,
                      ),
                      const Spacer(),
                      const Text(
                        'Powered By XyzzcyOfficial',
                        style: TextStyle(
                          color: _textMuted,
                          fontSize: 9,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilePreview() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _accent.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          if (_pendingFileType == 'image' && _pendingFile != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.file(_pendingFile!,
                  width: 40, height: 40, fit: BoxFit.cover),
            )
          else
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Icon(Icons.insert_drive_file_rounded,
                  color: _accent, size: 20),
            ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _pendingFileName ?? 'File',
              style: const TextStyle(
                  color: _textSecondary, fontSize: 12, fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          GestureDetector(
            onTap: () => setState(() {
              _pendingFile = null;
              _pendingFileType = null;
              _pendingFileName = null;
            }),
            child: const Icon(Icons.close_rounded, color: _textMuted, size: 18),
          ),
        ],
      ),
    );
  }
}

class _MessageRow extends StatefulWidget {
  final XMessage message;
  final bool animate;
  const _MessageRow({required this.message, this.animate = false});

  @override
  State<_MessageRow> createState() => _MessageRowState();
}

class _MessageRowState extends State<_MessageRow>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 300));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: Offset(widget.message.isAI ? -0.05 : 0.05, 0.03),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    if (widget.animate) {
      _ctrl.forward();
    } else {
      _ctrl.value = 1.0;
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAI = widget.message.isAI;
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 4),
          color: isAI ? _bgCard.withOpacity(0.4) : Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _Avatar(isAI: isAI),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            isAI ? 'X-Neuron' : 'Kamu',
                            style: const TextStyle(
                              color: _textPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _fmtTime(widget.message.timestamp),
                            style: const TextStyle(
                              color: _textMuted,
                              fontSize: 10,
                              fontFamily: 'monospace',
                            ),
                          ),
                          if (isAI && widget.message.source != null) ...[
                            const SizedBox(width: 6),
                            _SourceBadge(source: widget.message.source!),
                          ],
                        ],
                      ),
                      const SizedBox(height: 6),

                      if (widget.message.localFile != null &&
                          widget.message.fileType == 'image')
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.file(
                              widget.message.localFile!,
                              width: 200,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),

                      if (widget.message.imageUrl != null &&
                          widget.message.imageUrl!.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.network(
                              widget.message.imageUrl!,
                              width: 200,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const SizedBox(),
                            ),
                          ),
                        ),

                      _MessageContent(
                        text: widget.message.text,
                        isAI: isAI,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _fmtTime(DateTime dt) {
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}

class _MessageContent extends StatelessWidget {
  final String text;
  final bool isAI;
  const _MessageContent({required this.text, required this.isAI});

  @override
  Widget build(BuildContext context) {
    final parts = _parseContent(text);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: parts.map((p) {
        if (p.isCode) {
          return _CodeBlock(code: p.text, language: p.language);
        } else {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: SelectableText(
              p.text,
              style: TextStyle(
                color: isAI ? _textPrimary : _textPrimary,
                fontSize: 14,
                height: 1.6,
              ),
            ),
          );
        }
      }).toList(),
    );
  }

  List<_ContentPart> _parseContent(String raw) {
    final parts = <_ContentPart>[];
    final codeRegex = RegExp(r'```(\w*)\n?([\s\S]*?)```', multiLine: true);
    int lastEnd = 0;

    for (final match in codeRegex.allMatches(raw)) {
      if (match.start > lastEnd) {
        final before = raw.substring(lastEnd, match.start).trim();
        if (before.isNotEmpty) {
          parts.add(_ContentPart(text: before, isCode: false));
        }
      }
      final lang = match.group(1) ?? '';
      final code = match.group(2) ?? '';
      parts.add(_ContentPart(text: code.trim(), isCode: true, language: lang));
      lastEnd = match.end;
    }

    if (lastEnd < raw.length) {
      final remaining = raw.substring(lastEnd).trim();
      if (remaining.isNotEmpty) {
        parts.add(_ContentPart(text: remaining, isCode: false));
      }
    }

    if (parts.isEmpty) {
      parts.add(_ContentPart(text: raw, isCode: false));
    }

    return parts;
  }
}

class _ContentPart {
  final String text;
  final bool isCode;
  final String language;
  const _ContentPart({required this.text, required this.isCode, this.language = ''});
}

class _CodeBlock extends StatefulWidget {
  final String code;
  final String language;
  const _CodeBlock({required this.code, required this.language});

  @override
  State<_CodeBlock> createState() => _CodeBlockState();
}

class _CodeBlockState extends State<_CodeBlock> {
  bool _copied = false;

  void _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.code));
    setState(() => _copied = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: _codeBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: _border, width: 0.5)),
            ),
            child: Row(
              children: [
                if (widget.language.isNotEmpty)
                  Text(
                    widget.language.toUpperCase(),
                    style: const TextStyle(
                      color: _accent,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1,
                      fontFamily: 'monospace',
                    ),
                  )
                else
                  const Text(
                    'CODE',
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 10,
                      fontFamily: 'monospace',
                    ),
                  ),
                const Spacer(),
                GestureDetector(
                  onTap: _copy,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _copied
                          ? _accent.withOpacity(0.15)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: _copied
                            ? _accent.withOpacity(0.5)
                            : _border,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _copied ? Icons.check_rounded : Icons.copy_rounded,
                          size: 12,
                          color: _copied ? _accent : _textMuted,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _copied ? 'Disalin!' : 'Salin',
                          style: TextStyle(
                            color: _copied ? _accent : _textMuted,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(14),
            child: SelectableText(
              widget.code,
              style: const TextStyle(
                color: _codeText,
                fontSize: 12.5,
                fontFamily: 'monospace',
                height: 1.6,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TypingBubble extends StatelessWidget {
  final AnimationController controller;
  const _TypingBubble({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      color: _bgCard.withOpacity(0.4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const _Avatar(isAI: true),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _border),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (i) {
                return AnimatedBuilder(
                  animation: controller,
                  builder: (_, __) {
                    final offset = i * 0.3;
                    final val = ((controller.value - offset) % 1.0).clamp(0.0, 1.0);
                    final opacity = val < 0.5 ? val * 2 : (1.0 - val) * 2;
                    return Container(
                      margin: EdgeInsets.only(right: i < 2 ? 5 : 0),
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _accent.withOpacity(0.3 + opacity * 0.7),
                      ),
                    );
                  },
                );
              }),
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            'X-Neuron thinking...',
            style: TextStyle(
              color: _textMuted,
              fontSize: 11,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }
}

class _SidebarSessionTile extends StatelessWidget {
  final XSession session;
  final bool isActive;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  const _SidebarSessionTile({
    required this.session,
    required this.isActive,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 3),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: isActive ? _accent.withOpacity(0.12) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: isActive
                ? Border.all(color: _accent.withOpacity(0.35))
                : null,
          ),
          child: Row(
            children: [
              Icon(
                Icons.chat_bubble_outline_rounded,
                size: 14,
                color: isActive ? _accent : _textMuted,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      session.title,
                      style: TextStyle(
                        color: isActive ? _textPrimary : _textSecondary,
                        fontSize: 12,
                        fontWeight:
                            isActive ? FontWeight.w700 : FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${session.messageCount} pesan',
                      style: const TextStyle(
                          color: _textMuted,
                          fontSize: 10,
                          fontFamily: 'monospace'),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onDelete,
                child: const Padding(
                  padding: EdgeInsets.only(left: 4),
                  child: Icon(Icons.delete_outline_rounded,
                      size: 15, color: _red),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final bool isAI;
  const _Avatar({required this.isAI});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: isAI ? _accent.withOpacity(0.15) : _userBubble,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isAI ? _accent.withOpacity(0.4) : _accent.withOpacity(0.2),
        ),
      ),
      child: Icon(
        isAI ? Icons.psychology_rounded : Icons.person_rounded,
        color: isAI ? _accent : _textSecondary,
        size: 16,
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final String? tooltip;
  const _IconBtn({required this.icon, required this.onTap, this.tooltip});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip ?? '',
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: _textSecondary, size: 20),
        ),
      ),
    );
  }
}

class _InputActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _InputActionBtn(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Icon(icon, size: 15, color: _textMuted),
            const SizedBox(width: 4),
            Text(label,
                style: const TextStyle(
                    color: _textMuted, fontSize: 11, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _SendButton extends StatelessWidget {
  final bool enabled;
  final bool isLoading;
  final VoidCallback onTap;
  const _SendButton(
      {required this.enabled, required this.isLoading, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: enabled ? _accent : _border,
          borderRadius: BorderRadius.circular(9),
          boxShadow: enabled
              ? [BoxShadow(color: _accent.withOpacity(0.25), blurRadius: 12)]
              : [],
        ),
        child: Icon(
          isLoading ? Icons.hourglass_top_rounded : Icons.arrow_upward_rounded,
          color: enabled ? Colors.white : _textMuted,
          size: 18,
        ),
      ),
    );
  }
}

class _SourceBadge extends StatelessWidget {
  final String source;
  const _SourceBadge({required this.source});

  @override
  Widget build(BuildContext context) {
    final color = source == 'gemini'
        ? const Color(0xFF4285F4)
        : source == 'venice'
            ? const Color(0xFF7C3AED)
            : source == 'wrmgpt'
                ? const Color(0xFFEF4444)
                : _textMuted;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        source.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 8,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
          fontFamily: 'monospace',
        ),
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  final String emoji;
  final String text;
  final VoidCallback onTap;
  const _SuggestionCard(
      {required this.emoji, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _border),
        ),
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(
                  color: _textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                size: 12, color: _textMuted),
          ],
        ),
      ),
    );
  }
}

class XMessage {
  final String text;
  final bool isAI;
  final DateTime timestamp;
  final String? source;
  final String? imageUrl;
  final File? localFile;
  final String? fileType;
  final String? fileName;

  const XMessage({
    required this.text,
    required this.isAI,
    required this.timestamp,
    this.source,
    this.imageUrl,
    this.localFile,
    this.fileType,
    this.fileName,
  });
}

class XSession {
  final String sessionId;
  final String title;
  final int messageCount;
  final DateTime lastModified;
  final String preview;
  final String model;

  const XSession({
    required this.sessionId,
    required this.title,
    required this.messageCount,
    required this.lastModified,
    required this.preview,
    required this.model,
  });

  factory XSession.fromJson(Map<String, dynamic> json) {
    return XSession(
      sessionId: json['sessionId'] ?? '',
      title: json['title'] ?? json['sessionId'] ?? '',
      messageCount: json['messageCount'] ?? 0,
      lastModified:
          DateTime.tryParse(json['lastModified'] ?? '') ?? DateTime.now(),
      preview: json['preview'] ?? '',
      model: json['model'] ?? 'auto',
    );
  }
}