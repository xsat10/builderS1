import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AppColors {
  static const Color primary = Color(0xFF00E676);
  static const Color primaryDark = Color(0xFF00C853);
  static const Color background = Color(0xFF0A0A0A);
  static const Color surface = Color(0xFF141414);
  static const Color card = Color(0xFF1C1C1C);
  static const Color cardBorder = Color(0xFF2A2A2A);
  static const Color white = Colors.white;
  static const Color grey = Color(0xFF888888);
  static const Color greyDark = Color(0xFF444444);
  static const Color amber = Colors.amber;
}

const String _baseUrl = 'https://www.sankavollerei.com/anime/winbu';

class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  Map<String, dynamic>? homeData;
  bool isLoading = true;
  bool isSearching = false;
  List<dynamic> searchResults = [];
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  List<Map<String, dynamic>> _watchHistory = [];
  bool _isHistoryLoading = true;

  @override
  void initState() {
    super.initState();
    fetchHomeData();
    _loadWatchHistory();
  }

  void refreshHistory() => _loadWatchHistory();

  Future<void> _loadWatchHistory() async {
    setState(() => _isHistoryLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      setState(() {
        _watchHistory = historyJson
            .map((item) => Map<String, dynamic>.from(json.decode(item)))
            .toList();
        _isHistoryLoading = false;
      });
    } catch (e) {
      setState(() => _isHistoryLoading = false);
    }
  }

  Future<void> fetchHomeData() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/home'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          homeData = jsonData['data'];
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() { isSearching = false; searchResults.clear(); });
      return;
    }
    setState(() => isSearching = true);
    try {
      final encoded = Uri.encodeComponent(query);
      final response = await http.get(Uri.parse('$_baseUrl/search?q=$encoded'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() => searchResults = jsonData['results'] ?? []);
      } else {
        setState(() => searchResults = []);
      }
    } catch (e) {
      setState(() => searchResults = []);
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() { isSearching = false; searchResults.clear(); });
    _searchFocusNode.unfocus();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Row(
          children: const [
            FaIcon(FontAwesomeIcons.dragon, color: AppColors.primary, size: 20),
            SizedBox(width: 8),
            Text('WibuZone', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary, fontSize: 20)),
          ],
        ),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
        actions: [
          IconButton(
            icon: const FaIcon(FontAwesomeIcons.list, color: AppColors.primary, size: 18),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnimeListPage())).then((_) => refreshHistory()),
            tooltip: 'All Anime',
          ),
          IconButton(
            icon: const FaIcon(FontAwesomeIcons.user, color: AppColors.primary, size: 18),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              style: const TextStyle(color: AppColors.white),
              decoration: InputDecoration(
                hintText: "Cari anime, film, dan series...",
                hintStyle: const TextStyle(color: AppColors.grey),
                prefixIcon: const Padding(
                  padding: EdgeInsets.all(12),
                  child: FaIcon(FontAwesomeIcons.magnifyingGlass, color: AppColors.grey, size: 16),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const FaIcon(FontAwesomeIcons.xmark, color: AppColors.grey, size: 14),
                        onPressed: _clearSearch,
                      )
                    : null,
                filled: true,
                fillColor: AppColors.card,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: AppColors.primary.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: AppColors.cardBorder),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
              ),
              onChanged: (value) {
                setState(() {});
                if (value.isNotEmpty) {
                  searchAnime(value);
                } else {
                  setState(() { isSearching = false; searchResults.clear(); });
                }
              },
            ),
          ),
          Expanded(
            child: isLoading
                ? _buildLoadingShimmer()
                : isSearching
                    ? _buildSearchResults()
                    : homeData == null
                        ? _buildErrorWidget()
                        : _buildHomeContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    final top10Anime = homeData!['top10_anime'] ?? [];
    final top10Film = homeData!['top10_film'] ?? [];
    final latestAnime = homeData!['latest_anime'] ?? [];
    final latestFilm = homeData!['latest_film'] ?? [];
    final latestSeries = homeData!['latest_series'] ?? [];
    final tvShow = homeData!['tv_show'] ?? [];

    return RefreshIndicator(
      onRefresh: () async {
        await Future.wait([fetchHomeData(), _loadWatchHistory()]);
      },
      color: AppColors.primary,
      backgroundColor: AppColors.card,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(FontAwesomeIcons.clockRotateLeft, "Riwayat Tonton"),
            const SizedBox(height: 12),
            _isHistoryLoading
                ? _buildHorizontalShimmer()
                : _watchHistory.isEmpty
                    ? _buildEmptyHistory()
                    : _buildHistoryList(),
            const SizedBox(height: 24),

            _buildSectionHeader(FontAwesomeIcons.compass, "Jelajahi"),
            const SizedBox(height: 12),
            _buildQuickAccessGrid(),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.fire, "Top 10 Anime",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PopulerPage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildTop10List(top10Anime),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.film, "Top 10 Film",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FilmListPage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildHorizontalCardList(top10Film),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.tv, "Anime Terbaru",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UpdatePage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildHorizontalCardList(latestAnime),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.clapperboard, "Film Terbaru",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LatestPage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildHorizontalCardList(latestFilm),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.photoFilm, "Series Terbaru",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SeriesListPage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildHorizontalCardList(latestSeries),
            const SizedBox(height: 24),

            _buildSectionHeaderWithAction(
              FontAwesomeIcons.satellite, "TV Show",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TvShowPage())).then((_) => refreshHistory()),
            ),
            const SizedBox(height: 12),
            _buildHorizontalCardList(tvShow),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Row(
      children: [
        FaIcon(icon, color: AppColors.primary, size: 16),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.white)),
      ],
    );
  }

  Widget _buildSectionHeaderWithAction(IconData icon, String title, {required VoidCallback onTap}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(children: [
          FaIcon(icon, color: AppColors.primary, size: 16),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.white)),
        ]),
        GestureDetector(
          onTap: onTap,
          child: const Row(children: [
            Text("Lihat Semua", style: TextStyle(color: AppColors.primary, fontSize: 12)),
            SizedBox(width: 4),
            FaIcon(FontAwesomeIcons.chevronRight, color: AppColors.primary, size: 10),
          ]),
        ),
      ],
    );
  }

  Widget _buildEmptyHistory() {
    return Container(
      height: 100,
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          FaIcon(FontAwesomeIcons.film, color: AppColors.greyDark, size: 28),
          SizedBox(height: 8),
          Text("Belum ada riwayat tontonan", style: TextStyle(color: AppColors.grey, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildHistoryList() {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _watchHistory.length,
        itemBuilder: (context, index) {
          final anime = _watchHistory[index];
          return _buildHistoryCard(anime);
        },
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> anime) {
    return Container(
      width: 110,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () {
          if (anime['last_watched_episode_slug'] != null) {
            Navigator.push(context, MaterialPageRoute(
              builder: (_) => AnimeEpisodePage(
                episodeSlug: anime['last_watched_episode_slug'],
                animeId: anime['id'],
                animeTitle: anime['title'],
                animePoster: anime['poster'],
                animeType: anime['type'] ?? 'anime',
                onHistoryUpdate: refreshHistory,
              ),
            )).then((_) => refreshHistory());
          }
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: _buildNetworkImage(anime['poster'] ?? '', height: 155, width: 110),
                ),
                Positioned(
                  bottom: 0, left: 0, right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black87],
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(6),
                        bottomRight: Radius.circular(6),
                      ),
                    ),
                    child: Text(
                      anime['last_watched_episode'] ?? '',
                      style: const TextStyle(color: AppColors.primary, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Positioned(
                  top: 6, right: 6,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.85), shape: BoxShape.circle),
                    child: const FaIcon(FontAwesomeIcons.play, color: Colors.black, size: 8),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(anime['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 11, fontWeight: FontWeight.w500), maxLines: 2, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAccessGrid() {
    final items = [
      {'icon': FontAwesomeIcons.tags, 'label': 'Genre', 'page': const AnimeGenreListPage()},
      {'icon': FontAwesomeIcons.calendarDays, 'label': 'Jadwal', 'page': const AnimeSchedulePage()},
      {'icon': FontAwesomeIcons.circlePlay, 'label': 'Ongoing', 'page': const OngoingPage()},
      {'icon': FontAwesomeIcons.circleCheck, 'label': 'Completed', 'page': const CompletedPage()},
      {'icon': FontAwesomeIcons.rankingStar, 'label': 'Populer', 'page': const PopulerPage()},
      {'icon': FontAwesomeIcons.film, 'label': 'Film', 'page': const FilmListPage()},
      {'icon': FontAwesomeIcons.tv, 'label': 'Series', 'page': const SeriesListPage()},
      {'icon': FontAwesomeIcons.star, 'label': 'TV Show', 'page': const TvShowPage()},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.9,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item['page'] as Widget)).then((_) => refreshHistory()),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FaIcon(item['icon'] as IconData, color: AppColors.primary, size: 20),
                const SizedBox(height: 6),
                Text(item['label'] as String, style: const TextStyle(color: AppColors.white, fontSize: 10, fontWeight: FontWeight.w500), textAlign: TextAlign.center),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTop10List(List<dynamic> list) {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: list.length,
        itemBuilder: (context, index) {
          final item = list[index];
          return GestureDetector(
            onTap: () => _navigateToDetail(context, item),
            child: Container(
              width: 110,
              margin: const EdgeInsets.only(right: 12),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: _buildNetworkImage(item['image'] ?? '', height: 200, width: 110),
                  ),
                  Positioned(
                    top: 0, left: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(6), bottomRight: Radius.circular(6)),
                      ),
                      child: Text(item['rank'] ?? '', style: const TextStyle(color: Colors.black, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter, end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black87],
                        ),
                        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(6), bottomRight: Radius.circular(6)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (item['rating'] != null && item['rating'].toString().isNotEmpty && item['rating'].toString() != '0')
                            Row(children: [
                              const FaIcon(FontAwesomeIcons.star, color: AppColors.amber, size: 9),
                              const SizedBox(width: 3),
                              Text(item['rating'].toString(), style: const TextStyle(color: AppColors.white, fontSize: 9)),
                            ]),
                          Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 10, fontWeight: FontWeight.w500), maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHorizontalCardList(List<dynamic> list) {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: list.length,
        itemBuilder: (context, index) {
          final item = list[index];
          return GestureDetector(
            onTap: () => _navigateToDetail(context, item),
            child: Container(
              width: 110,
              margin: const EdgeInsets.only(right: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: _buildNetworkImage(item['image'] ?? '', height: 155, width: 110),
                      ),
                      if (item['episode'] != null && item['episode'].toString().isNotEmpty)
                        Positioned(
                          bottom: 4, left: 4,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                            decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(4)),
                            child: Text(item['episode'].toString(), style: const TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      Positioned(
                        top: 4, right: 4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                          decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(4)),
                          child: _buildTypeIcon(item['type'] ?? 'anime'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 10, fontWeight: FontWeight.w500), maxLines: 2, overflow: TextOverflow.ellipsis),
                  if (item['time'] != null)
                    Text(item['time'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 9)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTypeIcon(String type) {
    IconData icon;
    switch (type.toLowerCase()) {
      case 'film': icon = FontAwesomeIcons.film; break;
      case 'series': icon = FontAwesomeIcons.photoFilm; break;
      default: icon = FontAwesomeIcons.tv;
    }
    return FaIcon(icon, color: AppColors.primary, size: 8);
  }

  Widget _buildSearchResults() {
    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            FaIcon(FontAwesomeIcons.magnifyingGlass, color: AppColors.greyDark, size: 48),
            SizedBox(height: 16),
            Text("Tidak ada hasil", style: TextStyle(color: AppColors.grey, fontSize: 16)),
            SizedBox(height: 8),
            Text("Coba kata kunci lain", style: TextStyle(color: AppColors.greyDark, fontSize: 13)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: searchResults.length,
      itemBuilder: (context, index) {
        final item = searchResults[index];
        return _buildSearchCard(item);
      },
    );
  }

  Widget _buildSearchCard(Map<String, dynamic> item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: InkWell(
        onTap: () => _navigateToDetail(context, item),
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: _buildNetworkImage(item['image'] ?? '', height: 100, width: 70),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['title'] ?? '', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.white), maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 6),
                    Row(children: [
                      _buildTypeBadge(item['type'] ?? 'anime'),
                      if (item['rating'] != null && item['rating'].toString().isNotEmpty && item['rating'].toString() != '-') ...[
                        const SizedBox(width: 8),
                        const FaIcon(FontAwesomeIcons.star, color: AppColors.amber, size: 11),
                        const SizedBox(width: 3),
                        Text(item['rating'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 11)),
                      ],
                    ]),
                    if (item['description'] != null && item['description'].toString().isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(item['description'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
                    ],
                  ],
                ),
              ),
              const FaIcon(FontAwesomeIcons.chevronRight, color: AppColors.greyDark, size: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTypeBadge(String type) {
    Color color;
    switch (type.toLowerCase()) {
      case 'film': color = Colors.blue; break;
      case 'series': color = Colors.orange; break;
      default: color = AppColors.primary;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(4), border: Border.all(color: color.withOpacity(0.5))),
      child: Text(type.toUpperCase(), style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildHorizontalShimmer() {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 5,
        itemBuilder: (_, __) => Shimmer.fromColors(
          baseColor: AppColors.card,
          highlightColor: AppColors.cardBorder,
          child: Container(width: 110, margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(6))),
        ),
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: List.generate(4, (_) => Padding(
          padding: const EdgeInsets.only(bottom: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Shimmer.fromColors(
                baseColor: AppColors.card, highlightColor: AppColors.cardBorder,
                child: Container(height: 16, width: 120, decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(4))),
              ),
              const SizedBox(height: 12),
              SizedBox(height: 180, child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: 5,
                itemBuilder: (_, __) => Shimmer.fromColors(
                  baseColor: AppColors.card, highlightColor: AppColors.cardBorder,
                  child: Container(width: 110, margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(6))),
                ),
              )),
            ],
          ),
        )),
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const FaIcon(FontAwesomeIcons.triangleExclamation, color: AppColors.grey, size: 48),
          const SizedBox(height: 16),
          const Text("Gagal memuat data", style: TextStyle(color: AppColors.grey, fontSize: 16)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () async { setState(() => isLoading = true); await Future.wait([fetchHomeData(), _loadWatchHistory()]); },
            icon: const FaIcon(FontAwesomeIcons.arrowsRotate, size: 14),
            label: const Text("Coba Lagi"),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black),
          ),
        ],
      ),
    );
  }

  void _navigateToDetail(BuildContext context, Map<String, dynamic> item) {
    final type = item['type'] ?? 'anime';
    final id = item['id'] ?? '';
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => AnimeDetailPage(slug: id, type: type, onHistoryUpdate: refreshHistory),
    )).then((_) => refreshHistory());
  }
}

class AnimeDetailPage extends StatefulWidget {
  final String slug;
  final String type;
  final Function()? onHistoryUpdate;

  const AnimeDetailPage({super.key, required this.slug, required this.type, this.onHistoryUpdate});

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  Map<String, dynamic>? detailData;
  bool isLoading = true;
  bool isError = false;

  @override
  void initState() {
    super.initState();
    fetchDetail();
  }

  Future<void> fetchDetail() async {
    try {
      String endpoint;
      switch (widget.type.toLowerCase()) {
        case 'film': endpoint = 'film'; break;
        case 'series': endpoint = 'series'; break;
        default: endpoint = 'anime';
      }
      final response = await http.get(Uri.parse('$_baseUrl/$endpoint/${widget.slug}'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() { detailData = jsonData['data']; isLoading = false; });
      } else {
        setState(() { isLoading = false; isError = true; });
      }
    } catch (e) {
      setState(() { isLoading = false; isError = true; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(detailData?['title'] ?? 'Detail', style: const TextStyle(color: AppColors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: isLoading
          ? _buildShimmer()
          : isError || detailData == null
              ? _buildError()
              : _buildDetail(),
    );
  }

  Widget _buildShimmer() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: List.generate(5, (_) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Shimmer.fromColors(
          baseColor: AppColors.card, highlightColor: AppColors.cardBorder,
          child: Container(height: 60, width: double.infinity, decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(8))),
        ),
      ))),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const FaIcon(FontAwesomeIcons.triangleExclamation, color: AppColors.grey, size: 48),
          const SizedBox(height: 16),
          const Text("Gagal memuat detail", style: TextStyle(color: AppColors.grey)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () { setState(() { isLoading = true; isError = false; }); fetchDetail(); },
            icon: const FaIcon(FontAwesomeIcons.arrowsRotate, size: 14),
            label: const Text("Coba Lagi"),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black),
          ),
        ],
      ),
    );
  }

  Widget _buildDetail() {
    final anime = detailData!;
    final episodes = anime['episodes'] as List<dynamic>? ?? [];
    final recommendations = anime['recommendations'] as List<dynamic>? ?? [];
    final genres = (anime['info']?['genres'] as List<dynamic>?) ?? [];
    final downloads = anime['downloads'] as List<dynamic>? ?? [];
    final streamOptions = anime['stream_options'] as Map<String, dynamic>? ?? {};

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              _buildNetworkImage(anime['image'] ?? '', height: 280, width: double.infinity),
              Container(
                height: 280,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.transparent, AppColors.background],
                  ),
                ),
              ),
              Positioned(
                bottom: 16, left: 16, right: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(anime['title'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.white), maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 8),
                    Row(children: [
                      if (anime['info']?['rating'] != null && anime['info']['rating'] != '0') ...[
                        const FaIcon(FontAwesomeIcons.star, color: AppColors.amber, size: 12),
                        const SizedBox(width: 4),
                        Text(anime['info']['rating'].toString(), style: const TextStyle(color: AppColors.white, fontSize: 12)),
                        const SizedBox(width: 12),
                      ],
                      _buildTypeBadge(widget.type),
                      if (anime['info']?['season'] != null && anime['info']['season'] != '-') ...[
                        const SizedBox(width: 8),
                        Text(anime['info']['season'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 12)),
                      ],
                    ]),
                  ],
                ),
              ),
            ],
          ),

          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInfoSection(anime['info'] ?? {}),
                const SizedBox(height: 20),

                if (genres.isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.tags, "Genre"),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: genres.map<Widget>((g) {
                      final genreId = g['url'].toString().split('/').where((s) => s.isNotEmpty).last;
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeGenrePage(genreSlug: genreId, genreName: g['name']))),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.primary.withOpacity(0.4))),
                          child: Text(g['name'], style: const TextStyle(color: AppColors.primary, fontSize: 12)),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                ],

                if (anime['synopsis'] != null && anime['synopsis'].toString().isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.alignLeft, "Sinopsis"),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                    child: Text(anime['synopsis'], style: const TextStyle(color: AppColors.grey, height: 1.6, fontSize: 13), textAlign: TextAlign.justify),
                  ),
                  const SizedBox(height: 20),
                ],

                if (streamOptions.isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.play, "Streaming"),
                  const SizedBox(height: 10),
                  ...streamOptions.entries.map((entry) {
                    final servers = entry.value as List<dynamic>? ?? [];
                    if (servers.isEmpty) return const SizedBox.shrink();
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (entry.key.isNotEmpty)
                          Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(entry.key, style: const TextStyle(color: AppColors.grey, fontSize: 12))),
                        Wrap(
                          spacing: 8, runSpacing: 8,
                          children: servers.map<Widget>((s) {
                            return ElevatedButton.icon(
                              onPressed: () {
                                Navigator.push(context, MaterialPageRoute(
                                  builder: (_) => AnimeEpisodePage(
                                    episodeSlug: '${s['post']}_${s['nume']}_${s['type']}',
                                    animeId: widget.slug,
                                    animeTitle: anime['title'],
                                    animePoster: anime['image'],
                                    animeType: widget.type,
                                    streamPost: s['post']?.toString(),
                                    streamNume: s['nume']?.toString(),
                                    streamType: s['type']?.toString(),
                                    onHistoryUpdate: widget.onHistoryUpdate,
                                  ),
                                ));
                              },
                              icon: const FaIcon(FontAwesomeIcons.play, size: 10),
                              label: Text(s['server'] ?? ''),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary, foregroundColor: Colors.black,
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 12),
                      ],
                    );
                  }),
                  const SizedBox(height: 8),
                ],

                if (episodes.isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.listOl, "Episode (${episodes.length})"),
                  const SizedBox(height: 10),
                  ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: episodes.length,
                    itemBuilder: (context, index) {
                      final ep = episodes[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.cardBorder)),
                        child: ListTile(
                          leading: Container(
                            width: 36, height: 36,
                            decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(6)),
                            child: const Center(child: FaIcon(FontAwesomeIcons.play, color: Colors.black, size: 12)),
                          ),
                          title: Text(ep['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 13)),
                          trailing: const FaIcon(FontAwesomeIcons.chevronRight, color: AppColors.greyDark, size: 12),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (_) => AnimeEpisodePage(
                                episodeSlug: ep['id'],
                                animeId: widget.slug,
                                animeTitle: anime['title'],
                                animePoster: anime['image'],
                                animeType: widget.type,
                                allEpisodes: episodes,
                                onHistoryUpdate: widget.onHistoryUpdate,
                              ),
                            )).then((_) { if (widget.onHistoryUpdate != null) widget.onHistoryUpdate!(); });
                          },
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                ],

                if (downloads.isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.download, "Download"),
                  const SizedBox(height: 10),
                  ...downloads.map<Widget>((dl) {
                    final links = dl['links'] as List<dynamic>? ?? [];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            const FaIcon(FontAwesomeIcons.film, color: AppColors.primary, size: 12),
                            const SizedBox(width: 6),
                            Text(dl['resolution'] ?? '', style: const TextStyle(color: AppColors.primary, fontSize: 13, fontWeight: FontWeight.bold)),
                          ]),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8, runSpacing: 8,
                            children: links.map<Widget>((link) {
                              return OutlinedButton.icon(
                                onPressed: () async {
                                  final uri = Uri.parse(link['url']);
                                  if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
                                },
                                icon: const FaIcon(FontAwesomeIcons.download, size: 10),
                                label: Text(link['server'] ?? ''),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: AppColors.primary,
                                  side: const BorderSide(color: AppColors.primary, width: 1),
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  textStyle: const TextStyle(fontSize: 11),
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    );
                  }),
                  const SizedBox(height: 20),
                ],

                if (recommendations.isNotEmpty) ...[
                  _buildSectionTitle(FontAwesomeIcons.thumbsUp, "Rekomendasi"),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 200,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: recommendations.length,
                      itemBuilder: (context, index) {
                        final rec = recommendations[index];
                        if (index > 0) {
                          final prev = recommendations[index - 1];
                          if (rec['id'] == prev['id']) return const SizedBox.shrink();
                        }
                        return GestureDetector(
                          onTap: () => Navigator.push(context, MaterialPageRoute(
                            builder: (_) => AnimeDetailPage(slug: rec['id'], type: rec['type'] ?? 'anime', onHistoryUpdate: widget.onHistoryUpdate),
                          )),
                          child: Container(
                            width: 110,
                            margin: const EdgeInsets.only(right: 12),
                            child: Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: _buildNetworkImage(rec['image'] ?? '', height: 155, width: 110),
                                ),
                                const SizedBox(height: 5),
                                Text(rec['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 10), maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoSection(Map<String, dynamic> info) {
    final rows = [
      if (info['status'] != null && info['status'] != '-') {'label': 'Status', 'value': info['status'], 'icon': FontAwesomeIcons.circleInfo},
      if (info['type'] != null && info['type'] != '-') {'label': 'Tipe', 'value': info['type'], 'icon': FontAwesomeIcons.film},
      if (info['episodes_count'] != null && info['episodes_count'] != '-') {'label': 'Episode', 'value': info['episodes_count'], 'icon': FontAwesomeIcons.listOl},
      if (info['duration'] != null && info['duration'] != '-') {'label': 'Durasi', 'value': info['duration'], 'icon': FontAwesomeIcons.clock},
      if (info['studio'] != null && info['studio'] != '-') {'label': 'Studio', 'value': info['studio'], 'icon': FontAwesomeIcons.building},
      if (info['release_date'] != null && info['release_date'] != '-') {'label': 'Rilis', 'value': info['release_date'], 'icon': FontAwesomeIcons.calendarDays},
    ];
    if (rows.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
      child: Column(
        children: rows.map((row) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            FaIcon(row['icon'] as IconData, color: AppColors.primary, size: 12),
            const SizedBox(width: 8),
            Text('${row['label']}: ', style: const TextStyle(color: AppColors.grey, fontSize: 12)),
            Expanded(child: Text(row['value'].toString(), style: const TextStyle(color: AppColors.white, fontSize: 12, fontWeight: FontWeight.w500), overflow: TextOverflow.ellipsis)),
          ]),
        )).toList(),
      ),
    );
  }

  Widget _buildSectionTitle(IconData icon, String title) {
    return Row(children: [
      FaIcon(icon, color: AppColors.primary, size: 14),
      const SizedBox(width: 8),
      Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.white)),
    ]);
  }

  Widget _buildTypeBadge(String type) {
    Color color;
    switch (type.toLowerCase()) {
      case 'film': color = Colors.blue; break;
      case 'series': color = Colors.orange; break;
      default: color = AppColors.primary;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(4), border: Border.all(color: color.withOpacity(0.5))),
      child: Text(type.toUpperCase(), style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold)),
    );
  }
}

class AnimeEpisodePage extends StatefulWidget {
  final String episodeSlug;
  final String? animeId;
  final String? animeTitle;
  final String? animePoster;
  final String? animeType;
  final List<dynamic>? allEpisodes;
  final Function()? onHistoryUpdate;
  final String? streamPost;
  final String? streamNume;
  final String? streamType;

  const AnimeEpisodePage({
    super.key,
    required this.episodeSlug,
    this.animeId,
    this.animeTitle,
    this.animePoster,
    this.animeType,
    this.allEpisodes,
    this.onHistoryUpdate,
    this.streamPost,
    this.streamNume,
    this.streamType,
  });

  @override
  State<AnimeEpisodePage> createState() => _AnimeEpisodePageState();
}

class _AnimeEpisodePageState extends State<AnimeEpisodePage> with WidgetsBindingObserver {
  Map<String, dynamic>? episodeData;
  bool isLoading = true;
  bool isError = false;
  bool _isFullScreen = false;
  bool _isWebViewLoading = true;
  String? _embedUrl;
  late WebViewController _webViewController;

  List<dynamic> _streams = [];
  int _selectedStreamIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.streamPost != null) {
      _fetchServerEmbed(widget.streamPost!, widget.streamNume!, widget.streamType!);
      _addToHistory(widget.animeTitle ?? '', null);
    } else {
      fetchEpisodeData();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  Future<void> fetchEpisodeData() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/episode/${widget.episodeSlug}'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          episodeData = jsonData['data'];
          _streams = episodeData?['streams'] ?? [];
          isLoading = false;
        });
        if (_streams.isNotEmpty) {
          final s = _streams[0]['data'];
          await _fetchServerEmbed(s['post'].toString(), s['nume'].toString(), s['type'].toString());
        }
        await _addToHistory(episodeData?['title'] ?? '', episodeData);
      } else {
        setState(() { isLoading = false; isError = true; });
      }
    } catch (e) {
      setState(() { isLoading = false; isError = true; });
    }
  }

  Future<void> _fetchServerEmbed(String post, String nume, String type) async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/server?post=$post&nume=$nume&type=$type'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final url = jsonData['embed_url'] ?? '';
        setState(() { _embedUrl = url; isLoading = false; });
        _initWebView(url);
      }
    } catch (e) {
      setState(() { isLoading = false; });
    }
  }

  void _initWebView(String url) {
    if (url.isEmpty) return;
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel('FS', onMessageReceived: (msg) {
        if (msg.message == 'enter') _enterFS();
        else if (msg.message == 'exit') _exitFS();
      })
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (p) { if (p == 100) setState(() => _isWebViewLoading = false); },
        onPageStarted: (_) => setState(() => _isWebViewLoading = true),
        onPageFinished: (_) { setState(() => _isWebViewLoading = false); _injectFS(); },
        onNavigationRequest: (_) => NavigationDecision.navigate,
      ))
      ..loadRequest(Uri.parse(url), headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      });
  }

  void _injectFS() {
    _webViewController.runJavaScript('''
      function handleFS() {
        if (document.fullscreenElement||document.webkitFullscreenElement) FS.postMessage('enter');
        else FS.postMessage('exit');
      }
      document.addEventListener('fullscreenchange', handleFS);
      document.addEventListener('webkitfullscreenchange', handleFS);
    ''');
  }

  void _enterFS() { setState(() => _isFullScreen = true); SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]); SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky); }
  void _exitFS() { setState(() => _isFullScreen = false); SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]); SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge); }

  Future<void> _addToHistory(String title, Map<String, dynamic>? ep) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      var history = historyJson.map((i) => Map<String, dynamic>.from(json.decode(i))).toList();
      final item = {
        'id': widget.animeId,
        'title': widget.animeTitle,
        'poster': widget.animePoster,
        'type': widget.animeType ?? 'anime',
        'last_watched_episode': title,
        'last_watched_episode_slug': widget.episodeSlug,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      history.removeWhere((h) => h['id'] == widget.animeId);
      history.insert(0, item);
      if (history.length > 20) history = history.sublist(0, 20);
      await prefs.setStringList('watch_history', history.map((i) => json.encode(i)).toList());
      if (widget.onHistoryUpdate != null) widget.onHistoryUpdate!();
    } catch (e) {}
  }

  Future<void> _changeServer(int index) async {
    setState(() { _selectedStreamIndex = index; _isWebViewLoading = true; _embedUrl = null; });
    final s = _streams[index]['data'];
    await _fetchServerEmbed(s['post'].toString(), s['nume'].toString(), s['type'].toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: _isFullScreen ? null : AppBar(
        title: Text(episodeData?['title'] ?? widget.animeTitle ?? 'Streaming', style: const TextStyle(color: AppColors.white, fontSize: 14), maxLines: 1, overflow: TextOverflow.ellipsis),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
        actions: [
          if (_embedUrl != null)
            IconButton(
              icon: const FaIcon(FontAwesomeIcons.arrowsRotate, color: AppColors.primary, size: 16),
              onPressed: () { setState(() => _isWebViewLoading = true); _webViewController.reload(); },
            ),
          if (_embedUrl != null)
            IconButton(
              icon: const FaIcon(FontAwesomeIcons.upRightFromSquare, color: AppColors.primary, size: 14),
              onPressed: () async {
                if (_embedUrl != null) {
                  final uri = Uri.parse(_embedUrl!);
                  if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
                }
              },
            ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : isError
              ? _buildError()
              : _buildContent(),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const FaIcon(FontAwesomeIcons.triangleExclamation, color: AppColors.grey, size: 48),
        const SizedBox(height: 16),
        const Text("Gagal memuat episode", style: TextStyle(color: AppColors.grey)),
        const SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: () { setState(() { isLoading = true; isError = false; }); fetchEpisodeData(); },
          icon: const FaIcon(FontAwesomeIcons.arrowsRotate, size: 14),
          label: const Text("Coba Lagi"),
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black),
        ),
      ]),
    );
  }

  Widget _buildContent() {
    final allEps = widget.allEpisodes ?? (episodeData?['all_episodes'] as List<dynamic>? ?? []);
    final downloads = episodeData?['downloads'] as List<dynamic>? ?? [];

    return Column(
      children: [
        Container(
          height: _isFullScreen ? MediaQuery.of(context).size.height : MediaQuery.of(context).size.height * 0.3,
          width: double.infinity,
          color: Colors.black,
          child: Stack(
            children: [
              if (_embedUrl != null)
                WebViewWidget(controller: _webViewController)
              else
                const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  CircularProgressIndicator(color: AppColors.primary),
                  SizedBox(height: 12),
                  Text("Memuat player...", style: TextStyle(color: AppColors.grey, fontSize: 12)),
                ])),
              if (_isWebViewLoading)
                Container(color: Colors.black87, child: const Center(child: CircularProgressIndicator(color: AppColors.primary))),
              if (_isFullScreen)
                Positioned(
                  top: 40, right: 16,
                  child: IconButton(
                    onPressed: _exitFS,
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                      child: const FaIcon(FontAwesomeIcons.compress, color: AppColors.primary, size: 20),
                    ),
                  ),
                ),
            ],
          ),
        ),

        if (!_isFullScreen) Expanded(
          child: DefaultTabController(
            length: 3,
            child: Column(
              children: [
                if (_streams.isNotEmpty)
                  Container(
                    color: AppColors.surface,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _streams.asMap().entries.map((entry) {
                          final i = entry.key;
                          final s = entry.value;
                          final isSelected = i == _selectedStreamIndex;
                          return GestureDetector(
                            onTap: () => _changeServer(i),
                            child: Container(
                              margin: const EdgeInsets.only(right: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: isSelected ? AppColors.primary : AppColors.card,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: isSelected ? AppColors.primary : AppColors.cardBorder),
                              ),
                              child: Text(
                                '${s['resolution']} - ${s['server']}',
                                style: TextStyle(color: isSelected ? Colors.black : AppColors.grey, fontSize: 10, fontWeight: FontWeight.bold),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),

                Container(
                  color: AppColors.surface,
                  child: TabBar(
                    indicatorColor: AppColors.primary,
                    labelColor: AppColors.primary,
                    unselectedLabelColor: AppColors.grey,
                    tabs: const [
                      Tab(icon: FaIcon(FontAwesomeIcons.listOl, size: 14), text: 'Episode'),
                      Tab(icon: FaIcon(FontAwesomeIcons.download, size: 14), text: 'Download'),
                      Tab(icon: FaIcon(FontAwesomeIcons.circleInfo, size: 14), text: 'Info'),
                    ],
                  ),
                ),

                Expanded(
                  child: TabBarView(
                    children: [
                      allEps.isEmpty
                          ? const Center(child: Text("Tidak ada episode", style: TextStyle(color: AppColors.grey)))
                          : ListView.builder(
                              padding: const EdgeInsets.all(8),
                              itemCount: allEps.length,
                              itemBuilder: (context, index) {
                                final ep = allEps[index];
                                final isActive = ep['active'] == true || ep['id'] == widget.episodeSlug;
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 6),
                                  decoration: BoxDecoration(
                                    color: isActive ? AppColors.primary : AppColors.card,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(color: isActive ? AppColors.primary : AppColors.cardBorder),
                                  ),
                                  child: ListTile(
                                    leading: FaIcon(isActive ? FontAwesomeIcons.play : FontAwesomeIcons.circlePlay, color: isActive ? Colors.black : AppColors.primary, size: 16),
                                    title: Text(ep['title'] ?? '', style: TextStyle(color: isActive ? Colors.black : AppColors.white, fontSize: 12, fontWeight: isActive ? FontWeight.bold : FontWeight.normal)),
                                    onTap: isActive ? null : () {
                                      Navigator.pushReplacement(context, MaterialPageRoute(
                                        builder: (_) => AnimeEpisodePage(
                                          episodeSlug: ep['id'],
                                          animeId: widget.animeId,
                                          animeTitle: widget.animeTitle,
                                          animePoster: widget.animePoster,
                                          animeType: widget.animeType,
                                          allEpisodes: widget.allEpisodes,
                                          onHistoryUpdate: widget.onHistoryUpdate,
                                        ),
                                      ));
                                    },
                                  ),
                                );
                              },
                            ),

                      downloads.isEmpty
                          ? const Center(child: Text("Tidak ada link download", style: TextStyle(color: AppColors.grey)))
                          : ListView.builder(
                              padding: const EdgeInsets.all(12),
                              itemCount: downloads.length,
                              itemBuilder: (context, index) {
                                final dl = downloads[index];
                                final links = dl['links'] as List<dynamic>? ?? [];
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [
                                        const FaIcon(FontAwesomeIcons.film, color: AppColors.primary, size: 12),
                                        const SizedBox(width: 6),
                                        Text(dl['resolution'] ?? '', style: const TextStyle(color: AppColors.primary, fontSize: 13, fontWeight: FontWeight.bold)),
                                      ]),
                                      const SizedBox(height: 8),
                                      Wrap(
                                        spacing: 8, runSpacing: 8,
                                        children: links.map<Widget>((link) => OutlinedButton.icon(
                                          onPressed: () async {
                                            final uri = Uri.parse(link['url']);
                                            if (await canLaunchUrl(uri)) launchUrl(uri, mode: LaunchMode.externalApplication);
                                          },
                                          icon: const FaIcon(FontAwesomeIcons.download, size: 9),
                                          label: Text(link['server'] ?? ''),
                                          style: OutlinedButton.styleFrom(
                                            foregroundColor: AppColors.primary,
                                            side: const BorderSide(color: AppColors.primary),
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                            textStyle: const TextStyle(fontSize: 10),
                                          ),
                                        )).toList(),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),

                      SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (widget.animePoster != null)
                              Row(children: [
                                ClipRRect(borderRadius: BorderRadius.circular(6), child: _buildNetworkImage(widget.animePoster!, height: 80, width: 55)),
                                const SizedBox(width: 12),
                                Expanded(child: Text(widget.animeTitle ?? '', style: const TextStyle(color: AppColors.white, fontSize: 14, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis)),
                              ]),
                            if (episodeData?['navigation'] != null) ...[
                              const SizedBox(height: 16),
                              Row(children: [
                                if (episodeData!['navigation']['prev'] != null)
                                  Expanded(child: OutlinedButton.icon(
                                    onPressed: () {
                                      Navigator.pushReplacement(context, MaterialPageRoute(
                                        builder: (_) => AnimeEpisodePage(
                                          episodeSlug: episodeData!['navigation']['prev']['id'],
                                          animeId: widget.animeId,
                                          animeTitle: widget.animeTitle,
                                          animePoster: widget.animePoster,
                                          animeType: widget.animeType,
                                          onHistoryUpdate: widget.onHistoryUpdate,
                                        ),
                                      ));
                                    },
                                    icon: const FaIcon(FontAwesomeIcons.chevronLeft, size: 10),
                                    label: const Text("Prev"),
                                    style: OutlinedButton.styleFrom(foregroundColor: AppColors.primary, side: const BorderSide(color: AppColors.primary)),
                                  )),
                                if (episodeData!['navigation']['prev'] != null && episodeData!['navigation']['next'] != null)
                                  const SizedBox(width: 12),
                                if (episodeData!['navigation']['next'] != null)
                                  Expanded(child: ElevatedButton.icon(
                                    onPressed: () {
                                      Navigator.pushReplacement(context, MaterialPageRoute(
                                        builder: (_) => AnimeEpisodePage(
                                          episodeSlug: episodeData!['navigation']['next']['id'],
                                          animeId: widget.animeId,
                                          animeTitle: widget.animeTitle,
                                          animePoster: widget.animePoster,
                                          animeType: widget.animeType,
                                          onHistoryUpdate: widget.onHistoryUpdate,
                                        ),
                                      ));
                                    },
                                    icon: const FaIcon(FontAwesomeIcons.chevronRight, size: 10),
                                    label: const Text("Next"),
                                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black),
                                  )),
                              ]),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class AnimeGenreListPage extends StatefulWidget {
  const AnimeGenreListPage({super.key});

  @override
  State<AnimeGenreListPage> createState() => _AnimeGenreListPageState();
}

class _AnimeGenreListPageState extends State<AnimeGenreListPage> {
  List<dynamic> genres = [];
  bool isLoading = true;

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch() async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/genres'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() { genres = jsonData['data'] ?? []; isLoading = false; });
      } else { setState(() => isLoading = false); }
    } catch (e) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Row(children: [FaIcon(FontAwesomeIcons.tags, color: AppColors.primary, size: 16), SizedBox(width: 8), Text("Genre", style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold))]),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: isLoading
          ? _buildShimmer()
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: genres.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.5, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemBuilder: (context, index) {
                final genre = genres[index];
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeGenrePage(genreSlug: genre['slug'] ?? '', genreName: genre['name'] ?? ''))),
                  child: Container(
                    decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(children: [
                        const FaIcon(FontAwesomeIcons.tag, color: AppColors.primary, size: 12),
                        const SizedBox(width: 8),
                        Expanded(child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(genre['name'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 13, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
                            Text('${genre['count'] ?? 0} judul', style: const TextStyle(color: AppColors.grey, fontSize: 10)),
                          ],
                        )),
                      ]),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget _buildShimmer() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 20,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.5, crossAxisSpacing: 12, mainAxisSpacing: 12),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: AppColors.card, highlightColor: AppColors.cardBorder,
        child: Container(decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10))),
      ),
    );
  }
}

class AnimeGenrePage extends StatefulWidget {
  final String genreSlug;
  final String genreName;

  const AnimeGenrePage({super.key, required this.genreSlug, required this.genreName});

  @override
  State<AnimeGenrePage> createState() => _AnimeGenrePageState();
}

class _AnimeGenrePageState extends State<AnimeGenrePage> {
  List<dynamic> data = [];
  Map<String, dynamic>? pagination;
  bool isLoading = true;
  int currentPage = 1;

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch({int page = 1}) async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse('$_baseUrl/genre/${widget.genreSlug}?page=$page'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() { data = jsonData['data'] ?? []; pagination = jsonData['pagination']; isLoading = false; currentPage = page; });
      } else { setState(() => isLoading = false); }
    } catch (e) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text("Genre: ${widget.genreName}", style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: isLoading
          ? _buildShimmer()
          : Column(
              children: [
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: data.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.6, crossAxisSpacing: 10, mainAxisSpacing: 10),
                    itemBuilder: (context, index) {
                      final item = data[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeDetailPage(slug: item['id'] ?? '', type: item['type'] ?? 'anime'))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: _buildNetworkImage(item['image'] ?? '', height: double.infinity, width: double.infinity),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 10, fontWeight: FontWeight.w500), maxLines: 2, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                _buildPagination(),
              ],
            ),
    );
  }

  Widget _buildPagination() {
    if (pagination == null) return const SizedBox.shrink();
    final hasNext = pagination!['has_next_page'] == true;
    final hasPrev = pagination!['has_prev_page'] == true;
    return Container(
      padding: const EdgeInsets.all(16),
      color: AppColors.surface,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (hasPrev) OutlinedButton.icon(onPressed: () => _fetch(page: currentPage - 1), icon: const FaIcon(FontAwesomeIcons.chevronLeft, size: 10), label: const Text("Prev"), style: OutlinedButton.styleFrom(foregroundColor: AppColors.primary, side: const BorderSide(color: AppColors.primary))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text("$currentPage / ${pagination!['total_pages']}", style: const TextStyle(color: AppColors.grey))),
          if (hasNext) ElevatedButton.icon(onPressed: () => _fetch(page: currentPage + 1), icon: const FaIcon(FontAwesomeIcons.chevronRight, size: 10), label: const Text("Next"), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black)),
        ],
      ),
    );
  }

  Widget _buildShimmer() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 12,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.6, crossAxisSpacing: 10, mainAxisSpacing: 10),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: AppColors.card, highlightColor: AppColors.cardBorder,
        child: Container(decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(6))),
      ),
    );
  }
}

class AnimeSchedulePage extends StatefulWidget {
  const AnimeSchedulePage({super.key});
  @override
  State<AnimeSchedulePage> createState() => _AnimeSchedulePageState();
}

class _AnimeSchedulePageState extends State<AnimeSchedulePage> {
  List<dynamic> scheduleData = [];
  List<String> availableDays = ['senin','selasa','rabu','kamis','jumat','sabtu','minggu'];
  String selectedDay = 'senin';
  bool isLoading = true;

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch() async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse('$_baseUrl/schedule?day=$selectedDay'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          scheduleData = jsonData['data'] ?? [];
          availableDays = List<String>.from(jsonData['available_days'] ?? availableDays);
          isLoading = false;
        });
      } else { setState(() => isLoading = false); }
    } catch (e) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Row(children: [FaIcon(FontAwesomeIcons.calendarDays, color: AppColors.primary, size: 16), SizedBox(width: 8), Text("Jadwal", style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold))]),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: availableDays.map((day) {
                  final isSelected = day == selectedDay;
                  return GestureDetector(
                    onTap: () { setState(() => selectedDay = day); _fetch(); },
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primary : AppColors.card,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: isSelected ? AppColors.primary : AppColors.cardBorder),
                      ),
                      child: Text(day[0].toUpperCase() + day.substring(1), style: TextStyle(color: isSelected ? Colors.black : AppColors.grey, fontWeight: FontWeight.bold, fontSize: 12)),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                : scheduleData.isEmpty
                    ? const Center(child: Text("Tidak ada jadwal", style: TextStyle(color: AppColors.grey)))
                    : GridView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: scheduleData.length,
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.58, crossAxisSpacing: 10, mainAxisSpacing: 10),
                        itemBuilder: (context, index) {
                          final item = scheduleData[index];
                          return GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeDetailPage(slug: item['id'] ?? '', type: 'anime'))),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Stack(
                                    children: [
                                      ClipRRect(borderRadius: BorderRadius.circular(6), child: _buildNetworkImage(item['image'] ?? '', height: double.infinity, width: double.infinity)),
                                      if (item['time'] != null && item['time'].toString().isNotEmpty)
                                        Positioned(bottom: 4, right: 4, child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                          decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(4)),
                                          child: Text(item['time'].toString(), style: const TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.bold)),
                                        )),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 9, fontWeight: FontWeight.w500), maxLines: 2, overflow: TextOverflow.ellipsis),
                                if (item['score'] != null && item['score'] != '-')
                                  Row(children: [
                                    const FaIcon(FontAwesomeIcons.star, color: AppColors.amber, size: 8),
                                    const SizedBox(width: 2),
                                    Text(item['score'].toString(), style: const TextStyle(color: AppColors.grey, fontSize: 8)),
                                  ]),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key});
  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  List<dynamic> data = [];
  Map<String, dynamic>? pagination;
  bool isLoading = true;
  int currentPage = 1;
  String _title = '';
  String _order = 'update';
  String _type = '';
  String _status = '';
  final TextEditingController _titleController = TextEditingController();

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch({int page = 1}) async {
    setState(() => isLoading = true);
    try {
      var params = 'page=$page&order=$_order';
      if (_title.isNotEmpty) params += '&title=${Uri.encodeComponent(_title)}';
      if (_type.isNotEmpty) params += '&type=${Uri.encodeComponent(_type)}';
      if (_status.isNotEmpty) params += '&status=${Uri.encodeComponent(_status)}';
      final response = await http.get(Uri.parse('$_baseUrl/catalog?$params'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() { data = jsonData['data'] ?? []; pagination = jsonData['pagination']; isLoading = false; currentPage = page; });
      } else { setState(() => isLoading = false); }
    } catch (e) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Row(children: [FaIcon(FontAwesomeIcons.filter, color: AppColors.primary, size: 16), SizedBox(width: 8), Text("Katalog", style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold))]),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _titleController,
                  style: const TextStyle(color: AppColors.white, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: "Cari judul...",
                    hintStyle: const TextStyle(color: AppColors.grey),
                    prefixIcon: const Padding(padding: EdgeInsets.all(12), child: FaIcon(FontAwesomeIcons.magnifyingGlass, color: AppColors.grey, size: 13)),
                    filled: true, fillColor: AppColors.card,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  onSubmitted: (v) { _title = v; _fetch(); },
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip('Update', _order == 'update', () { _order = 'update'; _fetch(); }),
                      _buildFilterChip('Popular', _order == 'popular', () { _order = 'popular'; _fetch(); }),
                      _buildFilterChip('TV', _type == 'TV', () { _type = _type == 'TV' ? '' : 'TV'; _fetch(); }),
                      _buildFilterChip('Movie', _type == 'Movie', () { _type = _type == 'Movie' ? '' : 'Movie'; _fetch(); }),
                      _buildFilterChip('Airing', _status == 'Currently Airing', () { _status = _status == 'Currently Airing' ? '' : 'Currently Airing'; _fetch(); }),
                      _buildFilterChip('Finished', _status == 'Finished Airing', () { _status = _status == 'Finished Airing' ? '' : 'Finished Airing'; _fetch(); }),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                : data.isEmpty
                    ? const Center(child: Text("Tidak ada hasil", style: TextStyle(color: AppColors.grey)))
                    : GridView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: data.length,
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.6, crossAxisSpacing: 10, mainAxisSpacing: 10),
                        itemBuilder: (context, index) {
                          final item = data[index];
                          return GestureDetector(
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeDetailPage(slug: item['id'] ?? '', type: item['type'] ?? 'anime'))),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(6), child: _buildNetworkImage(item['image'] ?? '', height: double.infinity, width: double.infinity))),
                                const SizedBox(height: 4),
                                Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 9), maxLines: 2, overflow: TextOverflow.ellipsis),
                              ],
                            ),
                          );
                        },
                      ),
          ),
          if (pagination != null) _buildPagination(),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? AppColors.primary : AppColors.cardBorder),
        ),
        child: Text(label, style: TextStyle(color: selected ? Colors.black : AppColors.grey, fontSize: 11, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildPagination() {
    final hasNext = pagination!['has_next_page'] == true;
    final hasPrev = pagination!['has_prev_page'] == true;
    return Container(
      padding: const EdgeInsets.all(12),
      color: AppColors.surface,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        if (hasPrev) OutlinedButton.icon(onPressed: () => _fetch(page: currentPage - 1), icon: const FaIcon(FontAwesomeIcons.chevronLeft, size: 10), label: const Text("Prev"), style: OutlinedButton.styleFrom(foregroundColor: AppColors.primary, side: const BorderSide(color: AppColors.primary))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text("$currentPage / ${pagination!['total_pages']}", style: const TextStyle(color: AppColors.grey))),
        if (hasNext) ElevatedButton.icon(onPressed: () => _fetch(page: currentPage + 1), icon: const FaIcon(FontAwesomeIcons.chevronRight, size: 10), label: const Text("Next"), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black)),
      ]),
    );
  }
}

class _PaginatedListPage extends StatefulWidget {
  final String title;
  final IconData icon;
  final String endpoint;
  final String dataKey;

  const _PaginatedListPage({required this.title, required this.icon, required this.endpoint, required this.dataKey});

  @override
  State<_PaginatedListPage> createState() => _PaginatedListPageState();
}

class _PaginatedListPageState extends State<_PaginatedListPage> {
  List<dynamic> data = [];
  Map<String, dynamic>? pagination;
  bool isLoading = true;
  int currentPage = 1;

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch({int page = 1}) async {
    setState(() => isLoading = true);
    try {
      final url = widget.endpoint.contains('?') ? '${widget.endpoint}&page=$page' : '${widget.endpoint}?page=$page';
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final d = jsonData[widget.dataKey] ?? jsonData['data'] ?? [];
        setState(() { data = d; pagination = jsonData['pagination']; isLoading = false; currentPage = page; });
      } else { setState(() => isLoading = false); }
    } catch (e) { setState(() => isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Row(children: [FaIcon(widget.icon, color: AppColors.primary, size: 16), const SizedBox(width: 8), Text(widget.title, style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold))]),
        backgroundColor: AppColors.surface,
        iconTheme: const IconThemeData(color: AppColors.primary),
        elevation: 0,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : Column(
              children: [
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: data.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.6, crossAxisSpacing: 10, mainAxisSpacing: 10),
                    itemBuilder: (context, index) {
                      final item = data[index];
                      return GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AnimeDetailPage(slug: item['id'] ?? '', type: item['type'] ?? 'anime'))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Stack(children: [
                                ClipRRect(borderRadius: BorderRadius.circular(6), child: _buildNetworkImage(item['image'] ?? '', height: double.infinity, width: double.infinity)),
                                if (item['episode'] != null && item['episode'].toString().isNotEmpty)
                                  Positioned(bottom: 3, left: 3, child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                    decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(3)),
                                    child: Text(item['episode'].toString(), style: const TextStyle(color: Colors.black, fontSize: 7, fontWeight: FontWeight.bold)),
                                  )),
                              ]),
                            ),
                            const SizedBox(height: 4),
                            Text(item['title'] ?? '', style: const TextStyle(color: AppColors.white, fontSize: 9), maxLines: 2, overflow: TextOverflow.ellipsis),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                if (pagination != null) _buildPagination(),
              ],
            ),
    );
  }

  Widget _buildPagination() {
    final hasNext = pagination!['has_next_page'] == true;
    final hasPrev = pagination!['has_prev_page'] == true;
    return Container(
      padding: const EdgeInsets.all(12),
      color: AppColors.surface,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        if (hasPrev) OutlinedButton.icon(onPressed: () => _fetch(page: currentPage - 1), icon: const FaIcon(FontAwesomeIcons.chevronLeft, size: 10), label: const Text("Prev"), style: OutlinedButton.styleFrom(foregroundColor: AppColors.primary, side: const BorderSide(color: AppColors.primary))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text("$currentPage / ${pagination!['total_pages']}", style: const TextStyle(color: AppColors.grey))),
        if (hasNext) ElevatedButton.icon(onPressed: () => _fetch(page: currentPage + 1), icon: const FaIcon(FontAwesomeIcons.chevronRight, size: 10), label: const Text("Next"), style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.black)),
      ]),
    );
  }
}

class UpdatePage extends StatelessWidget {
  const UpdatePage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Anime Update', icon: FontAwesomeIcons.tv, endpoint: '$_baseUrl/update', dataKey: 'data');
}

class LatestPage extends StatelessWidget {
  const LatestPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Latest Added', icon: FontAwesomeIcons.clockRotateLeft, endpoint: '$_baseUrl/latest', dataKey: 'data');
}

class OngoingPage extends StatelessWidget {
  const OngoingPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Ongoing Anime', icon: FontAwesomeIcons.circlePlay, endpoint: '$_baseUrl/ongoing', dataKey: 'data');
}

class CompletedPage extends StatelessWidget {
  const CompletedPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Completed Anime', icon: FontAwesomeIcons.circleCheck, endpoint: '$_baseUrl/completed', dataKey: 'data');
}

class PopulerPage extends StatelessWidget {
  const PopulerPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Populer', icon: FontAwesomeIcons.fire, endpoint: '$_baseUrl/populer', dataKey: 'data');
}

class FilmListPage extends StatelessWidget {
  const FilmListPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Film', icon: FontAwesomeIcons.film, endpoint: '$_baseUrl/film', dataKey: 'data');
}

class SeriesListPage extends StatelessWidget {
  const SeriesListPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Series', icon: FontAwesomeIcons.photoFilm, endpoint: '$_baseUrl/series', dataKey: 'data');
}

class TvShowPage extends StatelessWidget {
  const TvShowPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'TV Show', icon: FontAwesomeIcons.satellite, endpoint: '$_baseUrl/tvshow', dataKey: 'data');
}

class AnimeListPage extends StatelessWidget {
  const AnimeListPage({super.key});
  @override
  Widget build(BuildContext context) => const _PaginatedListPage(title: 'Semua Anime (A-Z)', icon: FontAwesomeIcons.listUl, endpoint: '$_baseUrl/all-anime', dataKey: 'data');
}

Widget _buildNetworkImage(String url, {required double height, required double width}) {
  return Image.network(
    url,
    height: height,
    width: width,
    fit: BoxFit.cover,
    errorBuilder: (_, __, ___) => Container(
      height: height == double.infinity ? null : height,
      width: width == double.infinity ? null : width,
      color: AppColors.card,
      alignment: Alignment.center,
      child: const FaIcon(FontAwesomeIcons.imagePortrait, color: AppColors.greyDark, size: 20),
    ),
    loadingBuilder: (_, child, progress) {
      if (progress == null) return child;
      return Container(
        height: height == double.infinity ? null : height,
        width: width == double.infinity ? null : width,
        color: AppColors.card,
        alignment: Alignment.center,
        child: const CircularProgressIndicator(color: AppColors.primary, strokeWidth: 2),
      );
    },
  );
}