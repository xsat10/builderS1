import 'package:audioplayers/audioplayers.dart';

class AudioService {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;
  AudioService._internal();

  final AudioPlayer player = AudioPlayer();
  String? currentTrackId;
  bool isPlaying = false;

  Future<void> play(String url, String trackId) async {
    if (currentTrackId == trackId && isPlaying) return;
    if (currentTrackId != trackId) {
      await player.stop();
      await player.play(UrlSource(url));
      currentTrackId = trackId;
      isPlaying = true;
    } else if (!isPlaying) {
      await player.resume();
      isPlaying = true;
    }
  }

  Future<void> pause() async {
    await player.pause();
    isPlaying = false;
  }

  Future<void> stop() async {
    await player.stop();
    currentTrackId = null;
    isPlaying = false;
  }

  void dispose() {
    player.dispose();
  }
}