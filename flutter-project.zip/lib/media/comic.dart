import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

const kCPrimary = Color(0xFF1565C0);
const kCPrimaryLight = Color(0xFF1E88E5);
const kCPrimaryDark = Color(0xFF0D47A1);
const kCAccent = Color(0xFF64B5F6);
const kCAccentGlow = Color(0xFF90CAF9);
const kCBg = Color(0xFF070A0F);
const kCSurface = Color(0xFF0F1318);
const kCCard = Color(0xFF161B24);
const kCCardHover = Color(0xFF1E2530);
const kCWhite = Color(0xFFFFFFFF);
const kCWhite70 = Color(0xB3FFFFFF);
const kCWhite40 = Color(0x66FFFFFF);
const kCWhite10 = Color(0x1AFFFFFF);
const kCGreen = Color(0xFF4CAF50);

const kCBase = 'https://www.sankavollerei.com/comic';

const kImgHeaders = {
  'Referer': 'https://komiku.org/',
  'User-Agent':
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
};

class ComicItem {
  final String title;
  final String link;
  final String? chapter;
  final String? image;
  final String? genre;
  final String? type;
  final String? status;
  final String? timeAgo;
  final double? recommendationScore;
  final String? reason;

  const ComicItem({
    required this.title,
    required this.link,
    this.chapter,
    this.image,
    this.genre,
    this.type,
    this.status,
    this.timeAgo,
    this.recommendationScore,
    this.reason,
  });

  String get slug {
    final rel = RegExp(r'/manga/([^/]+)').firstMatch(link);
    if (rel != null) return rel.group(1)!;
    final detail = RegExp(r'/detail-komik/([^/]+)').firstMatch(link);
    if (detail != null) return detail.group(1)!;
    try {
      final uri = Uri.parse(link);
      final segs = uri.pathSegments.where((s) => s.isNotEmpty).toList();
      if (segs.length >= 2) return segs.last;
    } catch (_) {}
    return link;
  }

  factory ComicItem.fromMap(Map<String, dynamic> j) => ComicItem(
        title: j['title'] ?? '',
        link: j['link'] ?? j['href'] ?? '',
        chapter: j['chapter']?.toString(),
        image: j['image'] ?? j['thumbnail'],
        genre: j['genre']?.toString(),
        type: j['type']?.toString(),
        status: j['status']?.toString(),
        timeAgo: j['time_ago']?.toString(),
        recommendationScore: (j['recommendation_score'] as num?)?.toDouble(),
        reason: j['reason']?.toString(),
      );
}

class GenreItem {
  final String value;
  final String name;
  const GenreItem({required this.value, required this.name});
}

class ComicDetail {
  final String slug;
  final String title;
  final String titleIndonesian;
  final String image;
  final String synopsis;
  final String synopsisFull;
  final Map<String, dynamic> metadata;
  final List<Map<String, dynamic>> genres;
  final List<Map<String, dynamic>> chapters;

  const ComicDetail({
    required this.slug,
    required this.title,
    required this.titleIndonesian,
    required this.image,
    required this.synopsis,
    required this.synopsisFull,
    required this.metadata,
    required this.genres,
    required this.chapters,
  });

  factory ComicDetail.fromJson(Map<String, dynamic> j) => ComicDetail(
        slug: j['slug'] ?? '',
        title: j['title'] ?? '',
        titleIndonesian: j['title_indonesian'] ?? '',
        image: j['image'] ?? '',
        synopsis: j['synopsis'] ?? '',
        synopsisFull: j['synopsis_full'] ?? j['synopsis'] ?? '',
        metadata: Map<String, dynamic>.from(j['metadata'] ?? {}),
        genres: List<Map<String, dynamic>>.from(
          (j['genres'] as List? ?? []).map((g) => Map<String, dynamic>.from(g)),
        ),
        chapters: List<Map<String, dynamic>>.from(
          (j['chapters'] as List? ?? []).map((c) => Map<String, dynamic>.from(c)),
        ),
      );
}

class ChapterData {
  final String mangaTitle;
  final String chapterTitle;
  final String? previousChapter;
  final String? nextChapter;
  final String? chapterList;
  final List<String> images;

  const ChapterData({
    required this.mangaTitle,
    required this.chapterTitle,
    this.previousChapter,
    this.nextChapter,
    this.chapterList,
    required this.images,
  });

  factory ChapterData.fromJson(Map<String, dynamic> j) {
    final nav = j['navigation'] as Map<String, dynamic>? ?? {};
    return ChapterData(
      mangaTitle: j['manga_title'] ?? '',
      chapterTitle: j['chapter_title'] ?? '',
      previousChapter: nav['previousChapter']?.toString(),
      nextChapter: nav['nextChapter']?.toString(),
      chapterList: nav['chapterList']?.toString(),
      images: List<String>.from(j['images'] ?? []),
    );
  }
}

class BerwarnaItem {
  final String title;
  final String thumbnail;
  final String type;
  final String genre;
  final String url;
  final String detailUrl;
  final String description;
  final String stats;
  final String? latestChapterTitle;
  final String? latestChapterUrl;
  final String? firstChapterTitle;

  const BerwarnaItem({
    required this.title,
    required this.thumbnail,
    required this.type,
    required this.genre,
    required this.url,
    required this.detailUrl,
    required this.description,
    required this.stats,
    this.latestChapterTitle,
    this.latestChapterUrl,
    this.firstChapterTitle,
  });

  String get slug {
    final m = RegExp(r'/detail-komik/([^/\s]+)').firstMatch(detailUrl);
    if (m != null) return m.group(1)!;
    final m2 = RegExp(r'/manga/([^/]+)').firstMatch(url);
    return m2?.group(1) ?? '';
  }

  factory BerwarnaItem.fromJson(Map<String, dynamic> j) {
    final latest = j['latestChapter'] as Map<String, dynamic>? ?? {};
    final first = j['firstChapter'] as Map<String, dynamic>? ?? {};
    return BerwarnaItem(
      title: j['title'] ?? '',
      thumbnail: j['thumbnail'] ?? '',
      type: j['type'] ?? '',
      genre: j['genre'] ?? '',
      url: j['url'] ?? '',
      detailUrl: j['detailUrl'] ?? '',
      description: j['description'] ?? '',
      stats: j['stats'] ?? '',
      latestChapterTitle: latest['title']?.toString(),
      latestChapterUrl: latest['url']?.toString(),
      firstChapterTitle: first['title']?.toString(),
    );
  }
}

class ComicPlayApi {
  static Future<Map<String, dynamic>> _get(String url) async {
    final res = await http
        .get(Uri.parse(url))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw Exception('HTTP ${res.statusCode}');
    }
    return jsonDecode(res.body);
  }

  static Future<List<ComicItem>> terbaru({int page = 1, int limit = 20}) async {
    final d = await _get('$kCBase/terbaru?page=$page&limit=$limit');
    return toItems(d['comics']);
  }

  static Future<List<ComicItem>> populer({int page = 1, int limit = 20}) async {
    final d = await _get('$kCBase/populer?page=$page&limit=$limit');
    return toItems(d['comics']);
  }

  static Future<List<ComicItem>> trending() async {
    final d = await _get('$kCBase/trending');
    return toItems(d['trending']);
  }

  static Future<Map<String, dynamic>> scroll({int offset = 0, int? seed}) async {
    var url = '$kCBase/scroll?offset=$offset&batch_size=20';
    if (seed != null) url += '&seed=$seed';
    return _get(url);
  }

  static Future<List<ComicItem>> infinite({int page = 1}) async {
    final d = await _get('$kCBase/infinite?page=$page');
    return toItems(d['comics']);
  }

  static Future<List<ComicItem>> unlimited({String type = 'all'}) async {
    final d = await _get('$kCBase/unlimited?type=$type&max_pages=3');
    return toItems(d['comics']);
  }

  static Future<List<ComicItem>> realtime() async {
    final d = await _get('$kCBase/realtime');
    return toItems(d['comics']);
  }

  static Future<List<ComicItem>> recommendations({int limit = 10}) async {
    final d = await _get('$kCBase/recommendations?limit=$limit');
    return toItems(d['recommendations']);
  }

  static Future<List<ComicItem>> search(String q, {int page = 1}) async {
    final d = await _get(
        '$kCBase/search?q=${Uri.encodeComponent(q)}&page=$page');
    final raw = d['data'];
    if (raw is! List) return [];
    return raw.map((e) {
      final m = Map<String, dynamic>.from(e);
      m['link'] = m['href'] ?? m['link'] ?? '';
      m['image'] = m['thumbnail'] ?? m['image'];
      return ComicItem.fromMap(m);
    }).toList();
  }

  static Future<List<ComicItem>> advancedSearch({
    required String q,
    String? type,
    String? status,
    String? genre,
    String? sort,
    int page = 1,
  }) async {
    var url = '$kCBase/advanced-search?q=${Uri.encodeComponent(q)}&page=$page';
    if (type != null && type.isNotEmpty) url += '&type=$type';
    if (status != null && status.isNotEmpty) url += '&status=$status';
    if (genre != null && genre.isNotEmpty) url += '&genre=$genre';
    if (sort != null && sort.isNotEmpty) url += '&sort=$sort';
    final d = await _get(url);
    final raw = d['data'];
    if (raw is! List) return [];
    return raw.map((e) {
      final m = Map<String, dynamic>.from(e);
      m['link'] = m['href'] ?? m['link'] ?? '';
      m['image'] = m['thumbnail'] ?? m['image'];
      return ComicItem.fromMap(m);
    }).toList();
  }

  static Future<List<GenreItem>> genres() async {
    final d = await _get('$kCBase/genres');
    final result = <GenreItem>[];
    for (final key in d.keys) {
      if (key == 'creator') continue;
      final v = d[key];
      if (v is Map) {
        result.add(GenreItem(
          value: v['value']?.toString() ?? '',
          name: v['name']?.toString() ?? '',
        ));
      }
    }
    return result;
  }

  static Future<List<ComicItem>> genre(String g, {int page = 1}) async {
    final d = await _get('$kCBase/genre/$g?page=$page&limit=20');
    return toItems(d['comics']);
  }

  static Future<ComicDetail> comicDetail(String slug) async {
    final d = await _get('$kCBase/comic/$slug');
    return ComicDetail.fromJson(d);
  }

  static Future<ChapterData> chapter(String segment) async {
    final d = await _get('$kCBase/chapter/$segment');
    return ChapterData.fromJson(d);
  }

  static Future<List<BerwarnaItem>> berwarna({int page = 1}) async {
    final d = await _get('$kCBase/berwarna/$page');
    final results = d['data']?['results'] ?? d['results'] ?? [];
    return List<Map<String, dynamic>>.from(results)
        .map(BerwarnaItem.fromJson)
        .toList();
  }

  static Future<List<BerwarnaItem>> pustaka({int page = 1}) async {
    final d = await _get('$kCBase/pustaka/$page');
    final results = d['results'] ?? [];
    return List<Map<String, dynamic>>.from(results)
        .map(BerwarnaItem.fromJson)
        .toList();
  }

  static Future<Map<String, dynamic>> favorites() => _get('$kCBase/favorites');
  static Future<Map<String, dynamic>> comparison() => _get('$kCBase/comparison');

  static List<ComicItem> toItems(dynamic raw) {
    if (raw is! List) return [];
    return raw
        .cast<Map<String, dynamic>>()
        .map(ComicItem.fromMap)
        .toList();
  }
}

class ComicPlayPage extends StatefulWidget {
  const ComicPlayPage({super.key});
  @override
  State<ComicPlayPage> createState() => _ComicPlayPageState();
}

class _ComicPlayPageState extends State<ComicPlayPage> {
  int _idx = 0;

  static const _pages = [
    _ComicHome(),
    _ComicTerbaruPage(),
    _ComicTrendingPage(),
    _ComicGenrePage(),
    _ComicSearchPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: _buildTheme(),
      child: Scaffold(
        body: IndexedStack(index: _idx, children: _pages),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  ThemeData _buildTheme() => ThemeData.dark().copyWith(
        scaffoldBackgroundColor: kCBg,
        colorScheme: const ColorScheme.dark(
          primary: kCPrimary,
          secondary: kCAccent,
          surface: kCSurface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kCBg,
          elevation: 0,
          centerTitle: false,
        ),
      );

  Widget _buildBottomNav() => Container(
        decoration: const BoxDecoration(
          color: kCSurface,
          border: Border(top: BorderSide(color: kCPrimaryDark, width: 0.8)),
        ),
        child: SafeArea(
          child: SizedBox(
            height: 56,
            child: Row(
              children: [
                _NavItem(icon: FontAwesomeIcons.house, label: 'Beranda', idx: 0, current: _idx, onTap: _tap),
                _NavItem(icon: FontAwesomeIcons.bookOpen, label: 'Terbaru', idx: 1, current: _idx, onTap: _tap),
                _NavItem(icon: FontAwesomeIcons.chartLine, label: 'Trending', idx: 2, current: _idx, onTap: _tap),
                _NavItem(icon: FontAwesomeIcons.tags, label: 'Genre', idx: 3, current: _idx, onTap: _tap),
                _NavItem(icon: FontAwesomeIcons.magnifyingGlass, label: 'Cari', idx: 4, current: _idx, onTap: _tap),
              ],
            ),
          ),
        ),
      );

  void _tap(int i) => setState(() => _idx = i);
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int idx;
  final int current;
  final void Function(int) onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.idx,
    required this.current,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final sel = idx == current;
    return Expanded(
      child: GestureDetector(
        onTap: () => onTap(idx),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, size: 15, color: sel ? kCAccent : kCWhite40),
            const SizedBox(height: 3),
            Text(label,
                style: TextStyle(
                  fontSize: 9,
                  color: sel ? kCAccent : kCWhite40,
                  fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
                )),
          ],
        ),
      ),
    );
  }
}

class _ComicHome extends StatefulWidget {
  const _ComicHome();
  @override
  State<_ComicHome> createState() => _ComicHomeState();
}

class _ComicHomeState extends State<_ComicHome> {
  List<ComicItem> _populer = [];
  List<ComicItem> _terbaru = [];
  List<ComicItem> _trending = [];
  List<ComicItem> _recs = [];
  List<ComicItem> _realtime = [];
  List<ComicItem> _scrollItems = [];
  List<BerwarnaItem> _berwarna = [];

  int? _scrollSeed;
  int _scrollOffset = 0;
  bool _scrollHasMore = true;
  bool _scrollLoadingMore = false;

  bool _loading = true;
  String? _error;

  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _load();
    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels >=
            _scrollCtrl.position.maxScrollExtent - 300 &&
        !_scrollLoadingMore &&
        _scrollHasMore) {
      _loadMoreScroll();
    }
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final scrollRes = await ComicPlayApi.scroll(offset: 0);
      final info = scrollRes['scroll_info'] as Map<String, dynamic>? ?? {};
      _scrollSeed = (info['seed'] as num?)?.toInt();
      _scrollOffset = (info['next_offset'] as num?)?.toInt() ?? 20;
      _scrollHasMore = info['has_more'] as bool? ?? false;

      final results = await Future.wait([
        ComicPlayApi.populer(limit: 10),
        ComicPlayApi.terbaru(limit: 10),
        ComicPlayApi.trending(),
        ComicPlayApi.recommendations(limit: 10),
        ComicPlayApi.realtime(),
        ComicPlayApi.berwarna(page: 1),
      ]);

      setState(() {
        _populer = results[0] as List<ComicItem>;
        _terbaru = results[1] as List<ComicItem>;
        _trending = results[2] as List<ComicItem>;
        _recs = results[3] as List<ComicItem>;
        _realtime = results[4] as List<ComicItem>;
        _berwarna = results[5] as List<BerwarnaItem>;
        _scrollItems = ComicPlayApi.toItems(scrollRes['comics']);
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _loadMoreScroll() async {
    setState(() => _scrollLoadingMore = true);
    try {
      final res = await ComicPlayApi.scroll(offset: _scrollOffset, seed: _scrollSeed);
      final info = res['scroll_info'] as Map<String, dynamic>? ?? {};
      setState(() {
        _scrollItems.addAll(ComicPlayApi.toItems(res['comics']));
        _scrollOffset = (info['next_offset'] as num?)?.toInt() ?? (_scrollOffset + 20);
        _scrollHasMore = info['has_more'] as bool? ?? false;
        _scrollLoadingMore = false;
      });
    } catch (_) {
      setState(() => _scrollLoadingMore = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const _LoadingPage();
    if (_error != null) return _ErrorPage(onRetry: _load, message: _error!);

    return Scaffold(
      backgroundColor: kCBg,
      body: CustomScrollView(
        controller: _scrollCtrl,
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: kCBg,
            expandedHeight: 0,
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [kCPrimary, kCPrimaryLight]),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const FaIcon(FontAwesomeIcons.bookOpen, size: 13, color: kCWhite),
                ),
                const SizedBox(width: 10),
                RichText(
                  text: const TextSpan(children: [
                    TextSpan(text: 'Comic', style: TextStyle(color: kCWhite, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                    TextSpan(text: 'Play', style: TextStyle(color: kCAccent, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
                  ]),
                ),
                const Spacer(),
                _AppBarAction(icon: FontAwesomeIcons.infinity, tooltip: 'Jelajahi Semua', page: const _UnlimitedPage()),
                _AppBarAction(icon: FontAwesomeIcons.palette, tooltip: 'Komik Berwarna', page: const _BerwarnaPage()),
                _AppBarAction(icon: FontAwesomeIcons.layerGroup, tooltip: 'Pustaka', page: const _PustakaPage()),
              ],
            ),
          ),
          _Section(title: 'Populer', icon: FontAwesomeIcons.fire),
          _SliverHList(items: _populer, height: 185),
          _Section(title: 'Trending Hari Ini', icon: FontAwesomeIcons.chartLine),
          _SliverHList(items: _trending, height: 185),
          _Section(title: 'Komik Berwarna', icon: FontAwesomeIcons.palette),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 108,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: _berwarna.length,
                itemBuilder: (_, i) => _BerwarnaCard(item: _berwarna[i]),
              ),
            ),
          ),
          _Section(title: 'Update Terbaru', icon: FontAwesomeIcons.clockRotateLeft),
          _SliverHList(items: _terbaru, height: 185, showTimeAgo: true),
          _Section(title: 'Sedang Ramai Dibaca', icon: FontAwesomeIcons.users),
          _SliverHList(items: _realtime, height: 185),
          _Section(title: 'Rekomendasi Untukmu', icon: FontAwesomeIcons.thumbsUp),
          _SliverHList(items: _recs, height: 185, showScore: true),
          _Section(title: 'Semua Komik', icon: FontAwesomeIcons.layerGroup),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, childAspectRatio: 0.58,
                crossAxisSpacing: 8, mainAxisSpacing: 8,
              ),
              delegate: SliverChildBuilderDelegate(
                (_, i) {
                  if (i < _scrollItems.length) return _ComicCard(item: _scrollItems[i]);
                  return const Center(child: CircularProgressIndicator(color: kCPrimary, strokeWidth: 2));
                },
                childCount: _scrollItems.length + (_scrollHasMore ? 1 : 0),
              ),
            ),
          ),
          const SliverPadding(padding: EdgeInsets.only(bottom: 24)),
        ],
      ),
    );
  }
}

class _ComicTerbaruPage extends StatefulWidget {
  const _ComicTerbaruPage();
  @override
  State<_ComicTerbaruPage> createState() => _ComicTerbaruPageState();
}

class _ComicTerbaruPageState extends State<_ComicTerbaruPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tab = TabController(length: 2, vsync: this);

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kCBg,
      appBar: AppBar(
        backgroundColor: kCBg,
        automaticallyImplyLeading: false,
        title: const _AppBarTitle(title: 'Terbaru', icon: FontAwesomeIcons.bookOpen),
        bottom: _styledTabBar(_tab, ['Update', 'Populer']),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _PaginatedGrid(fetcher: (p) => ComicPlayApi.terbaru(page: p)),
          _PaginatedGrid(fetcher: (p) => ComicPlayApi.populer(page: p)),
        ],
      ),
    );
  }
}

class _ComicTrendingPage extends StatefulWidget {
  const _ComicTrendingPage();
  @override
  State<_ComicTrendingPage> createState() => _ComicTrendingPageState();
}

class _ComicTrendingPageState extends State<_ComicTrendingPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tab = TabController(length: 3, vsync: this);
  List<ComicItem> _trending = [];
  List<ComicItem> _infinite = [];
  List<BerwarnaItem> _pustaka = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await Future.wait([
        ComicPlayApi.trending(),
        ComicPlayApi.infinite(),
        ComicPlayApi.pustaka(),
      ]);
      setState(() {
        _trending = r[0] as List<ComicItem>;
        _infinite = r[1] as List<ComicItem>;
        _pustaka = r[2] as List<BerwarnaItem>;
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(
      backgroundColor: kCBg,
      automaticallyImplyLeading: false,
      title: const _AppBarTitle(title: 'Trending', icon: FontAwesomeIcons.chartLine),
      bottom: _styledTabBar(_tab, ['Trending', 'Infinite', 'Pustaka']),
    ),
    body: _loading
        ? const _LoadingPage()
        : TabBarView(
            controller: _tab,
            children: [
              _TrendingRanked(items: _trending),
              _PaginatedGrid(fetcher: (p) => ComicPlayApi.infinite(page: p),
                             preloaded: _infinite),
              _PustakaList(items: _pustaka),
            ],
          ),
  );
}

class _ComicGenrePage extends StatefulWidget {
  const _ComicGenrePage();
  @override
  State<_ComicGenrePage> createState() => _ComicGenrePageState();
}

class _ComicGenrePageState extends State<_ComicGenrePage> {
  List<GenreItem> _genres = [];
  GenreItem? _selected;
  List<ComicItem> _items = [];
  bool _loading = true;
  bool _loadingGenre = false;
  int _genrePage = 1;
  bool _genreHasMore = true;
  bool _genreLoadMore = false;
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadGenres();
    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void dispose() { _scrollCtrl.dispose(); super.dispose(); }

  void _onScroll() {
    if (_selected == null) return;
    if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 200 &&
        !_genreLoadMore && _genreHasMore) {
      _loadMoreGenre();
    }
  }

  Future<void> _loadGenres() async {
    try {
      final d = await ComicPlayApi.genres();
      setState(() { _genres = d; _loading = false; });
    } catch (_) { setState(() => _loading = false); }
  }

  Future<void> _selectGenre(GenreItem g) async {
    setState(() { _selected = g; _loadingGenre = true; _items = []; _genrePage = 1; _genreHasMore = true; });
    try {
      final d = await ComicPlayApi.genre(g.value, page: 1);
      setState(() { _items = d; _loadingGenre = false; _genreHasMore = d.length >= 10; });
    } catch (_) { setState(() => _loadingGenre = false); }
  }

  Future<void> _loadMoreGenre() async {
    setState(() => _genreLoadMore = true);
    try {
      final d = await ComicPlayApi.genre(_selected!.value, page: _genrePage + 1);
      setState(() {
        _items.addAll(d);
        _genrePage++;
        _genreHasMore = d.isNotEmpty;
        _genreLoadMore = false;
      });
    } catch (_) { setState(() => _genreLoadMore = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(
      backgroundColor: kCBg,
      automaticallyImplyLeading: false,
      title: const _AppBarTitle(title: 'Genre', icon: FontAwesomeIcons.tags),
    ),
    body: _loading ? const _LoadingPage() : Column(
      children: [
        Container(
          color: kCSurface,
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Wrap(
            spacing: 6, runSpacing: 6,
            children: _genres.map((g) {
              final sel = g.value == _selected?.value;
              return GestureDetector(
                onTap: () => _selectGenre(g),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: sel ? kCPrimary : kCCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: sel ? kCPrimaryLight : kCWhite10),
                  ),
                  child: Text(g.name,
                      style: TextStyle(
                        color: sel ? kCWhite : kCWhite70,
                        fontSize: 11,
                        fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
                      )),
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: _selected == null
              ? const _EmptyState(icon: FontAwesomeIcons.tags, title: 'Pilih Genre',
                                  subtitle: 'Tap genre di atas untuk mulai')
              : _loadingGenre
                  ? const _LoadingPage()
                  : _items.isEmpty
                      ? const _EmptyState(icon: FontAwesomeIcons.bookOpen,
                                          title: 'Belum Ada Komik', subtitle: 'Coba genre lain')
                      : GridView.builder(
                          controller: _scrollCtrl,
                          padding: const EdgeInsets.all(12),
                          gridDelegate: _grid3,
                          itemCount: _items.length + (_genreLoadMore ? 1 : 0),
                          itemBuilder: (_, i) {
                            if (i == _items.length) return _spinner;
                            return _ComicCard(item: _items[i]);
                          },
                        ),
        ),
      ],
    ),
  );
}

class _ComicSearchPage extends StatefulWidget {
  const _ComicSearchPage();
  @override
  State<_ComicSearchPage> createState() => _ComicSearchPageState();
}

class _ComicSearchPageState extends State<_ComicSearchPage> {
  final _ctrl = TextEditingController();
  List<ComicItem> _results = [];
  List<String> _history = [];
  bool _loading = false;
  bool _searched = false;
  bool _advanced = false;
  String? _fType, _fStatus, _fSort;

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() { _loading = true; _searched = true; });
    _history = [q, ..._history.where((h) => h != q)].take(10).toList();
    try {
      List<ComicItem> d;
      if (_advanced && (_fType != null || _fStatus != null || _fSort != null)) {
        d = await ComicPlayApi.advancedSearch(q: q, type: _fType, status: _fStatus, sort: _fSort);
      } else {
        d = await ComicPlayApi.search(q);
      }
      setState(() { _results = d; _loading = false; });
    } catch (e) {
      setState(() { _results = []; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(
      backgroundColor: kCBg,
      automaticallyImplyLeading: false,
      title: const _AppBarTitle(title: 'Cari Komik', icon: FontAwesomeIcons.magnifyingGlass),
      actions: [
        IconButton(
          icon: FaIcon(FontAwesomeIcons.sliders, size: 15,
              color: _advanced ? kCAccent : kCWhite70),
          onPressed: () => setState(() => _advanced = !_advanced),
        ),
      ],
    ),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
          child: Row(children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: kCCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kCWhite10),
                ),
                child: TextField(
                  controller: _ctrl,
                  style: const TextStyle(color: kCWhite, fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Cari judul komik...',
                    hintStyle: TextStyle(color: kCWhite40),
                    prefixIcon: Padding(padding: EdgeInsets.all(13),
                        child: FaIcon(FontAwesomeIcons.magnifyingGlass, size: 14, color: kCWhite40)),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 13),
                  ),
                  onSubmitted: (_) => _search(),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _search,
              child: Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kCPrimary, kCPrimaryLight]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const FaIcon(FontAwesomeIcons.magnifyingGlass, size: 15, color: kCWhite),
              ),
            ),
          ]),
        ),
        if (_advanced) _SearchFilters(
          fType: _fType, fStatus: _fStatus, fSort: _fSort,
          onTypeChanged: (v) => setState(() => _fType = v),
          onStatusChanged: (v) => setState(() => _fStatus = v),
          onSortChanged: (v) => setState(() => _fSort = v),
        ),
        Expanded(
          child: _loading
              ? const _LoadingPage()
              : !_searched
                  ? _SearchHistory(history: _history, onTap: (q) { _ctrl.text = q; _search(); })
                  : _results.isEmpty
                      ? const _EmptyState(icon: FontAwesomeIcons.bookOpen,
                                          title: 'Tidak Ditemukan', subtitle: 'Coba kata kunci lain')
                      : GridView.builder(
                          padding: const EdgeInsets.all(12),
                          gridDelegate: _grid3,
                          itemCount: _results.length,
                          itemBuilder: (_, i) => _ComicCard(item: _results[i]),
                        ),
        ),
      ],
    ),
  );
}

class _SearchFilters extends StatelessWidget {
  final String? fType, fStatus, fSort;
  final ValueChanged<String?> onTypeChanged, onStatusChanged, onSortChanged;

  const _SearchFilters({
    this.fType, this.fStatus, this.fSort,
    required this.onTypeChanged, required this.onStatusChanged, required this.onSortChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 6),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: kCCard,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: kCPrimary.withOpacity(0.25)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(children: [
          FaIcon(FontAwesomeIcons.sliders, size: 11, color: kCAccent),
          SizedBox(width: 6),
          Text('Filter Lanjutan', style: TextStyle(color: kCAccent, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 10),
        _FilterRow(label: 'Tipe', options: const [null, 'manga', 'manhwa', 'manhua'],
            labels: const ['Semua', 'Manga', 'Manhwa', 'Manhua'],
            selected: fType, onChanged: onTypeChanged),
        const SizedBox(height: 6),
        _FilterRow(label: 'Status', options: const [null, 'ongoing', 'completed'],
            labels: const ['Semua', 'Ongoing', 'Completed'],
            selected: fStatus, onChanged: onStatusChanged),
        const SizedBox(height: 6),
        _FilterRow(label: 'Urutkan', options: const [null, 'latest', 'popular', 'rating'],
            labels: const ['Relevan', 'Terbaru', 'Populer', 'Rating'],
            selected: fSort, onChanged: onSortChanged),
      ],
    ),
  );
}

class _FilterRow extends StatelessWidget {
  final String label;
  final List<String?> options;
  final List<String> labels;
  final String? selected;
  final ValueChanged<String?> onChanged;

  const _FilterRow({required this.label, required this.options, required this.labels,
      this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      SizedBox(width: 56,
        child: Text(label, style: const TextStyle(color: kCWhite70, fontSize: 11))),
      ...List.generate(options.length, (i) => GestureDetector(
        onTap: () => onChanged(options[i]),
        child: Container(
          margin: const EdgeInsets.only(left: 6),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
          decoration: BoxDecoration(
            color: selected == options[i] ? kCPrimary : kCSurface,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(labels[i],
              style: TextStyle(
                color: selected == options[i] ? kCWhite : kCWhite70,
                fontSize: 10,
              )),
        ),
      )),
    ],
  );
}

class _SearchHistory extends StatelessWidget {
  final List<String> history;
  final ValueChanged<String> onTap;
  const _SearchHistory({required this.history, required this.onTap});

  @override
  Widget build(BuildContext context) => history.isEmpty
      ? const _EmptyState(icon: FontAwesomeIcons.magnifyingGlass,
                          title: 'Cari Komik Favoritmu',
                          subtitle: 'Ketik judul untuk memulai')
      : ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Row(children: [
              FaIcon(FontAwesomeIcons.clockRotateLeft, size: 12, color: kCAccent),
              SizedBox(width: 6),
              Text('Riwayat Pencarian', style: TextStyle(color: kCAccent, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 10),
            ...history.map((h) => GestureDetector(
              onTap: () => onTap(h),
              child: Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(color: kCCard, borderRadius: BorderRadius.circular(8)),
                child: Row(children: [
                  const FaIcon(FontAwesomeIcons.clockRotateLeft, size: 11, color: kCWhite40),
                  const SizedBox(width: 10),
                  Expanded(child: Text(h, style: const TextStyle(color: kCWhite70, fontSize: 13))),
                  const FaIcon(FontAwesomeIcons.arrowUp, size: 11, color: kCWhite40),
                ]),
              ),
            )),
          ],
        );
}

class _ComicDetailPage extends StatefulWidget {
  final String slug;
  const _ComicDetailPage({required this.slug});
  @override
  State<_ComicDetailPage> createState() => _ComicDetailPageState();
}

class _ComicDetailPageState extends State<_ComicDetailPage> {
  ComicDetail? _detail;
  bool _loading = true;
  String? _error;
  bool _showFullSynopsis = false;
  bool _showAllChapters = false;
  bool _chapReversed = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final d = await ComicPlayApi.comicDetail(widget.slug);
      setState(() { _detail = d; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    body: _loading ? const _LoadingPage()
        : _error != null ? _ErrorPage(onRetry: _load, message: _error!)
        : _buildBody(),
  );

  Widget _buildBody() {
    final d = _detail!;
    final chapters = _chapReversed ? d.chapters.reversed.toList() : d.chapters;
    final visChapters = _showAllChapters ? chapters : chapters.take(10).toList();

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 270,
          pinned: true,
          backgroundColor: kCBg,
          leading: _BackBtn(),
          flexibleSpace: FlexibleSpaceBar(
            background: Stack(fit: StackFit.expand, children: [
              d.image.isNotEmpty
                  ? Image.network(d.image, fit: BoxFit.cover, headers: kImgHeaders,
                      errorBuilder: (_, __, ___) => Container(color: kCCard))
                  : Container(color: kCCard),
              Container(decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [Colors.transparent, kCBg.withOpacity(0.85), kCBg],
                ),
              )),
            ]),
          ),
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d.title, style: const TextStyle(color: kCWhite, fontSize: 20, fontWeight: FontWeight.w900)),
            if (d.titleIndonesian.isNotEmpty && d.titleIndonesian != d.title)
              Text(d.titleIndonesian, style: const TextStyle(color: kCWhite70, fontSize: 13)),
            const SizedBox(height: 10),
            _MetaBadges(metadata: d.metadata),
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: d.genres.map((g) {
              final name = g['name']?.toString() ?? '';
              final slug = g['slug']?.toString() ?? '';
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => _GenreDetailPage(genre: slug, title: name))),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: kCPrimary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kCPrimary, width: 0.8),
                  ),
                  child: Text(name, style: const TextStyle(color: kCAccent, fontSize: 11)),
                ),
              );
            }).toList()),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _PrimaryBtn(
                icon: FontAwesomeIcons.play, label: 'Mulai Baca',
                onTap: d.chapters.isNotEmpty ? () => _openChapter(context, d.chapters.last) : null,
              )),
              const SizedBox(width: 10),
              _IconBtn(icon: FontAwesomeIcons.bookmark, onTap: () {}),
              const SizedBox(width: 6),
              _IconBtn(icon: FontAwesomeIcons.shareNodes, onTap: () {}),
            ]),
            const SizedBox(height: 16),
            _SectionTitle('Sinopsis'),
            const SizedBox(height: 6),
            GestureDetector(
              onTap: () => setState(() => _showFullSynopsis = !_showFullSynopsis),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  _showFullSynopsis ? d.synopsisFull : d.synopsis,
                  style: const TextStyle(color: kCWhite70, fontSize: 13, height: 1.55),
                  maxLines: _showFullSynopsis ? null : 4,
                  overflow: _showFullSynopsis ? TextOverflow.visible : TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(_showFullSynopsis ? 'Sembunyikan ↑' : 'Baca selengkapnya ↓',
                    style: const TextStyle(color: kCAccent, fontSize: 12)),
              ]),
            ),
            const SizedBox(height: 16),
            _InfoGrid(metadata: d.metadata),
            const SizedBox(height: 16),
            Row(children: [
              _SectionTitle('Chapter (${d.chapters.length})'),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() => _chapReversed = !_chapReversed),
                child: Row(children: [
                  FaIcon(_chapReversed ? FontAwesomeIcons.arrowDown : FontAwesomeIcons.arrowUp,
                      size: 11, color: kCWhite70),
                  const SizedBox(width: 4),
                  Text(_chapReversed ? 'Lama–Baru' : 'Baru–Lama',
                      style: const TextStyle(color: kCWhite70, fontSize: 11)),
                ]),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () => setState(() => _showAllChapters = !_showAllChapters),
                child: Text(
                  _showAllChapters
                      ? 'Tampilkan Sedikit'
                      : 'Lihat Semua (${d.chapters.length})',
                  style: const TextStyle(color: kCAccent, fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
            ]),
            const SizedBox(height: 8),
            ...visChapters.map((ch) => _ChapterTile(
              chapter: ch,
              onTap: () => _openChapter(context, ch),
            )),
          ]),
        )),
      ],
    );
  }

  void _openChapter(BuildContext ctx, Map<String, dynamic> ch) {
    final seg = ch['slug']?.toString() ?? '';
    if (seg.isEmpty) return;
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => _ChapterReaderPage(segment: seg)));
  }
}

class _GenreDetailPage extends StatefulWidget {
  final String genre, title;
  const _GenreDetailPage({required this.genre, required this.title});
  @override
  State<_GenreDetailPage> createState() => _GenreDetailPageState();
}

class _GenreDetailPageState extends State<_GenreDetailPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(
      backgroundColor: kCBg,
      title: _AppBarTitle(title: widget.title, icon: FontAwesomeIcons.tags),
    ),
    body: _PaginatedGrid(fetcher: (p) => ComicPlayApi.genre(widget.genre, page: p)),
  );
}

class _ChapterReaderPage extends StatefulWidget {
  final String segment;
  const _ChapterReaderPage({required this.segment});
  @override
  State<_ChapterReaderPage> createState() => _ChapterReaderPageState();
}

class _ChapterReaderPageState extends State<_ChapterReaderPage> {
  ChapterData? _data;
  bool _loading = true;
  String? _error;
  bool _showUI = true;
  final _scrollCtrl = ScrollController();

  @override
  void initState() { super.initState(); _load(); }

  @override
  void dispose() { _scrollCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final d = await ComicPlayApi.chapter(widget.segment);
      setState(() { _data = d; _loading = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  void _navigate(String? seg) {
    if (seg == null || seg.isEmpty) return;
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => _ChapterReaderPage(segment: seg)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: _loading ? const _LoadingPage()
        : _error != null ? _ErrorPage(onRetry: _load, message: _error!)
        : _buildReader(),
  );

  Widget _buildReader() {
    final d = _data!;
    return GestureDetector(
      onTap: () => setState(() => _showUI = !_showUI),
      child: Stack(children: [
        ListView.builder(
          controller: _scrollCtrl,
          itemCount: d.images.length,
          itemBuilder: (_, i) => Image.network(
            d.images[i],
            headers: kImgHeaders,
            width: double.infinity,
            fit: BoxFit.fitWidth,
            loadingBuilder: (_, child, prog) {
              if (prog == null) return child;
              return SizedBox(height: 320, child: Center(
                child: CircularProgressIndicator(
                  color: kCPrimary, strokeWidth: 2,
                  value: prog.expectedTotalBytes != null
                      ? prog.cumulativeBytesLoaded / prog.expectedTotalBytes!
                      : null,
                ),
              ));
            },
            errorBuilder: (_, __, ___) => Container(height: 200, color: kCCard,
                child: const Center(child: FaIcon(FontAwesomeIcons.imagePortrait, color: kCWhite40, size: 30))),
          ),
        ),
        if (_showUI) Positioned(
          top: 0, left: 0, right: 0,
          child: Container(
            color: Colors.black.withOpacity(0.88),
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 4, bottom: 4),
            child: Row(children: [
              const SizedBox(width: 4),
              IconButton(
                icon: const Icon(Icons.arrow_back, color: kCWhite),
                onPressed: () => Navigator.pop(context),
              ),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(d.mangaTitle, style: const TextStyle(color: kCWhite, fontWeight: FontWeight.w700, fontSize: 13),
                    overflow: TextOverflow.ellipsis),
                Text(d.chapterTitle, style: const TextStyle(color: kCAccent, fontSize: 11)),
              ])),
              Text('${d.images.length} halaman',
                  style: const TextStyle(color: kCWhite40, fontSize: 11)),
              const SizedBox(width: 12),
            ]),
          ),
        ),
        if (_showUI) Positioned(
          bottom: 0, left: 0, right: 0,
          child: Container(
            color: Colors.black.withOpacity(0.88),
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).padding.bottom + 8,
              top: 8, left: 12, right: 12,
            ),
            child: Row(children: [
              Expanded(child: _NavBtn(
                label: 'Sebelumnya', icon: FontAwesomeIcons.chevronLeft,
                enabled: d.previousChapter != null,
                onTap: () => _navigate(d.previousChapter),
              )),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: d.chapterList != null
                    ? () => Navigator.push(context, MaterialPageRoute(
                            builder: (_) => _ComicDetailPage(slug: d.chapterList!)))
                    : null,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: kCCard, borderRadius: BorderRadius.circular(8)),
                  child: const FaIcon(FontAwesomeIcons.list, size: 14, color: kCWhite70),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(child: _NavBtn(
                label: 'Selanjutnya', icon: FontAwesomeIcons.chevronRight,
                iconRight: true,
                enabled: d.nextChapter != null,
                onTap: () => _navigate(d.nextChapter),
              )),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _UnlimitedPage extends StatefulWidget {
  const _UnlimitedPage();
  @override
  State<_UnlimitedPage> createState() => _UnlimitedPageState();
}

class _UnlimitedPageState extends State<_UnlimitedPage> {
  List<ComicItem> _items = [];
  int _offset = 0;
  int? _seed;
  bool _loading = true;
  bool _hasMore = true;
  bool _loadMore = false;
  String? _error;
  final _scrollCtrl = ScrollController();

  @override
  void initState() { super.initState(); _load(); _scrollCtrl.addListener(_onScroll); }
  @override
  void dispose() { _scrollCtrl.dispose(); super.dispose(); }

  void _onScroll() {
    if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 200
        && !_loadMore && _hasMore) _fetchMore();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final res = await ComicPlayApi.scroll(offset: 0);
      final info = res['scroll_info'] as Map<String, dynamic>? ?? {};
      setState(() {
        _items = ComicPlayApi.toItems(res['comics']);
        _seed = (info['seed'] as num?)?.toInt();
        _offset = (info['next_offset'] as num?)?.toInt() ?? 20;
        _hasMore = info['has_more'] as bool? ?? false;
        _loading = false;
      });
    } catch (e) { setState(() { _error = e.toString(); _loading = false; }); }
  }

  Future<void> _fetchMore() async {
    setState(() => _loadMore = true);
    try {
      final res = await ComicPlayApi.scroll(offset: _offset, seed: _seed);
      final info = res['scroll_info'] as Map<String, dynamic>? ?? {};
      setState(() {
        _items.addAll(ComicPlayApi.toItems(res['comics']));
        _offset = (info['next_offset'] as num?)?.toInt() ?? (_offset + 20);
        _hasMore = info['has_more'] as bool? ?? false;
        _loadMore = false;
      });
    } catch (_) { setState(() => _loadMore = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(
      backgroundColor: kCBg,
      title: const _AppBarTitle(title: 'Jelajahi Semua', icon: FontAwesomeIcons.infinity),
    ),
    body: _loading ? const _LoadingPage()
        : _error != null ? _ErrorPage(onRetry: _load, message: _error!)
        : GridView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.all(12),
            gridDelegate: _grid3,
            itemCount: _items.length + (_loadMore ? 1 : 0),
            itemBuilder: (_, i) {
              if (i == _items.length) return _spinner;
              return _ComicCard(item: _items[i]);
            },
          ),
  );
}

class _BerwarnaPage extends StatefulWidget {
  const _BerwarnaPage();
  @override
  State<_BerwarnaPage> createState() => _BerwarnaPageState();
}

class _BerwarnaPageState extends State<_BerwarnaPage> {
  List<BerwarnaItem> _items = [];
  int _page = 1;
  bool _loading = true;
  bool _hasMore = true;
  bool _more = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = await ComicPlayApi.berwarna(page: 1);
      setState(() { _items = d; _page = 1; _loading = false; _hasMore = d.length >= 10; });
    } catch (_) { setState(() => _loading = false); }
  }

  Future<void> _loadMore() async {
    setState(() => _more = true);
    try {
      final d = await ComicPlayApi.berwarna(page: _page + 1);
      setState(() { _items.addAll(d); _page++; _hasMore = d.isNotEmpty; _more = false; });
    } catch (_) { setState(() => _more = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(backgroundColor: kCBg,
        title: const _AppBarTitle(title: 'Komik Berwarna', icon: FontAwesomeIcons.palette)),
    body: _loading ? const _LoadingPage()
        : _BerwarnaListView(items: _items, hasMore: _hasMore, loading: _more, onLoadMore: _loadMore),
  );
}

class _PustakaPage extends StatefulWidget {
  const _PustakaPage();
  @override
  State<_PustakaPage> createState() => _PustakaPageState();
}

class _PustakaPageState extends State<_PustakaPage> {
  List<BerwarnaItem> _items = [];
  int _page = 1; bool _loading = true; bool _hasMore = true; bool _more = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = await ComicPlayApi.pustaka(page: 1);
      setState(() { _items = d; _page = 1; _loading = false; _hasMore = d.length >= 10; });
    } catch (_) { setState(() => _loading = false); }
  }

  Future<void> _loadMore() async {
    setState(() => _more = true);
    try {
      final d = await ComicPlayApi.pustaka(page: _page + 1);
      setState(() { _items.addAll(d); _page++; _hasMore = d.isNotEmpty; _more = false; });
    } catch (_) { setState(() => _more = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: kCBg,
    appBar: AppBar(backgroundColor: kCBg,
        title: const _AppBarTitle(title: 'Pustaka', icon: FontAwesomeIcons.layerGroup)),
    body: _loading ? const _LoadingPage()
        : _BerwarnaListView(items: _items, hasMore: _hasMore, loading: _more, onLoadMore: _loadMore),
  );
}

class _PaginatedGrid extends StatefulWidget {
  final Future<List<ComicItem>> Function(int page) fetcher;
  final List<ComicItem> preloaded;
  const _PaginatedGrid({required this.fetcher, this.preloaded = const []});
  @override
  State<_PaginatedGrid> createState() => _PaginatedGridState();
}

class _PaginatedGridState extends State<_PaginatedGrid> {
  List<ComicItem> _items = [];
  int _page = 1;
  bool _loading = true;
  bool _hasMore = true;
  bool _more = false;
  String? _error;
  final _ctrl = ScrollController();

  @override
  void initState() {
    super.initState();
    if (widget.preloaded.isNotEmpty) {
      _items = List.from(widget.preloaded);
      _loading = false;
    } else {
      _load();
    }
    _ctrl.addListener(_onScroll);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _onScroll() {
    if (_ctrl.position.pixels >= _ctrl.position.maxScrollExtent - 200
        && !_more && _hasMore) _loadMore();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final d = await widget.fetcher(1);
      setState(() { _items = d; _page = 1; _loading = false; _hasMore = d.length >= 10; });
    } catch (e) { setState(() { _error = e.toString(); _loading = false; }); }
  }

  Future<void> _loadMore() async {
    setState(() => _more = true);
    try {
      final d = await widget.fetcher(_page + 1);
      setState(() { _items.addAll(d); _page++; _hasMore = d.isNotEmpty; _more = false; });
    } catch (_) { setState(() => _more = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const _LoadingPage();
    if (_error != null) return _ErrorPage(onRetry: _load, message: _error!);
    return GridView.builder(
      controller: _ctrl,
      padding: const EdgeInsets.all(12),
      gridDelegate: _grid3,
      itemCount: _items.length + (_more ? 1 : 0),
      itemBuilder: (_, i) {
        if (i == _items.length) return _spinner;
        return _ComicCard(item: _items[i]);
      },
    );
  }
}

class _ComicCard extends StatelessWidget {
  final ComicItem item;
  const _ComicCard({required this.item});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Navigator.push(context,
        MaterialPageRoute(builder: (_) => _ComicDetailPage(slug: item.slug))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Stack(fit: StackFit.expand, children: [
            item.image != null && item.image!.isNotEmpty
                ? Image.network(item.image!, fit: BoxFit.cover, headers: kImgHeaders,
                    errorBuilder: (_, __, ___) => const _NoImage())
                : const _NoImage(),
            Positioned(bottom: 0, left: 0, right: 0, height: 55,
                child: Container(decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter, end: Alignment.topCenter,
                    colors: [kCBg.withOpacity(0.95), Colors.transparent],
                  ),
                ))),
            if (item.chapter != null)
              Positioned(bottom: 5, left: 5, right: 5,
                  child: Text(item.chapter!,
                      style: const TextStyle(color: kCWhite, fontSize: 9, fontWeight: FontWeight.w700),
                      overflow: TextOverflow.ellipsis)),
            if (item.recommendationScore != null)
              Positioned(top: 5, right: 5,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(color: kCPrimary, borderRadius: BorderRadius.circular(5)),
                    child: Text(item.recommendationScore!.toStringAsFixed(1),
                        style: const TextStyle(color: kCWhite, fontSize: 9, fontWeight: FontWeight.w700)),
                  )),
            if (item.timeAgo != null)
              Positioned(top: 5, left: 5,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(5)),
                    child: Text(item.timeAgo!,
                        style: const TextStyle(color: kCAccentGlow, fontSize: 8, fontWeight: FontWeight.w600)),
                  )),
          ]),
        ),
      ),
      const SizedBox(height: 5),
      Text(item.title,
          style: const TextStyle(color: kCWhite, fontSize: 10, fontWeight: FontWeight.w600),
          maxLines: 2, overflow: TextOverflow.ellipsis),
      if (item.genre != null)
        Text(item.genre!, style: const TextStyle(color: kCWhite40, fontSize: 9)),
    ]),
  );
}

class _SliverHList extends StatelessWidget {
  final List<ComicItem> items;
  final double height;
  final bool showTimeAgo;
  final bool showScore;
  const _SliverHList({required this.items, required this.height,
      this.showTimeAgo = false, this.showScore = false});

  @override
  Widget build(BuildContext context) => SliverToBoxAdapter(
    child: SizedBox(
      height: height,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: items.length,
        itemBuilder: (_, i) => SizedBox(
          width: 115,
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
              child: _ComicCard(item: items[i])),
        ),
      ),
    ),
  );
}

class _BerwarnaCard extends StatelessWidget {
  final BerwarnaItem item;
  const _BerwarnaCard({required this.item});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Navigator.push(context,
        MaterialPageRoute(builder: (_) => _ComicDetailPage(slug: item.slug))),
    child: Container(
      width: 210,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kCPrimary.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(children: [
          _Badge(item.type, kCAccent),
          const SizedBox(width: 6),
          _Badge('Berwarna', Colors.purpleAccent),
        ]),
        Text(item.title,
            style: const TextStyle(color: kCWhite, fontWeight: FontWeight.w700, fontSize: 12),
            maxLines: 1, overflow: TextOverflow.ellipsis),
        Row(children: [
          const FaIcon(FontAwesomeIcons.bookOpen, size: 9, color: kCAccent),
          const SizedBox(width: 4),
          Expanded(child: Text(item.latestChapterTitle ?? '',
              style: const TextStyle(color: kCWhite70, fontSize: 10),
              overflow: TextOverflow.ellipsis)),
        ]),
        Text(item.stats, style: const TextStyle(color: kCWhite40, fontSize: 9),
            maxLines: 1, overflow: TextOverflow.ellipsis),
      ]),
    ),
  );
}

class _BerwarnaListView extends StatelessWidget {
  final List<BerwarnaItem> items;
  final bool hasMore, loading;
  final VoidCallback onLoadMore;
  const _BerwarnaListView({required this.items, required this.hasMore,
      required this.loading, required this.onLoadMore});

  @override
  Widget build(BuildContext context) => ListView.builder(
    padding: const EdgeInsets.all(12),
    itemCount: items.length + (hasMore ? 1 : 0),
    itemBuilder: (_, i) {
      if (i == items.length) {
        if (loading) return _spinner;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Center(child: GestureDetector(
            onTap: onLoadMore,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [kCPrimary, kCPrimaryLight]),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                FaIcon(FontAwesomeIcons.arrowDown, size: 12, color: kCWhite),
                SizedBox(width: 8),
                Text('Muat Lebih Banyak', style: TextStyle(color: kCWhite, fontWeight: FontWeight.w700)),
              ]),
            ),
          )),
        );
      }
      final item = items[i];
      return GestureDetector(
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => _ComicDetailPage(slug: item.slug))),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(color: kCCard, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            ClipRRect(
              borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
              child: item.thumbnail.isNotEmpty
                  ? Image.network(item.thumbnail, width: 100, height: 80, fit: BoxFit.cover, headers: kImgHeaders,
                      errorBuilder: (_, __, ___) => Container(width: 100, height: 80, color: kCSurface,
                          child: const Center(child: FaIcon(FontAwesomeIcons.image, color: kCWhite40))))
                  : Container(width: 100, height: 80, color: kCSurface,
                      child: const Center(child: FaIcon(FontAwesomeIcons.image, color: kCWhite40))),
            ),
            const SizedBox(width: 12),
            Expanded(child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [_Badge(item.type, kCAccent), const SizedBox(width: 6), _Badge('Berwarna', Colors.purpleAccent)]),
                const SizedBox(height: 4),
                Text(item.title,
                    style: const TextStyle(color: kCWhite, fontWeight: FontWeight.w700, fontSize: 13),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                Text('${item.genre}',
                    style: const TextStyle(color: kCWhite70, fontSize: 11)),
                const SizedBox(height: 2),
                Text(item.latestChapterTitle ?? '',
                    style: const TextStyle(color: kCAccent, fontSize: 11),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                Text(item.stats, style: const TextStyle(color: kCWhite40, fontSize: 10),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
              ]),
            )),
            const Padding(
              padding: EdgeInsets.only(right: 12),
              child: FaIcon(FontAwesomeIcons.chevronRight, size: 11, color: kCWhite40),
            ),
          ]),
        ),
      );
    },
  );
}

class _TrendingRanked extends StatelessWidget {
  final List<ComicItem> items;
  const _TrendingRanked({required this.items});

  @override
  Widget build(BuildContext context) => ListView.builder(
    padding: const EdgeInsets.all(12),
    itemCount: items.length,
    itemBuilder: (_, i) {
      final item = items[i];
      final rank = i + 1;
      final top3 = rank <= 3;
      return GestureDetector(
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => _ComicDetailPage(slug: item.slug))),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kCCard,
            borderRadius: BorderRadius.circular(10),
            border: top3 ? Border.all(color: kCPrimary.withOpacity(0.45)) : null,
          ),
          child: Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: top3 ? kCPrimary : kCPrimary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(child: Text('#$rank',
                  style: TextStyle(color: top3 ? kCWhite : kCAccent,
                      fontWeight: FontWeight.w900, fontSize: 13))),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.title,
                  style: const TextStyle(color: kCWhite, fontSize: 13, fontWeight: FontWeight.w600),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(item.chapter ?? '', style: const TextStyle(color: kCAccent, fontSize: 11)),
            ])),
            if (top3) const FaIcon(FontAwesomeIcons.crown, size: 14, color: kCAccent),
          ]),
        ),
      );
    },
  );
}

class _PustakaList extends StatelessWidget {
  final List<BerwarnaItem> items;
  const _PustakaList({required this.items});

  @override
  Widget build(BuildContext context) => ListView.builder(
    padding: const EdgeInsets.all(12),
    itemCount: items.length,
    itemBuilder: (_, i) {
      final item = items[i];
      return GestureDetector(
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => _ComicDetailPage(slug: item.slug))),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: kCCard, borderRadius: BorderRadius.circular(10)),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(color: kCPrimary.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: const Center(child: FaIcon(FontAwesomeIcons.book, size: 18, color: kCAccent)),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.title,
                  style: const TextStyle(color: kCWhite, fontSize: 13, fontWeight: FontWeight.w600),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              Text('${item.type} • ${item.genre}',
                  style: const TextStyle(color: kCWhite70, fontSize: 11)),
              Text(item.stats, style: const TextStyle(color: kCWhite40, fontSize: 10),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
            ])),
            const FaIcon(FontAwesomeIcons.chevronRight, size: 11, color: kCWhite40),
          ]),
        ),
      );
    },
  );
}

class _ChapterTile extends StatelessWidget {
  final Map<String, dynamic> chapter;
  final VoidCallback onTap;
  const _ChapterTile({required this.chapter, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: kCCard, borderRadius: BorderRadius.circular(8)),
      child: Row(children: [
        Container(
          width: 38, height: 34,
          decoration: BoxDecoration(color: kCPrimary.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
          child: Center(child: Text(chapter['chapter'] ?? '',
              style: const TextStyle(color: kCAccent, fontWeight: FontWeight.w800, fontSize: 9),
              textAlign: TextAlign.center, maxLines: 2)),
        ),
        const SizedBox(width: 12),
        Expanded(child: Text(chapter['chapter'] ?? '',
            style: const TextStyle(color: kCWhite, fontSize: 12, fontWeight: FontWeight.w500))),
        Text(chapter['date'] ?? '', style: const TextStyle(color: kCWhite40, fontSize: 10)),
        const SizedBox(width: 8),
        const FaIcon(FontAwesomeIcons.bookOpen, size: 10, color: kCWhite40),
      ]),
    ),
  );
}

class _Section extends StatelessWidget {
  final String title; final IconData icon;
  const _Section({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) => SliverToBoxAdapter(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
      child: Row(children: [
        Container(width: 3, height: 17,
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [kCPrimary, kCAccent]),
              borderRadius: BorderRadius.circular(2),
            )),
        const SizedBox(width: 10),
        FaIcon(icon, size: 12, color: kCAccent),
        const SizedBox(width: 7),
        Text(title, style: const TextStyle(color: kCWhite, fontSize: 15, fontWeight: FontWeight.w700)),
      ]),
    ),
  );
}

class _AppBarTitle extends StatelessWidget {
  final String title; final IconData icon;
  const _AppBarTitle({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) => Row(children: [
    FaIcon(icon, size: 15, color: kCAccent),
    const SizedBox(width: 8),
    Text(title, style: const TextStyle(color: kCWhite, fontWeight: FontWeight.w800, fontSize: 18)),
  ]);
}

class _AppBarAction extends StatelessWidget {
  final IconData icon; final String tooltip; final Widget page;
  const _AppBarAction({required this.icon, required this.tooltip, required this.page});

  @override
  Widget build(BuildContext context) => IconButton(
    icon: FaIcon(icon, size: 16, color: kCWhite70),
    tooltip: tooltip,
    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
  );
}

class _MetaBadges extends StatelessWidget {
  final Map<String, dynamic> metadata;
  const _MetaBadges({required this.metadata});

  @override
  Widget build(BuildContext context) => Wrap(spacing: 6, children: [
    if (metadata['type'] != null) _Badge(metadata['type']!, kCAccent),
    if (metadata['status'] != null) _Badge(metadata['status']!, kCGreen),
    if (metadata['age_rating'] != null) _Badge(metadata['age_rating']!, kCWhite70),
  ]);
}

class _Badge extends StatelessWidget {
  final String label; final Color color;
  const _Badge(this.label, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(
      color: color.withOpacity(0.15),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(label, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
  );
}

class _InfoGrid extends StatelessWidget {
  final Map<String, dynamic> metadata;
  const _InfoGrid({required this.metadata});

  @override
  Widget build(BuildContext context) {
    final entries = [
      ['Tipe', metadata['type']], ['Pengarang', metadata['author']],
      ['Status', metadata['status']], ['Konsep', metadata['concept']],
      ['Rating Usia', metadata['age_rating']], ['Arah Baca', metadata['reading_direction']],
    ].where((e) => e[1] != null && e[1].toString().isNotEmpty).toList();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCCard, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kCPrimary.withOpacity(0.2)),
      ),
      child: Wrap(spacing: 16, runSpacing: 10,
        children: entries.map((e) => SizedBox(
          width: (MediaQuery.of(context).size.width - 72) / 2,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(e[0] ?? '', style: const TextStyle(color: kCWhite40, fontSize: 10)),
            Text(e[1]?.toString() ?? '-',
                style: const TextStyle(color: kCWhite, fontSize: 12, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis),
          ]),
        )).toList(),
      ),
    );
  }
}

Widget _SectionTitle(String text) => Padding(
  padding: const EdgeInsets.fromLTRB(0, 0, 0, 6),
  child: Text(
    text,
    style: const TextStyle(
      color: kCWhite,
      fontSize: 14,
      fontWeight: FontWeight.w700,
    ),
  ),
);

class _PrimaryBtn extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback? onTap;
  const _PrimaryBtn({required this.icon, required this.label, this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: onTap != null
            ? [kCPrimary, kCPrimaryLight] : [kCCard, kCCard]),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        FaIcon(icon, size: 12, color: onTap != null ? kCWhite : kCWhite40),
        const SizedBox(width: 8),
        Text(label, style: TextStyle(color: onTap != null ? kCWhite : kCWhite40,
            fontWeight: FontWeight.w700)),
      ]),
    ),
  );
}

class _IconBtn extends StatelessWidget {
  final IconData icon; final VoidCallback? onTap;
  const _IconBtn({required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCCard, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kCPrimary),
      ),
      child: FaIcon(icon, size: 16, color: kCAccent),
    ),
  );
}

class _NavBtn extends StatelessWidget {
  final String label; final IconData icon;
  final bool iconRight, enabled;
  final VoidCallback? onTap;
  const _NavBtn({required this.label, required this.icon,
      this.iconRight = false, required this.enabled, this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: enabled ? onTap : null,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: enabled ? kCPrimary : kCCard,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        if (!iconRight) ...[
          FaIcon(icon, size: 11, color: enabled ? kCWhite : kCWhite40),
          const SizedBox(width: 5),
        ],
        Text(label, style: TextStyle(color: enabled ? kCWhite : kCWhite40,
            fontSize: 12, fontWeight: FontWeight.w600)),
        if (iconRight) ...[
          const SizedBox(width: 5),
          FaIcon(icon, size: 11, color: enabled ? kCWhite : kCWhite40),
        ],
      ]),
    ),
  );
}

class _BackBtn extends StatelessWidget {
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => Navigator.pop(context),
    child: Container(
      margin: const EdgeInsets.all(8),
      decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
      child: const Icon(Icons.arrow_back, color: kCWhite),
    ),
  );
}

class _NoImage extends StatelessWidget {
  const _NoImage();
  @override
  Widget build(BuildContext context) => Container(
    color: kCCard,
    child: const Center(child: FaIcon(FontAwesomeIcons.image, color: kCWhite40, size: 22)),
  );
}

class _LoadingPage extends StatelessWidget {
  const _LoadingPage();
  @override
  Widget build(BuildContext context) => const Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      CircularProgressIndicator(color: kCPrimary, strokeWidth: 2),
      SizedBox(height: 12),
      Text('Memuat...', style: TextStyle(color: kCWhite40, fontSize: 13)),
    ]),
  );
}

class _ErrorPage extends StatelessWidget {
  final VoidCallback onRetry; final String message;
  const _ErrorPage({required this.onRetry, required this.message});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const FaIcon(FontAwesomeIcons.circleExclamation, size: 48, color: kCPrimary),
        const SizedBox(height: 14),
        const Text('Gagal Memuat', style: TextStyle(color: kCWhite, fontSize: 16, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text(message, style: const TextStyle(color: kCWhite40, fontSize: 11),
            textAlign: TextAlign.center, maxLines: 3),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: onRetry,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [kCPrimary, kCPrimaryLight]),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              FaIcon(FontAwesomeIcons.rotateRight, size: 13, color: kCWhite),
              SizedBox(width: 8),
              Text('Coba Lagi', style: TextStyle(color: kCWhite, fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ]),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  final IconData icon; final String title, subtitle;
  const _EmptyState({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(color: kCCard, shape: BoxShape.circle),
        child: FaIcon(icon, size: 36, color: kCPrimary),
      ),
      const SizedBox(height: 14),
      Text(title, style: const TextStyle(color: kCWhite, fontSize: 16, fontWeight: FontWeight.w700)),
      const SizedBox(height: 6),
      Text(subtitle, style: const TextStyle(color: kCWhite40, fontSize: 13)),
    ]),
  );
}

const _grid3 = SliverGridDelegateWithFixedCrossAxisCount(
  crossAxisCount: 3, childAspectRatio: 0.58,
  crossAxisSpacing: 8, mainAxisSpacing: 8,
);

Widget get _spinner => const Center(
  child: Padding(padding: EdgeInsets.all(8),
      child: CircularProgressIndicator(color: kCPrimary, strokeWidth: 2)));

PreferredSizeWidget _styledTabBar(TabController ctrl, List<String> tabs) => TabBar(
  controller: ctrl,
  indicatorColor: kCAccent,
  labelColor: kCAccent,
  unselectedLabelColor: kCWhite40,
  labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
  unselectedLabelStyle: const TextStyle(fontSize: 12),
  tabs: tabs.map((t) => Tab(text: t)).toList(),
);