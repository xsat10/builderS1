import 'package:flutter/foundation.dart';
import '../models/news_item.dart';
import '../services/news_service.dart';

class NewsProvider extends ChangeNotifier {
  final NewsService _service = NewsService();

  /// Pengumuman dari server (dikelola developer lewat News Management).
  List<NewsItem> _news = [];

  /// Berita live dari web (CNN, dll.) — TERPISAH dari pengumuman.
  List<NewsItem> _berita = [];

  bool _loading = false;

  List<NewsItem> get news => _news;
  List<NewsItem> get berita => _berita;
  bool get loading => _loading;

  Future<void> loadNews() async {
    _loading = true;
    notifyListeners();

    // Pengumuman server (tidak dicampur berita).
    _news = await _service.getNews();

    // Berita live web (punya gambar), terpisah.
    _berita = await _service.getLatestNews();

    _loading = false;
    notifyListeners();
  }

  Future<bool> addNews(NewsItem item) async {
    final ok = await _service.createNews(item);
    if (ok) await loadNews();
    return ok;
  }

  Future<bool> editNews(String id, NewsItem item) async {
    final ok = await _service.updateNews(id, item);
    if (ok) await loadNews();
    return ok;
  }

  Future<bool> removeNews(String id) async {
    final ok = await _service.deleteNews(id);
    if (ok) await loadNews();
    return ok;
  }
}
