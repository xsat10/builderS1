import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/wa_sender.dart';
import '../models/wa_function.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class WhatsAppProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  final SocketService _socket = SocketService();

  List<WaSender> _senders = [];
  List<WaFunction> _functions = [];
  List<Map<String, dynamic>> _protected = [];
  bool _protectedLoading = false;
  bool _functionsLoading = false;
  final Map<String, String> _qrCache = {};
  bool _loading = false;
  String? _error;
  String? _activeSenderId;
  bool _socketConnected = false;

  final List<StreamSubscription> _subscriptions = [];

  List<WaSender> get senders => _senders;
  List<WaFunction> get functions => _functions;
  List<Map<String, dynamic>> get protectedGroups => _protected;
  bool get protectedLoading => _protectedLoading;
  bool get functionsLoading => _functionsLoading;
  bool get loading => _loading;
  String? get error => _error;
  String? get activeSenderId => _activeSenderId;
  WaSender? get activeSender =>
      _activeSenderId == null ? null : senderById(_activeSenderId!);

  String? qrFor(String id) => _qrCache[id];

  int get totalSenders => _senders.length;
  int get connectedSenders =>
      _senders.where((s) => s.status == WaStatus.connected).length;
  int get connectingSenders => _senders
      .where(
        (s) =>
            s.status == WaStatus.connecting ||
            s.status == WaStatus.qr ||
            s.status == WaStatus.pairing,
      )
      .length;

  void connectSocket(String serverUrl, String token) {
    if (_socketConnected) return;
    _socket.connect(serverUrl, token);
    _socketConnected = true;
    _initSocket();
    notifyListeners();
  }

  void disconnectSocket() {
    _socket.disconnect();
    _socketConnected = false;
    for (final sub in _subscriptions) {
      sub.cancel();
    }
    _subscriptions.clear();
    notifyListeners();
  }

  void _initSocket() {
    _subscriptions.add(
      _socket.waStatusStream.listen((data) {
        final id = data['senderId']?.toString();
        if (id == null) return;
        final status = data['status']?.toString();
        final qr = data['qr']?.toString();
        final pairingCode = data['pairingCode']?.toString();
        if (qr != null && qr.isNotEmpty) _qrCache[id] = qr;
        if (status == WaStatus.qr) _qrCache[id] = _qrCache[id] ?? qr ?? '';
        if (status == WaStatus.disconnected) _qrCache.remove(id);

        final idx = _senders.indexWhere((s) => s.id == id);
        if (idx >= 0 && status != null) {
          final s = _senders[idx];
          _senders[idx] = s.copyWith(
            status: status,
            pairingCode: pairingCode != null && pairingCode.isNotEmpty
                ? pairingCode
                : (status == WaStatus.disconnected ? null : s.pairingCode),
          );
        }
        notifyListeners();
      }),
    );

    _subscriptions.add(
      _socket.waSenderCreatedStream.listen((data) {
        final senderJson = data['sender'];
        if (senderJson is Map) {
          final s = WaSender.fromJson(Map<String, dynamic>.from(senderJson));
          if (!_senders.any((e) => e.id == s.id)) {
            _senders.add(s);
            notifyListeners();
          }
        }
      }),
    );

    _subscriptions.add(
      _socket.waSenderUpdatedStream.listen((data) {
        final senderJson = data['sender'];
        if (senderJson is Map) {
          final s = WaSender.fromJson(Map<String, dynamic>.from(senderJson));
          final idx = _senders.indexWhere((e) => e.id == s.id);
          if (idx >= 0) {
            _senders[idx] = s;
          } else {
            _senders.add(s);
          }
          notifyListeners();
        }
      }),
    );

    _subscriptions.add(
      _socket.waSenderDeletedStream.listen((data) {
        final id = data['senderId']?.toString();
        if (id == null) return;
        _senders.removeWhere((s) => s.id == id);
        _qrCache.remove(id);
        if (_activeSenderId == id) _activeSenderId = null;
        notifyListeners();
      }),
    );
  }

  Future<void> loadSenders() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final result = await _api.getWaSenders();
      if (result['success'] == true) {
        final list = result['data'] as List? ?? [];
        _senders = list
            .whereType<Map>()
            .map((e) => WaSender.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } else {
        _error = result['error']?['message'] ?? 'Gagal memuat sender';
      }
    } catch (e) {
      _error = 'Gagal memuat sender: $e';
    }
    _loading = false;
    notifyListeners();
  }

  Future<Map<String, dynamic>> createSender(
    String phoneNumber, {
    String visibility = 'private',
    String? sessionName,
  }) async {
    final result = await _api.createWaSender(
      phoneNumber,
      visibility: visibility,
      sessionName: sessionName,
    );
    if (result['success'] == true && result['data'] is Map) {
      final s = WaSender.fromJson(
        Map<String, dynamic>.from(result['data'] as Map),
      );
      if (!_senders.any((e) => e.id == s.id)) _senders.add(s);
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> startQr(String id) async {
    final result = await _api.startWaQr(id);
    if (result['success'] == true) _applyStatus(id, WaStatus.connecting);
    return result;
  }

  Future<Map<String, dynamic>> startPairing(String id) async {
    final result = await _api.startWaPairing(id);
    if (result['success'] == true) _applyStatus(id, WaStatus.pairing);
    return result;
  }

  Future<Map<String, dynamic>> refreshStatus(String id) async {
    final result = await _api.getWaSenderStatus(id);
    if (result['success'] == true && result['data'] is Map) {
      final d = Map<String, dynamic>.from(result['data'] as Map);
      final qr = d['qr']?.toString();
      final pairingCode = d['pairingCode']?.toString();
      final status = d['status']?.toString();
      if (qr != null && qr.isNotEmpty) _qrCache[id] = qr;
      if (status != null) _applyStatus(id, status);
      if (status == WaStatus.qr && qr != null) _qrCache[id] = qr;
      final idx = _senders.indexWhere((s) => s.id == id);
      if (idx >= 0 && pairingCode != null && pairingCode.isNotEmpty) {
        _senders[idx] = _senders[idx].copyWith(pairingCode: pairingCode);
      }
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> disconnect(String id) async {
    final result = await _api.disconnectWaSender(id);
    if (result['success'] == true) _applyStatus(id, WaStatus.disconnected);
    return result;
  }

  Future<Map<String, dynamic>> setSenderEnabled(String id, bool enabled) async {
    final result = await _api.updateWaSender(id, {'enabled': enabled});
    if (result['success'] == true && result['data'] is Map) {
      final s = WaSender.fromJson(
        Map<String, dynamic>.from(result['data'] as Map),
      );
      final idx = _senders.indexWhere((e) => e.id == s.id);
      if (idx >= 0) {
        _senders[idx] = s;
      } else {
        _senders.add(s);
      }
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> updateVisibility(
    String id,
    String visibility,
  ) async {
    final result = await _api.updateWaSender(id, {'visibility': visibility});
    if (result['success'] == true && result['data'] is Map) {
      final s = WaSender.fromJson(
        Map<String, dynamic>.from(result['data'] as Map),
      );
      final idx = _senders.indexWhere((e) => e.id == s.id);
      if (idx >= 0) {
        _senders[idx] = s;
      } else {
        _senders.add(s);
      }
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> setSenderProtected(
    String id,
    bool protected,
  ) async {
    final result = await _api.updateWaSender(id, {'protected': protected});
    if (result['success'] == true && result['data'] is Map) {
      final s = WaSender.fromJson(
        Map<String, dynamic>.from(result['data'] as Map),
      );
      final idx = _senders.indexWhere((e) => e.id == s.id);
      if (idx >= 0) {
        _senders[idx] = s;
      } else {
        _senders.add(s);
      }
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> deleteSender(String id) async {
    final result = await _api.deleteWaSender(id);
    if (result['success'] == true) {
      _senders.removeWhere((s) => s.id == id);
      _qrCache.remove(id);
      if (_activeSenderId == id) _activeSenderId = null;
      notifyListeners();
    }
    return result;
  }

  Future<void> loadFunctions({bool activeOnly = false}) async {
    _functionsLoading = true;
    notifyListeners();
    final result = await _api.getWaFunctions(activeOnly: activeOnly);
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _functions = list
          .map((e) => WaFunction.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    _functionsLoading = false;
    notifyListeners();
  }

  Future<Map<String, dynamic>> execute(
    String senderId,
    String targetNumber,
    String functionId,
  ) {
    return _api.executeWaFunction(senderId, targetNumber, functionId);
  }

  Future<void> loadProtectedGroups() async {
    _protectedLoading = true;
    notifyListeners();
    final result = await _api.getWaProtectedGroups();
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _protected = list
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }
    _protectedLoading = false;
    notifyListeners();
  }

  Future<Map<String, dynamic>> addProtectedGroup(
    String slotId,
    String groupId, {
    String groupName = '',
    String kind = 'group',
  }) async {
    final result = await _api.addWaProtectedGroup(
      slotId,
      groupId,
      groupName: groupName,
      kind: kind,
    );
    if (result['success'] == true && result['data'] is Map) {
      _protected.insert(0, Map<String, dynamic>.from(result['data'] as Map));
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> removeProtectedGroup(String id) async {
    final result = await _api.deleteWaProtectedGroup(id);
    if (result['success'] == true) {
      _protected.removeWhere((g) => (g['id'] ?? '').toString() == id);
      notifyListeners();
    }
    return result;
  }

  void _applyStatus(String id, String status) {
    final idx = _senders.indexWhere((s) => s.id == id);
    if (idx >= 0) {
      _senders[idx] = _senders[idx].copyWith(
        status: status,
        pairingCode: status == WaStatus.disconnected
            ? null
            : _senders[idx].pairingCode,
      );
      if (status == WaStatus.disconnected) _qrCache.remove(id);
      notifyListeners();
    }
  }

  void selectSender(String id) {
    _activeSenderId = id;
    notifyListeners();
  }

  void clearActiveSender() {
    _activeSenderId = null;
    notifyListeners();
  }

  WaSender? senderById(String id) {
    for (final s in _senders) {
      if (s.id == id) return s;
    }
    return null;
  }

  @override
  void dispose() {
    for (final sub in _subscriptions) {
      sub.cancel();
    }
    _socket.dispose();
    super.dispose();
  }
}
