import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/neo_skin.dart';
import '../theme.dart' show NeoThemeBind;

/// Sumber kebenaran tunggal untuk skin NovaCore.
///
/// API minimal:
/// - String get skinId
/// - NeoPalette get palette
/// - Future<void> loadFromDisk()
/// - Future<void> setSkin(String id)
class NeoThemeProvider extends ChangeNotifier {
  static const String storageKey = 'neo_skin_id';

  String _skinId = NeoSkin.defaultId;

  /// Mengikat palet aktif ke token global (NeoColors/NeoGlass getters)
  /// yang dibaca seluruh UI.
  NeoPalette get palette {
    final p = NeoSkin.byId[_skinId] ?? NeoSkin.defaultPalette;
    NeoSkin.defaultId = _skinId;
    NeoThemeBind.activate(p);
    return p;
  }

  String get skinId => _skinId;

  // --- Helper generalisasi theme ---
  bool get isGoldEmerald => _skinId == NeoSkinId.goldEmerald;
  bool get isAmethystViolet => _skinId == NeoSkinId.amethystViolet;
  bool get isNeonCyber => _skinId == NeoSkinId.neonCyber;

  // Kompatibilitas lama (midnight/bubbleGum masih tersimpan di disk).
  bool get isBubbleGum => _skinId == NeoSkinId.bubbleGum;
  bool get isLegacy => !NeoSkinId.isPickerSkin(_skinId);

  /// Mengambil tema dari disk. Jika ID tidak dikenal → fallback goldEmerald.
  /// Tema lama (midnight/bubbleGum) tetap dihormati agar tidak merusak
  /// penyimpanan pengguna yang sudah ada.
  Future<void> loadFromDisk() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(storageKey);
    if (saved != null && NeoSkin.byId.containsKey(saved)) {
      _skinId = saved;
    } else {
      _skinId = NeoSkin.defaultId;
    }
    notifyListeners();
  }

  Future<void> setSkin(String id) async {
    if (!NeoSkin.byId.containsKey(id)) return;
    if (_skinId == id) {
      notifyListeners();
      return;
    }
    _skinId = id;
    NeoSkin.defaultId = id;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(storageKey, id);
  }

  /// Kompatibilitas: toggle lama. Sekarang berputar di antara 3 theme utama.
  void toggle() {
    final next = switch (_skinId) {
      NeoSkinId.goldEmerald => NeoSkinId.amethystViolet,
      NeoSkinId.amethystViolet => NeoSkinId.neonCyber,
      _ => NeoSkinId.goldEmerald,
    };
    setSkin(next);
  }
}