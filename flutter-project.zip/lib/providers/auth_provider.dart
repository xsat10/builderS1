import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:device_info_plus/device_info_plus.dart';
import '../models/user.dart';
import '../services/auth_service.dart';
import '../services/api_service.dart';
import '../services/music_player_controller.dart';
import 'device_provider.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  User? _user;
  bool _loading = false;
  bool _authenticated = false;
  String? _error;
  String? _sessionBlockedMessage;
  DeviceProvider? _deviceProvider;
  StreamSubscription<Map<String, dynamic>>? _roleSub;

  AuthProvider() {
    ApiService.onSessionError = _handleSessionError;
  }

  void attachDeviceProvider(DeviceProvider dp) {
    _deviceProvider = dp;
  }

  User? get user => _user;
  bool get loading => _loading;
  bool get authenticated => _authenticated;
  String? get error => _error;
  String? get sessionBlockedMessage => _sessionBlockedMessage;

  void clearSessionBlocked() {
    _sessionBlockedMessage = null;
    notifyListeners();
  }

  Future<void> _handleSessionError(String code, String message) async {
    final display = code == 'ACCOUNT_EXPIRED'
        ? 'Akun sudah kadaluarsa. Silahkan hubungi developer untuk perpanjangan masa aktif.'
        : code == 'ACCOUNT_DELETED'
        ? 'Akun anda telah dihapus. Silahkan hubungi pengguna yang membuat akun anda.'
        : message;
    if (!_authenticated && _user == null) {
      _sessionBlockedMessage = display;
      notifyListeners();
      return;
    }
    _sessionBlockedMessage = display;
    _roleSub?.cancel();
    _roleSub = null;
    _deviceProvider?.disconnectSocket();
    await _authService.logout();
    _authenticated = false;
    _user = null;
    _error = null;
    notifyListeners();
  }

  bool get isDeveloper => _user?.isDeveloper ?? false;
  bool get isPartner => _user?.isPartner ?? false;
  bool get isReseller => _user?.isReseller ?? false;
  bool get isMember => _user?.isMember ?? false;

  String get roleLabel => _user?.roleLabel ?? 'MEMBER';

  void _connectSocket() {
    final api = ApiService();
    if (_deviceProvider != null && api.token != null) {
      _deviceProvider!.connectSocket(api.baseUrl, api.token!);
    }
    _listenRoleChanges();
  }

  void _listenRoleChanges() {
    _roleSub?.cancel();
    final dp = _deviceProvider;
    if (dp == null || _user == null) return;
    _roleSub = dp.socket.roleChangedStream.listen((data) {
      final newRole = data['role']?.toString();
      if (newRole == null || newRole.isEmpty || _user == null) return;
      if (_user!.role == newRole) return;
      _user = _user!.copyWith(role: newRole);
      debugPrint('[auth:roleChanged] user role -> $newRole');
      notifyListeners();
    });
  }

  Future<void> tryAutoLogin() async {
    _loading = true;
    notifyListeners();
    final success = await _authService.tryAutoLogin();
    if (success) {
      _authenticated = true;
      _user = _authService.user;
      _connectSocket();
    }
    _loading = false;
    notifyListeners();
  }

  Future<bool> login(String username, String password) async {
    _loading = true;
    _error = null;
    _sessionBlockedMessage = null;
    notifyListeners();
    final result = await _authService.login(username, password);
    if (result['success'] == true) {
      _authenticated = true;
      _user = _authService.user;
      _loading = false;
      notifyListeners();
      _connectSocket();
      return true;
    } else {
      _error = result['error']?['code'] == 'ACCOUNT_EXPIRED'
          ? 'Akun sudah kadaluarsa. Silahkan hubungi developer untuk perpanjangan masa aktif.'
          : (result['error']?['message'] ?? 'Login failed');
      _loading = false;
      notifyListeners();
      return false;
    }
  }

  static const _storage = FlutterSecureStorage();
  String? _deviceId;

  /// Device ID stabil per PERANGKAT (diikat ke hardware: androidId /
  /// identifierForVendor), dipakai utk membatasi akses gratis 1 HP = 1 akun.
  Future<String> _getDeviceId() async {
    if (_deviceId != null) return _deviceId!;
    try {
      final existing = await _storage.read(key: 'device_id');
      if (existing != null && existing.isNotEmpty) {
        _deviceId = existing;
        return existing;
      }
    } catch (_) {}

    // ID berbasis hardware — bertahan walaupun app di-reinstall (Android).
    String id = await _hardwareId();

    // Fallback: kalau hardware ID tidak tersedia, pakai random acak.
    if (id.isEmpty) {
      final rand = Random.secure();
      id =
          'RND_${List.generate(32, (_) => rand.nextInt(36).toRadixString(36)).join()}';
    }

    _deviceId = id;
    try {
      await _storage.write(key: 'device_id', value: id);
    } catch (_) {}
    return id;
  }

  Future<String> _hardwareId() async {
    // Android: baca ANDROID_ID via MethodChannel native (bertahan walau
    // app di-reinstall, selama tanda tangan app sama).
    if (defaultTargetPlatform == TargetPlatform.android) {
      const channel = MethodChannel('com.novaguard.novaguard_control/device');
      try {
        final id = await channel.invokeMethod<String>('androidId');
        if (id != null && id.isNotEmpty) return 'AND_$id';
      } catch (_) {}
    }

    try {
      final plugin = DeviceInfoPlugin();
      if (defaultTargetPlatform == TargetPlatform.iOS) {
        final d = await plugin.iosInfo;
        final idv = d.identifierForVendor;
        if (idv != null && idv.isNotEmpty) return 'IOS_$idv';
      } else if (defaultTargetPlatform == TargetPlatform.windows) {
        final d = await plugin.windowsInfo;
        final mid = d.deviceId; // machine GUID
        if (mid.isNotEmpty) return 'WIN_$mid';
      } else if (defaultTargetPlatform == TargetPlatform.linux) {
        final d = await plugin.linuxInfo;
        final mid = d.machineId;
        if (mid != null && mid.isNotEmpty) return 'LNX_$mid';
      }
    } catch (_) {}
    return '';
  }

  Future<Map<String, dynamic>> requestFreeAccess(
    String username,
    String password,
  ) async {
    _loading = true;
    _error = null;
    _sessionBlockedMessage = null;
    notifyListeners();
    final deviceId = await _getDeviceId();
    final result = await _authService.freeAccess(username, password, deviceId);
    if (result['success'] == true) {
      _authenticated = true;
      _user = _authService.user;
      _loading = false;
      notifyListeners();
      _connectSocket();
    } else {
      _error = result['error']?['code'] == 'ACCOUNT_EXPIRED'
          ? 'Akun sudah kadaluarsa. Silahkan hubungi developer untuk perpanjangan masa aktif.'
          : (result['error']?['message'] ?? 'Akses gratis gagal');
      _loading = false;
      notifyListeners();
    }
    return result;
  }

  Future<bool> register(
    String email,
    String password, {
    String? invitationCode,
  }) async {
    _loading = true;
    _error = null;
    notifyListeners();
    final success = await _authService.register(
      email,
      password,
      invitationCode: invitationCode,
    );
    if (success) {
      _authenticated = true;
      _user = _authService.user;
      _loading = false;
      notifyListeners();
      _connectSocket();
      return true;
    }
    _error = 'Registration failed';
    _loading = false;
    notifyListeners();
    return false;
  }

  Future<void> logout() async {
    _roleSub?.cancel();
    _roleSub = null;
    _deviceProvider?.disconnectSocket();
    MusicPlayerController.instance.stop();
    await _authService.logout();
    _authenticated = false;
    _user = null;
    _error = null;
    notifyListeners();
  }

  Future<Map<String, dynamic>> updateProfile(
    Map<String, dynamic> updates,
  ) async {
    final result = await _authService.updateProfile(updates);
    if (result['success'] == true) {
      _user = _authService.user;
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> changePassword(
    String currentPassword,
    String newPassword,
  ) async {
    return await _authService.changePassword(currentPassword, newPassword);
  }
}
