import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/device.dart';
import '../models/activity.dart';
import '../models/notification.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class DeviceProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  final SocketService _socket = SocketService();
  List<Device> _devices = [];
  List<Activity> _activities = [];
  List<AppNotification> _notifications = [];
  Device? _selectedDevice;
  bool _loading = false;
  String? _error;
  bool _socketConnected = false;
  final Map<String, String> _viewerByDevice = {};
  final Map<String, String> _prevStatus = {};
  final StreamController<Map<String, dynamic>> _statusEventController = StreamController.broadcast();

  List<Device> get devices => _devices;
  Device? get selectedDevice => _selectedDevice;
  List<Activity> get activities => _activities;
  List<AppNotification> get notifications => _notifications;
  bool get loading => _loading;
  String? get error => _error;
  bool get socketConnected => _socketConnected;
  SocketService get socket => _socket;
  Stream<Map<String, dynamic>> get statusEventStream => _statusEventController.stream;

  String? viewerOf(String deviceId) => _viewerByDevice[deviceId];

  bool isLockedFor(String deviceId, String myUserId) {
    final viewer = _viewerByDevice[deviceId];
    if (viewer == null || viewer == myUserId) return false;
    final device = _devices.where((d) => d.id == deviceId).firstOrNull;
    if (device != null && device.ownerId == myUserId) return false;
    return true;
  }

  void emitView(String deviceId) => _socket.emitView(deviceId);

  void emitUnview(String deviceId) => _socket.emitUnview(deviceId);

  int get totalDevices => _devices.length;
  int get onlineDevices => _devices.where((d) => d.isOnline).length;
  int get offlineDevices => _devices.where((d) => !d.isOnline).length;

  final List<StreamSubscription> _subscriptions = [];

  void connectSocket(String serverUrl, String token) {
    _serverUrl = serverUrl;
    _token = token;
    if (_socketConnected) return;
    _socket.connect(serverUrl, token);
    _socketConnected = true;
    initSocket();
    notifyListeners();
    _startWatchdog();
  }

  String? _serverUrl;
  String? _token;
  Timer? _watchdogTimer;

  void _startWatchdog() {
    _watchdogTimer?.cancel();
    _watchdogTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      final url = _serverUrl;
      final tk = _token;
      if (url == null || tk == null) return;
      if (!_socket.isConnected) {
        debugPrint('[socket:watchdog] socket not connected, reconnecting to $url');
        _socket.connect(url, tk);
      }
    });
  }

  void disconnectSocket() {
    _watchdogTimer?.cancel();
    _watchdogTimer = null;
    _socket.disconnect();
    _socketConnected = false;
    notifyListeners();
  }

  Future<void> loadDevices() async {
    _loading = true;
    _error = null;
    notifyListeners();
    final result = await _api.getDevices();
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _devices = list.map((e) => Device.fromJson(e as Map<String, dynamic>)).toList();
      final viewerIds = <String, String>{};
      for (final e in list) {
        final id = e['id'] as String?;
        final vId = e['viewer_id'] as String?;
        if (id != null && vId != null && vId.isNotEmpty) {
          viewerIds[id] = vId;
        }
      }
      _viewerByDevice.clear();
      _viewerByDevice.addAll(viewerIds);
    } else {
      _error = result['error']?['message'] ?? 'Failed to load devices';
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> loadDeviceDetail(String id) async {
    _loading = true;
    _error = null;
    notifyListeners();
    final result = await _api.getDevice(id);
    if (result['success'] == true) {
      _selectedDevice = Device.fromJson(result['data'] as Map<String, dynamic>);
    } else {
      _error = result['error']?['message'] ?? 'Failed to load device';
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> loadActivities(String deviceId) async {
    final result = await _api.getDeviceActivity(deviceId);
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _activities = list.map((e) => Activity.fromJson(e as Map<String, dynamic>)).toList();
      notifyListeners();
    }
  }

  Future<void> loadMyActivities() async {
    final result = await _api.getMyActivities();
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _activities = list.map((e) => Activity.fromJson(e as Map<String, dynamic>)).toList();
      notifyListeners();
    }
  }

  Future<void> loadNotifications(String deviceId) async {
    final result = await _api.getDeviceNotifications(deviceId);
    if (result['success'] == true) {
      final list = result['data'] as List? ?? [];
      _notifications = list.map((e) => AppNotification.fromJson(e as Map<String, dynamic>)).toList();
      notifyListeners();
    }
  }

  void selectDevice(Device device) {
    _selectedDevice = device;
    notifyListeners();
  }

  void clearSelection() {
    _selectedDevice = null;
    notifyListeners();
  }

  void removeDevice(String id) {
    _devices.removeWhere((d) => d.id == id);
    if (_selectedDevice?.id == id) {
      _selectedDevice = null;
    }
    notifyListeners();
  }

  void initSocket() {
    final subConn = _socket.connectedStream.listen((connected) {
      if (!connected) return;
      loadDevices();
      final sel = _selectedDevice;
      if (sel != null) {
        _socket.emitView(sel.id);
      }
    });
    _subscriptions.add(subConn);

    final sub1 = _socket.deviceNewStream.listen((data) {
      final exists = _devices.any((d) => d.id == data['id']);
      if (!exists) {
        _devices.add(Device.fromJson(Map<String, dynamic>.from(data)));
        notifyListeners();
      }
    });
    _subscriptions.add(sub1);

    final subDeleted = _socket.deviceDeletedStream.listen((data) {
      final id = data['deviceId'] ?? data['device_id'];
      if (id != null) {
        removeDevice(id.toString());
      }
    });
    _subscriptions.add(subDeleted);

    final subOwnerChanged = _socket.deviceOwnerChangedStream.listen((data) {
      final id = data['deviceId'] ?? data['device_id'];
      if (id != null) {
        loadDevices();
      }
    });
    _subscriptions.add(subOwnerChanged);

    final sub2 = _socket.deviceStatusStream.listen((data) {
      final id = data['deviceId'] ?? data['device_id'];
      if (id != null) {
        final idx = _devices.indexWhere((d) => d.id == id);
        if (idx >= 0) {
          final d = _devices[idx];
          final newStatus = data['status'] as String?;
          if (newStatus != null && newStatus != d.status && (newStatus == 'online' || newStatus == 'offline')) {
            final previous = _prevStatus[id];
            _prevStatus[id] = newStatus;
            if (previous != null && previous != newStatus) {
              _statusEventController.add({
                'deviceId': id,
                'name': d.name,
                'status': newStatus,
                'ownerId': d.ownerId,
              });
            }
          }
          d.status = newStatus ?? d.status;
          if (data['battery'] != null) d.battery = (data['battery'] as num).toDouble();
          if (data['cpu'] != null) d.cpu = (data['cpu'] as num).toDouble();
          if (data['ram'] != null) d.ram = (data['ram'] as num).toDouble();
          if (data['storage'] != null) d.storage = (data['storage'] as num).toDouble();
          if (data['network'] != null) d.network = data['network'] as String;
          notifyListeners();
        }
      }
    });
    _subscriptions.add(sub2);

    final subViewing = _socket.viewingStream.listen((data) {
      final id = data['deviceId'] as String?;
      if (id == null) return;
      final viewerId = data['viewerId'] as String?;
      if (viewerId == null || viewerId.isEmpty) {
        _viewerByDevice.remove(id);
      } else {
        _viewerByDevice[id] = viewerId;
      }
      notifyListeners();
    });
    _subscriptions.add(subViewing);

    final sub3 = _socket.activityStream.listen((data) {
      if (data['type'] != null || data['action'] != null) {
        final activity = Activity(
          id: data['actionId'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
          userId: '',
          deviceId: data['deviceId'] ?? '',
          action: data['type'] ?? data['action'] ?? '',
          status: data['status'] ?? 'success',
          message: data['message'] ?? '',
          createdAt: data['timestamp'] ?? DateTime.now().toIso8601String(),
        );
        _activities.insert(0, activity);
        notifyListeners();
      }
    });
    _subscriptions.add(sub3);

    final sub4 = _socket.notificationStream.listen((data) {
      final notif = AppNotification(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        deviceId: data['deviceId'] ?? '',
        app: data['app'] ?? '',
        title: data['title'] ?? '',
        body: data['body'] ?? '',
        timestamp: data['timestamp'] ?? DateTime.now().toIso8601String(),
        createdAt: DateTime.now().toIso8601String(),
      );
      _notifications.insert(0, notif);
      notifyListeners();
    });
    _subscriptions.add(sub4);

    // 1 akun = 1 perangkat: server mengirim session:conflict saat akun ini
    // login di perangkat lain → paksakan logout + tampilkan dialog.
    final subConflict = _socket.sessionConflictStream.listen((data) {
      final msg = data['message']?.toString() ??
          'Akun anda baru saja login di perangkat lain. Silahkan login kembali.';
      ApiService.onSessionError?.call('LOGIN_ELSEWHERE', msg);
    });
    _subscriptions.add(subConflict);
  }

  @override
  void dispose() {
    for (final sub in _subscriptions) {
      sub.cancel();
    }
    _statusEventController.close();
    _socket.dispose();
    super.dispose();
  }

  void updateDeviceStatus(String deviceId, String status) {
    final idx = _devices.indexWhere((d) => d.id == deviceId);
    if (idx >= 0) {
      _devices[idx].status = status;
      notifyListeners();
    }
  }
}
