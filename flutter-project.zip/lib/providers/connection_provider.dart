import 'dart:async';
import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

class ConnectionProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  bool _connected = false;
  bool _checking = true;
  bool _socketConnected = false;
  String? _socketError;
  Timer? _monitorTimer;
  StreamSubscription<bool>? _socketSub;
  StreamSubscription<String>? _socketErrorSub;

  bool get connected => _connected;
  bool get checking => _checking;
  bool get socketConnected => _socketConnected;
  String? get socketError => _socketError;

  void bindSocket(Stream<bool> stream) {
    _socketSub?.cancel();
    _socketSub = stream.listen((c) {
      if (c != _socketConnected) {
        _socketConnected = c;
        notifyListeners();
      }
    });
  }

  void bindSocketErrors(Stream<String> stream) {
    _socketErrorSub?.cancel();
    _socketErrorSub = stream.listen((e) {
      if (e != _socketError) {
        _socketError = e;
        notifyListeners();
      }
    });
  }

  Future<void> checkConnection() async {
    _checking = true;
    notifyListeners();
    _connected = await _api.checkConnection();
    _checking = false;
    notifyListeners();
  }

  void setConnected(bool v) {
    _connected = v;
    notifyListeners();
  }

  void startMonitoring({Duration interval = const Duration(seconds: 15)}) {
    _monitorTimer?.cancel();
    _monitorTimer = Timer.periodic(interval, (_) => _poll());
  }

  void stopMonitoring() {
    _monitorTimer?.cancel();
    _monitorTimer = null;
  }

  Future<void> _poll() async {
    final ok = await _api.checkConnection();
    if (ok != _connected) {
      _connected = ok;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    stopMonitoring();
    _socketSub?.cancel();
    _socketErrorSub?.cancel();
    super.dispose();
  }
}
