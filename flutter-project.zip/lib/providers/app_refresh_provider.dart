import 'package:flutter/foundation.dart';

class AppRefreshProvider extends ChangeNotifier {
  int _revision = 0;
  int get revision => _revision;

  void bump() {
    _revision++;
    notifyListeners();
  }
}
