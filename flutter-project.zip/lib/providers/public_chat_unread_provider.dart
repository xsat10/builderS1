import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class PublicChatUnreadProvider extends ChangeNotifier {
  static const _lastReadKey = 'public_chat_last_read_at';

  int _count = 0;
  bool _loading = false;

  int get count => _count;
  bool get hasUnread => _count > 0;
  bool get loading => _loading;

  Future<void> refresh() async {
    if (_loading || ApiService().baseUrl.isEmpty) return;
    _loading = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastReadRaw = prefs.getString(_lastReadKey);
      final lastRead = lastReadRaw == null ? null : DateTime.tryParse(lastReadRaw);
      final result = await ApiService().getPublicChatMessages(limit: 60);
      final messages = result['success'] == true && result['data'] is List
          ? (result['data'] as List).whereType<Map>().toList()
          : const <Map>[];
      _count = messages.where((message) {
        final created = DateTime.tryParse(message['created_at']?.toString() ?? '');
        return created != null && (lastRead == null || created.isAfter(lastRead));
      }).length;
      notifyListeners();
    } catch (_) {
      // Keep the existing badge when the server is temporarily unavailable.
    } finally {
      _loading = false;
    }
  }

  Future<void> markRead() async {
    final now = DateTime.now().toUtc();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastReadKey, now.toIso8601String());
    if (_count != 0) {
      _count = 0;
      notifyListeners();
    }
  }
}
