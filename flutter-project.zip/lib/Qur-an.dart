import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DetailScreen extends StatefulWidget {
  final int surahId;
  final String surahName;
  DetailScreen({required this.surahId, required this.surahName});

  @override
  _DetailScreenState createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  List<dynamic> ayahs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchAyahs();
  }

  Future<void> fetchAyahs() async {
    try {
      final response = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah/${widget.surahId}'));
      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        setState(() {
          ayahs = data['data']['ayahs'];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5), // Abu-abu cerah
      appBar: AppBar(
        title: Text(
          '${widget.surahName}',
          style: TextStyle(
            color: Colors.grey[800],
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFFE0E0E0), // Abu-abu cerah
        elevation: 1,
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.grey[800]),
        foregroundColor: Colors.grey[800],
      ),
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(
                color: Colors.grey[600],
              ),
            )
          : ayahs.isEmpty
              ? Center(
                  child: Text(
                    'Tidak ada ayat',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 16,
                    ),
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.all(12),
                  itemCount: ayahs.length,
                  itemBuilder: (context, index) {
                    return Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            blurRadius: 4,
                            offset: Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            ayahs[index]['text'],
                            style: TextStyle(
                              fontSize: 24,
                              fontFamily: 'serif',
                              color: Colors.grey[900],
                              height: 1.8,
                            ),
                            textAlign: TextAlign.right,
                          ),
                          SizedBox(height: 8),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'Ayat ${ayahs[index]['numberInSurah']}',
                              style: TextStyle(
                                color: Colors.grey[700],
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}