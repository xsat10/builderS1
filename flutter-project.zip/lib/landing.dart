// landing.dart - VOR4X SYSTEM LANDING (HUD EDITION)
// Modern cyber-HUD layout with video banner at top
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';

const String baseUrl = 'https://paultzy.pteroqhost.web.id5015';

// ═══════════════════════════════════════════════════════════
// COLOR TOKENS
// ═══════════════════════════════════════════════════════════
class _C {
  static const bg          = Color(0xFF02040A);
  static const bg2         = Color(0xFF050B18);
  static const panel       = Color(0xB3070E1C);
  static const panelSolid  = Color(0xFF070E1C);
  static const panelHi     = Color(0xFF0C1629);

  static const cyan        = Color(0xFF00E5FF);
  static const cyanDim     = Color(0xFF0091EA);
  static const blue        = Color(0xFF2979FF);
  static const purple      = Color(0xFF7C4DFF);
  static const pink        = Color(0xFFFF3D9A);
  static const green       = Color(0xFF00E676);
  static const yellow      = Color(0xFFFFB300);
  static const red         = Color(0xFFFF1744);

  static const txt         = Color(0xFFEAF4FF);
  static const txt2        = Color(0xFF8FA8C7);
  static const txt3        = Color(0xFF4E6584);
  static const txt4        = Color(0xFF2A3B55);

  static const border      = Color(0x2E00E5FF);
  static const borderSoft  = Color(0x1400E5FF);
  static const borderHi    = Color(0x8000E5FF);
}

// ═══════════════════════════════════════════════════════════
// LANDING PAGE
// ═══════════════════════════════════════════════════════════
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late VideoPlayerController _videoCtrl;

  // Animation controllers
  late AnimationController _appFadeCtrl;
  late AnimationController _staggerCtrl;
  late AnimationController _blinkCtrl;
  late AnimationController _spinCtrl;
  late AnimationController _ringSpinCtrl;
  late AnimationController _auroraCtrl;
  late AnimationController _shineCtrl;
  late AnimationController _borderSpinCtrl;
  late AnimationController _loaderSpinCtrl;

  late Animation<double> _appFade;
  late Animation<double> _blink;
  late Animation<double> _aurora;
  late Animation<double> _shine;

  // Live stats
  int _sUsers = 0;
  int _sBugs = 0;
  int _sUptime = 0;
  int _sPing = 24;
  String _clock = '--:--';

  Timer? _clockTimer;
  Timer? _pingTimer;

  @override
  void initState() {
    super.initState();

    // ─── VIDEO ────────────────────────────────────────
    _videoCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0);
        _videoCtrl.play();
      }).catchError((e) {
        debugPrint('Video error: $e');
      });

    // ─── CONTROLLERS ──────────────────────────────────
    _appFadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _appFade = CurvedAnimation(parent: _appFadeCtrl, curve: Curves.easeOutCubic);

    _staggerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _blinkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _blink = Tween<double>(begin: 1.0, end: 0.35).animate(
      CurvedAnimation(parent: _blinkCtrl, curve: Curves.easeInOut),
    );

    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _ringSpinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3, milliseconds: 500),
    )..repeat();

    _auroraCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat(reverse: true);
    _aurora = Tween<double>(begin: -1.0, end: 1.0).animate(
      CurvedAnimation(parent: _auroraCtrl, curve: Curves.easeInOut),
    );

    _shineCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    _shine = Tween<double>(begin: -1.0, end: 2.0).animate(
      CurvedAnimation(parent: _shineCtrl, curve: Curves.easeInOut),
    );

    _borderSpinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();

    _loaderSpinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    )..repeat();

    // ─── CLOCK & PING ─────────────────────────────────
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) => _updateClock());
    _pingTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      final ms = 18 + math.Random().nextInt(20);
      setState(() => _sPing = ms);
    });

    // ─── BOOT ─────────────────────────────────────────
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _appFadeCtrl.forward();
      _staggerCtrl.forward();
      Future.delayed(const Duration(milliseconds: 800), _animateStats);
    });
  }

  void _updateClock() {
    if (!mounted) return;
    final now = DateTime.now();
    setState(() {
      _clock = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    });
  }

  void _animateStats() {
    const steps = 40;
    const dur = Duration(milliseconds: 1400);
    final stepDur = Duration(microseconds: dur.inMicroseconds ~/ steps);
    for (int i = 1; i <= steps; i++) {
      final t = i / steps;
      final e = Curves.easeOutCubic.transform(t);
      Future.delayed(stepDur * i, () {
        if (!mounted) return;
        setState(() {
          _sUsers = (12480 * e).round();
          _sBugs = (382 * e).round();
          _sUptime = (99 * e).round();
        });
      });
    }
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _pingTimer?.cancel();
    _videoCtrl.dispose();
    _appFadeCtrl.dispose();
    _staggerCtrl.dispose();
    _blinkCtrl.dispose();
    _spinCtrl.dispose();
    _ringSpinCtrl.dispose();
    _auroraCtrl.dispose();
    _shineCtrl.dispose();
    _borderSpinCtrl.dispose();
    _loaderSpinCtrl.dispose();
    super.dispose();
  }

  // ─── OPEN URL ─────────────────────────────────────────
  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $url');
    }
  }

  // ─── STAGGER HELPER ───────────────────────────────────
  Widget _stag(double begin, double end, Widget child) {
    final a = CurvedAnimation(
      parent: _staggerCtrl,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: a,
      builder: (_, __) => Opacity(
        opacity: a.value,
        child: Transform.translate(
          offset: Offset(0, (1 - a.value) * 18),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF02040A),
              Color(0xFF050B18),
              Color(0xFF02040A),
            ],
            stops: [0.0, 0.55, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Grid overlay
            Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(painter: _GridPainter()),
              ),
            ),

            // Radial glows
            Positioned.fill(
              child: IgnorePointer(
                child: Stack(
                  children: [
                    Positioned(
                      top: -120, left: -120,
                      child: _glowBlob(320, _C.cyan, 0.14),
                    ),
                    Positioned(
                      bottom: -140, right: -140,
                      child: _glowBlob(340, _C.purple, 0.12),
                    ),
                    Positioned(
                      bottom: 200, left: -100,
                      child: _glowBlob(280, _C.pink, 0.08),
                    ),
                  ],
                ),
              ),
            ),

            // Content
            SafeArea(
              child: FadeTransition(
                opacity: _appFade,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // ═══ STATUS BAR ═══
                      _stag(0.0, 0.18, _buildStatusBar()),
                      const SizedBox(height: 12),

                      // ═══ VIDEO BANNER (POSISI TETAP DI ATAS) ═══
                      _stag(0.08, 0.30, _buildVideoHud()),
                      const SizedBox(height: 14),

                      // ═══ HERO TITLE ═══
                      _stag(0.15, 0.40, _buildHero()),
                      const SizedBox(height: 14),

                      // ═══ IDENTITY PANEL ═══
                      _stag(0.25, 0.55, _buildIdentity()),
                      const SizedBox(height: 12),

                      // ═══ COMMAND MODULES ═══
                      _stag(0.35, 0.65, _buildModules()),
                      const SizedBox(height: 14),

                      // ═══ ACTIONS ═══
                      _stag(0.45, 0.80, _buildActions()),
                      const SizedBox(height: 12),

                      // ═══ SOCIAL DOCK ═══
                      _stag(0.55, 0.90, _buildDock()),
                      const SizedBox(height: 12),

                      // ═══ FOOTER ═══
                      _stag(0.65, 1.0, _buildFooter()),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glowBlob(double size, Color color, double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(opacity), Colors.transparent],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // STATUS BAR
  // ═══════════════════════════════════════════════════════
  Widget _buildStatusBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _C.cyan.withOpacity(0.06),
            _C.cyan.withOpacity(0.01),
          ],
        ),
        border: Border.all(color: _C.borderSoft),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          // Left group
          AnimatedBuilder(
            animation: _blink,
            builder: (_, __) => Container(
              width: 6, height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.green.withOpacity(_blink.value),
                boxShadow: [
                  BoxShadow(color: _C.green, blurRadius: 8, spreadRadius: 1),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            'VOR4X.SYS',
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
              color: _C.txt,
            ),
          ),
          const SizedBox(width: 10),
          const Icon(Icons.circle, size: 5, color: _C.cyan),
          const SizedBox(width: 5),
          Text(
            '${_sPing}ms',
            style: const TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9.5,
              letterSpacing: 0.8,
              color: _C.txt2,
            ),
          ),
          const Spacer(),
          const Icon(Icons.signal_cellular_alt, size: 11, color: _C.cyan),
          const SizedBox(width: 4),
          const Text(
            '5G',
            style: TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.8,
              color: _C.txt2,
            ),
          ),
          const SizedBox(width: 10),
          const Icon(Icons.shield_rounded, size: 11, color: _C.cyan),
          const SizedBox(width: 4),
          const Text(
            'SECURE',
            style: TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.8,
              color: _C.txt2,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            _clock,
            style: const TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.8,
              color: _C.txt2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // VIDEO HUD
  // ═══════════════════════════════════════════════════════
  Widget _buildVideoHud() {
    return _HudFrame(
      label: 'SYSTEM PREVIEW',
      labelRight: 'REC • 01',
      child: AspectRatio(
        aspectRatio: 16 / 10,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Video
              Container(
                color: Colors.black,
                child: _videoCtrl.value.isInitialized
                    ? FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoCtrl.value.size.width,
                          height: _videoCtrl.value.size.height,
                          child: VideoPlayer(_videoCtrl),
                        ),
                      )
                    : _buildVideoLoader(),
              ),

              // Gradient overlay
              IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.35),
                        Colors.transparent,
                        Colors.transparent,
                        _C.bg.withOpacity(0.92),
                      ],
                      stops: const [0.0, 0.30, 0.55, 1.0],
                    ),
                  ),
                ),
              ),

              // HUD corners
              Positioned(top: 10, left: 10, child: _corner(topLeft: true)),
              Positioned(top: 10, right: 10, child: _corner(topRight: true)),
              Positioned(bottom: 10, left: 10, child: _corner(bottomLeft: true)),
              Positioned(bottom: 10, right: 10, child: _corner(bottomRight: true)),

              // Top row
              Positioned(
                top: 14, left: 14, right: 14,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.bg.withOpacity(0.75),
                        border: Border.all(color: _C.cyan.withOpacity(0.5)),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AnimatedBuilder(
                            animation: _blink,
                            builder: (_, __) => Container(
                              width: 5, height: 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _C.red.withOpacity(_blink.value),
                                boxShadow: [
                                  BoxShadow(color: _C.red, blurRadius: 6),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 5),
                          const Text(
                            'LIVE',
                            style: TextStyle(
                              fontFamily: 'JetBrains Mono',
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.4,
                              color: _C.cyan,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildVideoTimer(),
                  ],
                ),
              ),

              // Bottom row
              Positioned(
                left: 16, right: 16, bottom: 14,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'VOR4X PREVIEW',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'SYSTEM ONLINE • v2.0.0',
                            style: TextStyle(
                              fontFamily: 'JetBrains Mono',
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.2,
                              color: _C.cyan,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildVideoPlayBtn(),
                  ],
                ),
              ),

              // Tap overlay
              if (_videoCtrl.value.isInitialized)
                Positioned.fill(
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        if (_videoCtrl.value.isPlaying) {
                          _videoCtrl.pause();
                        } else {
                          _videoCtrl.play();
                        }
                        setState(() {});
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoLoader() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF050B18), Color(0xFF02040A)],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 42, height: 42,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  RotationTransition(
                    turns: _loaderSpinCtrl,
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: CustomPaint(
                        painter: _ArcPainter(color: _C.cyan),
                      ),
                    ),
                  ),
                  RotationTransition(
                    turns: ReverseAnimation(_loaderSpinCtrl),
                    child: SizedBox(
                      width: 28, height: 28,
                      child: CustomPaint(
                        painter: _ArcPainter(color: _C.purple, startAngle: math.pi),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'INITIALIZING FEED…',
              style: TextStyle(
                fontFamily: 'JetBrains Mono',
                fontSize: 9.5,
                letterSpacing: 1.8,
                color: _C.txt3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoTimer() {
    return AnimatedBuilder(
      animation: _videoCtrl,
      builder: (_, __) {
        final pos = _videoCtrl.value.position;
        final dur = _videoCtrl.value.duration;
        String fmt(Duration d) {
          final m = d.inMinutes.toString().padLeft(2, '0');
          final s = (d.inSeconds % 60).toString().padLeft(2, '0');
          return '$m:$s';
        }
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _C.bg.withOpacity(0.7),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            '${fmt(pos)} / ${fmt(dur)}',
            style: const TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
              color: Color(0xBFFFFFFF),
            ),
          ),
        );
      },
    );
  }

  Widget _buildVideoPlayBtn() {
    return GestureDetector(
      onTap: () {
        if (!_videoCtrl.value.isInitialized) return;
        setState(() {
          _videoCtrl.value.isPlaying
              ? _videoCtrl.pause()
              : _videoCtrl.play();
        });
      },
      child: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _C.bg.withOpacity(0.75),
          border: Border.all(color: _C.cyan, width: 1.4),
          boxShadow: [
            BoxShadow(color: _C.cyan.withOpacity(0.45), blurRadius: 18),
          ],
        ),
        child: Icon(
          _videoCtrl.value.isPlaying
              ? Icons.pause_rounded
              : Icons.play_arrow_rounded,
          color: _C.cyan,
          size: 20,
        ),
      ),
    );
  }

  Widget _corner({
    bool topLeft = false,
    bool topRight = false,
    bool bottomLeft = false,
    bool bottomRight = false,
  }) {
    return Container(
      width: 18, height: 18,
      decoration: BoxDecoration(
        border: Border(
          top: (topLeft || topRight)
              ? const BorderSide(color: _C.cyan, width: 2)
              : BorderSide.none,
          bottom: (bottomLeft || bottomRight)
              ? const BorderSide(color: _C.cyan, width: 2)
              : BorderSide.none,
          left: (topLeft || bottomLeft)
              ? const BorderSide(color: _C.cyan, width: 2)
              : BorderSide.none,
          right: (topRight || bottomRight)
              ? const BorderSide(color: _C.cyan, width: 2)
              : BorderSide.none,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // HERO TITLE
  // ═══════════════════════════════════════════════════════
  Widget _buildHero() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [Colors.white, _C.cyan, _C.purple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
          child: const Text(
            'VOR4X',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 40,
              fontWeight: FontWeight.w900,
              letterSpacing: 6,
              height: 1,
              color: Colors.white,
              shadows: [
                Shadow(blurRadius: 24, color: Color(0x8000E5FF)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _metaChip(
              icon: Icons.circle,
              label: 'STABLE BUILD',
              color: _C.green,
            ),
            const SizedBox(width: 6),
            _metaChip(
              icon: Icons.code,
              label: 'v2.0.0',
              color: _C.cyan,
            ),
            const SizedBox(width: 6),
            _metaChip(
              icon: Icons.bolt_rounded,
              label: 'FAST',
              color: _C.cyan,
            ),
          ],
        ),
      ],
    );
  }

  Widget _metaChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        border: Border.all(color: color.withOpacity(0.3)),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 8, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontFamily: 'JetBrains Mono',
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
              color: color == _C.green ? _C.green : _C.txt2,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // IDENTITY PANEL
  // ═══════════════════════════════════════════════════════
  Widget _buildIdentity() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.cyan.withOpacity(0.28)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 40, offset: const Offset(0, 16)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            // Aurora background
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _aurora,
                builder: (_, __) => Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(-1 + _aurora.value * 0.3, -1),
                      end: Alignment(1 + _aurora.value * 0.3, 1),
                      colors: [
                        _C.pink.withOpacity(0.14),
                        _C.blue.withOpacity(0.14),
                        _C.cyan.withOpacity(0.10),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Radial glow
            Positioned.fill(
              child: IgnorePointer(
                child: Stack(
                  children: [
                    Positioned(
                      top: -30, left: -30,
                      child: _glowBlob(180, _C.pink, 0.35),
                    ),
                    Positioned(
                      bottom: -30, right: -30,
                      child: _glowBlob(180, _C.blue, 0.40),
                    ),
                  ],
                ),
              ),
            ),
            // Content
            Padding(
              padding: const EdgeInsets.all(4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Top row
                  Row(
                    children: [
                      Container(
                        width: 4, height: 4,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _C.cyan,
                          boxShadow: [BoxShadow(color: _C.cyan, blurRadius: 6)],
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        'VOR4X_CORE',
                        style: TextStyle(
                          fontFamily: 'JetBrains Mono',
                          fontSize: 9.5,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.8,
                          color: _C.cyan,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _C.red.withOpacity(0.2),
                          border: Border.all(color: _C.red.withOpacity(0.5)),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AnimatedBuilder(
                              animation: _blink,
                              builder: (_, __) => Container(
                                width: 5, height: 5,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _C.red.withOpacity(_blink.value),
                                  boxShadow: [BoxShadow(color: _C.red, blurRadius: 4)],
                                ),
                              ),
                            ),
                            const SizedBox(width: 5),
                            const Text(
                              'LIVE',
                              style: TextStyle(
                                fontFamily: 'JetBrains Mono',
                                fontSize: 8.5,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.4,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Avatar
                  Center(child: _buildAvatarRing()),
                  const SizedBox(height: 10),
                  const Center(
                    child: Text(
                      'NO PHOTO DETECTED — SYSTEM LOGO',
                      style: TextStyle(
                        fontFamily: 'JetBrains Mono',
                        fontSize: 9,
                        letterSpacing: 1.6,
                        color: Color(0x8CFFFFFF),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Name
                  const Center(
                    child: Text(
                      'VOR4X BUG',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 3,
                        color: Colors.white,
                        shadows: [
                          Shadow(blurRadius: 20, color: Color(0x80000000)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Stats
                  _buildStatsGrid(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatarRing() {
    return SizedBox(
      width: 110, height: 110,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Rotating outer arc
          RotationTransition(
            turns: _ringSpinCtrl,
            child: SizedBox(
              width: 110, height: 110,
              child: CustomPaint(
                painter: _ArcPainter(color: _C.cyan, strokeWidth: 1.8, sweep: 0.8),
              ),
            ),
          ),
          // Dashed ring reverse
          RotationTransition(
            turns: ReverseAnimation(_ringSpinCtrl),
            child: SizedBox(
              width: 96, height: 96,
              child: CustomPaint(
                painter: _DashedCirclePainter(color: _C.purple.withOpacity(0.5)),
              ),
            ),
          ),
          // Inner orb with glow
          Container(
            width: 76, height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _C.cyan.withOpacity(0.35),
                  _C.blue.withOpacity(0.15),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.6, 1.0],
              ),
              border: Border.all(color: _C.cyan.withOpacity(0.6), width: 1.4),
              boxShadow: [
                BoxShadow(color: _C.cyan.withOpacity(0.35), blurRadius: 30),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/login.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  alignment: Alignment.center,
                  child: const Text(
                    'V',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      color: _C.cyan,
                      shadows: [
                        Shadow(blurRadius: 20, color: Color(0xCC00E5FF)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsGrid() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        color: _C.bg.withOpacity(0.4),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(child: _statItem('Users', '${(_sUsers / 1000).toStringAsFixed(1)}K')),
          _statDivider(),
          Expanded(child: _statItem('Bugs', '$_sBugs')),
          _statDivider(),
          Expanded(child: _statItem('Uptime', '$_sUptime%')),
          _statDivider(),
          Expanded(child: _statItem('Ping', '${_sPing}ms')),
        ],
      ),
    );
  }

  Widget _statDivider() {
    return Container(
      width: 1,
      height: 28,
      color: Colors.white.withOpacity(0.08),
    );
  }

  Widget _statItem(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label.toUpperCase(),
          style: const TextStyle(
            fontFamily: 'JetBrains Mono',
            fontSize: 7.5,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
            color: Color(0x80FFFFFF),
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
            color: _C.cyan,
            shadows: [Shadow(blurRadius: 10, color: Color(0x8000E5FF))],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════
  // COMMAND MODULES
  // ═══════════════════════════════════════════════════════
  Widget _buildModules() {
    return _HudFrame(
      label: 'COMMAND MODULES',
      labelRight: '04',
      child: Row(
        children: [
          Expanded(child: _moduleCard(icon: FontAwesomeIcons.bug,       label: 'BUGS',   color: _C.cyan)),
          const SizedBox(width: 8),
          Expanded(child: _moduleCard(icon: FontAwesomeIcons.shieldHalved, label: 'SECURE', color: _C.green)),
          const SizedBox(width: 8),
          Expanded(child: _moduleCard(icon: FontAwesomeIcons.users,     label: 'GROUP',  color: _C.yellow)),
          const SizedBox(width: 8),
          Expanded(child: _moduleCard(icon: FontAwesomeIcons.layerGroup, label: 'LAYERS', color: _C.purple)),
        ],
      ),
    );
  }

  Widget _moduleCard({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          color: _C.panelSolid.withOpacity(0.85),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Stack(
          children: [
            // Top accent line
            Positioned(
              top: 0, left: 12, right: 12,
              child: Container(
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, color, Colors.transparent],
                  ),
                ),
              ),
            ),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: color.withOpacity(0.15),
                      border: Border.all(color: color.withOpacity(0.45)),
                      boxShadow: [
                        BoxShadow(color: color.withOpacity(0.3), blurRadius: 16),
                      ],
                    ),
                    child: Center(
                      child: FaIcon(icon, color: color, size: 15),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    label,
                    style: const TextStyle(
                      fontFamily: 'JetBrains Mono',
                      fontSize: 7.5,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                      color: _C.txt2,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════
  Widget _buildActions() {
    return Column(
      children: [
        _primaryBtn(
          icon: Icons.rocket_launch_rounded,
          label: 'LOGIN TO VOR4X',
          onTap: () => Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const LoginPage()),
          ),
        ),
        const SizedBox(height: 10),
        _secondaryBtn(
          icon: Icons.bolt_rounded,
          label: 'BELI AKSES PREMIUM',
          onTap: _showBuyAksesSheet,
        ),
        const SizedBox(height: 10),
        _tertiaryBtn(
          icon: Icons.support_agent_rounded,
          label: 'HUBUNGI SUPPORT',
          onTap: () => _openUrl('https://t.me/r4pzzxi'),
        ),
      ],
    );
  }

  Widget _primaryBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF00E5FF), Color(0xFF0091EA), Color(0xFF1E88E5)],
          ),
          boxShadow: [
            BoxShadow(color: _C.cyan.withOpacity(0.4), blurRadius: 28, offset: const Offset(0, 10)),
            BoxShadow(color: _C.cyan.withOpacity(0.18), blurRadius: 50),
          ],
        ),
        child: Stack(
          children: [
            // Shine sweep
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: AnimatedBuilder(
                  animation: _shine,
                  builder: (_, __) => Transform.translate(
                    offset: Offset(_shine.value * 200, 0),
                    child: Container(
                      width: 80,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            Colors.white.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // Content
            Center(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: _C.bg, size: 18),
                  const SizedBox(width: 10),
                  Text(
                    label,
                    style: const TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.8,
                      color: _C.bg,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _secondaryBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            colors: [
              _C.pink.withOpacity(0.16),
              _C.blue.withOpacity(0.16),
            ],
          ),
          border: Border.all(color: _C.pink.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 22, offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.8,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tertiaryBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          color: _C.panelSolid.withOpacity(0.7),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _C.txt2, size: 18),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 13,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.8,
                color: _C.txt2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // SOCIAL DOCK
  // ═══════════════════════════════════════════════════════
  Widget _buildDock() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: _C.panelSolid.withOpacity(0.7),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 30, offset: const Offset(0, 10)),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _dockBtn(
              icon: FontAwesomeIcons.telegram,
              iconColor: const Color(0xFF29A9EB),
              label: 'Telegram',
              onTap: () => _openUrl('https://t.me/r4pzzxi'),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _dockBtn(
              icon: FontAwesomeIcons.tiktok,
              iconColor: const Color(0xFFEE1D52),
              label: 'TikTok',
              onTap: () => _openUrl('https://www.tiktok.com/@⏤͟͟͞͞ 𝐑𝐀𝐏𝐙𝟒𝐘𝐎𝐔 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋|?_r=1&_t=ZS-99efUvG9vAi'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dockBtn({
    required IconData icon,
    required Color iconColor,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: iconColor, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontFamily: 'Rajdhani',
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: _C.txt2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // FOOTER
  // ═══════════════════════════════════════════════════════
  Widget _buildFooter() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: Text(
          '© 2026 VOR4X  •  2.0.0',
          style: TextStyle(
            fontFamily: 'JetBrains Mono',
            fontSize: 9,
            letterSpacing: 1,
            color: _C.txt4,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // SHEET
  // ═══════════════════════════════════════════════════════
  void _showBuyAksesSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _BuyAksesSheet(
        onBuy: (url) async {
          Navigator.pop(context);
          await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HUD FRAME WRAPPER
// ═══════════════════════════════════════════════════════════
class _HudFrame extends StatelessWidget {
  final String label;
  final String? labelRight;
  final Widget child;

  const _HudFrame({
    required this.label,
    required this.child,
    this.labelRight,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.panel,
        border: Border.all(color: _C.border),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 40, offset: const Offset(0, 12)),
        ],
      ),
      child: Stack(
        children: [
          // Corner brackets
          Positioned(top: -1, left: -1, child: _cornerHud(topLeft: true)),
          Positioned(bottom: -1, right: -1, child: _cornerHud(bottomRight: true)),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Label
              Row(
                children: [
                  Container(
                    width: 4, height: 10,
                    decoration: BoxDecoration(
                      color: _C.cyan,
                      borderRadius: BorderRadius.circular(1),
                      boxShadow: [BoxShadow(color: _C.cyan, blurRadius: 8)],
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: const TextStyle(
                      fontFamily: 'JetBrains Mono',
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5,
                      color: _C.txt3,
                    ),
                  ),
                  if (labelRight != null) ...[
                    const Spacer(),
                    Text(
                      labelRight!,
                      style: const TextStyle(
                        fontFamily: 'JetBrains Mono',
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.5,
                        color: _C.cyan,
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ],
      ),
    );
  }

  Widget _cornerHud({bool topLeft = false, bool bottomRight = false}) {
    return Container(
      width: 14, height: 14,
      decoration: BoxDecoration(
        border: Border(
          top: topLeft ? const BorderSide(color: _C.cyan, width: 1.5) : BorderSide.none,
          left: topLeft ? const BorderSide(color: _C.cyan, width: 1.5) : BorderSide.none,
          bottom: bottomRight ? const BorderSide(color: _C.cyan, width: 1.5) : BorderSide.none,
          right: bottomRight ? const BorderSide(color: _C.cyan, width: 1.5) : BorderSide.none,
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// ARC PAINTER
// ═══════════════════════════════════════════════════════════
class _ArcPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final double sweep;
  final double startAngle;

  _ArcPainter({
    required this.color,
    this.strokeWidth = 2,
    this.sweep = 0.8,
    this.startAngle = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..color = color
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

    final rect = Rect.fromLTWH(0, 0, size.width, size.height);
    canvas.drawArc(rect, startAngle, math.pi * 2 * sweep, false, paint);
  }

  @override
  bool shouldRepaint(covariant _ArcPainter old) =>
      old.color != color || old.sweep != sweep;
}

// ═══════════════════════════════════════════════════════════
// DASHED CIRCLE PAINTER
// ═══════════════════════════════════════════════════════════
class _DashedCirclePainter extends CustomPainter {
  final Color color;
  _DashedCirclePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    const dashCount = 40;

    for (int i = 0; i < dashCount; i++) {
      final start = (i / dashCount) * math.pi * 2;
      final end = start + (math.pi * 2 / dashCount) * 0.5;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        start, end - start, false, paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DashedCirclePainter old) => old.color != color;
}

// ═══════════════════════════════════════════════════════════
// GRID PAINTER
// ═══════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _C.cyan.withOpacity(0.028)
      ..strokeWidth = 1;

    const gap = 44.0;
    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════
// BUY AKSES SHEET
// ═══════════════════════════════════════════════════════════
class _BuyAksesSheet extends StatefulWidget {
  final Future<void> Function(String url) onBuy;
  const _BuyAksesSheet({required this.onBuy});

  @override
  State<_BuyAksesSheet> createState() => _BuyAksesSheetState();
}

class _BuyAksesSheetState extends State<_BuyAksesSheet> {
  int _selectedPackage = 0;
  String _selectedRole = 'member';

  final Map<String, Map<String, dynamic>> _packages = {
    'member': {
      'label': 'MEMBER',
      'desc': 'Akses dasar member',
      'color': const Color(0xFF6B7280),
      'level': 1,
      'icon': FontAwesomeIcons.user,
      'plans': [
        {'name': 'Trial Sehari',  'price': 'Rp 2.000',  'icon': Icons.access_time_rounded},
        {'name': 'Trial Sebulan', 'price': 'Rp 15.000', 'icon': Icons.calendar_month_rounded},
        {'name': 'Permanen',      'price': 'Rp 20.000', 'icon': Icons.all_inclusive_rounded},
      ],
    },
    'reseller': {
      'label': 'RESELLER',
      'desc': 'Bisa create akun Member',
      'color': const Color(0xFF22C55E),
      'level': 2,
      'icon': FontAwesomeIcons.store,
      'plans': [{'name': 'Permanen', 'price': 'Rp 25.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'admin': {
      'label': 'ADMIN',
      'desc': 'Bisa create sampai Reseller',
      'color': const Color(0xFFF59E0B),
      'level': 3,
      'icon': FontAwesomeIcons.userShield,
      'plans': [{'name': 'Permanen', 'price': 'Rp 30.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'partner': {
      'label': 'PARTNER',
      'desc': 'Bisa create sampai Admin',
      'color': const Color(0xFF8B5CF6),
      'level': 4,
      'icon': FontAwesomeIcons.handshake,
      'plans': [{'name': 'Permanen', 'price': 'Rp 35.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'owner': {
      'label': 'OWNER',
      'desc': 'Bisa create sampai Partner',
      'color': const Color(0xFFE50914),
      'level': 5,
      'icon': FontAwesomeIcons.crown,
      'plans': [{'name': 'Permanen', 'price': 'Rp 40.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'moderator': {
      'label': 'MODERATOR',
      'desc': 'Bisa create sampai Owner',
      'color': const Color(0xFF06B6D4),
      'level': 6,
      'icon': FontAwesomeIcons.gavel,
      'plans': [{'name': 'Permanen', 'price': 'Rp 45.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'high_owner': {
      'label': 'HIGH OWNER',
      'desc': 'Bisa create sampai Moderator',
      'color': const Color(0xFFFF6600),
      'level': 7,
      'icon': FontAwesomeIcons.fire,
      'plans': [{'name': 'Permanen', 'price': 'Rp 50.000', 'icon': Icons.all_inclusive_rounded}],
    },
    'tk': {
      'label': 'TK',
      'desc': 'Bisa create sampai High Owner',
      'color': const Color(0xFFEC4899),
      'level': 8,
      'icon': FontAwesomeIcons.gem,
      'plans': [{'name': 'Permanen', 'price': 'Rp 55.000', 'icon': Icons.all_inclusive_rounded}],
    },
  };

  List<String> get _roleOrder => [
    'member', 'reseller', 'admin', 'partner',
    'owner', 'moderator', 'high_owner', 'tk',
  ];

  @override
  Widget build(BuildContext context) {
    final pkg = _packages[_selectedRole]!;
    final plans = pkg['plans'] as List;
    final color = pkg['color'] as Color;
    final level = pkg['level'] as int;
    final totalLevel = _roleOrder.length;
    final icon = pkg['icon'] as IconData;

    return Container(
      height: MediaQuery.of(context).size.height * 0.88,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF071129), Color(0xFF02040A)],
        ),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: _C.borderHi, width: 1)),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 44, height: 4,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_C.cyan, _C.purple]),
              borderRadius: BorderRadius.circular(2),
              boxShadow: [BoxShadow(color: _C.cyan, blurRadius: 12)],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
            child: Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color),
                    boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 18)],
                  ),
                  child: Center(child: FaIcon(icon, color: color, size: 18)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'BELI AKSES',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                        ),
                      ),
                      Text(
                        'LEVEL $level DARI $totalLevel',
                        style: const TextStyle(
                          fontFamily: 'JetBrains Mono',
                          color: _C.txt3,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: color.withOpacity(0.5)),
                  ),
                  child: Text(
                    'Lv.$level',
                    style: TextStyle(
                      fontFamily: 'JetBrains Mono',
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Role tabs
          SizedBox(
            height: 34,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _roleOrder.length,
              itemBuilder: (_, i) {
                final key = _roleOrder[i];
                final rp = _packages[key]!;
                final c = rp['color'] as Color;
                final lv = rp['level'] as int;
                final isSel = _selectedRole == key;
                return GestureDetector(
                  onTap: () => setState(() {
                    _selectedRole = key;
                    _selectedPackage = 0;
                  }),
                  child: Container(
                    margin: const EdgeInsets.only(right: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: isSel ? c.withOpacity(0.15) : _C.panelSolid.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: isSel ? c : _C.border),
                      boxShadow: isSel
                          ? [BoxShadow(color: c.withOpacity(0.5), blurRadius: 16)]
                          : null,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Lv.$lv',
                          style: TextStyle(
                            fontFamily: 'JetBrains Mono',
                            color: isSel ? c : _C.txt3,
                            fontSize: 8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          rp['label'] as String,
                          style: TextStyle(
                            fontFamily: 'JetBrains Mono',
                            color: isSel ? c : _C.txt2,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  // Role info
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withOpacity(0.15), color.withOpacity(0.03)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: color.withOpacity(0.4)),
                      boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 22)],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42, height: 42,
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: [BoxShadow(color: color.withOpacity(0.5), blurRadius: 16)],
                          ),
                          child: Center(child: FaIcon(icon, color: color, size: 18)),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                pkg['label'] as String,
                                style: TextStyle(
                                  fontFamily: 'Orbitron',
                                  color: color,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.5,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                pkg['desc'] as String,
                                style: const TextStyle(
                                  fontFamily: 'JetBrains Mono',
                                  color: _C.txt3,
                                  fontSize: 10,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (_selectedRole == 'member')
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _C.yellow.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: _C.yellow.withOpacity(0.5)),
                              boxShadow: [BoxShadow(color: _C.yellow.withOpacity(0.4), blurRadius: 12)],
                            ),
                            child: const Text(
                              'RECOMMENDED',
                              style: TextStyle(
                                fontFamily: 'JetBrains Mono',
                                color: _C.yellow,
                                fontSize: 8.5,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Plans
                  ...plans.asMap().entries.map((entry) {
                    final i = entry.key;
                    final plan = entry.value as Map;
                    final isSel = _selectedPackage == i;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedPackage = i),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: isSel
                              ? LinearGradient(colors: [
                                  color.withOpacity(0.15),
                                  color.withOpacity(0.03),
                                ])
                              : null,
                          color: isSel ? null : _C.panelSolid.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSel ? color : _C.border,
                            width: isSel ? 1.5 : 1,
                          ),
                          boxShadow: isSel
                              ? [BoxShadow(color: color.withOpacity(0.4), blurRadius: 18)]
                              : null,
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 24, height: 24,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                                color: isSel ? color.withOpacity(0.22) : Colors.transparent,
                                border: Border.all(
                                  color: isSel ? color : _C.border,
                                  width: 1.5,
                                ),
                                boxShadow: isSel
                                    ? [BoxShadow(color: color.withOpacity(0.5), blurRadius: 10)]
                                    : null,
                              ),
                              child: isSel
                                  ? Icon(Icons.check_rounded, color: color, size: 14)
                                  : null,
                            ),
                            const SizedBox(width: 12),
                            Icon(
                              plan['icon'] as IconData,
                              color: isSel ? color : _C.txt3,
                              size: 18,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                plan['name'] as String,
                                style: TextStyle(
                                  fontFamily: 'Rajdhani',
                                  color: isSel ? Colors.white : _C.txt2,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                            Text(
                              plan['price'] as String,
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                color: isSel ? color : _C.txt2,
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 12),
                  // Hierarchy
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _C.panelSolid.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.border),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'ROLE HIERARCHY',
                          style: TextStyle(
                            fontFamily: 'JetBrains Mono',
                            color: _C.txt3,
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: _roleOrder.map((key) {
                            final rp = _packages[key]!;
                            final c = rp['color'] as Color;
                            final lv = rp['level'] as int;
                            final on = lv <= level;
                            return Expanded(
                              child: Column(
                                children: [
                                  Container(
                                    width: 22, height: 22,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: on ? c : Colors.transparent,
                                      border: Border.all(
                                        color: on ? c : _C.txt4,
                                        width: 1.5,
                                      ),
                                      boxShadow: on
                                          ? [BoxShadow(color: c.withOpacity(0.6), blurRadius: 10)]
                                          : null,
                                    ),
                                    child: on
                                        ? const Icon(Icons.check, color: Colors.white, size: 12)
                                        : null,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '$lv',
                                    style: TextStyle(
                                      fontFamily: 'JetBrains Mono',
                                      fontSize: 8,
                                      fontWeight: FontWeight.w600,
                                      color: on ? c : _C.txt4,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(context).padding.bottom + 16),
            child: GestureDetector(
              onTap: () {
                final plan = plans[_selectedPackage];
                final msg = 'Halo, saya mau beli akses ${pkg['label']} - ${plan['name']} (${plan['price']})';
                widget.onBuy('https://t.me/r4pzzxi?text=${Uri.encodeComponent(msg)}');
              },
              child: Container(
                width: double.infinity,
                height: 54,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.65)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.25)),
                  boxShadow: [
                    BoxShadow(color: color.withOpacity(0.55), blurRadius: 24),
                    BoxShadow(color: color.withOpacity(0.35), blurRadius: 40),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.bolt_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 10),
                    Text(
                      'CONTACT & BUY AKSES',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.8,
                        shadows: [Shadow(blurRadius: 8, color: Colors.black45)],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}