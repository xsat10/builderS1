import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';

import 'splash.dart';
import 'login_page.dart';
import 'utils/update_checker.dart';
import 'buy_account.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ============================================================
  // COLORS
  // ============================================================

  final Color bgBlack = const Color(0xFF050505);
  final Color bgDark = const Color(0xFF0A0A0A);
  final Color greyDark = const Color(0xFF151515);
  final Color greyMedium = const Color(0xFF242424);
  final Color greyLight = const Color(0xFFB7B7B7);

  final Color glassBorder = Colors.white.withOpacity(0.12);
  final Color cardBg = Colors.white.withOpacity(0.055);

  // ============================================================
  // INTRO
  // ============================================================

  bool _showLanding = false;

  late AnimationController _introController;
  late AnimationController _pulseController;
  late AnimationController _waveController;

  late Animation<double> _introScale;
  late Animation<double> _introOpacity;
  late Animation<double> _pulseAnimation;

  // ============================================================
  // SLIDER
  // ============================================================

  final PageController _pageController = PageController();

  int _currentPage = 0;

  late AnimationController _indicatorController;
  late Animation<double> _indicatorAnimation;

  // ============================================================
  // AI TYPING
  // ============================================================

  Timer? _typingTimer;

  final List<String> _aiMessages = [
    "Hello, welcome to STUX.",
    "Need secure access?",
    "Choose your path carefully.",
    "Already have an account? Go secure.",
    "No account yet? You can get access below.",
  ];

  int _aiMessageIndex = 0;
  int _typingIndex = 0;
  String _displayedAiText = "";

  // ============================================================
  // INIT
  // ============================================================

  @override
  void initState() {
    super.initState();

    // INTRO ANIMATION
    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _introScale = Tween<double>(
      begin: 0.88,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _introController,
        curve: Curves.easeOutCubic,
      ),
    );

    _introOpacity = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _introController,
        curve: Curves.easeOut,
      ),
    );

    // BUBBLE PULSE
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(
      begin: 0.92,
      end: 1.08,
    ).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    // WAVE
    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 7000),
    )..repeat();

    // PAGE INDICATOR
    _indicatorController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _indicatorAnimation = Tween<double>(
      begin: 0.85,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _indicatorController,
        curve: Curves.easeInOut,
      ),
    );

    _introController.forward();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkForUpdate(context);
    });
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _pageController.dispose();

    _introController.dispose();
    _pulseController.dispose();
    _waveController.dispose();
    _indicatorController.dispose();

    _typingTimer?.cancel();

    super.dispose();
  }

  // ============================================================
  // OPEN URL
  // ============================================================

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);

    if (!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      throw Exception("Could not launch $uri");
    }
  }

  // ============================================================
  // ENTER LANDING
  // ============================================================

  void _enterLanding() {
    setState(() {
      _showLanding = true;
    });

    _startAiTyping();
  }

  // ============================================================
  // AI TYPING
  // ============================================================

  void _startAiTyping() {
    _typingTimer?.cancel();

    _typingIndex = 0;
    _displayedAiText = "";

    _typingTimer = Timer.periodic(
      const Duration(milliseconds: 42),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        final message = _aiMessages[_aiMessageIndex];

        if (_typingIndex < message.length) {
          setState(() {
            _displayedAiText += message[_typingIndex];
            _typingIndex++;
          });
        } else {
          timer.cancel();

          Future.delayed(
            const Duration(milliseconds: 1600),
            () {
              if (!mounted) return;

              _aiMessageIndex =
                  (_aiMessageIndex + 1) % _aiMessages.length;

              _startAiTyping();
            },
          );
        }
      },
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 700),
        switchInCurve: Curves.easeOutCubic,
        switchOutCurve: Curves.easeInCubic,
        child: _showLanding
            ? _buildLanding()
            : _buildIntro(),
      ),
    );
  }

  // ============================================================
  // INTRO SCREEN
  // ============================================================

  Widget _buildIntro() {
    return Stack(
      key: const ValueKey("intro"),
      children: [
        // BACKGROUND
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 1.1,
                colors: [
                  const Color(0xFF242424),
                  bgDark,
                  bgBlack,
                ],
              ),
            ),
          ),
        ),

        // MOVING WAVES
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _waveController,
              builder: (context, child) {
                return CustomPaint(
                  painter: _WavePainter(
                    progress: _waveController.value,
                  ),
                );
              },
            ),
          ),
        ),

        // FLOATING BUBBLES
        Positioned.fill(
          child: IgnorePointer(
            child: Stack(
              children: [
                _bubble(
                  left: 35,
                  top: 150,
                  size: 95,
                  opacity: 0.08,
                  durationOffset: 0,
                ),
                _bubble(
                  right: 25,
                  top: 230,
                  size: 65,
                  opacity: 0.06,
                  durationOffset: 250,
                ),
                _bubble(
                  left: 80,
                  bottom: 160,
                  size: 55,
                  opacity: 0.07,
                  durationOffset: 500,
                ),
                _bubble(
                  right: 80,
                  bottom: 100,
                  size: 110,
                  opacity: 0.045,
                  durationOffset: 750,
                ),
              ],
            ),
          ),
        ),

        // CONTENT
        SafeArea(
          child: Center(
            child: AnimatedBuilder(
              animation: Listenable.merge([
                _introController,
                _pulseController,
              ]),
              builder: (context, child) {
                return Opacity(
                  opacity: _introOpacity.value,
                  child: Transform.scale(
                    scale: _introScale.value,
                    child: child,
                  ),
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildIntroLogo(),

                  const SizedBox(height: 35),

                  const Text(
                    "WELCOME TO",
                    style: TextStyle(
                      color: Colors.white54,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 4,
                    ),
                  ),

                  const SizedBox(height: 8),

                  const Text(
                    "STUX",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 46,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 7,
                      fontFamily: "Orbitron",
                    ),
                  ),

                  const SizedBox(height: 10),

                  const Text(
                    "A smarter way to enter your workspace.",
                    style: TextStyle(
                      color: Colors.white38,
                      fontSize: 13,
                    ),
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(height: 45),

                  _buildEnterButton(),

                  const SizedBox(height: 18),

                  const Text(
                    "Tap to continue",
                    style: TextStyle(
                      color: Colors.white30,
                      fontSize: 11,
                      letterSpacing: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // VERSION
        Positioned(
          bottom: 22,
          left: 0,
          right: 0,
          child: Center(
            child: Text(
              "STUX • VERSION 18.0",
              style: TextStyle(
                color: Colors.white.withOpacity(0.20),
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // INTRO LOGO
  // ============================================================

  Widget _buildIntroLogo() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            width: 105,
            height: 105,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.035),
              border: Border.all(
                color: Colors.white.withOpacity(0.16),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.05),
                  blurRadius: 45,
                  spreadRadius: 8,
                ),
              ],
            ),
            child: Center(
              child: Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.07),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.10),
                  ),
                ),
                child: const Icon(
                  Icons.auto_awesome,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // ENTER BUTTON
  // ============================================================

  Widget _buildEnterButton() {
    return Container(
      width: 210,
      height: 58,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          colors: [
            Color(0xFF303030),
            Color(0xFF111111),
          ],
        ),
        border: Border.all(
          color: Colors.white.withOpacity(0.18),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.7),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: _enterLanding,
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "ENTER STUX",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(width: 12),
              Icon(
                Icons.arrow_forward_rounded,
                color: Colors.white,
                size: 19,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BUBBLE
  // ============================================================

  Widget _bubble({
    double? left,
    double? right,
    double? top,
    double? bottom,
    required double size,
    required double opacity,
    required int durationOffset,
  }) {
    return Positioned(
      left: left,
      right: right,
      top: top,
      bottom: bottom,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.92, end: 1.08),
        duration: Duration(
          milliseconds: 2600 + durationOffset,
        ),
        curve: Curves.easeInOut,
        builder: (context, value, child) {
          return Transform.scale(
            scale: value,
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(opacity),
                border: Border.all(
                  color: Colors.white.withOpacity(0.06),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // MAIN LANDING
  // ============================================================

  Widget _buildLanding() {
    return Stack(
      children: [
        // BACKGROUND
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  const Color(0xFF151515),
                  bgBlack,
                  bgBlack,
                ],
              ),
            ),
          ),
        ),

        // SUBTLE GLOW
        Positioned(
          top: -180,
          left: -100,
          child: Container(
            width: 400,
            height: 400,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  Colors.white.withOpacity(0.055),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),

        SafeArea(
          child: Column(
            children: [
              _buildHeader(),

              Expanded(
                child: PageView(
                  controller: _pageController,
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  onPageChanged: (page) {
                    setState(() {
                      _currentPage = page;
                    });

                    if (page == 2) {
                      _startAiTyping();
                    }
                  },
                  children: [
                    _buildInfoSlide(),
                    _buildDeveloperSlide(),
                    _buildAccessSlide(),
                  ],
                ),
              ),

              _buildPageIndicator(),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 15, 22, 8),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.055),
              shape: BoxShape.circle,
              border: Border.all(
                color: glassBorder,
              ),
            ),
            child: const Icon(
              Icons.auto_awesome,
              color: Colors.white70,
              size: 18,
            ),
          ),

          const SizedBox(width: 12),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "STUX",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontFamily: "Orbitron",
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "STUX01 APPS",
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 9,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.045),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: glassBorder,
              ),
            ),
            child: const Text(
              "V18.0",
              style: TextStyle(
                color: Colors.white54,
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 1
  // ============================================================

  Widget _buildInfoSlide() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSlideNumber("01"),

          const SizedBox(height: 12),

          const Text(
            "INFORMATION",
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
              fontFamily: "Orbitron",
            ),
          ),

          const SizedBox(height: 10),

          Text(
            "A short introduction about STUX.",
            style: TextStyle(
              color: Colors.white.withOpacity(0.42),
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 28),

          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(
              24,
              28,
              24,
              28,
            ),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(26),
              border: Border.all(
                color: glassBorder,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.35),
                  blurRadius: 30,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "\"",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 55,
                    height: 0.7,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 15),

                const Text(
                  "STUX is designed as a modern application experience with a clean interface, useful tools and a simple way to access the available workspace.",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 15,
                    height: 1.75,
                  ),
                ),

                const SizedBox(height: 20),

                Container(
                  height: 1,
                  color: Colors.white.withOpacity(0.08),
                ),

                const SizedBox(height: 18),

                const Text(
                  "USE IT RESPONSIBLY",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.8,
                  ),
                ),

                const SizedBox(height: 7),

                const Text(
                  "Please follow the applicable rules and use the application responsibly.",
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 12,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 25),

          _buildMiniFeature(
            Icons.auto_awesome,
            "Clean Experience",
            "Minimal interface designed for comfortable navigation.",
          ),

          const SizedBox(height: 10),

          _buildMiniFeature(
            Icons.dashboard_customize_outlined,
            "Organized Workspace",
            "A structured landing experience with clear actions.",
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 2
  // ============================================================

  Widget _buildDeveloperSlide() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSlideNumber("02"),

          const SizedBox(height: 12),

          const Text(
            "PROJECT",
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
              fontFamily: "Orbitron",
            ),
          ),

          const SizedBox(height: 8),

          Text(
            "Built and maintained by the development team.",
            style: TextStyle(
              color: Colors.white.withOpacity(0.42),
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 30),

          _buildDeveloperCard(
            name: "SEISHIRO",
            role: "Developer",
            icon: Icons.code_rounded,
            number: "01",
          ),

          const SizedBox(height: 14),

          _buildDeveloperCard(
            name: "NUPZZ",
            role: "Developer",
            icon: Icons.terminal_rounded,
            number: "02",
          ),

          const SizedBox(height: 25),

          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.035),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
              ),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.info_outline,
                  color: Colors.white38,
                  size: 20,
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Text(
                    "STUX is developed as a collaborative project. Every part of the interface is designed to keep the experience simple, modern and easy to navigate.",
                    style: TextStyle(
                      color: Colors.white38,
                      fontSize: 12,
                      height: 1.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DEVELOPER CARD
  // ============================================================

  Widget _buildDeveloperCard({
    required String name,
    required String role,
    required IconData icon,
    required String number,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: glassBorder,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: Colors.white.withOpacity(0.10),
              ),
            ),
            child: Icon(
              icon,
              color: Colors.white70,
              size: 25,
            ),
          ),

          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  role,
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 11,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),

          Text(
            number,
            style: TextStyle(
              color: Colors.white.withOpacity(0.13),
              fontSize: 25,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 3
  // ============================================================

  Widget _buildAccessSlide() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
      child: Column(
        children: [
          _buildSlideNumber("03"),

          const SizedBox(height: 15),

          const Text(
            "READY?",
            style: TextStyle(
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
              fontFamily: "Orbitron",
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            "Choose how you want to continue.",
            style: TextStyle(
              color: Colors.white38,
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 25),

          // AI CARD
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.045),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Colors.white.withOpacity(0.10),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 45,
                  height: 45,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.07),
                  ),
                  child: const Icon(
                    Icons.smart_toy_outlined,
                    color: Colors.white70,
                    size: 22,
                  ),
                ),

                const SizedBox(width: 14),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "STUX AI",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),

                      const SizedBox(height: 8),

                      Text(
                        _displayedAiText,
                        style: const TextStyle(
                          color: Colors.white60,
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 4),

                      const Text(
                        "▋",
                        style: TextStyle(
                          color: Colors.white38,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 25),

          // SECURE BUTTON
          _buildMainActionButton(
            icon: Icons.lock_outline_rounded,
            title: "GO SECURE!!",
            subtitle: "Already have an account?",
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => LoginPage(),
                ),
              );
            },
          ),

          const SizedBox(height: 14),

          // BUY BUTTON
          _buildMainActionButton(
            icon: Icons.shopping_bag_outlined,
            title: "GET ACCESS",
            subtitle: "Don't have an account yet?",
            outlined: true,
            onTap: () {
              _openUrl(
                "https://t.me/Xseishz",
              );
            },
          ),

          const SizedBox(height: 18),

          const Text(
            "Access information is available through the official channel.",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white24,
              fontSize: 10,
              height: 1.5,
            ),
          ),

          const SizedBox(height: 25),

          Text(
            "© 2026 STUX APPLICATION",
            style: TextStyle(
              color: Colors.white.withOpacity(0.20),
              fontSize: 9,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // MAIN ACTION BUTTON
  // ============================================================

  Widget _buildMainActionButton({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool outlined = false,
  }) {
    return Container(
      width: double.infinity,
      height: 70,
      decoration: BoxDecoration(
        gradient: outlined
            ? null
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF292929),
                  Color(0xFF111111),
                ],
              ),
        color: outlined
            ? Colors.white.withOpacity(0.035)
            : null,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: Colors.white.withOpacity(
            outlined ? 0.12 : 0.08,
          ),
        ),
        boxShadow: outlined
            ? null
            : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.45),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(21),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 18,
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.055),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    icon,
                    color: Colors.white70,
                    size: 20,
                  ),
                ),

                const SizedBox(width: 14),

                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.35),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),

                const Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: Colors.white30,
                  size: 14,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SLIDE NUMBER
  // ============================================================

  Widget _buildSlideNumber(String number) {
    return Row(
      children: [
        Container(
          width: 35,
          height: 1,
          color: Colors.white24,
        ),
        const SizedBox(width: 10),
        Text(
          number,
          style: const TextStyle(
            color: Colors.white30,
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // MINI FEATURE
  // ============================================================

  Widget _buildMiniFeature(
    IconData icon,
    String title,
    String description,
  ) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.025),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.white38,
            size: 20,
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white60,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  description,
                  style: const TextStyle(
                    color: Colors.white30,
                    fontSize: 10,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PAGE INDICATOR
  // ============================================================

  Widget _buildPageIndicator() {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: 22,
        top: 10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(
          3,
          (index) {
            final bool active = _currentPage == index;

            return AnimatedBuilder(
              animation: _indicatorAnimation,
              builder: (context, child) {
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(
                    horizontal: 4,
                  ),
                  width: active
                      ? 28 * _indicatorAnimation.value
                      : 7,
                  height: 5,
                  decoration: BoxDecoration(
                    color: active
                        ? Colors.white70
                        : Colors.white12,
                    borderRadius: BorderRadius.circular(20),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

// ================================================================
// WAVE PAINTER
// ================================================================

class _WavePainter extends CustomPainter {
  final double progress;

  _WavePainter({
    required this.progress,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withOpacity(0.025);

    for (int i = 0; i < 7; i++) {
      final double baseY =
          size.height * 0.25 + (i * 75);

      final Path path = Path();

      for (double x = 0; x <= size.width; x += 4) {
        final double wave =
            18 *
            (i + 1) /
            7 *
            (0.5 +
                0.5 *
                    (1 +
                        0.0 *
                            (progress *
                                6)));

        final double y =
            baseY +
                20 *
                    (i + 1) /
                    7 *
                    MathSin(
                      (x / size.width * 6.28) +
                          (progress * 6.28),
                    );

        if (x == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y + wave * 0.02);
        }
      }

      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(
    covariant _WavePainter oldDelegate,
  ) {
    return oldDelegate.progress != progress;
  }
}

// ================================================================
// SIN HELPER
// ================================================================

double MathSin(double value) {
  // Simple approximation using dart:math-free animation helper.
  // Keeps this file self-contained.
  return _sinApprox(value);
}

double _sinApprox(double x) {
  while (x > 3.141592653589793) {
    x -= 6.283185307179586;
  }

  while (x < -3.141592653589793) {
    x += 6.283185307179586;
  }

  final double x2 = x * x;

  return x *
      (1 -
          x2 / 6 +
          (x2 * x2) / 120 -
          (x2 * x2 * x2) / 5040);
}