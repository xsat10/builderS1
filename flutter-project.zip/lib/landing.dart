import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ============================================================
  // COLORS
  // ============================================================

  static const Color bgDark = Color(0xFF050608);
  static const Color bgSecondary = Color(0xFF0B0D10);

  static const Color accent = Color(0xFFE5E7EB);
  static const Color accentSoft = Color(0xFF9CA3AF);

  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF9CA3AF);

  static const Color glassPrimary = Color(0x14FFFFFF);
  static const Color glassSecondary = Color(0x0AFFFFFF);

  static const Color borderColor = Color(0x22FFFFFF);

  // ============================================================
  // CONTROLLERS
  // ============================================================

  late AnimationController _introController;
  late AnimationController _backgroundController;
  late AnimationController _pulseController;
  late AnimationController _typingController;

  late Animation<double> _introFade;
  late Animation<double> _introScale;

  final PageController _pageController = PageController();

  Timer? _typingTimer;

  int _currentPage = 0;
  int _typingIndex = 0;

  bool _showIntro = true;

  final String _aiText =
      "STUX AI online.\nSystem ready.\nYour secure environment is waiting.";

  // ============================================================
  // GRADIENT
  // ============================================================

  LinearGradient get silverGradient => const LinearGradient(
        colors: [
          Color(0xFFFFFFFF),
          Color(0xFF9CA3AF),
          Color(0xFF3F3F46),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  // ============================================================
  // INIT
  // ============================================================

  @override
  void initState() {
    super.initState();

    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _backgroundController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _typingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _introFade = CurvedAnimation(
      parent: _introController,
      curve: Curves.easeOutCubic,
    );

    _introScale = Tween<double>(
      begin: 0.72,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _introController,
        curve: Curves.easeOutBack,
      ),
    );

    _introController.forward();

    Future.delayed(const Duration(milliseconds: 2300), () {
      if (!mounted) return;

      setState(() {
        _showIntro = false;
      });

      _startTyping();
    });
  }

  // ============================================================
  // TYPING
  // ============================================================

  void _startTyping() {
    _typingTimer?.cancel();

    _typingIndex = 0;

    _typingTimer = Timer.periodic(
      const Duration(milliseconds: 45),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (_typingIndex >= _aiText.length) {
          timer.cancel();
          return;
        }

        setState(() {
          _typingIndex++;
        });
      },
    );
  }

  // ============================================================
  // URL
  // ============================================================

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);

    try {
      final bool launched = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );

      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Unable to open this link.'),
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Unable to open this link.'),
        ),
      );
    }
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _typingTimer?.cancel();

    _pageController.dispose();

    _introController.dispose();
    _backgroundController.dispose();
    _pulseController.dispose();
    _typingController.dispose();

    super.dispose();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _backgroundController,
              builder: (context, child) {
                return CustomPaint(
                  painter: _FuturisticBackgroundPainter(
                    progress: _backgroundController.value,
                  ),
                );
              },
            ),
          ),

          Positioned.fill(
            child: SafeArea(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 650),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: _showIntro
                    ? _buildIntroScreen()
                    : _buildMainScreen(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // INTRO
  // ============================================================

  Widget _buildIntroScreen() {
    return Center(
      key: const ValueKey('intro'),
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _introController,
          _pulseController,
        ]),
        builder: (context, child) {
          final double pulse =
              1.0 + (_pulseController.value * 0.06);

          return FadeTransition(
            opacity: _introFade,
            child: Transform.scale(
              scale: _introScale.value * pulse,
              child: child,
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildIntroLogo(),

              const SizedBox(height: 28),

              const Text(
                'WELCOME TO',
                style: TextStyle(
                  color: softGrey,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 3,
                ),
              ),

              const SizedBox(height: 10),

              ShaderMask(
                shaderCallback: (bounds) {
                  return silverGradient.createShader(bounds);
                },
                child: const Text(
                  'STUX',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 46,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 7,
                  ),
                ),
              ),

              const SizedBox(height: 12),

              const Text(
                'Advanced Security Environment',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: softGrey,
                  fontSize: 12,
                  letterSpacing: 1,
                ),
              ),

              const SizedBox(height: 32),

              _buildEnterButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIntroLogo() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final double glow =
            18 + (_pulseController.value * 12);

        return Container(
          width: 116,
          height: 116,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: silverGradient,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.10),
                blurRadius: glow,
                spreadRadius: 3,
              ),
            ],
          ),
          padding: const EdgeInsets.all(2),
          child: Container(
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: bgSecondary,
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/logo.png',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(
                    Icons.security_rounded,
                    color: Colors.white,
                    size: 48,
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildEnterButton() {
    return GestureDetector(
      onTap: () {
        if (!mounted) return;

        setState(() {
          _showIntro = false;
        });

        _startTyping();
      },
      child: Container(
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 28),
        decoration: BoxDecoration(
          gradient: silverGradient,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.12),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'ENTER STUX',
              style: TextStyle(
                color: Colors.black,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.8,
              ),
            ),
            SizedBox(width: 12),
            Icon(
              Icons.arrow_forward_rounded,
              color: Colors.black,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // MAIN
  // ============================================================

  Widget _buildMainScreen() {
    return Column(
      key: const ValueKey('main'),
      children: [
        _buildMainHeader(),

        Expanded(
          child: PageView(
            controller: _pageController,
            physics: const BouncingScrollPhysics(),
            onPageChanged: (index) {
              if (!mounted) return;

              setState(() {
                _currentPage = index;
              });

              if (index == 2) {
                _startTyping();
              }
            },
            children: [
              _buildInformationSlide(),
              _buildProjectSlide(),
              _buildReadySlide(),
            ],
          ),
        ),

        _buildPageIndicator(),

        const SizedBox(height: 8),

        _buildFooter(),

        const SizedBox(height: 14),
      ],
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildMainHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.05),
              border: Border.all(
                color: Colors.white.withOpacity(0.12),
              ),
            ),
            padding: const EdgeInsets.all(2),
            child: ClipOval(
              child: Image.asset(
                'assets/images/logo.png',
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(
                    Icons.security_rounded,
                    color: Colors.white,
                    size: 22,
                  );
                },
              ),
            ),
          ),

          const SizedBox(width: 12),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'STUX',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.5,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'SECURITY SYSTEM',
                  style: TextStyle(
                    color: softGrey,
                    fontSize: 8,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.10),
              ),
            ),
            child: const Text(
              'v2.0',
              style: TextStyle(
                color: softGrey,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 1
  // ============================================================

  Widget _buildInformationSlide() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSlideTitle(
            eyebrow: '01 / INFORMATION',
            title: 'SECURITY FIRST.',
            description:
                'A clean and controlled environment designed around security, stability and responsible usage.',
          ),

          const SizedBox(height: 20),

          _buildGlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSmallLabel('SYSTEM QUOTE'),

                const SizedBox(height: 12),

                const Text(
                  '"Security is not a feature.\nIt is the foundation."',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    height: 1.35,
                    fontWeight: FontWeight.w700,
                  ),
                ),

                const SizedBox(height: 18),

                Container(
                  height: 1,
                  color: Colors.white.withOpacity(0.08),
                ),

                const SizedBox(height: 16),

                const Text(
                  'STUX provides a modern interface focused on simplicity, secure access and a controlled user experience.',
                  style: TextStyle(
                    color: softGrey,
                    fontSize: 12,
                    height: 1.6,
                  ),
                ),

                const SizedBox(height: 18),

                _buildWarningBox(),
              ],
            ),
          ),

          const SizedBox(height: 20),

          const Text(
            'CORE FEATURES',
            style: TextStyle(
              color: softGrey,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
            ),
          ),

          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: _buildMiniFeature(
                  Icons.shield_rounded,
                  'SECURE',
                  'Protected',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildMiniFeature(
                  Icons.bolt_rounded,
                  'FAST',
                  'Responsive',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildMiniFeature(
                  Icons.verified_rounded,
                  'TRUST',
                  'Reliable',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWarningBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.035),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline_rounded,
            color: Colors.white,
            size: 18,
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Use the system responsibly. Access should always be used in accordance with applicable rules and permissions.',
              style: TextStyle(
                color: softGrey,
                fontSize: 10,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniFeature(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Container(
      constraints: const BoxConstraints(
        minHeight: 92,
      ),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: glassPrimary,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: borderColor,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: Colors.white,
            size: 21,
          ),
          const SizedBox(height: 9),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: const TextStyle(
              color: softGrey,
              fontSize: 8,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 2
  // ============================================================

  Widget _buildProjectSlide() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSlideTitle(
            eyebrow: '02 / PROJECT',
            title: 'THE TEAM.',
            description:
                'A compact project environment built with focus, consistency and modern technology.',
          ),

          const SizedBox(height: 20),

          _buildDeveloperCard(
            icon: Icons.code_rounded,
            name: 'PINZX777',
            role: 'LEAD DEVELOPER',
            number: '01',
          ),

          const SizedBox(height: 12),

          _buildDeveloperCard(
            icon: Icons.security_rounded,
            name: 'STUX TEAM',
            role: 'SECURITY SYSTEM',
            number: '02',
          ),

          const SizedBox(height: 20),

          _buildGlassCard(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.06),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.10),
                    ),
                  ),
                  child: const Icon(
                    Icons.layers_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),

                const SizedBox(width: 13),

                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'PROJECT INFORMATION',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                      SizedBox(height: 7),
                      Text(
                        'STUX is designed with a minimal interface, controlled access flow and responsive visual system.',
                        style: TextStyle(
                          color: softGrey,
                          fontSize: 10,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeveloperCard({
    required IconData icon,
    required String name,
    required String role,
    required String number,
  }) {
    return _buildGlassCard(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: silverGradient,
            ),
            child: Icon(
              icon,
              color: Colors.black,
              size: 22,
            ),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  role,
                  style: const TextStyle(
                    color: softGrey,
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),

          Text(
            number,
            style: TextStyle(
              color: Colors.white.withOpacity(0.20),
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SLIDE 3
  // ============================================================

  Widget _buildReadySlide() {
    final int safeIndex = _typingIndex.clamp(0, _aiText.length);
    final String typedText = _aiText.substring(0, safeIndex);

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSlideTitle(
            eyebrow: '03 / READY?',
            title: 'GO SECURE.',
            description:
                'Your next step starts here. Enter the system or get access through the existing channel.',
          ),

          const SizedBox(height: 20),

          _buildAiCard(typedText),

          const SizedBox(height: 18),

          _buildSecureButton(),

          const SizedBox(height: 12),

          _buildAccessButton(),
        ],
      ),
    );
  }

  Widget _buildAiCard(String typedText) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0x0FFFFFFF),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Colors.white.withOpacity(0.11),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 25,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  return Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(
                            0.25 + (_pulseController.value * 0.25),
                          ),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  );
                },
              ),

              const SizedBox(width: 9),

              const Text(
                'STUX AI',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),

              const Spacer(),

              const Text(
                'ONLINE',
                style: TextStyle(
                  color: softGrey,
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          Container(
            width: double.infinity,
            constraints: const BoxConstraints(
              minHeight: 120,
            ),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.25),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: Colors.white.withOpacity(0.06),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '> ',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text(
                    typedText,
                    style: const TextStyle(
                      color: softGrey,
                      fontSize: 11,
                      height: 1.7,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    return Opacity(
                      opacity: _pulseController.value > 0.5 ? 1 : 0,
                      child: const Text(
                        '▋',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // BUTTONS
  // ============================================================

  Widget _buildSecureButton() {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/login');
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          horizontal: 17,
          vertical: 15,
        ),
        decoration: BoxDecoration(
          gradient: silverGradient,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.white.withOpacity(0.10),
              blurRadius: 18,
              spreadRadius: 1,
            ),
          ],
        ),
        child: const Row(
          children: [
            Icon(
              Icons.lock_rounded,
              color: Colors.black,
              size: 21,
            ),
            SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'GO SECURE!!',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Enter secure system',
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_rounded,
              color: Colors.black,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccessButton() {
    return GestureDetector(
      onTap: () => _openUrl('https://t.me/pinzx777'),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(
          horizontal: 17,
          vertical: 15,
        ),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.035),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: Colors.white.withOpacity(0.13),
          ),
        ),
        child: const Row(
          children: [
            FaIcon(
              FontAwesomeIcons.telegram,
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'GET ACCESS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Contact Telegram',
                    style: TextStyle(
                      color: softGrey,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_rounded,
              color: Colors.white,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SLIDE TITLE
  // ============================================================

  Widget _buildSlideTitle({
    required String eyebrow,
    required String title,
    required String description,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 15,
              decoration: BoxDecoration(
                gradient: silverGradient,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              eyebrow,
              style: const TextStyle(
                color: softGrey,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.8,
              ),
            ),
          ],
        ),

        const SizedBox(height: 10),

        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 29,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
          ),
        ),

        const SizedBox(height: 7),

        Text(
          description,
          style: const TextStyle(
            color: softGrey,
            fontSize: 10.5,
            height: 1.55,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // GLASS CARD
  // ============================================================

  Widget _buildGlassCard({
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(17),
  }) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: glassPrimary,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: Colors.white.withOpacity(0.09),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.25),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _buildSmallLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: softGrey,
        fontSize: 8,
        fontWeight: FontWeight.w800,
        letterSpacing: 2,
      ),
    );
  }

  // ============================================================
  // PAGE INDICATOR
  // ============================================================

  Widget _buildPageIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        3,
        (index) {
          final bool active = index == _currentPage;

          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic,
            width: active ? 28 : 7,
            height: 5,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              color: active
                  ? Colors.white
                  : Colors.white.withOpacity(0.20),
              borderRadius: BorderRadius.circular(10),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // FOOTER
  // ============================================================

  Widget _buildFooter() {
    return const Text(
      '© 2026 STUX  •  SECURE SYSTEM',
      style: TextStyle(
        color: Color(0x668F939A),
        fontSize: 8,
        letterSpacing: 1.4,
      ),
    );
  }
}

// ================================================================
// FUTURISTIC BACKGROUND
// ================================================================

class _FuturisticBackgroundPainter extends CustomPainter {
  final double progress;

  _FuturisticBackgroundPainter({
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint backgroundPaint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color(0xFF111318),
          Color(0xFF050608),
          Color(0xFF020304),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(
        Rect.fromLTWH(0, 0, size.width, size.height),
      );

    canvas.drawRect(
      Offset.zero & size,
      backgroundPaint,
    );

    _drawGrid(canvas, size);
    _drawWaves(canvas, size);
    _drawBubbles(canvas, size);
  }

  void _drawGrid(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = Colors.white.withOpacity(0.018)
      ..strokeWidth = 0.6
      ..style = PaintingStyle.stroke;

    const double gridSize = 34;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        paint,
      );
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        paint,
      );
    }
  }

  void _drawWaves(Canvas canvas, Size size) {
    for (int wave = 0; wave < 3; wave++) {
      final Paint paint = Paint()
        ..color = Colors.white.withOpacity(
          0.025 - (wave * 0.005),
        )
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1;

      final Path path = Path();

      final double baseY =
          size.height * (0.22 + wave * 0.18);

      final double movement =
          progress * size.width * 0.7;

      path.moveTo(
        -size.width,
        baseY,
      );

      for (double x = -size.width;
          x <= size.width * 2;
          x += 10) {
        final double normalized =
            (x + movement) / size.width;

        final double y =
            baseY +
                math.sin(
                      normalized * math.pi * 2 +
                          wave,
                    ) *
                    (14 + wave * 5) +
                math.sin(
                      normalized * math.pi * 4,
                    ) *
                    6;

        path.lineTo(x, y);
      }

      canvas.drawPath(path, paint);
    }
  }

  void _drawBubbles(Canvas canvas, Size size) {
    final List<_BubbleData> bubbles = [
      _BubbleData(
        x: 0.12,
        y: 0.20,
        radius: 30,
        speed: 1.0,
      ),
      _BubbleData(
        x: 0.82,
        y: 0.30,
        radius: 18,
        speed: 1.4,
      ),
      _BubbleData(
        x: 0.25,
        y: 0.65,
        radius: 14,
        speed: 0.8,
      ),
      _BubbleData(
        x: 0.90,
        y: 0.78,
        radius: 34,
        speed: 0.6,
      ),
      _BubbleData(
        x: 0.55,
        y: 0.48,
        radius: 9,
        speed: 1.8,
      ),
    ];

    for (final bubble in bubbles) {
      final double angle =
          progress * math.pi * 2 * bubble.speed;

      final double dx =
          math.sin(angle) * 12;

      final double dy =
          math.cos(angle) * 14;

      final Offset center = Offset(
        size.width * bubble.x + dx,
        size.height * bubble.y + dy,
      );

      final Paint glowPaint = Paint()
        ..color = Colors.white.withOpacity(0.025)
        ..maskFilter = const MaskFilter.blur(
          BlurStyle.normal,
          12,
        );

      canvas.drawCircle(
        center,
        bubble.radius,
        glowPaint,
      );

      final Paint borderPaint = Paint()
        ..color = Colors.white.withOpacity(0.035)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1;

      canvas.drawCircle(
        center,
        bubble.radius,
        borderPaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant _FuturisticBackgroundPainter oldDelegate,
  ) {
    return oldDelegate.progress != progress;
  }
}

class _BubbleData {
  final double x;
  final double y;
  final double radius;
  final double speed;

  const _BubbleData({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
  });
}