import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage>
    with TickerProviderStateMixin {
  // =========================
  // TEMA
  // =========================
  final Color bgDark = const Color(0xFF020305);
  final Color primaryGrey = const Color(0xFF24282D);
  final Color accentGrey = const Color(0xFF626A73);
  final Color lightGrey = const Color(0xFF9AA3AD);
  final Color primaryWhite = Colors.white;
  final Color accentGreyText = const Color(0xFFB5BDC7);

  final Color cardGlass = Colors.white.withOpacity(0.045);
  final Color borderGlass = Colors.white.withOpacity(0.10);

  List<ActivityModel> activities = [];

  bool isLoading = true;
  String baseUrl = "";

  // =========================
  // ANIMATION
  // =========================
  late AnimationController _backgroundController;
  late AnimationController _clockController;
  late AnimationController _headerController;

  Timer? _clockTimer;
  DateTime _currentTime = DateTime.now();

  @override
  void initState() {
    super.initState();

    _backgroundController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();

    _clockController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 60),
    )..repeat();

    _headerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();

    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          _currentTime = DateTime.now();
        });
      }
    });

    _loadConfigAndActivities();
  }

  @override
  void dispose() {
    _backgroundController.dispose();
    _clockController.dispose();
    _headerController.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }

  // =========================
  // LOAD CONFIG
  // =========================
  Future<void> _loadConfig() async {
    final response = await http.get(
      Uri.parse(
        "https://raw.githubusercontent.com/seishiro9/server1/refs/heads/main/srv1.json",
      ),
    );

    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadConfigAndActivities() async {
    await _loadConfig();
    await _loadActivities();
  }

  // =========================
  // LOAD ACTIVITY
  // =========================
  Future<void> _loadActivities() async {
    try {
      final response = await http
          .get(
            Uri.parse(
              '$baseUrl/getMyActivity?key=${widget.sessionKey}',
            ),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['valid']) {
          final List<dynamic> rawList = data['activities'];

          final parsedActivities = rawList.map((item) {
            return ActivityModel(
              type: item['type'] ?? 'system',
              title: item['title'] ?? 'Aktivitas',
              description: item['description'] ?? '-',
              timestamp: DateTime.fromMillisecondsSinceEpoch(
                item['timestamp'] ??
                    DateTime.now().millisecondsSinceEpoch,
              ),
            );
          }).toList();

          if (!mounted) return;

          setState(() {
            activities = parsedActivities;
            isLoading = false;
          });
        } else {
          if (!mounted) return;

          setState(() {
            isLoading = false;
          });
        }
      } else {
        if (!mounted) return;

        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  // =========================
  // BUILD
  // =========================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,

      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,

        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: _glassIconButton(
            icon: Icons.arrow_back_ios_new_rounded,
            onTap: () => Navigator.pop(context),
          ),
        ),

        title: AnimatedBuilder(
          animation: _headerController,
          builder: (context, child) {
            return Opacity(
              opacity: _headerController.value,
              child: Transform.translate(
                offset: Offset(
                  0,
                  -12 * (1 - _headerController.value),
                ),
                child: child,
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "ACTIVITY",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.55),
                  fontSize: 9,
                  letterSpacing: 3,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              const Text(
                "Riwayat Aktivitas",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.4,
                ),
              ),
            ],
          ),
        ),

        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: _statusIndicator(),
          ),
        ],
      ),

      body: Stack(
        children: [
          // BACKGROUND
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _backgroundController,
              builder: (context, child) {
                return CustomPaint(
                  painter: FuturisticBackgroundPainter(
                    progress: _backgroundController.value,
                  ),
                );
              },
            ),
          ),

          // CONTENT
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 70),

                // =========================
                // CLOCK
                // =========================
                _buildClockSection(),

                const SizedBox(height: 22),

                // =========================
                // ACTIVITY COUNTER
                // =========================
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _buildActivitySummary(),
                ),

                const SizedBox(height: 14),

                Expanded(
                  child: isLoading
                      ? _buildLoading()
                      : activities.isEmpty
                          ? _buildEmpty()
                          : RefreshIndicator(
                              onRefresh: _loadConfigAndActivities,
                              color: Colors.white,
                              backgroundColor: const Color(0xFF15181C),
                              strokeWidth: 2,
                              displacement: 30,
                              child: ListView.builder(
                                physics:
                                    const AlwaysScrollableScrollPhysics(
                                  parent: BouncingScrollPhysics(),
                                ),
                                padding: const EdgeInsets.fromLTRB(
                                  16,
                                  8,
                                  16,
                                  30,
                                ),
                                itemCount: activities.length,
                                itemBuilder: (context, index) {
                                  final activity = activities[index];

                                  return _AnimatedActivityCard(
                                    index: index,
                                    child: _buildActivityCard(
                                      activity,
                                      index,
                                    ),
                                  );
                                },
                              ),
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // CLOCK
  // =========================
  Widget _buildClockSection() {
    return AnimatedBuilder(
      animation: Listenable.merge([
        _clockController,
        _headerController,
      ]),
      builder: (context, child) {
        return Opacity(
          opacity: _headerController.value,
          child: Transform.scale(
            scale: 0.88 + (_headerController.value * 0.12),
            child: child,
          ),
        );
      },
      child: Column(
        children: [
          SizedBox(
            width: 170,
            height: 170,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // OUTER GLOW
                Container(
                  width: 170,
                  height: 170,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.055),
                        blurRadius: 35,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                ),

                // CLOCK
                CustomPaint(
                  size: const Size(170, 170),
                  painter: FuturisticClockPainter(
                    time: _currentTime,
                  ),
                ),

                // CENTER
                Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.5),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Text(
            DateFormat('HH:mm:ss').format(_currentTime),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w700,
              letterSpacing: 4,
              fontFeatures: [
                FontFeature.tabularFigures(),
              ],
            ),
          ),

          const SizedBox(height: 5),

          Text(
            DateFormat('EEEE, dd MMMM yyyy').format(_currentTime),
            style: TextStyle(
              color: Colors.white.withOpacity(0.45),
              fontSize: 11,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // SUMMARY
  // =========================
  Widget _buildActivitySummary() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 13,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.035),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: activities.isEmpty
                  ? Colors.white24
                  : Colors.white,
              boxShadow: activities.isEmpty
                  ? null
                  : [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.4),
                        blurRadius: 8,
                      ),
                    ],
            ),
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Text(
              activities.isEmpty
                  ? "NO ACTIVITY DETECTED"
                  : "ACTIVITY LOG • ${activities.length} EVENT",
              style: TextStyle(
                color: Colors.white.withOpacity(0.65),
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ),

          Icon(
            Icons.sync_rounded,
            size: 15,
            color: Colors.white.withOpacity(0.35),
          ),
        ],
      ),
    );
  }

  // =========================
  // STATUS
  // =========================
  Widget _statusIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.09),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            "LIVE",
            style: TextStyle(
              color: Colors.white.withOpacity(0.65),
              fontSize: 9,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // LOADING
  // =========================
  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 58,
            height: 58,
            child: CircularProgressIndicator(
              strokeWidth: 1.5,
              color: Colors.white.withOpacity(0.75),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            "SYNCING ACTIVITY",
            style: TextStyle(
              color: Colors.white.withOpacity(0.65),
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            "Menghubungkan ke server...",
            style: TextStyle(
              color: Colors.white.withOpacity(0.3),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // EMPTY
  // =========================
  Widget _buildEmpty() {
    return RefreshIndicator(
      onRefresh: _loadConfigAndActivities,
      color: Colors.white,
      backgroundColor: const Color(0xFF15181C),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(
          parent: BouncingScrollPhysics(),
        ),
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.27,
          ),

          Center(
            child: Column(
              children: [
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.035),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.09),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.025),
                        blurRadius: 35,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.history_toggle_off_rounded,
                    size: 42,
                    color: Colors.white.withOpacity(0.35),
                  ),
                ),

                const SizedBox(height: 22),

                const Text(
                  "Belum ada aktivitas",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),

                const SizedBox(height: 7),

                Text(
                  "Pastikan server aktif",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.35),
                    fontSize: 12,
                  ),
                ),

                const SizedBox(height: 16),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                  child: Text(
                    "PULL TO REFRESH",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // ACTIVITY CARD
  // =========================
  Widget _buildActivityCard(
    ActivityModel activity,
    int index,
  ) {
    Color iconColor;
    IconData iconData;
    String typeLabel;

    switch (activity.type) {
      case 'login':
        iconColor = Colors.greenAccent;
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        break;

      case 'bug':
        iconColor = Colors.orangeAccent;
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        break;

      case 'create':
        iconColor = Colors.cyanAccent;
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        break;

      default:
        iconColor = Colors.white54;
        iconData = Icons.info_outline_rounded;
        typeLabel = "SYSTEM";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 13),
      child: Stack(
        children: [
          // SIDE ACTION LINE
          Positioned(
            left: 0,
            top: 17,
            bottom: 17,
            child: Container(
              width: 2,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.65),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: iconColor.withOpacity(0.25),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),

          Container(
            margin: const EdgeInsets.only(left: 7),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: cardGlass,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: borderGlass,
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 18,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ICON
                Container(
                  width: 49,
                  height: 49,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.075),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: iconColor.withOpacity(0.18),
                    ),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: iconColor.withOpacity(0.08),
                          ),
                        ),
                      ),
                      Icon(
                        iconData,
                        color: iconColor,
                        size: 22,
                      ),
                    ],
                  ),
                ),

                const SizedBox(width: 13),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // TITLE + LABEL
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              activity.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                height: 1.2,
                              ),
                            ),
                          ),

                          const SizedBox(width: 8),

                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: iconColor.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(7),
                              border: Border.all(
                                color: iconColor.withOpacity(0.14),
                              ),
                            ),
                            child: Text(
                              typeLabel,
                              style: TextStyle(
                                color: iconColor.withOpacity(0.75),
                                fontSize: 7,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      // DESCRIPTION
                      Text(
                        activity.description,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.47),
                          fontSize: 12,
                          height: 1.45,
                        ),
                      ),

                      const SizedBox(height: 11),

                      // BOTTOM INFORMATION
                      Row(
                        children: [
                          Icon(
                            Icons.schedule_rounded,
                            size: 12,
                            color: Colors.white.withOpacity(0.28),
                          ),

                          const SizedBox(width: 5),

                          Expanded(
                            child: Text(
                              _formatDate(activity.timestamp),
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.32),
                                fontSize: 10,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ),

                          // ACTION DOTS
                          Row(
                            children: List.generate(
                              3,
                              (i) => Container(
                                margin:
                                    const EdgeInsets.only(left: 3),
                                width: 3,
                                height: 3,
                                decoration: BoxDecoration(
                                  color: iconColor.withOpacity(
                                    i == 2 ? 0.65 : 0.2,
                                  ),
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // GLASS BUTTON
  // =========================
  Widget _glassIconButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.045),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: Colors.white.withOpacity(0.09),
            ),
          ),
          child: Icon(
            icon,
            color: Colors.white.withOpacity(0.8),
            size: 17,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// ANIMATED CARD
// ============================================================

class _AnimatedActivityCard extends StatefulWidget {
  final Widget child;
  final int index;

  const _AnimatedActivityCard({
    required this.child,
    required this.index,
  });

  @override
  State<_AnimatedActivityCard> createState() =>
      _AnimatedActivityCardState();
}

class _AnimatedActivityCardState
    extends State<_AnimatedActivityCard>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );

    Future.delayed(
      Duration(milliseconds: math.min(widget.index * 70, 450)),
      () {
        if (mounted) controller.forward();
      },
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        final curved = Curves.easeOutCubic.transform(
          controller.value,
        );

        return Opacity(
          opacity: curved,
          child: Transform.translate(
            offset: Offset(
              35 * (1 - curved),
              0,
            ),
            child: Transform.scale(
              scale: 0.96 + (0.04 * curved),
              child: child,
            ),
          ),
        );
      },
      child: widget.child,
    );
  }
}

// ============================================================
// FUTURISTIC BACKGROUND
// ============================================================

class FuturisticBackgroundPainter extends CustomPainter {
  final double progress;

  FuturisticBackgroundPainter({
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(2026);

    // GRID
    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.018)
      ..strokeWidth = 0.5;

    const gridSize = 32.0;

    for (double x = 0; x < size.width; x += gridSize) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        gridPaint,
      );
    }

    for (double y = 0; y < size.height; y += gridSize) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    // BUBBLES
    for (int i = 0; i < 28; i++) {
      final baseX = random.nextDouble() * size.width;
      final baseY = random.nextDouble() * size.height;

      final radius = 1.5 + random.nextDouble() * 4;

      final movement =
          math.sin((progress * math.pi * 2) + i) * 18;

      final x = baseX + movement;
      final y = baseY + movement * 0.5;

      final bubblePaint = Paint()
        ..color = Colors.white.withOpacity(
          0.025 + random.nextDouble() * 0.035,
        )
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x, y),
        radius,
        bubblePaint,
      );
    }

    // FLOATING LARGE BUBBLES
    for (int i = 0; i < 5; i++) {
      final x = size.width *
          (0.15 + (i * 0.19)) +
          math.sin(
                progress * math.pi * 2 + i,
              ) *
              15;

      final y = size.height *
          (0.15 + (i * 0.17)) +
          math.cos(
                progress * math.pi * 2 + i,
              ) *
              12;

      final radius = 25.0 + i * 8;

      final paint = Paint()
        ..color = Colors.white.withOpacity(0.008)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x, y),
        radius,
        paint,
      );

      final outlinePaint = Paint()
        ..color = Colors.white.withOpacity(0.025)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.7;

      canvas.drawCircle(
        Offset(x, y),
        radius,
        outlinePaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant FuturisticBackgroundPainter oldDelegate,
  ) {
    return oldDelegate.progress != progress;
  }
}

// ============================================================
// FUTURISTIC ANALOG CLOCK
// ============================================================

class FuturisticClockPainter extends CustomPainter {
  final DateTime time;

  FuturisticClockPainter({
    required this.time,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    final radius = size.width / 2 - 7;

    // OUTER RING
    final outerPaint = Paint()
      ..color = Colors.white.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    canvas.drawCircle(
      center,
      radius,
      outerPaint,
    );

    // SECOND RING
    final secondRing = Paint()
      ..color = Colors.white.withOpacity(0.035)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8;

    canvas.drawCircle(
      center,
      radius - 7,
      secondRing,
    );

    // TICKS
    for (int i = 0; i < 60; i++) {
      final angle = (i * math.pi / 30) - math.pi / 2;

      final isHour = i % 5 == 0;

      final outer = radius - 10;
      final inner = isHour ? radius - 20 : radius - 15;

      final p1 = Offset(
        center.dx + math.cos(angle) * outer,
        center.dy + math.sin(angle) * outer,
      );

      final p2 = Offset(
        center.dx + math.cos(angle) * inner,
        center.dy + math.sin(angle) * inner,
      );

      final tickPaint = Paint()
        ..color = Colors.white.withOpacity(
          isHour ? 0.65 : 0.15,
        )
        ..strokeWidth = isHour ? 1.4 : 0.7
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(
        p1,
        p2,
        tickPaint,
      );
    }

    // HOUR HAND
    final hour =
        (time.hour % 12) + time.minute / 60.0;

    _drawHand(
      canvas,
      center,
      radius * 0.46,
      hour * math.pi / 6 - math.pi / 2,
      3,
      Colors.white.withOpacity(0.9),
    );

    // MINUTE HAND
    _drawHand(
      canvas,
      center,
      radius * 0.65,
      time.minute * math.pi / 30 - math.pi / 2,
      2,
      Colors.white.withOpacity(0.65),
    );

    // SECOND HAND
    _drawHand(
      canvas,
      center,
      radius * 0.72,
      time.second * math.pi / 30 - math.pi / 2,
      1,
      Colors.white.withOpacity(0.35),
    );

    // CENTER
    final centerPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawCircle(
      center,
      3.5,
      centerPaint,
    );

    // CENTER OUTLINE
    final centerOutline = Paint()
      ..color = Colors.white.withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    canvas.drawCircle(
      center,
      7,
      centerOutline,
    );
  }

  void _drawHand(
    Canvas canvas,
    Offset center,
    double length,
    double angle,
    double width,
    Color color,
  ) {
    final end = Offset(
      center.dx + math.cos(angle) * length,
      center.dy + math.sin(angle) * length,
    );

    final paint = Paint()
      ..color = color
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(
      center,
      end,
      paint,
    );
  }

  @override
  bool shouldRepaint(
    covariant FuturisticClockPainter oldDelegate,
  ) {
    return oldDelegate.time != time;
  }
}

// ============================================================
// MODEL
// ============================================================

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}