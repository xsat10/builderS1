import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'api_config.dart';

// ─── 🎯 ROLE SYSTEM BARU ──────────────────────────────────────────────────────
const Map<String, int> ROLE_LEVEL = {
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1
};

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
int getRoleLevel(String role) {
  return ROLE_LEVEL[role.toLowerCase()] ?? 0;
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF1744);
    case 'admin': return const Color(0xFFF59E0B);
    case 'tangan_kanan': return const Color(0xFF8B5CF6);
    case 'vip': return const Color(0xFFEC4899);
    case 'reseller': return const Color(0xFF22C55E);
    case 'full_up': return const Color(0xFF10B981);
    case 'member_perbulan': return const Color(0xFF3B82F6);
    case 'member_perminggu': return const Color(0xFFF97316);
    case 'member_perhari': return const Color(0xFF6B7280);
    default: return Colors.white;
  }
}

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  // ─── GETTER UNTUK ROLE ─────────────────────────────────────────────────────
  int get roleLevel => getRoleLevel(widget.role);
  String get roleDisplay => getRoleDisplay(widget.role);
  Color get roleColor => getRoleColor(widget.role);

  // ─── TEMA WARNA CYAN ────────────────────────────────────────────────────────
  final Color bgDark = const Color(0xFF0B1A1A);
  final Color primaryCyan = const Color(0xFF00ACC1);
  final Color accentCyan = const Color(0xFF18FFFF);
  final Color lightCyan = const Color(0xFF84FFFF);
  final Color primaryWhite = Colors.white;
  final Color accentGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.05);
  final Color borderGlass = Colors.white.withOpacity(0.1);

  List<ActivityModel> activities = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadActivities();
  }

  Future<void> _loadActivities() async {
    try {
      final response = await http.get(
        Uri.parse('http://pallmarketplace.ptdlpanel.my.id:11660/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                    item['timestamp'] ?? DateTime.now().millisecondsSinceEpoch
                ),
              );
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        print("Server Error: ${response.statusCode}");
        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Error fetching history: $e");
      setState(() => isLoading = false);
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Row(
          children: [
            Text(
              "Riwayat Aktivitas",
              style: TextStyle(
                color: primaryWhite,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    color: primaryCyan.withOpacity(0.8),
                    blurRadius: 10,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: roleColor.withOpacity(0.15),
                border: Border.all(color: roleColor.withOpacity(0.3)),
              ),
              child: Text(
                roleDisplay,
                style: TextStyle(
                  color: roleColor,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              bgDark,
              roleColor.withOpacity(0.05),
              bgDark,
            ],
          ),
        ),
        child: isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF00ACC1),
                ),
              )
            : activities.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.history_toggle_off, size: 60, color: accentGrey),
                        const SizedBox(height: 16),
                        Text(
                          "Belum ada aktivitas",
                          style: TextStyle(color: accentGrey, fontSize: 16),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "Pastikan server aktif",
                          style: TextStyle(color: accentGrey.withOpacity(0.6), fontSize: 12),
                        ),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _loadActivities,
                    color: roleColor,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: activities.length,
                      itemBuilder: (context, index) {
                        final activity = activities[index];
                        return _buildActivityCard(activity);
                      },
                    ),
                  ),
      ),
    );
  }

  Widget _buildActivityCard(ActivityModel activity) {
    Color iconColor;
    IconData iconData;
    String typeLabel;
    Color typeColor;

    switch (activity.type) {
      case 'login':
        iconColor = Colors.greenAccent;
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        typeColor = Colors.greenAccent;
        break;
      case 'bug':
        iconColor = Colors.orangeAccent;
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        typeColor = Colors.orangeAccent;
        break;
      case 'create':
        iconColor = accentCyan;
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        typeColor = accentCyan;
        break;
      case 'notify':
        iconColor = Colors.purpleAccent;
        iconData = Icons.notifications_active_rounded;
        typeLabel = "NOTIFY";
        typeColor = Colors.purpleAccent;
        break;
      case 'spam_whatsapp':
        iconColor = Colors.greenAccent;
        iconData = FontAwesomeIcons.whatsapp;
        typeLabel = "SPAM WA";
        typeColor = Colors.greenAccent;
        break;
      case 'spam_otp':
        iconColor = Colors.blueAccent;
        iconData = Icons.telegram;
        typeLabel = "SPAM OTP";
        typeColor = Colors.blueAccent;
        break;
      case 'custom_payload':
        iconColor = Colors.pinkAccent;
        iconData = Icons.settings_applications;
        typeLabel = "PAYLOAD";
        typeColor = Colors.pinkAccent;
        break;
      case 'bug_group':
        iconColor = Colors.redAccent;
        iconData = Icons.group_rounded;
        typeLabel = "GROUP";
        typeColor = Colors.redAccent;
        break;
      case 'join_group':
        iconColor = Colors.cyanAccent;
        iconData = Icons.group_add_rounded;
        typeLabel = "JOIN";
        typeColor = Colors.cyanAccent;
        break;
      default:
        iconColor = accentGrey;
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
        typeColor = accentGrey;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass, width: 1),
        boxShadow: [
          BoxShadow(
            color: roleColor.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: iconColor.withOpacity(0.3)),
            ),
            child: Icon(iconData, color: iconColor, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        activity.title,
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: typeColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: typeColor.withOpacity(0.2)),
                      ),
                      child: Text(
                        typeLabel,
                        style: TextStyle(
                          color: typeColor,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  activity.description,
                  style: TextStyle(
                    color: accentGrey,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.access_time, size: 12, color: accentGrey.withOpacity(0.7)),
                    const SizedBox(width: 4),
                    Text(
                      _formatDate(activity.timestamp),
                      style: TextStyle(
                        color: accentGrey.withOpacity(0.7),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    // Role badge di timestamp
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: roleColor.withOpacity(0.1),
                        border: Border.all(color: roleColor.withOpacity(0.2)),
                      ),
                      child: Text(
                        roleDisplay,
                        style: TextStyle(
                          color: roleColor,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}