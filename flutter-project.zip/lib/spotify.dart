import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const SpotifyPage(),
    );
  }
}

class SpotifyPage extends StatefulWidget {
  const SpotifyPage({super.key});

  @override
  State<SpotifyPage> createState() => _SpotifyPageState();
}

class _SpotifyPageState extends State<SpotifyPage> {

  final AudioPlayer player = AudioPlayer();

  List songs = [];
  List favorites = [];

  String currentSong = "";
  String currentArtist = "";
  String currentCover = "";
  String currentUrl = "";

  Duration duration = Duration.zero;
  Duration position = Duration.zero;

  bool isPlaying = false;

  int tabIndex = 0;

  @override
  void initState() {
    super.initState();

    player.onDurationChanged.listen((d) {
      setState(() => duration = d);
    });

    player.onPositionChanged.listen((p) {
      setState(() => position = p);
    });

    player.onPlayerComplete.listen((event) {
      setState(() => isPlaying = false);
    });
  }

  Future searchMusic(String query) async {

    final url =
        "https://itunes.apple.com/search?term=$query&entity=song&limit=25";

    final res = await http.get(Uri.parse(url));
    final data = json.decode(res.body);

    setState(() {
      songs = data["results"];
    });
  }

  void playMusic(song) async {

    await player.stop();

    await player.play(UrlSource(song["previewUrl"]));

    setState(() {
      currentSong = song["trackName"];
      currentArtist = song["artistName"];
      currentCover = song["artworkUrl100"];
      currentUrl = song["previewUrl"];
      isPlaying = true;
    });
  }

  void togglePlay() async {

    if (isPlaying) {
      await player.pause();
    } else {
      await player.resume();
    }

    setState(() {
      isPlaying = !isPlaying;
    });
  }

  void toggleFavorite(song) {

    if (favorites.contains(song)) {
      favorites.remove(song);
    } else {
      favorites.add(song);
    }

    setState(() {});
  }

  Widget songList(List list) {

    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, i) {

        final song = list[i];

        final isFav = favorites.contains(song);

        return ListTile(

          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(song["artworkUrl100"]),
          ),

          title: Text(
            song["trackName"],
            style: const TextStyle(color: Colors.white),
          ),

          subtitle: Text(
            song["artistName"],
            style: const TextStyle(color: Colors.grey),
          ),

          trailing: IconButton(
            icon: Icon(
              isFav ? Icons.favorite : Icons.favorite_border,
              color: isFav ? Colors.green : Colors.grey,
            ),
            onPressed: () => toggleFavorite(song),
          ),

          onTap: () => playMusic(song),
        );
      },
    );
  }

  Widget searchTab() {

    return Column(
      children: [

        Padding(
          padding: const EdgeInsets.all(15),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            onSubmitted: searchMusic,
            decoration: InputDecoration(
              hintText: "Search songs...",
              hintStyle: const TextStyle(color: Colors.grey),
              filled: true,
              fillColor: const Color(0xff1c1c1c),
              prefixIcon: const Icon(Icons.search, color: Colors.white),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),

        Expanded(child: songList(songs))
      ],
    );
  }

  Widget favoriteTab() {

    if (favorites.isEmpty) {
      return const Center(
        child: Text(
          "No favorites yet",
          style: TextStyle(color: Colors.grey),
        ),
      );
    }

    return songList(favorites);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Colors.black,

      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text("Xeternalz Music"),
        centerTitle: true,
      ),

      body: tabIndex == 0 ? searchTab() : favoriteTab(),

      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [

          if (currentSong.isNotEmpty)
          Container(
            color: const Color(0xff1db954),
            child: Column(
              children: [

                Slider(
                  min: 0,
                  max: duration.inSeconds.toDouble(),
                  value: position.inSeconds
                      .toDouble()
                      .clamp(0, duration.inSeconds.toDouble()),
                  onChanged: (v) async {
                    await player.seek(Duration(seconds: v.toInt()));
                  },
                ),

                ListTile(
                  leading: Image.network(currentCover),

                  title: Text(
                    currentSong,
                    style: const TextStyle(color: Colors.black),
                  ),

                  subtitle: Text(
                    currentArtist,
                    style: const TextStyle(color: Colors.black),
                  ),

                  trailing: IconButton(
                    icon: Icon(
                      isPlaying
                          ? Icons.pause_circle
                          : Icons.play_circle,
                      color: Colors.black,
                      size: 35,
                    ),
                    onPressed: togglePlay,
                  ),
                ),
              ],
            ),
          ),

          BottomNavigationBar(
            backgroundColor: Colors.black,
            selectedItemColor: Colors.green,
            unselectedItemColor: Colors.grey,
            currentIndex: tabIndex,
            onTap: (i) {
              setState(() {
                tabIndex = i;
              });
            },
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.search),
                label: "Search",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.favorite),
                label: "Favorites",
              ),
            ],
          )
        ],
      ),
    );
  }
}