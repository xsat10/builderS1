// intro_fingerprint_page.dart - VOR4X SECURE ACCESS
// Tema: Biru-Hitam, neon glow, fingerprint hold-to-unlock
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class IntroFingerprintPage extends StatefulWidget {
  /// Dipanggil setelah verifikasi sidik jari berhasil.
  /// Kalau null, akan fallback ke route '/otw_landing'.
  final VoidCallback? onVerified;

  const IntroFingerprintPage({
    super.key,
    this.onVerified,
  });

  @override
  State<IntroFingerprintPage> createState() => _IntroFingerprintPageState();
}

class _IntroFingerprintPageState extends State<IntroFingerprintPage>
    with TickerProviderStateMixin {
  // ─── PALET WARNA ─────────────────────────────────────────
  static const Color bgDark         = Color(0xFF000814);
  static const Color neonBlue       = Color(0xFF00E5FF);
  static const Color neonBlueBright = Color(0xFF33F0FF);
  static const Color neonBlueDim    = Color(0xFF0091EA);
  static const Color neonBlueDeep   = Color(0xFF0055AA);
  static const Color textSub        = Color(0xFF9FC4E0);

  // ─── CONFIG ──────────────────────────────────────────────
  static const int _holdDurationMs = 1400;
  static const double _circleSize = 240.0;

  // ─── STATE ───────────────────────────────────────────────
  bool _holding = false;
  bool _unlocked = false;
  bool _navigated = false;
  double _progress = 0.0;
  Timer? _holdTimer;
  DateTime? _holdStart;
  bool _successVibrated = false;

  // ─── ANIMASI ─────────────────────────────────────────────
  late AnimationController _decoRingCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _dotCtrl;
  late AnimationController _flashCtrl;
  late AnimationController _shockCtrl;

  late Animation<double> _decoRotate;
  late Animation<double> _pulse;
  late Animation<double> _dotBlink;
  late Animation<double> _flashAnim;
  late Animation<double> _shockAnim;

  @override
  void initState() {
    super.initState();

    // Deco ring berputar pelan
    _decoRingCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    )..repeat();

    _decoRotate = Tween<double>(begin: 0, end: 2 * math.pi).animate(
      CurvedAnimation(parent: _decoRingCtrl, curve: Curves.linear),
    );

    // Pulse glow
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat(reverse: true);

    _pulse = Tween<double>(begin: 0.4, end: 0.9).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    // Dot blink
    _dotCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _dotBlink = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _dotCtrl, curve: Curves.easeInOut),
    );

    // Flash biru pas unlock
    _flashCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _flashAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _flashCtrl, curve: Curves.easeOut),
    );

    // Shockwave pas unlock
    _shockCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _shockAnim = Tween<double>(begin: 0.5, end: 3.0).animate(
      CurvedAnimation(parent: _shockCtrl, curve: Curves.easeOut),
    );
  }

  // ═══════════════════════════════════════════════════════
  //  HOLD LOGIC
  // ═══════════════════════════════════════════════════════
  void _startHold() {
    if (_unlocked || _holding) return;

    setState(() {
      _holding = true;
      _progress = 0.0;
      _successVibrated = false;
    });

    HapticFeedback.lightImpact();
    _holdStart = DateTime.now();

    _holdTimer?.cancel();
    _holdTimer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_holding) {
        t.cancel();
        return;
      }

      final elapsed = DateTime.now().difference(_holdStart!).inMilliseconds;
      final p = (elapsed / _holdDurationMs).clamp(0.0, 1.0);

      setState(() => _progress = p);

      if (!_successVibrated && p >= 0.99) {
        _successVibrated = true;
        HapticFeedback.mediumImpact();
      }

      if (p >= 1.0) {
        t.cancel();
        _unlock();
      }
    });
  }

  void _cancelHold() {
    if (_unlocked || !_holding) return;

    _holdTimer?.cancel();
    _holdTimer = null;

    setState(() {
      _holding = false;
      _progress = 0.0;
    });

    HapticFeedback.selectionClick();
  }

  // ═══════════════════════════════════════════════════════
  //  UNLOCK + NAVIGASI (INI YANG FIX STUCK)
  // ═══════════════════════════════════════════════════════
  void _unlock() {
    if (_unlocked) return;

    _holdTimer?.cancel();
    _holdTimer = null;

    setState(() {
      _unlocked = true;
      _holding = false;
      _progress = 1.0;
    });

    HapticFeedback.heavyImpact();

    // Efek visual
    _flashCtrl.forward(from: 0).then((_) {
      if (mounted) _flashCtrl.reverse();
    });
    _shockCtrl.forward(from: 0);

    // ─── NAVIGASI OTOMATIS SETELAH 1.2 DETIK ─────────────
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted || _navigated) return;
      _navigated = true;

      // 1) Coba callback dari main.dart dulu
      if (widget.onVerified != null) {
        widget.onVerified!();
        return;
      }

      // 2) Fallback: pakai named route '/otw_landing'
      Navigator.of(context).pushReplacementNamed('/otw_landing');
    });
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _decoRingCtrl.dispose();
    _pulseCtrl.dispose();
    _dotCtrl.dispose();
    _flashCtrl.dispose();
    _shockCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // ─── BACKGROUND GRADIENT ──────────────────────────
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0, -0.2),
                  radius: 1.3,
                  colors: [
                    Color(0xFF003D66),
                    Color(0xFF001A33),
                    Color(0xFF000814),
                    Color(0xFF000205),
                  ],
                  stops: [0.0, 0.4, 0.75, 1.0],
                ),
              ),
            ),
          ),

          // ─── GRID NEON ────────────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _GridPainter()),
            ),
          ),

          // ─── GLOW ORB ATAS ────────────────────────────────
          Positioned(
            top: -250, left: -150, right: -150,
            child: IgnorePointer(
              child: Container(
                height: 700,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      neonBlue.withOpacity(0.28),
                      neonBlueDim.withOpacity(0.12),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.4, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // ─── GLOW ORB BAWAH ───────────────────────────────
          Positioned(
            bottom: -250, left: -100, right: -100,
            child: IgnorePointer(
              child: Container(
                height: 600,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      neonBlueDeep.withOpacity(0.32),
                      neonBlueDim.withOpacity(0.10),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // ─── PARTIKEL MELAYANG ────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: _ParticlesLayer(color: neonBlue, count: 22),
            ),
          ),

          // ─── SHOCKWAVE ────────────────────────────────────
          if (_unlocked)
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _shockAnim,
                  builder: (context, _) {
                    final v = _shockAnim.value;
                    final opacity = (1 - (v / 3)).clamp(0.0, 1.0);
                    return Center(
                      child: Opacity(
                        opacity: opacity,
                        child: Container(
                          width: 200 * v,
                          height: 200 * v,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: neonBlue,
                              width: 4 * (1 - v / 3).clamp(0.0, 1.0),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: neonBlue.withOpacity(0.8),
                                blurRadius: 40,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

          // ─── FLASH ────────────────────────────────────────
          if (_unlocked)
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _flashAnim,
                  builder: (context, _) {
                    return Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          colors: [
                            neonBlue.withOpacity(0.7 * _flashAnim.value),
                            neonBlue.withOpacity(0.2 * _flashAnim.value),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.3, 0.7],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

          // ─── KONTEN UTAMA ─────────────────────────────────
          SafeArea(
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 600),
              opacity: _unlocked ? 0 : 1,
              child: AnimatedScale(
                duration: const Duration(milliseconds: 600),
                scale: _unlocked ? 1.08 : 1.0,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildTitle(),
                      const SizedBox(height: 40),
                      _buildFingerprint(),
                      const SizedBox(height: 40),
                      _buildScanText(),
                      const SizedBox(height: 20),
                      if (!_unlocked) _buildHint(),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ─── WATERMARK ────────────────────────────────────
          const Positioned(
            bottom: 22,
            left: 0,
            right: 0,
            child: Center(
              child: Text(
                'VOR4X 2.0.0',
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 3,
                  color: Color(0x6600E5FF),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  //  TITLE
  // ═══════════════════════════════════════════════════════
  Widget _buildTitle() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFE0F7FF),
              Color(0xFF33F0FF),
              Color(0xFF00B4FF),
              Color(0xFF0066CC),
            ],
            stops: [0.0, 0.45, 0.8, 1.0],
          ).createShader(bounds),
          child: const Text(
            'VOR4X',
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 46,
              fontWeight: FontWeight.w900,
              letterSpacing: 8,
              color: Colors.white,
              height: 1.0,
              shadows: [
                Shadow(color: Color(0xFF00E5FF), blurRadius: 25),
                Shadow(color: Color(0xFF0091EA), blurRadius: 45),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _neonBar(),
            const SizedBox(width: 10),
            Text(
              'SECURE ACCESS',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 4,
                color: neonBlue.withOpacity(0.75),
                shadows: [
                  Shadow(color: neonBlue, blurRadius: 10),
                ],
              ),
            ),
            const SizedBox(width: 10),
            _neonBar(),
          ],
        ),
      ],
    );
  }

  Widget _neonBar() {
    return Container(
      width: 40,
      height: 1.5,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.transparent, neonBlue, Colors.transparent],
        ),
        boxShadow: [BoxShadow(color: neonBlue, blurRadius: 8)],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  //  FINGERPRINT AREA
  // ═══════════════════════════════════════════════════════
  Widget _buildFingerprint() {
    const double size = _circleSize;
    const double circleSize = 160;

    return GestureDetector(
      onTapDown: (_) => _startHold(),
      onTapUp: (_) => _cancelHold(),
      onTapCancel: _cancelHold,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Deco ring
            AnimatedBuilder(
              animation: _decoRotate,
              builder: (context, _) {
                return Transform.rotate(
                  angle: _decoRotate.value,
                  child: CustomPaint(
                    size: const Size(size, size),
                    painter: _DecoRingPainter(
                      color: neonBlue.withOpacity(0.20),
                      radius: size / 2 - 2,
                    ),
                  ),
                );
              },
            ),

            // Deco dots (4 titik)
            ..._buildDecoDots(size),

            // Pulse glow
            AnimatedBuilder(
              animation: _pulse,
              builder: (context, _) {
                final p = _holding ? 1.0 : _pulse.value;
                return Container(
                  width: size * 0.95,
                  height: size * 0.95,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: neonBlue.withOpacity(0.20 * p),
                        blurRadius: 40 * p,
                        spreadRadius: 10 * p,
                      ),
                    ],
                  ),
                );
              },
            ),

            // Ring progress
            CustomPaint(
              size: const Size(size, size),
              painter: _RingProgressPainter(
                progress: _progress,
                neonBlue: neonBlue,
                neonBlueBright: neonBlueBright,
                neonBlueDeep: neonBlueDeep,
              ),
            ),

            // Ring tip glow
            if (_progress > 0.01)
              _RingTip(
                progress: _progress,
                ringRadius: size / 2 - 20,
                containerSize: size,
                glowColor: neonBlueBright,
              ),

            // Finger circle + icon
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: circleSize * (_holding ? 1.03 : 1.0),
              height: circleSize * (_holding ? 1.03 : 1.0),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: _holding
                      ? [
                          neonBlue.withOpacity(0.20),
                          const Color(0xFF001E37).withOpacity(0.95),
                          const Color(0xFF000814),
                        ]
                      : [
                          neonBlue.withOpacity(0.06),
                          const Color(0xFF001428).withOpacity(0.9),
                          const Color(0xFF000814),
                        ],
                  stops: const [0.0, 0.7, 1.0],
                ),
                border: Border.all(
                  color: _holding
                      ? neonBlue.withOpacity(0.9)
                      : neonBlue.withOpacity(0.25),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: neonBlue.withOpacity(_holding ? 0.7 : 0.15),
                    blurRadius: _holding ? 50 : 25,
                    spreadRadius: _holding ? 4 : 0,
                  ),
                  BoxShadow(
                    color: neonBlue.withOpacity(_holding ? 0.3 : 0.08),
                    blurRadius: _holding ? 100 : 30,
                    spreadRadius: _holding ? 8 : 0,
                  ),
                ],
              ),
              child: Center(
                child: AnimatedScale(
                  duration: const Duration(milliseconds: 250),
                  scale: _holding ? 1.1 : 1.0,
                  child: ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF33F0FF),
                        Color(0xFF00E5FF),
                        Color(0xFF0091EA),
                      ],
                    ).createShader(bounds),
                    child: Icon(
                      Icons.fingerprint_rounded,
                      size: 90,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          color: neonBlue.withOpacity(0.9),
                          blurRadius: _holding ? 25 : 14,
                        ),
                        if (_holding)
                          Shadow(
                            color: neonBlue.withOpacity(0.8),
                            blurRadius: 50,
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildDecoDots(double size) {
    final dots = <Widget>[];
    final radius = size / 2 - 2;

    for (int i = 0; i < 4; i++) {
      final angle = (math.pi / 2) * i;
      final x = size / 2 + radius * math.cos(angle) - 2;
      final y = size / 2 + radius * math.sin(angle) - 2;

      dots.add(
        Positioned(
          left: x,
          top: y,
          child: AnimatedBuilder(
            animation: _pulse,
            builder: (context, _) {
              return Container(
                width: 4,
                height: 4,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: neonBlue,
                  boxShadow: [
                    BoxShadow(
                      color: neonBlue.withOpacity(_pulse.value),
                      blurRadius: 8,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      );
    }
    return dots;
  }

  // ═══════════════════════════════════════════════════════
  //  SCAN TEXT
  // ═══════════════════════════════════════════════════════
  Widget _buildScanText() {
    final String label;
    if (_unlocked) {
      label = '✓ AKSES DIBERIKAN';
    } else if (_holding) {
      label = 'MEMINDAI...';
    } else {
      label = 'SCAN SIDIK JARI';
    }

    final Color bgColor = _unlocked
        ? neonBlue.withOpacity(0.35)
        : _holding
            ? neonBlue.withOpacity(0.18)
            : neonBlue.withOpacity(0.06);

    final Color borderColor = _unlocked
        ? neonBlueBright
        : _holding
            ? neonBlue
            : neonBlue.withOpacity(0.35);

    final Color glowColor = _unlocked
        ? neonBlue.withOpacity(1.0)
        : _holding
            ? neonBlue.withOpacity(0.9)
            : neonBlue.withOpacity(0.2);

    return GestureDetector(
      onTapDown: (_) => _startHold(),
      onTapUp: (_) => _cancelHold(),
      onTapCancel: _cancelHold,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        constraints: const BoxConstraints(minWidth: 240),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 13),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: borderColor, width: 1),
          boxShadow: [
            BoxShadow(
              color: glowColor,
              blurRadius: _unlocked ? 50 : _holding ? 35 : 15,
            ),
            BoxShadow(
              color: glowColor.withOpacity(0.5),
              blurRadius: _unlocked ? 100 : 30,
            ),
          ],
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 4,
            color: (_unlocked || _holding) ? Colors.white : textSub,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  //  HINT
  // ═══════════════════════════════════════════════════════
  Widget _buildHint() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _BlinkDot(color: neonBlue, anim: _dotBlink),
        const SizedBox(width: 8),
        Text(
          'TAHAN SAMPAI RING PENUH',
          style: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
            color: neonBlue.withOpacity(0.45),
          ),
        ),
        const SizedBox(width: 8),
        _BlinkDot(color: neonBlue, anim: _dotBlink),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// HELPER WIDGETS & PAINTERS
// ═══════════════════════════════════════════════════════════

class _BlinkDot extends StatelessWidget {
  final Color color;
  final Animation<double> anim;
  const _BlinkDot({required this.color, required this.anim});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: anim,
      builder: (context, _) {
        return Container(
          width: 5,
          height: 5,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(anim.value),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(anim.value),
                blurRadius: 8,
              ),
            ],
          ),
        );
      },
    );
  }
}

class _RingTip extends StatelessWidget {
  final double progress;
  final double ringRadius;
  final double containerSize;
  final Color glowColor;

  const _RingTip({
    required this.progress,
    required this.ringRadius,
    required this.containerSize,
    required this.glowColor,
  });

  @override
  Widget build(BuildContext context) {
    final angle = -math.pi / 2 + (progress * 2 * math.pi);
    final cx = containerSize / 2 + ringRadius * math.cos(angle);
    final cy = containerSize / 2 + ringRadius * math.sin(angle);

    return Positioned(
      left: cx - 6,
      top: cy - 6,
      child: Container(
        width: 12,
        height: 12,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: glowColor, blurRadius: 12, spreadRadius: 3),
            BoxShadow(color: glowColor, blurRadius: 24, spreadRadius: 6),
          ],
        ),
      ),
    );
  }
}

class _RingProgressPainter extends CustomPainter {
  final double progress;
  final Color neonBlue;
  final Color neonBlueBright;
  final Color neonBlueDeep;

  _RingProgressPainter({
    required this.progress,
    required this.neonBlue,
    required this.neonBlueBright,
    required this.neonBlueDeep,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 20;

    // Track dalam
    final trackInner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = neonBlue.withOpacity(0.06);
    canvas.drawCircle(center, radius - 20, trackInner);

    // Track utama
    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..color = neonBlue.withOpacity(0.10);
    canvas.drawCircle(center, radius, trackPaint);

    // Progress arc
    if (progress > 0) {
      final rect = Rect.fromCircle(center: center, radius: radius);
      final sweep = 2 * math.pi * progress.clamp(0.0, 1.0);

      // Glow
      final glowPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 12
        ..strokeCap = StrokeCap.round
        ..color = neonBlue.withOpacity(0.4)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
      canvas.drawArc(rect, -math.pi / 2, sweep, false, glowPaint);

      // Main arc
      final arcPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round
        ..shader = SweepGradient(
          startAngle: -math.pi / 2,
          endAngle: -math.pi / 2 + 2 * math.pi,
          colors: [
            neonBlueDeep,
            neonBlue,
            neonBlueBright,
            neonBlue,
            neonBlueDeep,
          ],
          stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
        ).createShader(rect);
      canvas.drawArc(rect, -math.pi / 2, sweep, false, arcPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RingProgressPainter old) =>
      old.progress != progress;
}

class _DecoRingPainter extends CustomPainter {
  final Color color;
  final double radius;

  _DecoRingPainter({required this.color, required this.radius});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = color;

    const int dashes = 36;
    const double dashAngle = (2 * math.pi) / dashes / 2;

    for (int i = 0; i < dashes; i++) {
      final startAngle = (2 * math.pi / dashes) * i;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        dashAngle,
        false,
        paint,
      );
    }

    // Ring dalam dotted
    final innerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = color.withOpacity(0.75);

    const int innerDashes = 60;
    const double innerDashAngle = (2 * math.pi) / innerDashes / 2;
    for (int i = 0; i < innerDashes; i++) {
      final startAngle = (2 * math.pi / innerDashes) * i;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius * 0.92),
        startAngle,
        innerDashAngle,
        false,
        innerPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DecoRingPainter old) =>
      old.color != color || old.radius != radius;
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.04)
      ..strokeWidth = 1;

    const double gap = 44;

    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ═══════════════════════════════════════════════════════════
// PARTIKEL MELAYANG
// ═══════════════════════════════════════════════════════════
class _ParticlesLayer extends StatefulWidget {
  final Color color;
  final int count;

  const _ParticlesLayer({required this.color, required this.count});

  @override
  State<_ParticlesLayer> createState() => _ParticlesLayerState();
}

class _ParticlesLayerState extends State<_ParticlesLayer>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late List<_Particle> _particles;

  @override
  void initState() {
    super.initState();

    final rng = math.Random();
    _particles = List.generate(widget.count, (_) {
      return _Particle(
        x: rng.nextDouble(),
        size: 2 + rng.nextDouble() * 3,
        speed: 0.3 + rng.nextDouble() * 0.5,
        delay: rng.nextDouble(),
        drift: (rng.nextDouble() * 60 - 30) / 100,
        opacity: 0.3 + rng.nextDouble() * 0.5,
      );
    });

    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        return CustomPaint(
          painter: _ParticlePainter(
            particles: _particles,
            progress: _ctrl.value,
            color: widget.color,
          ),
        );
      },
    );
  }
}

class _Particle {
  final double x;
  final double size;
  final double speed;
  final double delay;
  final double drift;
  final double opacity;

  _Particle({
    required this.x,
    required this.size,
    required this.speed,
    required this.delay,
    required this.drift,
    required this.opacity,
  });
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  final double progress;
  final Color color;

  _ParticlePainter({
    required this.particles,
    required this.progress,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      double t = (progress * p.speed + p.delay) % 1.0;
      final y = size.height - (t * size.height * 1.1);
      final x = p.x * size.width + (t * p.drift * size.width);

      double alpha = p.opacity;
      if (t < 0.1) alpha *= t / 0.1;
      if (t > 0.9) alpha *= (1 - t) / 0.1;
      alpha = alpha.clamp(0.0, 1.0);

      final paint = Paint()
        ..color = color.withOpacity(alpha)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);

      canvas.drawCircle(Offset(x, y), p.size / 2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter old) => true;
}