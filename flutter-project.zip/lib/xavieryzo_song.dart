import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

class DarkRedTheme {
  static const Color bgDark = Color(0xFF0D0D0F);
  static const Color redDark = Color(0xFF8B0000);
  static const Color redAccent = Color(0xFFE53935);
  static const Color maroon = Color(0xFF3D1A1A);
  static const Color greyLight = Color(0xFFB0B0B0);
  static const Color textWhite = Colors.white;
}

class XavieryzoSongPage extends StatefulWidget {
  const XavieryzoSongPage({super.key});

  @override
  _XavieryzoSongPageState createState() => _XavieryzoSongPageState();
}

class _XavieryzoSongPageState extends State<XavieryzoSongPage> {
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  Map<String, dynamic>? _song;
  bool _loading = false;

  Future<void> searchSpotify(String input) async {
    setState(() {
      _loading = true;
      _song = null;
    });

    String spotifyUrl = input.trim();

    try {
      if (!spotifyUrl.contains("open.spotify.com")) {
        final searchRes = await http.get(Uri.parse(
            "https://riimusic.my.id/api/spotify/search?apikey=riicode&query=${Uri.encodeComponent(input)}"));

        final searchData = json.decode(searchRes.body);
        final track = searchData["result"]?["songs"]?[0];

        if (track == null) {
          setState(() {
            _loading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("❌ Lagu tidak ditemukan")));
          return;
        }

        spotifyUrl = track["url"];
      }

      final res = await http.get(Uri.parse(
          "https://api.ikyyxd.my.id/download/spotifydl?url=${Uri.encodeComponent(spotifyUrl)}"));

      final data = json.decode(res.body);

      if (data["status"] != true) {
        setState(() {
          _loading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("❌ Gagal mengambil lagu")));
        return;
      }

      setState(() {
        _song = data["result"];
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
      });
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("❌ Terjadi error: $e")));
    }
  }

  Future<void> playSong() async {
    if (_song == null) return;

    final audioRes = await http.get(Uri.parse(_song!["download"]),
        headers: {"User-Agent": "Mozilla/5.0"});

    Uint8List bytes = audioRes.bodyBytes;

    await _player.play(BytesSource(bytes));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: DarkRedTheme.bgDark,
      appBar: AppBar(
        backgroundColor: DarkRedTheme.redDark,
        title: const Text("Spotify Downloader"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              style: const TextStyle(color: DarkRedTheme.textWhite),
              decoration: InputDecoration(
                hintText: "Masukkan judul lagu / URL Spotify",
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: DarkRedTheme.maroon,
              ),
              onSubmitted: searchSpotify,
            ),
            const SizedBox(height: 20),
            if (_loading)
              const CircularProgressIndicator(color: DarkRedTheme.redAccent),
            if (_song != null) ...[
              Image.network(_song!["thumbnail"]),
              const SizedBox(height: 10),
              Text(
                _song!["title"],
                style: const TextStyle(
                    color: DarkRedTheme.textWhite, fontSize: 18),
              ),
              Text(
                "👤 ${_song!["artist"]}",
                style: const TextStyle(color: DarkRedTheme.greyLight),
              ),
              Text(
                "💿 Album: ${_song!["album"] ?? "-"}",
                style: const TextStyle(color: DarkRedTheme.greyLight),
              ),
              Text(
                "⏱️ Duration: ${_song!["duration"]}",
                style: const TextStyle(color: DarkRedTheme.greyLight),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: playSong,
                icon: const Icon(Icons.play_arrow),
                label: const Text("Play"),
              ),
            ]
          ],
        ),
      ),
    );
  }
}