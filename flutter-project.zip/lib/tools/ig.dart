import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

class IGColors {
  static const Color bgBase = Color(0xFF000000);
  static const Color bgCard = Color(0xFF1A1A1A);
  static const Color bgElevated = Color(0xFF262626);
  static const Color igPurple = Color(0xFF833AB4);
  static const Color igRed = Color(0xFFFD1D1D);
  static const Color igOrange = Color(0xFFF77737);
  static const Color igYellow = Color(0xFFFCAF45);
  static const Color igPink = Color(0xFFE1306C);
  static const Color white = Color(0xFFFFFFFF);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color textMuted = Color(0xFF555555);
  static const Color danger = Color(0xFFED4956);
  static const Color border = Color(0xFF363636);
  static const List<Color> gradient = [
    igPurple,
    igPink,
    igRed,
    igOrange,
    igYellow,
  ];
}

class IGGradient {
  static const LinearGradient main = LinearGradient(
    colors: IGColors.gradient,
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static BoxDecoration get buttonDecoration => BoxDecoration(
        gradient: main,
        borderRadius: BorderRadius.circular(50),
      );

  static BoxDecoration get borderDecoration => BoxDecoration(
        gradient: main,
        borderRadius: BorderRadius.circular(16),
      );
}

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() =>
      _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _urlController = TextEditingController();

  bool _isLoading = false;
  bool _saving    = false;
  Map<String, dynamic>? _result;
  String? _errorMessage;

  VideoPlayerController? _videoController;
  ChewieController?       _chewieController;

  int _carouselIndex = 0;
  final PageController _pageCtrl = PageController();

  late AnimationController _glowCtrl;
  late Animation<double>   _glowAnim;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    _glowCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  void _toast(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: IGColors.white)),
        backgroundColor:
            isError ? IGColors.danger : IGColors.bgElevated,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() => _errorMessage = 'url gak boleh kosong');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
      _carouselIndex = 0;
    });

    _videoController?.dispose();
    _chewieController?.dispose();
    _videoController = null;
    _chewieController = null;

    final apiUrl = Uri.parse(
      'https://api.nexray.eu.cc/downloader/v2/instagram?url=${Uri.encodeComponent(url)}',
    );

    try {
      final res =
          await http.get(apiUrl).timeout(const Duration(seconds: 25));

      if (res.statusCode != 200) {
        setState(
            () => _errorMessage = 'Error ${res.statusCode}');
        return;
      }

      final json = jsonDecode(res.body);
      if (json is Map &&
          json['status'] == true &&
          json['result'] != null) {
        final data = Map<String, dynamic>.from(json['result']);
        setState(() => _result = data);

        final media = data['media'] as List?;
        if (media != null && media.isNotEmpty) {
          final first = media.first as Map;
          if (first['type'] == 'mp4') {
            _initVideo(first['url'] as String?);
          }
        }
      } else {
        setState(() =>
            _errorMessage = 'gagal mengambil data. cek url dan coba lagi');
      }
    } catch (e) {
      setState(() => _errorMessage = 'Error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initVideo(String? videoUrl) {
    if (videoUrl == null || videoUrl.isEmpty) return;

    _videoController =
        VideoPlayerController.networkUrl(Uri.parse(videoUrl))
          ..initialize().then((_) {
            if (!mounted) return;
            setState(() {
              _chewieController = ChewieController(
                videoPlayerController: _videoController!,
                autoPlay: true,
                looping: false,
                showControls: true,
                materialProgressColors: ChewieProgressColors(
                  playedColor: IGColors.igPink,
                  handleColor: IGColors.igOrange,
                  backgroundColor:
                      IGColors.textMuted.withOpacity(0.3),
                  bufferedColor:
                      IGColors.textMuted.withOpacity(0.15),
                ),
              );
            });
          }).catchError(
              (_) => _toast('Gagal memutar video', isError: true));
  }

  Future<bool> _ensurePermission() async {
    if (!Platform.isAndroid) return true;
    final v = await Permission.videos.request();
    if (v.isGranted) return true;
    final s = await Permission.storage.request();
    return s.isGranted;
  }

Future<void> _saveVideo() async {
  final media = _result?['media'] as List?;
  if (media == null) return;
  final videoItem = media.cast<Map>().firstWhere(
    (m) => m['type'] == 'mp4',
    orElse: () => {},
  );
  final videoUrl = videoItem['url'] as String?;
  if (videoUrl == null) return;

  setState(() => _saving = true);
  try {
    final ok = await _ensurePermission();
    if (!ok) { _toast('Permission ditolak', isError: true); return; }
    _toast('Mengunduh video...');
    final res = await http.get(Uri.parse(videoUrl));
    if (res.statusCode != 200) {
      _toast('Download gagal (${res.statusCode})', isError: true);
      return;
    }
    final dir  = await getTemporaryDirectory();
    final file = File('${dir.path}/ig_${DateTime.now().millisecondsSinceEpoch}.mp4');
    await file.writeAsBytes(res.bodyBytes);
    await Gal.putVideo(file.path);
    _toast('✅ Video tersimpan ke galeri!');
  } on GalException catch (e) {
    _toast('Gagal simpan: ${e.type.message}', isError: true);
  } catch (e) {
    _toast('Error: $e', isError: true);
  } finally {
    if (mounted) setState(() => _saving = false);
  }
}

Future<void> _saveImage(String imageUrl, String ext) async {
  setState(() => _saving = true);
  try {
    final ok = await _ensurePermission();
    if (!ok) { _toast('Permission ditolak', isError: true); return; }
    _toast('Mengunduh gambar...');
    final res = await http.get(Uri.parse(imageUrl));
    if (res.statusCode != 200) {
      _toast('Download gagal (${res.statusCode})', isError: true);
      return;
    }
    final dir  = await getTemporaryDirectory();
    final file = File('${dir.path}/ig_${DateTime.now().millisecondsSinceEpoch}.$ext');
    await file.writeAsBytes(res.bodyBytes);
    await Gal.putImage(file.path);
    _toast('✅ Gambar tersimpan!');
  } on GalException catch (e) {
    _toast('Gagal simpan: ${e.type.message}', isError: true);
  } catch (e) {
    _toast('Error: $e', isError: true);
  } finally {
    if (mounted) setState(() => _saving = false);
  }
}

Future<void> _saveAllImages() async {
  final media = _result?['media'] as List?;
  if (media == null) return;
  final images = media.cast<Map>().where((m) => m['type'] != 'mp4').toList();
  if (images.isEmpty) return;

  setState(() => _saving = true);
  int saved = 0;
  for (final img in images) {
    try {
      final res = await http.get(Uri.parse(img['url'] as String));
      if (res.statusCode != 200) continue;
      final ext  = img['type'] as String? ?? 'jpg';
      final dir  = await getTemporaryDirectory();
      final file = File('${dir.path}/ig_${DateTime.now().millisecondsSinceEpoch}_$saved.$ext');
      await file.writeAsBytes(res.bodyBytes);
      await Gal.putImage(file.path);
      saved++;
    } catch (_) {}
  }
  if (mounted) setState(() => _saving = false);
  _toast('✅ $saved/${images.length} gambar tersimpan!');
}

  Future<void> _share() async {
    final media = _result?['media'] as List?;
    if (media == null || media.isEmpty) return;
    final first = media.first as Map;
    try {
      _toast('Menyiapkan file...');
      final res = await http.get(Uri.parse(first['url'] as String));
      if (res.statusCode != 200) {
        _toast('Gagal ambil media', isError: true);
        return;
      }
      final dir = await getTemporaryDirectory();
      final ext = first['type'] as String? ?? 'jpg';
      final file = File(
          '${dir.path}/share_${DateTime.now().millisecondsSinceEpoch}.$ext');
      await file.writeAsBytes(res.bodyBytes);
      final title = _result?['title'] as String? ?? 'Instagram Media';
      await Share.shareXFiles([XFile(file.path)], text: '📸 $title');
    } catch (e) {
      _toast('Share error: $e', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: IGColors.bgBase,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: IGColors.white),
        title: _buildAppBarTitle(),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildSearchBox(),
              const SizedBox(height: 12),
              if (_errorMessage != null) _buildErrorBox(),
              const SizedBox(height: 4),
              Expanded(
                child: _result != null
                    ? _buildResultPanel()
                    : _buildEmptyState(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarTitle() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ShaderMask(
          shaderCallback: (bounds) =>
              IGGradient.main.createShader(bounds),
          child: const FaIcon(
            FontAwesomeIcons.instagram,
            size: 22,
            color: IGColors.white,
          ),
        ),
        const SizedBox(width: 10),
        ShaderMask(
          shaderCallback: (bounds) =>
              IGGradient.main.createShader(bounds),
          child: const Text(
            'INSTAGRAM DOWNLOADER',
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 13,
              color: IGColors.white,
              letterSpacing: 1.2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBox() {
    return Container(
      decoration: BoxDecoration(
        color: IGColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: IGColors.border),
        boxShadow: [
          BoxShadow(
            color: IGColors.igPink.withOpacity(0.08),
            blurRadius: 24,
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: _urlController,
            style:
                const TextStyle(color: IGColors.white, fontSize: 14),
            cursorColor: IGColors.igPink,
            onSubmitted: (_) =>
                _isLoading ? null : _downloadInstagram(),
            decoration: InputDecoration(
              hintText: 'tempel url Instagram di sini...',
              hintStyle: const TextStyle(
                  color: IGColors.textMuted, fontSize: 13),
              prefixIcon: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14),
                child: ShaderMask(
                  shaderCallback: (bounds) =>
                      IGGradient.main.createShader(bounds),
                  child: const FaIcon(
                    FontAwesomeIcons.link,
                    size: 16,
                    color: IGColors.white,
                  ),
                ),
              ),
              prefixIconConstraints:
                  const BoxConstraints(minWidth: 44),
              filled: true,
              fillColor: IGColors.bgElevated,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(50),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(
                  vertical: 14, horizontal: 16),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: DecoratedBox(
              decoration: _isLoading
                  ? BoxDecoration(
                      color: IGColors.bgElevated,
                      borderRadius: BorderRadius.circular(50),
                    )
                  : IGGradient.buttonDecoration,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  foregroundColor: IGColors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50)),
                  elevation: 0,
                ),
                onPressed:
                    _isLoading ? null : _downloadInstagram,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _isLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                color: IGColors.white,
                                strokeWidth: 2),
                          )
                        : const FaIcon(
                            FontAwesomeIcons.download,
                            size: 15),
                    const SizedBox(width: 10),
                    Text(
                      _isLoading ? 'MEMPROSES...' : 'DOWNLOAD',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 1.2),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBox() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: IGColors.danger.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: IGColors.danger.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          const FaIcon(FontAwesomeIcons.circleExclamation,
              size: 16, color: IGColors.danger),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_errorMessage!,
                style: const TextStyle(
                    color: IGColors.textSub, fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: IGColors.bgCard,
                boxShadow: [
                  BoxShadow(
                    color: IGColors.igPink
                        .withOpacity(_glowAnim.value * 0.4),
                    blurRadius: 30,
                    spreadRadius: 4,
                  ),
                  BoxShadow(
                    color: IGColors.igPurple
                        .withOpacity(_glowAnim.value * 0.25),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(
                child: ShaderMask(
                  shaderCallback: (bounds) =>
                      IGGradient.main.createShader(bounds),
                  child: const FaIcon(
                    FontAwesomeIcons.instagram,
                    size: 48,
                    color: IGColors.white,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          ShaderMask(
            shaderCallback: (bounds) =>
                IGGradient.main.createShader(bounds),
            child: const Text(
              'Instagram Downloader',
              style: TextStyle(
                color: IGColors.white,
                fontSize: 18,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'tempel url Instagram untuk preview\ndan simpan foto atau video tanpa watermark',
            style:
                TextStyle(color: IGColors.textSub, fontSize: 13),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 8,
            children: const [
              _ChipBadge(
                  icon: FontAwesomeIcons.film, label: 'Reels'),
              _ChipBadge(
                  icon: FontAwesomeIcons.images, label: 'Slide'),
              _ChipBadge(
                  icon: FontAwesomeIcons.image, label: 'Photo'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResultPanel() {
    final r = _result!;
    final title = r['title'] as String? ?? 'No Caption';
    final username = r['username'] as String? ?? '-';
    final likes = r['likes'] as int? ?? 0;
    final comments = r['comment']  as int?    ?? 0;
    final takenAt = r['taken_at'] as int?;
    final thumbnail = r['thumbnail'] as String?;
    final media = (r['media'] as List?)?.cast<Map>() ?? [];
    final commentList =
        (r['comments'] as List?)?.cast<Map>() ?? [];

    final isVideo =
        media.isNotEmpty && media.first['type'] == 'mp4';
    final isCarousel =
        !isVideo && media.length > 1;

    final dateStr = takenAt != null
        ? _formatTs(takenAt)
        : '-';

    return SingleChildScrollView(
      child: Column(
        children: [
          _gradientBorderCard(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) =>
                            IGGradient.main.createShader(bounds),
                        child: FaIcon(
                          isVideo
                              ? FontAwesomeIcons.circlePlay
                              : isCarousel
                                  ? FontAwesomeIcons.images
                                  : FontAwesomeIcons.image,
                          size: 14,
                          color: IGColors.white,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isVideo
                            ? 'VIDEO PREVIEW'
                            : isCarousel
                                ? 'SLIDE  (${media.length} foto)'
                                : 'FOTO PREVIEW',
                        style: const TextStyle(
                          color: IGColors.white,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      if (isCarousel)
                        _igBadge(
                            '${_carouselIndex + 1}/${media.length}'),
                    ],
                  ),
                ),

                if (isVideo) _buildVideoPlayer(thumbnail) else
                  if (isCarousel)
                    _buildCarousel(media)
                  else
                    _buildSingleImage(
                        thumbnail ?? (media.isNotEmpty
                            ? media.first['url'] as String
                            : null)),

                Padding(
                  padding: const EdgeInsets.all(14),
                  child: isVideo
                      ? Row(
                          children: [
                            Expanded(
                              child: _actionButton(
                                icon: _saving
                                    ? FontAwesomeIcons.spinner
                                    : FontAwesomeIcons.floppyDisk,
                                label:
                                    _saving ? 'SAVING...' : 'SIMPAN',
                                isPrimary: false,
                                onTap: _saving ? null : _saveVideo,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _actionButton(
                                icon: FontAwesomeIcons.shareNodes,
                                label: 'SHARE',
                                isPrimary: true,
                                onTap: _share,
                              ),
                            ),
                          ],
                        )
                      : isCarousel
                          ? Column(
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: _actionButton(
                                        icon: _saving
                                            ? FontAwesomeIcons.spinner
                                            : FontAwesomeIcons.image,
                                        label: 'SIMPAN INI',
                                        isPrimary: false,
                                        onTap: _saving
                                            ? null
                                            : () {
                                                final item = media[
                                                    _carouselIndex];
                                                _saveImage(
                                                  item['url'] as String,
                                                  item['type'] as String? ??
                                                      'jpg',
                                                );
                                              },
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: _actionButton(
                                        icon: FontAwesomeIcons.images,
                                        label: 'SIMPAN SEMUA',
                                        isPrimary: true,
                                        onTap: _saving
                                            ? null
                                            : _saveAllImages,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                SizedBox(
                                  width: double.infinity,
                                  child: _actionButton(
                                    icon: FontAwesomeIcons.shareNodes,
                                    label: 'SHARE',
                                    isPrimary: false,
                                    onTap: _share,
                                  ),
                                ),
                              ],
                            )
                          : Row(
                              children: [
                                Expanded(
                                  child: _actionButton(
                                    icon: _saving
                                        ? FontAwesomeIcons.spinner
                                        : FontAwesomeIcons.floppyDisk,
                                    label: _saving
                                        ? 'SAVING...'
                                        : 'SIMPAN',
                                    isPrimary: false,
                                    onTap: _saving
                                        ? null
                                        : () {
                                            if (media.isEmpty) return;
                                            _saveImage(
                                              media.first['url']
                                                  as String,
                                              media.first['type']
                                                      as String? ??
                                                  'jpg',
                                            );
                                          },
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: _actionButton(
                                    icon: FontAwesomeIcons.shareNodes,
                                    label: 'SHARE',
                                    isPrimary: true,
                                    onTap: _share,
                                  ),
                                ),
                              ],
                            ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          _infoCard(children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: IGGradient.main,
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: IGColors.bgElevated,
                    ),
                    child: const Center(
                      child: FaIcon(FontAwesomeIcons.user,
                          size: 18, color: IGColors.textSub),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '@$username',
                        style: const TextStyle(
                          color: IGColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        dateStr,
                        style: const TextStyle(
                          color: IGColors.textMuted,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: IGGradient.main,
                  ),
                  child: const FaIcon(
                    FontAwesomeIcons.instagram,
                    size: 14,
                    color: IGColors.white,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),
            const Divider(color: IGColors.border, height: 1),
            const SizedBox(height: 12),

            if (title.isNotEmpty)
              Text(
                title,
                style: const TextStyle(
                    color: IGColors.textSub,
                    fontSize: 13,
                    height: 1.5),
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
              ),

            const SizedBox(height: 12),

            Row(
              children: [
                _statChip(
                  FontAwesomeIcons.heart,
                  likes >= 0 ? _formatNum(likes) : '—',
                  IGColors.igPink,
                ),
                const SizedBox(width: 12),
                _statChip(
                  FontAwesomeIcons.comment,
                  _formatNum(comments),
                  IGColors.igPurple,
                ),
                const SizedBox(width: 12),
                _statChip(
                  FontAwesomeIcons.images,
                  '${media.length} file',
                  IGColors.igOrange,
                ),
              ],
            ),
          ]),

          if (commentList.isNotEmpty) ...[
            const SizedBox(height: 10),
            _buildComments(commentList),
          ],

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer(String? thumbnail) {
    if (_chewieController != null && _videoController != null) {
      return ClipRRect(
        child: AspectRatio(
          aspectRatio: _videoController!.value.aspectRatio,
          child: Chewie(controller: _chewieController!),
        ),
      );
    }
    return Stack(
      alignment: Alignment.center,
      children: [
        if (thumbnail != null)
          Image.network(
            thumbnail,
            width: double.infinity,
            height: 300,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _mediaFallback(300),
          )
        else
          _mediaFallback(300),
        Container(
          width: double.infinity,
          height: 300,
          color: Colors.black.withOpacity(0.45),
        ),
        const CircularProgressIndicator(
            color: IGColors.igPink, strokeWidth: 2.5),
      ],
    );
  }

  Widget _buildSingleImage(String? imageUrl) {
    if (imageUrl == null) return _mediaFallback(300);
    return Image.network(
      imageUrl,
      width: double.infinity,
      height: 300,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _mediaFallback(300),
    );
  }

  Widget _buildCarousel(List<Map> media) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        SizedBox(
          height: 320,
          child: PageView.builder(
            controller: _pageCtrl,
            itemCount: media.length,
            onPageChanged: (i) =>
                setState(() => _carouselIndex = i),
            itemBuilder: (_, i) {
              final url = media[i]['url'] as String;
              return Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _mediaFallback(320),
              );
            },
          ),
        ),
        Positioned(
          bottom: 10,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(
              media.length,
              (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: i == _carouselIndex ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  gradient: i == _carouselIndex
                      ? IGGradient.main
                      : null,
                  color: i == _carouselIndex
                      ? null
                      : IGColors.white.withOpacity(0.4),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildComments(List<Map> comments) {
    return _infoCard(children: [
      Row(
        children: [
          ShaderMask(
            shaderCallback: (bounds) =>
                IGGradient.main.createShader(bounds),
            child: const FaIcon(
              FontAwesomeIcons.comments,
              size: 13,
              color: IGColors.white,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            'COMMENT',
            style: TextStyle(
              color: IGColors.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 11,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(width: 6),
          _igBadge('${comments.length}'),
        ],
      ),
      const SizedBox(height: 12),
      ...comments.take(5).map((c) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: IGGradient.main,
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(1.5),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: IGColors.bgElevated,
                    ),
                    child: const Center(
                      child: FaIcon(FontAwesomeIcons.user,
                          size: 12, color: IGColors.textMuted),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        '@${c['username'] ?? ''}',
                        style: const TextStyle(
                          color: IGColors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        c['text'] as String? ?? '',
                        style: const TextStyle(
                          color: IGColors.textSub,
                          fontSize: 12,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    ]);
  }

  Widget _gradientBorderCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        gradient: IGGradient.main,
        borderRadius: BorderRadius.circular(18),
      ),
      padding: const EdgeInsets.all(1.5),
      child: Container(
        decoration: BoxDecoration(
          color: IGColors.bgCard,
          borderRadius: BorderRadius.circular(16.5),
        ),
        clipBehavior: Clip.hardEdge,
        child: child,
      ),
    );
  }

  Widget _infoCard({required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: IGColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: IGColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _actionButton({
    required IconData icon,
    required String label,
    required bool isPrimary,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: DecoratedBox(
        decoration: isPrimary
            ? IGGradient.buttonDecoration
            : BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                border: Border.all(color: IGColors.igPink),
              ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 13),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              isPrimary
                  ? FaIcon(icon,
                      size: 14, color: IGColors.white)
                  : ShaderMask(
                      shaderCallback: (bounds) =>
                          IGGradient.main.createShader(bounds),
                      child: FaIcon(icon,
                          size: 14, color: IGColors.white),
                    ),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: isPrimary
                      ? IGColors.white
                      : IGColors.igPink,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statChip(IconData icon, String val, Color color) {
    return Row(
      children: [
        FaIcon(icon, size: 13, color: color),
        const SizedBox(width: 5),
        Text(
          val,
          style: TextStyle(
              color: color,
              fontSize: 13,
              fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _igBadge(String text) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        gradient: IGGradient.main,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(
            color: IGColors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _mediaFallback(double height) {
    return Container(
      width: double.infinity,
      height: height,
      color: IGColors.bgElevated,
      child: Center(
        child: ShaderMask(
          shaderCallback: (bounds) =>
              IGGradient.main.createShader(bounds),
          child: const FaIcon(
            FontAwesomeIcons.image,
            size: 48,
            color: IGColors.white,
          ),
        ),
      ),
    );
  }

  String _formatTs(int ts) {
    final dt =
        DateTime.fromMillisecondsSinceEpoch(ts * 1000);
    return '${dt.day}/${dt.month}/${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  String _formatNum(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

class _ChipBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  const _ChipBadge({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: IGColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: IGColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          ShaderMask(
            shaderCallback: (bounds) =>
                IGGradient.main.createShader(bounds),
            child: FaIcon(icon,
                size: 12, color: IGColors.white),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
                color: IGColors.textSub, fontSize: 12),
          ),
        ],
      ),
    );
  }
}