import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'ai.dart';
import 'nik.dart';
import 'mbuh.dart';
import 'domain.dart';
import 'youtube_player_page.dart';
import 'ig.dart';
import 'tiktok.dart';
import 'tele.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;

  const ToolsPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  final Color primaryDark = const Color(0xFF000000);
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color cardDarker = const Color(0xFF0D0D0D);
  final Color goldColor = const Color(0xFFFF1744);
  final Color blueColor = const Color(0xFF4A9EFF);

  late AnimationController _headerController;
  late AnimationController _listController;
  late Animation<double> _headerAnimation;
  late List<Animation<double>> _itemAnimations;

  final List<Map<String, dynamic>> tools = [
   {'icon': FontAwesomeIcons.youtube, 'label': 'Youtube Downloader', 'description': 'Nonton YouTube'},
    {'icon': FontAwesomeIcons.telegram, 'label': 'Telegram Report', 'description': 'Spam Report'},
    {'icon': FontAwesomeIcons.paperPlane, 'label': 'Spam NGL', 'description': 'Spam pesan ke NGL'},
    {'icon': Icons.chat_bubble_rounded, 'label': 'Chat AI', 'description': 'AI Private'},
    {'icon': Icons.badge_rounded, 'label': 'NIK Check', 'description': 'Check ID'},
    {'icon': Icons.phone_android_rounded, 'label': 'Phone Lookup', 'description': 'Lookup number'},
    {'icon': Icons.language_rounded, 'label': 'Subdomain', 'description': 'subdomains'},
    {'icon': FontAwesomeIcons.instagram, 'label': 'IG Downloader', 'description': 'Download reels'},
    {'icon': FontAwesomeIcons.tiktok, 'label': 'TikTok Downloader', 'description': 'Download video'},
  ];

  @override
  void initState() {
    super.initState();

    _headerController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _listController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _headerAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutBack),
    );

    _itemAnimations = List.generate(
      tools.length,
      (index) => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(index * 0.07, 1, curve: Curves.easeOut),
        ),
      ),
    );

    _headerController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _listController.forward();
    });
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final safeOpacity = _headerAnimation.value.clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: primaryDark,
        elevation: 0,
        leading: const BackButton(color: Colors.white),
        title: const Text(
          "Digital Tools",
          style: TextStyle(color: Colors.white, fontFamily: 'Orbitron'),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Container(color: primaryDark),

          Positioned.fill(
            child: AnimatedBuilder(
              animation: _headerController,
              builder: (_, __) => Opacity(
                opacity: safeOpacity * 0.05,
                child: CustomPaint(
                  painter: GridPatternPainter(color: goldColor),
                ),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                const SizedBox(height: 20),
                Expanded(child: _buildList()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: _headerAnimation,
      builder: (_, __) {
        final v = _headerAnimation.value.clamp(0.0, 1.0);

        return Transform.translate(
          offset: Offset(0, (1 - v) * 30),
          child: Opacity(
            opacity: v,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: cardDarker,
                border: Border.all(color: goldColor.withOpacity(.2)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: goldColor.withOpacity(.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.grid_view_rounded, color: goldColor),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Digital Tools",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Select a tool to begin",
                    style: TextStyle(color: blueColor.withOpacity(.8)),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: tools.length,
      itemBuilder: (context, i) {
        final tool = tools[i];

        return _buildItem(
          icon: tool['icon'],
          label: tool['label'],
          description: tool['description'],
          animation: _itemAnimations[i],
          onTap: () => _navigate(tool['label']),
        );
      },
    );
  }

  Widget _buildItem({
    required IconData icon,
    required String label,
    required String description,
    required Animation<double> animation,
    required VoidCallback onTap,
  }) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        final v = animation.value.clamp(0.0, 1.0);

        return Transform.translate(
          offset: Offset((1 - v) * 40, 0),
          child: Opacity(
            opacity: v,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: _InteractiveToolItem(
                icon: icon,
                label: label,
                description: description,
                onTap: onTap,
                primaryColor: goldColor,
                cardColor: cardDark,
              ),
            ),
          ),
        );
      },
    );
  }

  void _navigate(String name) {
    Widget page;

    switch (name) {
      case 'Youtube Downloader':
        page = YoutubePlayerPage();
        break;
      case 'Telegram Report':
        page = TelegramSpamPage(sessionKey: widget.sessionKey);
        break;
      case 'Spam NGL':
        page = NglPage();
        break;
      case 'Chat AI':
        page = AIPage(username: widget.username, sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage();
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage();
        break;
      case 'Subdomain Finder':
        page = SubdomainPage();
        break;
      case 'IG Downloader':
        page = InstagramDownloaderPage();
        break;
      case 'TikTok Downloader':
        page = TiktokDownloaderPage();
        break;
      default:
        return;
    }

    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}

class _InteractiveToolItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final VoidCallback onTap;
  final Color primaryColor;
  final Color cardColor;

  const _InteractiveToolItem({
    required this.icon,
    required this.label,
    required this.description,
    required this.onTap,
    required this.primaryColor,
    required this.cardColor,
  });

  @override
  State<_InteractiveToolItem> createState() => _InteractiveToolItemState();
}

class _InteractiveToolItemState extends State<_InteractiveToolItem>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> scale;
  bool pressed = false;

  @override
  void initState() {
    super.initState();
    controller =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    scale = Tween(begin: 1.0, end: .96).animate(controller);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        pressed = true;
        controller.forward();
        setState(() {});
      },
      onTapUp: (_) {
        pressed = false;
        controller.reverse();
        widget.onTap();
        setState(() {});
      },
      onTapCancel: () {
        pressed = false;
        controller.reverse();
        setState(() {});
      },
      child: AnimatedBuilder(
        animation: controller,
        builder: (_, __) => Transform.scale(
          scale: scale.value,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: widget.cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: widget.primaryColor.withOpacity(pressed ? .6 : .2),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: widget.primaryColor.withOpacity(.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(widget.icon, color: widget.primaryColor),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.label,
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold)),
                      Text(widget.description,
                          style: const TextStyle(color: Colors.white60)),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right,
                    color: widget.primaryColor.withOpacity(.5))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GridPatternPainter extends CustomPainter {
  final Color color;

  GridPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = .5;

    const gap = 30.0;

    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}