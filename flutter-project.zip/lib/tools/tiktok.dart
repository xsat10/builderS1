import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:chewie/chewie.dart';
import 'package:video_player/video_player.dart';

class TikTokColors {
  static const Color bgBase = Color(0xFF010101);
  static const Color bgCard = Color(0xFF161616);
  static const Color bgElevated = Color(0xFF1F1F1F);
  static const Color pink = Color(0xFFFF0050);
  static const Color cyan = Color(0xFF00F2EA);
  static const Color white = Color(0xFFFFFFFF);
  static const Color textSub = Color(0xFFAAAAAA);
  static const Color textMuted = Color(0xFF555555);
  static const Color danger = Color(0xFFFF3B30);
  static const Color border = Color(0xFF2A2A2A);
}

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _urlController = TextEditingController();

  bool _isLoading = false;
  bool _saving = false;
  Map<String, dynamic>? _result;
  String? _errorMessage;

  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  late AnimationController _glowCtrl;
  late Animation<double>  _glowAnim;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  void _toast(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: TikTokColors.white)),
        backgroundColor: isError ? TikTokColors.danger : TikTokColors.bgElevated,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() => _errorMessage = "url gak boleh kosong");
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
    });

    _videoController?.dispose();
    _chewieController?.dispose();
    _videoController = null;
    _chewieController = null;

    final apiUrl = Uri.parse(
      "https://api.nexray.eu.cc/downloader/tiktok?url=${Uri.encodeComponent(url)}",
    );

    try {
      final res = await http.get(apiUrl).timeout(const Duration(seconds: 20));

      if (res.statusCode != 200) {
        setState(() => _errorMessage = "Error (${res.statusCode}).");
        return;
      }

      final json = jsonDecode(res.body);
      if (json is Map && json['status'] == true && json['result'] != null) {
        final data = Map<String, dynamic>.from(json['result']);
        setState(() => _result = data);
        _initVideo(data['data']);
      } else {
        setState(() => _errorMessage = "gagal mengambil data. cek url dan coba lagi");
      }
    } catch (e) {
      setState(() => _errorMessage = "Error: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _initVideo(String? videoUrl) {
    if (videoUrl == null || videoUrl.isEmpty) return;

    _videoController = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            looping: false,
            showControls: true,
            materialProgressColors: ChewieProgressColors(
              playedColor: TikTokColors.pink,
              handleColor: TikTokColors.cyan,
              backgroundColor: TikTokColors.textMuted.withOpacity(0.3),
              bufferedColor: TikTokColors.textMuted.withOpacity(0.15),
            ),
          );
        });
      }).catchError((_) => _toast("Gagal memutar video", isError: true));
  }

  Future<bool> _ensurePermission() async {
    if (!Platform.isAndroid) return true;
    final v = await Permission.videos.request();
    if (v.isGranted) return true;
    final s = await Permission.storage.request();
    return s.isGranted;
  }

Future<void> _saveToGallery() async {
  final videoUrl = _result?['data'] as String?;
  if (videoUrl == null || videoUrl.isEmpty) return;

  setState(() => _saving = true);
  try {
    final ok = await _ensurePermission();
    if (!ok) {
      _toast("Permission ditolak", isError: true);
      return;
    }

    _toast("Mengunduh video...");
    final res = await http.get(Uri.parse(videoUrl));
    if (res.statusCode != 200) {
      _toast("Download gagal (${res.statusCode})", isError: true);
      return;
    }

    final dir  = await getTemporaryDirectory();
    final file = File('${dir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4');
    await file.writeAsBytes(res.bodyBytes);

    await Gal.putVideo(file.path);
    _toast("✅ Tersimpan ke galeri!");
  } on GalException catch (e) {
    _toast("Gagal simpan: ${e.type.message}", isError: true);
  } catch (e) {
    _toast("Error: $e", isError: true);
  } finally {
    if (mounted) setState(() => _saving = false);
  }
}
  Future<void> _shareVideo() async {
    final videoUrl = _result?['data'] as String?;
    if (videoUrl == null || videoUrl.isEmpty) return;
    
    try {
      _toast("Menyiapkan file...");
      final res = await http.get(Uri.parse(videoUrl));
      if (res.statusCode != 200) {
        _toast("Gagal ambil video.", isError: true);
        return;
      }
      
      final dir  = await getTemporaryDirectory();
      final file = File('${dir.path}/share_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(res.bodyBytes);
      final title = _result?['title'] ?? 'TikTok Video';
      await Share.shareXFiles([XFile(file.path)], text: "🎵 $title");
    } catch (e) {
      _toast("Share error: $e", isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TikTokColors.bgBase,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: TikTokColors.white),
        title: _buildAppBarTitle(),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildSearchBox(),
              const SizedBox(height: 12),
              if (_errorMessage != null) _buildErrorBox(),
              const SizedBox(height: 4),
              Expanded(
                child: _result != null
                    ? _buildResultPanel()
                    : _buildEmptyState(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBarTitle() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          children: [
            const FaIcon(FontAwesomeIcons.tiktok,
                size: 20, color: TikTokColors.cyan),
            Transform.translate(
              offset: const Offset(2, 1),
              child: const FaIcon(FontAwesomeIcons.tiktok,
                  size: 20, color: TikTokColors.pink),
            ),
            const FaIcon(FontAwesomeIcons.tiktok,
                size: 20, color: TikTokColors.white),
          ],
        ),
        const SizedBox(width: 10),
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [TikTokColors.cyan, TikTokColors.white, TikTokColors.pink],
          ).createShader(bounds),
          child: const Text(
            "TIKTOK DOWNLOADER",
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: TikTokColors.white,
              letterSpacing: 1.2,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBox() {
    return Container(
      decoration: BoxDecoration(
        color: TikTokColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: TikTokColors.border),
        boxShadow: [
          BoxShadow(
            color: TikTokColors.pink.withOpacity(0.08),
            blurRadius: 24,
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: _urlController,
            style: const TextStyle(color: TikTokColors.white, fontSize: 14),
            cursorColor: TikTokColors.pink,
            onSubmitted: (_) => _isLoading ? null : _downloadTiktok(),
            decoration: InputDecoration(
              hintText: 'tempel url tiktok di sini...',
              hintStyle: const TextStyle(color: TikTokColors.textMuted, fontSize: 13),
              prefixIcon: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 14),
                child: FaIcon(FontAwesomeIcons.link,
                    size: 16, color: TikTokColors.pink),
              ),
              prefixIconConstraints: const BoxConstraints(minWidth: 44),
              filled: true,
              fillColor: TikTokColors.bgElevated,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(50),
                borderSide: BorderSide.none,
              ),
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: TikTokColors.pink,
                foregroundColor: TikTokColors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50)),
                elevation: 0,
              ),
              onPressed: _isLoading ? null : _downloadTiktok,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _isLoading
                      ? const SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(
                              color: TikTokColors.white, strokeWidth: 2),
                        )
                      : const FaIcon(FontAwesomeIcons.download, size: 16),
                  const SizedBox(width: 10),
                  Text(
                    _isLoading ? "MEMPROSES..." : "DOWNLOAD",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        letterSpacing: 1.2),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBox() {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: TikTokColors.danger.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: TikTokColors.danger.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          const FaIcon(FontAwesomeIcons.circleExclamation,
              size: 16, color: TikTokColors.danger),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_errorMessage!,
                style: const TextStyle(
                    color: TikTokColors.textSub, fontSize: 13)),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              width: 96, height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: TikTokColors.bgCard,
                boxShadow: [
                  BoxShadow(
                    color: TikTokColors.pink.withOpacity(_glowAnim.value * 0.35),
                    blurRadius: 28,
                    spreadRadius: 4,
                  ),
                  BoxShadow(
                    color: TikTokColors.cyan.withOpacity(_glowAnim.value * 0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  FaIcon(FontAwesomeIcons.tiktok,
                      size: 40, color: TikTokColors.cyan.withOpacity(0.4)),
                  Transform.translate(
                    offset: const Offset(2.5, 1.5),
                    child: FaIcon(FontAwesomeIcons.tiktok,
                        size: 40, color: TikTokColors.pink.withOpacity(0.4)),
                  ),
                  const FaIcon(FontAwesomeIcons.tiktok,
                      size: 40, color: TikTokColors.white),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "TikTok Downloader",
            style: TextStyle(
              color: TikTokColors.white,
              fontSize: 18,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "tempel url tiktok untuk preview\ndan simpan tanpa watermark",
            style: TextStyle(color: TikTokColors.textSub, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildResultPanel() {
    final r = _result!;
    final title = r['title'] as String? ?? 'No Title';
    final cover = r['cover'] as String?;
    final duration = r['duration'] as String? ?? '-';
    final region = r['region'] as String? ?? '-';
    final takenAt = r['taken_at'] as String? ?? '-';
    final author = r['author'] as Map?;
    final authorName = author?['fullname'] as String? ?? '-';
    final authorNick = author?['nickname'] as String? ?? '';
    final authorAvt = author?['avatar'] as String?;
    final stats = r['stats'] as Map?;
    final music = r['music_info'] as Map?;

    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: TikTokColors.bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: TikTokColors.border),
              boxShadow: [
                BoxShadow(
                  color: TikTokColors.pink.withOpacity(0.15),
                  blurRadius: 24,
                ),
              ],
            ),
            clipBehavior: Clip.hardEdge,
            child: Column(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      const FaIcon(FontAwesomeIcons.circlePlay,
                          size: 14, color: TikTokColors.pink),
                      const SizedBox(width: 8),
                      const Text(
                        "VIDEO PREVIEW",
                        style: TextStyle(
                          color: TikTokColors.white,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: TikTokColors.pink.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: TikTokColors.pink.withOpacity(0.4)),
                        ),
                        child: Row(
                          children: [
                            const FaIcon(FontAwesomeIcons.clock,
                                size: 10, color: TikTokColors.pink),
                            const SizedBox(width: 4),
                            Text(duration,
                                style: const TextStyle(
                                    color: TikTokColors.pink,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                _chewieController != null && _videoController != null
                    ? ClipRRect(
                        child: AspectRatio(
                          aspectRatio: _videoController!.value.aspectRatio,
                          child: Chewie(controller: _chewieController!),
                        ),
                      )
                    : Stack(
                        alignment: Alignment.center,
                        children: [
                          if (cover != null)
                            Image.network(
                              cover,
                              width: double.infinity,
                              height: 280,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  _coverFallback(280),
                            )
                          else
                            _coverFallback(280),
                          Container(
                            width: double.infinity,
                            height: 280,
                            color: Colors.black.withOpacity(0.4),
                          ),
                          const CircularProgressIndicator(
                              color: TikTokColors.pink, strokeWidth: 2.5),
                        ],
                      ),

                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Expanded(
                        child: _actionButton(
                          icon: _saving
                              ? FontAwesomeIcons.spinner
                              : FontAwesomeIcons.floppyDisk,
                          label: _saving ? "SAVING..." : "SIMPAN",
                          isPrimary: false,
                          onTap: _saving ? null : _saveToGallery,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionButton(
                          icon: FontAwesomeIcons.shareNodes,
                          label: "SHARE",
                          isPrimary: true,
                          onTap: _shareVideo,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          _infoCard(children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  backgroundColor: TikTokColors.bgElevated,
                  backgroundImage:
                      authorAvt != null ? NetworkImage(authorAvt) : null,
                  child: authorAvt == null
                      ? const FaIcon(FontAwesomeIcons.user,
                          size: 18, color: TikTokColors.textSub)
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(authorNick,
                          style: const TextStyle(
                              color: TikTokColors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14)),
                      Text("@$authorName",
                          style: const TextStyle(
                              color: TikTokColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: TikTokColors.bgElevated,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: TikTokColors.border),
                  ),
                  child: Row(
                    children: [
                      const FaIcon(FontAwesomeIcons.earthAsia,
                          size: 11, color: TikTokColors.cyan),
                      const SizedBox(width: 5),
                      Text(region,
                          style: const TextStyle(
                              color: TikTokColors.cyan,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),
            const Divider(color: TikTokColors.border, height: 1),
            const SizedBox(height: 12),

            Text(
              title,
              style: const TextStyle(
                  color: TikTokColors.textSub,
                  fontSize: 13,
                  height: 1.5),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                const FaIcon(FontAwesomeIcons.calendar,
                    size: 11, color: TikTokColors.textMuted),
                const SizedBox(width: 6),
                Text(takenAt,
                    style: const TextStyle(
                        color: TikTokColors.textMuted, fontSize: 12)),
              ],
            ),
          ]),

          const SizedBox(height: 10),

          if (stats != null) _buildStats(stats),

          const SizedBox(height: 10),

          if (music != null) _buildMusicInfo(music),

          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildStats(Map stats) {
    return _infoCard(children: [
      Row(
        children: [
          const FaIcon(FontAwesomeIcons.chartBar,
              size: 13, color: TikTokColors.pink),
          const SizedBox(width: 8),
          const Text("STATISTIK",
              style: TextStyle(
                  color: TikTokColors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  letterSpacing: 0.8)),
        ],
      ),
      const SizedBox(height: 14),
      Row(
        children: [
          _statItem(FontAwesomeIcons.eye,      stats['views']    ?? '-', TikTokColors.white),
          _statItem(FontAwesomeIcons.heart,     stats['likes']    ?? '-', TikTokColors.pink),
          _statItem(FontAwesomeIcons.comment,   stats['comment']  ?? '-', TikTokColors.cyan),
          _statItem(FontAwesomeIcons.shareNodes, stats['share']   ?? '-', const Color(0xFFFFD700)),
          _statItem(FontAwesomeIcons.bookmark,  stats['save']     ?? '-', const Color(0xFF9B59B6)),
        ],
      ),
    ]);
  }

  Widget _statItem(IconData icon, String val, Color color) {
    return Expanded(
      child: Column(
        children: [
          FaIcon(icon, size: 16, color: color),
          const SizedBox(height: 5),
          Text(val,
              style: TextStyle(
                  color: color,
                  fontSize: 12,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildMusicInfo(Map music) {
    final musicTitle  = music['title']  as String? ?? '-';
    final musicAuthor = music['author'] as String? ?? '-';
    final musicDur    = music['duration'] as String? ?? '-';
    final isCopyright = (music['copyright'] as String?) == 'Yes';

    return _infoCard(children: [
      Row(
        children: [
          const FaIcon(FontAwesomeIcons.music,
              size: 13, color: TikTokColors.cyan),
          const SizedBox(width: 8),
          const Text("MUSIK",
              style: TextStyle(
                  color: TikTokColors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  letterSpacing: 0.8)),
          const Spacer(),
          if (isCopyright)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0xFFFFD700).withOpacity(0.12),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                    color: const Color(0xFFFFD700).withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  FaIcon(FontAwesomeIcons.copyright,
                      size: 10, color: Color(0xFFFFD700)),
                  SizedBox(width: 4),
                  Text("Copyright",
                      style: TextStyle(
                          color: Color(0xFFFFD700), fontSize: 10)),
                ],
              ),
            ),
        ],
      ),
      const SizedBox(height: 12),
      Row(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: TikTokColors.bgElevated,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: TikTokColors.cyan.withOpacity(0.3)),
            ),
            child: const Center(
              child: FaIcon(FontAwesomeIcons.compactDisc,
                  size: 20, color: TikTokColors.cyan),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(musicTitle,
                    style: const TextStyle(
                        color: TikTokColors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(musicAuthor,
                    style: const TextStyle(
                        color: TikTokColors.textSub, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: TikTokColors.bgElevated,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const FaIcon(FontAwesomeIcons.clock,
                    size: 10, color: TikTokColors.textMuted),
                const SizedBox(width: 5),
                Text(musicDur,
                    style: const TextStyle(
                        color: TikTokColors.textMuted, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    ]);
  }

  Widget _infoCard({required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: TikTokColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: TikTokColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }

  Widget _actionButton({
    required IconData icon,
    required String label,
    required bool isPrimary,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          color: isPrimary ? TikTokColors.pink : Colors.transparent,
          borderRadius: BorderRadius.circular(50),
          border: isPrimary
              ? null
              : Border.all(color: TikTokColors.pink),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon,
                size: 14,
                color: isPrimary ? TikTokColors.white : TikTokColors.pink),
            const SizedBox(width: 8),
            Text(label,
                style: TextStyle(
                  color: isPrimary ? TikTokColors.white : TikTokColors.pink,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 0.8,
                )),
          ],
        ),
      ),
    );
  }

  Widget _coverFallback(double height) {
    return Container(
      width: double.infinity,
      height: height,
      color: TikTokColors.bgElevated,
      child: const Center(
        child: FaIcon(FontAwesomeIcons.film,
            size: 48, color: TikTokColors.textMuted),
      ),
    );
  }
}