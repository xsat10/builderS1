import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_glass_overlay.dart';

class NeoResetPasswordDialog extends StatefulWidget {
  final String title;
  final Color accent;
  final String username;
  final Future<Map<String, dynamic>> Function(String newPassword) onReset;

  const NeoResetPasswordDialog({
    super.key,
    required this.title,
    required this.accent,
    required this.username,
    required this.onReset,
  });

  @override
  State<NeoResetPasswordDialog> createState() => _NeoResetPasswordDialogState();
}

class _NeoResetPasswordDialogState extends State<NeoResetPasswordDialog> {
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscure = true;
  bool _saving = false;
  String? _error;

  @override
  void dispose() {
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final password = _passCtrl.text;
    final confirm = _confirmCtrl.text;
    if (password.length < 6) {
      setState(() => _error = 'Password minimal 6 karakter.');
      return;
    }
    if (password != confirm) {
      setState(() => _error = 'Konfirmasi password tidak sama.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    final result = await widget.onReset(password);
    if (!mounted) return;
    if (result['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _saving = false;
        _error = result['error']?['message'] ?? 'Gagal reset password.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.title,
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: NeoColors.primaryText),
              ),
              const SizedBox(height: 12),
              Text(
                'Reset password untuk "${widget.username}"?',
                style: TextStyle(
                  fontSize: 13,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
              const SizedBox(height: NeoSpacing.md),
              TextField(
                controller: _passCtrl,
                obscureText: _obscure,
                decoration: InputDecoration(
                  labelText: 'Password baru',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscure
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                    ),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
              ),
              const SizedBox(height: NeoSpacing.sm),
              TextField(
                controller: _confirmCtrl,
                obscureText: _obscure,
                decoration: const InputDecoration(
                  labelText: 'Konfirmasi password',
                  border: OutlineInputBorder(),
                ),
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submit(),
              ),
              if (_error != null) ...[
                const SizedBox(height: NeoSpacing.sm),
                Text(
                  _error!,
                  style: const TextStyle(
                    color: NeoColors.pink,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  NeoButton(
                    label: 'CANCEL',
                    bgColor: NeoColors.surfaceElevated,
                    textColor: NeoColors.primaryText,
                    height: 40,
                    fontSize: 14,
                    onPressed: _saving ? null : () => Navigator.of(context).pop(false),
                  ),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'RESET',
                    bgColor: widget.accent,
                    textColor: NeoColors.white,
                    height: 40,
                    fontSize: 14,
                    loading: _saving,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
