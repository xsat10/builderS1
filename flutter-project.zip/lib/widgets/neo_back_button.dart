import 'package:flutter/material.dart';
import '../theme.dart';

class NeoBackButton extends StatelessWidget {
  final VoidCallback? onTap;

  const NeoBackButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(NeoSpacing.sm),
        decoration: BoxDecoration(
          color: isDark ? NeoColors.surface : NeoColors.white,
          border: Border.all(color: isDark ? NeoColors.line : NeoColors.border, width: NeoTheme.borderWidth),
          borderRadius: BorderRadius.circular(NeoRadius.md),
          boxShadow: NeoShadows.smD(isDark),
        ),
        child: Icon(Icons.arrow_back, size: 20, color: Theme.of(context).colorScheme.primary),
      ),
    );
  }
}
