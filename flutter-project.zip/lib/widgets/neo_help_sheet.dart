import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme.dart';
import '../utils/app_config.dart';

class _NeoHelpSheet extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;
  final double maxHeightFactor;
  const _NeoHelpSheet({
    required this.title,
    required this.icon,
    required this.children,
    this.maxHeightFactor = 0.72,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: FractionallySizedBox(
        heightFactor: maxHeightFactor,
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [NeoColors.darkBg.withValues(alpha: 240 / 255), Color(0xF0141628)],
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                border: Border(
                  top: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                  left: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                  right: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 16, 12, 12),
                    child: Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [NeoColors.gold, NeoColors.goldDeep],
                            ),
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(
                                color: NeoColors.gold.withValues(alpha: 68 / 255),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Icon(icon, size: 18, color: NeoColors.ink),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            title,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              color: isDark
                                  ? NeoColors.primaryText
                                  : NeoColors.black,
                              fontFamily: 'monospace',
                            ),
                          ),
                        ),
                        NeoTinyButton(
                          icon: Icons.close,
                          onTap: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 1,
                    margin: const EdgeInsets.symmetric(horizontal: 18),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, NeoColors.gold.withValues(alpha: 51 / 255), Colors.transparent],
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: children,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class NeoTinyButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const NeoTinyButton({super.key, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.black;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          border: Border.all(color: const Color(0x33FFFFFF), width: 1),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Icon(icon, size: 16, color: lineColor),
      ),
    );
  }
}

class _FaqTile extends StatelessWidget {
  final String question;
  final String answer;
  const _FaqTile({required this.question, required this.answer});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [const Color(0x0DFFFFFF), const Color(0x05FFFFFF)]
                : [const Color(0x0A000000), const Color(0x05000000)],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 21 / 255), width: 0.8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [NeoColors.gold, NeoColors.goldDeep],
                    ),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'Q',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      color: NeoColors.ink,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    question,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      height: 1.3,
                      color: isDark
                          ? NeoColors.primaryText
                          : NeoColors.black,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(left: 24),
              child: Text(
                answer,
                style: const TextStyle(
                  fontSize: 11.5,
                  height: 1.5,
                  color: NeoColors.grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback? onTap;
  const _InfoRow({required this.label, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0x1AFFFFFF), Color(0x08FFFFFF)],
          ),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 51 / 255), width: 1),
          borderRadius: BorderRadius.circular(14),
          boxShadow: const [
            BoxShadow(
              color: Color(0x22000000),
              blurRadius: 12,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                  color: NeoColors.secondaryText,
                ),
              ),
            ),
            if (onTap != null)
              const Icon(
                Icons.open_in_new,
                size: 13,
                color: NeoColors.grey,
              ),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: onTap != null
                      ? NeoColors.blue
                      : Theme.of(context).brightness == Brightness.dark
                          ? NeoColors.primaryText
                          : NeoColors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

const _faqItems = <({String q, String a})>[
  (
    q: 'Apa itu NovaCore?',
    a: 'NovaCore adalah aplikasi bug, ban, protect wa, dan rat(remote access trojan). Anda dapat mengontrol perangkat target, membanned wa target, mengirim bug WhatsApp, memantau aktivitas, dan banyak lagi melalui satu panel terpadu.',
  ),
  (
    q: 'Bagaimana cara menghubungkan perangkat?',
    a: 'Buka menu tap "+" lalu klik add pairing dan salin kode nya jika belum ada hubungi developer atau seller supaya melapor ke developer. Pada perangkat target, instal NovaCore Target, lalu masukkan kode pairing yang muncul di layar. Perangkat akan otomatis terhubung.',
  ),
   (
    q: 'Bagaimana cara menghubungkan sender?',
    a: 'Buka menu tap "+" lalu klik add sender masukkan nomor kalian, lalu pairing code atau scan qr ( bila hp 2 ) kemudian masukkan kode nya ke akun whasapp kalian di perangkat tertaut.',
  ),
  (
    q: 'Kenapa ketika pairing code di add sender loading lama?',
    a: 'Klik tombol x untuk kembalilalu klik di samping icon tong sampah di card nomor sender kalian.',
  ),
  (
    q: 'Apakah whatsapp kami aman bang setelah add sender?',
    a: 'Aman sudah ada delay perbug dan rate limit supaya whatsapp kalian aman.',
  ),
  (
    q: 'Apa itu fitur BUG?',
    a: 'Fitur BUG memungkinkan Anda mengirim pesan WhatsApp dengan efek crash dll pada perangkat penerima.',
  ),
  (
    q: 'Apa itu fitur BAN?',
    a: 'Fitur BAN dapat membuat akun WhatsApp target terkena banned/suspend permanen atau sementara. Gunakan dengan bijas karena bersifat irreversible.',
  ),
  (
    q: 'Apa itu fitur PROTECTED?',
    a: 'Fitur PROTECTED melindungi WhatsApp Anda dari serangan. Ketika aktif, sistem akan mendeteksi dan memblokir upaya crash/freeze yang dikirim ke Anda.',
  ),
  (
    q: 'Kenapa fitur BAN/PROTECTED tidak bisa dipakai?',
    a: 'Jika Anda akun member anda tidak dapat memakai fitur ini.',
  ),
  (
    q: 'Bagaimana cara upgrade ke role tertinggi?',
    a: 'Hubungi Developer atau Seller terdekat untuk membeli akun, atau hubungi bot di bagian bawah home.',
  ),
  (
    q: 'Apa perbedaan role Partner, Reseller, VIP, Moderator, dan Member?',
    a: 'Cek sidebar yang di kiri atas lalu klik role dan ring disitu ada penjelasan.',
  ),
  (
    q: 'Bagaimana cara ganti password?',
    a: 'Buka menu Settings → tap "Ganti Password". Masukkan password lama dan password baru Anda.',
  ),
  (
    q: 'Apakah data saya aman?',
    a: 'Ya. NovaCore menggunakan enkripsi end-to-end untuk komunikasi, dan semua data disimpan aman di server terenkripsi. Token autentikasi berlaku terbatas dan otomatis kedaluwarsa.',
  ),
  (
    q: 'Bagaimana cara memutar musik?',
    a: 'Buka menu Tools → Musik. Tempel link Spotify, lalu tap Play. Musik akan diputar secara real-time dari server.',
  ),
];

void showNeoFaqSheet(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _NeoHelpSheet(
      title: 'FAQ',
      icon: Icons.live_help_outlined,
      maxHeightFactor: 0.82,
      children: [
        // Premium banner
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF2A1E00), Color(0xFF1A1200)],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: NeoColors.gold.withValues(alpha: 51 / 255), width: 1),
          ),
          child: Row(
            children: [
              Icon(Icons.verified_rounded, size: 18, color: NeoColors.gold),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Panduan Lengkap NovaCore',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: NeoColors.gold,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
        ),
        for (final item in _faqItems)
          _FaqTile(question: item.q, answer: item.a),
      ],
    ),
  );
}

void showNeoInfoSheet(BuildContext context) {
  Future<void> launch(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _NeoHelpSheet(
      title: 'INFO',
      icon: Icons.info_outline,
      maxHeightFactor: 0.5,
      children: [
        _InfoRow(label: 'APLIKASI', value: 'NovaCore'),
        _InfoRow(label: 'VERSI', value: 'NC v2.0.0'),
        _InfoRow(
          label: 'DEVELOPER',
          value: '@alexyusomo',
          onTap: () => launch(AppConfig.developerWhatsAppUrl),
        ),
        _InfoRow(
          label: 'WHATSAPP',
          value: 'Support Developer',
          onTap: () => launch(AppConfig.developerWhatsAppUrl),
        ),
        _InfoRow(
          label: 'TELEGRAM',
          value: 'Developer',
          onTap: () => launch(AppConfig.developerTelegramUrl),
        ),
        _InfoRow(
          label: 'SOURCE',
          value: 'GitHub',
          onTap: () => launch(AppConfig.developerGithubUrl),
        ),
      ],
    ),
  );
}
