import 'package:flutter/material.dart';

/// Dynamic clearance for screens that sit behind the floating bottom nav.
/// Menghitung jarak bawah (bottom padding) scrollable content agar elemen
/// terakhir tetap terlihat penuh di atas floating navbar.
class ScrollClearance {
  /// Tinggi floating bottom navbar (harus sinkron dgn NeoBottomNav._barHeight).
  static const double navBarHeight = 75;

  /// Jarak aman antara content dan navbar.
  static const double navGap = 24;

  /// Bottom padding total: tinggi navbar + SafeArea/system inset + gap.
  static double bottomNav(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    return navBarHeight + bottom + navGap;
  }
}
