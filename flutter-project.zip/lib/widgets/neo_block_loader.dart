import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';

/// NeoBlockLoader — loader premium bertema Romawi (Liquid Gold / laurel).
///
/// Satu-satunya loader yang dipakai seluruh app agar seragam:
/// - cincin emas berputar (busur laurel),
/// - tiga ❦ (laurel) mengorbit berlawanan arah,
/// - medali emas di tengah + label SPQR (Cinzel) opsional di bawahnya.
///
/// `blockSize`, `c0`, `c1` tetap diterima agar pemanggilan lama tidak rusak;
/// visualnya kini seragam tema Romawi. Gunakan `compact: true` untuk varian
/// kecil (ring saja) di dalam tombol/area sempit.
class NeoBlockLoader extends StatefulWidget {
  final double blockSize;
  final Color c0;
  final Color c1;
  final double size;
  final bool compact;
  final String label;

  const NeoBlockLoader({
    super.key,
    this.blockSize = 9,
    this.c0 = NeoColors.black,
    this.c1 = NeoColors.yellow,
    this.size = 46,
    this.compact = false,
    this.label = 'SPQR · NOVACORE',
  });

  @override
  State<NeoBlockLoader> createState() => _NeoBlockLoaderState();
}

class _NeoBlockLoaderState extends State<NeoBlockLoader>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500));
    _ctrl.repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.c1 == NeoColors.yellow ? NeoColors.gold : widget.c1;
    final halo = accent.withValues(alpha: 0.14);
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;

    // Fallback aksesibilitas / gerak-rendah: spinner standar yang tenang.
    if (reduced) {
      return SizedBox(
        width: widget.size,
        height: widget.size,
        child: CircularProgressIndicator(
          strokeWidth: 2.5,
          color: accent,
          backgroundColor: halo,
        ),
      );
    }

    // Varian kecil: cukup cincin emas berputar (di tombol / area sempit).
    if (widget.compact) {
      return SizedBox(
        width: widget.size,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, _) {
            final t = _ctrl.value;
            return Transform.rotate(
              angle: t * 2 * math.pi,
              child: CustomPaint(
                size: Size.square(widget.size),
                painter: _LaurelRingPainter(
                  accent: accent,
                  stroke: math.max(2.5, widget.size * 0.12),
                ),
              ),
            );
          },
        ),
      );
    }

    final s = widget.size;
    final orbitR = s * 0.30;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: s,
          height: s,
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (context, _) {
              final t = _ctrl.value;
              return Stack(
                alignment: Alignment.center,
                children: [
                  // Cincin laurel utama — berputar searah jarum jam.
                  Transform.rotate(
                    angle: t * 2 * math.pi,
                    child: CustomPaint(
                      size: Size.square(s),
                      painter: _LaurelRingPainter(
                        accent: accent,
                        stroke: math.max(3, s * 0.11),
                      ),
                    ),
                  ),
                  // Cincin tipis senada — berputar berlawanan, temaram.
                  Transform.rotate(
                    angle: -t * 0.62 * 2 * math.pi,
                    child: CustomPaint(
                      size: Size.square(s),
                      painter: _LaurelRingPainter(
                        accent: accent.withValues(alpha: 0.35),
                        stroke: 1.2,
                      ),
                    ),
                  ),
                  // Tiga laurel ❦ mengorbit.
                  for (var i = 0; i < 3; i++) ...[
                    Transform.translate(
                      offset: Offset(
                        orbitR * math.cos(t * 2 * math.pi + i * 2 * math.pi / 3),
                        orbitR * math.sin(t * 2 * math.pi + i * 2 * math.pi / 3),
                      ),
                      child: Text(
                        '\u2766',
                        style: TextStyle(
                          fontSize: s * 0.2,
                          color: accent.withValues(alpha: 0.95),
                          shadows: [
                            Shadow(
                              color: accent.withValues(alpha: 0.7),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  // Medali emas inti.
                  Container(
                    width: s * 0.46,
                    height: s * 0.46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFFFFE3A3), NeoColors.goldDeep],
                      ),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.75),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withValues(alpha: 0.55),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        '\u2726',
                        style: TextStyle(
                          fontSize: s * 0.2,
                          color: const Color(0xFF2A1E00),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
        if (widget.label.isNotEmpty) ...[
          const SizedBox(height: 7),
          Text(
            widget.label,
            style: GoogleFonts.cinzel(
              fontSize: 8.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 2.4,
              color: accent.withValues(alpha: 0.8),
            ),
          ),
        ],
      ],
    );
  }
}

/// Busur cincin emas ala laurel: busur penuh temaram + busur tebal emas.
class _LaurelRingPainter extends CustomPainter {
  final Color accent;
  final double stroke;

  _LaurelRingPainter({required this.accent, required this.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2 - stroke;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final sweep = 2.4 * math.pi;

    void drawArc(Color color, double width, double offset) {
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = width
        ..strokeCap = StrokeCap.round
        ..color = color;
      canvas.drawArc(rect, -math.pi / 2 + offset, sweep, false, paint);
    }

    drawArc(accent.withValues(alpha: 0.14), stroke + 2, 0);
    drawArc(accent, stroke, 0);
  }

  @override
  bool shouldRepaint(covariant _LaurelRingPainter old) =>
      old.accent != accent || old.stroke != stroke;
}
