import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import 'neo_button.dart';

/// Cangkang glass Romawi untuk bottom sheet — blur + gradien ungu tembus
/// pandang + border emas tipis + bayangan lembut.
class RomanSheet extends StatelessWidget {
  final Widget child;

  const RomanSheet({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xF21B1030), Color(0xF20E081D)],
            ),
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: const Color(0x55FFD98A), width: 1),
            boxShadow: const [
              BoxShadow(
                color: Color(0x44000000),
                blurRadius: 30,
                offset: Offset(0, -8),
              ),
            ],
          ),
          child: SafeArea(top: false, child: child),
        ),
      ),
    );
  }
}

/// Cangkang glass Romawi untuk dialog tengah layar.
class RomanDialog extends StatelessWidget {
  final Widget child;
  final double radius;

  const RomanDialog({super.key, required this.child, this.radius = 24});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xF21B1030), Color(0xF20E081D)],
            ),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: const Color(0x55FFD98A), width: 1),
            boxShadow: const [
              BoxShadow(color: Color(0x88000000), blurRadius: 32),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Gagang (handle) emas di bagian atas sheet.
class RomanHandle extends StatelessWidget {
  const RomanHandle({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42,
      height: 4,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFFFD98A), Color(0xFFC6A15B)],
        ),
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }
}

/// Judul Romawi: teks Cinzel emas diapit garis laurel (garis emas + ✦).
class RomanSheetTitle extends StatelessWidget {
  final String text;
  final double fontSize;
  final FontWeight fontWeight;
  final double letterSpacing;

  const RomanSheetTitle(
    this.text, {
    super.key,
    this.fontSize = 16,
    this.fontWeight = FontWeight.w700,
    this.letterSpacing = 2,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(child: _RomanLine()),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text.rich(
            TextSpan(
              children: [
                const TextSpan(
                  text: '✦ ',
                  style: TextStyle(color: Color(0x99FFD98A), fontSize: 11),
                ),
                TextSpan(
                  text: text,
                  style: GoogleFonts.cinzel(
                    textStyle: TextStyle(
                      fontSize: fontSize,
                      fontWeight: fontWeight,
                      letterSpacing: letterSpacing,
                      color: const Color(0xFFFFD98A),
                    ),
                  ),
                ),
                const TextSpan(
                  text: ' ✦',
                  style: TextStyle(color: Color(0x99FFD98A), fontSize: 11),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const Expanded(child: _RomanLine()),
      ],
    );
  }
}

class _RomanLine extends StatelessWidget {
  const _RomanLine();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.transparent, Color(0x88C6A15B), Colors.transparent],
        ),
      ),
    );
  }
}

/// Dekorasi TextField ala Roman: isi kaca tembus pandang + border emas halus
/// (bukan OutlineInputBorder kaku).
InputDecoration romanFieldDecoration({
  String? hint,
  IconData? icon,
  String? label,
}) {
  final base = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: const BorderSide(color: Color(0x44FFD98A), width: 1),
  );
  return InputDecoration(
    hintText: hint,
    labelText: label,
    labelStyle: const TextStyle(
      color: Color(0xFFFBF5E6),
      fontSize: 12,
      fontWeight: FontWeight.w700,
      letterSpacing: 1,
    ),
    hintStyle: const TextStyle(color: Color(0x80FBF5E6), fontSize: 13),
    prefixIcon: icon != null
        ? Icon(icon, size: 20, color: const Color(0x99FFD98A))
        : null,
    filled: true,
    fillColor: Colors.white.withValues(alpha: 0.05),
    enabledBorder: base,
    focusedBorder: base.copyWith(
      borderSide: const BorderSide(color: Color(0xFFFFD98A), width: 1.4),
    ),
    errorBorder: base.copyWith(
      borderSide: const BorderSide(color: NeoColors.pink, width: 1),
    ),
  );
}

/// Baris label kecil (kata-kata kecil). Helper konsisten untuk sheet.
class RomanLabel extends StatelessWidget {
  final String text;
  final Color color;

  const RomanLabel(this.text, {super.key, required this.color});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
        color: color,
      ),
    );
  }
}

/// Judul screen ala Romawi: ikon emas + teks Cinzel gading + garis emas pendek.
/// Dipakai untuk header TOOLS agar seragam dengan DEVICES / WHATSAPP SENDERS.
class RomanTitle extends StatelessWidget {
  final String text;
  final IconData icon;
  final double fontSize;
  final double lineWidth;

  const RomanTitle(
    this.text, {
    super.key,
    this.icon = Icons.account_balance_rounded,
    this.fontSize = 18,
    this.lineWidth = 120,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: const Color(0xFFFFD98A), size: 20),
            const SizedBox(width: 8),
            Text(
              text,
              style: GoogleFonts.cinzel(
                textStyle: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                  color: const Color(0xFFFBF5E6),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Container(
          width: lineWidth,
          height: 1,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFD98A), Color(0x33C6A15B)],
            ),
          ),
        ),
      ],
    );
  }
}

/// Kaki (footer) ala Romawi: garis laurel + kata-kata Cinzel + moto kecil.
/// Meniru _SenateFooter di tools, bisa dipakai di akhir screen mana pun.
class RomanFooter extends StatelessWidget {
  final String words;
  final String subline;

  const RomanFooter({
    super.key,
    required this.words,
    this.subline = 'ANNO IMPERII · SPQR',
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const Expanded(child: _RomanLine()),
            const SizedBox(width: 12),
            const Text(
              '❦  ✦  ❦',
              style: TextStyle(color: Color(0xFFFFD98A), fontSize: 13, letterSpacing: 2),
            ),
            const SizedBox(width: 12),
            const Expanded(child: _RomanLine()),
          ],
        ),
        const SizedBox(height: 10),
        Text(
          words,
          textAlign: TextAlign.center,
          style: GoogleFonts.cinzel(
            fontSize: 11,
            letterSpacing: 3,
            fontWeight: FontWeight.w600,
            color: const Color(0xFFBB8C2E),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '❦  $subline  ❦',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 9,
            letterSpacing: 2,
            color: const Color(0xFFFBF5E6).withValues(alpha: 0.55),
          ),
        ),
      ],
    );
  }
}

/// Dialog tengah Romawi untuk pemberitahuan sesi: akun login di perangkat lain.
/// Punya tombol OK; kalau diketuk di luar dialog pun tetap keluar (logout sudah
/// dilakukan sebelum dialog ditampilkan — dialog murni informatif).
class SessionKickedDialog extends StatelessWidget {
  final String message;

  const SessionKickedDialog({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: RomanDialog(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFFFFD98A),
                        Color(0xFFC6A15B),
                        Color(0xFF8A6D2B),
                      ],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0x99FFFFFF),
                      width: 2,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x8AFFD98A),
                        blurRadius: 26,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.shield_moon_rounded,
                    color: Color(0xFF0D0D2B),
                    size: 34,
                  ),
                ),
              ),
              const SizedBox(height: 22),
              const RomanSheetTitle('AKUN MASUK', fontSize: 17),
              const SizedBox(height: 4),
              const RomanSheetTitle('DI PERANGKAT LAIN', fontSize: 15),
              const SizedBox(height: 20),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: Color(0xFFFBF5E6),
                ),
              ),
              const SizedBox(height: 24),
              NeoButton(
                label: 'OK',
                height: 44,
                fontSize: 13,
                onPressed: () => Navigator.of(context).pop(),
              ),
              const SizedBox(height: 12),
              const Center(
                child: Text(
                  'Ketuk di luar dialog untuk tetap keluar',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 0.5,
                    color: Color(0x99FFD98A),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}