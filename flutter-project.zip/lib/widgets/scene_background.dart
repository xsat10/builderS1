import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import 'neo_feature_config.dart';
import 'transition_state.dart';

const double _bgMaxOpacity = 0.20;

const String _romanBackgroundAsset = 'assets/bg/roman_background.png';
const String _bubbleBackgroundAsset = 'assets/bubble/roman_background.png';

class SceneBackground extends StatefulWidget {
  final Widget child;
  final FeatureTheme theme;
  final int screenIndex;

  const SceneBackground({
    super.key,
    required this.child,
    required this.theme,
    required this.screenIndex,
  });

  @override
  State<SceneBackground> createState() => _SceneBackgroundState();
}

class _SceneBackgroundState extends State<SceneBackground> {
  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final backgroundAsset = skin.isBubbleGum
      ? _bubbleBackgroundAsset
      : _romanBackgroundAsset;
    final ts = TransitionState.maybeOf(context);
    double exitT = 0;
    double enterT = 0;
    var isExiting = false;
    var isEntering = false;
    if (ts != null && ts.active) {
      isExiting = ts.exitIndex == widget.screenIndex;
      isEntering = ts.enterIndex == widget.screenIndex;
      if (isExiting) {
        exitT = (ts.progress / FeatureConfig.transitionExitRatio).clamp(0, 1);
      } else if (isEntering) {
        enterT =
            ((ts.progress - FeatureConfig.transitionExitRatio) /
                    FeatureConfig.transitionEnterRatio)
                .clamp(0, 1);
      }
    }

    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;

    return SceneTheme(
      theme: widget.theme,
      child: Stack(
        children: [
          Positioned.fill(
            child: ColoredBox(
              color: palette.background,
            ),
          ),
          Positioned.fill(
            child: Image.asset(
              backgroundAsset,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => const SizedBox.shrink(),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    palette.background.withValues(alpha: 0.66),
                    palette.surface.withValues(alpha: 0.48),
                    palette.primary.withValues(alpha: 0.22),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: _buildBackground(
              isExiting,
              isEntering,
              exitT,
              enterT,
              reduced,
            ),
          ),
          Positioned.fill(child: widget.child),
        ],
      ),
    );
  }

  Widget _buildBackground(
    bool isExiting,
    bool isEntering,
    double exitT,
    double enterT,
    bool reduced,
  ) {
    if (reduced) {
      return Container(
        color: widget.theme.backgroundColor.withValues(alpha: _bgMaxOpacity),
      );
    }
    double bgOpacity;
    if (isExiting) {
      bgOpacity = _bgMaxOpacity * (1 - exitT);
    } else if (isEntering) {
      bgOpacity = _bgMaxOpacity * enterT;
    } else {
      bgOpacity = _bgMaxOpacity;
    }
    return Container(
      color: widget.theme.backgroundColor.withValues(
        alpha: bgOpacity.clamp(0, _bgMaxOpacity),
      ),
    );
  }
}

class SceneTheme extends InheritedWidget {
  final FeatureTheme theme;

  const SceneTheme({super.key, required this.theme, required super.child});

  static SceneTheme of(BuildContext context) {
    final result = context.dependOnInheritedWidgetOfExactType<SceneTheme>();
    return result!;
  }

  static FeatureTheme? maybeThemeOf(BuildContext context) {
    return context.getInheritedWidgetOfExactType<SceneTheme>()?.theme;
  }

  Color get buttonColor => FeatureConfig.buttonAccentFor(theme);

  @override
  bool updateShouldNotify(SceneTheme old) => old.theme != theme;
}
