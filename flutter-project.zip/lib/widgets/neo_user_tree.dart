import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

class NeoUserTree extends StatefulWidget {
  final List<Map<String, dynamic>> users;
  final Color accent;
  final bool loading;
  final Widget? emptyWidget;
  final void Function(Map<String, dynamic> user)? onEdit;
  final void Function(Map<String, dynamic> user)? onReset;
  final void Function(Map<String, dynamic> user)? onToggle;
  final void Function(Map<String, dynamic> user)? onBan;
  final void Function(Map<String, dynamic> user)? onDelete;
  final void Function(Map<String, dynamic> user)? onRole;
  final bool Function(Map<String, dynamic> user)? canDelete;

  const NeoUserTree({
    super.key,
    required this.users,
    this.accent = NeoColors.member,
    this.loading = false,
    this.emptyWidget,
    this.onEdit,
    this.onReset,
    this.onToggle,
    this.onBan,
    this.onDelete,
    this.onRole,
    this.canDelete,
  });

  @override
  State<NeoUserTree> createState() => _NeoUserTreeState();
}

class _NeoUserTreeState extends State<NeoUserTree> {
  final Set<String> _collapsed = {};

  bool _defaultCollapsed(Map<String, dynamic> u) {
    return (u['role'] ?? '').toString() == 'member';
  }

  String _id(Map<String, dynamic> u) => (u['id'] ?? '').toString();

  List<Map<String, dynamic>> _children(Map<String, dynamic> u) {
    final myId = _id(u);
    return [for (final c in widget.users) if ((c['parent_id']?.toString() ?? '') == myId) c];
  }

  List<Map<String, dynamic>> get _roots {
    final ids = {for (final u in widget.users) _id(u)};
    return [
      for (final u in widget.users)
        if (u['parent_id'] == null ||
            (u['parent_id']?.toString() ?? '').isEmpty ||
            !ids.contains(u['parent_id']?.toString()))
          u,
    ];
  }

  bool _isCollapsed(Map<String, dynamic> u) {
    final id = _id(u);
    return _collapsed.contains(id) ? true : _defaultCollapsed(u);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (widget.loading) {
      return Container(
        decoration: BoxDecoration(
          color: isDark ? NeoColors.surface : NeoColors.white,
          border: Border.all(
            color: isDark ? NeoColors.line : NeoColors.border,
            width: NeoTheme.borderWidth,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.md),
        ),
        padding: const EdgeInsets.all(NeoSpacing.xxl),
        alignment: Alignment.center,
        child: const NeoBlockLoader(blockSize: 8, c0: NeoColors.black, c1: NeoColors.yellow),
      );
    }
    if (widget.users.isEmpty) {
      return widget.emptyWidget ??
          Padding(
            padding: const EdgeInsets.all(NeoSpacing.xl),
            child: Center(
              child: Text(
                'Tidak ada data',
                style: TextStyle(
                  fontSize: 13,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
            ),
          );
    }

    final rows = <Widget>[];
    void walk(Map<String, dynamic> u, int depth) {
      final kids = _children(u);
      rows.add(_row(u, depth, kids.isNotEmpty && !_isCollapsed(u), kids.isNotEmpty, isDark));
      if (kids.isNotEmpty && !_isCollapsed(u)) {
        for (final k in kids) {
          walk(k, depth + 1);
        }
      }
    }

    for (final r in _roots) {
      walk(r, 0);
    }
    if (rows.isEmpty && widget.users.isNotEmpty) {
      for (final u in widget.users) {
        rows.add(_row(u, 0, false, false, isDark));
      }
    }

    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: isDark ? NeoColors.line : NeoColors.border,
          width: NeoTheme.borderWidth,
        ),
        borderRadius: BorderRadius.circular(NeoRadius.md),
        color: isDark ? NeoColors.surface : NeoColors.white,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            color: isDark ? NeoColors.surfaceElevated : NeoColors.cream,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Text(
              'POHON USER',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
                color: NeoColors.secondaryText,
              ),
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: NeoColors.border.withValues(alpha: 0.4), width: 1),
              ),
            ),
            child: Text(
              'NAMA • ROLE • STATUS',
              style: TextStyle(
                fontSize: 8,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: NeoColors.secondaryText,
              ),
            ),
          ),
          for (final r in rows) r,
        ],
      ),
    );
  }

  Widget _row(
    Map<String, dynamic> u,
    int depth,
    bool expanded,
    bool hasChildren,
    bool isDark,
  ) {
    final rawName = (u['name'] ?? '').toString().trim();
    final rawUsername = (u['username'] ?? '').toString().trim();
    final rawEmail = (u['email'] ?? '').toString();
    final username = rawName.isNotEmpty
        ? rawName
        : rawUsername.isNotEmpty
            ? '@$rawUsername'
            : (rawEmail.split('@').first.isEmpty ? 'User' : rawEmail.split('@').first);
    final role = (u['role'] ?? '').toString();
    final status = (u['status'] ?? 'active').toString();
    final roleColor = NeoColors.roleColor(role);
    final initial = username.isEmpty ? '?' : username.substring(0, 1).toUpperCase();

    final divider = BorderSide(color: NeoColors.border.withValues(alpha: 0.4), width: 1);

    Widget rowInner() => Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              flex: 7,
              child: Row(
                children: [
                  SizedBox(width: depth * 18),
                  if (depth > 0) ...[
                    Container(width: 14, height: 2, color: roleColor),
                    const SizedBox(width: 2),
                  ],
                  SizedBox(
                    width: 20,
                    child: hasChildren
                        ? InkWell(
                            onTap: () => setState(() {
                              final id = _id(u);
                              if (_collapsed.contains(id)) {
                                _collapsed.remove(id);
                              } else {
                                _collapsed.add(id);
                              }
                            }),
                            child: AnimatedRotation(
                              turns: expanded ? 0.5 : 0,
                              duration: const Duration(milliseconds: 180),
                              child: Icon(
                                Icons.chevron_right,
                                size: 18,
                                color: NeoColors.secondaryText,
                              ),
                            ),
                          )
                        : const SizedBox(width: 18),
                  ),
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: roleColor,
                      border: Border.all(
                        color: isDark ? NeoColors.line : NeoColors.black,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      initial,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: NeoColors.black,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      username,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: isDark ? NeoColors.primaryText : NeoColors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 3,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                  decoration: BoxDecoration(
                    color: roleColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: Text(
                    role.isEmpty ? '—' : role.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.black,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 3,
              child: Row(
                children: [
                  Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: status == 'active'
                          ? NeoColors.green
                          : NeoColors.grey,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      status.toUpperCase(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                        color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 5,
              child: Align(
                alignment: Alignment.centerRight,
                child: Wrap(
                  spacing: 4,
                  children: [
                    if (widget.onEdit != null)
                      _IconAction(
                        Icons.edit_outlined,
                        widget.accent,
                        'Edit',
                        () => widget.onEdit!(u),
                      ),
                    if (widget.onReset != null)
                      _IconAction(
                        Icons.lock_reset,
                        NeoColors.yellow,
                        'Reset Password',
                        () => widget.onReset!(u),
                      ),
                    if (widget.onBan != null)
                      _IconAction(
                        (u['banned_at']?.toString() ?? '').isNotEmpty
                            ? Icons.gavel
                            : Icons.gavel_outlined,
                        (u['banned_at']?.toString() ?? '').isNotEmpty
                            ? NeoColors.green
                            : NeoColors.pink,
                        (u['banned_at']?.toString() ?? '').isNotEmpty
                            ? 'Buka Ban'
                            : 'Ban',
                        () => widget.onBan!(u),
                      ),
                    if (widget.onToggle != null)
                      _IconAction(
                        status == 'disabled'
                            ? Icons.check_circle_outline
                            : Icons.block,
                        status == 'disabled' ? NeoColors.green : NeoColors.pink,
                        status == 'disabled' ? 'Aktifkan' : 'Nonaktifkan',
                        () => widget.onToggle!(u),
                      ),
                    if (widget.onRole != null &&
                        role != 'developer' &&
                        (widget.canDelete?.call(u) ?? true))
                      _IconAction(
                        Icons.badge_outlined,
                        NeoColors.orange,
                        'Ubah Role',
                        () => widget.onRole!(u),
                      ),
                    if (widget.onDelete != null &&
                        (widget.canDelete?.call(u) ?? true))
                      _IconAction(
                        Icons.delete_outline,
                        NeoColors.pink,
                        'Hapus',
                        () => widget.onDelete!(u),
                      ),
                  ],
                ),
              ),
            ),
          ],
        );

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        border: Border(top: divider, bottom: divider),
      ),
      child: rowInner(),
    );
  }
}

class _IconAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _IconAction(this.icon, this.color, this.tooltip, this.onTap);

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(NeoRadius.sm),
        child: Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            color: color,
            border: Border.all(
              color: Theme.of(context).brightness == Brightness.dark
                  ? NeoColors.line
                  : NeoColors.black,
              width: 1.5,
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Icon(icon, size: 14, color: NeoColors.black),
        ),
      ),
    );
  }
}
