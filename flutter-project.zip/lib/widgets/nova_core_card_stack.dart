import 'dart:math' as math;
import 'dart:ui' show ImageFilter, lerpDouble;
import 'package:flutter/material.dart';
import '../theme.dart';

class NovaCoreStackCard {
  const NovaCoreStackCard({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.accent,
    this.description,
    this.footer,
    this.image,
    this.icon,
  });

  final String title;
  final String subtitle;
  final String badge;
  final String? description;
  final Widget? footer;
  final String? image;
  final IconData? icon;
  final Color accent;
}

class NovaCoreCardStack extends StatefulWidget {
  const NovaCoreCardStack({
    super.key,
    required this.cards,
    this.cycleDuration = const Duration(milliseconds: 560),
    this.snapDuration = const Duration(milliseconds: 420),
    this.maxCardWidth = 320,
    this.cardAspectRatio = 0.8,
  });

  final List<NovaCoreStackCard> cards;
  final Duration cycleDuration;
  final Duration snapDuration;
  final double maxCardWidth;
  final double cardAspectRatio;

  @override
  State<NovaCoreCardStack> createState() => _NovaCoreCardStackState();
}

class _Pose {
  const _Pose({
    required this.card,
    required this.matrix,
    required this.opacity,
    required this.z,
    required this.interactive,
  });

  final NovaCoreStackCard card;
  final Matrix4 matrix;
  final double opacity;
  final double z;
  final bool interactive;
}

class _NovaCoreCardStackState extends State<NovaCoreCardStack>
    with TickerProviderStateMixin {
  static const double _scaleDecay = 0.958;
  static const double _opacityDecay = 0.13;
  static const double _slotRot = 0.03;

  late List<NovaCoreStackCard> _order;
  late final AnimationController _cycle;
  late final AnimationController _snap;

  bool _cycling = false;
  int _cycleDir = 1;
  double _dragPx = 0;
  double _snapFromPx = 0;
  double _cycleStartDx = 0;
  double _cycleStartRot = 0;

  @override
  void initState() {
    super.initState();
    _order = List.of(widget.cards);
    _cycle = AnimationController(vsync: this, duration: widget.cycleDuration)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed && mounted) {
          setState(() {
            _order = [..._order.sublist(1), _order.first];
            _cycle.value = 0;
            _cycling = false;
            _cycleStartDx = 0;
            _cycleStartRot = 0;
          });
        }
      });
    _snap = AnimationController(vsync: this, duration: widget.snapDuration)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed && mounted) {
          setState(() {
            _dragPx = 0;
            _snapFromPx = 0;
            _snap.value = 0;
          });
        }
      });
  }

  @override
  void didUpdateWidget(covariant NovaCoreCardStack oldWidget) {
    super.didUpdateWidget(oldWidget);
    final next = widget.cards;
    if (next.length == oldWidget.cards.length && _order.length == next.length) {
      final frontTitle = _order.first.title;
      final idx = next.indexWhere((c) => c.title == frontTitle);
      if (idx >= 0) {
        _order = [...next.sublist(idx), ...next.sublist(0, idx)];
      } else {
        _order = List.of(next);
      }
    } else {
      _order = List.of(next);
      _dragPx = 0;
      _snapFromPx = 0;
      _cycle.value = 0;
      _snap.value = 0;
      _cycling = false;
    }
  }

  @override
  void dispose() {
    _cycle.dispose();
    _snap.dispose();
    super.dispose();
  }

  bool get _reduced => MediaQuery.disableAnimationsOf(context);

  void _dragUpdate(double delta) {
    if (_cycling) return;
    final w = widget.maxCardWidth;
    setState(() => _dragPx = (_dragPx + delta).clamp(-w, w).toDouble());
  }

  void _dragEnd() {
    if (_cycling) return;
    final w = widget.maxCardWidth;
    if (_dragPx.abs() >= w * 0.26) {
      _startCycle(_dragPx.isNegative ? -1 : 1);
    } else {
      _snapBack();
    }
  }

  void _tap() {
    if (_cycling) return;
    if (_reduced) {
      setState(() => _order = [..._order.sublist(1), _order.first]);
      return;
    }
    _startCycle(1);
  }

  void _startCycle(int dir) {
    final w = widget.maxCardWidth;
    if (_reduced) {
      setState(() {
        _order = [..._order.sublist(1), _order.first];
        _dragPx = 0;
      });
      return;
    }
    _snap.stop();
    setState(() {
      _cycleDir = dir;
      _cycling = true;
      _cycleStartDx = _dragPx;
      _cycleStartRot = (_dragPx / w) * 0.3;
      _dragPx = 0;
    });
    _cycle.forward(from: 0);
  }

  void _snapBack() {
    if (_reduced) {
      setState(() => _dragPx = 0);
      return;
    }
    setState(() => _snapFromPx = _dragPx);
    _snap.forward(from: 0);
  }

  double _slotScale(double s) => math.pow(_scaleDecay, s).toDouble();

  double _slotOpacity(double s) => (1 - _opacityDecay * s).clamp(0.05, 1.0);

  double _slotRotAt(double s) {
    final lo = s.floor();
    final f = s - lo;
    final a = (lo.isEven ? 1 : -1) * _slotRot;
    final b = (lo.isEven ? -1 : 1) * _slotRot;
    return lerpDouble(a, b, f)!;
  }

  @override
  Widget build(BuildContext context) {
    final cards = widget.cards;
    if (cards.isEmpty) return const SizedBox.shrink();
    return LayoutBuilder(
      builder: (context, constraints) {
        final count = _order.length;
        final w = math.min(widget.maxCardWidth, constraints.maxWidth);
        final h = w / widget.cardAspectRatio;
        final step = (w * 0.05).clamp(12.0, 26.0).toDouble();
        final topSlack = h * 0.12;
        final bottomSlack = h * 0.06;
        final stackH = topSlack + h + step * (count - 1) + bottomSlack;

        final poses = <_Pose>[];
        final t = _cycle.value;
        final visualDragPx = _snap.isAnimating
            ? _snapFromPx * (1 - Curves.easeOutCubic.transform(_snap.value))
            : _dragPx;
        final dragFrac = (visualDragPx / w).clamp(-1.0, 1.0).toDouble();
        final slide = Curves.easeInOutCubic.transform(t);

        for (var i = 0; i < count; i++) {
          final card = _order[i];
          var slot = i.toDouble();
          var dx = 0.0;
          var rot = 0.0;
          var scale = 1.0;
          var opacity = 1.0;
          var z = 0.0;

          if (_cycling) {
            if (i == 0) {
              if (t <= 0.4) {
                final u = Curves.easeOutCubic.transform(t / 0.4);
                slot = -0.5;
                scale = 1 + 0.06 * u;
                dx = _cycleStartDx + (_cycleDir * w * 0.1 - _cycleStartDx) * u;
                rot = _cycleStartRot + (_cycleDir * 0.14 - _cycleStartRot) * u;
                opacity = 1;
                z = -1;
              } else {
                final v = Curves.easeInOutCubic.transform((t - 0.4) / 0.6);
                final target = (count - 1).toDouble();
                final scaleT = _slotScale(target);
                final rotT = _slotRotAt(target);
                final opT = _slotOpacity(target);
                slot = target;
                scale = lerpDouble(1 + 0.06, scaleT, v)!;
                dx = lerpDouble(_cycleDir * w * 0.1, 0, v)!;
                rot = lerpDouble(_cycleDir * 0.14, rotT, v)!;
                opacity = lerpDouble(1, opT, v)!;
                z = count.toDouble();
              }
            } else {
              slot = i + slide * -1.0;
              scale = _slotScale(slot);
              rot = _slotRotAt(slot);
              opacity = _slotOpacity(slot);
              z = slot;
            }
          } else {
            if (i == 0) {
              slot = 0;
              scale = 1 - 0.03 * dragFrac.abs();
              dx = visualDragPx;
              rot = dragFrac * 0.3;
              opacity = 1;
              z = 0;
            } else {
              slot = (i - dragFrac * 0.4).clamp(0.0, (count - 1).toDouble());
              scale = _slotScale(slot);
              rot = _slotRotAt(slot);
              opacity = _slotOpacity(slot);
              z = i.toDouble();
            }
          }

          final liftUp = _cycling && i == 0 && t <= 0.4 ? -h * 0.04 : 0.0;
          final ty = topSlack + step * slot + liftUp;
          final matrix = Matrix4.identity()
            ..translateByDouble(dx, ty, 0, 1)
            ..rotateZ(rot)
            ..scaleByDouble(scale, scale, 1, 1);

          poses.add(
            _Pose(
              card: card,
              matrix: matrix,
              opacity: opacity,
              z: z,
              interactive: i == 0 && !_cycling,
            ),
          );
        }

        poses.sort((a, b) => b.z.compareTo(a.z));

        return Center(
          child: SizedBox(
            width: w,
            height: stackH,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _tap,
              onHorizontalDragStart: (_) {
                if (!_cycling) _snap.stop();
              },
              onHorizontalDragUpdate: (d) => _dragUpdate(d.delta.dx),
              onHorizontalDragEnd: (_) => _dragEnd(),
              onHorizontalDragCancel: _dragEnd,
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.topCenter,
                children: [
                  for (final pose in poses)
                    Transform(
                      alignment: Alignment.center,
                      transform: pose.matrix,
                      child: IgnorePointer(
                        ignoring: !pose.interactive,
                        child: Opacity(
                          opacity: pose.opacity,
                          child: SizedBox(
                            width: w,
                            height: h,
                            child: _DeckCard(
                              card: pose.card,
                              blur: pose.interactive,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _DeckCard extends StatelessWidget {
  const _DeckCard({required this.card, required this.blur});

  final NovaCoreStackCard card;
  final bool blur;

  @override
  Widget build(BuildContext context) {
    final accent = card.accent;
    final radius = BorderRadius.circular(24);
    final content = Container(
      width: double.infinity,
      height: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.10),
            Colors.white.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: radius,
        border: Border.all(color: accent.withValues(alpha: 0.55), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.45),
            blurRadius: 28,
            offset: const Offset(0, 14),
            spreadRadius: -6,
          ),
        ],
      ),
      child: Column(
        children: [
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: accent.withValues(alpha: 0.45)),
              ),
              child: Text(
                card.badge.toUpperCase(),
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2.5,
                  color: accent,
                  fontFamily: 'monospace',
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent.withValues(alpha: 0.10),
                    border: Border.all(
                      color: accent.withValues(alpha: 0.55),
                      width: 1.4,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withValues(alpha: 0.30),
                        blurRadius: 22,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: card.image != null
                      ? ClipOval(
                          child: Image.asset(card.image!, fit: BoxFit.cover),
                        )
                      : Icon(card.icon ?? Icons.code, size: 30, color: accent),
                ),
                const SizedBox(height: 16),
                Text(
                  card.title.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3,
                    color: NeoColors.primaryText,
                    fontFamily: 'monospace',
                    shadows: [
                      Shadow(
                        color: accent.withValues(alpha: 0.5),
                        blurRadius: 18,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  card.subtitle.toUpperCase(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 3,
                    color: accent,
                  ),
                ),
                if (card.description != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    card.description!,
                    textAlign: TextAlign.center,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: NeoColors.secondaryText,
                      height: 1.5,
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (card.footer != null) ...[
            Container(
              height: 1,
              margin: const EdgeInsets.only(top: 6),
              color: accent.withValues(alpha: 0.22),
            ),
            const SizedBox(height: 10),
            card.footer!,
          ],
        ],
      ),
    );
    if (!blur) return content;
    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: content,
      ),
    );
  }
}
