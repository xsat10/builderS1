import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

/// RoyalFrame — bingkai kerajaan "cornice imperial".
/// Satu garis emas tegas + bracket L di tiap sudut (dengan titik di ujung).
/// Digambar sekali lewat CustomPainter (tanpa asset, tanpa blur) agar ringan.
class RoyalFrame extends StatelessWidget {
  final Widget child;
  final double radius;
  final double cornerLength;
  final Color lineColor;
  final Color cornerColor;

  const RoyalFrame({
    super.key,
    required this.child,
    this.radius = 12,
    this.cornerLength = 15,
    this.lineColor = const Color(0x8CE5C365),
    this.cornerColor = const Color(0xE6E5C365),
  });

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Stack(
      children: [
        Positioned.fill(
          child: CustomPaint(
            painter: _RoyalFramePainter(
              radius: radius,
              cornerLength: cornerLength,
                lineColor: skin.isBubbleGum
                  ? palette.primary.withValues(alpha: 0.45)
                  : lineColor,
                cornerColor: skin.isBubbleGum ? palette.accent : cornerColor,
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _RoyalFramePainter extends CustomPainter {
  final double radius;
  final double cornerLength;
  final Color lineColor;
  final Color cornerColor;

  _RoyalFramePainter({
    required this.radius,
    required this.cornerLength,
    required this.lineColor,
    required this.cornerColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final half = 0.5;

    final outer = RRect.fromRectAndRadius(
      Rect.fromLTWH(half, half, w - 1, h - 1),
      Radius.circular(radius),
    );

    final linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = lineColor;

    canvas.drawRRect(outer, linePaint);

    final cornerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.square
      ..strokeWidth = 1.6
      ..color = cornerColor;

    final len = cornerLength.clamp(0.0, w / 2 - 4);
    final off = 0.75;

    void corner(Offset origin, double dirX, double dirY) {
      // dua lengan bracket: horizontal + vertikal dari sudut ke dalam
      canvas.drawLine(
        origin,
        origin.translate(len * dirX, 0),
        cornerPaint,
      );
      canvas.drawLine(
        origin,
        origin.translate(0, len * dirY),
        cornerPaint,
      );
      // titik kecil di ujung lengan agar terasa imperial
      final dot = Paint()..color = cornerColor;
      canvas.drawCircle(origin.translate(len * dirX, 0), 1.1, dot);
      canvas.drawCircle(origin.translate(0, len * dirY), 1.1, dot);
    }

    corner(Offset(off, off), 1, 1);
    corner(Offset(w - 1 - off, off), -1, 1);
    corner(Offset(off, h - 1 - off), 1, -1);
    corner(Offset(w - 1 - off, h - 1 - off), -1, -1);
  }

  @override
  bool shouldRepaint(covariant _RoyalFramePainter oldDelegate) {
    return false;
  }
}