import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_block_loader.dart';

class NeoLoadingOverlay {
  static Future<bool?> show({
    required BuildContext context,
    required String title,
    required String subtitle,
    required List<String> stages,
    required Future<bool> Function(NeoLoadingStage ctl) run,
  }) {
    return showGeneralDialog<bool>(
      context: context,
      barrierDismissible: false,
      barrierLabel: 'neo_loading',
      barrierColor: Colors.black.withValues(alpha: 0.45),
      transitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (ctx, animation, secondaryAnimation) => _NeoLoadingPanel(
        title: title,
        subtitle: subtitle,
        stages: stages,
        run: run,
      ),
      transitionBuilder: (ctx, anim, _, child) {
        final scale = CurvedAnimation(parent: anim, curve: Curves.easeOutBack);
        return FadeTransition(
          opacity: anim,
          child: ScaleTransition(scale: scale, child: child),
        );
      },
    );
  }
}

class NeoLoadingStage {
  final _NeoLoadingPanelState _state;
  NeoLoadingStage._(this._state);
  void set(int index) => _state.setStage(index);
  void setFail(String message) => _state.setFail(message);
}

class _NeoLoadingPanel extends StatefulWidget {
  final String title;
  final String subtitle;
  final List<String> stages;
  final Future<bool> Function(NeoLoadingStage ctl) run;

  const _NeoLoadingPanel({
    required this.title,
    required this.subtitle,
    required this.stages,
    required this.run,
  });

  @override
  State<_NeoLoadingPanel> createState() => _NeoLoadingPanelState();
}

class _NeoLoadingPanelState extends State<_NeoLoadingPanel>
    with TickerProviderStateMixin {
  late final AnimationController _stampCtrl;
  late final AnimationController _resultCtrl;
  late final AnimationController _joltCtrl;

  int _stage = 0;
  bool _done = false;
  bool _success = false;
  String _failMsg = '';

  bool get _reduced =>
      WidgetsBinding.instance.accessibilityFeatures.disableAnimations;

  @override
  void initState() {
    super.initState();
    _stampCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    if (!_reduced) _stampCtrl.repeat();
    _resultCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _joltCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 380),
    )..addListener(() => setState(() {}));
    _start();
  }

  @override
  void dispose() {
    _stampCtrl.dispose();
    _resultCtrl.dispose();
    _joltCtrl.dispose();
    super.dispose();
  }

  void setStage(int index) {
    if (!mounted) return;
    setState(() => _stage = index);
  }

  void setFail(String message) {
    if (!mounted) return;
    setState(() => _failMsg = message);
  }

  Future<void> _start() async {
    bool ok = false;
    try {
      ok = await widget.run(NeoLoadingStage._(this));
    } catch (_) {
      ok = false;
    }
    if (!mounted) return;
    _stampCtrl.stop();
    setState(() {
      _done = true;
      _success = ok;
    });
    if (_success) {
      _resultCtrl.forward(from: 0);
    } else {
      _resultCtrl.forward(from: 0);
      if (!_reduced) _joltCtrl.forward(from: 0);
    }
    if (ok) {
      await Future.delayed(const Duration(milliseconds: 950));
      if (mounted) Navigator.of(context).pop(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.border;

    return Center(
      child: AnimatedBuilder(
        animation: _joltCtrl,
        builder: (context, _) {
          final dx = _joltCtrl.isAnimating
              ? _JoltValues.valuesAt(_joltCtrl.value)
              : 0.0;
          return Transform.translate(
            offset: Offset(dx, 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                child: Container(
                  width: 300,
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xF21B1030), Color(0xF20E081D)],
                    ),
                    border: Border.all(
                      color: NeoColors.gold.withValues(alpha: 85 / 255),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x66000000),
                        blurRadius: 36,
                        offset: Offset(0, 16),
                        spreadRadius: -8,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _done ? _buildResult() : _buildLoading(isDark, lineColor),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoading(bool isDark, Color lineColor) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D2B),
                border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                'WA • EXECUTE',
                style: TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  color: NeoColors.gold,
                  letterSpacing: 1,
                ),
              ),
            ),
            const Spacer(),
            const Icon(
              Icons.touch_app_rounded,
              size: 16,
              color: Color(0x99888E98),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Text(
          widget.title,
          style: GoogleFonts.cinzel(
            textStyle: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
              color: NeoColors.gold,
            ),
          ),
        ),
        Text(
          widget.subtitle,
          style: TextStyle(
            fontSize: 11,
            color: NeoColors.marble.withValues(alpha: 175 / 255),
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 18),
        Center(
          child: _StampMotif(t: _stampCtrl, size: 26, reduced: _reduced),
        ),
        const SizedBox(height: 18),
        for (var i = 0; i < widget.stages.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: _StageRow(
              index: i,
              label: widget.stages[i],
              state: i < _stage
                  ? _StageState.done
                  : (i == _stage ? _StageState.active : _StageState.pending),
              progress: _stampCtrl,
            ),
          ),
        const SizedBox(height: 6),
        Row(
          children: [
            Icon(Icons.security_rounded, size: 12, color: NeoColors.gold.withValues(alpha: 153 / 255)),
            const SizedBox(width: 4),
            Text(
              'SELURUH PROSES AMAN • TUNGGU',
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: isDark ? NeoColors.marble.withValues(alpha: 175 / 255) : NeoColors.gold,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildResult() {
    final ok = _success;
    final bg = ok ? NeoColors.green : NeoColors.pink;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 16),
          decoration: BoxDecoration(
            color: bg,
            border: Border.all(color: NeoColors.gold, width: 2),
            borderRadius: BorderRadius.circular(NeoRadius.lg),
            boxShadow: [
              BoxShadow(
                color: NeoColors.gold.withValues(alpha: 64 / 255),
                offset: Offset(0, 0),
                blurRadius: 12,
              ),
            ],
          ),
          child: Center(
            child: ScaleTransition(
              scale: CurvedAnimation(
                parent: _resultCtrl,
                curve: Curves.easeOutBack,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D0D2B),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: NeoColors.gold,
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      ok ? Icons.check_rounded : Icons.close_rounded,
                      size: 24,
                      color: bg,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    ok ? 'TERKIRIM!' : 'GAGAL',
                    style: GoogleFonts.cinzel(
                      textStyle: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        color: bg == NeoColors.pink ? const Color(0xFF7A0018) : const Color(0xFF003B18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          ok
              ? 'Bug terkirim ke target.'
              : (_failMsg.isNotEmpty
                  ? _failMsg
                  : 'Gagal mengirim. Periksa nomor & coba lagi.'),
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: NeoColors.grey,
            height: 1.4,
          ),
        ),
        if (!ok) ...[
          const SizedBox(height: 14),
          NeoButton(
            label: 'TUTUP',
            bgColor: NeoColors.pink,
            onPressed: () => Navigator.of(context).pop(false),
          ),
        ],
      ],
    );
  }
}

class _JoltValues {
  static const _steps = [
    Offset(0, 0),
    Offset(-10, 0),
    Offset(10, 0),
    Offset(-7, 0),
    Offset(7, 0),
    Offset(-4, 0),
    Offset(4, 0),
    Offset(0, 0),
  ];
  static double valuesAt(double t) {
    final idx = (t * (_steps.length - 1)).round().clamp(0, _steps.length - 1);
    return _steps[idx].dx;
  }
}

enum _StageState { done, active, pending }

class _StageRow extends StatelessWidget {
  final int index;
  final String label;
  final _StageState state;
  final Animation<double> progress;

  const _StageRow({
    required this.index,
    required this.label,
    required this.state,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    final done = state == _StageState.done;
    final active = state == _StageState.active;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xCC1F1330),
        border: Border.all(
          color: done || active ? NeoColors.gold : const Color(0x224F4F66),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(8),
        boxShadow: done
            ? [
                BoxShadow(
                  color: NeoColors.gold.withValues(alpha: 51 / 255),
                  blurRadius: 8,
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: done ? NeoColors.gold : NeoColors.ink,
              border: Border.all(
                color: NeoColors.gold.withValues(alpha: 85 / 255),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(4),
            ),
            alignment: Alignment.center,
            child: done
                ? const Icon(
                    Icons.check_rounded,
                    size: 14,
                    color: Color(0xFF111111),
                  )
                : Text(
                    '${index + 1}',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.gold,
                    ),
                  ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                color: state == _StageState.pending
                    ? const Color(0x77B8B8CF)
                    : NeoColors.marble,
              ),
            ),
          ),
          if (active)
            SizedBox(
              width: 18,
              height: 12,
              child: NeoBlockLoader(
                blockSize: 5,
                c0: NeoColors.gold,
                c1: const Color(0xFFFFFFFF),
              ),
            )
          else if (done)
            Icon(Icons.done, size: 14, color: NeoColors.gold)
          else
            const Icon(
              Icons.radio_button_unchecked,
              size: 12,
              color: Color(0x77B8B8CF),
            ),
        ],
      ),
    );
  }
}

class _StampMotif extends StatelessWidget {
  final Animation<double> t;
  final double size;
  final bool reduced;

  const _StampMotif({
    required this.t,
    required this.size,
    required this.reduced,
  });

  @override
  Widget build(BuildContext context) {
    final cap = size;
    final follower = size * 0.42;
    final half = cap / 2;
    final directions = [(1.0, -1.0), (1.0, 1.0), (-1.0, 1.0), (-1.0, -1.0)];

    Widget capBox() => Container(
      width: cap,
      height: cap,
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D2B),
        border: Border.all(color: NeoColors.gold, width: 1.5),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [
          BoxShadow(
            color: NeoColors.gold.withValues(alpha: 102 / 255),
            offset: Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Icon(Icons.sync_rounded, size: 16, color: NeoColors.gold),
    );

    if (reduced) {
      return SizedBox(
        width: cap * 3,
        height: cap * 3,
        child: Stack(
          alignment: Alignment.center,
          children: [
            capBox(),
            for (var i = 0; i < 4; i++) _follower(directions[i], half + 14),
          ],
        ),
      );
    }

    return SizedBox(
      width: cap * 3,
      height: cap * 3,
      child: Stack(
        alignment: Alignment.center,
        children: [
          capBox(),
          for (var i = 0; i < 4; i++)
            AnimatedBuilder(
              animation: t,
              builder: (context, _) {
                final v = ((t.value * 2) + i * 0.25) % 1.0;
                final d = math.sin(v * math.pi);
                final dist = 6 + d * (cap * 0.7);
                return Transform.translate(
                  offset: Offset(
                    directions[i].$1 * dist,
                    directions[i].$2 * dist,
                  ),
                  child: Container(
                    width: follower,
                    height: follower,
                    decoration: BoxDecoration(
                      color: NeoColors.gold,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _follower((double, double) dir, double dist) {
    return Transform.translate(
      offset: Offset(dir.$1 * dist, dir.$2 * dist),
      child: Container(
        width: size * 0.42,
        height: size * 0.42,
        decoration: BoxDecoration(
          color: NeoColors.gold,
          borderRadius: BorderRadius.all(Radius.circular(2)),
        ),
      ),
    );
  }
}
