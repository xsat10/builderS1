import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

final Color _romanInk = const Color(0xFF180E26);

class NeoButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final Color textColor;
  final double height;
  final double fontSize;
  final IconData? icon;
  final bool loading;
  final double borderRadius;
  final bool roman;
  final Color? bgColor;

  const NeoButton({
    super.key,
    required this.label,
    this.onPressed,
    this.bgColor,
    this.textColor = NeoColors.white,
    this.height = 56,
    this.fontSize = 16,
    this.icon,
    this.loading = false,
    this.borderRadius = NeoRadius.xl,
    this.roman = false,
  });

  @override
  State<NeoButton> createState() => _NeoButtonState();
}

class _NeoButtonState extends State<NeoButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _hoverCtrl;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _hoverCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 220),
    );
  }

  @override
  void dispose() {
    _hoverCtrl.dispose();
    super.dispose();
  }

  Color get _loaderC0 {
    final bright = ThemeData.estimateBrightnessForColor(_effectiveText);
    return bright == Brightness.dark ? NeoColors.yellow : NeoColors.black;
  }

  Color get _loaderC1 {
    return _loaderC0 == NeoColors.yellow ? NeoColors.white : NeoColors.grey;
  }

  Color get _effectiveText {
    final explicitIsDark =
        ThemeData.estimateBrightnessForColor(widget.textColor) == Brightness.dark;
    final bgIsDark =
        ThemeData.estimateBrightnessForColor(widget.bgColor ?? NeoColors.gold) == Brightness.dark;
    // Gunakan warna teks eksplisit jika kontras layak, jika tidak auto.
    return explicitIsDark == bgIsDark ? widget.textColor : widget.textColor;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final bubbleRoman = skin.isBubbleGum && widget.roman;
    final bgColor = widget.bgColor ?? NeoColors.gold;
    final buttonBg = skin.isBubbleGum &&
        (bgColor == NeoColors.gold ||
          bgColor == NeoColors.goldDeep)
      ? palette.primary
      : bgColor;
    final buttonText = skin.isBubbleGum && bubbleRoman
      ? palette.onBackground1
      : widget.textColor;
    final disabled = widget.loading || widget.onPressed == null;

    return MouseRegion(
      onEnter: disabled ? null : (_) => _hoverCtrl.forward(),
      onExit: disabled ? null : (_) => _hoverCtrl.reverse(),
      cursor: disabled ? SystemMouseCursors.basic : SystemMouseCursors.click,
      child: GestureDetector(
        onTapDown: disabled
            ? null
            : (_) {
                if (!mounted) return;
                setState(() => _pressed = true);
              },
        onTapUp: disabled
            ? null
            : (_) {
                if (!mounted) return;
                setState(() => _pressed = false);
                widget.onPressed?.call();
              },
        onTapCancel: () {
          if (!mounted) return;
          setState(() => _pressed = false);
        },
        child: AnimatedBuilder(
          animation: _hoverCtrl,
          builder: (_, child) => Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              boxShadow: _pressed
                  ? []
                  : [
                      BoxShadow(
                        color: buttonBg.withValues(alpha: 0.22),
                        blurRadius: 18,
                        offset: const Offset(0, 8),
                        spreadRadius: -4,
                      ),
                    ],
            ),
            child: child,
          ),
          child: AnimatedScale(
            scale: _pressed ? 0.97 : 1.0,
            duration: const Duration(milliseconds: 120),
            curve: Curves.easeOut,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                  height: widget.height,
                  decoration: BoxDecoration(
                    color: bubbleRoman
                        ? null
                        : disabled && !widget.loading
                            ? Colors.white.withValues(alpha: 0.05)
                            : buttonBg.withValues(
                                alpha: isDark ? 0.34 : 0.30),
                    gradient: bubbleRoman || widget.roman
                      ? LinearGradient(
                        colors: bubbleRoman
                          ? [palette.primary, palette.accent]
                          : [NeoColors.gold, NeoColors.goldDeep],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    border: Border.all(
                        color: bubbleRoman || widget.roman
                          ? bubbleRoman
                            ? palette.primary.withValues(alpha: 0.75)
                            : NeoColors.marble.withValues(alpha: 153 / 255)
                          : disabled && !widget.loading
                              ? const Color(0x22FFFFFF)
                              : buttonBg.withValues(alpha: 0.65),
                      width: widget.roman ? 1.2 : 1,
                    ),
                    borderRadius: BorderRadius.circular(widget.borderRadius),
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.white.withValues(alpha: 0.10),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                      Center(
                        child: widget.loading
                            ? NeoBlockLoader(
                                compact: true,
                                size: 18,
                                label: '',
                                c0: _loaderC0,
                                c1: _loaderC1,
                              )
                            : Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (widget.icon != null) ...[
                                    Icon(
                                      widget.icon,
                                        color: bubbleRoman || widget.roman
                                          ? bubbleRoman
                                            ? buttonText
                                            : _romanInk
                                          : buttonText,
                                      size: 18,
                                    ),
                                    const SizedBox(width: 8),
                                  ],
                                  Flexible(
                                    child: Text(
                                      widget.label,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                        style: bubbleRoman || widget.roman
                                          ? GoogleFonts.cinzel(
                                              textStyle: TextStyle(
                                                fontSize: widget.fontSize,
                                                fontWeight: FontWeight.w700,
                                                color: bubbleRoman
                                                  ? buttonText
                                                  : _romanInk,
                                                letterSpacing: 2.0,
                                              ),
                                            )
                                          : TextStyle(
                                              fontSize: widget.fontSize,
                                              fontWeight: FontWeight.w800,
                                              color: buttonText,
                                              letterSpacing: 0.6,
                                            ),
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
    );
  }
}
