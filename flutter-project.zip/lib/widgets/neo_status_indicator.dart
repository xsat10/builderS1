import 'package:flutter/material.dart';
import '../theme.dart';

class NeoStatusIndicator extends StatelessWidget {
  final bool active;
  final String activeLabel;
  final String inactiveLabel;
  final Color activeColor;

  const NeoStatusIndicator({
    super.key,
    this.active = false,
    this.activeLabel = 'ACTIVE',
    this.inactiveLabel = 'INACTIVE',
    this.activeColor = NeoColors.green,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10, height: 10,
          decoration: BoxDecoration(
            color: active ? activeColor : NeoColors.grey,
            shape: BoxShape.circle,
            border: Border.all(color: NeoColors.black, width: 2),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          active ? activeLabel : inactiveLabel,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: active ? activeColor : NeoColors.grey,
          ),
        ),
      ],
    );
  }
}
