import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_glass_overlay.dart';
import 'neo_button.dart';
import '../games/catur.dart';
import '../games/block_blast_game.dart';
import '../services/sound_service.dart';

void showNovaGamesModal(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (ctx) => const _NovaGamesDialog(),
  );
}

class _NovaGamesDialog extends StatelessWidget {
  const _NovaGamesDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: NeoGlassOverlay(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [NeoColors.gold, NeoColors.goldDeep],
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.sports_esports_rounded, size: 22, color: Color(0xFF1A1100)),
                  ),
                  const SizedBox(width: 12),
            Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'NOVACORE ARENA',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.5,
                            color: NeoColors.primaryText,
                          ),
                        ),
                        Text(
                          'Pilih Mini Game',
                          style: TextStyle(
                            fontSize: 11,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: NeoColors.grey, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Game 1: CATUR (Chess)
              _GameTile(
                title: 'CATUR (CHESS 1v1)',
                subtitle: 'Multiplayer online & AI Bot (Match 2 min)',
                icon: Icons.grid_4x4_rounded,
                accentColor: NeoColors.gold,
                badge: 'ONLINE / BOT',
                onTap: () {
                  Navigator.pop(context);
                  _startChessMatchmaking(context);
                },
              ),

              const SizedBox(height: 12),

              // Game 2: BLOCK BLAST
              _GameTile(
                title: 'BLOCK BLAST',
                subtitle: 'Puzzle susun balok skor tertinggi',
                icon: Icons.extension_rounded,
                accentColor: NeoColors.purple,
                badge: 'PUZZLE',
                onTap: () {
                  Navigator.pop(context);
                  _openBlockBlastGame(context);
                },
              ),

              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  static void _startChessMatchmaking(BuildContext context) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const _ChessMatchmakingDialog(),
    );
  }

  static void _openBlockBlastGame(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const BlockBlastGame()),
    );
  }
}

class _GameTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accentColor;
  final String badge;
  final VoidCallback onTap;

  const _GameTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accentColor,
    required this.badge,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.04),
          border: Border.all(
            color: accentColor.withValues(alpha: 0.35),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: accentColor.withValues(alpha: 0.10),
              blurRadius: 16,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: accentColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentColor.withValues(alpha: 0.4), width: 1),
              ),
              child: Icon(icon, color: accentColor, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          title,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: NeoColors.primaryText,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: accentColor.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          badge,
                          style: TextStyle(
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.8,
                            color: accentColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: NeoColors.secondaryText,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.play_arrow_rounded, color: NeoColors.gold, size: 22),
          ],
        ),
      ),
    );
  }
}

// === CHESS MATCHMAKING (2 MIN TIMER → BOT FALLBACK) ===
class _ChessMatchmakingDialog extends StatefulWidget {
  const _ChessMatchmakingDialog();

  @override
  State<_ChessMatchmakingDialog> createState() => _ChessMatchmakingDialogState();
}

class _ChessMatchmakingDialogState extends State<_ChessMatchmakingDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  Timer? _timer;
  int _secondsLeft = 120; // 2 min

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        t.cancel();
        _startVsBot();
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  void _startVsBot() {
    _timer?.cancel();
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CaturPage()),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  String get _timeString {
    final m = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    final s = (_secondsLeft % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (ctx, _) {
                final scale = 1.0 + 0.12 * _pulseCtrl.value;
                return Transform.scale(
                  scale: scale,
                  child: Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [NeoColors.gold, NeoColors.goldDeep],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: NeoColors.gold.withValues(alpha: 0.4),
                          blurRadius: 24 * scale,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.cell_tower_rounded, size: 36, color: Color(0xFF1A1100)),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              'MENCARI LAWAN ONLINE...',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
                color: NeoColors.primaryText,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Maksimal tunggu 2 menit (Matchmaking)',
              style: TextStyle(fontSize: 11, color: NeoColors.secondaryText),
            ),
            const SizedBox(height: 16),
            Text(
              _timeString,
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.w900,
                color: NeoColors.gold,
                fontFamily: 'monospace',
              ),
            ),
            const SizedBox(height: 24),
            NeoButton(
              label: 'MAIN LAWAN BOT SEKARANG 🤖',
              bgColor: NeoColors.gold,
              textColor: const Color(0xFF1A1100),
              height: 46,
              fontSize: 13,
              onPressed: _startVsBot,
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () {
                _timer?.cancel();
                Navigator.pop(context);
              },
              child: const Text(
                'BATAL',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: NeoColors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// === CHESS GAME BOARD (INTERACTIVE) ===
class _ChessGameDialog extends StatefulWidget {
  final bool vsBot;
  const _ChessGameDialog({required this.vsBot});

  @override
  State<_ChessGameDialog> createState() => _ChessGameDialogState();
}

class _ChessGameDialogState extends State<_ChessGameDialog> {
  // 8x8 Board representation:
  // uppercase = White (player), lowercase = Black (bot)
  // r=rook, n=knight, b=bishop, q=queen, k=king, p=pawn
  late List<List<String>> _board;
  int? _selR, _selC;
  bool _playerTurn = true; // White moves first
  String _statusMsg = 'Turn Anda (Putih ♔)';

  @override
  void initState() {
    super.initState();
    _resetBoard();
  }

  void _resetBoard() {
    _board = [
      ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
      ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
      ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
    ];
    _selR = null;
    _selC = null;
    _playerTurn = true;
    _statusMsg = 'Turn Anda (Putih ♔)';
  }

  bool _isWhite(String piece) => piece.isNotEmpty && piece == piece.toUpperCase();
  bool _isBlack(String piece) => piece.isNotEmpty && piece == piece.toLowerCase();

  String _pieceSymbol(String p) {
    switch (p) {
      case 'K': return '♔';
      case 'Q': return '♕';
      case 'R': return '♖';
      case 'B': return '♗';
      case 'N': return '♘';
      case 'P': return '♙';
      case 'k': return '♚';
      case 'q': return '♛';
      case 'r': return '♜';
      case 'b': return '♝';
      case 'n': return '♞';
      case 'p': return '♟';
      default: return '';
    }
  }

  void _onSquareTap(int r, int c) {
    if (!_playerTurn) return;

    final target = _board[r][c];

    if (_selR != null && _selC != null) {
      final sr = _selR!;
      final sc = _selC!;
      if (sr == r && sc == c) {
        // Deselect
        setState(() { _selR = null; _selC = null; });
        return;
      }
      // Move piece if target is empty or black
      if (target.isEmpty || _isBlack(target)) {
        setState(() {
          _board[r][c] = _board[sr][sc];
          _board[sr][sc] = '';
          _selR = null;
          _selC = null;
          _playerTurn = false;
          _statusMsg = 'Bot sedang berpikir... 🤖';
        });
        SoundService.playChessMove();

        // Trigger Bot turn
        if (widget.vsBot) {
          Future.delayed(const Duration(milliseconds: 900), _botMove);
        }
        return;
      }
    }

    // Select white piece
    if (_isWhite(target)) {
      setState(() {
        _selR = r;
        _selC = c;
      });
    }
  }

  void _botMove() {
    if (!mounted) return;
    final moves = <(int, int, int, int)>[];
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (_isBlack(_board[r][c])) {
          // Find potential moves for black piece
          for (int dr = 0; dr < 8; dr++) {
            for (int dc = 0; dc < 8; dc++) {
              if (!_isBlack(_board[dr][dc])) {
                moves.add((r, c, dr, dc));
              }
            }
          }
        }
      }
    }
    if (moves.isNotEmpty) {
      final m = moves[math.Random().nextInt(moves.length)];
      setState(() {
        _board[m.$3][m.$4] = _board[m.$1][m.$2];
        _board[m.$1][m.$2] = '';
        _playerTurn = true;
        _statusMsg = 'Turn Anda (Putih ♔)';
      });
      SoundService.playChessMove();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: NeoGlassOverlay(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Icon(Icons.grid_4x4_rounded, color: NeoColors.gold, size: 20),
                const SizedBox(width: 8),
                Text(
                  'CATUR ARENA',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    color: NeoColors.primaryText,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: NeoColors.grey, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),

            const SizedBox(height: 6),

            Text(
              _statusMsg,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: NeoColors.gold),
            ),

            const SizedBox(height: 12),

            // Chessboard 8x8
            AspectRatio(
              aspectRatio: 1,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: NeoColors.gold.withValues(alpha: 102 / 255), width: 1.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(7),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 8,
                    ),
                    itemCount: 64,
                    itemBuilder: (ctx, i) {
                      final r = i ~/ 8;
                      final c = i % 8;
                      final isDarkSq = (r + c) % 2 == 1;
                      final piece = _board[r][c];
                      final isSel = _selR == r && _selC == c;

                      return GestureDetector(
                        onTap: () => _onSquareTap(r, c),
                        child: Container(
                          color: isSel
                              ? NeoColors.gold.withValues(alpha: 153 / 255)
                              : (isDarkSq
                                  ? const Color(0xFF2A1E38)
                                  : const Color(0xFF4A3860)),
                          child: Center(
                            child: Text(
                              _pieceSymbol(piece),
                              style: TextStyle(
                                fontSize: 26,
                                color: _isWhite(piece)
                                    ? Colors.white
                                    : const Color(0xFF28282B),
                                shadows: const [
                                  Shadow(color: Colors.black, blurRadius: 4),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: NeoButton(
                    label: 'RESET BOARD',
                    bgColor: const Color(0x22FFFFFF),
                    textColor: NeoColors.primaryText,
                    height: 40,
                    fontSize: 12,
                    onPressed: _resetBoard,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// === BLOCK BLAST GAME ===
class _BlockBlastDialog extends StatefulWidget {
  const _BlockBlastDialog();

  @override
  State<_BlockBlastDialog> createState() => _BlockBlastDialogState();
}

class _BlockBlastDialogState extends State<_BlockBlastDialog> {
  late List<List<bool>> _grid;
  int _score = 0;

  @override
  void initState() {
    super.initState();
    _resetGame();
  }

  void _resetGame() {
    _grid = List.generate(8, (_) => List.generate(8, (_) => false));
    _score = 0;
  }

  void _placeBlock(int r, int c) {
    if (_grid[r][c]) return;
    setState(() {
      _grid[r][c] = true;
      _score += 10;
      _checkLines();
    });
  }

  void _checkLines() {
    // Check rows & columns to clear
    for (int r = 0; r < 8; r++) {
      if (_grid[r].every((b) => b)) {
        for (int c = 0; c < 8; c++) {
          _grid[r][c] = false;
        }
        _score += 100;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: NeoGlassOverlay(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.extension_rounded, color: NeoColors.purple, size: 20),
                const SizedBox(width: 8),
                Text(
                  'BLOCK BLAST',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    color: NeoColors.primaryText,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: NeoColors.grey, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),

            Text(
              'SKOR: $_score',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: NeoColors.gold),
            ),

            const SizedBox(height: 12),

            AspectRatio(
              aspectRatio: 1,
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0x669B6BFF), width: 1.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(7),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 8,
                    ),
                    itemCount: 64,
                    itemBuilder: (ctx, i) {
                      final r = i ~/ 8;
                      final c = i % 8;
                      final filled = _grid[r][c];

                      return GestureDetector(
                        onTap: () => _placeBlock(r, c),
                        child: Container(
                          margin: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            color: filled
                                ? NeoColors.purple
                                : Colors.white.withValues(alpha: 0.05),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            NeoButton(
              label: 'RESTART GAME',
              bgColor: const Color(0x22FFFFFF),
              textColor: NeoColors.primaryText,
              height: 40,
              fontSize: 12,
              onPressed: () => setState(_resetGame),
            ),
          ],
        ),
      ),
    );
  }
}

// === HOME SCREEN CARD WIDGET ===
class NovaGamesCard extends StatelessWidget {
  const NovaGamesCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showNovaGamesModal(context),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              NeoColors.gold.withValues(alpha: 51 / 255),
              Color(0x11FFFFFF),
              Color(0x229B6BFF),
            ],
          ),
          border: Border.all(
            color: NeoColors.gold.withValues(alpha: 68 / 255),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 20,
              spreadRadius: -4,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [NeoColors.gold, NeoColors.goldDeep],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: NeoColors.gold.withValues(alpha: 85 / 255),
                    blurRadius: 16,
                  ),
                ],
              ),
              child: const Icon(Icons.sports_esports_rounded, size: 28, color: Color(0xFF1A1100)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'NOVA ARENA',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          color: NeoColors.primaryText,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: NeoColors.gold.withValues(alpha: 51 / 255),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'MINI GAMES',
                          style: TextStyle(
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.8,
                            color: NeoColors.gold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Catur Multiplayer 1v1 & Block Blast Puzzle',
                    style: TextStyle(
                      fontSize: 11.5,
                      color: NeoColors.secondaryText,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.chevron_right, color: NeoColors.gold, size: 24),
          ],
        ),
      ),
    );
  }
}
