import '../theme.dart';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';

class NeoGlassOverlay extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final double blurSigma;

  const NeoGlassOverlay({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(24),
    this.borderRadius = 20,
    this.blurSigma = 24,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                NeoColors.darkBg.withValues(alpha: 240 / 255),
                Color(0xF0141628),
              ],
            ),
            border: Border.all(
              color: NeoColors.gold.withValues(alpha: 68 / 255),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(borderRadius),
            boxShadow: const [
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 36,
                offset: Offset(0, 16),
                spreadRadius: -8,
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  static Widget sheet({
    required Widget child,
    double maxHeightFactor = 0.72,
    required BuildContext context,
  }) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: FractionallySizedBox(
        heightFactor: maxHeightFactor,
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    NeoColors.darkBg.withValues(alpha: 240 / 255),
                    Color(0xF0141628),
                  ],
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                border: Border(
                  top: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                  left: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                  right: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}
