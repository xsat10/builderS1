import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/news_item.dart';
import '../providers/news_provider.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

class NeoNewsCarousel extends StatefulWidget {
  const NeoNewsCarousel({super.key});

  @override
  State<NeoNewsCarousel> createState() => _NeoNewsCarouselState();
}

class _NeoNewsCarouselState extends State<NeoNewsCarousel> {
  final PageController _pageCtrl = PageController();
  Timer? _timer;
  Timer? _refreshTimer;
  int _current = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NewsProvider>().loadNews();
    });
    _startTimer();
    // Segarkan berita secara berkala supaya otomatis mengambil yang
    // terbaru (tidak "itu-itu aja"). Api external CNN/berita-indo-api
    // mengembalikan berita terbaru; reload berkala memunculkan judul baru.
    _refreshTimer = Timer.periodic(const Duration(seconds: 45), (_) {
      if (!mounted) return;
      context.read<NewsProvider>().loadNews();
    });
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted) return;
      final provider = context.read<NewsProvider>();
      final news =
          provider.berita.isNotEmpty ? provider.berita : provider.news;
      if (news.isEmpty) return;
      if (_current < news.length - 1) {
        _pageCtrl.nextPage(
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
        );
      } else {
        _pageCtrl.animateToPage(
          0,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _refreshTimer?.cancel();
    _pageCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<NewsProvider>(
      builder: (_, provider, _) {
        final news = provider.berita.isNotEmpty ? provider.berita : provider.news;
        if (news.isEmpty) return const SizedBox.shrink();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 96,
              child: PageView.builder(
                controller: _pageCtrl,
                onPageChanged: (i) => setState(() => _current = i),
                itemCount: news.length,
                itemBuilder: (ctx, i) => _NewsCard(item: news[i]),
              ),
            ),
            const SizedBox(height: 8),
            _Dots(count: news.length, current: _current),
          ],
        );
      },
    );
  }
}

class _NewsCard extends StatelessWidget {
  final NewsItem item;
  const _NewsCard({required this.item});

  Future<void> _launch(BuildContext context) async {
    final url = item.buttonUrl;
    if (url == null || url.isEmpty) return;
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  static const _fallbackColors = [
    [Color(0xFFFFD900), Color(0xFFE6C200)],
    [Color(0xFFFF5C8A), Color(0xFFE04A75)],
    [Color(0xFF5B8CFF), Color(0xFF4A7AE6)],
    [Color(0xFF55E878), Color(0xFF44D666)],
    [Color(0xFFFF9F43), Color(0xFFE68C36)],
    [Color(0xFF9B6BFF), Color(0xFF8658E6)],
  ];

  List<Color> _fallbackGradient() {
    final idx = item.id.hashCode.abs() % _fallbackColors.length;
    return _fallbackColors[idx];
  }

  bool get _showButton =>
      item.showButton &&
      item.buttonText != null &&
      (item.buttonUrl?.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    final bgGradient = _fallbackGradient();
    final imageUrl = (item.backgroundImageUrl ?? item.imageUrl);
    final hasImage = imageUrl != null && imageUrl.isNotEmpty;

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withValues(alpha: 0.08),
              Colors.white.withValues(alpha: 0.03),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.12),
            width: 1,
          ),
        ),
        child: Row(
            children: [
              if (hasImage) ...[
                SizedBox(
                  width: 84,
                  height: double.infinity,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: bgGradient,
                          ),
                        ),
                        child: const Icon(
                          Icons.article_outlined,
                          color: Colors.black54,
                          size: 30,
                        ),
                      ),
                      loadingBuilder: (ctx, child, progress) {
                        if (progress == null) return child;
                        return Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: bgGradient,
                            ),
                          ),
                          child: const Center(
                            child: NeoBlockLoader(
                              blockSize: 6,
                              c0: NeoColors.black,
                              c1: NeoColors.yellow,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 4,
                            height: 4,
                            decoration: BoxDecoration(
                              color: NeoColors.yellow,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'BERITA',
                            style: TextStyle(
                              fontSize: 7,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.2,
                              color: NeoColors.gold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(
                        item.title,
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          color: NeoColors.primaryText,
                          height: 1.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        item.description,
                        style: TextStyle(
                          fontSize: 9.5,
                          color: NeoColors.secondaryText,
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (_showButton) ...[
                        const SizedBox(height: 6),
                        GestureDetector(
                          onTap: () => _launch(context),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                item.buttonText!,
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w900,
                                  color: NeoColors.gold,
                                ),
                              ),
                              const SizedBox(width: 3),
                              Icon(
                                Icons.arrow_forward_rounded,
                                size: 11,
                                color: NeoColors.gold,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
    );
  }
}

class _Dots extends StatelessWidget {
  final int count;
  final int current;
  const _Dots({required this.count, required this.current});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final active = i == current;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: active ? 20 : 8,
          height: 8,
          decoration: BoxDecoration(
            color: active ? NeoColors.yellow : NeoColors.grey,
            border: Border.all(color: NeoColors.border, width: 2),
            borderRadius: BorderRadius.circular(NeoRadius.sm),
          ),
        );
      }),
    );
  }
}
