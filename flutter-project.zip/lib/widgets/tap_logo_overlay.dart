// lib/widgets/tap_logo_overlay.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TapLogoOverlay extends StatefulWidget {
  final int tapsToUnlock;
  final int? requiredTaps;
  final int maxBubbles;
  final VoidCallback? onSecretTap;
  final VoidCallback? onTap;
  final String? logoAsset;
  final String? imagePath;
  final double size;
  final double? logoSize;
  final Widget? child;
  final Color neonColor;
  final Color glowColor;
  final String? label;
  final String? text;
  final Duration resetAfter;
  final Color? innerColor;
  final Color? outerColor;

  const TapLogoOverlay({
    super.key,
    this.tapsToUnlock = 5,
    this.requiredTaps,
    this.maxBubbles = 5,
    this.onSecretTap,
    this.onTap,
    this.logoAsset,
    this.imagePath,
    this.size = 120,
    this.logoSize,
    this.child,
    this.neonColor = const Color(0xFF00E5FF),
    this.glowColor = const Color(0xFF2979FF),
    this.label,
    this.text,
    this.resetAfter = const Duration(milliseconds: 1500),
    this.innerColor,
    this.outerColor,
  });

  @override
  State<TapLogoOverlay> createState() => _TapLogoOverlayState();
}

class _TapLogoOverlayState extends State<TapLogoOverlay>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _scaleController;
  late Animation<double> _scaleAnim;

  int _tapCount = 0;
  Timer? _resetTimer;
  final List<AnimationController> _ripples = [];
  bool _unlocked = false;

  double get _effectiveSize => widget.logoSize ?? widget.size;
  int get _effectiveTaps => widget.requiredTaps ?? widget.tapsToUnlock;
  String? get _effectiveAsset => widget.logoAsset ?? widget.imagePath;
  String? get _effectiveLabel => widget.label ?? widget.text;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 130),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.90).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _scaleController.dispose();
    _resetTimer?.cancel();
    for (final r in _ripples) {
      r.dispose();
    }
    super.dispose();
  }

  void _handleTap() {
    HapticFeedback.selectionClick();
    _scaleController.forward().then((_) => _scaleController.reverse());

    final ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
    _ripples.add(ctrl);
    while (_ripples.length > widget.maxBubbles) {
      _ripples.removeAt(0).dispose();
    }

    _tapCount++;
    widget.onTap?.call();

    _resetTimer?.cancel();
    _resetTimer = Timer(widget.resetAfter, () {
      if (mounted) setState(() => _tapCount = 0);
    });

    if (!_unlocked && _tapCount >= _effectiveTaps) {
      _unlocked = true;
      HapticFeedback.heavyImpact();
      widget.onSecretTap?.call();
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _tapCount = 0;
            _unlocked = false;
          });
        }
      });
    }
    setState(() {});
  }

  Widget _buildLogoContent() {
    if (_effectiveAsset != null) {
      return ClipOval(
        child: Image.asset(
          _effectiveAsset!,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _defaultIcon(),
        ),
      );
    }
    return _defaultIcon();
  }

  Widget _defaultIcon() {
    return Icon(
      Icons.touch_app_rounded,
      size: _effectiveSize * 0.4,
      color: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    // ✅ FIX UTAMA: Kalau ada `child`, langsung pakai child TANPA dibungkus Container
    // Ini mencegah child (misal Text / ShaderMask) ke-render sebagai kotak
    if (widget.child != null) {
      return GestureDetector(
        onTap: _handleTap,
        behavior: HitTestBehavior.opaque,
        child: widget.child!,
      );
    }

    // Kalau gak ada child, pakai logo bulat biasa
    final displaySize = _effectiveSize * 1.8;

    return GestureDetector(
      onTap: _handleTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: displaySize,
        height: displaySize,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Ripple layer
            ..._ripples.map((ctrl) => AnimatedBuilder(
                  animation: ctrl,
                  builder: (context, _) {
                    final v = ctrl.value;
                    return Container(
                      width: displaySize * 0.6 * v,
                      height: displaySize * 0.6 * v,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: widget.neonColor.withOpacity((1 - v) * 0.5),
                          width: 1.8,
                        ),
                      ),
                    );
                  },
                )),

            // Pulse glow
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, _) {
                final p = _pulseController.value;
                return Container(
                  width: _effectiveSize * (1.35 + 0.10 * p),
                  height: _effectiveSize * (1.35 + 0.10 * p),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        widget.neonColor.withOpacity(0.15 + 0.10 * p),
                        widget.glowColor.withOpacity(0.05),
                        Colors.transparent,
                      ],
                    ),
                  ),
                );
              },
            ),

            // Ring neon
            AnimatedBuilder(
              animation: _pulseController,
              builder: (context, _) {
                final p = _pulseController.value;
                return Container(
                  width: _effectiveSize * 1.12,
                  height: _effectiveSize * 1.12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: widget.neonColor.withOpacity(0.55 + 0.35 * p),
                      width: 1.6,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: widget.neonColor.withOpacity(0.35 + 0.25 * p),
                        blurRadius: 22 + 12 * p,
                        spreadRadius: 1.5,
                      ),
                    ],
                  ),
                );
              },
            ),

            // Logo bulat
            AnimatedBuilder(
              animation: _scaleAnim,
              builder: (context, child) => Transform.scale(
                scale: _scaleAnim.value,
                child: child,
              ),
              child: Container(
                width: _effectiveSize,
                height: _effectiveSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.innerColor ?? Colors.transparent,
                ),
                child: _buildLogoContent(),
              ),
            ),

            // Label
            if (_effectiveLabel != null && _effectiveLabel!.isNotEmpty)
              Positioned(
                bottom: 6,
                child: Text(
                  _tapCount > 0
                      ? '$_tapCount / $_effectiveTaps'
                      : _effectiveLabel!,
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 1.5,
                    color: widget.neonColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

            // Counter badge
            if (_tapCount > 0 && _effectiveTaps > 1)
              Positioned(
                top: 4,
                right: 4,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF020617).withOpacity(0.85),
                    border: Border.all(
                      color: widget.neonColor,
                      width: 1.5,
                    ),
                  ),
                  child: Text(
                    '$_tapCount',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: widget.neonColor,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}