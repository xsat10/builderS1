import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/neo_skin.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';

/// Buka Theme Picker sebagai glass bottom sheet.
///
/// Hanya 3 theme yang ditampilkan:
///   1. GOLD & EMERALD
///   2. AMETHYST & VIOLET
///   3. NEON CYBER
///
/// Pemilihan langsung diterapkan + disimpan (SharedPreferences `neo_skin_id`)
/// oleh NeoThemeProvider — aplikasi berubah saat itu juga tanpa restart.
Future<void> showNeoThemePicker(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.55),
    useSafeArea: true,
    builder: (_) => const _NeoThemePickerSheet(),
  );
}

class _NeoThemePickerSheet extends StatefulWidget {
  const _NeoThemePickerSheet();

  @override
  State<_NeoThemePickerSheet> createState() => _NeoThemePickerSheetState();
}

class _NeoThemePickerSheetState extends State<_NeoThemePickerSheet> {
  @override
  Widget build(BuildContext context) {
    return _GlassSheet(
      child: LayoutBuilder(
        builder: (context, cons) {
          final maxW = cons.maxWidth;
          final wide = maxW >= 720;
          final cardWidthLimit = wide ? 460.0 : null;

          Widget tcard(NeoPalette p) {
            final card = _ThemeCard(palette: p, wide: wide);
            if (cardWidthLimit == null) return card;
            return Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: card,
              ),
            );
          }

          return SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(maxW >= 640 ? 32 : 20, 12, maxW >= 640 ? 32 : 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _PickerHandle(),
                const SizedBox(height: 12),
                const _PickerHeader(),
                const SizedBox(height: 16),
                tcard(NeoSkin.goldEmerald),
                const SizedBox(height: 12),
                tcard(NeoSkin.amethystViolet),
                const SizedBox(height: 12),
                tcard(NeoSkin.neonCyber),
                if (wide) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Themes are applied instantly · stored locally',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 10,
                      letterSpacing: 0.8,
                      color: NeoColors.textMuted,
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Cangkang glass sheet theme picker — blur + palet aktif + border + glow.
class _GlassSheet extends StatelessWidget {
  final Widget child;
  const _GlassSheet({required this.child});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<NeoThemeProvider>().palette;
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 28, sigmaY: 28),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                p.background.withValues(alpha: 0.97),
                p.backgroundSecondary.withValues(alpha: 0.99),
                p.surface.withValues(alpha: 0.96),
              ],
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
            border: Border.all(color: p.border, width: 1),
            boxShadow: [
              BoxShadow(
                color: p.glow.withValues(alpha: 0.12),
                blurRadius: 34,
                offset: const Offset(0, -6),
              ),
            ],
          ),
          child: SafeArea(top: false, child: child),
        ),
      ),
    );
  }
}

class _PickerHandle extends StatelessWidget {
  const _PickerHandle();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 46,
        height: 4,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              NeoColors.goldBright.withValues(alpha: 0.9),
              NeoColors.goldDeep,
            ],
          ),
          borderRadius: BorderRadius.circular(4),
        ),
      ),
    );
  }
}

class _PickerHeader extends StatelessWidget {
  const _PickerHeader();

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 640;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'THEMES',
            style: TextStyle(
              fontSize: isWide ? 22 : 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
              color: NeoColors.primaryText,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'Choose your NovaCore appearance',
            style: TextStyle(
              fontSize: 12,
              letterSpacing: 0.6,
              color: NeoColors.secondaryText,
            ),
          ),
        ],
      ),
    );
  }
}

/// Satu referensi theme: preview mini NovaCore + palet + tombol pilih.
class _ThemeCard extends StatelessWidget {
  final NeoPalette palette;
  final bool wide;

  const _ThemeCard({required this.palette, required this.wide});

  @override
  Widget build(BuildContext context) {
    final tp = context.watch<NeoThemeProvider>();
    final active = tp.skinId == palette.id;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            palette.background,
            palette.backgroundSecondary,
            palette.surface,
          ],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: active ? palette.borderStrong : palette.borderSubtle,
          width: active ? 1.6 : 1,
        ),
        boxShadow: [
          if (active)
            BoxShadow(
              color: palette.glow.withValues(alpha: 0.35),
              blurRadius: 26,
              spreadRadius: 0,
            ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.30),
            blurRadius: 18,
            offset: const Offset(0, 8),
            spreadRadius: -4,
          ),
        ],
      ),
      child: InkWell(
        onTap: () => tp.setSkin(palette.id),
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: EdgeInsets.all(wide ? 22 : 16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 4),
                    _PreviewMini(palette: palette),
                    const SizedBox(height: 12),
                    Text(
                      palette.label,
                      maxLines: 2,
                      style: TextStyle(
                        fontSize: wide ? 16 : 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: palette.id == NeoSkinId.goldEmerald ? 1.2 : 1,
                        color: palette.textPrimary,
                      ),
                    ),
                    if (palette.subtitle.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        palette.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10.5,
                          letterSpacing: 0.4,
                          color: palette.textSecondary,
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    _SwatchRow(palette: palette),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              _SelectBadge(palette: palette, active: active),
            ],
          ),
        ),
      ),
    );
  }
}

/// Mini preview yang memperlihatkan karakter NovaCore (glass card + navbar).
class _PreviewMini extends StatelessWidget {
  final NeoPalette palette;
  const _PreviewMini({required this.palette});

  @override
  Widget build(BuildContext context) {
    final p = palette;
    return Container(
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: p.border, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: p.primary,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: p.glow.withValues(alpha: 0.8),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  'NovaCore',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    color: p.textPrimary,
                  ),
                ),
                const Spacer(),
                Text(
                  '◆',
                  style: TextStyle(
                    fontSize: 6,
                    color: p.selected,
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: p.surfaceGlass,
                borderRadius: BorderRadius.circular(9),
                border: Border.all(color: p.borderSubtle, width: 1),
              ),
              child: Row(
                children: [
                  Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [p.primary, p.secondary],
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Glass Card',
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        color: p.textSecondary,
                      ),
                    ),
                  ),
                  Container(
                    height: 4,
                    width: 26,
                    decoration: BoxDecoration(
                      color: p.inputBorder,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: p.surface,
              border: Border(
                top: BorderSide(color: p.borderSubtle, width: 1),
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _miniNavItem(p: p, icon: Icons.home_rounded, label: 'HOME', active: true),
                _miniNavItem(p: p, icon: Icons.add_rounded, label: 'ADD', active: false),
                _miniNavItem(p: p, icon: Icons.devices_rounded, label: 'DEVICE', active: false),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniNavItem({
    required NeoPalette p,
    required IconData icon,
    required String label,
    required bool active,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          size: 11,
          color: active ? p.navbarActive : p.navbarInactive,
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            fontSize: 6.2,
            fontWeight: active ? FontWeight.w800 : FontWeight.w600,
            letterSpacing: 0.6,
            color: active ? p.navbarActive : p.navbarInactive,
          ),
        ),
      ],
    );
  }
}

class _SwatchRow extends StatelessWidget {
  final NeoPalette palette;
  const _SwatchRow({required this.palette});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _swatch(palette.primary),
        const SizedBox(width: 6),
        _swatch(palette.secondary),
        const SizedBox(width: 6),
        _swatch(palette.accent),
        const SizedBox(width: 6),
        _swatch(palette.glow),
      ],
    );
  }

  Widget _swatch(Color c) {
    return Container(
      width: 18,
      height: 18,
      decoration: BoxDecoration(
        color: c,
        shape: BoxShape.circle,
        border: Border.all(color: palette.borderSubtle, width: 1),
        boxShadow: [
          BoxShadow(
            color: c.withValues(alpha: 0.45),
            blurRadius: 8,
          ),
        ],
      ),
    );
  }
}

/// Bulatan status pilihan: check icon saat aktif, panah halus saat tidak.
class _SelectBadge extends StatelessWidget {
  final NeoPalette palette;
  final bool active;

  const _SelectBadge({required this.palette, required this.active});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 240),
      curve: Curves.easeOutBack,
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: active
            ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [palette.primary, palette.secondary],
              )
            : null,
        color: active ? null : palette.surfaceGlass,
        border: Border.all(
          color: active ? palette.selectedBorder : palette.borderSubtle,
          width: active ? 1.6 : 1,
        ),
        boxShadow: active
            ? [
                BoxShadow(
                  color: palette.glow.withValues(alpha: 0.5),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
              ]
            : null,
      ),
      child: Icon(
        active ? Icons.check_rounded : Icons.arrow_forward_ios_rounded,
        size: active ? 18 : 13,
        color: active ? palette.textOnAccent : palette.textMuted,
      ),
    );
  }
}
