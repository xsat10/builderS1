import 'package:flutter/material.dart';
import '../theme.dart';

class NeoBadge extends StatelessWidget {
  final String label;
  final Color bgColor;
  final Color textColor;

  const NeoBadge({
    super.key,
    required this.label,
    this.bgColor = NeoColors.black,
    this.textColor = NeoColors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        border: Border.all(color: NeoColors.black, width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: textColor)),
    );
  }
}
