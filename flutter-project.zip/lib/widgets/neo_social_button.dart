import 'package:flutter/material.dart';
import '../theme.dart';

class NeoSocialButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  const NeoSocialButton({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(NeoSpacing.md),
            decoration: BoxDecoration(
              color: isDark ? NeoColors.surface : NeoColors.white,
              border: Border.all(
                color: isDark ? NeoColors.line : NeoColors.border,
                width: NeoTheme.borderWidth,
              ),
              borderRadius: BorderRadius.circular(NeoRadius.xl),
              boxShadow: NeoShadows.smD(isDark),
            ),
            child: Icon(icon, size: 24, color: Theme.of(context).colorScheme.primary),
          ),
          const SizedBox(height: NeoSpacing.xs + 2),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: NeoColors.grey,
            ),
          ),
        ],
      ),
    );
  }
}
