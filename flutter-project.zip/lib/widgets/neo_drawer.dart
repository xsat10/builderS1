import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/connection_provider.dart';
import '../providers/theme_provider.dart';
import '../models/user.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_feature_config.dart';
import 'neo_help_sheet.dart';
import 'neo_role_badge.dart';
import 'neo_role_ring.dart';
import '../screens/role_ring_page.dart';

/// NeoDrawer — sidebar "Senat" Romawi imperial yang bersih:
/// panel dobel lembayung penuh (tanpa blur tepi), medali emas untuk menu,
/// tipografi Cinzel, dan ring sesuai role pada avatar (sama seperti home).
class NeoDrawer extends StatelessWidget {
  final void Function(int tabIndex)? onNavigate;
  final VoidCallback? onAccount;
  final int activeIndex;

  const NeoDrawer({
    super.key,
    this.onNavigate,
    this.onAccount,
    this.activeIndex = 0,
  });

  // Palet Senat — marmer, emas, dan lembayung Romawi.
  static final _gold = NeoColors.gold;
  static const _goldBright = Color(0xFFF3D98A);
  static const _goldDeep = Color(0xFFBB8C2E);
  static final _ivory = NeoColors.marble;
  static const _ink = Color(0xFF180E26);
  static const _velvetTop = Color(0xFF241A38);
  static const _velvetMid = Color(0xFF120C1D);
  static const _velvetBottom = Color(0xFF2A1938);
  static final _hairline = NeoColors.gold.withValues(alpha: 89 / 255);

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final conn = context.watch<ConnectionProvider>();
    final user = auth.user;
    final role = user?.role ?? 'member';
    const radius = BorderRadius.horizontal(right: Radius.circular(26));
    final width = (MediaQuery.of(context).size.width * 0.74).clamp(
      296.0,
      392.0,
    );

    return Drawer(
      width: width,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(borderRadius: radius),
      child: ClipRRect(
        borderRadius: radius,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
                colors: skin.isBubbleGum
                  ? [palette.background, palette.surface, const Color(0xFF1D1022)]
                  : [_velvetTop, _velvetMid, _velvetBottom],
            ),
            border: Border(
              right: BorderSide(
                color: skin.isBubbleGum
                    ? palette.primary.withValues(alpha: 0.65)
                    : NeoColors.gold.withValues(alpha: 102 / 255),
                width: 1,
              ),
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                _buildHeader(user, conn, role),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 18, vertical: 4),
                  child: _OrnamentDivider(),
                ),
                Expanded(child: _buildMenuSection(context, role)),
                _buildLogout(context, auth),
                _buildFooter(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(User? user, ConnectionProvider conn, String role) {
    final displayId = user?.displayIdentifier ?? 'Not logged in';
    final email = user?.email ?? '';
    final free = user?.isFree ?? false;

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '◆',
                style: TextStyle(fontSize: 7, color: _gold, height: 1),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'SENATVS NOVACORE',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cinzel(
                    textStyle: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.8,
                      color: _gold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                conn.connected ? '● ONLINE' : '● OFFLINE',
                style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                  color: conn.connected
                      ? const Color(0xFF6BE08A)
                      : const Color(0xFF9A9AB0),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _AvatarMedallion(role: role, user: user, free: free),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      displayId,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.cinzel(
                        textStyle: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                          color: _ivory,
                        ),
                      ),
                    ),
                    if (email.isNotEmpty &&
                        !email.toLowerCase().endsWith('@novacore.local')) ...[
                      const SizedBox(height: 3),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFFA9A3BE),
                        ),
                      ),
                    ],
                    const SizedBox(height: 8),
                    if (!free) _RoleChip(role: role),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMenuSection(BuildContext context, String role) {
    final isDev = role == 'developer';
    final isPartner = role == 'partner';
    final isReseller = role == 'reseller';
    final isVip = role == 'vip';
    final isModerator = role == 'moderator';

    Widget tile({
      required IconData icon,
      required String label,
      required String subtitle,
      required VoidCallback onTap,
      int? targetIndex,
      bool delayAfterPop = true,
    }) {
      final isActive = targetIndex != null && targetIndex == activeIndex;
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2.5),
        child: _SenateTile(
          icon: icon,
          label: label,
          subtitle: subtitle,
          isActive: isActive,
          onTap: () {
            Navigator.pop(context);
            if (delayAfterPop) {
              // Tunggu drawer tertutup, baru geser halaman — animasi jadi halus.
              Future.delayed(const Duration(milliseconds: 240), onTap);
            } else {
              onTap();
            }
          },
        ),
      );
    }

    final items = <Widget>[_SectionLabel('MENU')];

    if (isDev) {
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.admin_panel_settings_rounded,
          label: 'Manage',
          subtitle: 'Users, devices, news, senders',
          onTap: () => onNavigate?.call(6),
          targetIndex: 6,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    } else if (isPartner) {
      items.add(
        tile(
          icon: Icons.people_alt_rounded,
          label: 'Users',
          subtitle: 'Resellers, moderators & members',
          onTap: () => onNavigate?.call(FeatureConfig.partnersIndex),
          targetIndex: FeatureConfig.partnersIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.chat_bubble_rounded,
          label: 'Senders',
          subtitle: 'Sender akun di bawah Anda',
          onTap: () => onNavigate?.call(FeatureConfig.sendersIndex),
          targetIndex: FeatureConfig.sendersIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    } else if (isModerator) {
      items.add(
        tile(
          icon: Icons.forum_rounded,
          label: 'WhatsApp',
          subtitle: 'Ban & mode Protected',
          onTap: () => onNavigate?.call(FeatureConfig.whatsappIndex),
          targetIndex: FeatureConfig.whatsappIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.people_alt_rounded,
          label: 'Users',
          subtitle: 'Resellers, VIP & member Anda',
          onTap: () => onNavigate?.call(FeatureConfig.moderatorIndex),
          targetIndex: FeatureConfig.moderatorIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.chat_bubble_rounded,
          label: 'Senders',
          subtitle: 'Sender akun di bawah Anda',
          onTap: () => onNavigate?.call(FeatureConfig.sendersIndex),
          targetIndex: FeatureConfig.sendersIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    } else if (isReseller) {
      items.add(
        tile(
          icon: Icons.people_alt_rounded,
          label: 'Users',
          subtitle: 'Your members',
          onTap: () => onNavigate?.call(FeatureConfig.resellersIndex),
          targetIndex: FeatureConfig.resellersIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.chat_bubble_rounded,
          label: 'Senders',
          subtitle: 'Sender akun di bawah Anda',
          onTap: () => onNavigate?.call(FeatureConfig.sendersIndex),
          targetIndex: FeatureConfig.sendersIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    } else if (isVip) {
      items.add(
        tile(
          icon: Icons.devices_other_rounded,
          label: 'Device',
          subtitle: 'Device milik Anda',
          onTap: () => onNavigate?.call(FeatureConfig.deviceIndex),
          targetIndex: FeatureConfig.deviceIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.forum_rounded,
          label: 'WhatsApp',
          subtitle: 'Ban & mode WhatsApp',
          onTap: () => onNavigate?.call(FeatureConfig.whatsappIndex),
          targetIndex: FeatureConfig.whatsappIndex,
        ),
      );
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    } else {
      items.add(
        tile(
          icon: Icons.history_rounded,
          label: 'Activity',
          subtitle: 'Device activity log',
          onTap: () => onNavigate?.call(2),
          targetIndex: 2,
        ),
      );
      items.add(
        tile(
          icon: Icons.settings_rounded,
          label: 'Settings',
          subtitle: 'Profile & preferences',
          onTap: () => onAccount?.call(),
          targetIndex: FeatureConfig.settingsIndex,
        ),
      );
    }

    items.add(_SectionLabel('TENTANG'));
    items.add(
      tile(
        icon: Icons.emoji_events_rounded,
        label: 'ROLE & RING',
        subtitle: 'Hierarki peran & cincin kebesaran',
        delayAfterPop: false,
        onTap: () {
          Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => const RoleRingPage()));
        },
      ),
    );
    items.add(_SectionLabel('BANTUAN'));
    items.add(
      tile(
        icon: Icons.live_help_rounded,
        label: 'FAQ',
        subtitle: 'Pertanyaan yang sering diajukan',
        delayAfterPop: false,
        onTap: () => showNeoFaqSheet(context),
      ),
    );
    items.add(
      tile(
        icon: Icons.info_rounded,
        label: 'INFO',
        subtitle: 'Tentang aplikasi & kontak',
        delayAfterPop: false,
        onTap: () => showNeoInfoSheet(context),
      ),
    );

    // Animasi khusus sidebar: item menu masuk satu per satu secara halus
    // (geser dari kiri + fade), halaman konten tidak ikut dianimasikan.
    final staggered = <Widget>[];
    for (var i = 0; i < items.length; i++) {
      staggered.add(_RevealItem(index: i, child: items[i]));
    }

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 4),
      physics: const ClampingScrollPhysics(),
      children: staggered,
    );
  }

  Widget _buildLogout(BuildContext context, AuthProvider auth) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
      child: NeoButton(
        label: 'LOG OUT',
        roman: !skin.isBubbleGum,
        bgColor: skin.isBubbleGum ? palette.primary : NeoColors.gold,
        textColor: skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink,
        height: 44,
        fontSize: 13,
        icon: Icons.logout_rounded,
        onPressed: () async {
          await auth.logout();
          if (context.mounted) {
            Navigator.of(
              context,
            ).pushNamedAndRemoveUntil('/login', (route) => false);
          }
        },
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(width: 26, height: 1, color: _hairline),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Text('◆', style: TextStyle(fontSize: 6, color: _gold)),
          ),
          Text(
            'NOVACORE · v2.0',
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.4,
              color: _gold.withValues(alpha: 0.6),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Text('◆', style: TextStyle(fontSize: 6, color: _gold)),
          ),
          Container(width: 26, height: 1, color: _hairline),
        ],
      ),
    );
  }
}

/// Avatar sidebar — ring menyala sesuai role (SAMA seperti di home).
/// Akun gratis ditampilkan polosan tanpa ring & tanpa badge.
class _AvatarMedallion extends StatelessWidget {
  final String role;
  final User? user;
  final bool free;

  const _AvatarMedallion({
    required this.role,
    required this.user,
    required this.free,
  });

  @override
  Widget build(BuildContext context) {
    final roleColor = NeoColors.roleColor(role);
    final initials = _initialsOf(user);

    Widget face(String initials, User? u) {
      return Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [roleColor, roleColor.withValues(alpha: 0.6)],
          ),
          shape: BoxShape.circle,
          border: Border.all(
            color: free ? const Color(0x33FFFFFF) : const Color(0x77FFFFFF),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(color: roleColor.withValues(alpha: 0.5), blurRadius: 16),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: (u?.avatar?.isNotEmpty ?? false)
            ? Image.network(
                u!.avatar!,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => Center(
                  child: Text(
                    initials,
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.darkCard,
                    ),
                  ),
                ),
              )
            : Center(
                child: Text(
                  initials,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: NeoColors.darkCard,
                  ),
                ),
              ),
      );
    }

    return SizedBox(
      width: 58,
      height: 58,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned.fill(
            child: free
                ? Container(
                    margin: const EdgeInsets.all(5),
                    child: face(initials, user),
                  )
                : NeoRoleRing(
                    role: role,
                    size: 58,
                    padding: const EdgeInsets.all(5),
                    child: face(initials, user),
                  ),
          ),
          if (!free)
            Positioned(
              right: -2,
              bottom: -2,
              child: NeoRoleBadge(role: role, size: 19),
            ),
        ],
      ),
    );
  }

  String _initialsOf(User? u) {
    final identifier = u?.displayIdentifier;
    if (identifier != null && identifier.startsWith('@')) {
      final name = identifier.substring(1);
      if (name.length >= 2) return name.substring(0, 2).toUpperCase();
      return name[0].toUpperCase();
    }
    final email = u?.email ?? '';
    if (email.contains('@')) {
      final parts = email.split('@').first.split('.');
      if (parts.length >= 2) {
        return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
      }
      if (parts.isNotEmpty) return parts[0][0].toUpperCase();
    }
    return '?';
  }
}

class _RoleChip extends StatelessWidget {
  final String role;
  const _RoleChip({required this.role});

  @override
  Widget build(BuildContext context) {
    final color = NeoColors.roleColor(role);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.5), width: 1),
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          fontSize: 8.5,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
          color: color,
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel(this.label);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 12, 7),
      child: Row(
        children: [
          Text(
            '◆',
            style: TextStyle(fontSize: 6, color: NeoDrawer._gold),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.cinzel(
              textStyle: TextStyle(
                fontSize: 9.5,
                fontWeight: FontWeight.w700,
                letterSpacing: 2.6,
                color: NeoDrawer._gold,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Container(height: 1, color: NeoDrawer._hairline)),
        ],
      ),
    );
  }
}

class _SenateTile extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;
  final bool isActive;

  const _SenateTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
    this.isActive = false,
  });

  @override
  State<_SenateTile> createState() => _SenateTileState();
}

class _SenateTileState extends State<_SenateTile> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final active = widget.isActive;
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            border: Border(
              left: BorderSide(
                color: active ? NeoDrawer._gold : Colors.transparent,
                width: 4,
              ),
            ),
          ),
          child: Row(
            children: [
              _CoinIcon(icon: widget.icon, size: 38, active: active),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.label,
                      style: GoogleFonts.cinzel(
                        textStyle: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.4,
                          color: NeoDrawer._ivory,
                        ),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w500,
                        color: Color(0xFFA9A3BE),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              CustomPaint(
                size: const Size(14, 14),
                painter: _ArrowTailPainter(
                  color: active
                      ? NeoDrawer._gold
                      : _hovered
                      ? NeoDrawer._gold.withValues(alpha: 0.8)
                      : NeoDrawer._gold.withValues(alpha: 0.35),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Koin emas menu — ikon dibungkus medali agar tak terasa kaku.
class _CoinIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final bool active;

  const _CoinIcon({
    required this.icon,
    required this.size,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withValues(alpha: 0.05),
        border: Border.all(
          color: active
              ? NeoDrawer._goldBright
              : NeoDrawer._gold.withValues(alpha: 0.45),
          width: active ? 1.4 : 1,
        ),
        boxShadow: [
          if (active)
            BoxShadow(color: NeoColors.gold.withValues(alpha: 51 / 255), blurRadius: 8)
          else
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.25),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
        ],
      ),
      child: Icon(
        icon,
        size: size * 0.5,
        color: active ? NeoDrawer._goldBright : NeoDrawer._gold,
      ),
    );
  }
}

/// Panah tipis kekaisaran (bukan chevron Material yang kaku).
class _ArrowTailPainter extends CustomPainter {
  final Color color;
  _ArrowTailPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round
      ..color = color;
    final mid = size.height / 2;
    canvas.drawLine(Offset(1, mid), Offset(size.width - 4, mid), paint);
    canvas.drawLine(
      Offset(size.width - 7, mid - 3),
      Offset(size.width - 3, mid),
      paint,
    );
    canvas.drawLine(
      Offset(size.width - 7, mid + 3),
      Offset(size.width - 3, mid),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _ArrowTailPainter oldDelegate) =>
      oldDelegate.color != color;
}

/// Garis ornamen Romawi dengan berlian emas di tengah.
class _OrnamentDivider extends StatelessWidget {
  const _OrnamentDivider();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Container(height: 1, color: NeoDrawer._hairline)),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Text(
            '◆',
            style: TextStyle(fontSize: 6, color: NeoDrawer._gold),
          ),
        ),
        Expanded(child: Container(height: 1, color: NeoDrawer._hairline)),
      ],
    );
  }
}

/// Entri animasi item sidebar — geser halus dari kiri + fade, bertingkat per indeks.
class _RevealItem extends StatefulWidget {
  final int index;
  final Widget child;

  const _RevealItem({required this.index, required this.child});

  @override
  State<_RevealItem> createState() => _RevealItemState();
}

class _RevealItemState extends State<_RevealItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _slide;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    final curve = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic);
    _slide = Tween<double>(begin: 0, end: 1).animate(curve);
    _fade = Tween<double>(begin: 0, end: 1).animate(_ctrl);
    Future.delayed(Duration(milliseconds: widget.index * 45), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      child: widget.child,
      builder: (context, child) {
        return Opacity(
          opacity: _fade.value,
          child: Transform.translate(
            offset: Offset((1 - _slide.value) * -16, 0),
            child: child,
          ),
        );
      },
    );
  }
}
