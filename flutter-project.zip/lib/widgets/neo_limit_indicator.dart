import 'package:flutter/material.dart';
import '../theme.dart';

class NeoLimitIndicator extends StatelessWidget {
  final String label;
  final int used;
  final int max;
  final bool showBar;

  const NeoLimitIndicator({
    super.key,
    required this.label,
    required this.used,
    required this.max,
    this.showBar = true,
  });

  double get ratio => max > 0 ? used / max : 0;
  bool get isNearLimit => ratio >= 0.8 && ratio < 1;
  bool get isAtLimit => ratio >= 1;

  String get display => max > 0 ? '$used / $max' : '$used / ∞';

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            Text(display, style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: isAtLimit ? NeoColors.pink : isNearLimit ? NeoColors.orange : NeoColors.black,
            )),
          ],
        ),
        if (showBar && max > 0) ...[
          const SizedBox(height: 6),
          Container(
            height: 10,
            decoration: BoxDecoration(
              color: NeoColors.white,
              border: Border.all(color: NeoColors.black, width: 2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: ratio.clamp(0, 1),
              child: Container(
                decoration: BoxDecoration(
                  color: isAtLimit ? NeoColors.pink : isNearLimit ? NeoColors.orange : NeoColors.green,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ),
          if (isNearLimit)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('LIMIT NEARLY REACHED', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: NeoColors.orange)),
            ),
          if (isAtLimit)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('LIMIT REACHED', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: NeoColors.pink)),
            ),
        ],
      ],
    );
  }
}
