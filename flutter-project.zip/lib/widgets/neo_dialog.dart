import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_button.dart';

class NeoDialog {
  static Future<bool?> show({
    required BuildContext context,
    required String title,
    required String message,
    String cancelLabel = 'CANCEL',
    String confirmLabel = 'CONFIRM',
    Color confirmColor = NeoColors.pink,
  }) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      NeoColors.darkBg.withValues(alpha: 242 / 255),
                      const Color(0xF2141628),
                    ],
                  ),
                  border: Border.all(
                    color: NeoColors.gold.withValues(alpha: 68 / 255),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 36,
                      offset: Offset(0, 16),
                      spreadRadius: -8,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: NeoColors.primaryText,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      message,
                      style: TextStyle(
                        fontSize: 13.5,
                        color: NeoColors.secondaryText,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: NeoButton(
                            label: cancelLabel,
                            bgColor: const Color(0x22FFFFFF),
                            textColor: NeoColors.primaryText,
                            height: 44,
                            fontSize: 13,
                            onPressed: () => Navigator.pop(ctx, false),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: NeoButton(
                            label: confirmLabel,
                            bgColor: confirmColor,
                            height: 44,
                            fontSize: 13,
                            onPressed: () => Navigator.pop(ctx, true),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static Future<bool?> confirm(BuildContext context, {required String title, required String message}) {
    return show(
      context: context,
      title: title,
      message: message,
      confirmLabel: 'DELETE',
      confirmColor: NeoColors.pink,
    );
  }
}
