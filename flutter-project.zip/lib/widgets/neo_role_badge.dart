import 'package:flutter/material.dart';
import '../theme.dart';

/// Badge bulat tema Kaiser Romawi yang menempel di sudut avatar.
/// Berisi ikon peran (kode/jabat tangan/toko/orang) di atas cincin emas
/// dengan cahaya sesuai warna peran. Dipakai seragam di home, sidebar,
/// dan profil — ter-update realtime lewat AuthProvider.
class NeoRoleBadge extends StatelessWidget {
  final String role;
  final double size;
  final IconData? fallbackIcon;

  const NeoRoleBadge({
    super.key,
    required this.role,
    this.size = 20,
    this.fallbackIcon,
  });

  @override
  Widget build(BuildContext context) {
    final color = NeoColors.roleColor(role);
    final icon = NeoColors.roleIcon[role] ?? fallbackIcon ?? Icons.military_tech;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [NeoColors.gold, NeoColors.goldDeep],
        ),
        border: Border.all(
          color: NeoColors.marble.withValues(alpha: 0.9),
          width: size * 0.12,
        ),
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.6), blurRadius: 6, spreadRadius: 0.5),
          BoxShadow(color: Colors.black.withValues(alpha: 0.4), blurRadius: 4),
        ],
      ),
      child: Icon(icon, size: size * 0.56, color: const Color(0xFF2A1E00)),
    );
  }
}
