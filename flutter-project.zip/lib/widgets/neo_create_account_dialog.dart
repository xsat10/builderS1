import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_glass_overlay.dart';
import 'roman_sheet.dart';

class NeoCreateAccountDialog extends StatefulWidget {
  final String title;
  final Color accent;
  final bool showExpiry;
  final Set<String>? existingUsernames;
  final Future<Map<String, dynamic>> Function(String username, String password, String? expiresAt) onCreate;

  const NeoCreateAccountDialog({
    super.key,
    required this.title,
    required this.accent,
    required this.onCreate,
    this.showExpiry = false,
    this.existingUsernames,
  });

  @override
  State<NeoCreateAccountDialog> createState() => _NeoCreateAccountDialogState();
}

class _NeoCreateAccountDialogState extends State<NeoCreateAccountDialog> {
  final _usernameCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;
  bool _saving = false;
  bool _customDays = false;
  bool _usernameExists = false;
  String? _error;
  DateTime? _expiry;

  @override
  void initState() {
    super.initState();
    _expiry = _endOfDay(DateTime.now().add(const Duration(days: 30)));
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  DateTime _endOfDay(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59);

  void _setExpiryDays(int days) {
    setState(() {
      _customDays = false;
      _expiry = _endOfDay(DateTime.now().add(Duration(days: days)));
    });
  }

  void _clearExpiry() {
    setState(() {
      _customDays = false;
      _expiry = null;
    });
  }

  Future<void> _pickCustomDays() async {
    final days = await showDialog<int>(
      context: context,
      builder: (_) => const _CustomDaysDialog(),
    );
    if (days != null && mounted) {
      setState(() {
        _customDays = true;
        _expiry = _endOfDay(DateTime.now().add(Duration(days: days)));
      });
    }
  }

  Future<void> _pickExpiry() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _expiry ?? now.add(const Duration(days: 30)),
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 365 * 5)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: Theme.of(ctx).colorScheme.copyWith(
            primary: NeoColors.yellow,
            onPrimary: NeoColors.black,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null && mounted) {
      setState(() {
        _customDays = false;
        _expiry = _endOfDay(picked);
      });
    }
  }

  Future<void> _submit() async {
    final username = _usernameCtrl.text.trim();
    final password = _passCtrl.text;
    if (username.isEmpty || password.isEmpty) {
      setState(() => _error = 'Username and password required.');
      return;
    }
    if (_usernameExists) {
      setState(() => _error = 'User sudah ada. Gunakan username lain.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    final result = await widget.onCreate(username, password, _expiry?.toIso8601String());
    if (!mounted) return;
    if (result['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _saving = false;
        final errMsg = (result['error']?['message'] ?? '').toString();
        if (errMsg.toLowerCase().contains('already') ||
            errMsg.toLowerCase().contains('taken')) {
          _error = 'User sudah ada. Gunakan username lain.';
        } else {
          _error = errMsg.isEmpty ? 'Failed to create account.' : errMsg;
        }
      });
    }
  }

  void _onUsernameChanged(String value) {
    final exists = widget.existingUsernames
            ?.any((u) => u.toLowerCase() == value.trim().toLowerCase()) ??
        false;
    if (exists != _usernameExists) {
      setState(() => _usernameExists = exists);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RomanSheetTitle(widget.title, fontSize: 15),
              const SizedBox(height: 12),
              TextField(
                controller: _usernameCtrl,
                onChanged: _onUsernameChanged,
                style: TextStyle(fontSize: 15, color: NeoColors.marble),
                decoration: romanFieldDecoration(
                  label: 'Username',
                  icon: Icons.person_outline,
                ).copyWith(
                  errorText: _usernameExists ? 'User sudah ada' : null,
                  errorStyle: const TextStyle(
                    color: NeoColors.pink,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                textCapitalization: TextCapitalization.none,
              ),
              const SizedBox(height: NeoSpacing.sm),
              TextField(
                controller: _passCtrl,
                obscureText: _obscure,
                style: TextStyle(fontSize: 15, color: NeoColors.marble),
                decoration: romanFieldDecoration(
                  label: 'Password',
                  icon: Icons.lock_outline,
                ).copyWith(
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      color: NeoColors.gold.withValues(alpha: 153 / 255),
                      size: 20,
                    ),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
              ),
              if (widget.showExpiry) ...[
                const SizedBox(height: NeoSpacing.md),
                Row(
                  children: [
                    const Icon(Icons.event_outlined, size: 18, color: NeoColors.grey),
                    const SizedBox(width: NeoSpacing.sm),
                    Text('Masa aktif: ', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: isDark ? NeoColors.secondaryText : NeoColors.grey)),
                    Expanded(
                      child: TextButton(
                        onPressed: _pickExpiry,
                        child: Text(
                          _expiry == null
                              ? 'Tanpa batas'
                              : '${_expiry!.day.toString().padLeft(2, '0')}/${_expiry!.month.toString().padLeft(2, '0')}/${_expiry!.year}',
                          style: const TextStyle(fontWeight: FontWeight.w800),
                          textAlign: TextAlign.end,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: NeoSpacing.sm),
                Wrap(
                  spacing: NeoSpacing.sm,
                  runSpacing: NeoSpacing.sm,
                  children: [
                    _ExpiryChip(label: 'Tanpa batas', selected: _expiry == null, onTap: _clearExpiry),
                    _ExpiryChip(label: '30 hari', selected: !_customDays && _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 30)))), onTap: () => _setExpiryDays(30)),
                    _ExpiryChip(label: '90 hari', selected: !_customDays && _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 90)))), onTap: () => _setExpiryDays(90)),
                    _ExpiryChip(label: '1 tahun', selected: !_customDays && _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 365)))), onTap: () => _setExpiryDays(365)),
                    _ExpiryChip(label: 'Custom hari', selected: _customDays, onTap: _pickCustomDays),
                  ],
                ),
              ],
              if (_error != null) ...[
                const SizedBox(height: NeoSpacing.sm),
                Text(_error!, style: const TextStyle(color: NeoColors.pink, fontSize: 12, fontWeight: FontWeight.w700)),
              ],
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  NeoButton(
                    label: 'CANCEL',
                    bgColor: NeoColors.surfaceElevated,
                    textColor: NeoColors.primaryText,
                    height: 40,
                    fontSize: 14,
                    onPressed: _saving ? null : () => Navigator.of(context).pop(false),
                  ),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'CREATE',
                    bgColor: widget.accent,
                    textColor: NeoColors.white,
                    height: 40,
                    fontSize: 14,
                    roman: true,
                    loading: _saving,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomDaysDialog extends StatefulWidget {
  const _CustomDaysDialog();

  @override
  State<_CustomDaysDialog> createState() => _CustomDaysDialogState();
}

class _CustomDaysDialogState extends State<_CustomDaysDialog> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _submit() {
    final n = int.tryParse(_ctrl.text.trim());
    if (n != null && n > 0) Navigator.of(context).pop(n);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('MASA AKTIF', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: NeoColors.primaryText)),
              const SizedBox(height: 12),
              const Text('Berapa hari akun aktif sejak sekarang?', style: TextStyle(fontSize: 13, color: NeoColors.grey)),
              const SizedBox(height: NeoSpacing.md),
              TextField(
                controller: _ctrl,
                keyboardType: TextInputType.number,
                autofocus: true,
                onSubmitted: (_) => _submit(),
                decoration: const InputDecoration(labelText: 'Jumlah hari', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('BATAL')),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'SET',
                    height: 40,
                    fontSize: 14,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

class _ExpiryChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _ExpiryChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? NeoColors.yellow : Colors.transparent,
          border: Border.all(color: selected ? NeoColors.yellow : NeoColors.border, width: 2),
          borderRadius: BorderRadius.circular(NeoRadius.sm),
        ),
        child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: selected ? NeoColors.black : NeoColors.grey)),
      ),
    );
  }
}
