import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_glass_overlay.dart';

class NeoRolePickerDialog extends StatefulWidget {
  final String initialRole;
  final List<String> roles;
  final Future<Map<String, dynamic>> Function(String role) onSave;

  const NeoRolePickerDialog({
    super.key,
    required this.initialRole,
    this.roles = const ['partner', 'moderator', 'reseller', 'vip', 'member'],
    required this.onSave,
  });

  @override
  State<NeoRolePickerDialog> createState() => _NeoRolePickerDialogState();
}

class _NeoRolePickerDialogState extends State<NeoRolePickerDialog> {
  late String _role;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _role = widget.initialRole;
  }

  Future<void> _submit() async {
    if (_role == widget.initialRole) {
      Navigator.of(context).pop(false);
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    final result = await widget.onSave(_role);
    if (!mounted) return;
    if (result['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _saving = false;
        _error = result['error']?['message'] ?? 'Gagal mengubah role.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.black;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: NeoColors.yellow,
                      border: Border.all(color: lineColor, width: 2),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: const Icon(Icons.badge_outlined, size: 18, color: NeoColors.black),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'UBAH ROLE',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, letterSpacing: 1, color: NeoColors.primaryText),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                'Role saat ini:',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
              const SizedBox(height: 8),
              for (final role in widget.roles) ...[
                _RoleOption(
                  role: role,
                  selected: _role == role,
                  onTap: () => setState(() => _role = role),
                ),
                const SizedBox(height: 8),
              ],
              Text(
                '* Hanya role di bawah jabatan kamu yang bisa dipasang. Server akan menolak bila tidak sesuai.',
                style: TextStyle(
                  fontSize: 10,
                  height: 1.4,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: NeoSpacing.sm),
                Text(
                  _error!,
                  style: const TextStyle(color: NeoColors.pink, fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ],
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  NeoButton(
                    label: 'CANCEL',
                    bgColor: NeoColors.surfaceElevated,
                    textColor: NeoColors.primaryText,
                    height: 40,
                    fontSize: 14,
                    onPressed: _saving ? null : () => Navigator.of(context).pop(false),
                  ),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'SAVE',
                    bgColor: NeoColors.goldDeep,
                    textColor: NeoColors.white,
                    height: 40,
                    fontSize: 14,
                    loading: _saving,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleOption extends StatelessWidget {
  final String role;
  final bool selected;
  final VoidCallback onTap;

  const _RoleOption({
    required this.role,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.black;
    final color = NeoColors.roleColor(role);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? color : (isDark ? NeoColors.black : NeoColors.cream),
          border: Border.all(
            color: selected ? color : lineColor,
            width: selected ? NeoTheme.borderWidth : 1.5,
          ),
          borderRadius: BorderRadius.circular(8),
          boxShadow: selected ? [BoxShadow(color: lineColor, offset: const Offset(3, 3), blurRadius: 0)] : null,
        ),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: NeoColors.black,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Icon(NeoColors.roleIcon[role] ?? Icons.person, size: 15, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    NeoColors.roleTitle[role] ?? 'AKUN',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: selected ? NeoColors.black : (isDark ? NeoColors.primaryText : NeoColors.black),
                    ),
                  ),
                  Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1,
                      color: selected ? NeoColors.black : NeoColors.grey,
                    ),
                  ),
                ],
              ),
            ),
            if (selected)
              const Icon(Icons.check_circle_rounded, size: 18, color: NeoColors.black),
          ],
        ),
      ),
    );
  }
}
