import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_service.dart';
import '../services/story_service.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

class StoryCreationSheet extends StatefulWidget {
  const StoryCreationSheet({super.key});

  @override
  State<StoryCreationSheet> createState() => _StoryCreationSheetState();
}

class _StoryCreationSheetState extends State<StoryCreationSheet> {
  final TextEditingController _textController = TextEditingController();
  final StoryService _storyService = StoryService();
  final ApiService _api = ApiService();
  final ImagePicker _picker = ImagePicker();
  bool _isSubmitting = false;
  String _selectedColor = '#1A1E38';

  // Media state: '' (teks saja), '_photo', '_video'
  String _mediaType = '';
  XFile? _mediaFile;
  String? _mediaUrl;

  static const List<String> _bgColors = [
    '#1A1E38',
    '#2D1B4E',
    '#0D3B2E',
    '#3B1A1A',
    '#1A2E3B',
    '#3B2E1A',
    '#2E1A3B',
    '#0D1B3B',
  ];

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  String get _contentType {
    if (_mediaType == 'photo')
      return _textController.text.trim().isEmpty ? 'photo' : 'photo_text';
    if (_mediaType == 'video')
      return _textController.text.trim().isEmpty ? 'video' : 'video_text';
    return 'text';
  }

  Future<void> _pickPhoto() async {
    final file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );
    if (file == null) return;
    setState(() {
      _mediaType = 'photo';
      _mediaFile = file;
      _mediaUrl = null;
    });
  }

  Future<void> _pickVideo() async {
    final file = await _picker.pickVideo(
      source: ImageSource.gallery,
      maxDuration: const Duration(minutes: 1),
    );
    if (file == null) return;
    setState(() {
      _mediaType = 'video';
      _mediaFile = file;
      _mediaUrl = null;
    });
  }

  Future<String?> _uploadMedia() async {
    if (_mediaFile == null) return null;
    final filename =
        'story_${DateTime.now().millisecondsSinceEpoch}_${_mediaFile!.name}';
    final result = await _api.uploadImage(
      _mediaFile!.path,
      filename: filename,
      kind: _mediaType == 'video' ? 'video' : 'image',
    );
    final url = (result['data']?['url'] as String?) ?? '';
    return url.isNotEmpty ? url : null;
  }

  Future<void> _submit() async {
    final text = _textController.text.trim();
    final hasMedia = _mediaFile != null;
    final hasText = text.isNotEmpty;
    if (!hasMedia && !hasText) return;

    setState(() => _isSubmitting = true);

    try {
      String? mediaUrl = _mediaUrl;
      if (hasMedia) {
        mediaUrl = await _uploadMedia();
        if (mediaUrl == null) {
          throw Exception('Gagal mengunggah media');
        }
      }

      final story = await _storyService.createStory(
        contentType: _contentType,
        textContent: hasText ? text : null,
        mediaUrl: mediaUrl,
        bgColor: _selectedColor,
      );
      if (!mounted) return;
      if (story != null) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Story berhasil dibuat!', style: GoogleFonts.inter()),
            backgroundColor: const Color(0xFF0D0D2B),
          ),
        );
      } else {
        throw Exception('Gagal membuat story');
      }
    } catch (e) {
      if (!mounted) return;
      if (e is StoryCreateException && e.code == 'USER_BANNED') {
        await showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: const Color(0xFF0D0D2B),
            title: Text(
              'Akun Anda Di Ban',
              style: GoogleFonts.cinzel(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Colors.red.shade300,
              ),
            ),
            content: Text(
              e.message,
              style: GoogleFonts.inter(color: Colors.white70),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'OK',
                  style: GoogleFonts.inter(
                    color: const Color(0xFFC9A55A),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        );
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text(e.toString().replaceFirst('Exception: ', ''), style: GoogleFonts.inter()),
          backgroundColor: Colors.red.shade700,
        ),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg = Color(int.parse(_selectedColor.replaceFirst('#', '0xFF')));

    return Container(
      height: MediaQuery.of(context).size.height * 0.72,
      decoration: const BoxDecoration(
        color: Color(0xFF0D0D2B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Title
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Buat Story',
              style: GoogleFonts.cinzel(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: const Color(0xFFC9A55A),
              ),
            ),
          ),
          // Media type selector
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                _MediaTypeButton(
                  icon: Icons.text_fields,
                  label: 'Teks',
                  selected: _mediaType == '',
                  onTap: () => setState(() => _mediaType = ''),
                ),
                const SizedBox(width: 10),
                _MediaTypeButton(
                  icon: Icons.photo_outlined,
                  label: 'Foto',
                  selected: _mediaType == 'photo',
                  onTap: _pickPhoto,
                ),
                const SizedBox(width: 10),
                _MediaTypeButton(
                  icon: Icons.videocam_outlined,
                  label: 'Video',
                  selected: _mediaType == 'video',
                  onTap: _pickVideo,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Preview area
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(16),
              ),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // Media preview
                  if (_mediaFile != null && _mediaType == 'photo')
                    Image.file(File(_mediaFile!.path), fit: BoxFit.cover)
                  else if (_mediaFile != null && _mediaType == 'video')
                    Container(
                      color: Colors.black87,
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.videocam,
                              color: Colors.white70,
                              size: 48,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Video siap diunggah',
                              style: GoogleFonts.inter(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    Center(
                      child: _textController.text.isEmpty
                          ? Text(
                              'Ketik sesuatu atau pilih foto/video',
                              style: GoogleFonts.cinzel(
                                fontSize: 20,
                                color: Colors.white24,
                              ),
                            )
                          : null,
                    ),
                  // Text overlay on media
                  if (_textController.text.isNotEmpty)
                    Center(
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(24),
                        color: Colors.black.withValues(alpha: 0.35),
                        child: Text(
                          _textController.text,
                          style: GoogleFonts.cinzel(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            height: 1.4,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Color picker
          SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: _bgColors.length,
              separatorBuilder: (_, _) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final c = _bgColors[index];
                final color = Color(int.parse(c.replaceFirst('#', '0xFF')));
                final isSelected = c == _selectedColor;
                return GestureDetector(
                  onTap: () => setState(() => _selectedColor = c),
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isSelected
                            ? const Color(0xFFC9A55A)
                            : Colors.white24,
                        width: isSelected ? 2.5 : 1,
                      ),
                    ),
                    child: isSelected
                        ? const Icon(
                            Icons.check,
                            color: Color(0xFFC9A55A),
                            size: 14,
                          )
                        : null,
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          // Text input
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TextField(
              controller: _textController,
              maxLength: 500,
              maxLines: 2,
              onChanged: (_) => setState(() {}),
              style: GoogleFonts.inter(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Tulis ceritamu (opsional)...',
                hintStyle: GoogleFonts.inter(color: Colors.white24),
                filled: true,
                fillColor: Colors.white.withValues(alpha: 0.05),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: Colors.white.withValues(alpha: 0.1),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: Colors.white.withValues(alpha: 0.1),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFFC9A55A)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Submit button
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed:
                    (_isSubmitting ||
                        (_textController.text.trim().isEmpty &&
                            _mediaFile == null))
                    ? null
                    : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC9A55A),
                  foregroundColor: NeoColors.ink,
                  disabledBackgroundColor: const Color(
                    0xFFC9A55A,
                  ).withValues(alpha: 0.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isSubmitting
                    ? const NeoBlockLoader(
                        compact: true,
                        size: 20,
                        c1: Color(0xFF0D0D2B),
                        label: '',
                      )
                    : Text(
                        'Bagikan Story',
                        style: GoogleFonts.cinzel(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
              ),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).padding.bottom + 16),
        ],
      ),
    );
  }
}

class _MediaTypeButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback? onTap;

  const _MediaTypeButton({
    required this.icon,
    required this.label,
    required this.selected,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: selected
                ? const Color(0xFFC9A55A).withValues(alpha: 0.15)
                : Colors.white.withValues(alpha: 0.05),
            border: Border.all(
              color: selected
                  ? const Color(0xFFC9A55A)
                  : Colors.white.withValues(alpha: 0.08),
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 20,
                color: selected ? const Color(0xFFC9A55A) : Colors.white54,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                  color: selected ? const Color(0xFFC9A55A) : Colors.white54,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
