import 'package:flutter/material.dart';

class NeoAnimatedEntry extends StatefulWidget {
  final Widget child;
  final int index;
  final Duration duration;

  const NeoAnimatedEntry({
    super.key,
    required this.child,
    this.index = 0,
    this.duration = const Duration(milliseconds: 300),
  });

  @override
  State<NeoAnimatedEntry> createState() => _NeoAnimatedEntryState();
}

class _NeoAnimatedEntryState extends State<NeoAnimatedEntry> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _opacity;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    final stagger = widget.index * 50;
    _ctrl = AnimationController(vsync: this, duration: widget.duration);
    _opacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _ctrl, curve: Interval(0, 0.6, curve: Curves.easeOut)),
    );
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero).animate(
      CurvedAnimation(parent: _ctrl, curve: Interval(0, 0.6, curve: Curves.easeOut)),
    );
    Future.delayed(Duration(milliseconds: stagger), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}
