import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';

class NeoRomanClock extends StatefulWidget {
  final double size;
  const NeoRomanClock({super.key, this.size = 44});

  @override
  State<NeoRomanClock> createState() => _NeoRomanClockState();
}

class _NeoRomanClockState extends State<NeoRomanClock> {
  Timer? _timer;
  late DateTime _now;

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sec = _now.second + _now.millisecond / 1000;
    final minutes = _now.minute + sec / 60;
    final hour = (_now.hour % 12) + minutes / 60;

    return CustomPaint(
      size: Size.square(widget.size),
      painter: _RomanClockPainter(
        hour: hour,
        minute: minutes,
        second: sec,
      ),
    );
  }
}

class _RomanClockPainter extends CustomPainter {
  final double hour;
  final double minute;
  final double second;

  _RomanClockPainter({
    required this.hour,
    required this.minute,
    required this.second,
  });

  static const _romans = ['XII', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI'];

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final gold = NeoColors.gold;
    final goldDeep = NeoColors.goldDeep;

    // Outer ring (border)
    final ringPaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFD98A), Color(0xFFC6A15B), Color(0xFF8A6D2B)],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = radius * 0.16;
    canvas.drawCircle(center, radius - ringPaint.strokeWidth / 2 - 0.5, ringPaint);

    // Inner face
    final facePaint = Paint()..color = const Color(0xFF0B0D1F);
    canvas.drawCircle(center, radius * 0.80, facePaint);

    // Tick marks
    final tickColor = Paint()
      ..color = gold.withValues(alpha: 0.9)
      ..strokeWidth = radius * 0.03
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 12; i++) {
      final angle = -pi / 2 + i * (2 * pi / 12);
      final outer = radius * 0.72;
      final inner = (i % 3 == 0) ? radius * 0.58 : radius * 0.64;
      canvas.drawLine(
        center + Offset(cos(angle), sin(angle)) * inner,
        center + Offset(cos(angle), sin(angle)) * outer,
        tickColor,
      );
    }

    // Roman numerals
    final numeralPainter = TextPainter(
      textDirection: TextDirection.ltr,
    );
    for (var i = 0; i < 12; i++) {
      final angle = -pi / 2 + i * (2 * pi / 12);
      final numeral = _romans[i];
      numeralPainter.text = TextSpan(
        text: numeral,
        style: TextStyle(
          fontSize: radius * (numeral.length > 2 ? 0.13 : 0.17),
          fontWeight: FontWeight.w800,
          color: gold,
        ),
      );
      numeralPainter.layout();
      final pos = center +
          Offset(cos(angle), sin(angle)) * radius * 0.46 -
          Offset(numeralPainter.width / 2, numeralPainter.height / 2);
      numeralPainter.paint(canvas, pos);
    }

    // Center hub
    canvas.drawCircle(center, radius * 0.05, Paint()..color = goldDeep);

    // Minute hand
    final minuteAngle = (minute / 60) * 2 * pi - pi / 2;
    final minutePaint = Paint()
      ..color = gold
      ..strokeWidth = radius * 0.05
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      center + Offset(cos(minuteAngle), sin(minuteAngle)) * radius * 0.58,
      minutePaint,
    );

    // Hour hand
    final hourAngle = (hour / 12) * 2 * pi - pi / 2;
    final hourPaint = Paint()
      ..color = NeoColors.primaryText
      ..strokeWidth = radius * 0.07
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      center + Offset(cos(hourAngle), sin(hourAngle)) * radius * 0.40,
      hourPaint,
    );

    // Second hand (thin accent)
    final secondAngle = (second / 60) * 2 * pi - pi / 2;
    final secondPaint = Paint()
      ..color = const Color(0xFF9B6BFF)
      ..strokeWidth = radius * 0.02
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      center,
      center + Offset(cos(secondAngle), sin(secondAngle)) * radius * 0.66,
      secondPaint,
    );

    // Hub cap
    canvas.drawCircle(center, radius * 0.015, Paint()..color = NeoColors.primaryText);
  }

  @override
  bool shouldRepaint(covariant _RomanClockPainter oldDelegate) {
    return oldDelegate.hour != hour ||
        oldDelegate.minute != minute ||
        oldDelegate.second != second;
  }
}
