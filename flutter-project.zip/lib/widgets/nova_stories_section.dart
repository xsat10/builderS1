import '../theme.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/story.dart';
import '../providers/auth_provider.dart';
import '../providers/device_provider.dart';
import '../services/story_service.dart';
import 'neo_block_loader.dart';
import 'neo_role_ring.dart';
import 'story_viewer.dart';
import 'story_creation_sheet.dart';

class NovaStoriesSection extends StatefulWidget {
  const NovaStoriesSection({super.key});

  @override
  State<NovaStoriesSection> createState() => _NovaStoriesSectionState();
}

class _NovaStoriesSectionState extends State<NovaStoriesSection> {
  final StoryService _storyService = StoryService();
  List<Story> _myStories = [];
  List<_StoryGroup> _groups = [];
  bool _loading = true;
  StreamSubscription<Map<String, dynamic>>? _storyNewSub;
  StreamSubscription<Map<String, dynamic>>? _storyDeletedSub;

  @override
  void initState() {
    super.initState();
    _loadStories();
    final socket = context.read<DeviceProvider>().socket;
    // Muat ulang otomatis saat ada story baru / story terhapus (mis. oleh
    // ban), supaya daftar tidak menampilkan cache lawas.
    _storyNewSub = socket.storyNewStream.listen((_) => _loadStories());
    _storyDeletedSub =
        socket.storyDeletedStream.listen((_) => _loadStories());
  }

  @override
  void dispose() {
    _storyNewSub?.cancel();
    _storyDeletedSub?.cancel();
    super.dispose();
  }

  Future<void> _loadStories() async {
    setState(() => _loading = true);
    final currentUserId = context.read<AuthProvider>().user?.id;
    final all = await _storyService.getStories();
    final mine = all.where((s) => s.userId == currentUserId).toList();
    final others = all.where((s) => s.userId != currentUserId).toList();
    final byUser = <String, List<Story>>{};
    for (final s in others) {
      (byUser[s.userId] ??= []).add(s);
    }
    final groups = byUser.entries
        .map((e) => _StoryGroup(e.key, e.value.first, e.value))
        .toList();
    if (mounted) {
      setState(() {
        _myStories = mine;
        _groups = groups;
        _loading = false;
      });
    }
  }

  void _showCreationSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const StoryCreationSheet(),
    ).then((_) => _loadStories());
  }

  void _openViewer(
    BuildContext context,
    List<Story> stories,
    int initialIndex,
  ) {
    final currentUserId = context.read<AuthProvider>().user?.id;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StoryViewer(
          stories: stories,
          initialIndex: initialIndex,
          currentUserId: currentUserId,
        ),
      ),
      // Setelah viewer ditutup (termasuk setelah hapus story), muat ulang
      // daftar dari server supaya story yang dihapus tidak muncul lagi.
    ).then((_) {
      if (mounted) _loadStories();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: NeoBlockLoader(label: ''),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Section header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 18,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                'NOVA STORIES',
                style: GoogleFonts.cinzel(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2.5,
                  color: const Color(0xFFC9A55A),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // Stories horizontal scroll
        SizedBox(
          height: 110,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: _groups.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              if (index == 0) {
                return _MyStoryCircle(
                  myStories: _myStories,
                  onTap: _myStories.isEmpty
                      ? _showCreationSheet
                      : () => _openViewer(context, _myStories, 0),
                  onAddTap: _showCreationSheet,
                );
              }
              final group = _groups[index - 1];
              return _StoryCircle(
                story: group.user,
                storiesCount: group.stories.length,
                onTap: () => _openViewer(context, group.stories, 0),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _StoryGroup {
  final String userId;
  final Story user;
  final List<Story> stories;

  _StoryGroup(this.userId, this.user, this.stories);
}

class _MyStoryCircle extends StatelessWidget {
  final List<Story> myStories;
  final VoidCallback? onTap;
  final VoidCallback? onAddTap;

  const _MyStoryCircle({this.myStories = const [], this.onTap, this.onAddTap});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final avatarUrl = user?.avatar;
    final free = user?.isFree ?? false;
    final hasStories = myStories.isNotEmpty;

    Widget avatar() => Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: NeoColors.darkBg,
        border: Border.all(
          color: free
              ? Colors.white.withValues(alpha: 0.25)
              : hasStories
              ? const Color(0xFFC9A55A)
              : const Color(0xFFC9A55A).withValues(alpha: 0.8),
          width: 2,
        ),
        image: avatarUrl != null && avatarUrl.isNotEmpty
            ? DecorationImage(image: NetworkImage(avatarUrl), fit: BoxFit.cover)
            : null,
      ),
      child: avatarUrl != null && avatarUrl.isNotEmpty
          ? null
          : Icon(
              Icons.person,
              size: 32,
              color: const Color(0xFFC9A55A).withValues(alpha: 0.8),
            ),
    );

    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              free
                  ? SizedBox(
                      width: 68,
                      height: 68,
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: avatar(),
                      ),
                    )
                  : NeoRoleRing(
                      role: user?.role ?? 'member',
                      size: 68,
                      child: avatar(),
                    ),
              Positioned(
                left: 0,
                right: 0,
                bottom: -4,
                child: GestureDetector(
                  onTap: onAddTap,
                  child: Center(
                    child: Container(
                      width: 22,
                      height: 22,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
                        ),
                        border: Border.all(
                          color: const Color(0xFF0D0D2B),
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.add,
                        size: 16,
                        color: Color(0xFF0D0D2B),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          SizedBox(
            width: 72,
            child: Text(
              user?.displayName ?? 'My Status',
              style: GoogleFonts.inter(
                fontSize: 10,
                color: Colors.white.withValues(alpha: 0.6),
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

class _StoryCircle extends StatelessWidget {
  final Story story;
  final int storiesCount;
  final VoidCallback? onTap;

  const _StoryCircle({required this.story, this.storiesCount = 0, this.onTap});

  @override
  Widget build(BuildContext context) {
    final avatar = story.user?.avatar;
    final hasAvatar = avatar != null && avatar.isNotEmpty;
    final hasMedia = story.hasMedia;
    final bg = Color(
      int.parse(story.bgColor?.replaceFirst('#', '0xFF') ?? '0xFF1A1E38'),
    );

    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          // Ring per role (aktif emas saat user punya stories, seperti WA)
          NeoRoleRing(
            role: story.user?.role ?? 'member',
            size: 68,
            active: storiesCount > 0,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bg,
                image: hasAvatar
                    ? DecorationImage(
                        image: NetworkImage(avatar),
                        fit: BoxFit.cover,
                      )
                    : hasMedia && story.mediaUrl != null
                    ? DecorationImage(
                        image: NetworkImage(story.mediaUrl!),
                        fit: BoxFit.cover,
                      )
                    : null,
              ),
              child: hasMedia && !hasAvatar
                  ? null
                  : !hasAvatar
                  ? Center(
                      child: Text(
                        (story.textContent ?? '?')
                            .substring(0, 1)
                            .toUpperCase(),
                        style: GoogleFonts.cinzel(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFC9A55A),
                        ),
                      ),
                    )
                  : null,
            ),
          ),
          const SizedBox(height: 6),
          // Name
          SizedBox(
            width: 72,
            child: Text(
              story.user?.displayName ?? 'User',
              style: GoogleFonts.inter(
                fontSize: 10,
                color: Colors.white.withValues(alpha: 0.6),
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}
