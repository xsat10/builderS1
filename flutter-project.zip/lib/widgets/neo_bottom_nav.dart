import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/theme_provider.dart';

class _Slot {
  final IconData icon;
  final String label;
  const _Slot(this.icon, this.label);
}

/// NeoBottomNav — bottom nav bergaya GlazeNavBar.
/// Port geometri dari template `contoh.dart`:
/// - Bar kaca compact (~75px) dengan BackdropFilter.
/// - Tombol bundar melayang (berisi ikon slot aktif) yang meluncur ke item
///   aktif memakai AnimationController (600ms, easeOut), menyelam saat
///   melewati titik tengah (buttonHide).
/// - Lekukan/notch DANGKAL mengikuti keliling tombol (kubik s=0.2), bukan
///   lubang U besar.
/// - Item: ikon + label; ikon item aktif "naik" ke dalam lingkaran; badge
///   dipertahankan (untuk maju: NeoBottomNav.badgeCounts per slot).
class NeoBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final VoidCallback? onAddTap;
  final VoidCallback? onThemeTap;

  /// Badge (jumlah) per visual slot 0..5, opsional. Tidak di-set = tanpa badge.
  final Map<int, int>? badgeCounts;

  const NeoBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    this.onAddTap,
    this.onThemeTap,
    this.badgeCounts,
  });

  @override
  State<NeoBottomNav> createState() => _NeoBottomNavState();
}

class _NeoBottomNavState extends State<NeoBottomNav>
    with SingleTickerProviderStateMixin {
  static const double _barHeight = 75;
  static const int _length = 6;
  static const int _addSlot = 2;
  static const int _themeSlot = 5;
  static const double _buttonSize = 46;
  static const double _buttonOverflow = 16;
  static const double _diveDistance = 56;

  late double _startingPos;
  late int _endingIndex;
  late double _pos;
  late IconData _icon;
  late AnimationController _animationController;
  double _buttonHide = 0;

  static const List<_Slot> _slots = [
    _Slot(Icons.home_rounded, 'HOME'),
    _Slot(Icons.chat_bubble_rounded, 'WHATSAPP'),
    _Slot(Icons.add_rounded, 'ADD'),
    _Slot(Icons.devices_rounded, 'DEVICE'),
    _Slot(Icons.handyman_rounded, 'TOOLS'),
    _Slot(Icons.palette_rounded, 'THEME'),
  ];

  int _slotForIndex(int index) {
    switch (index) {
      case 0:
        return 0;
      case 1:
        return 1;
      case 15:
        return 3;
      case 4:
        return 4;
      default:
        return -1;
    }
  }

  int _indexForSlot(int slot) {
    if (slot == 3) return 15;
    if (slot == 4) return 4;
    return slot;
  }

  @override
  void initState() {
    super.initState();
    final start = _slotForIndex(widget.currentIndex);
    _endingIndex = start < 0 ? 0 : start;
    _icon = _slots[_endingIndex].icon;
    _pos = _endingIndex / _length;
    _startingPos = _pos;
    _animationController = AnimationController(vsync: this, value: _pos);
    _animationController.addListener(() {
      setState(() {
        _pos = _animationController.value.clamp(0.0, 1.0);
        final endingPos = _endingIndex / _length;
        final middle = (endingPos + _startingPos) / 2;
        if ((endingPos - _pos).abs() < (_startingPos - _pos).abs()) {
          _icon = _slots[_endingIndex].icon;
        }
        // Prevent division by zero and NaN values.
        // dive = 0 saat di tengah perjalanan (button menyelam ke atas),
        //        = 1 saat di posisi akhir (button kembali ke posisi normal).
        final denominator = _startingPos - middle;
        final dive = denominator.abs() < 0.0001
            ? 1.0
            : ((middle - _pos) / denominator).abs().clamp(0.0, 1.0);
        _buttonHide = (1 - dive).clamp(0.0, 1.0) * _diveDistance;
      });
    });
  }

  @override
  void didUpdateWidget(covariant NeoBottomNav old) {
    super.didUpdateWidget(old);
    if (old.currentIndex != widget.currentIndex) {
      final slot = _slotForIndex(widget.currentIndex);
      if (slot >= 0) {
        final newPosition = slot / _length;
        setState(() {
          _startingPos = _pos;
          _endingIndex = slot;
          _animationController.animateTo(
            newPosition,
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOut,
          );
        });
      }
    }
    if (!_animationController.isAnimating) {
      _icon = _slots[_endingIndex].icon;
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _glideTo(int slot) {
    final target = slot / _length;
    setState(() {
      _startingPos = _pos;
      _endingIndex = slot;
      _animationController.animateTo(
        target,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOut,
      );
    });
  }

  void _onSlotTap(int slot) {
    if (slot == _themeSlot) {
      // THEME bukan route navigation — cukup buka Theme Picker.
      widget.onThemeTap?.call();
      return;
    }
    if (slot == _addSlot) {
      // Geser tombol ke tengah, buka dialog tambah, lalu kembali ke slot aktif.
      _glideTo(_addSlot);
      widget.onAddTap?.call();
      final nav = _slotForIndex(widget.currentIndex);
      Future.delayed(const Duration(milliseconds: 900), () {
        if (!mounted) return;
        if (nav >= 0 && nav != _addSlot) _glideTo(nav);
      });
      return;
    }
    widget.onTap(_indexForSlot(slot));
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final barGradient = [
      palette.primary.withValues(alpha: 0.22),
      palette.navbarBackground.withValues(alpha: 0.92),
      palette.accent.withValues(alpha: 0.14),
    ];
    final barBorder = palette.navbarBorder;
    return SafeArea(
      top: false,
      child: SizedBox(
        height: _barHeight,
        child: LayoutBuilder(
          builder: (context, cons) {
            final w = cons.maxWidth;
            return Stack(
              clipBehavior: Clip.none,
              children: <Widget>[
                // ---- Button melayang (paling bawah, dibentuk dulu) ----
                Positioned(
                  bottom: _barHeight - _buttonSize + _buttonOverflow,
                  left: (_pos * w).clamp(0.0, w),
                  width: w / _length,
                  child: _buildFloatingButton(isDark: isDark),
                ),
                // ---- Kaca bar dengan notch dangkal di sekitar tombol ----
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: ClipPath(
                    clipper: _GlazeClipper(
                      startingLoc: _pos,
                      itemsLength: _length,
                      hasLabel: true,
                      height: _barHeight,
                      isAndroid:
                          Theme.of(context).platform == TargetPlatform.android,
                    ),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: isDark ? 22 : 14,
                        sigmaY: isDark ? 22 : 14,
                      ),
                      child: Container(
                        width: w,
                        height: _barHeight,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: barGradient,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // ---- Border stroke mengikuti siluet bar + notch ----
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: IgnorePointer(
                    child: CustomPaint(
                      size: Size(w, _barHeight),
                      painter: _GlazeBorderPainter(
                        startingLoc: _pos,
                        itemsLength: _length,
                        hasLabel: true,
                        height: _barHeight,
                        borderColor: barBorder,
                        borderWidth: 1,
                        isAndroid:
                            Theme.of(context).platform ==
                            TargetPlatform.android,
                      ),
                    ),
                  ),
                ),
                // ---- Item navigasi (ikon + label), digambar paling atas ----
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: SizedBox(
                    height: _barHeight,
                    child: Row(
                      children: [
                        for (var i = 0; i < _slots.length; i++)
                          Expanded(child: _buildItem(context, i, isDark)),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Tombol bundar melayang berisi ikon slot aktif (+ badge bila ada).
  Widget _buildFloatingButton({required bool isDark}) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final badge = widget.badgeCounts?[_endingIndex];
    final hasBadge = badge != null && badge > 0;

    Widget child = Icon(
      _icon,
      size: _icon == Icons.add_rounded ? 26 : 24,
      color: palette.textOnAccent,
      shadows: const [Shadow(color: Color(0x33FFFFFF), blurRadius: 4)],
    );

    if (hasBadge) {
      child = Badge.count(
        count: badge,
        alignment: Alignment.topRight,
        textColor: Colors.white,
        backgroundColor: const Color(0xFFE53935),
        child: child,
      );
    }

    return Center(
      child: Transform.translate(
        offset: Offset(0, -_buttonHide),
        child: Container(
          width: _buttonSize,
          height: _buttonSize,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [palette.primary, palette.secondary],
            ),
            border: Border.all(
              color: isDark ? const Color(0xCCFFFFFF) : const Color(0x99FFFFFF),
              width: 1.6,
            ),
            boxShadow: [
              BoxShadow(
                color: palette.glow.withValues(alpha: 0.45),
                blurRadius: 14,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: palette.glowSecondary.withValues(alpha: 0.28),
                blurRadius: 26,
                spreadRadius: 3,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            type: MaterialType.circle,
            child: Center(child: child),
          ),
        ),
      ),
    );
  }

  Widget _buildItem(BuildContext context, int slot, bool isDark) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final item = _slots[slot];
    final active = slot == _endingIndex;
    final labelColor = active
        ? palette.navbarActive
        : palette.navbarInactive;
    final badge = widget.badgeCounts?[slot];
    final showBadge = !active && badge != null && badge > 0;

    return _Pressable(
      onTap: () => _onSlotTap(slot),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 24,
            height: 24,
            child: Center(
              child: showBadge
                  ? Badge.count(
                      count: badge,
                      alignment: Alignment.topRight,
                      textColor: Colors.white,
                      backgroundColor: const Color(0xFFE53935),
                      child: Icon(item.icon, size: 20, color: labelColor),
                    )
                  : active
                  ? const SizedBox(width: 20, height: 20)
                  : Icon(item.icon, size: 20, color: labelColor),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            item.label,
            style: TextStyle(
              fontSize: 9,
              fontWeight: active ? FontWeight.w800 : FontWeight.w600,
              letterSpacing: 0.4,
              color: labelColor,
            ),
          ),
        ],
      ),
    );
  }
}

/// Siluet bar kaca: kotak dengan sudut atas rounded + notch dangkal
/// (kubik s=0.2) mengikuti keliling tombol melayang.
/// Dibangun sebagai satu jalur berurutan tanpa ruas yang memotong dirinya
/// sendiri — saat slot aktif di pinggir, notch menyatu mulus dengan sudut
/// bar sehingga tidak tampak "pecah".
Path _barSilhouette({
  required double w,
  required double h,
  required double loc,
  required double bottom,
}) {
  const s = 0.2;
  const r = 24.0;
  final bottomY = h * bottom;
  final dipL = w * (loc - 0.05).clamp(0.0, 1.0);
  final dipR = w * (loc + s + 0.05).clamp(0.0, 1.0);

  final p = Path()
    ..moveTo(0, h)
    ..lineTo(0, r);
  if (dipL >= r) {
    p
      ..quadraticBezierTo(0, 0, r, 0)
      ..lineTo(dipL, 0);
  } else {
    p.quadraticBezierTo(0, 0, dipL, 0);
  }
  p
    ..cubicTo(
      w * (loc + s * 0.2).clamp(0.0, 1.0),
      h * 0.05,
      w * loc.clamp(0.0, 1.0),
      bottomY,
      w * (loc + s * 0.5).clamp(0.0, 1.0),
      bottomY,
    )
    ..cubicTo(
      w * (loc + s).clamp(0.0, 1.0),
      bottomY,
      w * (loc + s * 0.8).clamp(0.0, 1.0),
      h * 0.05,
      dipR,
      0,
    );
  if (dipR <= w - r) {
    p
      ..lineTo(w - r, 0)
      ..quadraticBezierTo(w, 0, w, r);
  } else {
    p.quadraticBezierTo(w, 0, w, r);
  }
  p
    ..lineTo(w, h)
    ..lineTo(0, h)
    ..close();
  return p;
}

/// Klip kaca bar (geometri notch dari _NavBarClipper contoh.dart).
class _GlazeClipper extends CustomClipper<Path> {
  final double startingLoc;
  final int itemsLength;
  final bool hasLabel;
  final double height;
  final bool isAndroid;

  const _GlazeClipper({
    required this.startingLoc,
    required this.itemsLength,
    required this.hasLabel,
    required this.height,
    required this.isAndroid,
  });

  @override
  Path getClip(Size size) {
    if (size.width <= 0 || size.height <= 0) {
      return Path()..addRect(Rect.zero);
    }
    const s = 0.2;
    final span = 1.0 / itemsLength;
    final l = startingLoc + (span - s) / 2;
    final loc = l.clamp(0.0, 1.0 - s);
    final bottom = hasLabel
        ? (isAndroid ? 0.55 : 0.45)
        : (isAndroid ? 0.6 : 0.5);
    return _barSilhouette(
      w: size.width,
      h: size.height,
      loc: loc,
      bottom: bottom,
    );
  }

  @override
  bool shouldReclip(_GlazeClipper oldClipper) {
    return startingLoc != oldClipper.startingLoc ||
        itemsLength != oldClipper.itemsLength ||
        hasLabel != oldClipper.hasLabel ||
        isAndroid != oldClipper.isAndroid;
  }
}

/// Border tipis mengikuti siluet bar (geometri _NavBarBorderPainter don't
/// contoh.dart, diperluas rounded corners).
class _GlazeBorderPainter extends CustomPainter {
  final double startingLoc;
  final int itemsLength;
  final bool hasLabel;
  final double height;
  final Color borderColor;
  final double borderWidth;
  final bool isAndroid;

  const _GlazeBorderPainter({
    required this.startingLoc,
    required this.itemsLength,
    required this.hasLabel,
    required this.height,
    required this.borderColor,
    required this.borderWidth,
    required this.isAndroid,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    const s = 0.2;
    final span = 1.0 / itemsLength;
    final l = startingLoc + (span - s) / 2;
    final loc = l.clamp(0.0, 1.0 - s);
    final bottom = hasLabel
        ? (isAndroid ? 0.55 : 0.45)
        : (isAndroid ? 0.6 : 0.5);

    final paint = Paint()
      ..color = borderColor
      ..strokeWidth = borderWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(
      _barSilhouette(w: size.width, h: size.height, loc: loc, bottom: bottom),
      paint,
    );
  }

  @override
  bool shouldRepaint(_GlazeBorderPainter oldDelegate) {
    return startingLoc != oldDelegate.startingLoc ||
        itemsLength != oldDelegate.itemsLength ||
        hasLabel != oldDelegate.hasLabel ||
        borderColor != oldDelegate.borderColor ||
        borderWidth != oldDelegate.borderWidth ||
        isAndroid != oldDelegate.isAndroid;
  }
}

class _Pressable extends StatefulWidget {
  final VoidCallback? onTap;
  final Widget child;
  const _Pressable({this.onTap, required this.child});

  @override
  State<_Pressable> createState() => _PressableState();
}

class _PressableState extends State<_Pressable> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap?.call();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.9 : 1.0,
          duration: const Duration(milliseconds: 110),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      ),
    );
  }
}
