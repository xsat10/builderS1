import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/music_track.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../screens/profile_screen.dart';
import '../services/api_service.dart';
import '../services/music_service.dart';
import '../services/music_player_controller.dart';
import '../theme.dart';
import 'neo_block_loader.dart';
import 'neo_button.dart';
import 'roman_sheet.dart';
import 'package:google_fonts/google_fonts.dart';

/// NeoAppHeader (redesign — navbar baru)
/// Layout: [hamburger] ... [LOGO tengah] ... [musik] [cs] [profil]
class NeoAppHeader extends StatelessWidget {
  final VoidCallback? onMenuTap;
  final VoidCallback? onProfileTap;

  const NeoAppHeader({super.key, this.onMenuTap, this.onProfileTap});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          NeoSpacing.md,
          NeoSpacing.md,
          NeoSpacing.md,
          NeoSpacing.sm,
        ),
        child: Row(
          children: [
            _HamburgerButton(onTap: onMenuTap),
            const Spacer(),
            _IconButton(
              icon: Icons.music_note_rounded,
              onTap: () => _showMusicDialog(context),
            ),
            _IconButton(
              icon: Icons.headset_mic_outlined,
              onTap: () => _showSupportDialog(context),
            ),
            _IconButton(
              icon: Icons.palette_outlined,
              onTap: () {
                final tp = context.read<
                    NeoThemeProvider>(
                );
                tp.toggle();
              },
            ),
            _IconButton(
              icon: Icons.person_rounded,
              onTap:
                  onProfileTap ??
                  () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const ProfileScreen()),
                    );
                  },
            ),
          ],
        ),
      ),
    );
  }

  void _showMusicDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.55),
      builder: (ctx) => const _SpotifyPlayerSheet(),
    );
  }

  void _showSupportDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: RomanDialog(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [NeoColors.gold, NeoColors.goldDeep],
                        ),
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                      ),
                      child: Icon(
                        Icons.headset_mic,
                        color: NeoColors.darkCard,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Customer Support',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: NeoColors.primaryText,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: const Icon(
                        Icons.close,
                        color: NeoColors.grey,
                        size: 20,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const RomanSheetTitle('PELAYANAN ISTANA', fontSize: 11),
                const SizedBox(height: 18),
                _contactButton(
                  icon: Icons.email_outlined,
                  label: 'Email',
                  subtitle: 'yusomoalex@gmail.com',
                  url: 'mailto:yusomoalex@gmail.com',
                ),
                const SizedBox(height: 12),
                _contactButton(
                  icon: Icons.language_outlined,
                  label: 'Website',
                  subtitle: 'alex-yusomo.vercel.app',
                  url: 'https://alex-yusomo.vercel.app',
                ),
                const SizedBox(height: 12),
                _contactButton(
                  icon: Icons.document_scanner_outlined,
                  label: 'Documentation',
                  subtitle: 'alex-yusomo.vercel.app',
                  url: 'https://alex-yusomo.vercel.app',
                ),
                const SizedBox(height: 20),
                NeoButton(
                  label: 'TUTUP',
                  bgColor: const Color(0x22FFFFFF),
                  textColor: NeoColors.primaryText,
                  onPressed: () => Navigator.pop(ctx),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _launchUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      // abaikan bila gagal membuka tautan.
    }
  }

  Widget _contactButton({
    required IconData icon,
    required String label,
    required String subtitle,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => _launchUrl(url),
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0x1AFFFFFF), Color(0x08FFFFFF)],
          ),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 51 / 255), width: 1),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [NeoColors.gold, NeoColors.goldDeep],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: NeoColors.darkCard, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.cinzel(
                      textStyle: TextStyle(
                        color: NeoColors.marble,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: NeoColors.marble.withValues(alpha: 0.55),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: NeoColors.gold,
              size: 14,
            ),
          ],
        ),
      ),
    );
  }
}

class _HamburgerButton extends StatefulWidget {
  final VoidCallback? onTap;
  const _HamburgerButton({this.onTap});

  @override
  State<_HamburgerButton> createState() => _HamburgerButtonState();
}

class _HamburgerButtonState extends State<_HamburgerButton>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;

  void _handleTap() {
    if (widget.onTap != null) {
      widget.onTap!();
    } else {
      Scaffold.maybeOf(context)?.openDrawer();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        _handleTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.9 : 1.0,
        duration: const Duration(milliseconds: 110),
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(
            Icons.menu,
            size: 20,
            color: _pressed
                ? Theme.of(context).colorScheme.secondary
                : Theme.of(context).colorScheme.primary,
          ),
        ),
      ),
    );
  }
}

class _IconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _IconButton({required this.icon, this.onTap});

  @override
  State<_IconButton> createState() => _IconButtonState();
}

class _IconButtonState extends State<_IconButton>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.9 : 1.0,
        duration: const Duration(milliseconds: 110),
        child: SizedBox(
          width: 38,
          height: 38,
          child: Icon(
            widget.icon,
            size: 19,
            color: _pressed
                ? Theme.of(context).colorScheme.secondary
                : Theme.of(context).colorScheme.primary,
          ),
        ),
      ),
    );
  }
}

/// Mini Spotify player (liquid glass) — dibuka dari tombol musik navbar.
/// Daftar lagu diambil dari server (database JSON lokal). Developer hanya meng-input
/// link lagu Spotify. Musik otomatis PAUSE saat app di luar layar (background).
class _SpotifyPlayerSheet extends StatefulWidget {
  const _SpotifyPlayerSheet();

  @override
  State<_SpotifyPlayerSheet> createState() => _SpotifyPlayerSheetState();
}

class _SpotifyPlayerSheetState extends State<_SpotifyPlayerSheet> {
  final MusicPlayerController _ctrl = MusicPlayerController.instance;

  List<MusicTrack> _tracks = [];
  bool _loading = true;
  String? _loadingError;
  int _currentIndex = -1;
  bool _playing = false;
  double _position = 0;
  double _duration = 0;

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(_onCtrl);
    _sync();
    _ctrl.ensureLoaded();
  }

  @override
  void dispose() {
    _ctrl.removeListener(_onCtrl);
    super.dispose();
  }

  void _onCtrl() {
    if (!mounted) return;
    setState(_sync);
  }

  void _sync() {
    _tracks = List.of(_ctrl.tracks);
    _currentIndex = _ctrl.currentIndex;
    _playing = _ctrl.playing;
    _position = _ctrl.position.inMicroseconds / 1000000;
    _duration = _ctrl.duration.inSeconds.toDouble();
    _loading = _ctrl.loading;
    _loadingError = _ctrl.error;
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _loadingError = null;
    });
    await _ctrl.ensureLoaded(force: true);
    if (mounted) _onCtrl();
  }

  Future<void> _playTrack(int index) async {
    final result = await _ctrl.playTrack(index);
    if (!mounted) return;
    _onCtrl();
    if (result == MusicPlayResult.noPreview) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Preview tidak tersedia untuk lagu ini.'),
          backgroundColor: NeoColors.goldDeep,
        ),
      );
    } else if (result == MusicPlayResult.failed) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal memutar lagu.'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  void _togglePlay() {
    if (_tracks.isEmpty) return;
    if (_playing) {
      _pause();
    } else {
      if (_ctrl.position > Duration.zero && _ctrl.duration > Duration.zero) {
        _resume();
      } else {
        _playTrack(_currentIndex < 0 ? 0 : _currentIndex);
      }
    }
  }

  void _resume() {
    _ctrl.resume();
  }

  void _pause() {
    _ctrl.pause();
  }

  void _next() {
    if (_tracks.isEmpty) return;
    _ctrl.next();
  }

  void _prev() {
    if (_tracks.isEmpty) return;
    _ctrl.prev();
  }

  void _seek(double v) {
    _ctrl.seek(Duration(seconds: v.round()));
  }

  /// Buka dialog tambah lagu. Lagu disimpan ke database (via server) memakai
  /// link Spotify, lalu daftar Nova Music dimuat ulang.
  Future<void> _addSong() async {
    final track = await showDialog<_AddTrackResult>(
      context: context,
      builder: (_) => const _AddTrackDialog(),
    );
    if (track == null || !mounted) return;
    setState(() => _loading = true);
    try {
      final result = await ApiService().createMusic({
        'title': track.title,
        'artist': track.artist,
        'url': track.spotifyUrl,
        'spotifyUrl': track.spotifyUrl,
        if (track.artwork != null && track.artwork!.isNotEmpty)
          'coverUrl': track.artwork,
      });
      if (!mounted) return;
      if (result['success'] == true || result['error'] == null) {
        await _load();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Lagu berhasil ditambahkan.'),
            backgroundColor: NeoColors.goldDeep,
          ),
        );
      } else {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              (result['error']?['message'] ?? 'Gagal menambahkan lagu.')
                  .toString(),
            ),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal menyimpan ke database.'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  String _fmt(double s) {
    if (s.isNaN || s < 0) return '0:00';
    final m = s ~/ 60;
    final sec = (s % 60).floor();
    return '${m.toString().padLeft(1, '0')}:${sec.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
        child: Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
            boxShadow: NeoShadows.lgD(isDark),
          ),
          child: Container(
            color: const Color(0xE61A1A33),
            padding: const EdgeInsets.fromLTRB(24, 14, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF1DB954), Color(0xFF14833B)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(
                              0xFF1DB954,
                            ).withValues(alpha: 0.4),
                            blurRadius: 18,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.graphic_eq,
                        color: NeoColors.white,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'NovaCore Music',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: NeoColors.primaryText,
                            ),
                          ),
                          SizedBox(height: 3),
                          Text(
                            'Lagu dari link Spotify',
                            style: TextStyle(
                              fontSize: 12,
                              color: NeoColors.secondaryText,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.add_rounded,
                        color: NeoColors.gold,
                      ),
                      tooltip: 'Tambah lagu',
                      onPressed: _addSong,
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.close,
                        color: NeoColors.secondaryText,
                      ),
                      tooltip: 'Tutup (musik tetap berlanjut)',
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                if (_loading)
                  const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: NeoBlockLoader(label: '')),
                  )
                else if (_tracks.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Icon(
                          Icons.music_off_rounded,
                          color: NeoColors.secondaryText,
                          size: 34,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          _loadingError ?? 'Belum ada lagu. Hubungi developer.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                      ],
                    ),
                  )
                else ...[
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 200),
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: _tracks.length,
                      separatorBuilder: (_, index) => const SizedBox(height: 6),
                      itemBuilder: (ctx, i) => _TrackRow(
                        track: _tracks[i],
                        selected: i == _currentIndex,
                        playing: i == _currentIndex && _playing,
                        onTap: () => _playTrack(i),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_currentIndex >= 0 && _currentIndex < _tracks.length)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _playerCtl(Icons.skip_previous_rounded, _prev),
                        _playButton(),
                        _playerCtl(Icons.skip_next_rounded, _next),
                      ],
                    ),
                  const SizedBox(height: 14),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: const Color(0xFF1DB954),
                      inactiveTrackColor: Colors.white24,
                      thumbColor: NeoColors.white,
                      trackHeight: 3,
                      overlayShape: SliderComponentShape.noOverlay,
                    ),
                    child: Slider(
                      value: _duration > 0 ? _position.clamp(0, _duration) : 0,
                      max: _duration > 0 ? _duration : 1,
                      onChanged: _duration > 0 ? _seek : null,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _fmt(_position),
                          style: TextStyle(
                            fontSize: 11,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                        Text(
                          _fmt(_duration),
                          style: TextStyle(
                            fontSize: 11,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _playerCtl(IconData icon, VoidCallback onTap) {
    return IconButton(
      icon: Icon(icon, color: NeoColors.white),
      iconSize: 32,
      onPressed: onTap,
    );
  }

  Widget _playButton() {
    return GestureDetector(
      onTap: _togglePlay,
      child: Container(
        width: 62,
        height: 62,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [Color(0xFF1DB954), Color(0xFF17A346)],
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF1DB954).withValues(alpha: 0.5),
              blurRadius: 22,
              spreadRadius: 1,
            ),
          ],
        ),
        child: _ctrl.busy
            ? const SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                  color: NeoColors.white,
                  strokeWidth: 3,
                ),
              )
            : Icon(
                _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                color: NeoColors.white,
                size: 36,
              ),
      ),
    );
  }
}

class _TrackRow extends StatelessWidget {
  final MusicTrack track;
  final bool selected;
  final bool playing;
  final VoidCallback onTap;
  const _TrackRow({
    required this.track,
    required this.selected,
    required this.playing,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF1DB954).withValues(alpha: 0.18)
              : Colors.white.withValues(alpha: 0.04),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? const Color(0x661DB954)
                : Colors.white.withValues(alpha: 0.08),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(
                  colors: track.artwork != null && track.artwork!.isNotEmpty
                      ? [const Color(0xFF1DB954), const Color(0xFF14833B)]
                      : [const Color(0xFF555555), const Color(0xFF333333)],
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: track.artwork != null && track.artwork!.isNotEmpty
                  ? Image.network(
                      track.artwork!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => const Icon(
                        Icons.music_note,
                        color: Colors.white,
                        size: 20,
                      ),
                    )
                  : Icon(
                      playing ? Icons.graphic_eq : Icons.music_note,
                      color: Colors.white,
                      size: 20,
                    ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: selected
                          ? const Color(0xFF1DB954)
                          : NeoColors.primaryText,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    track.artist.isEmpty ? 'Spotify' : track.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      color: NeoColors.secondaryText,
                    ),
                  ),
                ],
              ),
            ),
            if (playing)
              const Icon(Icons.graphic_eq, color: Color(0xFF1DB954), size: 18),
          ],
        ),
      ),
    );
  }
}

/// Hasil dialog tambah lagu (link Spotify + metadata opsional).
class _AddTrackResult {
  final String title;
  final String artist;
  final String spotifyUrl;
  final String? artwork;
  const _AddTrackResult({
    required this.title,
    required this.artist,
    required this.spotifyUrl,
    this.artwork,
  });
}

/// Dialog tambah lagu ke Nova Music: input LINK Spotify (wajib), dengan
/// opsi "cek otomatis" untuk mengisi judul/artis/gambar dari Spotify.
class _AddTrackDialog extends StatefulWidget {
  const _AddTrackDialog();
  @override
  State<_AddTrackDialog> createState() => _AddTrackDialogState();
}

class _AddTrackDialogState extends State<_AddTrackDialog> {
  final _linkCtrl = TextEditingController();
  final _titleCtrl = TextEditingController();
  final _artistCtrl = TextEditingController();
  bool _loadingMeta = false;
  String? _error;
  String? _artwork;

  @override
  void dispose() {
    _linkCtrl.dispose();
    _titleCtrl.dispose();
    _artistCtrl.dispose();
    super.dispose();
  }

  Future<void> _resolveMeta() async {
    final link = _linkCtrl.text.trim();
    if (link.isEmpty) {
      setState(() => _error = 'Masukkan link Spotify dulu.');
      return;
    }
    setState(() {
      _loadingMeta = true;
      _error = null;
    });
    final meta = await MusicService.resolveMeta(link);
    if (!mounted) return;
    setState(() {
      _loadingMeta = false;
      if (_titleCtrl.text.trim().isEmpty) _titleCtrl.text = meta['title'] ?? '';
      if (_artistCtrl.text.trim().isEmpty) {
        _artistCtrl.text = meta['artist'] ?? '';
      }
      if (meta['artwork'] != null && meta['artwork']!.isNotEmpty) {
        _artwork = meta['artwork'];
      }
    });
  }

  void _submit() {
    final link = _linkCtrl.text.trim();
    if (link.isEmpty) {
      setState(() => _error = 'Link Spotify wajib diisi.');
      return;
    }
    Navigator.of(context).pop(
      _AddTrackResult(
        title: _titleCtrl.text.trim().isNotEmpty
            ? _titleCtrl.text.trim()
            : 'Lagu Spotify',
        artist: _artistCtrl.text.trim(),
        spotifyUrl: link,
        artwork: _artwork,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            color: NeoColors.surfaceElevated,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFF1DB954).withValues(alpha: 0.4),
            ),
            boxShadow: NeoShadows.lgD(isDark),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'TAMBAH LAGU KE NOVA MUSIC',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                  color: NeoColors.primaryText,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Tempel link lagu Spotify. Lagu akan tersimpan ke database.',
                style: TextStyle(fontSize: 11, color: NeoColors.secondaryText),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _linkCtrl,
                keyboardType: TextInputType.url,
                style: TextStyle(color: NeoColors.primaryText),
                cursorColor: NeoColors.gold,
                decoration: _dec('Link Spotify *'),
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: _loadingMeta ? null : _resolveMeta,
                  icon: _loadingMeta
                      ? const NeoBlockLoader(compact: true, size: 14, label: '')
                      : const Icon(Icons.auto_awesome, size: 16),
                  label: const Text('Isi otomatis'),
                  style: TextButton.styleFrom(foregroundColor: NeoColors.gold),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _titleCtrl,
                style: TextStyle(color: NeoColors.primaryText),
                cursorColor: NeoColors.gold,
                decoration: _dec('Judul (opsional)'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _artistCtrl,
                style: TextStyle(color: NeoColors.primaryText),
                cursorColor: NeoColors.gold,
                decoration: _dec('Artis (opsional)'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(
                  _error!,
                  style: const TextStyle(
                    color: NeoColors.pink,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text(
                      'BATAL',
                      style: TextStyle(color: NeoColors.grey),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1DB954),
                      foregroundColor: Colors.white,
                    ),
                    child: const Text(
                      'SIMPAN',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _dec(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: NeoColors.secondaryText, fontSize: 12),
      filled: true,
      fillColor: Colors.white.withValues(alpha: 0.04),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0x22FFFFFF)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: NeoColors.gold),
      ),
    );
  }
}
