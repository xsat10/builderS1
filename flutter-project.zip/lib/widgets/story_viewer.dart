import '../theme.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';
import '../models/story.dart';
import '../services/story_service.dart';

class StoryViewer extends StatefulWidget {
  final List<Story> stories;
  final int initialIndex;
  final String? currentUserId;

  const StoryViewer({
    super.key,
    required this.stories,
    this.initialIndex = 0,
    this.currentUserId,
  });

  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer>
    with SingleTickerProviderStateMixin {
  late int _currentIndex;
  late AnimationController _progressController;
  Timer? _autoAdvanceTimer;
  Timer? _iconTimer;
  bool _paused = false;
  bool _showIcon = false;
  bool _closing = false;

  // Controller video untuk story berjenis video (agar bisa diputar + suara)
  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoFailed = false;

  static const Duration _photoDuration = Duration(seconds: 5);

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _progressController =
        AnimationController(vsync: this, duration: _photoDuration)
          ..addStatusListener((status) {
            if (status == AnimationStatus.completed && !_closing) {
              _nextStory();
            }
          });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _setupVideoFor(_currentStory);
    });
    _startPhotoProgress(immediate: true);
  }

  @override
  void dispose() {
    _progressController.dispose();
    _autoAdvanceTimer?.cancel();
    _iconTimer?.cancel();
    _videoController?.removeListener(_onVideoUpdate);
    _videoController?.dispose();
    _videoController = null;
    super.dispose();
  }

  Story get _currentStory => widget.stories[_currentIndex];

  // ── Video setup ──────────────────────────────────────────────────────────
  Future<void> _setupVideoFor(Story story) async {
    final old = _videoController;
    if (old != null) {
      old.removeListener(_onVideoUpdate);
      await old.dispose();
    }
    _videoController = null;
    setState(() {
      _videoReady = false;
      _videoFailed = false;
    });

    if (!story.isVideo || story.mediaUrl == null || story.mediaUrl!.isEmpty) {
      // Bukan video → jalankan progress foto biasa.
      _startPhotoProgress(immediate: true);
      return;
    }

    // Pause progress foto; durasi dikendalikan oleh video.
    _progressController.stop();

    final ctrl = VideoPlayerController.networkUrl(
      Uri.parse(story.mediaUrl!),
    )..addListener(_onVideoUpdate);
    _videoController = ctrl;

    try {
      await ctrl.initialize();
      if (!mounted) return;
      // Volume penuh (agar ada suara).
      await ctrl.setVolume(1.0);
      ctrl.setLooping(false);
      await ctrl.play();
      if (!mounted) return;
      setState(() => _videoReady = true);
      // Sinkronkan durasi progress bar dengan durasi video.
      final dur = ctrl.value.duration;
      if (dur > Duration.zero) {
        _progressController.duration = dur;
      }
      _startVideoProgress();
    } catch (e) {
      debugPrint('Story video error: $e');
      if (!mounted) return;
      // Gagal memutar video → fallback ke progress foto biasa.
      setState(() => _videoFailed = true);
      _startPhotoProgress(immediate: true);
    }
  }

  void _onVideoUpdate() {
    if (!mounted || _videoController == null) return;
    final c = _videoController!;
    final value = c.value;
    if (!value.isInitialized) return;
    if (value.isCompleted && !_closing) {
      _nextStory();
    }
  }

  // Progress bar mengikuti posisi video secara realtime.
  void _startVideoProgress() {
    _progressController.duration = _videoController?.value.duration ??
        _photoDuration;
    _progressController.forward(from: 0);
    _autoAdvanceTimer?.cancel();
  }

  // ── Progress / navigation ──────────────────────────────────────────────
  void _startPhotoProgress({bool immediate = false}) {
    _paused = false;
    setState(() {});
    _progressController.duration = _photoDuration;
    if (immediate) {
      _progressController.forward(from: 0);
    } else {
      _progressController.forward(from: 0);
    }
  }

  void _togglePause() {
    final wasPaused = _paused;
    setState(() {
      _paused = !wasPaused;
      _showIcon = true;
    });

    if (_currentStory.isVideo && _videoController != null) {
      if (wasPaused) {
        _videoController!.play();
      } else {
        _videoController!.pause();
      }
    }

    if (wasPaused) {
      _progressController.forward();
    } else {
      _progressController.stop();
    }
    _iconTimer?.cancel();
    _iconTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _showIcon = false);
    });
  }

  void _goTo(int index) {
    if (_closing) return;
    setState(() {
      _currentIndex = index;
      _showIcon = false;
      _paused = false;
    });
    _setupVideoFor(_currentStory);
  }

  void _nextStory() {
    if (_closing) return;
    if (_currentIndex < widget.stories.length - 1) {
      _goTo(_currentIndex + 1);
    } else {
      _closeViewer();
    }
  }

  // Menutup viewer dengan aman.
  void _closeViewer() {
    if (_closing) return;
    _closing = true;
    _progressController.stop();
    _autoAdvanceTimer?.cancel();
    _iconTimer?.cancel();
    _videoController?.pause();
    Navigator.pop(context);
  }

  void _prevStory() {
    if (_currentIndex > 0) {
      _goTo(_currentIndex - 1);
    }
  }

  Future<void> _deleteStory() async {
    final story = _currentStory;
    final isMine =
        widget.currentUserId != null && widget.currentUserId == story.userId;
    if (!isMine) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: NeoColors.darkBg,
        title: const Text(
          'Hapus story?',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Story ini akan dihapus permanen.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'Hapus',
              style: TextStyle(color: Color(0xFFFF5252)),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final ok = await StoryService().deleteStory(story.id);
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal menghapus story'),
          backgroundColor: Color(0xFFD63B3B),
        ),
      );
      return;
    }
    final updated = List<Story>.of(widget.stories)..removeAt(_currentIndex);
    _progressController.stop();
    _autoAdvanceTimer?.cancel();
    _iconTimer?.cancel();
    _videoController?.pause();
    Navigator.pop(context);
    if (!mounted) return;
    if (updated.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => StoryViewer(
            stories: updated,
            initialIndex: (_currentIndex >= updated.length)
                ? updated.length - 1
                : _currentIndex,
            currentUserId: widget.currentUserId,
          ),
        ),
      );
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text('Story dihapus'),
        backgroundColor: NeoColors.darkBg,
      ),
    );
  }

  Widget _buildMedia(Story story) {
    if (story.isVideo) {
      final c = _videoController;
      if (_videoFailed) {
        // Fallback: thumbnail (foto pertama) jika video gagal diputar.
        return story.hasMedia && story.mediaUrl != null
            ? Image.network(
                story.mediaUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Center(
                  child: Icon(
                    Icons.broken_image,
                    color: Colors.white38,
                    size: 48,
                  ),
                ),
              )
            : const SizedBox();
      }
      if (!_videoReady) {
        return const Center(
          child: CircularProgressIndicator(
            color: Color(0xFFC9A55A),
          ),
        );
      }
      return Center(
        child: AspectRatio(
          aspectRatio: c!.value.aspectRatio,
          child: VideoPlayer(c),
        ),
      );
    }

    // Photo
    return story.hasMedia && story.mediaUrl != null
        ? Image.network(
            story.mediaUrl!,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const Center(
              child: Icon(
                Icons.broken_image,
                color: Colors.white38,
                size: 48,
              ),
            ),
          )
        : story.hasText
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: Text(
                story.textContent ?? '',
                style: GoogleFonts.cinzel(
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          )
        : const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    final story = _currentStory;
    final bg = Color(
      int.parse(story.bgColor?.replaceFirst('#', '0xFF') ?? '0xFF1A1E38'),
    );

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _closeViewer();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTapDown: (details) {
            final w = MediaQuery.of(context).size.width;
            if (details.globalPosition.dx < w * 0.33) {
              _prevStory();
            } else if (details.globalPosition.dx > w * 0.66) {
              _nextStory();
            } else if (_currentStory.isVideo) {
              _togglePause();
            }
          },
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Background
              Container(
                color: bg,
                child: _buildMedia(story),
              ),
              // Gradient overlays
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: 120,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.6),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                height: 160,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.6),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              // Caption untuk story media (foto/video).
              // Ditampilkan di FULLSCREEN & ukuran teks menyesuaikan panjang
              // teks (font otomatis mengecil bila terlalu panjang, tidak
              // terpotong/mengecil card-nya).
              if ((story.isPhoto || story.isVideo) &&
                  (story.textContent?.isNotEmpty ?? false))
                Positioned(
                  bottom: MediaQuery.of(context).padding.bottom + 24,
                  left: 16,
                  right: 16,
                  child: _AutoFitCaption(text: story.textContent!),
                ),
              // Top bar: progress + user info
              Positioned(
                top: MediaQuery.of(context).padding.top + 8,
                left: 16,
                right: 16,
                child: Column(
                  children: [
                    // Progress bars (mengikuti video bila story video)
                    Row(
                      children: List.generate(widget.stories.length, (i) {
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: i == _currentIndex
                                ? AnimatedBuilder(
                                    animation: _progressController,
                                    builder: (_, __) => LinearProgressIndicator(
                                      value: _progressController.value,
                                      backgroundColor: Colors.white24,
                                      valueColor:
                                          const AlwaysStoppedAnimation(
                                        Color(0xFFC9A55A),
                                      ),
                                      minHeight: 2.5,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  )
                                : Container(
                                    height: 2.5,
                                    decoration: BoxDecoration(
                                      color: i < _currentIndex
                                          ? const Color(0xFFC9A55A)
                                          : Colors.white24,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 12),
                    // User info
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor: const Color(0xFFC9A55A),
                          backgroundImage: story.user?.avatar != null
                              ? NetworkImage(story.user!.avatar!)
                              : null,
                          child: story.user?.avatar == null
                              ? Text(
                                  (story.user?.displayName ?? '?')
                                      .substring(0, 1)
                                      .toUpperCase(),
                                  style: GoogleFonts.cinzel(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFF0D0D2B),
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                story.user?.displayName ?? 'User',
                                style: GoogleFonts.inter(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                _formatTimeAgo(story.createdAt),
                                style: GoogleFonts.inter(
                                  fontSize: 11,
                                  color: Colors.white60,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (widget.currentUserId != null &&
                            widget.currentUserId == _currentStory.userId) ...[
                          GestureDetector(
                            onTap: _deleteStory,
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.4),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.delete_outline,
                                color: Color(0xFFFF5252),
                                size: 20,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                        ],
                        GestureDetector(
                          onTap: _closeViewer,
                          child: const Padding(
                            padding: EdgeInsets.all(2),
                            child: Icon(
                              Icons.close,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Pause/play indicator (hanya untuk video)
              if (_showIcon && _currentStory.isVideo)
                Positioned.fill(
                  child: IgnorePointer(
                    child: Center(
                      child: AnimatedOpacity(
                        opacity: _showIcon ? 1 : 0,
                        duration: const Duration(milliseconds: 300),
                        child: Container(
                          width: 64,
                          height: 64,
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.5),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _paused ? Icons.pause : Icons.play_arrow,
                            color: Colors.white,
                            size: 34,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              // Indikator loading video (mute/speaker access)
              if (_currentStory.isVideo && _videoReady)
                Positioned(
                  bottom: MediaQuery.of(context).padding.bottom + 76,
                  right: 16,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.45),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.volume_up,
                      color: Colors.white70,
                      size: 18,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatTimeAgo(DateTime time) {
    final diff = DateTime.now().difference(time);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes}m lalu';
    if (diff.inHours < 12) return '${diff.inHours}j lalu';
    return '${diff.inDays}h lalu';
  }
}

/// Caption dengan ukuran font yang menyesuaikan panjang teks.
/// Teks panjang tidak lagi membuat card mengecil / teks terpotong — malah
/// teks diposisikan full-wide dan font disesuaikan otomatis.
class _AutoFitCaption extends StatelessWidget {
  final String text;
  const _AutoFitCaption({required this.text});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    // Pilih ukuran font berdasarkan panjang teks supaya tidak terpotong.
    double fontSize;
    if (text.length > 300) {
      fontSize = 12;
    } else if (text.length > 200) {
      fontSize = 13;
    } else if (text.length > 140) {
      fontSize = 14;
    } else if (text.length > 90) {
      fontSize = 15;
    } else {
      fontSize = 16;
    }

    return Container(
      width: screenWidth - 32,
      constraints: const BoxConstraints(maxHeight: 220),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: SingleChildScrollView(
        reverse: true,
        child: Text(
          text,
          style: GoogleFonts.cinzel(
            fontSize: fontSize,
            fontWeight: FontWeight.w600,
            color: Colors.white,
            height: 1.35,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
