import 'package:flutter/material.dart';
import '../theme.dart';

class FeatureTheme {
  final Color backgroundColor;
  final List<IconData> icons;
  final String label;

  const FeatureTheme({
    required this.backgroundColor,
    required this.icons,
    required this.label,
  });
}

class FeatureConfig {
  static const int dashboardIndex = 0;
  static const int whatsappIndex = 1;
  static const int activityIndex = 2;
  static const int controlIndex = 3;
  static const int toolsIndex = 4;
  static const int settingsIndex = 5;
  static const int manageIndex = 6;
  static const int usersIndex = 7;
  static const int partnersIndex = 8;
  static const int resellersIndex = 9;
  static const int newsIndex = 10;
  static const int featuresIndex = 11;
  static const int deviceDetailIndex = 12;
  static const int sendersIndex = 13;
  static const int pairingIndex = 14;
  static const int deviceIndex = 15;
  static const int imageIndex = 16;
  static const int moderatorIndex = 17;

  static const double transitionExitRatio = 0.30;
  static const double transitionEnterRatio = 0.70;

  static const FeatureTheme dashboard = FeatureTheme(
    label: 'Dashboard',
    backgroundColor: Color(0xFF0088FF),
    icons: [
      Icons.bar_chart_rounded,
      Icons.show_chart_rounded,
      Icons.analytics_rounded,
      Icons.data_usage_rounded,
      Icons.trending_up_rounded,
      Icons.insights_rounded,
      Icons.leaderboard_rounded,
      Icons.trending_down_rounded,
      Icons.stacked_bar_chart_rounded,
      Icons.grid_view_rounded,
      Icons.query_stats_rounded,
      Icons.pie_chart_rounded,
    ],
  );

  static const FeatureTheme activity = FeatureTheme(
    label: 'Activity',
    backgroundColor: Color(0xFF00ACC1),
    icons: [
      Icons.history_rounded,
      Icons.timeline_rounded,
      Icons.schedule_rounded,
      Icons.update_rounded,
      Icons.access_time_rounded,
      Icons.replay_rounded,
      Icons.notification_important_rounded,
      Icons.bolt_rounded,
      Icons.calendar_month_rounded,
      Icons.pending_rounded,
      Icons.change_circle_rounded,
      Icons.autorenew_rounded,
      Icons.sync_rounded,
      Icons.more_horiz_rounded,
      Icons.double_arrow_rounded,
    ],
  );

  static const FeatureTheme users = FeatureTheme(
    label: 'Users',
    backgroundColor: Color(0xFF7B1FA2),
    icons: [
      Icons.people_rounded,
      Icons.group_rounded,
      Icons.person_add_rounded,
      Icons.supervisor_account_rounded,
      Icons.manage_accounts_rounded,
      Icons.person_rounded,
      Icons.groups_rounded,
      Icons.badge_rounded,
      Icons.contact_page_rounded,
      Icons.face_rounded,
      Icons.account_circle_rounded,
      Icons.emoji_people_rounded,
    ],
  );

  static const FeatureTheme control = FeatureTheme(
    label: 'Control',
    backgroundColor: Color(0xFFC62828),
    icons: [
      Icons.bug_report_rounded,
      Icons.shield_rounded,
      Icons.security_rounded,
      Icons.verified_user_rounded,
      Icons.lock_rounded,
      Icons.gpp_good_rounded,
      Icons.gpp_bad_rounded,
      Icons.do_not_disturb_rounded,
      Icons.block_rounded,
      Icons.report_rounded,
      Icons.dangerous_rounded,
      Icons.warning_rounded,
      Icons.military_tech_rounded,
      Icons.vpn_lock_rounded,
    ],
  );

  static const FeatureTheme settings = FeatureTheme(
    label: 'Settings',
    backgroundColor: Color(0xFF1A237E),
    icons: [
      Icons.settings_rounded,
      Icons.tune_rounded,
      Icons.build_rounded,
      Icons.construction_rounded,
      Icons.speed_rounded,
      Icons.settings_applications_rounded,
      Icons.toggle_on_rounded,
      Icons.adjust_rounded,
      Icons.contrast_rounded,
      Icons.auto_fix_high_rounded,
      Icons.engineering_rounded,
      Icons.manage_search_rounded,
    ],
  );

  static const FeatureTheme whatsapp = FeatureTheme(
    label: 'WhatsApp',
    backgroundColor: Color(0xFF1FA855),
    icons: [
      Icons.chat_bubble_rounded,
      Icons.forum_rounded,
      Icons.send_rounded,
      Icons.mark_chat_unread_rounded,
      Icons.message_rounded,
      Icons.contact_phone_rounded,
      Icons.smart_toy_rounded,
      Icons.dns_rounded,
      Icons.wifi_tethering_rounded,
      Icons.settings_ethernet_rounded,
      Icons.hub_rounded,
      Icons.share_rounded,
    ],
  );

  static const FeatureTheme tools = FeatureTheme(
    label: 'Tools',
    backgroundColor: Color(0xFF00897B),
    icons: [
      Icons.handyman_rounded,
      Icons.construction_rounded,
      Icons.build_circle_rounded,
      Icons.hardware_rounded,
      Icons.extension_rounded,
      Icons.widgets_rounded,
      Icons.plumbing_rounded,
      Icons.memory_rounded,
      Icons.settings_input_component_rounded,
      Icons.cable_rounded,
      Icons.electrical_services_rounded,
      Icons.precision_manufacturing_rounded,
    ],
  );

  static const FeatureTheme manage = FeatureTheme(
    label: 'Manage',
    backgroundColor: Color(0xFF6A1B9A),
    icons: [
      Icons.admin_panel_settings_rounded,
      Icons.manage_accounts_rounded,
      Icons.tune_rounded,
      Icons.dashboard_customize_rounded,
      Icons.fact_check_rounded,
      Icons.security_rounded,
      Icons.verified_rounded,
      Icons.account_tree_rounded,
      Icons.badge_rounded,
      Icons.inventory_rounded,
    ],
  );

  static const FeatureTheme partner = FeatureTheme(
    label: 'Partners',
    backgroundColor: Color(0xFFE65100),
    icons: [
      Icons.group_add_rounded,
      Icons.business_rounded,
      Icons.star_rounded,
      Icons.groups_rounded,
      Icons.people_rounded,
      Icons.insert_chart_rounded,
      Icons.trending_up_rounded,
    ],
  );

  static const FeatureTheme reseller = FeatureTheme(
    label: 'Resellers',
    backgroundColor: Color(0xFF00897B),
    icons: [
      Icons.store_rounded,
      Icons.shopping_cart_rounded,
      Icons.payments_rounded,
      Icons.credit_card_rounded,
      Icons.savings_rounded,
      Icons.inventory_rounded,
    ],
  );

  static const FeatureTheme pairing = FeatureTheme(
    label: 'Pairing',
    backgroundColor: Color(0xFFEF6C00),
    icons: [
      Icons.qr_code_2_rounded,
      Icons.qr_code_rounded,
      Icons.password_rounded,
      Icons.key_rounded,
      Icons.vpn_key_rounded,
      Icons.link_rounded,
    ],
  );

  static const FeatureTheme device = FeatureTheme(
    label: 'Device',
    backgroundColor: Color(0xFF0B0D1F),
    icons: [
      Icons.devices_rounded,
      Icons.smartphone_rounded,
      Icons.tablet_rounded,
      Icons.security_rounded,
      Icons.public_rounded,
      Icons.lan_rounded,
    ],
  );

  static const FeatureTheme moderator = FeatureTheme(
    label: 'Moderator',
    backgroundColor: Color(0xFF0E5A47),
    icons: [
      Icons.verified_user_rounded,
      Icons.people_alt_rounded,
      Icons.manage_accounts_rounded,
      Icons.gavel_rounded,
      Icons.shield_rounded,
      Icons.admin_panel_settings_rounded,
    ],
  );

  static FeatureTheme forIndex(int index, String role) {
    switch (index) {
      case 0:
        return dashboard;
      case 1:
        return whatsapp;
      case 2:
        return activity;
      case 3:
        return control;
      case 4:
        return tools;
      case 5:
        return settings;
      case 6:
        return role == 'developer' ? manage : users;
      case 7:
        return users;
      case 8:
        return partner;
      case 9:
        return reseller;
      case 10:
        return manage;
      case 11:
        return manage;
      case 12:
        return control;
      case 13:
        return manage;
      case 14:
        return pairing;
      case 15:
        return device;
      case 16:
        return manage;
      case 17:
        return moderator;
    }
    return dashboard;
  }

  static FeatureTheme forRoleScreen(String role) {
    switch (role) {
      case 'partner':
        return partner;
      case 'reseller':
        return reseller;
      case 'moderator':
        return moderator;
      default:
        return users;
    }
  }

  static Color buttonAccentFor(FeatureTheme theme) {
    if (identical(theme, dashboard)) return const Color(0xFF5B8CFF);
    if (identical(theme, whatsapp)) return const Color(0xFF55E878);
    if (identical(theme, activity)) return const Color(0xFF5B8CFF);
    if (identical(theme, users)) return const Color(0xFF9B6BFF);
    if (identical(theme, control)) return const Color(0xFFFF9F43);
    if (identical(theme, tools)) return const Color(0xFF36C5F0);
    if (identical(theme, settings)) return const Color(0xFF5B8CFF);
    if (identical(theme, manage)) return const Color(0xFF9B6BFF);
    if (identical(theme, partner)) return const Color(0xFFE65100);
    if (identical(theme, reseller)) return const Color(0xFF00897B);
    if (identical(theme, pairing)) return const Color(0xFFFF8A3D);
    if (identical(theme, device)) return const Color(0xFF8FA6B8);
    if (identical(theme, moderator)) return const Color(0xFF3DD3A5);
    return NeoColors.yellow;
  }
}
