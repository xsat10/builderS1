import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_button.dart';
import 'neo_glass_overlay.dart';

class NeoEditAccountDialog extends StatefulWidget {
  final String title;
  final Color accent;
  final String initialName;
  final String? lockedUsername;
  final DateTime? initialExpiry;
  final int? initialSenderLimit;
  final Future<Map<String, dynamic>> Function(String name, String? expiresAt, int? senderLimit) onSave;

  const NeoEditAccountDialog({
    super.key,
    required this.title,
    required this.accent,
    required this.initialName,
    this.lockedUsername,
    required this.onSave,
    this.initialExpiry,
    this.initialSenderLimit,
  });

  @override
  State<NeoEditAccountDialog> createState() => _NeoEditAccountDialogState();
}

class _NeoEditAccountDialogState extends State<NeoEditAccountDialog> {
  late final TextEditingController _nameCtrl;
  final TextEditingController _customDaysCtrl = TextEditingController();
  final TextEditingController _senderLimitCtrl = TextEditingController();
  bool _saving = false;
  String? _error;
  DateTime? _expiry;
  bool _customOpen = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialName);
    _expiry = widget.initialExpiry;
    if (widget.initialSenderLimit != null) {
      _senderLimitCtrl.text = widget.initialSenderLimit.toString();
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _customDaysCtrl.dispose();
    _senderLimitCtrl.dispose();
    super.dispose();
  }

  DateTime _endOfDay(DateTime d) => DateTime(d.year, d.month, d.day, 23, 59, 59);

  void _setExpiryDays(int days) {
    setState(() => _expiry = _endOfDay(DateTime.now().add(Duration(days: days))));
  }

  void _clearExpiry() {
    setState(() => _expiry = null);
  }

  void _applyCustomDays() {
    final v = int.tryParse(_customDaysCtrl.text.trim());
    if (v == null || v <= 0 || v > 3650) return;
    setState(() {
      _customOpen = true;
      _expiry = _endOfDay(DateTime.now().add(Duration(days: v)));
    });
  }

  Future<void> _pickExpiry() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _expiry ?? now.add(const Duration(days: 30)),
      firstDate: now.subtract(const Duration(days: 1)),
      lastDate: now.add(const Duration(days: 365 * 5)),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: Theme.of(ctx).colorScheme.copyWith(
            primary: NeoColors.yellow,
            onPrimary: NeoColors.black,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null && mounted) {
      setState(() => _expiry = _endOfDay(picked));
    }
  }

  Future<void> _submit() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Nama tidak boleh kosong.');
      return;
    }
    final senderLimitText = _senderLimitCtrl.text.trim();
    int? senderLimit;
    if (senderLimitText.isNotEmpty) {
      senderLimit = int.tryParse(senderLimitText);
      if (senderLimit == null || senderLimit < 0) {
        setState(() => _error = 'Limit sender harus berupa angka positif.');
        return;
      }
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    final result = await widget.onSave(name, _expiry?.toIso8601String(), senderLimit);
    if (!mounted) return;
    if (result['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      setState(() {
        _saving = false;
        _error = result['error']?['message'] ?? 'Failed to save.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.title, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: NeoColors.primaryText)),
              const SizedBox(height: 12),
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Nama', border: OutlineInputBorder()),
              ),
              const SizedBox(height: NeoSpacing.sm),
              if (widget.lockedUsername != null && widget.lockedUsername!.isNotEmpty) ...[
                Row(
                  children: [
                    const Icon(Icons.lock_outline, size: 14, color: NeoColors.grey),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(
                      child: Text(
                        '@${widget.lockedUsername}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: NeoColors.secondaryText),
                      ),
                    ),
                    const Text('username terkunci', style: TextStyle(fontSize: 9, color: NeoColors.grey)),
                  ],
                ),
                const SizedBox(height: NeoSpacing.md),
              ],
              Row(
                children: [
                  const Icon(Icons.event_outlined, size: 18, color: NeoColors.grey),
                  const SizedBox(width: NeoSpacing.sm),
                  Text('Masa aktif: ', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: isDark ? NeoColors.secondaryText : NeoColors.grey)),
                  Expanded(
                    child: TextButton(
                      onPressed: _pickExpiry,
                      child: Text(
                        _expiry == null
                            ? 'Tanpa batas'
                            : '${_expiry!.day.toString().padLeft(2, '0')}/${_expiry!.month.toString().padLeft(2, '0')}/${_expiry!.year}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                        textAlign: TextAlign.end,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.sm),
              Wrap(
                spacing: NeoSpacing.sm,
                runSpacing: NeoSpacing.sm,
                children: [
                  _EditChip(label: 'Tanpa batas', selected: _expiry == null, onTap: _clearExpiry),
                  _EditChip(label: '30 hari', selected: _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 30)))), onTap: () => _setExpiryDays(30)),
                  _EditChip(label: '90 hari', selected: _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 90)))), onTap: () => _setExpiryDays(90)),
                  _EditChip(label: '1 tahun', selected: _expiry != null && _sameDay(_expiry!, _endOfDay(DateTime.now().add(const Duration(days: 365)))), onTap: () => _setExpiryDays(365)),
                  _EditChip(label: 'Custom...', selected: _customOpen, onTap: () => setState(() => _customOpen = !_customOpen)),
                ],
              ),
              if (_customOpen) ...[
                const SizedBox(height: NeoSpacing.sm),
                Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _customDaysCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Jumlah hari',
                          suffixText: 'hari',
                          border: OutlineInputBorder(),
                        ),
                        onSubmitted: (_) => _applyCustomDays(),
                      ),
                    ),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(
                      flex: 2,
                      child: NeoButton(
                        label: 'TERAPKAN',
                        bgColor: NeoColors.yellow,
                        textColor: NeoColors.black,
                        height: 48,
                        fontSize: 12,
                        onPressed: _applyCustomDays,
                      ),
                    ),
                  ],
                ),
              ],
              const SizedBox(height: NeoSpacing.md),
              TextField(
                controller: _senderLimitCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Limit sender (kosongkan = pakai limit role)',
                  hintText: 'contoh: 3',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: NeoSpacing.sm),
              const Text(
                'Batas maksimal "add sender" untuk akun ini. Kosongkan agar mengikuti limit default role.',
                style: TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
              if (_error != null) ...[
                const SizedBox(height: NeoSpacing.sm),
                Text(_error!, style: const TextStyle(color: NeoColors.pink, fontSize: 12, fontWeight: FontWeight.w700)),
              ],
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  NeoButton(
                    label: 'CANCEL',
                    bgColor: NeoColors.surfaceElevated,
                    textColor: NeoColors.primaryText,
                    height: 40,
                    fontSize: 14,
                    onPressed: _saving ? null : () => Navigator.of(context).pop(false),
                  ),
                  const SizedBox(width: 8),
                  NeoButton(
                    label: 'SAVE',
                    bgColor: widget.accent,
                    textColor: NeoColors.white,
                    height: 40,
                    fontSize: 14,
                    loading: _saving,
                    onPressed: _submit,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

class _EditChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _EditChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? NeoColors.yellow : Colors.transparent,
          border: Border.all(color: selected ? NeoColors.yellow : NeoColors.border, width: 2),
          borderRadius: BorderRadius.circular(NeoRadius.sm),
        ),
        child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: selected ? NeoColors.black : NeoColors.grey)),
      ),
    );
  }
}
