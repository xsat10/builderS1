import 'package:flutter/material.dart';
import '../theme.dart';

class NeoIconButton extends StatefulWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final Color? bgColor;
  final Color? iconColor;
  final double size;
  final bool enabled;

  const NeoIconButton({
    super.key,
    required this.icon,
    this.onTap,
    this.bgColor,
    this.iconColor,
    this.size = 40,
    this.enabled = true,
  });

  @override
  State<NeoIconButton> createState() => _NeoIconButtonState();
}

class _NeoIconButtonState extends State<NeoIconButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final active = widget.enabled && widget.onTap != null;
    final bg = widget.bgColor ?? (isDark ? NeoColors.surface : NeoColors.white);
    final iconCol = widget.iconColor ??
        (active
            ? Theme.of(context).colorScheme.primary
            : NeoColors.secondaryText);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: active ? (_) => setState(() => _pressed = true) : null,
      onTapUp: active
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 110),
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          color: bg,
          border: Border.all(
            color: isDark ? NeoColors.line : NeoColors.border,
            width: NeoTheme.borderWidth,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.md),
          boxShadow: _pressed ? [] : NeoShadows.smD(isDark),
        ),
        transform: _pressed
            ? Matrix4.translationValues(2, 2, 0)
            : Matrix4.identity(),
        child: Icon(widget.icon, size: widget.size * 0.48, color: iconCol),
      ),
    );
  }
}