import 'package:flutter/material.dart';
import 'neo_feature_config.dart';

class TransitionState extends InheritedWidget {
  final double progress;
  final int exitIndex;
  final int enterIndex;
  final int currentIndex;
  final bool active;
  final FeatureTheme currentTheme;

  const TransitionState({
    super.key,
    required this.progress,
    required this.exitIndex,
    required this.enterIndex,
    required this.currentIndex,
    required this.active,
    required this.currentTheme,
    required super.child,
  });

  static TransitionState of(BuildContext context) {
    final result = context.dependOnInheritedWidgetOfExactType<TransitionState>();
    assert(result != null, 'No TransitionState found in context');
    return result!;
  }

  static TransitionState? maybeOf(BuildContext context) {
    return context.getInheritedWidgetOfExactType<TransitionState>();
  }

  @override
  bool updateShouldNotify(TransitionState old) {
    return old.progress != progress ||
        old.active != active ||
        old.exitIndex != exitIndex ||
        old.enterIndex != enterIndex ||
        old.currentIndex != currentIndex ||
        old.currentTheme != currentTheme;
  }
}
