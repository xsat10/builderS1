import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';

class NeoDeviceCard extends StatelessWidget {
  final Device device;
  final VoidCallback? onTap;
  final bool locked;
  final String? viewedByLabel;

  const NeoDeviceCard({
    super.key,
    required this.device,
    this.onTap,
    this.locked = false,
    this.viewedByLabel,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final statusColor = device.isOnline ? NeoColors.green : NeoColors.grey;

    return GestureDetector(
      onTap: locked ? null : onTap,
      child: Container(
        clipBehavior: Clip.antiAlias,
        padding: const EdgeInsets.all(NeoSpacing.md),
        decoration: BoxDecoration(
          color: locked
              ? (isDark ? NeoColors.darkCard : const Color(0xFFDDDDDD))
              : null,
            gradient: locked
              ? null
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                    colors: skin.isBubbleGum
                      ? [palette.surface.withValues(alpha: 0.88), palette.surface.withValues(alpha: 0.62)]
                      : isDark
                      ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
                      : [NeoColors.white.withValues(alpha: 0.9), NeoColors.white.withValues(alpha: 0.7)],
                ),
          border: Border.all(
            color: skin.isBubbleGum
              ? palette.primary.withValues(alpha: 0.65)
              : NeoColors.gold.withValues(alpha: 68 / 255),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.lg),
          boxShadow: [
            BoxShadow(
              color: NeoColors.black.withValues(alpha: 0.25),
              offset: const Offset(0, 8),
              blurRadius: 20,
              spreadRadius: -6,
            ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: statusColor,
                        shape: BoxShape.circle,
                        border: Border.all(color: NeoColors.black, width: 1),
                      ),
                    ),
                    const SizedBox(width: NeoSpacing.xs),
                    Expanded(
                      child: Text(
                        device.isOnline ? 'ONLINE' : 'OFFLINE',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                          color: statusColor,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: NeoColors.black,
                        borderRadius: BorderRadius.circular(3),
                      ),
                      child: Text(
                        device.network.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                          color: NeoColors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: NeoSpacing.sm),
                Text(
                  device.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cinzel(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                    color: isDark ? NeoColors.primaryText : NeoColors.black,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${device.model} • Android ${device.androidVersion}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10,
                    color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                  ),
                ),
                const SizedBox(height: NeoSpacing.sm),
                Row(
                  children: [
                    Expanded(child: _statCell('BAT', '${device.battery.toInt()}%', _cellColor(device.battery), isDark)),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(child: _statCell('CPU', '${device.cpu.toInt()}%', _cellColor(device.cpu), isDark)),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(child: _statCell('RAM', '${device.ram.toInt()}%', _cellColor(device.ram), isDark)),
                  ],
                ),
              ],
            ),
            if (locked)
              const SizedBox.expand(
                child: CustomPaint(painter: _HatchPainter()),
              ),
            if (locked)
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: NeoColors.orange,
                    border: Border.all(color: NeoColors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.lock, size: 11, color: NeoColors.black),
                      const SizedBox(width: 3),
                      Text(
                        viewedByLabel ?? 'DI LIHAT',
                        style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: NeoColors.black),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _statCell(String label, String value, Color accent, bool isDark) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0x0FFFFFFF),
        border: Border.all(
          color: const Color(0x22FFFFFF),
          width: 1,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(
              color: accent,
              borderRadius: BorderRadius.circular(3),
            ),
            child: Text(
              label,
              style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: NeoColors.black),
            ),
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              value,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: isDark ? NeoColors.primaryText : NeoColors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _cellColor(double v) {
    if (v < 15) return NeoColors.pink;
    if (v < 40) return NeoColors.orange;
    return NeoColors.green;
  }
}

class _HatchPainter extends CustomPainter {
  const _HatchPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoColors.white.withValues(alpha: 0.5)
      ..strokeWidth = 2;
    const gap = 10.0;
    for (double x = -size.height; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _HatchPainter oldDelegate) => false;
}
