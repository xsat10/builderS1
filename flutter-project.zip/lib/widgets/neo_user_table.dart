import 'package:flutter/material.dart';
import '../theme.dart';
import 'neo_table.dart';

class NeoUserTable extends StatelessWidget {
  final List<Map<String, dynamic>> users;
  final Color accent;
  final bool loading;
  final Widget? emptyWidget;
  final void Function(Map<String, dynamic> user)? onEdit;
  final void Function(Map<String, dynamic> user)? onReset;
  final void Function(Map<String, dynamic> user)? onToggle;
  final void Function(Map<String, dynamic> user)? onDelete;
  final bool Function(Map<String, dynamic> user)? canDelete;

  const NeoUserTable({
    super.key,
    required this.users,
    this.accent = NeoColors.member,
    this.loading = false,
    this.emptyWidget,
    this.onEdit,
    this.onReset,
    this.onToggle,
    this.onDelete,
    this.canDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return NeoTable(
      headers: const ['USERNAME', 'PASSWORD', 'ROLE', 'STATUS', 'AKSI'],
      columnWidths: const [9, 6, 7, 7, 10],
      loading: loading,
      emptyWidget: emptyWidget,
      rows: [
        for (final u in users)
          _row(u, isDark),
      ],
    );
  }

  List<Widget> _row(Map<String, dynamic> u, bool isDark) {
    final username = (u['username'] ?? u['email'] ?? '').toString();
    final role = (u['role'] ?? '').toString();
    return [
      Text(username, maxLines: 1, overflow: TextOverflow.ellipsis),
      const Text('••••••••'),
      _roleChip(role),
      _statusChip((u['status'] ?? 'active').toString(), isDark),
      Wrap(
        spacing: 2,
        runSpacing: 2,
        children: [
          if (onEdit != null)
            _iconAction(Icons.edit_outlined, accent, 'Edit', () => onEdit!(u)),
          if (onReset != null)
            _iconAction(
              Icons.lock_reset,
              NeoColors.yellow,
              'Reset Password',
              () => onReset!(u),
            ),
          if (onToggle != null)
            _iconAction(
              u['status'] == 'disabled'
                  ? Icons.check_circle_outline
                  : Icons.block,
              u['status'] == 'disabled' ? NeoColors.green : NeoColors.pink,
              u['status'] == 'disabled' ? 'Aktifkan' : 'Nonaktifkan',
              () => onToggle!(u),
            ),
          if (onDelete != null && (canDelete?.call(u) ?? true))
            _iconAction(
              Icons.delete_outline,
              NeoColors.pink,
              'Hapus',
              () => onDelete!(u),
            ),
        ],
      ),
    ];
  }

  Widget _roleChip(String role) {
    final color = NeoColors.roleColor(role);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.18),
        border: Border.all(color: color, width: 1.5),
        borderRadius: BorderRadius.circular(NeoRadius.sm),
      ),
      child: Text(
        role.isEmpty ? '—' : role.toUpperCase(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: NeoColors.black,
        ),
      ),
    );
  }

  Widget _statusChip(String status, bool isDark) {
    final color = status == 'active'
        ? NeoColors.green
        : status == 'disabled'
            ? NeoColors.grey
            : NeoColors.orange;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.18),
        border: Border.all(color: color, width: 1.5),
        borderRadius: BorderRadius.circular(NeoRadius.sm),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: isDark ? NeoColors.primaryText : Colors.black,
        ),
      ),
    );
  }

  Widget _iconAction(
    IconData icon,
    Color color,
    String tooltip,
    VoidCallback onTap,
  ) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(NeoRadius.sm),
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Icon(icon, size: 18, color: color),
        ),
      ),
    );
  }
}
