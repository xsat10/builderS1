import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

class NeoStatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color accentColor;
  final VoidCallback? onTap;

  const NeoStatCard({
    super.key,
    required this.label,
    required this.value,
    this.accentColor = NeoColors.yellow,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 6, height: 6, color: accentColor),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                  letterSpacing: 1,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: NeoSpacing.sm),
        Row(
          children: [
            Expanded(
              child: value == '—'
                  ? const Align(
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: 40,
                        child: NeoBlockLoader(blockSize: 6, c0: NeoColors.black, c1: NeoColors.yellow),
                      ),
                    )
                  : Text(
                      value,
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w800,
                        color: accentColor,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
            ),
            if (onTap != null)
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  color: accentColor,
                  border: Border.all(
                    color: isDark ? NeoColors.line : NeoColors.black,
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Icon(Icons.arrow_outward, size: 14, color: NeoColors.black),
              ),
          ],
        ),
      ],
    );
    return Container(
      clipBehavior: Clip.antiAlias,
      padding: const EdgeInsets.all(NeoSpacing.lg),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
            colors: skin.isBubbleGum
              ? [palette.surface.withValues(alpha: 0.88), palette.surface.withValues(alpha: 0.62)]
              : isDark
              ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
              : [NeoColors.white.withValues(alpha: 0.9), NeoColors.white.withValues(alpha: 0.7)],
        ),
        borderRadius: BorderRadius.circular(NeoRadius.xl),
        border: Border.all(
            color: skin.isBubbleGum
              ? palette.primary.withValues(alpha: 0.65)
              : isDark ? NeoColors.gold.withValues(alpha: 68 / 255) : NeoColors.gold.withValues(alpha: 102 / 255),
          width: 1.2,
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6),
        ],
      ),
      child: onTap == null
          ? content
          : GestureDetector(
              onTap: onTap,
              child: content,
            ),
    );
  }
}
