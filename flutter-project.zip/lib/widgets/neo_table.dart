import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';
import 'neo_block_loader.dart';

class NeoTable extends StatelessWidget {
  final List<String> headers;
  final List<int> columnWidths;
  final List<List<Widget>> rows;
  final bool loading;
  final Widget? emptyWidget;

  const NeoTable({
    super.key,
    required this.headers,
    required this.columnWidths,
    required this.rows,
    this.loading = false,
    this.emptyWidget,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    if (loading) {
      return const Padding(
        padding: EdgeInsets.all(NeoSpacing.xxl),
        child: Center(child: NeoBlockLoader(blockSize: 8, c0: NeoColors.black, c1: NeoColors.yellow)),
      );
    }
    if (rows.isEmpty) {
      return emptyWidget ??
          Padding(
            padding: const EdgeInsets.all(NeoSpacing.xl),
            child: Center(
              child: Text(
                'Tidak ada data',
                style: TextStyle(
                  fontSize: 13,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
            ),
          );
    }

    final cellPadding = const EdgeInsets.symmetric(
      horizontal: NeoSpacing.sm,
      vertical: 10,
    );

    return Container(
      decoration: BoxDecoration(
        border: Border.all(
            color: skin.isBubbleGum
              ? palette.primary.withValues(alpha: 0.65)
              : isDark ? NeoColors.gold.withValues(alpha: 68 / 255) : NeoColors.gold.withValues(alpha: 102 / 255),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(NeoRadius.lg),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
            colors: skin.isBubbleGum
              ? [palette.surface.withValues(alpha: 0.88), palette.surface.withValues(alpha: 0.62)]
              : isDark
              ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
              : [NeoColors.white.withValues(alpha: 0.9), NeoColors.white.withValues(alpha: 0.7)],
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                color: isDark ? NeoColors.surfaceElevated : NeoColors.cream,
                child: Row(
                  children: [
                    for (var i = 0; i < headers.length; i++)
                      Expanded(
                        flex: columnWidths[i],
                        child: Padding(
                          padding: cellPadding,
                          child: Text(
                            headers[i],
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.6,
                              color: NeoColors.secondaryText,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              for (var r = 0; r < rows.length; r++)
                Container(
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: NeoColors.border.withValues(alpha: 0.5),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      for (var c = 0; c < rows[r].length; c++)
                        Expanded(
                          flex: columnWidths[c],
                          child: Padding(
                            padding: cellPadding,
                            child: DefaultTextStyle(
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: isDark
                                    ? NeoColors.primaryText
                                    : NeoColors.black,
                              ),
                              child: rows[r][c],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
    );
  }
}
