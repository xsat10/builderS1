import 'dart:math';
import 'package:flutter/material.dart';

/// NeoRoleRing — cincin kerajaan sesuai hierarki role.
/// Semakin tinggi role, semakin menyala "api"-nya (member → developer):
/// member polos perak, vip api redup, dan developer meledak penuh api
/// ungu + aura + butiran percikan. Glow berdenyut mengikuti warna role.
/// Akun bebas (polosan) tidak memakai ring ini.
class NeoRoleRing extends StatefulWidget {
  final String role;
  final double size;
  final Widget? child;
  final EdgeInsetsGeometry padding;
  final bool active;

  const NeoRoleRing({
    super.key,
    this.role = 'member',
    this.size = 68,
    this.child,
    this.padding = const EdgeInsets.all(3),
    this.active = true,
  });

  @override
  State<NeoRoleRing> createState() => _NeoRoleRingState();
}

class _NeoRoleRingState extends State<NeoRoleRing>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    );
    if (_RingSpec.of(widget.role).fire > 0) {
      _ctrl.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant NeoRoleRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    final animate = _RingSpec.of(widget.role).fire > 0;
    if (animate && !_ctrl.isAnimating) {
      _ctrl.repeat();
    } else if (!animate && _ctrl.isAnimating) {
      _ctrl.stop();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final spec = _RingSpec.of(widget.role);
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: Stack(
        children: [
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (_, _) {
                return CustomPaint(
                  painter: _RoleRingPainter(
                    spec: spec,
                    accent: NeoRoles.colorOf(widget.role),
                    progress: _ctrl.value,
                    active: widget.active,
                  ),
                );
              },
            ),
          ),
          if (widget.child != null)
            Positioned.fill(
              child: Padding(padding: widget.padding, child: widget.child),
            ),
        ],
      ),
    );
  }
}

class _RingSpec {
  final int strokes; // jumlah garis konsentris
  final bool dots; // titik N / E / S / W
  final bool diamonds; // wajik di 45°,135°,225°,315°
  final bool ticks; // takik radial di sela-sela ornamen
  final double fire; // intensitas api 0..1 (0 = polos, 1 = menyala maksimal)
  final int comets; // jumlah komet api yang berputar
  final double alpha; // kekuatan garis utama

  const _RingSpec({
    required this.strokes,
    required this.dots,
    required this.diamonds,
    required this.ticks,
    required this.fire,
    required this.comets,
    required this.alpha,
  });

  static _RingSpec of(String role) {
    switch (role) {
      case 'developer':
        return const _RingSpec(strokes: 3, dots: true, diamonds: true, ticks: true, fire: 1.0, comets: 3, alpha: 1.0);
      case 'partner':
        return const _RingSpec(strokes: 2, dots: true, diamonds: true, ticks: true, fire: 0.85, comets: 2, alpha: 0.96);
      case 'moderator':
        return const _RingSpec(strokes: 2, dots: true, diamonds: true, ticks: false, fire: 0.65, comets: 2, alpha: 0.92);
      case 'reseller':
        return const _RingSpec(strokes: 2, dots: true, diamonds: false, ticks: false, fire: 0.50, comets: 1, alpha: 0.88);
      case 'vip':
        return const _RingSpec(strokes: 1, dots: false, diamonds: false, ticks: false, fire: 0.28, comets: 1, alpha: 0.85);
      default: // member
        return const _RingSpec(strokes: 1, dots: false, diamonds: false, ticks: false, fire: 0.0, comets: 0, alpha: 0.55);
    }
  }
}

class _RoleRingPainter extends CustomPainter {
  final _RingSpec spec;
  final Color accent;
  final double progress; // 0..1
  final bool active;

  _RoleRingPainter({
    required this.spec,
    required this.accent,
    this.progress = 0,
    this.active = true,
  });

  static const _gold = Color(0xFFE5C365);
  static const _goldBright = Color(0xFFF3D98A);
  static const _silver = Color(0xFFCFCFCF);

  /// Nyala api yang "hidup" — gabungan dua gelombang untuk genjatan tak beraturan.
  double _flame(double p, [double ph = 0]) {
    final x = p * 2 * pi + ph;
    final w1 = 0.5 + 0.5 * sin(x);
    final w2 = 0.5 + 0.5 * sin(x * 2.37 + 1.31);
    return (w1 * 0.6 + w2 * 0.4).clamp(0.0, 1.0);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 0.5;
    final fire = spec.fire;
    final fl = _flame(progress);

    final base = !active ? _silver : (spec.strokes > 1 || spec.dots || spec.diamonds || spec.ticks ? _gold : (fire > 0 ? _gold : _silver));

    // 1) Aura — bauran radial menyala mengikuti warna role.
    if (fire > 0) {
      final gazeR = r + 2 + 8 * fire;
      final gaze = Paint()
        ..shader = RadialGradient(colors: [
          accent.withValues(alpha: 0.30 * fire * (0.6 + 0.4 * fl)),
          accent.withValues(alpha: 0.12 * fire * (0.5 + 0.5 * fl)),
          accent.withValues(alpha: 0),
        ]).createShader(Rect.fromCircle(center: c, radius: gazeR));
      canvas.drawCircle(c, gazeR, gaze);
    }

    // 2) Neon blur — cincin luar temaram yang mengikuti denyut api.
    if (fire > 0) {
      final neonLayers = fire >= 1.0 ? 3 : (fire >= 0.5 ? 2 : 1);
      for (var i = 1; i <= neonLayers; i++) {
        final neon = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2.0 * i + 1.0)
          ..color = accent.withValues(alpha: fire * (0.16 - 0.05 * i) * (0.7 + 0.3 * fl));
        canvas.drawCircle(c, r + i * 2.0, neon);
      }
    }

    // 3) Garis konsentris dari luar ke dalam.
    for (var i = 0; i < spec.strokes; i++) {
      final inset = i == 0 ? 1.2 : (1.2 + 3.2 * i);
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = i == 0 ? 1.5 : 1.0
        ..color = base.withValues(alpha: i == 0 ? spec.alpha : spec.alpha * 0.5);
      canvas.drawCircle(c, r - inset, paint);
    }

    final ringR = r - 1.2; // radius untuk ornamen & api

    // 4) Titik di N / E / S / W.
    if (spec.dots) {
      final dot = Paint()..color = accent.withValues(alpha: 0.95);
      for (final a in [0.0, 90.0, 180.0, 270.0]) {
        canvas.drawCircle(_polarDeg(c, ringR, a), 1.35, dot);
      }
    }

    // 5) Wajik di sela titik.
    if (spec.diamonds) {
      final half = 1.7;
      final gem = Paint()..color = _goldBright.withValues(alpha: 0.95);
      for (final a in [45.0, 135.0, 225.0, 315.0]) {
        canvas.save();
        canvas.translate(_polarDeg(c, ringR, a).dx, _polarDeg(c, ringR, a).dy);
        canvas.rotate(pi / 4);
        canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: half * 2, height: half * 2), gem);
        canvas.restore();
      }
    }

    // 6) Takik radial di antara ornamen (partner & developer).
    if (spec.ticks) {
      final tick = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3
        ..color = accent.withValues(alpha: 0.8);
      for (var k = 0; k < 8; k++) {
        final a = 22.5 + k * 45.0;
        final inner = _polarDeg(c, r - 3.4, a);
        final outer = _polarDeg(c, r - 0.6, a);
        canvas.drawLine(inner, outer, tick);
      }
    }

    // 7) API — komet menyala berputar; makin tinggi role makin banyak,
    //    makin tebal, makin cerah, dan makin cepat putarannya.
    if (fire > 0) {
      final speed = 0.55 + 0.8 * fire; // role tinggi berputar lebih cepat
      final t = progress * 2 * pi * speed;

      for (var i = 0; i < spec.comets; i++) {
        final baseAngle = spec.comets > 1 ? i * (2 * pi / spec.comets) : 0.0;
        final head = -pi / 2 + t + baseAngle;
        // Setiap komet berdenyut dengan fase berbeda agar hidup.
        final flick = _flame(progress, i * 2.1 + 0.5);
        final bright = (0.55 + 0.45 * fire) * (0.7 + 0.3 * flick);
        final headSweep = 1.15 + 1.05 * fire;

        // ekor panjang redup
        _arc(canvas, c, r - 1.2, head - headSweep * 3.4, headSweep * 3.4,
            accent.withValues(alpha: 0.16 * bright), 0.7);
        // badan komet
        _arc(canvas, c, r - 1.2, head - headSweep * 2.1, headSweep * 2.1,
            accent.withValues(alpha: 0.36 * bright), 1.0 + 0.8 * fire);
        // kepala api
        _arc(canvas, c, r - 1.2, head - headSweep, headSweep,
            accent.withValues(alpha: 0.78 * bright), 1.5 + 1.6 * fire);
        // pusat putih-panas
        _arc(canvas, c, r - 1.2, head - 0.30, 0.30,
            Color.lerp(accent, Colors.white, 0.6)!.withValues(alpha: 0.9 * bright),
            1.2 + 1.0 * fire);

        // titik api di ujung kepala
        final tip = _polarRad(c, r - 1.2, head);
        canvas.drawCircle(
            tip,
            1.6 + 1.5 * fire,
            Paint()
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.2)
              ..color = accent.withValues(alpha: 0.55 * bright));
        canvas.drawCircle(
            tip,
            0.9 + 0.9 * fire,
            Paint()
              ..color = Color.lerp(accent, Colors.white, 0.7)!.withValues(alpha: 0.95 * bright));

        // butiran percikan yang rontok di belakang komet
        final spkCount = (3 + 7 * fire).round();
        for (var s = 1; s <= spkCount; s++) {
          final a = head - 0.16 * s * (1 - flick * 0.35);
          final jit = sin(head * 57.29578 + s * 12.9898) * 0.8;
          final pos = _polarRad(c, r - 1.2 + jit * 0.4, a);
          final fade = 1 - s / (spkCount + 1);
          canvas.drawCircle(
              pos,
              0.4 + 0.6 * fade * fire,
              Paint()..color = accent.withValues(alpha: 0.5 * bright * fade));
        }
      }
    }
  }

  void _arc(Canvas canvas, Offset center, double radius, double start, double sweep, Color color, double width) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = width
      ..color = color;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, sweep, false, paint);
  }

  Offset _polarDeg(Offset center, double radius, double angleDeg) {
    return _polarRad(center, radius, angleDeg * pi / 180);
  }

  Offset _polarRad(Offset center, double radius, double angleRad) {
    return center + Offset(cos(angleRad) * radius, sin(angleRad) * radius);
  }

  @override
  bool shouldRepaint(covariant _RoleRingPainter oldDelegate) {
    return oldDelegate.spec != spec ||
        oldDelegate.accent != accent ||
        oldDelegate.active != active ||
        (oldDelegate.progress - progress).abs() > 0.0001;
  }
}

class NeoRoles {
  NeoRoles._();

  static const Map<String, Color> _colors = {
    'developer': Color(0xFF9B6BFF),
    'partner': Color(0xFFFF9F43),
    'reseller': Color(0xFF36C5F0),
    'moderator': Color(0xFF3DD3A5),
    'vip': Color(0xFFFFD700),
  };

  static Color colorOf(String role) => _colors[role] ?? const Color(0xFFC9A55A);
}