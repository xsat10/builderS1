import 'package:flutter/material.dart';
import 'landing.dart';

class StuxOnboardingPage extends StatefulWidget {
  const StuxOnboardingPage({super.key});
  @override
  State<StuxOnboardingPage> createState() => _StuxOnboardingPageState();
}

class _StuxOnboardingPageState extends State<StuxOnboardingPage> {
  int _index = 0;
  final _pages = const [
    _IntroData('WELCOME TO STUX X 01',
      'Selamat datang di STUX X 01.\nNikmati pengalaman modern dengan tampilan cyan neon dan berbagai fitur yang dirancang agar nyaman, praktis, dan mudah digunakan.'),
    _IntroData('TENTANG STUX X 01',
      'STUX X 01 adalah platform dengan berbagai fitur dan tools yang terus dikembangkan.\nGunakan setiap fitur dengan bijak dan nikmati pengalaman yang cepat, rapi, dan modern.'),
    _IntroData('LARANGAN & ATURAN',
      'Gunakan STUX X 01 secara bertanggung jawab.\nDilarang menyalahgunakan fitur, merugikan pengguna lain, mengganggu layanan, atau melakukan aktivitas yang melanggar hukum.\nDengan melanjutkan, kamu menyetujui aturan penggunaan.'),
  ];

  void _go(int delta) {
    final next = _index + delta;
    if (next < 0) return;
    if (next >= _pages.length) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LandingPage()));
      return;
    }
    setState(() => _index = next);
  }

  @override
  Widget build(BuildContext context) {
    final page = _pages[_index];
    return Scaffold(
      backgroundColor: const Color(0xFF050914),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onVerticalDragEnd: (details) {
          final v = details.primaryVelocity ?? 0;
          // STUX navigation: swipe DOWN = lanjut, swipe UP = kembali.
          if (v >= 220) {
            _go(1);
          } else if (v <= -220) {
            _go(-1);
          }
        },
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _NeonGridPainter())),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Text('STUX X 01',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 2)),
                        const Spacer(),
                        Text('${_index + 1}/3',
                          style: const TextStyle(color: Color(0xFF67F9FF), fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 280),
                        transitionBuilder: (child, anim) => FadeTransition(
                          opacity: anim,
                          child: SlideTransition(
                            position: Tween(begin: const Offset(0, .08), end: Offset.zero).animate(anim),
                            child: child,
                          ),
                        ),
                        child: Center(
                          key: ValueKey(_index),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 520),
                            child: Container(
                              padding: const EdgeInsets.all(28),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(.045),
                                borderRadius: BorderRadius.circular(28),
                                border: Border.all(color: const Color(0xFF00F5FF).withOpacity(.25)),
                                boxShadow: [BoxShadow(color: const Color(0xFF00F5FF).withOpacity(.10), blurRadius: 35, spreadRadius: 2)],
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 72, height: 72,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: const Color(0xFF00F5FF).withOpacity(.10),
                                      border: Border.all(color: const Color(0xFF00F5FF).withOpacity(.55)),
                                      boxShadow: [BoxShadow(color: const Color(0xFF00F5FF).withOpacity(.25), blurRadius: 22)],
                                    ),
                                    child: const Icon(Icons.bolt_rounded, color: Color(0xFF67F9FF), size: 38),
                                  ),
                                  const SizedBox(height: 28),
                                  Text(page.title, textAlign: TextAlign.center,
                                    style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                                  const SizedBox(height: 16),
                                  Text(page.body, textAlign: TextAlign.center,
                                    style: const TextStyle(color: Color(0xFFB7C7D9), fontSize: 14, height: 1.65)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(3, (i) => AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: i == _index ? 28 : 7, height: 7,
                        decoration: BoxDecoration(
                          color: i == _index ? const Color(0xFF00F5FF) : Colors.white24,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: i == _index ? const [BoxShadow(color: Color(0xFF00F5FF), blurRadius: 8)] : null,
                        ),
                      )),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _index == 0
                          ? 'GESER KE BAWAH UNTUK LANJUT'
                          : _index == 2
                              ? 'GESER KE BAWAH UNTUK MASUK\nGESER KE ATAS UNTUK KEMBALI'
                              : 'GESER KE BAWAH UNTUK LANJUT\nGESER KE ATAS UNTUK KEMBALI',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFF67F9FF), fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: .8),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class _IntroData {
  final String title, body;
  const _IntroData(this.title, this.body);
}
class _NeonGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFF00F5FF).withOpacity(.035)..strokeWidth = .7;
    const gap = 36.0;
    for (double x=0;x<size.width;x+=gap) canvas.drawLine(Offset(x,0), Offset(x,size.height), p);
    for (double y=0;y<size.height;y+=gap) canvas.drawLine(Offset(0,y), Offset(size.width,y), p);
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
