import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'landing.dart';

class StuxOnboardingPage extends StatefulWidget {
  const StuxOnboardingPage({super.key});

  @override
  State<StuxOnboardingPage> createState() => _StuxOnboardingPageState();
}

class _StuxOnboardingPageState extends State<StuxOnboardingPage>
    with TickerProviderStateMixin {
  late final AnimationController _floatController;
  late final AnimationController _pulseController;
  late final AnimationController _contentController;

  @override
  void initState() {
    super.initState();

    // Animasi bubble + dragon.
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();

    // Animasi glow/pulse.
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    // Animasi masuk konten.
    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) {
        _contentController.forward();
      }
    });
  }

  @override
  void dispose() {
    _floatController.dispose();
    _pulseController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  // ==============================
  // MENUJU LANDING PAGE
  // ==============================

  void _openLanding() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => const LandingPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF030712),
      body: Stack(
        children: [
          // ==============================
          // BACKGROUND GRID
          // ==============================

          const Positioned.fill(
            child: CustomPaint(
              painter: _NeonGridPainter(),
            ),
          ),

          // ==============================
          // FLOATING BUBBLES
          // ==============================

          Positioned.fill(
            child: AnimatedBuilder(
              animation: _floatController,
              builder: (context, child) {
                return CustomPaint(
                  painter: _BubblePainter(
                    progress: _floatController.value,
                  ),
                );
              },
            ),
          ),

          // ==============================
          // BACKGROUND GLOW
          // ==============================

          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.35),
                    radius: 1.15,
                    colors: [
                      const Color(0xFF00E5FF).withValues(alpha: 0.10),
                      Colors.transparent,
                      const Color(0xFF030712),
                    ],
                    stops: const [
                      0.0,
                      0.42,
                      1.0,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ==============================
          // MAIN CONTENT
          // ==============================

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(
                24,
                22,
                24,
                24,
              ),
              child: Column(
                children: [
                  _buildTopBar(),

                  Expanded(
                    child: Center(
                      child: AnimatedBuilder(
                        animation: _contentController,
                        builder: (context, child) {
                          final value = Curves.easeOutCubic.transform(
                            _contentController.value,
                          );

                          return Opacity(
                            opacity: value,
                            child: Transform.translate(
                              offset: Offset(
                                0,
                                35 * (1 - value),
                              ),
                              child: child,
                            ),
                          );
                        },
                        child: _buildMainContent(),
                      ),
                    ),
                  ),

                  _buildBottomSection(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==============================
  // TOP BAR
  // ==============================

  Widget _buildTopBar() {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF00E5FF).withValues(alpha: 0.08),
            border: Border.all(
              color: const Color(0xFF00E5FF).withValues(alpha: 0.25),
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00E5FF).withValues(alpha: 0.08),
                blurRadius: 20,
              ),
            ],
          ),
          child: const Icon(
            Icons.shield_outlined,
            color: Color(0xFF67F9FF),
            size: 21,
          ),
        ),
        const SizedBox(width: 12),
        const Text(
          'STUX X 01',
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF00E5FF).withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: const Color(0xFF00E5FF).withValues(alpha: 0.18),
            ),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _StatusDot(),
              SizedBox(width: 6),
              Text(
                'ONLINE',
                style: TextStyle(
                  color: Color(0xFF67F9FF),
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==============================
  // MAIN CONTENT
  // ==============================

  Widget _buildMainContent() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // DRAGON CYBER
        AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            final pulse =
                1 + (_pulseController.value * 0.035);

            return Transform.scale(
              scale: pulse,
              child: child,
            );
          },
          child: const _AnimatedLinuxDragon(),
        ),

        const SizedBox(height: 25),

        const Text(
          'WELCOME TO',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFF67F9FF),
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 4,
          ),
        ),

        const SizedBox(height: 9),

        const Text(
          'STUX X 01',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontSize: 34,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            height: 1,
          ),
        ),

        const SizedBox(height: 18),

        Container(
          constraints: const BoxConstraints(
            maxWidth: 430,
          ),
          child: Text(
            'Platform modern dengan pengalaman futuristik, '
            'cepat, praktis, dan dirancang untuk membuat '
            'setiap fitur terasa lebih nyaman digunakan.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: const Color(0xFFB7C7D9).withValues(
                alpha: 0.90,
              ),
              fontSize: 14,
              height: 1.7,
            ),
          ),
        ),

        const SizedBox(height: 25),

        _buildFeatureRow(),
      ],
    );
  }

  // ==============================
  // FEATURE
  // ==============================

  Widget _buildFeatureRow() {
    return const Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _MiniFeature(
          icon: Icons.auto_awesome,
          label: 'MODERN',
        ),
        SizedBox(width: 8),
        _MiniFeature(
          icon: Icons.flash_on_rounded,
          label: 'FAST',
        ),
        SizedBox(width: 8),
        _MiniFeature(
          icon: Icons.security_rounded,
          label: 'SECURE',
        ),
      ],
    );
  }

  // ==============================
  // BOTTOM
  // ==============================

  Widget _buildBottomSection() {
    return Column(
      children: [
        GestureDetector(
          onTap: _openLanding,
          child: Container(
            width: double.infinity,
            constraints: const BoxConstraints(
              maxWidth: 460,
            ),
            height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [
                  Color(0xFF073A4A),
                  Color(0xFF005B70),
                  Color(0xFF073A4A),
                ],
              ),
              border: Border.all(
                color: const Color(0xFF67F9FF).withValues(
                  alpha: 0.38,
                ),
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF00E5FF).withValues(
                    alpha: 0.16,
                  ),
                  blurRadius: 24,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'LANJUTKAN',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                SizedBox(width: 12),
                Icon(
                  Icons.arrow_forward_rounded,
                  color: Color(0xFF67F9FF),
                  size: 21,
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 8),

        TextButton(
          onPressed: _openLanding,
          child: const Text(
            'NANTI',
            style: TextStyle(
              color: Color(0xFF8495A8),
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
            ),
          ),
        ),

        const SizedBox(height: 2),

        const Text(
          'STUX SYSTEM • READY TO START',
          style: TextStyle(
            color: Color(0xFF526477),
            fontSize: 8,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

// ============================================================
// ANIMATED DRAGON
// ============================================================

class _AnimatedLinuxDragon extends StatefulWidget {
  const _AnimatedLinuxDragon();

  @override
  State<_AnimatedLinuxDragon> createState() =>
      _AnimatedLinuxDragonState();
}

class _AnimatedLinuxDragonState
    extends State<_AnimatedLinuxDragon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final t = _controller.value * math.pi * 2;

        return Transform.translate(
          offset: Offset(
            math.sin(t) * 7,
            math.sin(t * 2) * 5,
          ),
          child: Transform.rotate(
            angle: math.sin(t) * 0.025,
            child: child,
          ),
        );
      },
      child: const SizedBox(
        width: 185,
        height: 185,
        child: CustomPaint(
          painter: _DragonPainter(),
        ),
      ),
    );
  }
}

// ============================================================
// DRAGON PAINTER
// ============================================================

class _DragonPainter extends CustomPainter {
  const _DragonPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    // --------------------------
    // OUTER GLOW
    // --------------------------

    final glow = Paint()
      ..color = const Color(0xFF00E5FF).withValues(
        alpha: 0.10,
      )
      ..maskFilter = const MaskFilter.blur(
        BlurStyle.normal,
        28,
      );

    canvas.drawCircle(
      Offset(cx, cy),
      65,
      glow,
    );

    // --------------------------
    // TECHNO RINGS
    // --------------------------

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = const Color(0xFF00E5FF).withValues(
        alpha: 0.16,
      );

    canvas.drawCircle(
      Offset(cx, cy),
      78,
      ring,
    );

    canvas.drawCircle(
      Offset(cx, cy),
      66,
      ring,
    );

    // --------------------------
    // HEAD
    // --------------------------

    final head = Paint()
      ..color = const Color(0xFF071C27)
      ..style = PaintingStyle.fill;

    final headOutline = Paint()
      ..color = const Color(0xFF67F9FF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final headPath = Path();

    headPath.moveTo(
      cx - 43,
      cy - 15,
    );

    // Tanduk kiri
    headPath.lineTo(
      cx - 58,
      cy - 50,
    );

    headPath.lineTo(
      cx - 35,
      cy - 37,
    );

    // Kepala
    headPath.quadraticBezierTo(
      cx - 22,
      cy - 59,
      cx,
      cy - 61,
    );

    headPath.quadraticBezierTo(
      cx + 22,
      cy - 59,
      cx + 35,
      cy - 37,
    );

    // Tanduk kanan
    headPath.lineTo(
      cx + 58,
      cy - 50,
    );

    headPath.lineTo(
      cx + 43,
      cy - 15,
    );

    // Rahang
    headPath.quadraticBezierTo(
      cx + 34,
      cy + 35,
      cx,
      cy + 48,
    );

    headPath.quadraticBezierTo(
      cx - 34,
      cy + 35,
      cx - 43,
      cy - 15,
    );

    headPath.close();

    canvas.drawPath(
      headPath,
      head,
    );

    canvas.drawPath(
      headPath,
      headOutline,
    );

    // --------------------------
    // MATA
    // --------------------------

    final eye = Paint()
      ..color = const Color(0xFF67F9FF);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(
          cx - 22,
          cy - 18,
        ),
        width: 19,
        height: 9,
      ),
      eye,
    );

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(
          cx + 22,
          cy - 18,
        ),
        width: 19,
        height: 9,
      ),
      eye,
    );

    // Glow mata
    final eyeGlow = Paint()
      ..color = const Color(0xFF00E5FF).withValues(
        alpha: 0.35,
      )
      ..maskFilter = const MaskFilter.blur(
        BlurStyle.normal,
        8,
      );

    canvas.drawCircle(
      Offset(cx - 22, cy - 18),
      5,
      eyeGlow,
    );

    canvas.drawCircle(
      Offset(cx + 22, cy - 18),
      5,
      eyeGlow,
    );

    // --------------------------
    // HIDUNG
    // --------------------------

    final nose = Paint()
      ..color = const Color(0xFF67F9FF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final nosePath = Path()
      ..moveTo(
        cx - 7,
        cy + 1,
      )
      ..lineTo(
        cx,
        cy + 7,
      )
      ..lineTo(
        cx + 7,
        cy + 1,
      );

    canvas.drawPath(
      nosePath,
      nose,
    );

    // --------------------------
    // MULUT
    // --------------------------

    final mouth = Paint()
      ..color = const Color(0xFF00E5FF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final mouthPath = Path()
      ..moveTo(
        cx - 24,
        cy + 15,
      )
      ..quadraticBezierTo(
        cx,
        cy + 31,
        cx + 24,
        cy + 15,
      );

    canvas.drawPath(
      mouthPath,
      mouth,
    );

    // --------------------------
    // TARING
    // --------------------------

    final fang = Paint()
      ..color = const Color(0xFFBDFBFF);

    final leftFang = Path()
      ..moveTo(
        cx - 18,
        cy + 22,
      )
      ..lineTo(
        cx - 13,
        cy + 34,
      )
      ..lineTo(
        cx - 8,
        cy + 22,
      )
      ..close();

    final rightFang = Path()
      ..moveTo(
        cx + 8,
        cy + 22,
      )
      ..lineTo(
        cx + 13,
        cy + 34,
      )
      ..lineTo(
        cx + 18,
        cy + 22,
      )
      ..close();

    canvas.drawPath(
      leftFang,
      fang,
    );

    canvas.drawPath(
      rightFang,
      fang,
    );

    // --------------------------
    // SAYAP KIRI
    // --------------------------

    final wingPaint = Paint()
      ..color = const Color(0xFF062F3C)
      ..style = PaintingStyle.fill;

    final wingOutline = Paint()
      ..color = const Color(0xFF00E5FF).withValues(
        alpha: 0.65,
      )
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final leftWing = Path()
      ..moveTo(
        cx - 42,
        cy - 5,
      )
      ..lineTo(
        cx - 84,
        cy - 30,
      )
      ..lineTo(
        cx - 67,
        cy + 4,
      )
      ..lineTo(
        cx - 84,
        cy + 22,
      )
      ..lineTo(
        cx - 47,
        cy + 18,
      )
      ..close();

    canvas.drawPath(
      leftWing,
      wingPaint,
    );

    canvas.drawPath(
      leftWing,
      wingOutline,
    );

    // --------------------------
    // SAYAP KANAN
    // --------------------------

    final rightWing = Path()
      ..moveTo(
        cx + 42,
        cy - 5,
      )
      ..lineTo(
        cx + 84,
        cy - 30,
      )
      ..lineTo(
        cx + 67,
        cy + 4,
      )
      ..lineTo(
        cx + 84,
        cy + 22,
      )
      ..lineTo(
        cx + 47,
        cy + 18,
      )
      ..close();

    canvas.drawPath(
      rightWing,
      wingPaint,
    );

    canvas.drawPath(
      rightWing,
      wingOutline,
    );

    // --------------------------
    // ENERGY LINE
    // --------------------------

    final energy = Paint()
      ..color = const Color(0xFF67F9FF).withValues(
        alpha: 0.7,
      )
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(cx, cy - 75),
      Offset(cx, cy - 62),
      energy,
    );

    canvas.drawLine(
      Offset(cx, cy + 49),
      Offset(cx, cy + 70),
      energy,
    );
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}

// ============================================================
// MINI FEATURE
// ============================================================

class _MiniFeature extends StatelessWidget {
  final IconData icon;
  final String label;

  const _MiniFeature({
    required this.icon,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withValues(
          alpha: 0.025,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF00E5FF).withValues(
            alpha: 0.10,
          ),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: const Color(0xFF67F9FF),
            size: 13,
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF8FA6B8),
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// STATUS DOT
// ============================================================

class _StatusDot extends StatefulWidget {
  const _StatusDot();

  @override
  State<_StatusDot> createState() => _StatusDotState();
}

class _StatusDotState extends State<_StatusDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1200,
      ),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final size = 6 + (_controller.value * 2);

        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF67F9FF),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00E5FF).withValues(
                  alpha: 0.25 +
                      (_controller.value * 0.3),
                ),
                blurRadius: 8,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ============================================================
// NEON GRID
// ============================================================

class _NeonGridPainter extends CustomPainter {
  const _NeonGridPainter();

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = const Color(0xFF00E5FF).withValues(
        alpha: 0.025,
      )
      ..strokeWidth = 0.6;

    const gap = 36.0;

    for (
      double x = 0;
      x <= size.width;
      x += gap
    ) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        paint,
      );
    }

    for (
      double y = 0;
      y <= size.height;
      y += gap
    ) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}

// ============================================================
// FLOATING BUBBLES
// ============================================================

class _BubblePainter extends CustomPainter {
  final double progress;

  const _BubblePainter({
    required this.progress,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final bubbles = <_Bubble>[
      const _Bubble(
        x: 0.10,
        y: 0.18,
        radius: 30,
        speed: 1.0,
      ),
      const _Bubble(
        x: 0.88,
        y: 0.26,
        radius: 18,
        speed: 1.4,
      ),
      const _Bubble(
        x: 0.06,
        y: 0.72,
        radius: 14,
        speed: 1.7,
      ),
      const _Bubble(
        x: 0.93,
        y: 0.78,
        radius: 35,
        speed: 0.8,
      ),
      const _Bubble(
        x: 0.25,
        y: 0.52,
        radius: 7,
        speed: 2.0,
      ),
      const _Bubble(
        x: 0.78,
        y: 0.57,
        radius: 9,
        speed: 1.8,
      ),
    ];

    for (final bubble in bubbles) {
      final wave = math.sin(
        (progress * math.pi * 2 * bubble.speed) +
            (bubble.x * 4),
      );

      final dx =
          bubble.x * size.width + (wave * 10);

      final dy =
          bubble.y * size.height + (wave * 14);

      final glowPaint = Paint()
        ..color = const Color(0xFF00E5FF).withValues(
          alpha: 0.035,
        )
        ..maskFilter = MaskFilter.blur(
          BlurStyle.normal,
          bubble.radius * 0.8,
        );

      canvas.drawCircle(
        Offset(dx, dy),
        bubble.radius,
        glowPaint,
      );

      final borderPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8
        ..color = const Color(0xFF00E5FF).withValues(
          alpha: 0.10,
        );

      canvas.drawCircle(
        Offset(dx, dy),
        bubble.radius,
        borderPaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant _BubblePainter oldDelegate,
  ) {
    return oldDelegate.progress != progress;
  }
}

// ============================================================
// BUBBLE DATA
// ============================================================

class _Bubble {
  final double x;
  final double y;
  final double radius;
  final double speed;

  const _Bubble({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
  });
}