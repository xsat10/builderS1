// lib/config.dart
// ============================================================
// KONFIGURASI SERVER
// GANTI IP & PORT DI BAWAH INI SESUAI PORT HTTP VPS ANDA
// JANGAN pakai port SSH (27239) - itu tidak akan bekerja
// ============================================================
const String SERVER_HOST = "66.33.22.220";
const int SERVER_HTTP_PORT = 8080; // GANTI ke port HTTP NAT Anda
const String API_PATH = "/api/sms";

String get baseUrl => "http://$SERVER_HOST:$SERVER_HTTP_PORT";
String get apiSmsUrl => "$baseUrl$API_PATH";