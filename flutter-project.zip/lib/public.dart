import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:provider/provider.dart';
import 'package:gal/gal.dart';
import 'package:file_picker/file_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'providers/auth_provider.dart';
import 'providers/public_chat_unread_provider.dart';
import 'services/api_service.dart';
import 'services/sticker_service.dart';
import 'theme.dart';
import 'utils/app_config.dart';

class PublicChatPage extends StatefulWidget {
  const PublicChatPage({super.key});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final ApiService _api = ApiService();
  final StickerService _stickerService = StickerService();

  List<Map<String, dynamic>> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  String? _replyToId;
  Map<String, dynamic>? _replyToMessage;
  io.Socket? _socket;
  String? _currentUserId;
  String? _currentUserRole;
  Set<String> _deletedForMeIds = {};
  String? _chatClearedAt;
  bool _serverMessagesLoaded = false;
  bool _isBlocked = false;
  String? _blockedByName;
  final ImagePicker _picker = ImagePicker();

  // Voice Note state
  final AudioRecorder _audioRecorder = AudioRecorder();
  bool _isRecording = false;
  int _recordDurationSec = 0;
  Timer? _recordTimer;

  // Attachment
  bool _showAttach;
  List<String> _stickers = [];

  _PublicChatPageState() : _showAttach = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<PublicChatUnreadProvider>().markRead();
    });
    _loadUser();
    _loadDeletedForMe();
    _loadChatCache();
    _loadMessages();
    _connectSocket();
    _loadStickers();
    _checkBlocked();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _socket?.disconnect();
    _socket?.dispose();
    _recordTimer?.cancel();
    _audioRecorder.dispose();
    super.dispose();
  }

  void _loadUser() {
    try {
      final auth = context.read<AuthProvider>();
      _currentUserId = auth.user?.id;
      _currentUserRole = auth.user?.role ?? 'member';
    } catch (_) {}
  }

  Future<void> _loadDeletedForMe() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList('deleted_msgs_${_currentUserId ?? 'guest'}') ?? [];
      if (mounted) setState(() => _deletedForMeIds = list.toSet());
    } catch (_) {}
  }

  Future<void> _deleteForMe(String id) async {
    setState(() {
      _deletedForMeIds.add(id);
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('deleted_msgs_${_currentUserId ?? 'guest'}', _deletedForMeIds.toList());
    } catch (_) {}
  }

  /// Pulihkan chat secara lokal supaya tidak "hilang" saat kembali ke layar.
  Future<void> _loadChatCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('chat_cache_${_currentUserId ?? 'guest'}');
      final cleared = prefs.getString('chat_cleared_${_currentUserId ?? 'guest'}');
      if (!mounted) return;
      if (_serverMessagesLoaded) return;
      setState(() {
        _chatClearedAt = (cleared != null && cleared.isNotEmpty) ? cleared : null;
        if (raw != null && raw.isNotEmpty) {
          try {
            final decoded = jsonDecode(raw) as List?;
            if (decoded != null && decoded.isNotEmpty) {
              _messages = decoded.cast<Map<String, dynamic>>();
            }
          } catch (_) {}
        }
      });
    } catch (_) {}
  }

  void _persistMessages() {
    try {
      SharedPreferences.getInstance().then((prefs) {
        prefs.setString('chat_cache_${_currentUserId ?? 'guest'}', jsonEncode(_messages));
      });
    } catch (_) {}
  }

  bool _canDeleteForEveryone(Map<String, dynamic> msg) {
    final authorId = msg['user_id']?.toString();
    if (authorId == _currentUserId) return true;

    final myRole = _currentUserRole ?? 'member';
    final authorUser = msg['user'] as Map<String, dynamic>?;
    final authorRole = authorUser?['role']?.toString() ?? 'member';

    if (myRole == 'developer') return true;

    if (myRole == 'partner' || myRole == 'moderator') {
      return authorRole != 'developer';
    }

    return false;
  }

  Future<void> _loadStickers() async {
    final stickers = await _stickerService.loadStickers();
    if (mounted) setState(() => _stickers = stickers);
  }

  Future<void> _loadMessages() async {
    if (_messages.isEmpty) setState(() => _isLoading = true);
    try {
      final result = await _api.getPublicChatMessages(limit: 60);
      if (result['success'] == true && result['data'] != null) {
        final list = result['data'] as List;
        _serverMessagesLoaded = true;
        setState(() {
          _messages = list.cast<Map<String, dynamic>>();
          _isLoading = false;
        });
        _persistMessages();
        _scrollToBottom();
      }
    } catch (_) {}
    if (mounted) setState(() => _isLoading = false);
  }

  void _connectSocket() {
    try {
      final baseUrl = _api.baseUrl;
      _socket = io.io(baseUrl, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
      });
      _socket!.connect();
      _socket!.on('chat:message', (data) {
        if (!mounted) return;
        if (data is Map) {
          final msg = Map<String, dynamic>.from(data);
          if (msg['user_id']?.toString() == _currentUserId) return;
          setState(() => _messages.add(msg));
          _persistMessages();
          _scrollToBottom();
        }
      });
      _socket!.on('chat:deleted', (data) {
        if (!mounted || data is! Map) return;
        final msgId = data['messageId']?.toString();
        if (msgId != null) {
          setState(() {
            final i = _messages.indexWhere((m) => m['id']?.toString() == msgId);
            if (i >= 0) {
              _markMessageDeleted(_messages[i]);
            }
          });
          _persistMessages();
        }
      });
      _socket!.on('chat:reaction', (data) {
        if (!mounted || data is! Map) return;
        final rUserId = data['userId']?.toString();
        if (data['messageId'] != null && rUserId == _currentUserId) return;
        if (data['messageId'] != null) {
          setState(() {
            _applyReactionToMessages(
              data['messageId']?.toString(),
              data['emoji']?.toString(),
              data['removed'] == true,
              previousEmoji: data['previousEmoji']?.toString(),
            );
          });
        }
      });
      _socket!.on('chat:edited', (data) {
        if (!mounted || data is! Map) return;
        final msgId = data['messageId']?.toString();
        final newText = data['message']?.toString();
        if (msgId == null) return;
        setState(() {
          final i = _messages.indexWhere((m) => m['id']?.toString() == msgId);
          if (i >= 0 && newText != null) {
            _messages[i]['message'] = newText;
            _messages[i]['edited_at'] = data['editedAt']?.toString() ?? DateTime.now().toIso8601String();
          }
        });
      });
      _socket!.on('chat:harddelete', (data) {
        if (!mounted || data is! Map) return;
        final bannedId = data['bannedUserId']?.toString();
        if (bannedId == null) return;
        setState(() {
          _messages.removeWhere((m) => m['user_id']?.toString() == bannedId);
        });
      });
      _socket!.on('chat:banned', (data) {
        if (!mounted || data is! Map) return;
        if (data['bannedUserId']?.toString() == _currentUserId) {
          _checkBlocked();
        }
      });
      _socket!.on('chat:unbanned', (data) {
        if (!mounted || data is! Map) return;
        if (data['bannedUserId']?.toString() == _currentUserId) {
          setState(() {
            _isBlocked = false;
            _blockedByName = null;
          });
        }
      });
    } catch (_) {}
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendText() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    _messageController.clear();
    await _sendMessageApi(text);
  }

  Future<void> _sendMessageApi(String text, {String? replyToId}) async {
    setState(() => _isSending = true);
    try {
      final result = await _api.sendPublicChatMessage(text,
          replyToId: replyToId ?? _replyToId);
      if (_handleBlockedIfNeeded(result)) return;
      if (result['success'] == true && result['data'] != null) {
        final msg = result['data'] as Map<String, dynamic>;
        setState(() {
          final exists = _messages.any((m) => m['id']?.toString() == msg['id']?.toString());
          if (!exists) _messages.add(msg);
          _replyToId = null;
          _replyToMessage = null;
        });
        _persistMessages();
        _scrollToBottom();
      }
    } catch (_) {
      _toast('Gagal mengirim pesan');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  bool _handleBlockedIfNeeded(Map<String, dynamic> result) {
    if (!mounted) return true;
    final err = result['error'];
    if (result['success'] != true && err is Map && err['code'] == 'BLOCKED') {
      final msg = err['message']?.toString() ?? '';
      setState(() {
        _isBlocked = true;
        _blockedByName ??= _extractBlockedName(msg);
      });
      _toast(msg.isEmpty ? 'Anda telah diblokir' : msg);
      return true;
    }
    return false;
  }

  String? _extractBlockedName(String msg) {
    final start = msg.indexOf('oleh ');
    if (start < 0) return null;
    final rest = msg.substring(start + 5);
    final dot = rest.indexOf('.');
    final name = (dot >= 0 ? rest.substring(0, dot) : rest).trim();
    return name.isEmpty ? null : name;
  }

  Future<void> _sendMedia({
    required String messageType,
    XFile? file,
    String? caption,
    String? base64Data,
  }) async {
    if (file == null && base64Data == null) return;
    setState(() => _isSending = true);
    try {
      String? mediaUrl;
      String? mimeType;
      String? fileName;
      int? fileSize;

      if (base64Data != null) {
        // Sticker from local data — upload as image
        final b = base64Decode(base64Data.startsWith('data:image/png;base64,')
            ? base64Data.replaceFirst('data:image/png;base64,', '')
            : base64Data);
        final tmp = File('${Directory.systemTemp.path}/sticker_${DateTime.now().millisecondsSinceEpoch}.png');
        await tmp.writeAsBytes(b);
        final upload = await _api.uploadImage(tmp.path);
        mediaUrl = (upload['data']?['url'] as String?) ?? '';
        mimeType = 'image/png';
        fileName = 'sticker.png';
        fileSize = b.length;
        file = XFile(tmp.path);
      } else {
        final upload = await _api.uploadImage(
          file!.path,
          kind: messageType == 'video' ? 'video' : 'image',
        );
        mediaUrl = (upload['data']?['url'] as String?) ?? '';
        final f = File(file.path);
        fileSize = await f.length();
        fileName = file.name;
        mimeType = _mimeFor(file.name);
      }

      if (mediaUrl.isEmpty) {
        _toast('Gagal mengunggah media');
        return;
      }

      final result = await _api.sendPublicChatMedia(
        messageType: messageType,
        mediaUrl: mediaUrl,
        mimeType: mimeType,
        fileName: fileName,
        fileSize: fileSize,
        caption: caption,
        replyToId: _replyToId,
      );
      if (_handleBlockedIfNeeded(result)) return;
      if (result['success'] == true && result['data'] != null) {
        final msg = result['data'] as Map<String, dynamic>;
        setState(() {
          _messages.add(msg);
          _replyToId = null;
          _replyToMessage = null;
        });
        _persistMessages();
        _scrollToBottom();
      } else {
        _toast('Gagal mengirim media');
      }
    } catch (_) {
      _toast('Gagal mengirim media');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  String _mimeFor(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'webp':
        return 'image/webp';
      case 'mp4':
        return 'video/mp4';
      case 'mov':
        return 'video/quicktime';
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'mp3':
        return 'audio/mpeg';
      default:
        return 'application/octet-stream';
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.inter()),
        backgroundColor: const Color(0xFF2E2E38),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // --- Actions ---
  Future<void> _pickAndSendPhoto() async {
    final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;
    final caption = await _promptCaption('Caption foto');
    if (caption == null) return; // cancelled
    await _sendMedia(messageType: caption.isEmpty ? 'photo' : 'photo', file: file, caption: caption.isEmpty ? null : caption);
  }

  Future<void> _pickAndSendVideo() async {
    final file = await _picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 2));
    if (file == null) return;
    await _sendMedia(messageType: 'video', file: file);
  }

  Future<void> _pickAndSendDocument() async {
    final result = await FilePicker.platform.pickFiles();
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    if (f.path == null) return;
    await _sendMedia(messageType: 'document', file: XFile(f.path!, name: f.name));
  }

  void _toggleAttach() {
    setState(() => _showAttach = !_showAttach);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_showAttach && _scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<String?> _promptCaption(String title) async {
    final ctrl = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF2E2E38),
        title: Text(title, style: GoogleFonts.inter(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: GoogleFonts.inter(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Tulis caption (opsional)',
            hintStyle: TextStyle(color: Colors.white38),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, ''),
            child: Text('Kirim', style: GoogleFonts.inter(color: const Color(0xFF6BB9FF))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, null),
            child: Text('Batal', style: GoogleFonts.inter(color: Colors.white54)),
          ),
        ],
      ),
    );
    return value;
  }

  Future<void> _makeStickerFromPhoto() async {
    final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (file == null) return;
    final bytes = await file.readAsBytes();
    final b64 = StickerService.encodeBytes(bytes);
    await _stickerService.addSticker(b64);
    _toast('Stiker berhasil ditambahkan ke pack');
    await _loadStickers();
    setState(() => _showAttach = false);
    // Auto send sticker to chat
    await _sendMedia(messageType: 'sticker', base64Data: b64);
  }

  void _sendSticker(String stickerData) {
    final isRemote = stickerData.startsWith('http');
    if (isRemote) {
      // Remote sticker URL
      _api.sendPublicChatMedia(
        messageType: 'sticker',
        mediaUrl: stickerData,
        mimeType: 'image/png',
        fileName: 'sticker.png',
        replyToId: _replyToId,
      ).then((res) {
        if (res['success'] == true && res['data'] != null) {
          final msg = res['data'] as Map<String, dynamic>;
          setState(() {
            _messages.add(msg);
            _replyToId = null;
            _replyToMessage = null;
          });
          _scrollToBottom();
        }
      });
    } else {
      _sendMedia(messageType: 'sticker', base64Data: stickerData);
    }
    setState(() => _showAttach = false);
  }

  Future<void> _saveMediaToGallery(String url) async {
    try {
      if (url.startsWith('http')) {
        final uri = Uri.parse(url);
        final res = await http.get(uri);
        if (res.statusCode == 200) {
          await Gal.putImageBytes(res.bodyBytes);
        }
      } else {
        final bytes = base64Decode(url.replaceFirst('data:image/png;base64,', ''));
        await Gal.putImageBytes(bytes);
      }
      _toast('Tersimpan ke galeri');
    } catch (_) {
      _toast('Gagal menyimpan ke galeri');
    }
  }

  Future<void> _makeStickerFromUrl(String url) async {
    try {
      List<int> bytes;
      if (url.startsWith('http')) {
        final res = await http.get(Uri.parse(url));
        bytes = res.bodyBytes;
      } else {
        bytes = base64Decode(url.replaceFirst('data:image/png;base64,', ''));
      }
      final b64 = StickerService.encodeBytes(bytes);
      await _stickerService.addSticker(b64);
      _toast('Ditambahkan ke pack stiker');
      await _loadStickers();
    } catch (_) {
      _toast('Gagal membuat stiker');
    }
  }

  void _setReply(Map<String, dynamic> message) {
    setState(() {
      _replyToId = message['id']?.toString();
      _replyToMessage = message;
    });
    _messageController.selection = TextSelection.fromPosition(
      TextPosition(offset: _messageController.text.length),
    );
  }

  void _cancelReply() {
    setState(() {
      _replyToId = null;
      _replyToMessage = null;
    });
  }

  Future<void> _deleteMessage(String id) async {
    try {
      final result = await _api.deletePublicChatMessage(id);
      if (result['success'] == true) {
        setState(() {
          final i = _messages.indexWhere((m) => m['id']?.toString() == id);
          if (i >= 0) {
            _markMessageDeleted(_messages[i]);
            _messages[i] = Map<String, dynamic>.from(_messages[i]);
            _deletedForMeIds.remove(id);
          }
        });
        _persistMessages();
      } else if (mounted) {
        final message = result['error']?['message']?.toString();
        _toast(message == null || message.isEmpty
            ? 'Gagal menghapus pesan untuk semua orang'
            : message);
      }
    } catch (_) {
      if (mounted) _toast('Gagal menghapus pesan untuk semua orang');
    }
  }

  void _markMessageDeleted(Map<String, dynamic> m) {
    m['message_type'] = 'deleted';
    m['message'] = '';
    m['media_url'] = '';
    m['caption'] = '';
    m['file_name'] = '';
    m['mime_type'] = '';
    m['file_size'] = null;
    m['reactions'] = {};
    m['myReactions'] = [];
  }

  Future<void> _sendReaction(String id, String emoji) async {
    try {
      String? localPrev;
      final i = _messages.indexWhere((m) => m['id']?.toString() == id);
      if (i >= 0) {
        final my = ((_messages[i]['myReactions'] as List?) ?? [])
            .cast<String>()
            .where((e) => e != emoji)
            .toList();
        if (my.isNotEmpty) localPrev = my.first;
      }
      final result = await _api.addPublicChatReaction(id, emoji);
      if (result['success'] == true) {
        final d = result['data'] as Map<String, dynamic>?;
        final removed = d?['removed'] == true;
        final serverPrev = d?['previousEmoji']?.toString();
        setState(() {
          _applyReactionToMessages(
            id,
            emoji,
            removed,
            previousEmoji: serverPrev ?? (removed ? null : localPrev),
          );
        });
      }
    } catch (_) {}
  }

  void _applyReactionToMessages(
    String? messageId,
    String? emoji,
    bool removed, {
    String? previousEmoji,
  }) {
    if (messageId == null || emoji == null) return;
    final i = _messages.indexWhere((m) => m['id']?.toString() == messageId);
    if (i < 0) return;
    final m = _messages[i];
    final reactions = (m['reactions'] as Map?)?.cast<String, int>() ?? {};
    final myReactions = ((m['myReactions'] as List?) ?? []).cast<String>().toList();

    if (removed) {
      final current = reactions[emoji] ?? 0;
      if (current <= 1) {
        reactions.remove(emoji);
      } else {
        reactions[emoji] = current - 1;
      }
      myReactions.remove(emoji);
    } else {
      // Replace reaksi lama (WA): emoji lama dihapus, emoji baru ditambah.
      if (previousEmoji != null &&
          previousEmoji.isNotEmpty &&
          previousEmoji != emoji) {
        final prev = reactions[previousEmoji] ?? 0;
        if (prev <= 1) {
          reactions.remove(previousEmoji);
        } else {
          reactions[previousEmoji] = prev - 1;
        }
        myReactions.remove(previousEmoji);
      }
      reactions[emoji] = (reactions[emoji] ?? 0) + 1;
      if (!myReactions.contains(emoji)) myReactions.add(emoji);
    }

    m['reactions'] = reactions;
    m['myReactions'] = myReactions;
    _messages[i] = Map<String, dynamic>.from(m);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D2B),
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: const Color(0xFFE8D5A3),
        elevation: 0,
        titleSpacing: 8,
        title: Row(
          children: [
            // Ikon transparan tanpa border (premium look)
            const Icon(
              Icons.public,
              color: Color(0x99C9A55A),
              size: 20,
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'NOVACORE CHAT',
                  style: GoogleFonts.cinzel(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFC9A55A),
                    letterSpacing: 2,
                  ),
                ),
                Text(
                  'Public Room',
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    color: Colors.white.withValues(alpha: 0.4),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Color(0x99C9A55A), size: 22),
            color: const Color(0xFF2E2E38),
            onSelected: (v) {
              if (v == 'clear') _clearChat();
              if (v == 'restore') _restoreChat();
              if (v == 'bans' && _isModerator) _showBlockedUsers();
            },
            itemBuilder: (_) => [
              if (_isModerator)
                const PopupMenuItem(
                  value: 'bans',
                  child: Row(
                    children: [
                      Icon(Icons.block, color: Color(0xFFFF7B7B), size: 20),
                      SizedBox(width: 10),
                      Text('Pengguna Diblokir', style: TextStyle(color: Colors.white, fontSize: 14)),
                    ],
                  ),
                ),
              if (_chatClearedAt != null)
                const PopupMenuItem(
                  value: 'restore',
                  child: Row(
                    children: [
                      Icon(Icons.restore, color: Color(0xFF6BB9FF), size: 20),
                      SizedBox(width: 10),
                      Text('Pulihkan Chat', style: TextStyle(color: Colors.white, fontSize: 14)),
                    ],
                  ),
                ),
              const PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    Icon(Icons.delete_sweep_outlined, color: Color(0xFF6BB9FF), size: 20),
                    SizedBox(width: 10),
                    Text('Bersihkan Chat', style: TextStyle(color: Colors.white, fontSize: 14)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background premium publik
          Image.asset(
            'assets/bg/public.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, _, _) => const SizedBox.shrink(),
          ),
          // Overlay gelap biar teks tetap kebaca
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  const Color(0xFF0D0D2B).withValues(alpha: 0.55),
                  const Color(0xFF0D0D2B).withValues(alpha: 0.35),
                  const Color(0xFF0D0D2B).withValues(alpha: 0.65),
                ],
              ),
            ),
          ),
          Column(
            children: [
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(color: Color(0xFFC9A55A)),
                      )
                    : () {
                        final visibleMessages = _messages.where((m) {
                          final cleared = _chatClearedAt;
                          if (cleared != null &&
                              (m['created_at']?.toString() ?? '').isNotEmpty &&
                              (m['created_at']?.toString() ?? '').compareTo(cleared) < 0) {
                            return false;
                          }
                          return !_deletedForMeIds.contains(m['id']?.toString());
                        }).toList();
                        if (visibleMessages.isEmpty) return _buildEmptyState();

                        return ListView.builder(
                          controller: _scrollController,
                          physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
padding: EdgeInsets.only(
                            top: MediaQuery.of(context).padding.top + kToolbarHeight + 14,
                            bottom: 12,
                          ),
                          itemCount: visibleMessages.length,
                          itemBuilder: (context, index) {
                            final msg = visibleMessages[index];
                            final msgId = msg['id'].toString();
                            final isMe = msg['user_id']?.toString() == _currentUserId;
                            final canDeleteEveryone = _canDeleteForEveryone(msg);
                            final canEdit = _canEditMessage(msg);
                            final prev = index > 0 ? visibleMessages[index - 1] : null;
                            final daySep = _buildDaySeparator(prev, msg);

                            return Column(
                              children: [
                                ?daySep,
                                _ChatBubble(
                                  message: msg,
                                  isMe: isMe,
                                  onReply: () => _setReply(msg),
                                  onSave: _saveMediaToGallery,
                                  onMakeSticker: _makeStickerFromUrl,
                                  onDeleteForMe: () => _deleteForMe(msgId),
                                  onDeleteForEveryone: canDeleteEveryone ? () => _deleteMessage(msgId) : null,
                                  onReact: (emoji) => _sendReaction(msgId, emoji),
                                  onEdit: canEdit ? () => _editMessageDialog(msg) : null,
                                  onBan: _canBlockUser(msg) ? () => _banUser(msg) : null,
                                ),
                              ],
                            );
                          },
                    );
                  }(),
          ),
          if (_replyToMessage != null) _buildReplyPreview(),
          if (_showAttach) _buildAttachBar(),
          if (_isBlocked)
            _buildBlockedBanner()
          else
            _buildInputBar(),
        ],
      ),
      ],
    ),
  );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.forum_outlined,
            size: 64,
            color: const Color(0xFFC9A55A).withValues(alpha: 0.2),
          ),
          const SizedBox(height: 16),
          Text(
            'Belum ada pesan',
            style: GoogleFonts.cinzel(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.white.withValues(alpha: 0.3),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Mulai percakapan sekarang!',
            style: GoogleFonts.inter(
              fontSize: 13,
              color: Colors.white.withValues(alpha: 0.2),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReplyPreview() {
    final sender = _replyToMessage!['user']?['name']?.toString() ??
        _replyToMessage!['user']?['username']?.toString() ??
        'User';
    final text = _replyToMessage!['message']?.toString() ?? '';
    final type = _replyToMessage!['message_type']?.toString() ?? 'text';
    final preview = type == 'text' ? text : '📎 ${_typeLabel(type)}';
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFC9A55A).withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border(
          left: BorderSide(color: const Color(0xFFC9A55A).withValues(alpha: 0.4), width: 3),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Membalas $sender',
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFFC9A55A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  preview.length > 60 ? '${preview.substring(0, 60)}...' : preview,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.white.withValues(alpha: 0.5),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _cancelReply,
            child: const Icon(Icons.close, color: Colors.white38, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildAttachBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: Colors.transparent,
        border: Border(
          top: BorderSide(color: Colors.white.withValues(alpha: 0.06)),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Sticker pack row (horizontal)
          if (_stickers.isNotEmpty)
            SizedBox(
              height: 72,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: _stickers.length,
                separatorBuilder: (_, _) => const SizedBox(width: 10),
                itemBuilder: (context, index) {
                  final s = _stickers[index];
                  return GestureDetector(
                    onTap: () => _sendSticker(s),
                    child: Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(10),
                        image: s.startsWith('http')
                            ? DecorationImage(
                                image: NetworkImage(s),
                                fit: BoxFit.contain,
                              )
                            : DecorationImage(
                                image: MemoryImage(base64Decode(
                                  s.replaceFirst('data:image/png;base64,', ''),
                                )),
                                fit: BoxFit.contain,
                              ),
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _AttachItem(
                icon: Icons.photo_outlined,
                label: 'Foto',
                color: const Color(0xFF6BB9FF),
                onTap: _pickAndSendPhoto,
              ),
              _AttachItem(
                icon: Icons.videocam_outlined,
                label: 'Video',
                color: const Color(0xFFC88BFF),
                onTap: _pickAndSendVideo,
              ),
              _AttachItem(
                icon: Icons.description_outlined,
                label: 'Dokumen',
                color: const Color(0xFFFFB35C),
                onTap: _pickAndSendDocument,
              ),
              _AttachItem(
                icon: Icons.mood_outlined,
                label: 'Buat Stiker',
                color: const Color(0xFFFF7BB3),
                onTap: _makeStickerFromPhoto,
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'photo':
        return 'Foto';
      case 'video':
        return 'Video';
      case 'document':
        return 'Dokumen';
      case 'sticker':
        return 'Stiker';
      default:
        return 'Pesan';
    }
  }

  bool _canEditMessage(Map<String, dynamic> msg) {
    if (msg['user_id']?.toString() != _currentUserId) return false;
    if (msg['message_type']?.toString() != 'text') return false;
    if (msg['message_type']?.toString() == 'deleted') return false;
    final created = DateTime.tryParse(msg['created_at']?.toString() ?? '');
    if (created == null) return false;
    return DateTime.now().difference(created).inMinutes < 60;
  }

  static const List<String> _indMonth = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
  ];

  Widget? _buildDaySeparator(Map<String, dynamic>? prev, Map<String, dynamic> msg) {
    final parsedCur = DateTime.tryParse(msg['created_at']?.toString() ?? '');
    final cur = parsedCur?.toLocal();
    if (cur == null) return null;
    final parsedPrev = prev == null
        ? null
        : DateTime.tryParse(prev['created_at']?.toString() ?? '');
    final prevDay = parsedPrev?.toLocal();
    if (prevDay != null &&
        prevDay.year == cur.year &&
        prevDay.month == cur.month &&
        prevDay.day == cur.day) {
      return null;
    }

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(cur.year, cur.month, cur.day);
    String label;
    if (day == today) {
      label = 'Hari Ini';
    } else if (day == today.subtract(const Duration(days: 1))) {
      label = 'Kemarin';
    } else {
      label = '${cur.day} ${_indMonth[cur.month - 1]} ${cur.year}';
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.35),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Colors.white.withValues(alpha: 0.7),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _editMessageDialog(Map<String, dynamic> msg) async {
    final controller = TextEditingController(text: msg['message']?.toString() ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF2E2E38),
        title: Text('Edit Pesan', style: GoogleFonts.inter(color: Colors.white, fontSize: 16)),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 3,
          maxLength: 2000,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Tulis pesan baru...',
            hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.4)),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim()),
            child: const Text('Simpan', style: TextStyle(color: Color(0xFFC9A55A))),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result == null || result.isEmpty) return;

    try {
      final res = await _api.editPublicChatMessage(msg['id'].toString(), result);
      if (res['success'] == true) {
        setState(() {
          final i = _messages.indexWhere((m) => m['id']?.toString() == msg['id']?.toString());
          if (i >= 0) {
            _messages[i]['message'] = result;
            _messages[i]['edited_at'] = DateTime.now().toIso8601String();
            _messages[i] = Map<String, dynamic>.from(_messages[i]);
          }
        });
        _toast('Pesan diperbarui');
      } else {
        _toast('Gagal: ${res['message'] ?? 'tidak diketahui'}');
      }
    } catch (_) {
      _toast('Gagal mengedit pesan');
    }
  }

  Future<void> _clearChat() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF2E2E38),
        title: Text('Bersihkan Chat', style: GoogleFonts.inter(color: Colors.white, fontSize: 16)),
        content: Text(
          'Semua pesan di Public Room akan disembunyikan untuk kamu. '
          'Riwayat tetap tersimpan dan bisa dipulihkan kapan saja.',
          style: GoogleFonts.inter(color: Colors.white.withValues(alpha: 0.7), fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Bersihkan', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      final clearedAt = DateTime.now().toIso8601String();
      await prefs.setString('chat_cleared_${_currentUserId ?? 'guest'}', clearedAt);
      if (!mounted) return;
      setState(() {
        _chatClearedAt = clearedAt;
        _messages = [];
      });
      _persistMessages();
      _toast('Chat dibersihkan untuk kamu');
    } catch (_) {
      _toast('Gagal membersihkan chat');
    }
  }

  Future<void> _restoreChat() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('chat_cleared_${_currentUserId ?? 'guest'}');
      if (!mounted) return;
      setState(() => _chatClearedAt = null);
      await _loadMessages();
      _toast('Riwayat chat dipulihkan');
    } catch (_) {
      _toast('Gagal memulihkan chat');
    }
  }

  Future<void> _checkBlocked() async {
    try {
      final res = await _api.getMyPublicChatBan();
      if (!mounted) return;
      if (res['success'] == true && res['data'] != null) {
        final d = res['data'] as Map<String, dynamic>;
        final blocked = d['blocked'] == true;
        String? name;
        final by = d['banned_by'] as Map<String, dynamic>?;
        if (by != null) {
          name = by['name']?.toString() ?? by['username']?.toString();
        }
        setState(() {
          _isBlocked = blocked;
          _blockedByName = name;
        });
      }
    } catch (_) {}
  }

  bool get _isModerator {
    return _currentUserRole == 'developer' ||
        _currentUserRole == 'partner' ||
        _currentUserRole == 'moderator';
  }

  bool _canBlockUser(Map<String, dynamic> msg) {
    if (!_isModerator) return false;
    final authorId = msg['user_id']?.toString();
    if (authorId == _currentUserId) return false;
    final authorUser = msg['user'] as Map<String, dynamic>?;
    final authorRole = authorUser?['role']?.toString() ?? 'member';
    if (authorRole == 'developer') return false;
    return true;
  }

  String _userDisplayName(Map<String, dynamic>? u) {
    if (u == null) return 'User';
    return u['name']?.toString() ??
        u['username']?.toString() ??
        'User';
  }

  Future<void> _banUser(Map<String, dynamic> msg) async {
    final name = _userDisplayName(msg['user'] as Map<String, dynamic>?);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF2E2E38),
        title: Text('Blokir $name?', style: GoogleFonts.inter(color: Colors.white, fontSize: 16)),
        content: Text(
          'Semua pesan $name di Public Room akan dihapus permanen tanpa jejak, '
          'dan $name tidak bisa chat lagi sampai dibuka blokirnya.',
          style: GoogleFonts.inter(color: Colors.white.withValues(alpha: 0.7), fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Blokir', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final res = await _api.banPublicChatUser(msg['id'].toString());
      if (res['success'] == true) {
        setState(() {
          _messages.removeWhere((m) => m['user_id']?.toString() == msg['user_id']?.toString());
        });
        _toast('$name berhasil diblokir');
      } else {
        _toast('Gagal: ${res['error']?['message'] ?? 'tidak diketahui'}');
      }
    } catch (_) {
      _toast('Gagal memblokir user');
    }
  }

  Future<void> _showBlockedUsers() async {
    final res = await _api.getPublicChatBans();
    if (!mounted) return;
    List<Map<String, dynamic>> bans = [];
    if (res['success'] == true && res['data'] != null) {
      bans = (res['data'] as List).cast<Map<String, dynamic>>();
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.7,
        ),
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
        decoration: BoxDecoration(
          color: const Color(0xFF2E2E38),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Pengguna Diblokir',
              style: GoogleFonts.cinzel(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: const Color(0xFFC9A55A),
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _currentUserRole == 'developer'
                  ? 'Semua blokir (oleh developer, partner, moderator)'
                  : 'Blokir yang dibuat oleh kamu',
              style: GoogleFonts.inter(
                fontSize: 11,
                color: Colors.white.withValues(alpha: 0.5),
              ),
            ),
            const SizedBox(height: 10),
            if (bans.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: Text(
                    'Tidak ada user yang diblokir',
                    style: GoogleFonts.inter(
                      fontSize: 13,
                      color: Colors.white.withValues(alpha: 0.4),
                    ),
                  ),
                ),
              )
            else
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: bans.length,
                  separatorBuilder: (_, _) => const Divider(height: 1, color: Colors.white12),
                  itemBuilder: (_, index) {
                    final b = bans[index];
                    final u = b['user'] as Map<String, dynamic>?;
                    final by = b['banned_by'] as Map<String, dynamic>?;
                    final uname = _userDisplayName(u);
                    final byName = _userDisplayName(by);
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                      dense: true,
                      leading: CircleAvatar(
                        radius: 18,
                        backgroundColor: const Color(0xFFC9A55A).withValues(alpha: 0.15),
                        child: Text(
                          uname.isNotEmpty ? uname.substring(0, 1).toUpperCase() : '?',
                          style: GoogleFonts.cinzel(color: const Color(0xFFC9A55A), fontSize: 13),
                        ),
                      ),
                      title: Text(
                        uname,
                        style: GoogleFonts.inter(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      subtitle: Text(
                        'oleh $byName',
                        style: GoogleFonts.inter(
                          color: Colors.white.withValues(alpha: 0.45),
                          fontSize: 11,
                        ),
                      ),
                      trailing: IconButton(
                        tooltip: 'Buka blokir',
                        icon: const Icon(Icons.lock_open_outlined, color: Color(0xFF6BB9FF)),
                        onPressed: () => _unbanUser(b['banned_user_id']?.toString() ?? ''),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _unbanUser(String userId) async {
    if (userId.isEmpty) return;
    try {
      final res = await _api.unbanPublicChatUser(userId);
      if (mounted) {
        Navigator.of(context).pop();
      }
      if (res['success'] == true) {
        _toast('Blokir dibuka');
        _showBlockedUsers();
      } else {
        _toast('Gagal: ${res['error']?['message'] ?? 'tidak diketahui'}');
      }
    } catch (_) {
      _toast('Gagal membuka blokir');
    }
  }

  Future<void> _openDeveloperContact() async {
    try {
      final url = AppConfig.developerWhatsAppUrl;
      final uri = Uri.parse(url);
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) _toast('Tidak bisa membuka kontak developer');
    } catch (_) {
      _toast('Tidak bisa membuka kontak developer');
    }
  }

  Widget _buildBlockedBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: BoxDecoration(
        color: Colors.red.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.redAccent.withValues(alpha: 0.4)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.block, color: Colors.redAccent, size: 28),
          const SizedBox(height: 8),
          Text(
            _blockedByName == null
                ? 'Anda telah diblokir'
                : 'Anda telah diblokir oleh $_blockedByName',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Hubungi developer untuk membuka blokir.',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: _openDeveloperContact,
            icon: const Icon(Icons.support_agent, size: 18),
            label: const Text('Hubungi Developer'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFC9A55A),
              foregroundColor: NeoColors.ink,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        final dir = await getTemporaryDirectory();
        final filePath = '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a';
        await _audioRecorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: filePath);
        setState(() {
          _isRecording = true;
          _recordDurationSec = 0;
        });
        _recordTimer?.cancel();
        _recordTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
          if (mounted) setState(() => _recordDurationSec++);
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Izin mikrofon diperlukan untuk merekam pesan suara')),
          );
        }
      }
    } catch (e) {
      debugPrint('Start record error: $e');
    }
  }

  Future<void> _stopAndSendRecording() async {
    _recordTimer?.cancel();
    try {
      final path = await _audioRecorder.stop();
      setState(() => _isRecording = false);

      if (path == null || _recordDurationSec < 1) return;

      final file = File(path);
      if (!await file.exists()) return;

      final bytes = await file.readAsBytes();
      final uploadRes = await _api.uploadImage(path);

      if (uploadRes['success'] == true && uploadRes['data']?['url'] != null) {
        final url = uploadRes['data']['url'].toString();
        await _api.sendPublicChatMedia(
          messageType: 'audio',
          mediaUrl: url,
          mimeType: 'audio/m4a',
          fileName: 'Voice_Note.m4a',
          fileSize: bytes.length,
          replyToId: _replyToId,
        ).then((res) {
          if (_handleBlockedIfNeeded(res)) return;
          if (res['success'] == true && res['data'] != null) {
            final msg = res['data'] as Map<String, dynamic>;
            setState(() {
              _messages.add(msg);
              _replyToId = null;
              _replyToMessage = null;
            });
            _scrollToBottom();
          }
        });
      }
    } catch (e) {
      debugPrint('Stop record error: $e');
      if (mounted) setState(() => _isRecording = false);
    }
  }

  Future<void> _cancelRecording() async {
    _recordTimer?.cancel();
    try {
      await _audioRecorder.stop();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _isRecording = false;
        _recordDurationSec = 0;
      });
    }
  }

  Widget _buildInputBar() {
    final hasText = _messageController.text.trim().isNotEmpty;

    return Container(
      padding: EdgeInsets.only(
        left: 8,
        right: 12,
        top: 8,
        bottom: MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.transparent,
        border: Border(
          top: BorderSide(color: Colors.white.withValues(alpha: 0.06)),
        ),
      ),
      child: SafeArea(
        top: false,
        child: _isRecording
            ? Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    onPressed: _cancelRecording,
                  ),
                  const SizedBox(width: 8),
                  Container(
                    width: 10,
                    height: 10,
                    decoration: const BoxDecoration(
                      color: Colors.redAccent,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${(_recordDurationSec ~/ 60).toString().padLeft(2, '0')}:${(_recordDurationSec % 60).toString().padLeft(2, '0')}',
                    style: GoogleFonts.inter(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: _stopAndSendRecording,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: const BoxDecoration(
                        color: Color(0xFF1E8E5A),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.send, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              )
            : Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Plus / attach toggle
                  GestureDetector(
                    onTap: _toggleAttach,
                    child: Container(
                      width: 38,
                      height: 38,
                      margin: const EdgeInsets.only(bottom: 4),
                      decoration: BoxDecoration(
                        color: _showAttach
                            ? const Color(0xFFC9A55A)
                            : Colors.white.withValues(alpha: 0.06),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        _showAttach ? Icons.close : Icons.add,
                        color: _showAttach ? NeoColors.ink : const Color(0xFFC9A55A),
                        size: 24,
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  // Text field
                  Expanded(
                    child: Container(
                      constraints: const BoxConstraints(maxHeight: 110),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.08),
                        ),
                      ),
                      child: TextField(
                        controller: _messageController,
                        maxLines: null,
                        textInputAction: TextInputAction.newline,
                        onChanged: (_) => setState(() {}),
                        style: GoogleFonts.inter(color: Colors.white, fontSize: 15),
                        cursorColor: const Color(0xFFC9A55A),
                        decoration: InputDecoration(
                          hintText: 'Pesan',
                          hintStyle: GoogleFonts.inter(
                            color: Colors.white.withValues(alpha: 0.25),
                            fontSize: 15,
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 9,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  // Send or Mic button
                  GestureDetector(
                    onTap: hasText
                        ? (_isSending ? null : _sendText)
                        : _startRecording,
                    child: Container(
                      width: 38,
                      height: 38,
                      margin: const EdgeInsets.only(bottom: 4),
                      decoration: BoxDecoration(
                        gradient: hasText
                            ? const LinearGradient(
                                colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
                              )
                            : null,
                        color: hasText ? null : const Color(0xFF1E8E5A),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        hasText ? Icons.arrow_upward : Icons.mic,
                        color: hasText ? NeoColors.ink : Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
        ),
    );
  }
}

class _AttachItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;

  const _AttachItem({
    required this.icon,
    required this.label,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 11,
              color: Colors.white.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatBubble extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isMe;
  final VoidCallback? onReply;
  final void Function(String)? onSave;
  final void Function(String)? onMakeSticker;
  final VoidCallback? onDeleteForMe;
  final VoidCallback? onDeleteForEveryone;
  final void Function(String)? onReact;
  final VoidCallback? onEdit;
  final VoidCallback? onBan;

  const _ChatBubble({
    required this.message,
    required this.isMe,
    this.onReply,
    this.onSave,
    this.onMakeSticker,
    this.onDeleteForMe,
    this.onDeleteForEveryone,
    this.onReact,
    this.onEdit,
    this.onBan,
  });

  static const List<String> _quickReactions = [
    '\u{1F44D}', // 👍
    '\u2764\uFE0F', // ❤️
    '\u{1F602}', // 😂
    '\u{1F62E}', // 😮
    '\u{1F62D}', // 😢
    '\u{1F64F}', // 🙏
    '\u{1F525}', // 🔥
    '\u{1F389}', // 🎉
  ];

  String get _type => message['message_type']?.toString() ?? 'text';
  String get _mediaUrl => message['media_url']?.toString() ?? '';
  String get _text => message['message']?.toString() ?? '';
  String get _caption => message['caption']?.toString() ?? '';
  String get _fileName => message['file_name']?.toString() ?? '';
  bool get _isDeleted =>
      _type == 'deleted' || _text == 'Pesan ini telah dihapus';
  bool get _isEdited => message['edited_at']?.toString().isNotEmpty == true;
  Map<String, int> get _reactionsMap =>
      (message['reactions'] as Map?)?.cast<String, int>() ?? {};
  List<String> get _myReactions =>
      ((message['myReactions'] as List?) ?? []).cast<String>().toList();

  @override
  Widget build(BuildContext context) {
    final user = message['user'] as Map<String, dynamic>?;
    final name = user?['name']?.toString() ??
        user?['username']?.toString() ??
        'User';
    final role = user?['role']?.toString() ?? 'member';
    final msgTime = DateTime.tryParse(message['created_at']?.toString() ?? '')?.toLocal() ?? DateTime.now();

    Color roleColor;
    switch (role) {
      case 'developer':
        roleColor = const Color(0xFFFF6B35);
        break;
      case 'partner':
        roleColor = const Color(0xFF9B59B6);
        break;
      case 'moderator':
        roleColor = const Color(0xFF3498DB);
        break;
      case 'reseller':
        roleColor = const Color(0xFF2ECC71);
        break;
      default:
        roleColor = const Color(0xFFC9A55A);
    }

    return GestureDetector(
      onLongPress: _isDeleted ? null : () => _showContextMenu(context),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [
            // Avatar (only for others, like WhatsApp)
            if (!isMe) _avatar(context, name, roleColor),
            const SizedBox(width: 8),
            // Bubble column (name + bubble)
            Flexible(
              child: Column(
                crossAxisAlignment: isMe
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: [
                  if (!isMe)
                    Padding(
                      padding: const EdgeInsets.only(left: 2, bottom: 2),
                      child: _isDeleted ? const SizedBox.shrink() : Text(
                        name,
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: roleColor,
                        ),
                      ),
                    ),
                  // Bubble
                  Container(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.68,
                    ),
                    padding: _type == 'sticker'
                        ? const EdgeInsets.all(4)
                        : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: _isDeleted
                          ? Colors.white.withValues(alpha: 0.06)
                          : isMe
                              ? const Color(0x331E8E5A)
                              : Colors.white.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(_isDeleted ? 16 : (isMe ? 16 : 4)),
                        topRight: Radius.circular(_isDeleted ? 16 : (isMe ? 4 : 16)),
                        bottomLeft: const Radius.circular(16),
                        bottomRight: const Radius.circular(16),
                      ),
                      border: Border.all(
                        color: (isMe
                                ? const Color(0xFF7FE0B0)
                                : Colors.white)
                            .withValues(alpha: isMe ? 0.22 : 0.12),
                      ),
                    ),
                    child: _buildContent(context, msgTime),
                  ),
                  if (!_isDeleted && onReact != null && _reactionsMap.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: _buildReactionChips(),
                    ),
                ],
              ),
            ),
            // Own message read/status ticks (empty space reserved)
            if (!isMe) const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }

  Widget _avatar(BuildContext context, String name, Color roleColor) {
    final avatar = (message['user'] as Map<String, dynamic>?)?['avatar']?.toString();
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: roleColor.withValues(alpha: 0.15),
        border: Border.all(color: roleColor.withValues(alpha: 0.3)),
      ),
      child: avatar != null && avatar.isNotEmpty
          ? ClipOval(
              child: Image.network(
                avatar,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => _avatarInitials(name, roleColor),
              ),
            )
          : _avatarInitials(name, roleColor),
    );
  }

  Widget _avatarInitials(String name, Color roleColor) {
    final initial = name.isNotEmpty ? name.substring(0, 1).toUpperCase() : '?';
    return Center(
      child: Text(
        initial,
        style: GoogleFonts.cinzel(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          color: roleColor,
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, DateTime msgTime) {
    final replyTo = message['reply_to'] as Map<String, dynamic>?;

    // Deleted message placeholder (jejak "Pesan ini telah dihapus" ala WA)
    if (_isDeleted) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Text(
          'Pesan ini telah dihapus',
          style: GoogleFonts.inter(
            fontSize: 13,
            fontStyle: FontStyle.italic,
            color: Colors.white.withValues(alpha: 0.5),
          ),
        ),
      );
    }

    // Audio / Voice Note
    if (_type == 'audio') {
      return Column(
        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          _AudioBubble(
            url: _mediaUrl,
            time: msgTime,
            isMe: isMe,
          ),
          const SizedBox(height: 2),
          _timestamp(msgTime),
        ],
      );
    }

    // Sticker
    if (_type == 'sticker') {
      final isRemote = _mediaUrl.startsWith('http');
      return Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: isRemote
                ? Image.network(
                    _mediaUrl,
                    width: 160,
                    height: 160,
                    fit: BoxFit.contain,
                    errorBuilder: (_, _, _) => const SizedBox(width: 160, height: 160),
                  )
                : Image.memory(
                    base64Decode(_mediaUrl.replaceFirst('data:image/png;base64,', '')),
                    width: 160,
                    height: 160,
                    fit: BoxFit.contain,
                    errorBuilder: (_, _, _) => const SizedBox(width: 160, height: 160),
                  ),
          ),
          Positioned(
            right: 6,
            bottom: 6,
            child: Text(
              '${msgTime.hour}:${msgTime.minute.toString().padLeft(2, '0')}',
              style: GoogleFonts.inter(
                fontSize: 9,
                color: Colors.white.withValues(alpha: 0.6),
              ),
            ),
          ),
        ],
      );
    }

    // Photo
    if (_type == 'photo') {
      final image = _mediaUrl.isNotEmpty
          ? Image.network(
              _mediaUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => const SizedBox(width: 220, height: 160),
            )
          : const Icon(Icons.broken_image, color: Colors.white38, size: 40);
      return Column(
        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: () => _openPhoto(context),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                width: 220,
                height: 160,
                child: image,
              ),
            ),
          ),
          if (_caption.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              _caption,
              style: GoogleFonts.inter(fontSize: 13, color: Colors.white),
            ),
          ],
          _timestamp(msgTime),
        ],
      );
    }

    // Video
    if (_type == 'video') {
      return _VideoBubble(
        url: _mediaUrl,
        fileName: _fileName,
        time: msgTime,
        onOpen: () => _openVideo(context),
      );
    }

    // Document
    if (_type == 'document') {
      return Column(
        crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Container(
            width: 200,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: isMe ? const Color(0xFF1E8E5A) : const Color(0xFF3498DB),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.description, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _fileName.isEmpty ? 'Dokumen' : _fileName,
                    style: GoogleFonts.inter(fontSize: 13, color: Colors.white),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          _timestamp(msgTime),
        ],
      );
    }

    // Text (default)
    return Column(
      crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        if (replyTo != null) ...[
          Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(6),
              border: Border(
                left: BorderSide(color: isMe ? const Color(0xFF1E8E5A) : const Color(0xFF3498DB), width: 2),
              ),
            ),
            child: Text(
              replyTo['message']?.toString() ?? _typeLabel(replyTo['message_type']?.toString()),
              style: GoogleFonts.inter(
                fontSize: 10,
                color: Colors.white.withValues(alpha: 0.4),
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
        Text(
          _text,
          style: GoogleFonts.inter(
            fontSize: 15,
            color: Colors.white,
            height: 1.35,
          ),
        ),
        const SizedBox(height: 2),
        _timestamp(msgTime),
      ],
    );
  }

  String _typeLabel(String? type) {
    switch (type) {
      case 'photo':
        return '[Foto]';
      case 'video':
        return '[Video]';
      case 'document':
        return '[Dokumen]';
      case 'sticker':
        return '[Stiker]';
      case 'deleted':
        return 'Pesan ini telah dihapus';
      default:
        return '';
    }
  }

  Widget _buildReactionChips() {
    return Wrap(
      spacing: 6,
      runSpacing: 4,
      children: [
        ..._reactionsMap.entries.map((e) {
          final mine = _myReactions.contains(e.key);
          return GestureDetector(
            onTap: () => onReact?.call(e.key),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: (mine ? const Color(0xFFC9A55A) : Colors.white)
                    .withValues(alpha: mine ? 0.35 : 0.10),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: mine
                      ? const Color(0xFFC9A55A).withValues(alpha: 0.8)
                      : Colors.white.withValues(alpha: 0.15),
                  width: 1,
                ),
              ),
              child: Text(
                '${e.key} ${e.value}',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.white,
                  fontWeight: mine ? FontWeight.w700 : FontWeight.w400,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  void _showReactionPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
        decoration: BoxDecoration(
          color: const Color(0xFF2E2E38),
          borderRadius: BorderRadius.circular(18),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Reaksi',
                style: GoogleFonts.inter(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white.withValues(alpha: 0.6),
                ),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: _quickReactions.map((e) {
                  final active = _myReactions.contains(e);
                  return GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      onReact?.call(e);
                    },
                    child: Container(
                      width: 42,
                      height: 42,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: active
                            ? const Color(0xFFC9A55A).withValues(alpha: 0.30)
                            : Colors.white.withValues(alpha: 0.06),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: active
                              ? const Color(0xFFC9A55A)
                              : Colors.white.withValues(alpha: 0.12),
                          width: 1,
                        ),
                      ),
                      child: Text(e, style: const TextStyle(fontSize: 22)),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  Widget _timestamp(DateTime msgTime) {
    final t = DateFormat('HH:mm').format(msgTime);
    return Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          t,
          style: GoogleFonts.inter(
            fontSize: 9,
            color: Colors.white.withValues(alpha: 0.4),
          ),
        ),
        if (_isEdited && !_isDeleted) ...[
          const SizedBox(width: 3),
          Text(
            '• diedit',
            style: GoogleFonts.inter(
              fontSize: 9,
              color: Colors.white.withValues(alpha: 0.4),
            ),
          ),
        ],
        if (isMe) ...[
          const SizedBox(width: 4),
          const Icon(
            Icons.done_all,
            size: 13,
            color: Color(0xFF9BE7B8),
          ),
        ],
      ],
    );
  }

  void _openVideo(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _FullVideoPlayer(url: _mediaUrl),
      ),
    );
  }

  void _openPhoto(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _FullPhotoViewer(url: _mediaUrl, onSave: onSave),
      ),
    );
  }

  void _showContextMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF2E2E38),
          borderRadius: BorderRadius.circular(18),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.emoji_emotions_outlined, color: Color(0xFFFFC94D), size: 22),
                title: Text('Reaksi', style: GoogleFonts.inter(color: Colors.white, fontSize: 15)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white24, size: 18),
                onTap: () {
                  Navigator.pop(context);
                  _showReactionPicker(context);
                },
              ),
              const Divider(height: 1, color: Colors.white12),
              if (_type == 'photo' && onSave != null) ...[
                ListTile(
                  leading: const Icon(Icons.download_outlined, color: Color(0xFF6BB9FF), size: 22),
                  title: Text('Simpan ke galeri', style: GoogleFonts.inter(color: Colors.white, fontSize: 15)),
                  onTap: () {
                    Navigator.pop(context);
                    onSave!(_mediaUrl);
                  },
                ),
                const Divider(height: 1, color: Colors.white12),
              ],
              ListTile(
                leading: const Icon(Icons.reply, color: Color(0xFF6BB9FF), size: 22),
                title: Text('Balas', style: GoogleFonts.inter(color: Colors.white, fontSize: 15)),
                onTap: () {
                  Navigator.pop(context);
                  onReply?.call();
                },
              ),
              if (onEdit != null)
                ListTile(
                  leading: const Icon(Icons.edit_outlined, color: Color(0xFF8B9DFF), size: 22),
                  title: Text('Edit', style: GoogleFonts.inter(color: Colors.white, fontSize: 15)),
                  onTap: () {
                    Navigator.pop(context);
                    onEdit!();
                  },
                ),
              const Divider(height: 1, color: Colors.white12),
              if (onBan != null)
                ListTile(
                  leading: const Icon(Icons.block, color: Color(0xFFFF7B7B), size: 22),
                  title: Text('Blokir Pengguna', style: GoogleFonts.inter(color: Color(0xFFFF7B7B), fontSize: 15)),
                  onTap: () {
                    Navigator.pop(context);
                    onBan!();
                  },
                ),
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 22),
                title: Text('Hapus untuk saya', style: GoogleFonts.inter(color: Colors.redAccent, fontSize: 15)),
                onTap: () {
                  Navigator.pop(context);
                  onDeleteForMe?.call();
                },
              ),
              if (onDeleteForEveryone != null)
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.red, size: 22),
                  title: Text('Hapus untuk semua orang', style: GoogleFonts.inter(color: Colors.red, fontSize: 15)),
                  onTap: () {
                    Navigator.pop(context);
                    onDeleteForEveryone?.call();
                  },
                ),
              const Divider(height: 1, color: Colors.white12),
              if (_type == 'photo' && onMakeSticker != null)
                ListTile(
                  leading: const Icon(Icons.star_outline, color: Color(0xFFFFD700), size: 22),
                  title: Text('Jadikan stiker', style: GoogleFonts.inter(color: Colors.white, fontSize: 15)),
                  onTap: () {
                    Navigator.pop(context);
                    onMakeSticker!(_mediaUrl);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AudioBubble extends StatefulWidget {
  final String url;
  final DateTime time;
  final bool isMe;

  const _AudioBubble({
    required this.url,
    required this.time,
    required this.isMe,
  });

  @override
  State<_AudioBubble> createState() => _AudioBubbleState();
}

class _AudioBubbleState extends State<_AudioBubble> {
  final AudioPlayer _player = AudioPlayer();
  bool _isPlaying = false;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _initAudio();
  }

  Future<void> _initAudio() async {
    try {
      await _player.setUrl(widget.url);
      _player.durationStream.listen((d) {
        if (mounted && d != null) setState(() => _duration = d);
      });
      _player.positionStream.listen((p) {
        if (mounted) setState(() => _position = p);
      });
      _player.playerStateStream.listen((state) {
        if (mounted) {
          setState(() {
            _isPlaying = state.playing && state.processingState != ProcessingState.completed;
            if (state.processingState == ProcessingState.completed) {
              _position = Duration.zero;
              _player.seek(Duration.zero);
              _player.pause();
            }
          });
        }
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  void _togglePlay() {
    if (_isPlaying) {
      _player.pause();
    } else {
      _player.play();
    }
  }

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 210,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: _togglePlay,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: widget.isMe ? Colors.white24 : const Color(0xFF1E8E5A),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _isPlaying ? Icons.pause : Icons.play_arrow,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 3,
                    thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                    overlayShape: const RoundSliderOverlayShape(overlayRadius: 8),
                    activeTrackColor: Colors.white,
                    inactiveTrackColor: Colors.white24,
                    thumbColor: Colors.white,
                  ),
                  child: Slider(
                    value: _position.inMilliseconds.toDouble().clamp(0.0, _duration.inMilliseconds.toDouble() > 0 ? _duration.inMilliseconds.toDouble() : 1.0),
                    max: _duration.inMilliseconds.toDouble() > 0 ? _duration.inMilliseconds.toDouble() : 1.0,
                    onChanged: (val) {
                      _player.seek(Duration(milliseconds: val.toInt()));
                    },
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 44, right: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _isPlaying ? _formatDuration(_position) : _formatDuration(_duration),
                  style: GoogleFonts.inter(fontSize: 10, color: Colors.white70),
                ),
                Icon(Icons.mic, size: 12, color: Colors.white.withValues(alpha: 0.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _VideoBubble extends StatefulWidget {
  final String url;
  final String fileName;
  final DateTime time;
  final VoidCallback? onOpen;

  const _VideoBubble({required this.url, required this.fileName, required this.time, this.onOpen});

  @override
  State<_VideoBubble> createState() => _VideoBubbleState();
}

class _VideoBubbleState extends State<_VideoBubble> {
  VideoPlayerController? _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      await _controller!.initialize();
      if (mounted) setState(() => _ready = true);
    } catch (_) {}
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onOpen,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 200,
            height: 150,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.antiAlias,
            child: _ready && _controller != null
                ? Stack(
                    fit: StackFit.expand,
                    children: [
                      FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _controller!.value.size.width,
                          height: _controller!.value.size.height,
                          child: VideoPlayer(_controller!),
                        ),
                      ),
                      const Center(
                        child: Icon(Icons.play_circle_outline, color: Colors.white, size: 48),
                      ),
                    ],
                  )
                : const Center(
                    child: Icon(Icons.play_circle_outline, color: Colors.white54, size: 48),
                  ),
          ),
          const SizedBox(height: 4),
          _vtime(),
        ],
      ),
    );
  }

  Widget _vtime() {
    final t = DateFormat('HH:mm').format(widget.time);
    return Text(
      t,
      style: GoogleFonts.inter(fontSize: 9, color: Colors.white.withValues(alpha: 0.35)),
    );
  }
}

class _FullVideoPlayer extends StatefulWidget {
  final String url;
  const _FullVideoPlayer({required this.url});

  @override
  State<_FullVideoPlayer> createState() => _FullVideoPlayerState();
}

class _FullVideoPlayerState extends State<_FullVideoPlayer> {
  VideoPlayerController? _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      await _controller!.initialize();
      if (mounted) setState(() => _ready = true);
    } catch (_) {}
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Center(
        child: _ready && _controller != null
            ? GestureDetector(
                onTap: () {
                  setState(() {
                    if (_controller!.value.isPlaying) {
                      _controller!.pause();
                    } else {
                      _controller!.play();
                    }
                  });
                },
                child: AspectRatio(
                  aspectRatio: _controller!.value.aspectRatio,
                  child: VideoPlayer(_controller!),
                ),
              )
            : const CircularProgressIndicator(color: Colors.white54),
      ),
    );
  }
}

class _FullPhotoViewer extends StatefulWidget {
  final String url;
  final void Function(String)? onSave;
  const _FullPhotoViewer({required this.url, this.onSave});

  @override
  State<_FullPhotoViewer> createState() => _FullPhotoViewerState();
}

class _FullPhotoViewerState extends State<_FullPhotoViewer> {
  bool _saving = false;

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final uri = Uri.tryParse(widget.url);
    var ok = false;
    try {
      if (uri != null && widget.url.startsWith('http') && (uri.scheme == 'http' || uri.scheme == 'https')) {
        final res = await http.get(uri);
        if (res.statusCode == 200) {
          await Gal.putImageBytes(res.bodyBytes);
          ok = true;
        }
      } else if (widget.url.startsWith('data:image')) {
        await Gal.putImageBytes(base64Decode(widget.url.replaceFirst('data:image/png;base64,', '')));
        ok = true;
      }
    } catch (_) {
      ok = false;
    }
    if (mounted) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(ok ? 'Tersimpan ke galeri' : 'Gagal menyimpan', style: GoogleFonts.inter(fontSize: 13)),
          backgroundColor: const Color(0xFF2E2E38),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          InteractiveViewer(
            minScale: 1.0,
            maxScale: 6.0,
            boundaryMargin: const EdgeInsets.all(80),
            child: Center(
              child: Image.network(
                widget.url,
                fit: BoxFit.contain,
                loadingBuilder: (context, child, progress) =>
                    progress == null ? child : const CircularProgressIndicator(color: Colors.white54),
                errorBuilder: (_, _, _) => const Icon(Icons.broken_image, color: Colors.white38, size: 48),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white, size: 28),
                    onPressed: () => Navigator.pop(context),
                  ),
                  if (widget.onSave != null && widget.url.startsWith('http'))
                    IconButton(
                      icon: _saving
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.download, color: Colors.white, size: 26),
                      onPressed: _save,
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
