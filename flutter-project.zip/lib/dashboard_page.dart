import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:image_picker/image_picker.dart';

import 'api_config.dart';
import 'global_theme.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'ceo_page.dart';
import 'developers_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'spam_pair.dart';
import 'custom_payload.dart';
import 'bug_group_page.dart';
import 'chat_room_page.dart';
import 'music_page.dart';
import 'color_settings_page.dart';
import 'support_page.dart';
import 'story_page.dart';

// ═══════════════════════════════════════════════════════════
// 🎨 COLORS
// ═══════════════════════════════════════════════════════════
const Color kWhite    = Colors.white;
const Color kWhite54  = Colors.white54;
const Color kWhite24  = Colors.white24;
const Color kWhite12  = Colors.white12;
const Color kGreen    = Color(0xFF00E676);
const Color kRed      = Color(0xFFFF1744);
const Color kOrange   = Color(0xFFFF9100);
const Color kPink     = Color(0xFFFF00E5);
const Color kPurple   = Color(0xFF1565C0);
const Color kTeal     = Color(0xFF00B0FF);
const Color kIndigo   = Color(0xFF0D47A1);

const Color kNeonBg       = Color(0xFF020814);
const Color kNeonCard1    = Color(0xF70A193C);
const Color kNeonCard2    = Color(0xFC020818);
const Color kNeonBlue     = Color(0xFF3B82F6);
const Color kNeonCyan     = Color(0xFF06B6D4);
const Color kNeonSky      = Color(0xFF38BDF8);
const Color kNeonLight    = Color(0xFF93C5FD);
const Color kNeonLighter  = Color(0xFFDBEAFE);
const Color kNeonBright   = Color(0xFFE0F2FE);

Color get kBg       => GlobalTheme.bgTop;
Color get kCard     => GlobalTheme.cardBg;
Color get kCardAlt  => GlobalTheme.darken(GlobalTheme.primary, 0.65);
Color get kBorder   => GlobalTheme.primary.withOpacity(0.35);
Color get kCyan     => GlobalTheme.primary;
Color get kBlue     => GlobalTheme.darken(GlobalTheme.primary, 0.25);
Color get kSkyBlue  => GlobalTheme.lighten(GlobalTheme.primary, 0.15);
Color get kNavy     => GlobalTheme.darken(GlobalTheme.primary, 0.55);

const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

const List<String> ROLE_HIERARCHY = [
  'developers', 'ceo', 'owner', 'admin', 'tangan_kanan',
  'vip', 'reseller', 'full_up', 'member_perbulan',
  'member_perminggu', 'member_perhari'
];

const Map<String, int> ROLE_LEVEL = {
  'developers': 10, 'ceo': 9, 'owner': 8, 'admin': 7, 'tangan_kanan': 6,
  'vip': 5, 'reseller': 4, 'full_up': 3, 'member_perbulan': 2,
  'member_perminggu': 2, 'member_perhari': 1
};

const List<String> GLOBAL_SENDER_ROLES = [
  'developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip'
];

bool canAccessGlobalSender(String role) =>
    GLOBAL_SENDER_ROLES.contains(role.toLowerCase());
int getRoleLevel(String role) => ROLE_LEVEL[role.toLowerCase()] ?? 0;

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'DEVELOPERS';
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developers':      return const Color(0xFF00E5FF);
    case 'ceo':             return const Color(0xFF2196F3);
    case 'owner':           return const Color(0xFF1976D2);
    case 'admin':           return const Color(0xFF0D47A1);
    case 'tangan_kanan':    return const Color(0xFF64B5F6);
    case 'vip':             return const Color(0xFF00B0FF);
    case 'reseller':        return const Color(0xFF1565C0);
    case 'full_up':         return const Color(0xFF0288D1);
    case 'member_perbulan': return const Color(0xFF01579B);
    case 'member_perminggu':return const Color(0xFF0277BD);
    case 'member_perhari':  return const Color(0xFF4FC3F7);
    default:                return const Color(0xFF90CAF9);
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ═══════════════════════════════════════════════════════════
// 🕌 PRAYER TIME SERVICE
// ═══════════════════════════════════════════════════════════
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ═══════════════════════════════════════════════════════════
// 🔵 ANIMATED DOT
// ═══════════════════════════════════════════════════════════
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ═══════════════════════════════════════════════════════════
// 🔤 LOGO VOR4X
// ═══════════════════════════════════════════════════════════
class _LampTitle extends StatefulWidget {
  final int trigger;
  const _LampTitle({required this.trigger});
  @override
  State<_LampTitle> createState() => _LampTitleState();
}

class _LampTitleState extends State<_LampTitle>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final letters = [
      {'char': 'V', 'color': kCyan},
      {'char': 'O', 'color': kWhite},
      {'char': 'R', 'color': kCyan},
      {'char': '4', 'color': kSkyBlue},
      {'char': 'X', 'color': kCyan},
    ];
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        final t = _ctrl.value;
        double opacity;
        double glow;

        if (t < 0.15) { opacity = 1.0; glow = 14.0; }
        else if (t < 0.40) { opacity = 0.15; glow = 0.0; }
        else if (t < 0.55) { opacity = 1.0; glow = 14.0; }
        else if (t < 0.80) { opacity = 0.15; glow = 0.0; }
        else { opacity = 1.0; glow = 14.0; }

        return Row(
          mainAxisSize: MainAxisSize.min,
          children: letters.map((l) {
            final Color c = l['color'] as Color;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.5),
              child: Opacity(
                opacity: opacity,
                child: Text(l['char'] as String,
                  style: TextStyle(
                    color: c, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 2,
                    shadows: glow > 0 ? [
                      Shadow(color: c, blurRadius: glow),
                      Shadow(color: c, blurRadius: glow * 2),
                    ] : null,
                  )),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 💿 MINI VINYL
// ═══════════════════════════════════════════════════════════
class MiniVinylPlayer extends StatefulWidget {
  final bool isPlaying;
  const MiniVinylPlayer({super.key, required this.isPlaying});
  @override
  State<MiniVinylPlayer> createState() => _MiniVinylPlayerState();
}

class _MiniVinylPlayerState extends State<MiniVinylPlayer>
    with SingleTickerProviderStateMixin {
  late AnimationController _spinCtrl;
  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4));
    if (widget.isPlaying) _spinCtrl.repeat();
  }
  @override
  void didUpdateWidget(covariant MiniVinylPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isPlaying) { _spinCtrl.repeat(); } else { _spinCtrl.stop(); }
  }
  @override
  void dispose() { _spinCtrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (!widget.isPlaying) return const SizedBox.shrink();
    return Positioned(
      bottom: 180, right: 16,
      child: AnimatedBuilder(
        animation: _spinCtrl,
        builder: (context, _) {
          return Transform.rotate(
            angle: _spinCtrl.value * 2 * math.pi,
            child: Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const SweepGradient(colors: [
                  Color(0xFF030810), Color(0xFF0A1424),
                  Color(0xFF030810), Color(0xFF102040),
                  Color(0xFF0A1424), Color(0xFF030810),
                ]),
                border: Border.all(color: kNeonSky.withOpacity(0.85), width: 1.5),
                boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.7), blurRadius: 22)],
              ),
              child: Center(child: Container(
                width: 18, height: 18,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: kNeonSky, width: 1)),
                child: Icon(Icons.music_note, color: kNeonSky, size: 10),
              )),
            ),
          );
        },
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;
  bool _wsConnected = false;

  bool _isMusicPlaying = false;
  final AudioPlayer _audioPlayer = AudioPlayer();

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  Timer? _statsTimer;
  Timer? _clockTick;

  bool _locationLoading = false;
  String _prayerCity = 'Surabaya';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime = '';
  bool _prayerLoading = true;

  VideoPlayerController? _videoController;
  bool _videoInitialized = false;

  // ── Scroll controller untuk carousel card modules ──
  final ScrollController _moduleScrollCtrl = ScrollController();
  int _activeModuleIndex = 0;
  static const double _moduleCardGap = 14;

  String get roleDisplay => getRoleDisplay(role);
  Color get roleColor => getRoleColor(role);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _initAndroidId();
    _loadProfileImage();
    _detectLocationAndFetchPrayer();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());

    _clockTick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });

    _moduleScrollCtrl.addListener(_onModuleScroll);
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _clockTick?.cancel();
    _videoController?.dispose();
    _audioPlayer.dispose();
    try { channel.sink.close(status.goingAway); } catch (_) {}
    _fadeCtrl.dispose();
    _moduleScrollCtrl.removeListener(_onModuleScroll);
    _moduleScrollCtrl.dispose();
    super.dispose();
  }

  void _onModuleScroll() {
    if (!_moduleScrollCtrl.hasClients) return;
    final viewportWidth = MediaQuery.of(context).size.width;
    final cardWidth = viewportWidth * 0.80;
    final totalItem = cardWidth + _moduleCardGap;
    final center = _moduleScrollCtrl.offset + viewportWidth / 2;
    final idx = ((center - cardWidth / 2) / totalItem).round();
    final clamped = idx.clamp(0, 2);
    if (clamped != _activeModuleIndex && mounted) {
      setState(() => _activeModuleIndex = clamped);
    }
  }

  // ═══ NAV HANDLERS ═══
  void _onNavTap(int index) {
    if (_navIndex == index) return;
    setState(() => _navIndex = index);
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      case 4: page = CEOPage(sessionKey: sessionKey, username: username); break;
      case 5: page = DevelopersPage(sessionKey: sessionKey, username: username); break;
      case 6: page = const SupportPage(); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) setState(() => _navIndex = 0);
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 0: return _buildHomePage();
      case 1: return _buildChatMenuPage();
      case 2: return BugGroupPage(sessionKey: sessionKey, role: role);
      case 3: return InfoPage(sessionKey: sessionKey);
      case 4: return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      default: return _buildHomePage();
    }
  }

  void _navigate(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // ═══ LOADERS ═══
  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
    } catch (e) {
      debugPrint('[AndroidId] $e');
    } finally {
      _connectWS();
    }
  }

  void _connectWS() {
    try {
      _statsTimer?.cancel();
      channel = WebSocketChannel.connect(Uri.parse('ws://pallmarketplace.ptdlpanel.my.id:11660'));
      channel.sink.add(jsonEncode({'type': 'validate', 'key': sessionKey, 'androidId': androidId}));
      channel.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
          channel.sink.add(jsonEncode({'type': 'stats'}));
          setState(() => _wsConnected = true);
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
            _wsConnected = true;
          });
        }
      }, onError: (_) {
        if (mounted) setState(() => _wsConnected = false);
        Future.delayed(const Duration(seconds: 3), () { if (mounted) _connectWS(); });
      }, onDone: () {
        if (mounted) setState(() => _wsConnected = false);
        Future.delayed(const Duration(seconds: 3), () { if (mounted) _connectWS(); });
      });
      _statsTimer = Timer.periodic(const Duration(seconds: 3), (_) {
        try { channel.sink.add(jsonEncode({'type': 'stats'})); } catch (_) {}
      });
    } catch (e) {
      Future.delayed(const Duration(seconds: 3), () { if (mounted) _connectWS(); });
    }
  }

  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/videos/banner.mp4');
      await controller.initialize();
      controller.setLooping(true);
      controller.setVolume(1.0);
      await controller.play();
      if (mounted) {
        setState(() { _videoController = controller; _videoInitialized = true; });
      }
    } catch (e) { debugPrint('Video: $e'); }
  }

  Future<void> _openUrl(String url) async {
    try { await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication); } catch (_) {}
  }

  String _pad(int n) => n < 10 ? '0$n' : '$n';

  // ═══ PRAYER ═══
  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh': timings['Fajr'] ?? '--:--',
        'Dzuhur': timings['Dhuhr'] ?? '--:--',
        'Ashar': timings['Asr'] ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya': timings['Isha'] ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key; nextTime = entry.value; break;
          }
        }
      }
      setState(() { _prayerTimes = times; _nextPrayerLabel = nextLabel; _nextPrayerTime = nextTime; _prayerLoading = false; });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) { setState(() { _locationLoading = false; _prayerCity = 'Surabaya'; }); await _fetchPrayerTimes(); }
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) { setState(() { _locationLoading = false; _prayerCity = 'Surabaya'; }); await _fetchPrayerTimes(); }
          return;
        }
      }
      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      final placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';
        setState(() { _prayerCity = city; _locationLoading = false; });
        await _fetchPrayerTimes();
      }
    } catch (e) {
      if (mounted) { setState(() { _locationLoading = false; _prayerCity = 'Surabaya'; }); await _fetchPrayerTimes(); }
    }
  }

  // ═══ PROFILE PICKER ═══
  Future<void> _pickProfileImage() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF0B1120),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: kNeonBlue.withOpacity(0.3)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: kWhite24, borderRadius: BorderRadius.circular(2))),
          Text('Foto Profil', style: TextStyle(color: kWhite, fontSize: 16, fontWeight: FontWeight.bold, shadows: _ts)),
          const SizedBox(height: 16),
          ListTile(
            leading: Icon(Icons.photo_library_rounded, color: kNeonSky, size: 24),
            title: Text('Pilih dari Galeri', style: TextStyle(color: kWhite, fontWeight: FontWeight.w600)),
            onTap: () { Navigator.pop(context); _pickImage(ImageSource.gallery); },
          ),
          ListTile(
            leading: Icon(Icons.camera_alt_rounded, color: kNeonSky, size: 24),
            title: Text('Ambil dari Kamera', style: TextStyle(color: kWhite, fontWeight: FontWeight.w600)),
            onTap: () { Navigator.pop(context); _pickImage(ImageSource.camera); },
          ),
          if (_profileImage != null)
            ListTile(
              leading: Icon(Icons.delete_outline_rounded, color: kRed, size: 24),
              title: Text('Hapus Foto', style: TextStyle(color: kRed, fontWeight: FontWeight.w600)),
              onTap: () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.remove('profile_image_$username');
                if (mounted) setState(() => _profileImage = null);
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(source: source, imageQuality: 85, maxWidth: 1080, maxHeight: 1080);
      if (picked == null) return;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_$username', picked.path);
      if (mounted) setState(() => _profileImage = File(picked.path));
    } catch (e) { debugPrint('[Image] $e'); }
  }

  // ═══ HOME PAGE ═══
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 180),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildVideoBanner(),
            const SizedBox(height: 8),
            _buildDigitalClockCard(),
            const SizedBox(height: 12),
            _buildBlueNeonCard(),
            const SizedBox(height: 14),
            _buildStatCards(),
            const SizedBox(height: 14),
            _buildQuickActionsSection(),
            const SizedBox(height: 14),
            _buildPrayerSection(),
            const SizedBox(height: 14),
            _buildCredits(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🎬 VIDEO BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Container(
          height: 200, width: double.infinity,
          decoration: BoxDecoration(
            border: Border.all(color: kNeonBlue.withOpacity(0.5), width: 1.5),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(color: kNeonBlue.withOpacity(0.30), blurRadius: 30, offset: const Offset(0, 10)),
              BoxShadow(color: kNeonSky.withOpacity(0.15), blurRadius: 40),
            ],
          ),
          child: Stack(children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF04070D), Color(0xFF0A1424), Color(0xFF0D47A1)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [Colors.white, Color(0xFF00B0FF), Color(0xFF1565C0)]).createShader(b),
                  child: const Text('Power', style: TextStyle(
                    fontSize: 68, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 4)),
                ),
              ),
            ),
            if (_videoInitialized && _videoController != null)
              Positioned.fill(child: FittedBox(fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!)))),
            Positioned.fill(child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [kNeonBlue.withOpacity(0.15), Colors.transparent, Colors.black.withOpacity(0.85)],
                  stops: const [0, 0.4, 1.0],
                ),
              ),
            )),
            Positioned(top: 12, left: 12, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kNeonSky.withOpacity(0.85))),
              child: Row(children: [
                _AnimatedDot(color: kNeonSky, size: 5),
                const SizedBox(width: 5),
                Text('CINEMATIC', style: TextStyle(color: kNeonSky, fontSize: 8.5,
                  fontWeight: FontWeight.w800, letterSpacing: 0.8, shadows: _ts)),
              ]),
            )),
            Positioned(top: 12, right: 12, child: GestureDetector(
              onTap: () {
                if (_videoController != null) {
                  final isMuted = _videoController!.value.volume == 0.0;
                  _videoController!.setVolume(isMuted ? 1.0 : 0.0).then((_) {
                    if (mounted) setState(() {});
                  });
                }
              },
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  shape: BoxShape.circle,
                  border: Border.all(color: kNeonSky.withOpacity(0.85)),
                ),
                child: Icon(
                  (_videoController?.value.volume ?? 1.0) > 0.0
                      ? Icons.volume_up_rounded
                      : Icons.volume_off_rounded,
                  color: kNeonSky, size: 14,
                ),
              ),
            )),
            Positioned(bottom: 18, left: 22, child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('VOR4X', style: TextStyle(color: kWhite,
                  fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2, shadows: _ts)),
                const SizedBox(height: 4),
                Text('© 2026 · All Rights Reserved', style: TextStyle(color: kWhite54, fontSize: 11, shadows: _ts)),
              ],
            )),
          ]),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ⏱️ DIGITAL CLOCK CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildDigitalClockCard() {
    final now = DateTime.now();
    final h = _pad(now.hour);
    final m = _pad(now.minute);
    final s = _pad(now.second);

    const hari = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
    const bulan = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
                   'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    final dayName = hari[now.weekday % 7];
    final dayNum = _pad(now.day);
    final monthName = bulan[now.month - 1];
    final year = now.year;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xD90A1932),
              Color(0xBF0D2A5C),
              Color(0xE60A1932),
            ],
          ),
          border: Border.all(color: kNeonSky.withOpacity(0.60), width: 1.3),
          boxShadow: [
            BoxShadow(color: kNeonBlue.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6)),
            BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 18, offset: const Offset(0, 6)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.access_time_rounded, color: kNeonSky, size: 13, shadows: _ts),
                  const SizedBox(width: 8),
                  Text('DIGITAL CLOCK', style: TextStyle(
                    color: kNeonSky, fontSize: 12, fontWeight: FontWeight.w800,
                    letterSpacing: 2.5,
                    shadows: [
                      Shadow(color: kNeonSky.withOpacity(0.8), blurRadius: 10),
                      const Shadow(color: Colors.black, blurRadius: 4, offset: Offset(0, 2)),
                    ],
                  )),
                ]),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xE6020814), Color(0xF20A1424)],
                    ),
                    border: Border.all(color: kNeonSky.withOpacity(0.45), width: 1.2),
                  ),
                  child: Center(
                    child: Text(
                      '$h:$m:$s',
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3,
                        color: kWhite,
                        shadows: [
                          const Shadow(color: Colors.white, blurRadius: 8),
                          Shadow(color: kNeonSky, blurRadius: 18),
                          Shadow(color: kNeonBlue, blurRadius: 36),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text(
                    '$dayName · $dayNum $monthName $year',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      color: kNeonLight,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2.5,
                      shadows: [
                        Shadow(color: kNeonLight.withOpacity(0.7), blurRadius: 10),
                        const Shadow(color: Colors.black, blurRadius: 4, offset: Offset(0, 2)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 24,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: List.generate(32, (i) {
                      final barHeight = 6.0 + ((math.sin(i * 0.8 + now.second * 0.5) + 1) * 7);
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 1.5),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.easeInOut,
                          width: 3,
                          height: barHeight,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(3),
                            gradient: const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [kNeonLighter, kNeonSky, kNeonBlue],
                            ),
                            boxShadow: [
                              BoxShadow(color: kNeonSky.withOpacity(0.7), blurRadius: 8),
                              BoxShadow(color: kNeonBlue.withOpacity(0.5), blurRadius: 14),
                            ],
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 💙 BLUE NEON CARD
  // ═══════════════════════════════════════════════════════════
  Widget _buildBlueNeonCard() {
    final now = DateTime.now();
    final hour = now.hour;
    String greeting; IconData greetIcon;
    if (hour >= 4 && hour < 11) { greeting = 'Selamat Pagi'; greetIcon = Icons.wb_sunny; }
    else if (hour >= 11 && hour < 15) { greeting = 'Selamat Siang'; greetIcon = Icons.wb_cloudy; }
    else if (hour >= 15 && hour < 18) { greeting = 'Selamat Sore'; greetIcon = Icons.cloud; }
    else { greeting = 'Selamat Malam'; greetIcon = Icons.nightlight_round; }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(36),
          border: Border.all(color: kNeonSky.withOpacity(0.55), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: kNeonBlue.withOpacity(0.45),
              blurRadius: 40, spreadRadius: -5, offset: const Offset(0, 15),
            ),
            BoxShadow(color: kNeonSky.withOpacity(0.25), blurRadius: 60, spreadRadius: -10),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(34.5),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/card_dashboard.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                        colors: [kNeonCard1, kNeonCard2],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.45),
                        Colors.black.withOpacity(0.15),
                        Colors.black.withOpacity(0.55),
                      ],
                      stops: const [0.0, 0.45, 1.0],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _OrbitingAvatar(
                          imageFile: _profileImage,
                          username: username,
                          onTap: _pickProfileImage,
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                Text(greeting, style: TextStyle(
                                  fontSize: 12.5, fontWeight: FontWeight.w500,
                                  color: Colors.white, letterSpacing: 0.5,
                                  shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 6)],
                                )),
                                const SizedBox(width: 6),
                                Icon(greetIcon, color: const Color(0xFFFBBF24), size: 14),
                              ]),
                              const SizedBox(height: 4),
                              ShaderMask(
                                shaderCallback: (bounds) => const LinearGradient(
                                  colors: [Colors.white, kNeonLight, kNeonSky, Colors.white],
                                ).createShader(bounds),
                                child: Text(username, style: const TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.w900,
                                  color: Colors.white, letterSpacing: -0.5, height: 1,
                                )),
                              ),
                              const SizedBox(height: 8),
                              Row(children: [
                                _buildNeonChip(roleDisplay),
                                const SizedBox(width: 6),
                                _buildNeonChip('VOR4X', cyan: true),
                              ]),
                            ],
                          ),
                        ),
                        _buildMiniNeonClock(),
                      ],
                    ),
                    const SizedBox(height: 20),
                    _buildNeonAddSender(),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: _buildMiniNeonWeather()),
                      const SizedBox(width: 12),
                      Expanded(child: _buildMiniNeonExpired()),
                    ]),
                    const SizedBox(height: 14),
                    Row(children: [
                      Expanded(child: _buildNeonContact(
                        label: 'Contact Dev',
                        icon: FontAwesomeIcons.whatsapp,
                        isWA: true,
                        url: 'https://wa.me/6283181413194',
                      )),
                      const SizedBox(width: 12),
                      Expanded(child: _buildNeonContact(
                        label: 'Contact Dev',
                        icon: FontAwesomeIcons.telegram,
                        isWA: false,
                        url: 'https://t.me/r4pzzxi',
                      )),
                    ]),
                    const SizedBox(height: 18),
                    Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.bolt, color: kNeonSky, size: 9),
                          const SizedBox(width: 6),
                          Text('Powered by ', style: TextStyle(
                            fontSize: 10, color: Colors.white.withOpacity(0.7),
                            letterSpacing: 0.8,
                            shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 6)],
                          )),
                          Text('@VOR4X', style: TextStyle(
                            fontSize: 10, color: kNeonLight,
                            fontWeight: FontWeight.w700, letterSpacing: 0.8,
                            shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 6)],
                          )),
                          Text(' · ', style: TextStyle(
                            fontSize: 10, color: Colors.white.withOpacity(0.7),
                            shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 6)],
                          )),
                          Text('@ZiLXPEDIA', style: TextStyle(
                            fontSize: 10, color: kNeonSky,
                            fontWeight: FontWeight.w700, letterSpacing: 0.8,
                            shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 6)],
                          )),
                          const SizedBox(width: 6),
                          const Icon(Icons.bolt, color: kNeonSky, size: 9),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeonChip(String text, {bool cyan = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: cyan ? kNeonSky.withOpacity(0.30) : kNeonBlue.withOpacity(0.30),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: cyan ? kNeonSky.withOpacity(0.70) : kNeonBlue.withOpacity(0.60), width: 1),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 4)],
      ),
      child: Text(text, style: TextStyle(
        fontSize: 9, fontWeight: FontWeight.w700, letterSpacing: 1.5,
        color: Colors.white,
        shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 4)],
      )),
    );
  }

  Widget _buildMiniNeonClock() {
    final now = DateTime.now();
    final h = now.hour, m = now.minute, s = now.second;
    return Column(children: [
      Container(
        width: 54, height: 54,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const RadialGradient(
            center: Alignment(-0.4, -0.4),
            colors: [Color(0xFF0A1F4A), Color(0xFF030A1C)],
          ),
          border: Border.all(color: kNeonBlue.withOpacity(0.65), width: 1.5),
          boxShadow: [
            BoxShadow(color: kNeonBlue.withOpacity(0.5), blurRadius: 15, spreadRadius: 1),
            BoxShadow(color: kNeonBlue.withOpacity(0.45), blurRadius: 22),
          ],
        ),
        child: Stack(alignment: Alignment.center, children: [
          Transform.rotate(
            angle: ((h % 12) * 30 + m * 0.5) * math.pi / 180,
            child: Container(width: 3, height: 13,
              margin: const EdgeInsets.only(bottom: 13),
              decoration: BoxDecoration(color: kWhite, borderRadius: BorderRadius.circular(5),
                boxShadow: [BoxShadow(color: kWhite, blurRadius: 7)])),
          ),
          Transform.rotate(
            angle: m * 6 * math.pi / 180,
            child: Container(width: 2, height: 19,
              margin: const EdgeInsets.only(bottom: 19),
              decoration: BoxDecoration(color: kNeonSky, borderRadius: BorderRadius.circular(5),
                boxShadow: [BoxShadow(color: kNeonSky, blurRadius: 8)])),
          ),
          Transform.rotate(
            angle: s * 6 * math.pi / 180,
            child: Container(width: 1, height: 21,
              margin: const EdgeInsets.only(bottom: 21),
              decoration: BoxDecoration(color: kNeonBlue, borderRadius: BorderRadius.circular(5),
                boxShadow: [BoxShadow(color: kNeonBlue, blurRadius: 5)])),
          ),
          Container(width: 5, height: 5,
            decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite,
              boxShadow: [BoxShadow(color: kWhite, blurRadius: 10), BoxShadow(color: kNeonSky, blurRadius: 15)])),
        ]),
      ),
      const SizedBox(height: 6),
      Text('${_pad(h)}:${_pad(m)}:${_pad(s)}', style: TextStyle(
        fontSize: 10, fontWeight: FontWeight.w700, color: kNeonLight,
        letterSpacing: 1,
        shadows: [Shadow(color: Colors.black.withOpacity(0.8), blurRadius: 4)],
      )),
    ]);
  }

  Widget _buildNeonAddSender() {
    return GestureDetector(
      onTap: () => _navigate(BugSenderPage(
        sessionKey: sessionKey, username: username, role: role)),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [kNeonBlue.withOpacity(0.85), kNeonSky.withOpacity(0.70)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kNeonLight.withOpacity(0.8), width: 1.5),
          boxShadow: [
            BoxShadow(color: kNeonBlue.withOpacity(0.55), blurRadius: 25),
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 5)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(children: [
              const Icon(Icons.add_circle, color: Colors.white, size: 20),
              const SizedBox(width: 12),
              const Text('ADD SENDER', style: TextStyle(
                color: Colors.white, fontSize: 14.5,
                fontWeight: FontWeight.w700, letterSpacing: 1.5,
                shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
              )),
            ]),
            const Icon(Icons.arrow_forward, color: Colors.white, size: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniNeonWeather() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kNeonBlue.withOpacity(0.55), width: 1.3),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8)],
      ),
      child: Stack(children: [
        Positioned(left: 0, top: 0, bottom: 0,
          child: Container(width: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kNeonBlue, kNeonSky],
                begin: Alignment.topCenter, end: Alignment.bottomCenter),
              boxShadow: [BoxShadow(color: kNeonSky, blurRadius: 10)],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('CUACA', style: TextStyle(
              fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w700,
              color: kNeonLight, shadows: [Shadow(color: Colors.black, blurRadius: 4)],
            )),
            const SizedBox(height: 7),
            Row(children: [
              const Icon(Icons.cloud, color: Colors.white, size: 14),
              const SizedBox(width: 5),
              Text('28°C', style: TextStyle(
                fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white,
                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
              )),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _buildMiniNeonExpired() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kNeonBlue.withOpacity(0.55), width: 1.3),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8)],
      ),
      child: Stack(children: [
        Positioned(left: 0, top: 0, bottom: 0,
          child: Container(width: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kNeonBlue, kNeonSky],
                begin: Alignment.topCenter, end: Alignment.bottomCenter),
              boxShadow: [BoxShadow(color: kNeonSky, blurRadius: 10)],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('EXPIRED', style: TextStyle(
              fontSize: 9, letterSpacing: 2, fontWeight: FontWeight.w700,
              color: kNeonLight, shadows: [Shadow(color: Colors.black, blurRadius: 4)],
            )),
            const SizedBox(height: 7),
            Row(children: [
              const Icon(Icons.hourglass_bottom, color: Color(0xFF60A5FA), size: 13),
              const SizedBox(width: 5),
              Expanded(child: Text(
                expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                  color: Colors.white,
                  shadows: [Shadow(color: Colors.black, blurRadius: 4)]),
                maxLines: 1, overflow: TextOverflow.ellipsis,
              )),
            ]),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: SizedBox(height: 4,
                child: LinearProgressIndicator(
                  value: 0.78,
                  backgroundColor: kWhite.withOpacity(0.15),
                  valueColor: AlwaysStoppedAnimation(kNeonSky),
                )),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildNeonContact({
    required String label, required IconData icon,
    required bool isWA, required String url,
  }) {
    final accent = isWA ? kNeonBlue : kNeonSky;
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        decoration: BoxDecoration(
          color: isWA ? kNeonBlue.withOpacity(0.55) : kNeonSky.withOpacity(0.45),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: accent.withOpacity(0.85), width: 1.5),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(0.4), blurRadius: 20),
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: TextStyle(
            fontSize: 13, fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: 0.3,
            shadows: [Shadow(color: Colors.black, blurRadius: 6)],
          ), maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
      ),
    );
  }

  // ═══ STAT CARDS ═══
  Widget _buildStatCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(children: [
        Expanded(child: _buildSolidStatCard(
          icon: Icons.cell_tower_rounded,
          value: _wsConnected ? '$activeConns' : '0',
          label: 'ONLINE SENDER',
          iconColor: const Color(0xFFE0F2FE),
          isOnline: _wsConnected && activeConns > 0,
        )),
        const SizedBox(width: 12),
        Expanded(child: _buildSolidStatCard(
          icon: Icons.people_alt_rounded,
          value: _wsConnected ? '$onlineUsers' : '0',
          label: 'ONLINE USERS',
          iconColor: const Color(0xFFF59E0B),
          isOnline: _wsConnected && onlineUsers > 0,
        )),
      ]),
    );
  }

  Widget _buildSolidStatCard({
    required IconData icon,
    required String value,
    required String label,
    required Color iconColor,
    required bool isOnline,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xF21565C0),
            Color(0xF70D47A1),
            Color(0xFA0A1932),
          ],
          stops: [0.0, 0.5, 1.0],
        ),
        border: Border.all(color: kNeonSky.withOpacity(0.65), width: 1.4),
        boxShadow: [
          BoxShadow(color: kNeonBlue.withOpacity(0.45), blurRadius: 20, spreadRadius: -2, offset: const Offset(0, 8)),
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: iconColor,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: iconColor.withOpacity(0.7), blurRadius: 16, spreadRadius: 1)],
            ),
            child: Icon(icon, color: iconColor.computeLuminance() > 0.5 ? const Color(0xFF0D47A1) : Colors.white, size: 24),
          ),
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isOnline ? kGreen : kRed,
              boxShadow: [
                BoxShadow(color: (isOnline ? kGreen : kRed).withOpacity(0.95), blurRadius: 10, spreadRadius: 1),
              ],
            ),
          ),
        ]),
        const SizedBox(height: 22),
        Text(value, style: TextStyle(
          color: kWhite, fontSize: 38, fontWeight: FontWeight.w900, height: 1,
          shadows: [
            Shadow(color: kNeonSky.withOpacity(0.7), blurRadius: 12),
            const Shadow(color: Colors.black, blurRadius: 6, offset: Offset(0, 2)),
          ],
        )),
        const SizedBox(height: 6),
        Text(label, style: TextStyle(
          color: kWhite.withOpacity(0.92), fontSize: 11,
          fontWeight: FontWeight.w700, letterSpacing: 1.4,
          shadows: _ts,
        )),
      ]),
    );
  }

  // ═══ QUICK ACTIONS ═══
  Widget _buildQuickActionsSection() {
    final actions = [
      {'title': 'Bug Sender', 'subtitle': 'Management Sender',
       'icon': FontAwesomeIcons.whatsapp,
       'gradient': [const Color(0xFF1565C0), const Color(0xFF0D47A1)],
       'onTap': () => _navigate(BugSenderPage(
           sessionKey: sessionKey, username: username, role: role))},
      {'title': 'Join Channel', 'subtitle': 'Info Channel',
       'icon': FontAwesomeIcons.telegram,
       'gradient': [const Color(0xFF0288D1), const Color(0xFF01579B)],
       'onTap': () => _openUrl('https://t.me/r4pzzxi')},
      {'title': 'Chat Room', 'subtitle': 'Obrolan Global',
       'icon': Icons.chat_rounded,
       'gradient': [const Color(0xFF00BCD4), const Color(0xFF00838F)],
       'onTap': () => _navigate(ChatRoomPage(username: username))},
      {'title': 'Al Quran', 'subtitle': 'Baca Al-Quran',
       'icon': FontAwesomeIcons.bookQuran,
       'gradient': [const Color(0xFF3D5AFE), const Color(0xFF1A237E)],
       'onTap': () => _navigate(AlQuranPage())},
      {'title': 'Support', 'subtitle': 'Tim & Supporter',
       'icon': Icons.support_agent_rounded,
       'gradient': [const Color(0xFF00E5FF), const Color(0xFF0088CC)],
       'onTap': () => _navigate(const SupportPage())},
      {'title': 'Profile', 'subtitle': 'Akun Saya',
       'icon': Icons.person_rounded,
       'gradient': [const Color(0xFF00B0FF), const Color(0xFF0288D1)],
       'onTap': () => _navigate(ProfilePage(
           username: username, password: password, role: role,
           expiredDate: expiredDate, sessionKey: sessionKey))},
      {'title': 'Settings', 'subtitle': 'Pengaturan',
       'icon': Icons.settings_rounded,
       'gradient': [const Color(0xFF1565C0), const Color(0xFF0D47A1)],
       'onTap': () => _navigate(ColorSettingsPage())},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(children: [
            Container(
              width: 54, height: 54, padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: kNeonSky.withOpacity(0.15),
                border: Border.all(color: kNeonSky.withOpacity(0.4)),
                boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.20), blurRadius: 18)],
              ),
              child: Icon(Icons.bolt_rounded, color: kNeonSky, size: 24, shadows: _ts),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('QUICK ACCESS', style: TextStyle(color: kWhite,
                  fontWeight: FontWeight.bold, fontSize: 19, letterSpacing: 1.8, shadows: _ts)),
                Text('Geser untuk lihat menu lainnya →',
                  style: TextStyle(color: kWhite54, fontSize: 12.5, shadows: _ts)),
              ],
            )),
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 165,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: actions.length,
            itemBuilder: (ctx, i) {
              final a = actions[i];
              final g = a['gradient'] as List<Color>;
              return GestureDetector(
                onTap: a['onTap'] as VoidCallback,
                child: Container(
                  width: 330,
                  margin: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(26),
                    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: g),
                    border: Border.all(color: kNeonSky.withOpacity(0.40), width: 1.8),
                    boxShadow: [
                      BoxShadow(color: g[0].withOpacity(0.50), blurRadius: 24, spreadRadius: 2, offset: const Offset(0, 8)),
                      BoxShadow(color: kNeonSky.withOpacity(0.15), blurRadius: 40),
                    ],
                  ),
                  child: Row(children: [
                    Container(
                      width: 72, height: 72,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(colors: [kNeonSky, kNeonCyan],
                          begin: Alignment.topLeft, end: Alignment.bottomRight),
                        boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.80), blurRadius: 30, spreadRadius: 2)],
                        border: Border.all(color: kWhite.withOpacity(0.30), width: 1.8),
                      ),
                      child: Center(child: Icon(a['icon'] as IconData, color: kWhite, size: 30, shadows: _ts)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(a['title'] as String, style: TextStyle(color: kWhite,
                          fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1,
                          shadows: [Shadow(color: kNeonSky.withOpacity(0.6), blurRadius: 12), ..._ts]),
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 5),
                        Text(a['subtitle'] as String, style: TextStyle(color: kWhite.withOpacity(0.82),
                          fontSize: 12.5, shadows: _ts), maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 4),
                          decoration: BoxDecoration(
                            color: kNeonSky.withOpacity(0.22),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: kNeonSky.withOpacity(0.65), width: 1.2),
                            boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.35), blurRadius: 10)],
                          ),
                          child: Text('TAP TO OPEN', style: TextStyle(color: kNeonLighter,
                            fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.2, shadows: _ts)),
                        ),
                      ],
                    )),
                  ]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ═══ PRAYER SECTION ═══
  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF0D47A1), const Color(0xFF1565C0), const Color(0xFF1976D2),
      const Color(0xFF0288D1), const Color(0xFF0277BD),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded, Icons.wb_sunny_rounded, Icons.cloud_rounded,
      Icons.wb_twilight_rounded, Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF0A1F4A).withOpacity(0.92),
              const Color(0xFF0D2A5C).withOpacity(0.88),
              const Color(0xFF0A1932).withOpacity(0.94),
            ],
          ),
          border: Border.all(color: kNeonSky.withOpacity(0.55), width: 1.5),
          boxShadow: [
            BoxShadow(color: kNeonBlue.withOpacity(0.35), blurRadius: 30, spreadRadius: -4, offset: const Offset(0, 12)),
            BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(26),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(
                        colors: [kNeonSky.withOpacity(0.9), kNeonBlue.withOpacity(0.8)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.5),
                      boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.5), blurRadius: 18)],
                    ),
                    child: Center(child: Icon(Icons.mosque, color: Colors.white, size: 26, shadows: _ts)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('JADWAL SHOLAT', style: TextStyle(color: kWhite,
                      fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1.2, shadows: _ts)),
                    const SizedBox(height: 2),
                    Row(children: [
                      Icon(Icons.location_on, color: kNeonSky, size: 12),
                      const SizedBox(width: 4),
                      Text(_prayerCity, style: TextStyle(color: kWhite.withOpacity(0.85),
                        fontSize: 12.5, fontWeight: FontWeight.w600, shadows: _ts)),
                    ]),
                  ])),
                  if (_locationLoading)
                    SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: kNeonSky, strokeWidth: 2)),
                ]),
                const SizedBox(height: 16),
                if (_nextPrayerLabel.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        colors: [kNeonSky.withOpacity(0.25), kNeonBlue.withOpacity(0.15)],
                      ),
                      border: Border.all(color: kNeonSky.withOpacity(0.65), width: 1.3),
                      boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.25), blurRadius: 16)],
                    ),
                    child: Row(children: [
                      _AnimatedDot(color: kNeonSky, size: 10),
                      const SizedBox(width: 12),
                      Expanded(child: Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: TextStyle(color: kWhite, fontSize: 13,
                          fontWeight: FontWeight.w700, shadows: _ts))),
                    ]),
                  ),
                const SizedBox(height: 16),
                if (_prayerLoading)
                  Center(child: CircularProgressIndicator(color: kNeonSky, strokeWidth: 2))
                else
                  SizedBox(
                    height: 120,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      itemCount: prayerKeys.length,
                      itemBuilder: (ctx, i) {
                        final key = prayerKeys[i];
                        final time = _prayerTimes[key] ?? '--:--';
                        final color = prayerColors[i];
                        final icon = prayerIcons[i];
                        final isNext = key == _nextPrayerLabel;
                        return Container(
                          margin: EdgeInsets.only(right: 10, top: isNext ? 0 : 6, bottom: isNext ? 0 : 6),
                          width: 110,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft, end: Alignment.bottomRight,
                              colors: [color.withOpacity(0.95), color.withOpacity(0.72)],
                            ),
                            boxShadow: [BoxShadow(color: color.withOpacity(isNext ? 0.75 : 0.4),
                              blurRadius: isNext ? 20 : 10, offset: const Offset(0, 4))],
                            border: Border.all(
                              color: isNext ? kNeonSky.withOpacity(0.9) : Colors.white.withOpacity(0.18),
                              width: isNext ? 1.8 : 1.2,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(icon, color: Colors.white, size: 26, shadows: _ts),
                              const SizedBox(height: 6),
                              Text(key.toUpperCase(), style: TextStyle(color: Colors.white, fontSize: 9,
                                fontWeight: FontWeight.bold, letterSpacing: 0.8, shadows: _ts)),
                              const SizedBox(height: 6),
                              Text(time, style: TextStyle(color: Colors.white, fontSize: 20,
                                fontWeight: FontWeight.w900, shadows: _ts)),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  // ═══ CORE CREW ═══
  Widget _buildCredits() {
    final crew = [
      {'role': 'Developer', 'username': 'DANZ', 'tag': 'LEAD CODER',
       'color': kNeonSky, 'icon': FontAwesomeIcons.code, 'link': 'https://wa.me/6283181413194'},
      {'role': 'Pemilik', 'username': 'ZILXPEDIA', 'tag': 'FOUNDER',
       'color': kNeonLight, 'icon': FontAwesomeIcons.userShield, 'link': 'https://t.me/r4pzzxi'},
      {'role': 'TikTok', 'username': 'SPIDERMENMU', 'tag': 'MEDIA HUB',
       'color': kNeonBlue, 'icon': FontAwesomeIcons.tiktok, 'link': 'https://www.tiktok.com/@⏤͟͟͞͞ 𝐑𝐀𝐏𝐙𝟒𝐘𝐎𝐔 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋|'},
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1F4A), Color(0xFF0D2A5C), Color(0xFF061530)],
        ),
        border: Border.all(color: kNeonSky.withOpacity(0.55), width: 1.5),
        boxShadow: [
          BoxShadow(color: kNeonBlue.withOpacity(0.35), blurRadius: 30, spreadRadius: -4, offset: const Offset(0, 12)),
          BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 20, offset: const Offset(0, 8)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.035),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    colors: [kNeonSky.withOpacity(0.35), kNeonBlue.withOpacity(0.22)],
                  ),
                  border: Border.all(color: kNeonSky.withOpacity(0.75), width: 1.3),
                  boxShadow: [BoxShadow(color: kNeonSky.withOpacity(0.3), blurRadius: 14)],
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(FontAwesomeIcons.crown, color: kNeonSky, size: 13, shadows: _ts),
                  const SizedBox(width: 8),
                  Text('VOR4X CORE CREW', style: TextStyle(color: kWhite, fontSize: 11.5,
                    fontWeight: FontWeight.w900, letterSpacing: 1.8, shadows: _ts)),
                ]),
              ),
              const SizedBox(height: 16),
              Row(children: crew.map((c) => Expanded(child: _buildCrewCard(c))).toList()),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildCrewCard(Map<String, dynamic> c) {
    final color = c['color'] as Color;
    return GestureDetector(
      onTap: () => _openUrl(c['link'] as String),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [
              color.withOpacity(0.28),
              const Color(0xFF0D2A5C).withOpacity(0.55),
              color.withOpacity(0.12),
            ],
          ),
          border: Border.all(color: color.withOpacity(0.65), width: 1.4),
          boxShadow: [
            BoxShadow(color: color.withOpacity(0.25), blurRadius: 16, offset: const Offset(0, 6)),
            BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 10, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: LinearGradient(colors: [color, kNeonBlue],
                begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: [BoxShadow(color: color.withOpacity(0.85), blurRadius: 22)],
              border: Border.all(color: Colors.white.withOpacity(0.4), width: 1.8)),
            child: Center(child: Icon(c['icon'] as IconData, color: Colors.white, size: 20, shadows: _ts)),
          ),
          const SizedBox(height: 10),
          Text(c['role'] as String, style: TextStyle(color: Colors.white, fontSize: 11,
            fontWeight: FontWeight.w800, shadows: _ts)),
          const SizedBox(height: 3),
          Text(c['username'] as String, style: TextStyle(color: Colors.white.withOpacity(0.92),
            fontSize: 10, fontWeight: FontWeight.w700, shadows: _ts),
            maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: color.withOpacity(0.25),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: color.withOpacity(0.7), width: 1),
              boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 8)],
            ),
            child: Text(c['tag'] as String, style: TextStyle(color: Colors.white, fontSize: 7.5,
              fontWeight: FontWeight.w800, letterSpacing: 0.8, shadows: _ts)),
          ),
        ]),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🚀 CHAT MENU PAGE — CAROUSEL CARD MODULES (GLASS NYATU BG)
  // ═══════════════════════════════════════════════════════════
  Widget _buildChatMenuPage() {
    final menus = [
      {
        'title': 'VOR4X',
        'subtitle': 'Hanya Bug',
        'desc': 'Buat menu bug, delay pengiriman dan loops',
        'icon': Icons.bug_report,
        'badge': 'RECOMMENDED',
        'accent': kNeonSky,
        'features': ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
        'page': HomePage(username: username, password: password, sessionKey: sessionKey,
            listBug: listBug, role: role, expiredDate: expiredDate),
      },
      {
        'title': 'CUSTOM BUG',
        'subtitle': 'Menu custom bug',
        'desc': 'Buat menu bug, delay pengiriman dan loops',
        'icon': Icons.settings_applications,
        'badge': 'CUSTOM',
        'accent': kNeonLight,
        'features': ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
        'page': CustomPayloadPage(sessionKey: sessionKey, username: username, role: role, listBug: listBug),
      },
      {
        'title': 'SPAM PAIR',
        'subtitle': 'Menu Spam Pairing',
        'desc': 'Pairing WhatsApp & OTP dengan cepat',
        'icon': Icons.mail,
        'badge': 'SPAM',
        'accent': kNeonCyan,
        'features': ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
        'page': SpamPairPage(sessionKey: sessionKey, username: username, role: role),
      },
    ];

    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final cardWidth = screenWidth * 0.80;
    final cardHeight = screenHeight * 0.63;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── HEADER ──
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
          child: Row(
            children: [
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    colors: [kNeonSky.withOpacity(0.28), kNeonBlue.withOpacity(0.35)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  border: Border.all(color: kNeonSky.withOpacity(0.55)),
                  boxShadow: [
                    BoxShadow(color: kNeonSky.withOpacity(0.4), blurRadius: 18),
                  ],
                ),
                child: Icon(Icons.grid_view_rounded, color: kNeonBright, size: 21),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (b) => const LinearGradient(
                        colors: [Colors.white, kNeonLight, kNeonSky, Colors.white],
                      ).createShader(b),
                      child: const Text('MODULES', style: TextStyle(
                        color: Colors.white, fontSize: 21,
                        fontWeight: FontWeight.w900, letterSpacing: 3.5)),
                    ),
                    Text('Geser untuk lihat modul lainnya →',
                      style: TextStyle(color: kNeonBright.withOpacity(0.7),
                        fontSize: 12, letterSpacing: 0.3)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // ── CAROUSEL CARD MODULES ──
        Expanded(
          child: ListView.builder(
            controller: _moduleScrollCtrl,
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(
              horizontal: (screenWidth - cardWidth) / 2,
              vertical: 12,
            ),
            itemCount: menus.length,
            itemBuilder: (ctx, i) {
              final m = menus[i];
              final accent = m['accent'] as Color;
              final isActive = i == _activeModuleIndex;
              return Padding(
                padding: EdgeInsets.only(
                  right: i == menus.length - 1 ? 0 : _moduleCardGap,
                ),
                child: _buildModuleCard(
                  m: m,
                  accent: accent,
                  cardWidth: cardWidth,
                  cardHeight: cardHeight,
                  isActive: isActive,
                  onTap: () => _navigate(m['page'] as Widget),
                ),
              );
            },
          ),
        ),

        // ── DOT INDICATOR ──
        Padding(
          padding: const EdgeInsets.only(top: 0, bottom: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(menus.length, (i) {
              final isActive = i == _activeModuleIndex;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: isActive ? 26 : 8,
                height: 8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  gradient: isActive
                      ? const LinearGradient(colors: [kNeonLight, kNeonSky, Colors.white])
                      : null,
                  color: isActive ? null : kNeonLight.withOpacity(0.3),
                  boxShadow: isActive
                      ? [
                          BoxShadow(color: kNeonSky.withOpacity(0.95), blurRadius: 14),
                        ]
                      : null,
                ),
              );
            }),
          ),
        ),
      ],
    );
  }

  // ═══ MODULE CARD — GLASS NYATU BACKGROUND ═══
  Widget _buildModuleCard({
    required Map<String, dynamic> m,
    required Color accent,
    required double cardWidth,
    required double cardHeight,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    final features = m['features'] as List<String>;

    return GestureDetector(
      onTap: onTap,
      onTapDown: (_) => HapticFeedback.lightImpact(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
        width: cardWidth,
        height: cardHeight,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          // ══════════════════════════════════════════
          // 🔥 GLASSMORPHISM — TRANSPARAN, NYATU BG
          // ══════════════════════════════════════════
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withOpacity(isActive ? 0.16 : 0.10),
              kNeonSky.withOpacity(isActive ? 0.10 : 0.06),
              Colors.white.withOpacity(isActive ? 0.04 : 0.02),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
          border: Border.all(
            color: Colors.white.withOpacity(isActive ? 0.35 : 0.18),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: kNeonSky.withOpacity(isActive ? 0.35 : 0.15),
              blurRadius: isActive ? 40 : 24,
              spreadRadius: -4,
              offset: const Offset(0, 12),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Stack(
              children: [
                // Glow dekoratif halus kanan atas
                Positioned(
                  top: -70, right: -70,
                  child: Container(
                    width: 220, height: 220,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          accent.withOpacity(isActive ? 0.25 : 0.12),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                // Garis cahaya atas
                Positioned(
                  top: 0, left: 30, right: 30,
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.white.withOpacity(0.5),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                // ── KONTEN ──
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // TOP: icon + badge
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // ICON BULAT GLASS
                          Container(
                            width: 64, height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.white.withOpacity(0.22),
                                  Colors.white.withOpacity(0.06),
                                ],
                              ),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.35),
                                width: 1.3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: accent.withOpacity(0.35),
                                  blurRadius: 20,
                                  spreadRadius: -2,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Icon(
                                m['icon'] as IconData,
                                color: Colors.white,
                                size: 28,
                                shadows: [
                                  Shadow(
                                    color: accent.withOpacity(0.9),
                                    blurRadius: 14,
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // BADGE pill glass
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.10),
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.30),
                                width: 1.1,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: accent.withOpacity(0.20),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                            child: Text(
                              m['badge'] as String,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 26),

                      // TITLE
                      ShaderMask(
                        shaderCallback: (b) => const LinearGradient(
                          colors: [Colors.white, Color(0xFFDBEAFE), Color(0xFF93C5FD)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ).createShader(b),
                        child: Text(
                          m['title'] as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                            height: 1.1,
                            shadows: [
                              Shadow(
                                color: Color(0xFF38BDF8),
                                blurRadius: 18,
                              ),
                              Shadow(
                                color: Colors.black,
                                blurRadius: 6,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // SUBTITLE
                      Text(
                        m['subtitle'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.92),
                          fontSize: 14.5,
                          fontWeight: FontWeight.w400,
                          height: 1.3,
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.6),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),

                      // DESC
                      Text(
                        m['desc'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 13,
                          height: 1.4,
                          fontWeight: FontWeight.w400,
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),

                      // FITUR LIST — centang hijau
                      ...features.map((f) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          children: [
                            Container(
                              width: 22, height: 22,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF4ADE80),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF4ADE80).withOpacity(0.6),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.check_rounded,
                                  color: Colors.white,
                                  size: 14,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                f,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.95),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  height: 1.2,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black.withOpacity(0.6),
                                      blurRadius: 4,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      )),

                      const Spacer(),

                      // TOMBOL START MODULE — PILL GLASS
                      GestureDetector(
                        onTap: () {
                          HapticFeedback.mediumImpact();
                          onTap();
                        },
                        behavior: HitTestBehavior.opaque,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.16),
                                Colors.white.withOpacity(0.08),
                              ],
                            ),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.35),
                              width: 1.2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: accent.withOpacity(0.25),
                                blurRadius: 20,
                                spreadRadius: -4,
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.play_arrow_rounded,
                                color: Colors.white,
                                size: 20,
                                shadows: [
                                  Shadow(
                                    color: accent.withOpacity(0.9),
                                    blurRadius: 10,
                                  ),
                                ],
                              ),
                              const SizedBox(width: 10),
                              Text(
                                'START MODULE',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 3,
                                  shadows: [
                                    Shadow(
                                      color: accent.withOpacity(0.85),
                                      blurRadius: 12,
                                    ),
                                    Shadow(
                                      color: Colors.black.withOpacity(0.7),
                                      blurRadius: 4,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 10),
                              Icon(
                                Icons.chevron_right_rounded,
                                color: Colors.white.withOpacity(0.85),
                                size: 20,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══ DRAWER ═══
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kNeonBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(children: [
        Container(
          height: 260,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [kNeonBlue.withOpacity(0.4), kNeonBg]),
          ),
          child: SafeArea(child: Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: roleColor.withOpacity(0.7), width: 2.5),
                  boxShadow: [BoxShadow(color: roleColor.withOpacity(0.4), blurRadius: 16)]),
                child: ClipOval(child: _profileImage != null
                    ? Image.file(_profileImage!, fit: BoxFit.cover)
                    : Icon(FontAwesomeIcons.userAstronaut, size: 40, color: kWhite)),
              ),
              const SizedBox(height: 14),
              Text(username, style: TextStyle(color: kWhite, fontSize: 20,
                fontWeight: FontWeight.bold, shadows: _ts)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: roleColor.withOpacity(0.20),
                  border: Border.all(color: roleColor.withOpacity(0.4)),
                ),
                child: Text(roleDisplay, style: TextStyle(color: roleColor, fontSize: 12,
                  letterSpacing: 2, fontWeight: FontWeight.bold, shadows: _ts)),
              ),
            ],
          ))),
        ),
        Expanded(child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 16),
          children: [
            if (getRoleLevel(role) >= getRoleLevel('reseller'))
              _buildDrawerItem(icon: Icons.storefront_rounded, label: 'Seller Page', onTap: () => _onDrawerNav(1)),
            if (getRoleLevel(role) >= getRoleLevel('admin'))
              _buildDrawerItem(icon: Icons.admin_panel_settings_rounded, label: 'Admin Page', onTap: () => _onDrawerNav(2)),
            if (getRoleLevel(role) >= getRoleLevel('owner'))
              _buildDrawerItem(icon: Icons.workspace_premium_rounded, label: 'Owner Page', onTap: () => _onDrawerNav(3)),
            if (getRoleLevel(role) >= getRoleLevel('ceo'))
              _buildDrawerItem(icon: Icons.workspace_premium_rounded, label: 'CEO Page', onTap: () => _onDrawerNav(4)),
            if (getRoleLevel(role) >= getRoleLevel('developers'))
              _buildDrawerItem(icon: Icons.code_rounded, label: 'Developers Page', onTap: () => _onDrawerNav(5)),
            _buildDrawerItem(icon: Icons.support_agent_rounded, label: 'Support', onTap: () => _onDrawerNav(6)),
            _buildDrawerItem(icon: Icons.history_rounded, label: 'Riwayat',
              onTap: () { Navigator.pop(context); _navigate(RiwayatPage(sessionKey: sessionKey, role: role)); }),
            _buildDrawerItem(icon: Icons.lock_outline_rounded, label: 'Ganti Password',
              onTap: () { Navigator.pop(context); _navigate(ChangePasswordPage(username: username, sessionKey: sessionKey)); }),
            _buildDrawerItem(icon: Icons.palette_rounded, label: 'Warna Tema',
              onTap: () { Navigator.pop(context); _navigate(ColorSettingsPage()); }),
            const SizedBox(height: 16),
            _buildDrawerItem(icon: Icons.logout_rounded, label: 'Keluar', isLogout: true,
              onTap: () async {
                Navigator.pop(context);
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
              }),
          ],
        )),
      ]),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon, required String label,
    required VoidCallback onTap, bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? kRed.withOpacity(0.10) : kWhite.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isLogout ? kRed.withOpacity(0.35) : kWhite24),
      ),
      child: ListTile(
        leading: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: isLogout ? kRed.withOpacity(0.2) : roleColor.withOpacity(0.15)),
          child: Icon(icon, color: isLogout ? kRed : roleColor, size: 18),
        ),
        title: Text(label, style: TextStyle(color: isLogout ? kRed : kWhite,
          fontWeight: FontWeight.w600, fontSize: 14, shadows: _ts)),
        trailing: Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  // ═══ BUILD ═══
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (context, _, __) {
        return Scaffold(
          key: _scaffoldKey,
          backgroundColor: kNeonBg,
          extendBody: true,
          extendBodyBehindAppBar: true,
          appBar: _buildAppBar(),
          drawer: _buildDrawer(),
          body: Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/dashboard.png'),
                fit: BoxFit.cover,
                alignment: Alignment.center,
              ),
            ),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          kNeonBg.withOpacity(0.55),
                          kNeonBg.withOpacity(0.20),
                          kNeonBg.withOpacity(0.55),
                        ],
                        stops: const [0.0, 0.45, 1.0],
                      ),
                    ),
                  ),
                ),
                SafeArea(
                  top: true, bottom: false,
                  child: Stack(children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 400),
                      transitionBuilder: (child, anim) =>
                          FadeTransition(opacity: anim, child: child),
                      child: KeyedSubtree(
                        key: ValueKey(_navIndex),
                        child: _buildCurrentPage(),
                      ),
                    ),
                    MiniVinylPlayer(isPlaying: _isMusicPlaying),
                  ]),
                ),
              ],
            ),
          ),
          bottomNavigationBar: _buildBottomNav(),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BOTTOM NAV — FLOATING PILL MODERN
  // ═══════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    final items = [
      const _NavItem(icon: Icons.home_rounded, label: 'Home'),
      const _NavItem(icon: Icons.chat_bubble_rounded, label: 'Chat'),
      const _NavItem(icon: Icons.people_alt_rounded, label: 'Group'),
      const _NavItem(icon: Icons.info_outline_rounded, label: 'Info'),
      const _NavItem(icon: Icons.build_rounded, label: 'Tools'),
    ];

    final bottomPad = MediaQuery.of(context).padding.bottom;
    const navHeight = 78.0;
    const circleSize = 54.0;
    const liftUp = 24.0;
    const pillRadius = 40.0;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: bottomPad > 0 ? bottomPad : 12,
      ),
      child: SizedBox(
        height: navHeight + liftUp + 6,
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.bottomCenter,
          children: [
            Positioned(
              left: 0, right: 0, bottom: 0,
              height: navHeight,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(pillRadius),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF0A1F4A).withOpacity(0.98),
                      const Color(0xFF061530).withOpacity(0.98),
                    ],
                  ),
                  border: Border.all(
                    color: kNeonSky.withOpacity(0.40),
                    width: 1.3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.45),
                      blurRadius: 20,
                      offset: const Offset(0, 6),
                    ),
                    BoxShadow(
                      color: kNeonBlue.withOpacity(0.28),
                      blurRadius: 32,
                      spreadRadius: -4,
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 0, right: 0, bottom: 0,
              height: navHeight + liftUp,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(items.length, (i) {
                  final isActive = _navIndex == i;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => _onNavTap(i),
                      behavior: HitTestBehavior.opaque,
                      child: SizedBox(
                        height: navHeight + liftUp,
                        child: Stack(
                          clipBehavior: Clip.none,
                          alignment: Alignment.bottomCenter,
                          children: [
                            AnimatedPositioned(
                              duration: const Duration(milliseconds: 380),
                              curve: Curves.easeOutBack,
                              bottom: isActive ? 26 : 14,
                              left: 0, right: 0,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  AnimatedContainer(
                                    duration: const Duration(milliseconds: 380),
                                    curve: Curves.easeOutBack,
                                    width: isActive ? circleSize : 40,
                                    height: isActive ? circleSize : 40,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: isActive
                                          ? const LinearGradient(
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                              colors: [
                                                Color(0xFF4FA8FF),
                                                Color(0xFF1565C0),
                                              ],
                                            )
                                          : LinearGradient(
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                              colors: [
                                                kNeonSky.withOpacity(0.18),
                                                kNeonBlue.withOpacity(0.10),
                                              ],
                                            ),
                                      border: Border.all(
                                        color: isActive
                                            ? Colors.white.withOpacity(0.40)
                                            : kNeonSky.withOpacity(0.35),
                                        width: isActive ? 2.2 : 1.2,
                                      ),
                                      boxShadow: isActive
                                          ? [
                                              BoxShadow(
                                                color: kNeonSky.withOpacity(0.90),
                                                blurRadius: 24,
                                                spreadRadius: 2,
                                              ),
                                              BoxShadow(
                                                color: kNeonBlue.withOpacity(0.60),
                                                blurRadius: 44,
                                              ),
                                            ]
                                          : null,
                                    ),
                                    child: Center(
                                      child: Icon(
                                        items[i].icon,
                                        color: isActive
                                            ? Colors.white
                                            : const Color(0xFFB8C7DB),
                                        size: isActive ? 25 : 21,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    items[i].label,
                                    style: TextStyle(
                                      color: isActive
                                          ? Colors.white
                                          : const Color(0xFFB8C7DB),
                                      fontSize: 11.5,
                                      fontWeight: isActive
                                          ? FontWeight.w800
                                          : FontWeight.w700,
                                      letterSpacing: 0.3,
                                      shadows: isActive
                                          ? [
                                              Shadow(
                                                color: kNeonSky.withOpacity(0.75),
                                                blurRadius: 10,
                                              ),
                                              ..._ts,
                                            ]
                                          : _ts,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ APP BAR ═══
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Colors.black.withOpacity(0.35), Colors.transparent]),
        ),
      ),
      leadingWidth: 70,
      leading: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: GestureDetector(
          onTap: () => _scaffoldKey.currentState?.openDrawer(),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: kNeonSky.withOpacity(0.10),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kNeonSky.withOpacity(0.35)),
            ),
            child: Icon(Icons.menu, color: kNeonSky, size: 20),
          ),
        ),
      ),
      title: const Center(child: _LampTitle(trigger: 0)),
      centerTitle: true,
      actions: [
        IconButton(
          icon: Icon(Icons.support_agent_rounded, color: kWhite, size: 22),
          onPressed: () => _navigate(const SupportPage()),
        ),
        IconButton(
          icon: Icon(_isMusicPlaying ? Icons.pause_circle_filled : Icons.music_note_rounded,
            color: _isMusicPlaying ? kNeonSky : kWhite, size: 22),
          onPressed: () async {
            if (_isMusicPlaying) { await _audioPlayer.pause(); }
            else { _navigate(MusicPage()); }
          },
        ),
        IconButton(
          icon: Icon(Icons.headset_mic_outlined, color: kWhite, size: 22),
          onPressed: () => _navigate(ContactPage()),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 12),
          child: GestureDetector(
            onTap: () => _navigate(ProfilePage(
              username: username, password: password, role: role,
              expiredDate: expiredDate, sessionKey: sessionKey,
            )),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: roleColor.withOpacity(0.7), width: 2),
                color: roleColor.withOpacity(0.25),
                boxShadow: [BoxShadow(color: roleColor.withOpacity(0.35), blurRadius: 12)],
              ),
              child: ClipOval(child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : Icon(FontAwesomeIcons.userAstronaut, color: roleColor, size: 20)),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 👤 ORBITING AVATAR
// ═══════════════════════════════════════════════════════════
class _OrbitingAvatar extends StatefulWidget {
  final File? imageFile;
  final String username;
  final VoidCallback onTap;
  const _OrbitingAvatar({this.imageFile, required this.username, required this.onTap});
  @override
  State<_OrbitingAvatar> createState() => _OrbitingAvatarState();
}

class _OrbitingAvatarState extends State<_OrbitingAvatar>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 12))..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: 82, height: 82,
        child: Stack(alignment: Alignment.center, children: [
          AnimatedBuilder(
            animation: _ctrl,
            builder: (context, _) {
              return Transform.rotate(
                angle: _ctrl.value * 2 * math.pi,
                child: Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: kNeonBlue.withOpacity(0.6), width: 1),
                  ),
                  child: Stack(children: [
                    Positioned(
                      top: -3, left: 42,
                      child: Container(
                        width: 7, height: 7,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle, color: Colors.white,
                          boxShadow: [
                            BoxShadow(color: Colors.white, blurRadius: 12),
                            BoxShadow(color: kNeonSky, blurRadius: 20),
                          ],
                        ),
                      ),
                    ),
                  ]),
                ),
              );
            },
          ),
          Container(
            width: 82, height: 82,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: kWhite.withOpacity(0.25), width: 2),
              boxShadow: [
                BoxShadow(color: kNeonBlue.withOpacity(0.6), blurRadius: 30),
                BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 5)),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: widget.imageFile != null
                  ? Image.file(widget.imageFile!, fit: BoxFit.cover)
                  : Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [kNeonSky.withOpacity(0.3), kNeonBlue.withOpacity(0.2)],
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                      ),
                      child: Center(child: Text(
                        widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '?',
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900,
                          color: kNeonSky,
                          shadows: [Shadow(color: kNeonSky, blurRadius: 20), Shadow(color: kNeonSky, blurRadius: 40)]),
                      )),
                    ),
            ),
          ),
          Positioned(
            bottom: 2, right: 2,
            child: Container(
              width: 15, height: 15,
              decoration: BoxDecoration(
                shape: BoxShape.circle, color: const Color(0xFF22FF88),
                border: Border.all(color: const Color(0xFF061530), width: 3),
                boxShadow: [BoxShadow(color: const Color(0xFF22FF88), blurRadius: 14)],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}