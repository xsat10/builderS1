// dashboard_page.dart

import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// HAPUS BARIS "import '.dart';" JIKA MEMANG TIDAK ADA FILE TERSEBUT.
//
// import '.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'ucapan_page.dart';
import 'toko_page.dart';
import 'public_chat_page.dart';
import 'weather_page.dart';
import 'jadwal_sholat_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  WebSocketChannel? _channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;

  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;

  Timer? _statsTimer;
  Timer? _onlineTimer;
  Timer? _clockTimer;

  String _currentDateTime = "";

  int _batteryLevel = 0;
  bool _isCharging = false;

  String _deviceModel = "Memuat...";
  String _androidVersion = "Memuat...";
  String _ramInfo = "Memuat...";
  String _storageInfo = "Memuat...";
  String _networkInfo = "Memuat...";

  // ============================================================
  // GLOBAL CHAT
  // ============================================================

  List<Map<String, dynamic>> _chatMessages = [];
  List<String> _onlineUserList = [];

  final TextEditingController _chatInputController =
      TextEditingController();

  final ScrollController _chatScrollController =
      ScrollController();

  // ============================================================
  // THEME
  // ============================================================

  static const Color primaryDark = Color(0xFF05070D);
  static const Color backgroundDark = Color(0xFF080B12);
  static const Color cardDark = Color(0xFF0D121B);
  static const Color cardDark2 = Color(0xFF111925);

  static const Color gold = Color(0xFFFFD700);
  static const Color goldSoft = Color(0xFFFFE66D);

  static const Color blue = Color(0xFF4A9EFF);
  static const Color blueSoft = Color(0xFF72B5FF);

  static const Color white = Color(0xFFFFFFFF);
  static const Color grey = Color(0xFF8D99AA);
  static const Color grey2 = Color(0xFF64748B);

  Color get glassPrimary => const Color(0x18FFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);

  LinearGradient get goldGradient {
    return const LinearGradient(
      colors: [
        Color(0xFFFFE36E),
        Color(0xFFFFD700),
        Color(0xFFE8A900),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  LinearGradient get blueGradient {
    return const LinearGradient(
      colors: [
        Color(0xFF72B5FF),
        Color(0xFF4A9EFF),
        Color(0xFF246BC2),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  LinearGradient get darkGradient {
    return const LinearGradient(
      colors: [
        Color(0xFF151D29),
        Color(0xFF080B12),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;

    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _initAnimations();

    _selectedPage = _buildHomePage();

    _initAndroidIdAndConnect();
    _loadDeviceStats();
    _loadProfileImage();

    _startStatsTimer();

    _fetchOnlineUsers();
    _startOnlinePolling();

    _startClock();
  }

  // ============================================================
  // ANIMATION
  // ============================================================

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );
  }

  // ============================================================
  // STATS
  // ============================================================

  void _startStatsTimer() {
    _statsTimer = Timer.periodic(
      const Duration(seconds: 5),
      (timer) {
        if (_channel != null) {
          _channel?.sink.add(
            jsonEncode({
              "type": "stats",
            }),
          );
        }
      },
    );
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse(
          'http://127.0.0.1:3000/getOnlineUsers?key=$sessionKey',
        ),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['valid'] == true) {
          if (!mounted) return;

          setState(() {
            onlineUsers = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint(
        'Error fetching online users: $e',
      );
    }
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(
      const Duration(seconds: 10),
      (timer) {
        _fetchOnlineUsers();
      },
    );
  }

  // ============================================================
  // CLOCK
  // ============================================================

  void _startClock() {
    _updateDateTime();

    _clockTimer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        _updateDateTime();
      },
    );
  }

  void _updateDateTime() {
    final now = DateTime.now();

    final time =
        "${now.hour.toString().padLeft(2, '0')}:"
        "${now.minute.toString().padLeft(2, '0')}:"
        "${now.second.toString().padLeft(2, '0')}";

    final date =
        "${now.day.toString().padLeft(2, '0')}/"
        "${now.month.toString().padLeft(2, '0')}/"
        "${now.year}";

    if (!mounted) return;

    setState(() {
      _currentDateTime = "$time • $date";
    });
  }

  // ============================================================
  // PROFILE
  // ============================================================

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();

    final imagePath = prefs.getString(
      'profile_image_$username',
    );

    if (imagePath != null && imagePath.isNotEmpty) {
      if (!mounted) return;

      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  // ============================================================
  // DEVICE INFO
  // ============================================================

  static const MethodChannel _deviceChannel =
      MethodChannel('stux_x_01/device_info');

  Future<void> _loadDeviceStats() async {
    try {
      final result = await _deviceChannel.invokeMethod<dynamic>(
        'getDeviceStats',
      );

      if (!mounted || result is! Map) return;

      final data = Map<dynamic, dynamic>.from(result);

      setState(() {
        _batteryLevel =
            (data['batteryLevel'] as num?)?.toInt() ?? 0;

        _isCharging =
            data['isCharging'] == true;

        _deviceModel =
            (data['deviceModel'] ?? 'Unknown device').toString();

        _androidVersion =
            (data['androidVersion'] ?? 'Unknown').toString();

        _ramInfo =
            (data['ramInfo'] ?? 'Unknown').toString();

        _storageInfo =
            (data['storageInfo'] ?? 'Unknown').toString();

        _networkInfo =
            (data['networkInfo'] ?? 'Unknown').toString();
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _deviceModel = 'Unknown device';
        _androidVersion = 'Unknown';
        _ramInfo = 'Unavailable';
        _storageInfo = 'Unavailable';
        _networkInfo = 'Unavailable';
      });
    }
  }

  // ============================================================
  // WEBSOCKET
  // ============================================================

  Future<void> _initAndroidIdAndConnect() async {
    try {
      final deviceInfo =
          await DeviceInfoPlugin().androidInfo;

      androidId = deviceInfo.id;

      _connectToWebSocket();
    } catch (e) {
      debugPrint(
        'Device info error: $e',
      );
    }
  }

  void _connectToWebSocket() {
    _channel = WebSocketChannel.connect(
      Uri.parse(
        'http://127.0.0.1:3000',
      ),
    );

    _channel?.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );

    _channel?.sink.add(
      jsonEncode({
        "type": "stats",
      }),
    );

    _channel?.sink.add(
      jsonEncode({
        "type": "get_online_users",
      }),
    );

    _channel?.stream.listen(
      (event) {
        try {
          final data = jsonDecode(event);

          if (data['type'] == 'myInfo') {
            if (data['valid'] == false) {
              if (data['reason'] ==
                  'androidIdMismatch') {
                _handleInvalidSession(
                  "Your account has logged on another device.",
                );
              } else if (data['reason'] ==
                  'keyInvalid') {
                _handleInvalidSession(
                  "Key is not valid. Please login again.",
                );
              }
            }
          }

          if (data['type'] == 'stats') {
            if (!mounted) return;

            setState(() {
              onlineUsers =
                  data['onlineUsers'] ?? 0;

              activeConnections =
                  data['activeConnections'] ?? 0;
            });
          }

          if (data['type'] ==
              'chat_message') {
            _addChatMessage(data);
          }

          if (data['type'] ==
              'online_users_list') {
            if (mounted &&
                data['users'] != null) {
              setState(() {
                _onlineUserList =
                    List<String>.from(
                  data['users'],
                );
              });
            }
          }
        } catch (e) {
          debugPrint(
            'WebSocket parsing error: $e',
          );
        }
      },
    );
  }

  // ============================================================
  // CHAT
  // ============================================================

  void _addChatMessage(
    Map<String, dynamic> message,
  ) {
    if (!mounted) return;

    setState(() {
      _chatMessages.add(message);
    });

    if (_bottomNavIndex == 4 &&
        _chatScrollController.hasClients) {
      WidgetsBinding.instance
          .addPostFrameCallback((_) {
        if (_chatScrollController
            .hasClients) {
          _chatScrollController.animateTo(
            _chatScrollController
                .position.maxScrollExtent,
            duration:
                const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  void _sendChatMessage(String text) {
    if (text.trim().isEmpty) return;

    final messageData = {
      "type": "chat",
      "message": text,
      "username": username,
      "sessionKey": sessionKey,
    };

    _channel?.sink.add(
      jsonEncode(messageData),
    );

    _chatInputController.clear();
  }

  void _requestOnlineUsersList() {
    _channel?.sink.add(
      jsonEncode({
        "type": "get_online_users",
      }),
    );
  }

  String _formatChatTime(dynamic timeData) {
    if (timeData == null) {
      return "Now";
    }

    try {
      final DateTime time =
          DateTime.parse(
        timeData.toString(),
      );

      return
          "${time.hour.toString().padLeft(2, '0')}:"
          "${time.minute.toString().padLeft(2, '0')}";
    } catch (_) {
      return "Just now";
    }
  }

  // ============================================================
  // INVALID SESSION
  // ============================================================

  void _handleInvalidSession(
    String message,
  ) async {
    await Future.delayed(
      const Duration(milliseconds: 300),
    );

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.clear();

    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: _glassContainer(
            padding: const EdgeInsets.all(22),
            radius: 24,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    gradient: goldGradient,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color:
                            gold.withOpacity(.25),
                        blurRadius: 22,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.warning_amber_rounded,
                    color: primaryDark,
                    size: 30,
                  ),
                ),

                const SizedBox(height: 18),

                const Text(
                  "SESSION EXPIRED",
                  style: TextStyle(
                    color: gold,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: grey,
                    fontSize: 13,
                    height: 1.5,
                  ),
                ),

                const SizedBox(height: 22),

                SizedBox(
                  width: double.infinity,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: blueGradient,
                      borderRadius:
                          BorderRadius.circular(14),
                    ),
                    child: TextButton(
                      onPressed: () {
                        Navigator.of(context)
                            .pushAndRemoveUntil(
                          MaterialPageRoute(
                            builder: (_) =>
                                const LoginPage(),
                          ),
                          (route) => false,
                        );
                      },
                      child: const Text(
                        "LOGIN KEMBALI",
                        style: TextStyle(
                          color: white,
                          fontWeight:
                              FontWeight.w800,
                          letterSpacing: .7,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // GLASS CONTAINER
  // ============================================================

  Widget _glassContainer({
    required Widget child,
    EdgeInsetsGeometry padding =
        const EdgeInsets.all(16),
    double radius = 20,
    Color? color,
    Border? border,
  }) {
    return ClipRRect(
      borderRadius:
          BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: 18,
          sigmaY: 18,
        ),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color:
                color ?? glassPrimary,
            borderRadius:
                BorderRadius.circular(radius),
            border: border ??
                Border.all(
                  color:
                      Colors.white.withOpacity(.07),
                ),
          ),
          child: child,
        ),
      ),
    );
  }

  // ============================================================
  // HOME
  // ============================================================

  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics:
          const BouncingScrollPhysics(),
      padding:
          const EdgeInsets.only(bottom: 30),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          _buildProfileHero(),

          const SizedBox(height: 18),

          Padding(
            padding:
                const EdgeInsets.symmetric(
              horizontal: 16,
            ),
            child:
                _buildDeviceStatusCard(),
          ),

          const SizedBox(height: 30),

          _buildSectionHeader(
            "QUICK ACTIONS",
            "SHORTCUT",
          ),

          const SizedBox(height: 14),

          _buildQuickActions(),

          if (newsList.isNotEmpty) ...[
            const SizedBox(height: 32),

            _buildSectionHeader(
              "BERITA TERBARU",
              "${newsList.length} ARTIKEL",
            ),

            const SizedBox(height: 14),

            _buildNewsSection(),
          ],

          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ============================================================
  // PROFILE HERO
  // ============================================================

  Widget _buildProfileHero() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(
        20,
        28,
        20,
        24,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF121C2A),
            Color(0xFF070A10),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border(
          bottom: BorderSide(
            color: gold.withOpacity(.15),
          ),
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -60,
            top: -70,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                    blue.withOpacity(.08),
              ),
            ),
          ),

          Positioned(
            left: -70,
            bottom: -100,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                    gold.withOpacity(.05),
              ),
            ),
          ),

          Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _buildGlowingAvatar(),

                  const SizedBox(width: 14),

                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback:
                              (bounds) {
                            return goldGradient
                                .createShader(
                              bounds,
                            );
                          },
                          child: Text(
                            username,
                            maxLines: 1,
                            overflow:
                                TextOverflow.ellipsis,
                            style:
                                const TextStyle(
                              color: white,
                              fontSize: 22,
                              fontWeight:
                                  FontWeight.w900,
                              letterSpacing: .4,
                            ),
                          ),
                        ),

                        const SizedBox(height: 6),

                        Row(
                          children: [
                            Container(
                              padding:
                                  const EdgeInsets
                                      .symmetric(
                                horizontal: 9,
                                vertical: 5,
                              ),
                              decoration:
                                  BoxDecoration(
                                color:
                                    blue.withOpacity(
                                  .12,
                                ),
                                borderRadius:
                                    BorderRadius
                                        .circular(
                                  20,
                                ),
                                border:
                                    Border.all(
                                  color:
                                      blue.withOpacity(
                                    .3,
                                  ),
                                ),
                              ),
                              child: Text(
                                role.toUpperCase(),
                                style:
                                    const TextStyle(
                                  color: blueSoft,
                                  fontSize: 9,
                                  fontWeight:
                                      FontWeight.w800,
                                  letterSpacing:
                                      1,
                                ),
                              ),
                            ),

                            const SizedBox(width: 8),

                            const Icon(
                              Icons.verified_rounded,
                              color: gold,
                              size: 15,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  _buildLiveBadge(),
                ],
              ),

              const SizedBox(height: 24),

              Row(
                children: [
                  Expanded(
                    child: _miniHeroInfo(
                      Icons.access_time_rounded,
                      _currentDateTime,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _miniHeroInfo(
                      Icons.event_rounded,
                      expiredDate,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGlowingAvatar() {
    return Container(
      width: 68,
      height: 68,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: goldGradient,
        boxShadow: [
          BoxShadow(
            color: gold.withOpacity(.28),
            blurRadius: 22,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipOval(
        child: _profileImage != null
            ? Image.file(
                _profileImage!,
                fit: BoxFit.cover,
              )
            : Container(
                decoration: BoxDecoration(
                  gradient: blueGradient,
                ),
                child: const Icon(
                  FontAwesomeIcons
                      .userAstronaut,
                  color: white,
                  size: 29,
                ),
              ),
      ),
    );
  }

  Widget _buildLiveBadge() {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color:
            const Color(0xFF00C853)
                .withOpacity(.08),
        borderRadius:
            BorderRadius.circular(20),
        border: Border.all(
          color:
              const Color(0xFF00C853)
                  .withOpacity(.35),
        ),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration:
                const BoxDecoration(
              color:
                  Color(0xFF00C853),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          const Text(
            "ONLINE",
            style: TextStyle(
              color:
                  Color(0xFF00C853),
              fontSize: 8,
              fontWeight:
                  FontWeight.w800,
              letterSpacing: .8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniHeroInfo(
    IconData icon,
    String value,
  ) {
    return _glassContainer(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 10,
      ),
      radius: 14,
      child: Row(
        children: [
          Icon(
            icon,
            color: gold,
            size: 15,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              maxLines: 1,
              overflow:
                  TextOverflow.ellipsis,
              style:
                  const TextStyle(
                color: white,
                fontSize: 10,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION HEADER
  // ============================================================

  Widget _buildSectionHeader(
    String title,
    String trailing,
  ) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 20,
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 25,
            decoration: BoxDecoration(
              gradient: goldGradient,
              borderRadius:
                  BorderRadius.circular(4),
            ),
          ),

          const SizedBox(width: 10),

          Text(
            title,
            style: const TextStyle(
              color: white,
              fontSize: 13,
              fontWeight:
                  FontWeight.w800,
              letterSpacing: 1.3,
            ),
          ),

          const Spacer(),

          Text(
            trailing,
            style: const TextStyle(
              color: grey2,
              fontSize: 9,
              fontWeight:
                  FontWeight.w700,
              letterSpacing: .7,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DEVICE STATUS
  // ============================================================

  Widget _buildDeviceStatusCard() {
    final battery =
        (_batteryLevel.clamp(0, 100)
                as num)
            .toDouble() /
        100;

    return _glassContainer(
      radius: 24,
      padding:
          const EdgeInsets.fromLTRB(
        16,
        17,
        16,
        18,
      ),
      color:
          const Color(0xB50A1018),
      border: Border.all(
        color: gold.withOpacity(.18),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: BoxDecoration(
                  gradient: goldGradient,
                  borderRadius:
                      BorderRadius.circular(
                    14,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color:
                          gold.withOpacity(.2),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons
                      .space_dashboard_rounded,
                  color: primaryDark,
                  size: 22,
                ),
              ),

              const SizedBox(width: 12),

              const Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      "SYSTEM STATUS",
                      style:
                          TextStyle(
                        color: white,
                        fontSize: 16,
                        fontWeight:
                            FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      "DEVICE • ACCOUNT • NETWORK",
                      style:
                          TextStyle(
                        color: grey,
                        fontSize: 8,
                        fontWeight:
                            FontWeight.w700,
                        letterSpacing:
                            1,
                      ),
                    ),
                  ],
                ),
              ),

              _statusPill(),
            ],
          ),

          const SizedBox(height: 18),

          ClipRRect(
            borderRadius:
                BorderRadius.circular(10),
            child: SizedBox(
              height: 5,
              child: Stack(
                children: [
                  Container(
                    color: Colors.white
                        .withOpacity(.05),
                  ),
                  FractionallySizedBox(
                    widthFactor: battery,
                    alignment:
                        Alignment.centerLeft,
                    child: Container(
                      decoration:
                          BoxDecoration(
                        gradient:
                            goldGradient,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              Expanded(
                child: _statusItem(
                  Icons.person_rounded,
                  "ROLE",
                  role.toUpperCase(),
                  gold,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.people_alt_rounded,
                  "ONLINE",
                  "$onlineUsers",
                  blue,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.battery_charging_full_rounded,
                  "BATTERY",
                  "${_batteryLevel}%",
                  gold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              Expanded(
                child: _statusItem(
                  Icons.phone_android_rounded,
                  "DEVICE",
                  _deviceModel,
                  blue,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.android_rounded,
                  "ANDROID",
                  _androidVersion,
                  blue,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.link_rounded,
                  "CONNECTION",
                  "$activeConnections",
                  gold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              Expanded(
                child: _statusItem(
                  Icons.memory_rounded,
                  "RAM",
                  _ramInfo,
                  blue,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.storage_rounded,
                  "STORAGE",
                  _storageInfo,
                  gold,
                ),
              ),
              Expanded(
                child: _statusItem(
                  Icons.wifi_rounded,
                  "NETWORK",
                  _networkInfo,
                  blue,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statusPill() {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color:
            gold.withOpacity(.07),
        borderRadius:
            BorderRadius.circular(20),
        border: Border.all(
          color:
              gold.withOpacity(.25),
        ),
      ),
      child: const Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            Icons.bolt_rounded,
            color: gold,
            size: 12,
          ),
          SizedBox(width: 4),
          Text(
            "ACTIVE",
            style: TextStyle(
              color: gold,
              fontSize: 8,
              fontWeight:
                  FontWeight.w900,
              letterSpacing: .8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusItem(
    IconData icon,
    String label,
    String value,
    Color color,
  ) {
    return Container(
      margin:
          const EdgeInsets.symmetric(
        horizontal: 3,
      ),
      constraints:
          const BoxConstraints(
        minHeight: 65,
      ),
      padding:
          const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color:
            Colors.white.withOpacity(.025),
        borderRadius:
            BorderRadius.circular(15),
        border: Border.all(
          color:
              Colors.white.withOpacity(.055),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: color,
            size: 16,
          ),
          const SizedBox(height: 5),
          Text(
            label,
            maxLines: 1,
            overflow:
                TextOverflow.ellipsis,
            style: const TextStyle(
              color: grey2,
              fontSize: 7,
              fontWeight:
                  FontWeight.w800,
              letterSpacing: .7,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 2,
            overflow:
                TextOverflow.ellipsis,
            style: const TextStyle(
              color: white,
              fontSize: 9,
              fontWeight:
                  FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // QUICK ACTIONS
  // ============================================================

  Widget _buildQuickActions() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        title: "Info Channel",
        subtitle: "Telegram",
        colors: const [
          Color(0xFF168DD9),
          Color(0xFF07538A),
        ],
        onTap: () {
          _openUrl(
            "https://t.me/channelalpin",
          );
        },
      ),

      _QuickActionData(
        icon: Icons.wifi_tethering_rounded,
        title: "Bug Sender",
        subtitle: "Sender",
        colors: const [
          Color(0xFF276BFF),
          Color(0xFF142E70),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.card_giftcard_rounded,
        title: "Ucapan",
        subtitle: "Messages",
        colors: const [
          Color(0xFFE6A51C),
          Color(0xFF704C00),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  UcapanPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.shopping_bag_rounded,
        title: "Toko",
        subtitle: "Marketplace",
        colors: const [
          Color(0xFF16A085),
          Color(0xFF075744),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  const TokoPage(),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.public_rounded,
        title: "Public Chat",
        subtitle: "Community",
        colors: const [
          Color(0xFFE64A8B),
          Color(0xFF71143F),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  PublicChatPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.history_rounded,
        title: "Riwayat",
        subtitle: "Activity",
        colors: const [
          Color(0xFF9357E8),
          Color(0xFF452071),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  RiwayatPage(
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.wb_sunny_rounded,
        title: "Cek Cuaca",
        subtitle: "Weather",
        colors: const [
          Color(0xFFFFA726),
          Color(0xFF7B3F00),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  WeatherPage(
                sessionKey: sessionKey,
                username: username,
              ),
            ),
          );
        },
      ),

      _QuickActionData(
        icon: Icons.mosque_rounded,
        title: "Jadwal Sholat",
        subtitle: "Prayer",
        colors: const [
          Color(0xFF38B27D),
          Color(0xFF14563E),
        ],
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  JadwalSholatPage(
                sessionKey: sessionKey,
                username: username,
              ),
            ),
          );
        },
      ),
    ];

    return SizedBox(
      height: 142,
      child: ListView.separated(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 16,
        ),
        scrollDirection:
            Axis.horizontal,
        physics:
            const BouncingScrollPhysics(),
        itemCount: actions.length,
        separatorBuilder:
            (_, __) =>
                const SizedBox(width: 12),
        itemBuilder:
            (context, index) {
          final item =
              actions[index];

          return _buildQuickActionCard(
            item,
            index,
          );
        },
      ),
    );
  }

  Widget _buildQuickActionCard(
    _QuickActionData item,
    int index,
  ) {
    return TweenAnimationBuilder<double>(
      duration: Duration(
        milliseconds:
            300 + (index * 50),
      ),
      tween:
          Tween(begin: .85, end: 1),
      curve:
          Curves.easeOutBack,
      builder:
          (context, scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: GestureDetector(
        onTap: item.onTap,
        child: Container(
          width: 132,
          padding:
              const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient:
                LinearGradient(
              colors: item.colors,
              begin:
                  Alignment.topLeft,
              end:
                  Alignment.bottomRight,
            ),
            borderRadius:
                BorderRadius.circular(22),
            border: Border.all(
              color:
                  Colors.white.withOpacity(
                .12,
              ),
            ),
            boxShadow: [
              BoxShadow(
                color:
                    item.colors.first
                        .withOpacity(.16),
                blurRadius: 18,
                offset:
                    const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: BoxDecoration(
                  color: white.withOpacity(.12),
                  borderRadius:
                      BorderRadius.circular(
                    14,
                  ),
                ),
                child: Icon(
                  item.icon,
                  color: white,
                  size: 21,
                ),
              ),

              const Spacer(),

              Text(
                item.title,
                maxLines: 1,
                overflow:
                    TextOverflow.ellipsis,
                style: const TextStyle(
                  color: white,
                  fontSize: 12,
                  fontWeight:
                      FontWeight.w800,
                ),
              ),

              const SizedBox(height: 3),

              Text(
                item.subtitle,
                maxLines: 1,
                overflow:
                    TextOverflow.ellipsis,
                style: TextStyle(
                  color:
                      white.withOpacity(.62),
                  fontSize: 9,
                  fontWeight:
                      FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // NEWS
  // ============================================================

  Widget _buildNewsSection() {
    return SizedBox(
      height: 300,
      child: ListView.builder(
        scrollDirection:
            Axis.horizontal,
        physics:
            const BouncingScrollPhysics(),
        padding:
            const EdgeInsets.symmetric(
          horizontal: 16,
        ),
        itemCount:
            newsList.length,
        itemBuilder:
            (context, index) {
          final item =
              newsList[index];

          return Container(
            width:
                MediaQuery.of(context)
                        .size
                        .width *
                    .82,
            margin:
                const EdgeInsets.only(
              right: 14,
            ),
            child:
                _buildNewsCard(
              item,
              index,
            ),
          );
        },
      ),
    );
  }

  Widget _buildNewsCard(
    dynamic item,
    int index,
  ) {
    if (item == null) {
      return const SizedBox();
    }

    return TweenAnimationBuilder<double>(
      duration: Duration(
        milliseconds:
            400 + (index * 80),
      ),
      tween:
          Tween(begin: .94, end: 1),
      curve:
          Curves.easeOut,
      builder:
          (context, scale, child) {
        return Transform.scale(
          scale: scale,
          child: child,
        );
      },
      child: GestureDetector(
        onTap: () {},
        child: _glassContainer(
          radius: 22,
          padding:
              EdgeInsets.zero,
          color:
              const Color(0xCC0B1018),
          border: Border.all(
            color:
                Colors.white.withOpacity(
              .07,
            ),
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 5,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (item['image'] != null &&
                        item['image']
                            .toString()
                            .isNotEmpty)
                      Image.network(
                        item['image'],
                        fit: BoxFit.cover,
                        errorBuilder:
                            (_, __, ___) {
                          return _newsPlaceholder();
                        },
                        loadingBuilder:
                            (
                          context,
                          child,
                          progress,
                        ) {
                          if (progress ==
                              null) {
                            return child;
                          }

                          return _newsLoading();
                        },
                      )
                    else
                      _newsPlaceholder(),

                    DecoratedBox(
                      decoration:
                          BoxDecoration(
                        gradient:
                            LinearGradient(
                          colors: [
                            Colors.black
                                .withOpacity(.5),
                            Colors.transparent,
                            Colors.black
                                .withOpacity(.15),
                          ],
                          begin:
                              Alignment
                                  .bottomCenter,
                          end:
                              Alignment
                                  .topCenter,
                        ),
                      ),
                    ),

                    Positioned(
                      left: 12,
                      top: 12,
                      child: Container(
                        padding:
                            const EdgeInsets
                                .symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration:
                            BoxDecoration(
                          gradient:
                              goldGradient,
                          borderRadius:
                              BorderRadius
                                  .circular(
                            9,
                          ),
                        ),
                        child: const Text(
                          "NEW",
                          style:
                              TextStyle(
                            color:
                                primaryDark,
                            fontSize: 8,
                            fontWeight:
                                FontWeight.w900,
                            letterSpacing:
                                .8,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                flex: 4,
                child: Padding(
                  padding:
                      const EdgeInsets.all(
                    14,
                  ),
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment
                            .start,
                    children: [
                      Text(
                        item['title'] ??
                            'No Title',
                        maxLines: 2,
                        overflow:
                            TextOverflow.ellipsis,
                        style:
                            const TextStyle(
                          color: white,
                          fontSize: 14,
                          fontWeight:
                              FontWeight.w800,
                        ),
                      ),

                      const SizedBox(height: 5),

                      Expanded(
                        child: Text(
                          item['desc'] ??
                              '',
                          maxLines: 2,
                          overflow:
                              TextOverflow
                                  .ellipsis,
                          style:
                              const TextStyle(
                            color: grey,
                            fontSize: 10,
                            height: 1.4,
                          ),
                        ),
                      ),

                      Row(
                        children: [
                          const Icon(
                            Icons
                                .access_time_rounded,
                            color: gold,
                            size: 12,
                          ),
                          const SizedBox(
                            width: 5,
                          ),
                          Text(
                            _formatDate(
                              item[
                                  'created_at'],
                            ),
                            style:
                                const TextStyle(
                              color: grey2,
                              fontSize: 9,
                            ),
                          ),
                          const Spacer(),
                          const Icon(
                            Icons
                                .arrow_forward_rounded,
                            color: blue,
                            size: 15,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _newsPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        gradient: darkGradient,
      ),
      child: const Center(
        child: Icon(
          Icons.image_outlined,
          color: grey,
          size: 38,
        ),
      ),
    );
  }

  Widget _newsLoading() {
    return Container(
      decoration: BoxDecoration(
        gradient: darkGradient,
      ),
      child: const Center(
        child: SizedBox(
          width: 24,
          height: 24,
          child:
              CircularProgressIndicator(
            strokeWidth: 2,
            color: gold,
          ),
        ),
      ),
    );
  }

  String _formatDate(
    String? dateString,
  ) {
    if (dateString == null) {
      return "Baru saja";
    }

    try {
      final date =
          DateTime.parse(dateString);

      final now =
          DateTime.now();

      final diff =
          now.difference(date);

      if (diff.inDays > 0) {
        return "${diff.inDays} hari lalu";
      }

      if (diff.inHours > 0) {
        return "${diff.inHours} jam lalu";
      }

      if (diff.inMinutes > 0) {
        return "${diff.inMinutes} menit lalu";
      }

      return "Baru saja";
    } catch (_) {
      return dateString;
    }
  }

  // ============================================================
  // GLOBAL CHAT
  // ============================================================

  Widget _buildGlobalChatPage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF0D1724),
            backgroundDark,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        children: [
          _buildChatHeader(),

          _buildOnlineUsers(),

          Expanded(
            child: _chatMessages.isEmpty
                ? _buildEmptyChat()
                : ListView.builder(
                    controller:
                        _chatScrollController,
                    physics:
                        const BouncingScrollPhysics(),
                    padding:
                        const EdgeInsets
                            .fromLTRB(
                      16,
                      12,
                      16,
                      12,
                    ),
                    itemCount:
                        _chatMessages.length,
                    itemBuilder:
                        (context, index) {
                      return _buildMessageBubble(
                        _chatMessages[index],
                      );
                    },
                  ),
          ),

          _buildChatInput(),
        ],
      ),
    );
  }

  Widget _buildChatHeader() {
    return Padding(
      padding:
          const EdgeInsets.fromLTRB(
        18,
        18,
        18,
        10,
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 28,
            decoration: BoxDecoration(
              gradient: goldGradient,
              borderRadius:
                  BorderRadius.circular(4),
            ),
          ),

          const SizedBox(width: 11),

          const Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                "GLOBAL CHAT",
                style: TextStyle(
                  color: white,
                  fontSize: 17,
                  fontWeight:
                      FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              SizedBox(height: 2),
              Text(
                "COMMUNITY NETWORK",
                style: TextStyle(
                  color: grey2,
                  fontSize: 8,
                  fontWeight:
                      FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),

          const Spacer(),

          GestureDetector(
            onTap:
                _requestOnlineUsersList,
            child: _glassContainer(
              radius: 13,
              padding:
                  const EdgeInsets.all(
                9,
              ),
              child: const Icon(
                Icons.refresh_rounded,
                color: gold,
                size: 19,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineUsers() {
    return SizedBox(
      height: 47,
      child: ListView.builder(
        scrollDirection:
            Axis.horizontal,
        physics:
            const BouncingScrollPhysics(),
        padding:
            const EdgeInsets.symmetric(
          horizontal: 16,
        ),
        itemCount:
            _onlineUserList.length,
        itemBuilder:
            (context, index) {
          final user =
              _onlineUserList[index];

          return Container(
            margin:
                const EdgeInsets.only(
              right: 9,
            ),
            padding:
                const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 6,
            ),
            decoration:
                BoxDecoration(
              color:
                  blue.withOpacity(.06),
              borderRadius:
                  BorderRadius.circular(
                20,
              ),
              border: Border.all(
                color:
                    blue.withOpacity(.16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration:
                      const BoxDecoration(
                    color:
                        Color(0xFF00C853),
                    shape:
                        BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 7),
                Text(
                  user,
                  style:
                      const TextStyle(
                    color: white,
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyChat() {
    return Center(
      child: Column(
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Container(
            width: 75,
            height: 75,
            decoration: BoxDecoration(
              gradient:
                  darkGradient,
              shape: BoxShape.circle,
              border: Border.all(
                color:
                    blue.withOpacity(.2),
              ),
            ),
            child: const Icon(
              Icons
                  .chat_bubble_outline_rounded,
              color: blue,
              size: 32,
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            "Belum ada pesan",
            style: TextStyle(
              color: white,
              fontSize: 15,
              fontWeight:
                  FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            "Mulai obrolan global sekarang.",
            style: TextStyle(
              color: grey,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(
    Map<String, dynamic> msg,
  ) {
    final isMe =
        msg['username'] == username;

    return Align(
      alignment: isMe
          ? Alignment.centerRight
          : Alignment.centerLeft,
      child: Container(
        constraints:
            BoxConstraints(
          maxWidth:
              MediaQuery.of(context)
                      .size
                      .width *
                  .78,
        ),
        margin:
            const EdgeInsets.only(
          bottom: 10,
        ),
        padding:
            const EdgeInsets.all(12),
        decoration:
            BoxDecoration(
          gradient: isMe
              ? blueGradient
              : darkGradient,
          borderRadius:
              BorderRadius.only(
            topLeft:
                const Radius.circular(
              18,
            ),
            topRight:
                const Radius.circular(
              18,
            ),
            bottomLeft:
                Radius.circular(
              isMe ? 18 : 5,
            ),
            bottomRight:
                Radius.circular(
              isMe ? 5 : 18,
            ),
          ),
          border: Border.all(
            color: isMe
                ? Colors.transparent
                : Colors.white
                    .withOpacity(.07),
          ),
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Text(
              msg['username'] ??
                  'unknown',
              style: TextStyle(
                color: isMe
                    ? white
                    : gold,
                fontSize: 10,
                fontWeight:
                    FontWeight.w800,
              ),
            ),

            const SizedBox(height: 4),

            Text(
              msg['message'] ?? '',
              style:
                  const TextStyle(
                color: white,
                fontSize: 13,
                height: 1.35,
              ),
            ),

            const SizedBox(height: 5),

            Text(
              _formatChatTime(
                msg['time'],
              ),
              style: TextStyle(
                color:
                    white.withOpacity(.5),
                fontSize: 8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatInput() {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        14,
        10,
        14,
        12,
      ),
      decoration: BoxDecoration(
        color:
            const Color(0xCC080C13),
        border: Border(
          top: BorderSide(
            color:
                Colors.white.withOpacity(
              .06,
            ),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 16,
              ),
              decoration:
                  BoxDecoration(
                color:
                    Colors.white.withOpacity(
                  .035,
                ),
                borderRadius:
                    BorderRadius.circular(
                  25,
                ),
                border: Border.all(
                  color:
                      blue.withOpacity(.18),
                ),
              ),
              child: TextField(
                controller:
                    _chatInputController,
                style:
                    const TextStyle(
                  color: white,
                  fontSize: 13,
                ),
                decoration:
                    const InputDecoration(
                  hintText:
                      "Ketik pesan...",
                  hintStyle:
                      TextStyle(
                    color: grey2,
                    fontSize: 12,
                  ),
                  border:
                      InputBorder.none,
                ),
                onSubmitted:
                    _sendChatMessage,
              ),
            ),
          ),

          const SizedBox(width: 9),

          GestureDetector(
            onTap: () {
              _sendChatMessage(
                _chatInputController
                    .text,
              );
            },
            child: Container(
              width: 45,
              height: 45,
              decoration:
                  BoxDecoration(
                gradient:
                    goldGradient,
                shape:
                    BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color:
                        gold.withOpacity(
                      .2,
                    ),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: const Icon(
                Icons
                    .arrow_upward_rounded,
                color: primaryDark,
                size: 21,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _onBottomNavTapped(
    int index,
  ) {
    setState(() {
      _bottomNavIndex = index;

      if (index == 0) {
        _selectedPage =
            _buildHomePage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage =
            InfoPage(
          sessionKey: sessionKey,
        );
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      } else if (index == 4) {
        _selectedPage =
            _buildGlobalChatPage();

        _requestOnlineUsersList();
      }
    });

    _animationController
        .forward(from: 0);
  }

  // ============================================================
  // DRAWER
  // ============================================================

  void _onSidebarTabSelected(
    int index,
  ) {
    Navigator.pop(context);

    Future.delayed(
      const Duration(
        milliseconds: 150,
      ),
      () {
        if (!mounted) return;

        setState(() {
          if (index == 1) {
            _selectedPage =
                SellerPage(
              keyToken: sessionKey,
            );
          } else if (index == 2) {
            _selectedPage =
                AdminPage(
              sessionKey: sessionKey,
            );
          } else if (index == 3) {
            _selectedPage =
                OwnerPage(
              sessionKey: sessionKey,
              username: username,
            );
          }
        });

        _animationController
            .forward(from: 0);
      },
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      width:
          MediaQuery.of(context)
                  .size
                  .width *
              .86,
      backgroundColor:
          backgroundDark,
      child: Column(
        children: [
          _buildDrawerHeader(),

          Expanded(
            child: ListView(
              padding:
                  const EdgeInsets.fromLTRB(
                14,
                18,
                14,
                20,
              ),
              children: [
                if (role == "reseller")
                  _buildDrawerItem(
                    icon:
                        Icons.storefront_rounded,
                    label:
                        "Seller Page",
                    onTap: () =>
                        _onSidebarTabSelected(
                      1,
                    ),
                  ),

                if (role == "admin")
                  _buildDrawerItem(
                    icon: Icons
                        .admin_panel_settings_rounded,
                    label:
                        "Admin Page",
                    onTap: () =>
                        _onSidebarTabSelected(
                      2,
                    ),
                  ),

                if (role == "owner" ||
                    role == "pemilik")
                  _buildDrawerItem(
                    icon: Icons
                        .workspace_premium_rounded,
                    label:
                        "Owner Page",
                    onTap: () =>
                        _onSidebarTabSelected(
                      3,
                    ),
                  ),

                _buildDrawerItem(
                  icon:
                      Icons.history_rounded,
                  label:
                      "Riwayat Aktivitas",
                  onTap: () {
                    Navigator.pop(
                      context,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) =>
                                RiwayatPage(
                          sessionKey:
                              sessionKey,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),

                _buildDrawerItem(
                  icon:
                      Icons.send_rounded,
                  label:
                      "Manage Sender",
                  onTap: () {
                    Navigator.pop(
                      context,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) =>
                                BugSenderPage(
                          sessionKey:
                              sessionKey,
                          username:
                              username,
                          role: role,
                        ),
                      ),
                    );
                  },
                ),

                _buildDrawerItem(
                  icon: Icons
                      .shopping_bag_rounded,
                  label: "Toko",
                  onTap: () {
                    Navigator.pop(
                      context,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) =>
                                const TokoPage(),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 12),

                Container(
                  height: 1,
                  color:
                      Colors.white
                          .withOpacity(.06),
                ),

                const SizedBox(height: 12),

                _buildDrawerItem(
                  icon: Icons
                      .phone_android_rounded,
                  label:
                      "Device Info",
                  onTap: () {
                    Navigator.pop(
                      context,
                    );

                    _showDeviceInfo();
                  },
                ),

                _buildDrawerItem(
                  icon: Icons
                      .layers_rounded,
                  label:
                      "Floating Bagger",
                  onTap: () {
                    Navigator.pop(
                      context,
                    );

                    _showFeatureInfo(
                      "Floating Bagger",
                    );
                  },
                ),

                const SizedBox(height: 20),

                _buildDrawerLogout(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerHeader() {
    return Container(
      height: 285,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFF1B2638),
            Color(0xFF0A0D13),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border(
          bottom: BorderSide(
            color:
                gold.withOpacity(.15),
          ),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding:
              const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              _buildGlowingAvatar(),

              const SizedBox(height: 15),

              Text(
                username,
                maxLines: 1,
                overflow:
                    TextOverflow.ellipsis,
                style: const TextStyle(
                  color: white,
                  fontSize: 20,
                  fontWeight:
                      FontWeight.w900,
                ),
              ),

              const SizedBox(height: 8),

              Row(
                children: [
                  _drawerInfoChip(
                    role.toUpperCase(),
                    blue,
                  ),
                  const SizedBox(width: 7),
                  _drawerInfoChip(
                    "ACTIVE",
                    gold,
                  ),
                ],
              ),

              const SizedBox(height: 10),

              Row(
                children: [
                  const Icon(
                    Icons.event_rounded,
                    color: grey,
                    size: 14,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "Expired: $expiredDate",
                    style:
                        const TextStyle(
                      color: grey,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _drawerInfoChip(
    String text,
    Color color,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color:
            color.withOpacity(.08),
        borderRadius:
            BorderRadius.circular(20),
        border: Border.all(
          color:
              color.withOpacity(.2),
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 8,
          fontWeight:
              FontWeight.w800,
          letterSpacing: .7,
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin:
          const EdgeInsets.only(
        bottom: 6,
      ),
      decoration: BoxDecoration(
        color:
            Colors.white.withOpacity(
          .025,
        ),
        borderRadius:
            BorderRadius.circular(16),
        border: Border.all(
          color:
              Colors.white.withOpacity(
            .045,
          ),
        ),
      ),
      child: ListTile(
        onTap: onTap,
        dense: true,
        leading: Container(
          width: 39,
          height: 39,
          decoration: BoxDecoration(
            color:
                Colors.white.withOpacity(
              .035,
            ),
            borderRadius:
                BorderRadius.circular(
              12,
            ),
          ),
          child: Icon(
            icon,
            color: grey,
            size: 19,
          ),
        ),
        title: Text(
          label,
          style: const TextStyle(
            color: white,
            fontSize: 13,
            fontWeight:
                FontWeight.w600,
          ),
        ),
        trailing: const Icon(
          Icons
              .chevron_right_rounded,
          color: grey2,
          size: 19,
        ),
      ),
    );
  }

  Widget _buildDrawerLogout() {
    return Container(
      decoration: BoxDecoration(
        color:
            const Color(0xFFE53935)
                .withOpacity(.07),
        borderRadius:
            BorderRadius.circular(16),
        border: Border.all(
          color:
              const Color(0xFFE53935)
                  .withOpacity(.15),
        ),
      ),
      child: ListTile(
        leading: Container(
          width: 39,
          height: 39,
          decoration: BoxDecoration(
            color:
                const Color(0xFFE53935)
                    .withOpacity(.1),
            borderRadius:
                BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.logout_rounded,
            color:
                Color(0xFFFF5C5C),
            size: 19,
          ),
        ),
        title: const Text(
          "Log Out",
          style: TextStyle(
            color:
                Color(0xFFFF5C5C),
            fontSize: 13,
            fontWeight:
                FontWeight.w700,
          ),
        ),
        onTap: () async {
          Navigator.pop(
            context,
          );

          final prefs =
              await SharedPreferences
                  .getInstance();

          await prefs.clear();

          if (!mounted) return;

          Navigator.of(context)
              .pushAndRemoveUntil(
            MaterialPageRoute(
              builder: (context) =>
                  const LoginPage(),
            ),
            (route) => false,
          );
        },
      ),
    );
  }

  // ============================================================
  // EXTRA INFO
  // ============================================================

  void _showDeviceInfo() {
    showModalBottomSheet(
      context: context,
      backgroundColor:
          Colors.transparent,
      isScrollControlled: true,
      builder: (_) {
        return _glassContainer(
          radius: 26,
          padding:
              const EdgeInsets.all(22),
          color:
              const Color(0xF20A0F17),
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              const Text(
                "DEVICE INFORMATION",
                style: TextStyle(
                  color: gold,
                  fontSize: 17,
                  fontWeight:
                      FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 18),
              _infoRow(
                "Device",
                _deviceModel,
              ),
              _infoRow(
                "Android",
                _androidVersion,
              ),
              _infoRow(
                "RAM",
                _ramInfo,
              ),
              _infoRow(
                "Storage",
                _storageInfo,
              ),
              _infoRow(
                "Network",
                _networkInfo,
              ),
              _infoRow(
                "Battery",
                "${_batteryLevel}%"
                "${_isCharging ? ' • Charging' : ''}",
              ),
              _infoRow(
                "Android ID",
                androidId,
              ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Widget _infoRow(
    String label,
    String value,
  ) {
    return Padding(
      padding:
          const EdgeInsets.only(
        bottom: 11,
      ),
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style:
                  const TextStyle(
                color: grey2,
                fontSize: 10,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style:
                  const TextStyle(
                color: white,
                fontSize: 10,
                fontWeight:
                    FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showFeatureInfo(
    String title,
  ) {
    showDialog(
      context: context,
      builder: (_) {
        return Dialog(
          backgroundColor:
              Colors.transparent,
          child: _glassContainer(
            radius: 22,
            child: Column(
              mainAxisSize:
                  MainAxisSize.min,
              children: [
                const Icon(
                  Icons
                      .layers_rounded,
                  color: gold,
                  size: 40,
                ),
                const SizedBox(
                  height: 14,
                ),
                Text(
                  title,
                  style:
                      const TextStyle(
                    color: white,
                    fontSize: 17,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                const Text(
                  "Fitur Floating Bagger tetap menggunakan mekanisme yang sudah ada pada project.",
                  textAlign:
                      TextAlign.center,
                  style:
                      TextStyle(
                    color: grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
                const SizedBox(
                  height: 18,
                ),
                TextButton(
                  onPressed: () =>
                      Navigator.pop(
                    context,
                  ),
                  child: const Text(
                    "TUTUP",
                    style:
                        TextStyle(
                      color: gold,
                      fontWeight:
                          FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // URL
  // ============================================================

  Future<void> _openUrl(
    String url,
  ) async {
    final Uri uri =
        Uri.parse(url);

    if (!await launchUrl(
      uri,
      mode:
          LaunchMode.externalApplication,
    )) {
      throw Exception(
        "Could not launch $uri",
      );
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          backgroundDark,

      extendBody: true,

      appBar: AppBar(
        backgroundColor:
            Colors.transparent,
        elevation: 0,
        centerTitle: true,

        iconTheme:
            const IconThemeData(
          color: white,
        ),

        title: Container(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 17,
            vertical: 8,
          ),
          decoration: BoxDecoration(
            color:
                Colors.white.withOpacity(
              .045,
            ),
            borderRadius:
                BorderRadius.circular(
              25,
            ),
            border: Border.all(
              color:
                  gold.withOpacity(.18),
            ),
          ),
          child: ShaderMask(
            shaderCallback:
                (bounds) {
              return goldGradient
                  .createShader(
                bounds,
              );
            },
            child: const Text(
              "NECROBYTE",
              style: TextStyle(
                color: white,
                fontWeight:
                    FontWeight.w900,
                fontSize: 13,
                letterSpacing: 1.7,
              ),
            ),
          ),
        ),

        actions: [
          _appBarButton(
            Icons
                .headset_mic_rounded,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (context) =>
                          const ContactPage(),
                ),
              );
            },
          ),

          const SizedBox(width: 5),

          _appBarButton(
            FontAwesomeIcons
                .circleUser,
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (context) =>
                          ProfilePage(
                    username:
                        username,
                    password:
                        password,
                    role: role,
                    expiredDate:
                        expiredDate,
                    sessionKey:
                        sessionKey,
                  ),
                ),
              );
            },
          ),

          const SizedBox(width: 8),
        ],
      ),

      drawer:
          _buildCustomDrawer(),

      body: Container(
        decoration:
            const BoxDecoration(
          gradient: RadialGradient(
            center:
                Alignment.topLeft,
            radius: 1.4,
            colors: [
              Color(0xFF111E30),
              backgroundDark,
              primaryDark,
            ],
            stops: [
              0.0,
              .45,
              1.0,
            ],
          ),
        ),
        child: CustomPaint(
          painter:
              _GridPainter(),
          child: SafeArea(
            top: false,
            child: FadeTransition(
              opacity:
                  _fadeAnimation,
              child:
                  SlideTransition(
                position:
                    _slideAnimation,
                child:
                    _selectedPage,
              ),
            ),
          ),
        ),
      ),

      bottomNavigationBar:
          _buildBottomNavigation(),
    );
  }

  Widget _appBarButton(
    IconData icon,
    VoidCallback onTap,
  ) {
    return Container(
      margin:
          const EdgeInsets.symmetric(
        vertical: 7,
      ),
      decoration:
          BoxDecoration(
        color:
            Colors.white.withOpacity(
          .035,
        ),
        borderRadius:
            BorderRadius.circular(13),
        border: Border.all(
          color:
              Colors.white.withOpacity(
            .06,
          ),
        ),
      ),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(
          icon,
          color: gold,
          size: 19,
        ),
      ),
    );
  }

  // ============================================================
  // BOTTOM NAV
  // ============================================================

  Widget _buildBottomNavigation() {
    final items = [
      (
        Icons.dashboard_rounded,
        "Home",
      ),
      (
        FontAwesomeIcons.whatsapp,
        "WhatsApp",
      ),
      (
        Icons.notifications_active_rounded,
        "Info",
      ),
      (
        Icons.build_rounded,
        "Tools",
      ),
      (
        Icons.chat_bubble_rounded,
        "Chat",
      ),
    ];

    return Container(
      margin:
          const EdgeInsets.fromLTRB(
        12,
        0,
        12,
        10,
      ),
      padding:
          const EdgeInsets.symmetric(
        horizontal: 5,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color:
            const Color(0xE6111721),
        borderRadius:
            BorderRadius.circular(24),
        border: Border.all(
          color:
              Colors.white.withOpacity(
            .08,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color:
                Colors.black.withOpacity(
              .35,
            ),
            blurRadius: 25,
            offset:
                const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: List.generate(
          items.length,
          (index) {
            final active =
                _bottomNavIndex ==
                    index;

            return Expanded(
              child: GestureDetector(
                onTap: () =>
                    _onBottomNavTapped(
                  index,
                ),
                child:
                    AnimatedContainer(
                  duration:
                      const Duration(
                    milliseconds:
                        220,
                  ),
                  curve:
                      Curves.easeOut,
                  padding:
                      const EdgeInsets
                          .symmetric(
                    vertical: 7,
                  ),
                  decoration:
                      BoxDecoration(
                    color: active
                        ? gold.withOpacity(
                            .10,
                          )
                        : Colors
                            .transparent,
                    borderRadius:
                        BorderRadius
                            .circular(
                      18,
                    ),
                    border: active
                        ? Border.all(
                            color: gold
                                .withOpacity(
                              .16,
                            ),
                          )
                        : null,
                  ),
                  child:
                      TweenAnimationBuilder<
                          double>(
                    duration:
                        const Duration(
                      milliseconds:
                          220,
                    ),
                    tween:
                        Tween(
                      begin:
                          active
                              ? .88
                              : .78,
                      end: active
                          ? 1
                          : .88,
                    ),
                    builder:
                        (
                      context,
                      scale,
                      child,
                    ) {
                      return Transform
                          .scale(
                        scale: scale,
                        child: child,
                      );
                    },
                    child: Column(
                      mainAxisSize:
                          MainAxisSize.min,
                      children: [
                        Icon(
                          items[index]
                              .$1,
                          color: active
                              ? gold
                              : grey2,
                          size:
                              active
                                  ? 20
                                  : 18,
                        ),
                        const SizedBox(
                          height: 3,
                        ),
                        Text(
                          items[index]
                              .$2,
                          style:
                              TextStyle(
                            color: active
                                ? gold
                                : grey2,
                            fontSize: 8,
                            fontWeight:
                                active
                                    ? FontWeight
                                        .w800
                                    : FontWeight
                                        .w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _statsTimer?.cancel();
    _onlineTimer?.cancel();
    _clockTimer?.cancel();

    _channel?.sink.close(
      status.goingAway,
    );

    _animationController.dispose();

    _chatInputController.dispose();
    _chatScrollController.dispose();

    super.dispose();
  }
}

// ================================================================
// QUICK ACTION MODEL
// ================================================================

class _QuickActionData {
  final IconData icon;
  final String title;
  final String subtitle;
  final List<Color> colors;
  final VoidCallback onTap;

  const _QuickActionData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.colors,
    required this.onTap,
  });
}

// ================================================================
// GRID PAINTER
// ================================================================

class _GridPainter
    extends CustomPainter {
  static const Color blue =
      Color(0xFF4A9EFF);

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color =
          Colors.white.withOpacity(.018)
      ..strokeWidth = .7
      ..style =
          PaintingStyle.stroke;

    const gridSize = 30.0;

    for (
      double x = 0;
      x <= size.width;
      x += gridSize
    ) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        paint,
      );
    }

    for (
      double y = 0;
      y <= size.height;
      y += gridSize
    ) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        paint,
      );
    }

    final accentPaint = Paint()
      ..color =
          blue.withOpacity(.035)
      ..strokeWidth = 1.2
      ..style =
          PaintingStyle.stroke;

    for (
      double x = 0;
      x <= size.width;
      x += gridSize * 5
    ) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        accentPaint,
      );
    }

    for (
      double y = 0;
      y <= size.height;
      y += gridSize * 5
    ) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        accentPaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant CustomPainter oldDelegate,
  ) {
    return false;
  }
}