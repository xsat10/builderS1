import 'dart:convert';
import 'dart:core';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:chewie/chewie.dart';
import 'spotify.dart';
import 'surat.dart'; 
import 'media/xneuron_chat.dart';
import 'media/games_menu.dart'; 
import 'media/donghua.dart';
import 'media/animek.dart';
import 'media/hentai.dart';
import 'media/music.dart';
import 'media/comic.dart';
import 'infoh.dart';
import 'up_role.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'contact_page.dart';
import 'jadwal_sholat.dart';
import 'package:http/http.dart' as http;
import 'dart:ui' as ui; 
import 'package:cached_network_image/cached_network_image.dart';
import 'package:video_player/video_player.dart';
import 'bugs/bug_sender.dart';
import 'manager/admin_page.dart';
import 'bugs/home_page.dart';
import 'info/tqto.dart';
import 'info/info.dart';
import 'riwayat_page.dart';
import 'manager/change_password_page.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'dart:io';
import 'info/chat.dart';
import 'tools/load_tools.dart';
import 'login_page.dart';
import 'bugs/ddos_panel.dart';
import 'floating/floating_bug.dart';
import 'floating/floating_bagger.dart';

// ==================== KONSTANTA WARNA GLOBAL ====================
const Color kCard = Color(0xFF1A1A1A);
const Color kBorder = Color(0xFF333333);
const Color kGray = Color(0xFF9CA3AF);
const Color _greenSoft = Color(0xFF3CB371);
const Color kGrayLight = Color(0xFFD1D5DB);
const Color kGrayDark = Color(0xFF4B5563);
const Color kWhite = Color(0xFFFFFFFF);
const Color kWhite54 = Color(0x8AFFFFFF);
const Color kCardNews = Color(0xFF1A1A1A);
const Color kCardAltNews = Color(0xFF252525);
const Color kBorderNews = Color(0xFF333333);

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;
  String? sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  List<Map<String, dynamic>> _activityLogs = [];
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  int _selectedTabIndex = 0;
  Widget _selectedPage = const Center(child: CircularProgressIndicator());
  int totalUsers = 0;
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  
  final Color darkRed = const Color(0xFF616161);
  final Color primaryDark = const Color(0xFF121212);
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color cardDarker = const Color(0xFF0D0D0D);
  final Color darkCardLighter = const Color(0xFF2A2A2A);
  final Color textSecondary = const Color(0xFF9CA3AF);
  final Color accentGrey = const Color(0xFF666666);
  final Color goldColor = const Color(0xFFFF1744);
  final Color accentRead = const Color(0xFFDC143C);
  final Color blueColor = const Color(0xFF4A9EFF);
  final Color accentRed = const Color(0xFFBDBDBD);
  
  late ChewieController _chewieController;
  late VideoPlayerController _videoController;
  
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;
  
  bool isLoadingUsers = true;
  bool senderConnected = false;
  bool _isVideoInitialized = false;
  bool _isLoadingKey = false;
  bool _isFloatingBaggerActive = false;
  bool _isLoadingWeather = true;
  bool _hasWeatherError = false;
  String _weatherCity = "Jakarta";
  String _weatherTemperature = "--";
  String _weatherCondition = "Loading...";
  String _weatherIcon = "🌤️";
  int _weatherHumidity = 0;
  double _weatherWindSpeed = 0;
  int _weatherPressure = 0;
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;
  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = false;
  int _lastHadithNumber = 0;

  String baseUrl = "";
  String _selectedCity = "Jakarta";
  double _cityLat = -6.2088;
  double _cityLon = 106.8456;
  String _getWeatherCondition(int code) {
  switch (code) {
    case 0: return 'Cerah';
    case 1: case 2: case 3: return 'Berawan';
    case 45: case 48: return 'Kabut';
    case 51: case 53: case 55: return 'Gerimis';
    case 61: case 63: case 65: return 'Hujan';
    case 71: case 73: case 75: return 'Salju';
    case 80: case 81: case 82: return 'Hujan Deras';
    case 95: case 96: case 99: return 'Badai Petir';
    default: return 'Cerah Berawan';
  }
}

String _getWeatherIconFromCode(int code) {
  switch (code) {
    case 0: return '☀️';
    case 1: case 2: case 3: return '⛅';
    case 45: case 48: return '🌫️';
    case 51: case 53: case 55: return '🌦️';
    case 61: case 63: case 65: return '🌧️';
    case 71: case 73: case 75: return '❄️';
    case 80: case 81: case 82: return '⛈️';
    case 95: case 96: case 99: return '⛈️';
    default: return '🌤️';
  }
}

  @override
  void initState() {
    super.initState();    
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    
    _loadConfigAndInit();
    _setFallbackHadith();
    _requestNotificationPermission();
    _initNotifications();
    _fetchNews();
    _fetchActivityLogs();
    _fetchWeather();
    _activityLogs = [
    {'activity': 'Login', 'timestamp': DateTime.now().toIso8601String(), 'details': {'target': 'Dashboard'}},
    {'activity': 'Welcome', 'timestamp': DateTime.now().toIso8601String(), 'details': {'target': 'STUX01'}},
  ];
    Timer.periodic(const Duration(minutes: 10), (timer) {
  if (mounted) {
    _fetchWeather();
  }
});

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    _selectedPage = const Center(child: CircularProgressIndicator());
  }
  
  // Daftar kota
final List<Map<String, dynamic>> _cities = [
  {'name': 'Jakarta', 'lat': -6.2088, 'lon': 106.8456},
  {'name': 'Surabaya', 'lat': -7.2575, 'lon': 112.7521},
  {'name': 'Bandung', 'lat': -6.9175, 'lon': 107.6191},
  {'name': 'Medan', 'lat': 3.5952, 'lon': 98.6722},
  {'name': 'Makassar', 'lat': -5.1477, 'lon': 119.4327},
  {'name': 'Semarang', 'lat': -6.9667, 'lon': 110.4167},
  {'name': 'Yogyakarta', 'lat': -7.7956, 'lon': 110.3695},
  {'name': 'Bali', 'lat': -8.3405, 'lon': 115.0920},
  {'name': 'Palembang', 'lat': -2.9761, 'lon': 104.7754},
  {'name': 'Balikpapan', 'lat': -1.2379, 'lon': 116.8529},
];
  
// Tambahkan method ini juga

Color _getActivityColor(String activity) {
  switch (activity.toLowerCase()) {
    case 'login':
      return Colors.green;
    case 'logout':
      return Colors.red;
    case 'send_bug':
      return Colors.orange;
    case 'raid_group':
      return Colors.purple;
    case 'create_account':
      return Colors.blue;
    case 'login_failed':
      return Colors.red;
    default:
      return Colors.grey;
  }
}

IconData _getActivityIcon(String activity) {
  switch (activity.toLowerCase()) {
    case 'login':
      return Icons.login_rounded;
    case 'logout':
      return Icons.logout_rounded;
    case 'send_bug':
      return Icons.send_rounded;
    case 'raid_group':
      return Icons.group_rounded;
    case 'create_account':
      return Icons.person_add_rounded;
    case 'login_failed':
      return Icons.error_rounded;
    default:
      return Icons.circle_rounded;
  }
}

String _formatDateTime(DateTime date) {
  final now = DateTime.now();
  final difference = now.difference(date);

  if (difference.inDays > 0) {
    return DateFormat('dd/MM HH:mm').format(date);
  } else if (difference.inHours > 0) {
    return '${difference.inHours}h ago';
  } else if (difference.inMinutes > 0) {
    return '${difference.inMinutes}m ago';
  } else {
    return 'Just now';
  }
}

// ── UBAH _fetchRandomHadith ──
Future<void> _fetchRandomHadith() async {
  setState(() => _hadithLoading = true);
  
  try {
    final response = await http.get(
      Uri.parse("https://api.hadith.sutanlab.id/books/muslim/random"),
    ).timeout(const Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _hadith = data;
        _hadithLoading = false;
      });
    } else {
      _setFallbackHadith();
    }
  } catch (e) {
    debugPrint('Error fetch hadith: $e');
    _setFallbackHadith();
  }
}

// ── TAMBAHKAN METHOD FALLBACK ──
void _setFallbackHadith() {
  setState(() {
    _hadith = {
      'data': {
        'text': {
          'ar': 'لا تتركوا صلواتكم واحفظوها، فإذا ضاعت صلواتكم، ستفقدون كل شيء.',
          'id': 'Jangan lah engkau tinggalkan sholat mu dan jagalah sholat mu, ketika kamu kehilangan sholat, kamu akan kehilangan segalanya.'
        },
        'id': 1,
        'source': 'Muslim',
        'grade': 'Sahih Muslim'
      }
    };
    _hadithLoading = false;
  });
}
  
    
Future<void> _fetchActivityLogs() async {
  // JANGAN LOADING LAMA, LANGSUNG TAMPILIN DUMMY DULU
  if (_activityLogs.isEmpty) {
    setState(() {
      _activityLogs = [
        {'activity': 'Welcome', 'timestamp': DateTime.now().toIso8601String(), 'details': {'target': 'STUX01'}},
      ];
    });
  }

  setState(() {
    _isLoadingActivityLogs = true;
    _hasActivityLogsError = false;
  });

  try {
    final response = await http.get(
      Uri.parse('$baseUrl/getActivityLogs?key=$sessionKey&limit=10'),
    ).timeout(const Duration(seconds: 5)); // TIMEOUT 5 DETIK

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['valid'] == true && data['logs'] != null) {
        final logs = data['logs'];
        if (logs.isNotEmpty) {
          setState(() {
            _activityLogs = List<Map<String, dynamic>>.from(logs);
            _isLoadingActivityLogs = false;
          });
        } else {
          setState(() {
            _isLoadingActivityLogs = false;
          });
        }
      } else {
        setState(() {
          _isLoadingActivityLogs = false;
        });
      }
    } else {
      setState(() {
        _isLoadingActivityLogs = false;
      });
    }
  } catch (e) {
    // KALAU ERROR, TETAP TAMPILIN DUMMY
    setState(() {
      _isLoadingActivityLogs = false;
      _hasActivityLogsError = false; // JANGAN TAMPILIN ERROR
    });
  }
}
  
  // ── FETCH NEWS ──
  Future<void> _fetchNews() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/news"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['news'] != null) {
          setState(() {
            newsList = data['news'];
          });
          return;
        }
      }
    } catch (e) {
      debugPrint('Error fetching news: $e');
    }
  }
  
  Future<void> _requestNotificationPermission() async {
  if (await Permission.notification.isDenied) {
    await Permission.notification.request();
  }
}

Future<void> _initNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  
  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
  );
  
  await _notifications.initialize(initializationSettings);
}

Future<void> _showNotification(String title, String body) async {
  const AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
        'STUX01',
        'STUX01 Notifikasi',
        channelDescription: 'Notifikasi dari STUX01 Apps',
        importance: Importance.max,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
      );
  
  const NotificationDetails platformChannelSpecifics = NotificationDetails(
    android: androidPlatformChannelSpecifics,
  );
  
  await _notifications.show(0, title, body, platformChannelSpecifics);
}

Future<void> _checkNotifications() async {
  print('📢 _checkNotifications() dipanggil');
  print('📢 sessionKey: $sessionKey');
  
  if (sessionKey == null) {
    print('❌ sessionKey null, skip');
    return;
  }
  
  try {
    final url = '$baseUrl/getNotifications?key=$sessionKey';
    print('📢 URL: $url');
    
    final response = await http.get(Uri.parse(url));
    print('📢 Response status: ${response.statusCode}');
    print('📢 Response body: ${response.body}');
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      print('📢 Data: $data');
      
      if (data['valid'] == true && data['notifications'] != null) {
        final notifs = data['notifications'];
        print('📢 Jumlah notif: ${notifs.length}');
        
        if (notifs.isNotEmpty) {
          final latest = notifs[0];
          print('📢 Menampilkan: ${latest['title']} - ${latest['body']}');
          _showNotification(latest['title'], latest['body']);
        } else {
          print('📢 Tidak ada notifikasi');
        }
      }
    }
  } catch (e) {
    print('❌ Error: $e');
  }
}
  
  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse("https://raw.githubusercontent.com/seishiro9/server1/refs/heads/main/srv1.json"));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }
  
  Future<void> _loadConfigAndInit() async {
    await _loadConfig();
    await _initAndroidIdAndConnect();
    await _initializeVideoPlayer();
    await _getSessionKey();
    await _checkFloatingBaggerStatus();
    
    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (sessionKey != null && mounted) {
        checkSenderStatus();
      }
    });
  }
  
  Future<void> _checkFloatingBaggerStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isFloatingBaggerActive = prefs.getBool('floating_bagger_running') ?? false;
    });
  }

  Future<void> fetchTotalUsers() async {
    if (sessionKey == null) return;
    
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/listUsers?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['valid'] == true && data['users'] != null) {
          List<dynamic> users = data['users'];
          setState(() {
            totalUsers = users.length;
            isLoadingUsers = false;
          });
        } else {
          setState(() => isLoadingUsers = false);
        }
      } else {
        setState(() => isLoadingUsers = false);
      }
    } catch (e) {
      print('Error fetch users: $e');
      setState(() => isLoadingUsers = false);
    }
  }
  
  
Future<void> _fetchWeather() async {
  setState(() {
    _isLoadingWeather = true;
    _hasWeatherError = false;
  });

  try {
    final response = await http.get(
      Uri.parse(
        "https://api.open-meteo.com/v1/forecast?latitude=${_cityLat}&longitude=${_cityLon}&current_weather=true&timezone=auto"
      ),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final current = data['current_weather'];

      setState(() {
        _weatherCity = _selectedCity;
        _weatherTemperature = "${current['temperature'].round()}°C";
        _weatherCondition = _getWeatherCondition(current['weathercode']);
        _weatherIcon = _getWeatherIconFromCode(current['weathercode']);
        _weatherHumidity = 65;
        _weatherWindSpeed = current['windspeed'] ?? 0;
        _weatherPressure = 1013;
        _isLoadingWeather = false;
      });
    } else {
      _setFallbackWeather(_selectedCity);
    }
  } catch (e) {
    debugPrint('Weather fetch error: $e');
    _setFallbackWeather(_selectedCity);
  }
}

void _setFallbackWeather(String city) {
  setState(() {
    _weatherCity = city;
    _weatherTemperature = "28°C";
    _weatherCondition = "Cerah Berawan";
    _weatherIcon = "🌤️";
    _weatherHumidity = 65;
    _weatherWindSpeed = 12.5;
    _weatherPressure = 1013;
    _isLoadingWeather = false;
  });
}

void _openGames(BuildContext context) {
  _showCustomSheet(
    context,
    title: "Games & Puzzle",
    titleIcon: Icons.games_rounded,
    titleColor: _greenSoft,
    items: [
      _SheetItemData(  // ✅ Tambah const
        icon: Icons.extension,
        iconColor: Colors.orange,
        title: "Puzzle Game",
        subtitle: "Susun gambar menjadi utuh.",
        onTap: _navigateToPuzzle,  // ✅ Pindahkan ke method terpisah
      ),
      _SheetItemData(
        icon: Icons.quiz,
        iconColor: Colors.purple,
        title: "Teka Teki",
        subtitle: "Tebak kata & logika.",
        onTap: _navigateToTekaTeki,
      ),
      _SheetItemData(
        icon: Icons.psychology,
        iconColor: Colors.cyan,
        title: "Tes IQ",
        subtitle: "Uji kecerdasan Anda.",
        onTap: _navigateToIQTest,
      ),
      _SheetItemData(
        icon: Icons.grid_on,
        iconColor: Colors.green,
        title: "Ular Tangga",
        subtitle: "Game klasik ular tangga.",
        onTap: _navigateToUlarTangga,
      ),
      _SheetItemData(
        icon: Icons.extension,
        iconColor: Colors.deepPurple,
        title: "Memecahkan Misteri",
        subtitle: "Selesaikan kasus detektif.",
        onTap: _navigateToMystery,
      ),
      _SheetItemData(
        icon: Icons.games,
        iconColor: Colors.amber,
        title: "Catur",
        subtitle: "Main catur dengan 3 level kesulitan",
        onTap: _navigateToChess,
      ),
      _SheetItemData(
        icon: Icons.text_fields,
        iconColor: Colors.lightBlue,
        title: "Tebak Kata",
        subtitle: "Sambung atau tebak kata yang benar",
        onTap: _navigateToWordGame,
      ),
      _SheetItemData(
        icon: Icons.grid_on,
        iconColor: Colors.purple,
        title: "Teka Teki Silang",
        subtitle: "Isi teka‑teki silang",
        onTap: _navigateToCrossword,
      ),
      _SheetItemData(
        icon: Icons.code,
        iconColor: Colors.green,
        title: "Kuis Pemrograman",
        subtitle: "Pilih kategori: JavaScript, HTML, Python",
        onTap: _navigateToProgrammingQuiz,
      ),
    ],
  );
}

// ✅ TAMBAHKAN METHOD NAVIGASI
void _navigateToPuzzle(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const PuzzleGame()));
}

void _navigateToTekaTeki(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const TekaTekiGame()));
}

void _navigateToIQTest(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const IQTestGame()));
}

void _navigateToUlarTangga(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const UlarTanggaGame()));
}

void _navigateToMystery(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const MysteryGame()));
}

void _navigateToChess(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ChessGame()));
}

void _navigateToWordGame(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const WordGame()));
}

void _navigateToCrossword(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const CrosswordGame()));
}

void _navigateToProgrammingQuiz(BuildContext ctx) {
  Navigator.pop(ctx);
  Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ProgrammingQuiz()));
}

  Future<void> _getSessionKey() async {
    setState(() {
      _isLoadingKey = true;
    });

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/getKey?username=${widget.username}"),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          if (!mounted) return;

          sessionKey = data['key'];

          await checkSenderStatus(); 
          await _checkNotifications();
          await fetchTotalUsers();

          setState(() {
            _isLoadingKey = false;
            _selectedPage = _buildNewsPage(); 
          });
        }
      } else {
        setState(() => _isLoadingKey = false);
      }
    } catch (e) {
      print("Error get session key: $e");
      setState(() => _isLoadingKey = false);
    }
  }
  
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
  }
  
  Future<void> checkSenderStatus() async {
    if (sessionKey == null || sessionKey!.isEmpty) {
      print("Session key null, skip check sender");
      return;
    }

    try {
      print("Checking sender status for key: $sessionKey");
      
      final response = await http.get(
        Uri.parse("$baseUrl/mySender?key=$sessionKey"),
      ).timeout(const Duration(seconds: 10));

      print("Response status: ${response.statusCode}");
      print("Response body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print("Parsed data: $data");

        setState(() {
          if (data['connections'] != null && data['connections'].length > 0) {
            senderConnected = true;
          } else {
            senderConnected = false;
          }
        });
        
        print("Sender connected: $senderConnected");
      } else {
        setState(() {
          senderConnected = false;
        });
      }
    } catch (e) {
      print("Error cek sender: $e");
      setState(() {
        senderConnected = false;
      });
    }
  }

  Future<void> refreshSenderStatus() async {
    await checkSenderStatus();
  }
  
  void _onTabTapped(int index) {
    if (sessionKey == null) return;

    setState(() {
      _selectedTabIndex = index;

      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } 
      else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey!,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        );
      } 
      else if (index == 2) {
        _selectedPage = InfoPage(
          sessionKey: sessionKey!,
        );
      }
      else if (index == 3) {
        _selectedPage = CommunityPage(
          username: username,
          role: role,
        );
      }
    });
  }

  void _onDrawerItemSelected(int index) {
    if (sessionKey == null) return;

    setState(() {
      if (index == 4) {
        _selectedPage = ChangePasswordPage(username: username, sessionKey: sessionKey!);
      } else if (index == 5 || index == 6) {
        _selectedPage = AdminPage(sessionKey: sessionKey!, currentUserRole: role);
      }
    });
  }

  Future<void> openLink(String url) async {
    final Uri uri = Uri.parse(url);

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $url';
    }
  }

  Future<void> _initializeVideoPlayer() async {
    Completer<void> completer = Completer<void>();
    
    try {
      _videoController = VideoPlayerController.asset(
        'assets/videos/landing.mp4',
      );
      
      await _videoController.initialize();
      
      _videoController.setVolume(0.1);
      _videoController.setLooping(true);
      _videoController.play();
      
      _chewieController = ChewieController(
        videoPlayerController: _videoController,
        autoPlay: true,
        looping: true,
        showControls: false,
        autoInitialize: true,
        errorBuilder: (context, errorMessage) {
          return Container(
            height: 280,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  darkRed.withOpacity(0.3),
                  accentRed.withOpacity(0.3)
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Icon(Icons.play_arrow, color: accentRed, size: 40),
            ),
          );
        },
      );
      
      if (mounted) {
        setState(() {
          _isVideoInitialized = true;
        });
      }
      
      completer.complete();
      
    } catch (error) {
      print("Video initialization error: $error");
      
      if (mounted) {
        setState(() {
          _isVideoInitialized = false;
        });
      }
      
      completer.completeError(error);
    }
    
    return completer.future;
  }

  // ==================== BUILD METHODS ====================
  
  Widget _buildHeaderPanel() {
    return SlideTransition(
      position: _slideAnimation,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        width: double.infinity,
        height: 280,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_isVideoInitialized)
                SizedBox(
                  width: double.infinity,
                  height: 280,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  ),
                )
              else
                Container(
                  width: double.infinity,
                  height: 280,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.grey.withOpacity(0.3),
                        Colors.grey.withOpacity(0.3)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.play_arrow, color: Colors.grey, size: 40),
                        const SizedBox(height: 8),
                        Text(
                          "Loading Video...",
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
              Container(
                width: double.infinity,
                height: 280,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(0.7),
                      Colors.transparent,
                      Colors.black.withOpacity(0.8),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
              BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FadeTransition(
                        opacity: Tween(begin: 0.6, end: 1.0)
                            .animate(_fadeController),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                Colors.grey.withOpacity(0.4),
                                Colors.grey.withOpacity(0.4)
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: const CircleAvatar(
                            radius: 40,
                            backgroundImage:
                                AssetImage('assets/images/soso.jpg'),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [Colors.grey.shade400, Colors.white],
                        ).createShader(bounds),
                        child: Text(
                          username,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.grey.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(12),
                              border:
                                  Border.all(color: Colors.grey.withOpacity(0.5)),
                            ),
                            child: Text(
                              role.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border:
                                  Border.all(color: Colors.white.withOpacity(0.3)),
                            ),
                            child: Text(
                              "Exp: $expiredDate",
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Statistics Information",
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                icon: FontAwesomeIcons.users,
                title: "Online All Users",
                value: isLoadingUsers ? "..." : totalUsers.toString(),
                color: Colors.blue,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                icon: FontAwesomeIcons.whatsapp,
                title: "Sender Connected",
                value: senderConnected ? "1" : "0",
                color: Colors.green,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    bool fullWidth = false,
  }) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, cardDarker],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: primaryDark.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

Widget _buildAccountInfo() {
  final actions = <_QuickActionData>[
    _QuickActionData(
      icon: Icons.build_circle_outlined,
      label: "Digital Tools",
      subtitle: "Show All Tools",
      gradient: const LinearGradient(colors: [Color(0xFF6A11CB), Color(0xFF9B59B6)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ToolsPage(
            sessionKey: sessionKey!,
            username: username,
            userRole: role,
          ),
        ),
      ),
    ),
    _QuickActionData(
      icon: Icons.auto_stories_rounded,
      label: "Reading Comics",
      subtitle: "Show All Comics",
      gradient: const LinearGradient(colors: [Color(0xFF0D47A1), Color(0xFF2575FC)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ComicPlayPage()),
      ),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.discord,
      label: "Anime Stream",
      subtitle: "Nonton Anime Dll",
      gradient: const LinearGradient(colors: [Color(0xFFB71C1C), Color(0xFFE53935)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => HomeAnimePage()),
      ),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.whatsapp,
      label: "Sender Manager",
      subtitle: "Add My Sender",
      gradient: const LinearGradient(colors: [Color(0xFF1DB954), Color(0xFF1ED760)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BugSenderPage(
            sessionKey: sessionKey!,
            username: username,
            role: role,
          ),
        ),
      ),
    ),
    _QuickActionData(
      icon: Icons.menu_book_rounded,
      label: "Al Qur-an",
      subtitle: "Baca Al-Quran",
      gradient: const LinearGradient(colors: [Color(0xFF616161), Color(0xFFBDBDBD)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => SurahListScreen()),
      ),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.bilibili,
      label: "Watching Donghua",
      subtitle: "Menonton Donghua",
      gradient: LinearGradient(colors: [const Color(0xFF8B0000), accentRead]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => AnPlayPage()),
      ),
    ),
    _QuickActionData(
      icon: Icons.sports_esports_rounded,
      label: "Play Games",
      subtitle: "Main Game Seru",
      gradient: const LinearGradient(colors: [Color(0xFFC2185B), Color(0xFFFF4081)]),
      onTap: () => _openGames(context),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.brain,
      label: "Ai Fixxed Code",
      subtitle: "Fix Code Memakai Ai",
      gradient: const LinearGradient(colors: [Color(0xFF00695C), Color(0xFF26A69A)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => XNeuronChatPage(sessionKey: sessionKey!),
        ),
      ),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.clapperboard,
      label: "Watching 18 Hentai Anime",
      subtitle: "Nonton Anime Hentai 18+",
      gradient: const LinearGradient(colors: [Color(0xFF996515), Color(0xFFD4AF37)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => HentaiPage()),
      ),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.music,
      label: "Music Player",
      subtitle: "Pemutar Musik",
      gradient: const LinearGradient(colors: [Color(0xFF000000), Color(0xFF444444)]),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => MusicPage()),
      ),
    ),
  ];

  return Container(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
    decoration: BoxDecoration(
      color: cardDark,
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF1D1D1D), Color(0xFF0D0D0D)],
      ),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.35),
          blurRadius: 18,
          offset: const Offset(0, 8),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: Colors.white.withOpacity(0.10)),
              ),
              child: const Icon(Icons.bolt_rounded, color: Colors.white70, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "QUICK ACTIONS",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      fontFamily: "Orbitron",
                      letterSpacing: 0.8,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    "Geser untuk melihat semua fitur",
                    style: TextStyle(color: Colors.white54, fontSize: 11),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Text(
                "${actions.length} MENU",
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 158,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: actions.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              return TweenAnimationBuilder<double>(
                duration: Duration(milliseconds: 350 + (index * 45)),
                curve: Curves.easeOutCubic,
                tween: Tween(begin: 0.88, end: 1),
                builder: (_, scale, child) => Transform.scale(
                  scale: scale,
                  alignment: Alignment.centerLeft,
                  child: child,
                ),
                child: _buildActionCard(data: actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            const Icon(Icons.swipe_rounded, color: Colors.white38, size: 15),
            const SizedBox(width: 6),
            const Expanded(
              child: Text(
                "Swipe horizontal untuk akses cepat",
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ),
            Text(
              "SMOOTH • ${actions.length} FEATURES",
              style: TextStyle(
                color: Colors.white.withOpacity(0.28),
                fontSize: 9,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

  Widget _buildActionCard({
    required _QuickActionData data,
  }) {
    return SizedBox(
      width: 190,
      height: 150,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: data.onTap,
          borderRadius: BorderRadius.circular(18),
          splashColor: Colors.white.withOpacity(0.12),
          highlightColor: Colors.white.withOpacity(0.04),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: data.gradient,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.30),
                  blurRadius: 14,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  right: -18,
                  top: -18,
                  child: Icon(
                    data.icon,
                    size: 86,
                    color: Colors.white.withOpacity(0.09),
                  ),
                ),
                Positioned(
                  right: 12,
                  bottom: 10,
                  child: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.06),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.17),
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.18),
                          ),
                        ),
                        child: Icon(data.icon, color: Colors.white, size: 22),
                      ),
                      const Spacer(),
                      Text(
                        data.label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        data.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.78),
                          fontSize: 10.5,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: 11,
                  bottom: 12,
                  child: Icon(
                    Icons.arrow_forward_rounded,
                    color: Colors.white.withOpacity(0.75),
                    size: 17,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── NEWS SECTION ──
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Icon(Icons.dashboard_customize_rounded, color: kGray, size: 22),
              const SizedBox(width: 8),
              const Text(
                'LATEST UPDATES',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kGray.withOpacity(0.15),
                    border: Border.all(color: kGray.withOpacity(0.4)),
                  ),
                  child: Text(
                    '${newsList.length} Updates',
                    style: TextStyle(
                      color: kGray,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              IconButton(
                icon: Icon(Icons.refresh_rounded, color: kGray, size: 18),
                onPressed: _fetchNews,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                splashRadius: 18,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCard(newsList[i]),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: kCardNews,
                border: Border.all(color: kBorderNews.withOpacity(0.4)),
              ),
              child: const Center(
                child: Text(
                  'No updates available',
                  style: TextStyle(color: Colors.white54),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCard(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final desc = item['desc']?.toString() ?? '';
    final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCardNews,
        border: Border.all(color: kBorderNews.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110,
                  width: double.infinity,
                  color: kCardAltNews,
                  child: imgUrl.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: imgUrl,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => Container(
                            color: kCardAltNews,
                            child: const Center(
                              child: SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  color: Color(0xFF9CA3AF),
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                          ),
                          errorWidget: (_, __, ___) => const Center(
                            child: Icon(Icons.image_not_supported, color: Colors.white54, size: 30),
                          ),
                        )
                      : const Center(
                          child: Icon(Icons.article_rounded, color: Colors.white54, size: 30),
                        ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: kGray.withOpacity(0.7)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kGray, size: 10),
                        const SizedBox(width: 3),
                        Text(
                          'NEW',
                          style: TextStyle(
                            color: kGray,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (desc.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                desc,
                style: TextStyle(
                  color: kGray,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                Icon(Icons.access_time_rounded, color: kGray, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                      date.length > 10 ? date.substring(0, 10) : date,
                      style: TextStyle(color: kGray, fontSize: 10),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: kGray.withOpacity(0.18),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: kGray,
                    size: 9,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── HADITH SECTION ──
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: const Center(child: CircularProgressIndicator(color: Color(0xFF9CA3AF), strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'لا تتركوا صلواتكم واحفظوها، فإذا ضاعت صلواتكم، ستفقدون كل شيء.';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Jangan lah tinggalkan sholat mu dan jagalah sholatmu, ketika kamu kehilangan sholat, kamu akan kehilangan segalanya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    final Color grayAccent = const Color(0xFF9CA3AF);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: grayAccent.withOpacity(0.18)),
                  child: Center(child: Icon(Icons.menu_book_rounded, color: grayAccent, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('MOTIVATIONAL QUOTES',
                        style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15,
                          fontFamily: 'Orbitron', letterSpacing: 0.5)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap card to read full',
                        style: TextStyle(color: grayAccent, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF1A1F2E),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: ui.TextDirection.rtl,
                        style: const TextStyle(color: Colors.white, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14), color: const Color(0xFF141824)),
                    child: Text(indo,
                        style: TextStyle(
                          color: grayAccent, fontSize: 12, fontStyle: FontStyle.italic, height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: grayAccent.withOpacity(0.45)),
                    color: grayAccent.withOpacity(0.07),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.receipt_long_rounded, color: grayAccent, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: TextStyle(
                            color: grayAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.white54.withOpacity(0.3)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: Colors.white54, size: 14),
                      SizedBox(width: 4),
                      Text('Tap card', style: TextStyle(color: Colors.white54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    final Color grayAccent = const Color(0xFF9CA3AF);

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, 
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: grayAccent.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: grayAccent.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: grayAccent.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, 
                        color: grayAccent.withOpacity(0.2)
                      ),
                      child: Icon(Icons.menu_book_rounded, color: grayAccent, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start, 
                        children: [
                          const Text(
                            'MOTIVATIONAL QUOTES LENGKAP',
                            style: TextStyle(
                              color: Colors.white, 
                              fontWeight: FontWeight.bold, 
                              fontSize: 14, 
                              fontFamily: 'Orbitron'
                            )
                          ),
                          Text(
                            grade, 
                            style: TextStyle(color: grayAccent, fontSize: 11)
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle, 
                          color: Colors.white.withOpacity(0.08)
                        ),
                        child: const Icon(Icons.close_rounded, color: Colors.white54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, 
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF1A1F2E),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(
                          arabic,
                          textAlign: TextAlign.right, 
                          textDirection: ui.TextDirection.rtl,
                          style: const TextStyle(
                            color: Colors.white, 
                            fontSize: 19, 
                            height: 2.2
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(
                          width: 3, 
                          height: 18,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2), 
                            color: grayAccent
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'ARTINYA:', 
                          style: TextStyle(
                            color: grayAccent, 
                            fontSize: 11, 
                            fontWeight: FontWeight.bold, 
                            letterSpacing: 1.2
                          ),
                        ),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, 
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF141824),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(
                          indo,
                          style: const TextStyle(
                            color: Colors.white, 
                            fontSize: 14, 
                            fontStyle: FontStyle.italic, 
                            height: 1.8
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: grayAccent.withOpacity(0.5)),
                          color: grayAccent.withOpacity(0.08),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min, 
                          children: [
                            Icon(Icons.receipt_long_rounded, color: grayAccent, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              '${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: TextStyle(
                                color: grayAccent, 
                                fontSize: 12, 
                                fontWeight: FontWeight.bold
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
Widget _buildWeatherCard() {
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [
          const Color(0xFF2A2A2A),
          const Color(0xFF1A1A1A),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(
        color: kGray.withOpacity(0.3),
        width: 1,
      ),
      boxShadow: [
        BoxShadow(
          color: kGray.withOpacity(0.15),
          blurRadius: 20,
          spreadRadius: 0,
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: kGray.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.wb_sunny,
                  color: kGray,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                "WEATHER",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const Spacer(),
              // 🔥 SELECT KOTA
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: kGray.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: kGray.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedCity,
                    dropdownColor: const Color(0xFF1A1A1A),
                    icon: Icon(Icons.arrow_drop_down, color: kGray, size: 20),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                    ),
onChanged: (String? newValue) async {
  if (newValue != null) {
    final city = _cities.firstWhere((c) => c['name'] == newValue);
    setState(() {
      _selectedCity = newValue;
      _cityLat = city['lat'];
      _cityLon = city['lon'];
    });
    await Future.microtask(() {});
    _fetchWeather();
  }
},
                    items: _cities.map<DropdownMenuItem<String>>((city) {
                      return DropdownMenuItem<String>(
                        value: city['name'],
                        child: Text(
                          city['name'],
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _fetchWeather,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: kGray.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.refresh,
                    color: kGray,
                    size: 14,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (_isLoadingWeather)
            _buildWeatherDummy()
          else if (_hasWeatherError)
            const Center(
              child: Text(
                "Failed to load weather",
                style: TextStyle(color: Color(0xFF9CA3AF)),
              ),
            )
          else
            Row(
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      colors: [
                        kGray.withOpacity(0.2),
                        Colors.transparent,
                      ],
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      _weatherIcon,
                      style: const TextStyle(fontSize: 48),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _weatherTemperature,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      Text(
                        _weatherCity,
                        style: TextStyle(
                          color: kGray,
                          fontSize: 14,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _weatherCondition,
                        style: TextStyle(
                          color: kGray.withOpacity(0.7),
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A3A4A),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: kGray.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.water_drop,
                            color: kGray,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "$_weatherHumidity%",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(
                            Icons.air,
                            color: kGray,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "${_weatherWindSpeed.toStringAsFixed(1)} km/h",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    ),
  );
}

// ── TAMBAHKAN METHOD INI ──
Widget _buildWeatherDummy() {
  return Row(
    children: [
      Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [
              kGray.withOpacity(0.2),
              Colors.transparent,
            ],
          ),
          shape: BoxShape.circle,
        ),
        child: const Center(child: Text("🌤️", style: TextStyle(fontSize: 48))),
      ),
      const SizedBox(width: 16),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "28°C",
              style: TextStyle(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            Text(
              "Surabaya",
              style: TextStyle(
                color: kGray,
                fontSize: 14,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "Cerah Berawan",
              style: TextStyle(
                color: kGray.withOpacity(0.7),
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF2A3A4A),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: kGray.withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.water_drop, color: kGray, size: 12),
                const SizedBox(width: 4),
                const Text(
                  "65%",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.air, color: kGray, size: 12),
                const SizedBox(width: 4),
                const Text(
                  "12.5 km/h",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ],
  );
}
  
  // ── BUILD CONNECT WITH TEAM ──
Widget buildConnectWithTeam() {
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          cardDark,
          cardDark,
          const Color(0xFF252525),
        ],
      ),
      border: Border.all(
        color: Colors.white.withOpacity(0.1),
        width: 1,
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.4),
          blurRadius: 15,
          offset: const Offset(0, 6),
        ),
        BoxShadow(
          color: accentRed.withOpacity(0.05),
          blurRadius: 5,
          spreadRadius: 1,
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.wifi_tethering, color: Colors.grey),
            const SizedBox(width: 10),
            const Text(
              "SOCIAL MEDIA CREATOR APPS",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildSocialButton(
              icon: Icons.telegram,
              label: "Telegram",
              color: Colors.blue,
              link: "https://t.me/XyzzcyOfficial",
            ),
            _buildSocialButton(
              icon: FontAwesomeIcons.youtube,
              label: "YouTube",
              color: Colors.red,
              link: "https://youtube.com/@xyzzcyofficial",
            ),
            _buildSocialButton(
              icon: Icons.music_note,
              label: "TikTok",
              color: Colors.black,
              link: "https://tiktok.com/@xyzzcyslowlys",
            ),
            _buildSocialButton(
              icon: FontAwesomeIcons.whatsapp,
              label: "Whatsapp",
              color: Colors.green,
              link: "https://wa.me/62895639019490",
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Center(
          child: Text(
            "All Social Media Creator of the STUX01 Application",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 13,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    ),
  );
}

Widget _buildSocialButton({
  required IconData icon,
  required String label,
  required Color color,
  required String link,
}) {
  return GestureDetector(
    onTap: () => openLink(link),
    child: Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: color.withOpacity(0.4)),
            color: color.withOpacity(0.15),
          ),
          child: Icon(icon, color: color, size: 30),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
          ),
        ),
      ],
    ),
  );
}


Widget _buildRecentActivity() {
  final today = DateTime.now();
  int countToday(String type) {
    return _activityLogs.where((log) {
      final time = DateTime.tryParse(log['timestamp']?.toString() ?? '');
      return time != null &&
          time.year == today.year &&
          time.month == today.month &&
          time.day == today.day &&
          (log['activity']?.toString().toLowerCase() == type);
    }).length;
  }

  final sendBug = countToday('send_bug');
  final login = countToday('login');
  final logout = countToday('logout');
  final raid = countToday('raid_group');
  final account = countToday('create_account');

  final metrics = <Map<String, dynamic>>[
    {'label': 'SEND BUG', 'value': sendBug, 'icon': Icons.send_rounded},
    {'label': 'LOGIN', 'value': login, 'icon': Icons.login_rounded},
    {'label': 'LOGOUT', 'value': logout, 'icon': Icons.logout_rounded},
    {'label': 'RAID', 'value': raid, 'icon': Icons.group_rounded},
    {'label': 'ACCOUNT', 'value': account, 'icon': Icons.person_add_alt_1_rounded},
  ];
  final maxValue = metrics.fold<int>(1, (max, item) => item['value'] > max ? item['value'] : max);

  return Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: cardDark,
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF1A1A1A), Color(0xFF0D0D0D)],
      ),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.32),
          blurRadius: 18,
          offset: const Offset(0, 8),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.insights_rounded, color: Colors.white70, size: 20),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "RECENT ACTIVITY",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    "Statistik aktivitas hari ini",
                    style: TextStyle(color: Colors.white54, fontSize: 10.5),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  _selectedTabIndex = 3;
                  _selectedPage = _buildActivityLogsPage();
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.10)),
                ),
                child: const Text(
                  "VIEW ALL",
                  style: TextStyle(color: Colors.white60, fontSize: 9, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          height: 145,
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          decoration: BoxDecoration(
            color: cardDarker.withOpacity(0.62),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.05)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: metrics.map((item) {
              final value = item['value'] as int;
              final factor = value == 0 ? 0.035 : value / maxValue;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: TweenAnimationBuilder<double>(
                    duration: const Duration(milliseconds: 800),
                    curve: Curves.easeOutCubic,
                    tween: Tween(begin: 0.02, end: factor),
                    builder: (_, heightFactor, __) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            child: Text(
                              "$value",
                              key: ValueKey(value),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(height: 5),
                          Container(
                            height: 86 * heightFactor,
                            width: double.infinity,
                            constraints: const BoxConstraints(minHeight: 4),
                            decoration: BoxDecoration(
                              borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(8),
                              ),
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xFF8E8E8E), Color(0xFF353535)],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white.withOpacity(0.07),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 7),
                          Icon(
                            item['icon'] as IconData,
                            color: Colors.white54,
                            size: 14,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            item['label'] as String,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 7.5,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            const Icon(Icons.info_outline_rounded, color: Colors.white30, size: 14),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                "Data dihitung dari activity log yang diterima aplikasi.",
                style: TextStyle(color: Colors.white.withOpacity(0.32), fontSize: 9.5),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

Widget _buildActivityLogsPage() {
  return RefreshIndicator(
    color: Colors.grey,
    onRefresh: () async {
      await _fetchActivityLogs();
    },
    child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardDark,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.history, color: Colors.grey, size: 24),
              ),
              const SizedBox(width: 15),
              const Text(
                "Activity History",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (_isLoadingActivityLogs)
          const Center(child: CircularProgressIndicator(color: Colors.grey))
        else if (_activityLogs.isEmpty)
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Center(
              child: Text(
                "Tidak ada aktivitas",
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
            ),
          )
        else
          ..._activityLogs.map((log) {
            final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
            final formattedTime = _formatDateTime(timestamp);

            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardDarker.withOpacity(0.7),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _getActivityColor(log['activity']).withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _getActivityColor(log['activity']).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          _getActivityIcon(log['activity']),
                          color: _getActivityColor(log['activity']),
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              log['activity'] ?? 'Unknown Activity',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (log['details'] != null && log['details']['target'] != null)
                              Text(
                                "Target: ${log['details']['target']}",
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 12,
                                ),
                              ),
                          ],
                        ),
                      ),
                      Text(
                        formattedTime,
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }).toList(),
      ],
    ),
  );
}

Widget _buildDeviceInfoCard() {
  final android = Platform.operatingSystemVersion;
  final memoryBytes = ProcessInfo.currentRss;
  final memoryMb = (memoryBytes / (1024 * 1024)).toStringAsFixed(1);

  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: cardDark,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.30),
          blurRadius: 16,
          offset: const Offset(0, 7),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.phone_android_rounded, color: Colors.white70, size: 20),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                "DEVICE INFO",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Orbitron",
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.10),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.green.withOpacity(0.22)),
              ),
              child: const Text(
                "ONLINE",
                style: TextStyle(color: Colors.greenAccent, fontSize: 8, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _deviceChip(Icons.android_rounded, "OS", android),
            _deviceChip(Icons.memory_rounded, "APP RAM", "$memoryMb MB"),
            _deviceChip(Icons.fingerprint_rounded, "DEVICE ID", androidId),
            _deviceChip(Icons.key_rounded, "SESSION", sessionKey == null ? "OFF" : "ACTIVE"),
          ],
        ),
      ],
    ),
  );
}

Widget _deviceChip(IconData icon, String label, String value) {
  return Container(
    width: 150,
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: cardDarker.withOpacity(0.75),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white.withOpacity(0.06)),
    ),
    child: Row(
      children: [
        Icon(icon, color: Colors.white54, size: 17),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: Colors.white30, fontSize: 8, fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget _buildMemberCatalog() {
  final plans = <Map<String, dynamic>>[
    {'name': 'MEMBER', 'price': '15K', 'icon': Icons.person_outline_rounded, 'desc': 'Akses member'},
    {'name': 'RESELLER', 'price': '25K', 'icon': Icons.storefront_rounded, 'desc': 'Akses reseller'},
    {'name': 'VIP', 'price': '35K', 'icon': Icons.workspace_premium_rounded, 'desc': 'Akses VIP'},
    {'name': 'OWNER', 'price': '60K', 'icon': Icons.shield_rounded, 'desc': 'Akses owner'},
  ];

  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: cardDark,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white.withOpacity(0.08)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.30),
          blurRadius: 16,
          offset: const Offset(0, 7),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.local_mall_rounded, color: Colors.white70, size: 20),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "MEMBERSHIP CATALOG",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    "Pilihan paket & harga",
                    style: TextStyle(color: Colors.white38, fontSize: 10),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 112,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: plans.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, index) {
              final plan = plans[index];
              return TweenAnimationBuilder<double>(
                duration: Duration(milliseconds: 450 + index * 80),
                tween: Tween(begin: 0.0, end: 1.0),
                curve: Curves.easeOutCubic,
                builder: (_, value, child) => Opacity(
                  opacity: value,
                  child: Transform.translate(
                    offset: Offset(18 * (1 - value), 0),
                    child: child,
                  ),
                ),
                child: Container(
                  width: 150,
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF242424), Color(0xFF101010)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(plan['icon'] as IconData, color: Colors.white70, size: 17),
                          const Spacer(),
                          Text(
                            plan['price'] as String,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      Text(
                        plan['name'] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.7,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        plan['desc'] as String,
                        style: const TextStyle(color: Colors.white38, fontSize: 9),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}

Widget _buildNewsPage() {
  return FadeTransition(
    opacity: _fadeAnimation,
    child: RefreshIndicator(
      color: Colors.grey, // ← tambahin ini
      onRefresh: () async {
        await _fetchActivityLogs();
        await _fetchWeather();
        await _fetchNews();
        await _fetchRandomHadith();
        await fetchTotalUsers();
        await checkSenderStatus();
        setState(() {});
      },
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeaderPanel(),
            const SizedBox(height: 24),
            _buildStatsCards(),
            const SizedBox(height: 18),
            _buildRecentActivity(),
            const SizedBox(height: 18),
            _buildAccountInfo(),
            const SizedBox(height: 24),
            _buildNewsSection(),
            const SizedBox(height: 24),
            _buildWeatherCard(),
            const SizedBox(height: 24),
            const JadwalSholat(),
            const SizedBox(height: 24),
            _buildHadithSection(),
            const SizedBox(height: 24),
            buildConnectWithTeam(),
            const SizedBox(height: 18),
            _buildMemberCatalog(),
            const SizedBox(height: 18),
            _buildDeviceInfoCard(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    ),
  );
}


  
  Widget _buildGlassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1.5,
            ),
          ),
          child: child,
        ),
      ),
    );
  }
  
Color _getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case "staff":
      return Colors.green;
    case "moderator":
      return Colors.cyan;
    case "owner":
      return Colors.grey;
    case "admin":
      return Colors.orange;
    case "reseller":
      return Colors.purple;
    default:
      return Colors.grey[600]!; // goldColor diganti abu-abu
  }
}

Widget _buildDrawer() {
  return Drawer(
    backgroundColor: cardDarker,
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryDark, primaryDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "STUX01 APPS",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildDrawerInfo("User:", username),
              _buildDrawerInfo("Role:", role),
              _buildDrawerInfo("Expired:", expiredDate),
            ],
          ),
        ),

        const SizedBox(height: 16),

        _buildDrawerItem(
          icon: Icons.person,
          label: "My Info",
          onTap: () {
            if (sessionKey == null) return;
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MyInfoPage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey!,
                ),
              ),
            );
          },
        ),
        
        _buildDrawerItem(
          icon: Icons.phone_android_rounded,
          label: "Device Info",
          onTap: () {
            Navigator.pop(context);
            showModalBottomSheet(
              context: context,
              backgroundColor: Colors.transparent,
              isScrollControlled: true,
              builder: (_) => SafeArea(
                child: Container(
                  padding: const EdgeInsets.only(top: 12, bottom: 20),
                  decoration: BoxDecoration(
                    color: cardDarker,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: SingleChildScrollView(
                    child: _buildDeviceInfoCard(),
                  ),
                ),
              ),
            );
          },
        ),

        _buildDrawerItem(
  icon: Icons.history_rounded,
  label: "Riwayat Aktivitas",
  onTap: () {
    Navigator.pop(context);
    if (sessionKey != null) {  // Tambahkan pengecekan
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RiwayatPage(
            sessionKey: sessionKey!,
            role: role,
          ),
        ),
      );
    }
  },
),
        
        _buildDrawerItem(
          icon: Icons.group,
          label: "Thanks To",
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ThanksToPage()),
            );
          },
        ),

        const Divider(color: Colors.white24),

        _buildDrawerItem(
          icon: Icons.logout,
          label: "Logout",
          onTap: () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (!mounted) return;
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (route) => false,
            );
          },
        ),
      ],
    ),
  );
}

  void _showFloatingBugMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Floating Bug",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.android, color: Colors.green),
              title: const Text(
                "Di Dalam Aplikasi",
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                "Muncul di dalam APK",
                style: TextStyle(color: Colors.white.withOpacity(0.6)),
              ),
              onTap: () {
                Navigator.pop(context);
                FloatingBugService().toggleEnabled();
              },
            ),
            const Divider(color: Colors.white24),
            ListTile(
              leading: const Icon(Icons.chat_bubble, color: Colors.blue),
              title: const Text(
                "Di Luar Aplikasi",
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                "Muncul di semua layar",
                style: TextStyle(color: Colors.white.withOpacity(0.6)),
              ),
              onTap: () {
                Navigator.pop(context);
                _toggleFloatingBagger();
              },
            ),
          ],
        ),
      ),
    );
  }
  Future<void> _toggleFloatingBagger() async {
    final hasPermission = await FloatingBagger.checkOverlayPermission();
    if (!hasPermission) {
      final granted = await FloatingBagger.requestOverlayPermission();
      if (!granted) {
        _showAlert("❌ Izin Ditolak", 
            "Aktifkan izin 'Tampilkan di atas aplikasi lain' di pengaturan");
        return;
      }
    }
    
    final prefs = await SharedPreferences.getInstance();
    final isServiceRunning = prefs.getBool('floating_bagger_running') ?? false;
    
    if (isServiceRunning) {
      await FloatingBagger.stopService();
      await prefs.setBool('floating_bagger_running', false);
      setState(() {
        _isFloatingBaggerActive = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Dimatikan")),
      );
    } else {
      await FloatingBagger.startService(
        username: username,
        password: password,
        sessionKey: sessionKey!,
        role: role,
        expiredDate: expiredDate,
      );
      await prefs.setBool('floating_bagger_running', true);
      setState(() {
        _isFloatingBaggerActive = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Diaktifkan")),
      );
    }
  }

  Widget _buildFloatingBaggerToggle() {
    return GestureDetector(
      onTap: _toggleFloatingBagger,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isFloatingBaggerActive
                ? Colors.green.withOpacity(0.5)
                : goldColor.withOpacity(0.3),
            width: 1
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _isFloatingBaggerActive
                    ? Colors.green.withOpacity(0.2)
                    : Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.chat_bubble,
                color: _isFloatingBaggerActive
                    ? Colors.green
                    : blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Floating Bagger (Luar Aplikasi)",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    _isFloatingBaggerActive
                        ? "Aktif - Tap untuk matikan"
                        : "Nonaktif - Tap untuk aktifkan",
                    style: TextStyle(
                      color: _isFloatingBaggerActive
                          ? Colors.green.withOpacity(0.8)
                          : Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              _isFloatingBaggerActive
                  ? Icons.toggle_on
                  : Icons.toggle_off,
              color: _isFloatingBaggerActive
                  ? Colors.green
                  : goldColor,
              size: 30,
            ),
          ],
        ),
      ),
    );
  }

void _showAlert(String title, String msg) {
  final bool isSuccess = title.contains("✅");

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      cardDark.withOpacity(0.95),
                      cardDarker.withOpacity(0.98),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 30,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [

                    /// ICON
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: isSuccess
                              ? [
                                  Colors.green.withOpacity(0.3),
                                  const Color(0xFF00FF88).withOpacity(0.3),
                                ]
                              : [
                                  const Color(0xFFDC143C).withOpacity(0.3),
                                  const Color(0xFFFF416C).withOpacity(0.3),
                                ],
                        ),
                      ),
                      child: Icon(
                        isSuccess
                            ? Icons.check_circle
                            : Icons.error,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),

                    const SizedBox(height: 24),

                    /// TITLE
                    Text(
                      title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),

                    const SizedBox(height: 16),

                    /// MESSAGE
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        msg,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 15,
                          height: 1.5,
                        ),
                      ),
                    ),

                    const SizedBox(height: 32),

                    /// BUTTON
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: () => Navigator.of(context).pop(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isSuccess
                              ? const Color(0xFF00FF88).withOpacity(0.2)
                              : const Color(0xFFDC143C).withOpacity(0.2),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: isSuccess
                                  ? const Color(0xFF00FF88).withOpacity(0.5)
                                  : const Color(0xFFDC143C).withOpacity(0.5),
                              width: 1.5,
                            ),
                          ),
                        ),
                        child: const Text(
                          "OK",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}

  Widget _buildManageBugSenderButton() {
    return GestureDetector(
      onTap: () {
        if (sessionKey == null) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugSenderPage(
              sessionKey: sessionKey!,
              username: username,
              role: role,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Bug Sender",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Manage WhatsApp",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
  
Widget _buildToolsButton() {
  return GestureDetector(
    onTap: () {
      if (sessionKey == null) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ToolsPage(
            sessionKey: sessionKey!,
            username: username,
            userRole: role,
          ),
        ),
      );
    },
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, cardDarker],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: goldColor.withOpacity(0.3), // ✅ FIXED
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1), // ✅ FIXED
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.build_circle_outlined,
              color: blueColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Tools",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  "Digital Tools",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios,
            color: goldColor,
            size: 16,
          ),
        ],
      ),
    ),
  );
}
  
  Widget _buildDDosPanelButton() {
    return GestureDetector(
      onTap: () {
        if (sessionKey == null) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AttackPanel(
              sessionKey: sessionKey!,
              listDDoS: listDoos,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.server,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Attack",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "DDos Panel",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildChannelButton() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse("https://t.me/aboutxyzzcy");
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.telegram,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Telegram",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Join Update Channel",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeveloperButton() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse("https://t.me/XyzzcyOfficial");
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.telegram,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Telegram",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Contact Developer",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: TextStyle(
              color: goldColor,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

Widget _buildAnimatedNavItem(
  int index,
  IconData activeIcon,
  IconData inactiveIcon,
  String label,
) {
  final selected = _selectedTabIndex == index;
  return Expanded(
    child: GestureDetector(
      onTap: () => _onTabTapped(index),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? Colors.white.withOpacity(0.09) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: selected ? Colors.white.withOpacity(0.10) : Colors.transparent,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedScale(
              scale: selected ? 1.08 : 1.0,
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutBack,
              child: Icon(
                selected ? activeIcon : inactiveIcon,
                color: selected ? Colors.white : Colors.white38,
                size: 22,
              ),
            ),
            const SizedBox(height: 3),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 220),
              style: TextStyle(
                color: selected ? Colors.white : Colors.white38,
                fontSize: selected ? 9.5 : 9,
                fontWeight: selected ? FontWeight.bold : FontWeight.w500,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget _buildDrawerItem({
  required IconData icon,
  required String label,
  required VoidCallback onTap,
}) {
  return ListTile(
    leading: Icon(
      icon,
      color: Colors.grey.shade400,  // ✅ abu-abu untuk icon
    ),
    title: Text(
      label,
      style: TextStyle(
        color: Colors.grey.shade300,  // ✅ abu-abu untuk teks
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ),
    ),
    onTap: onTap,
  );
}

@override
Widget build(BuildContext context) {
  if (sessionKey == null) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: Center(
        child: CircularProgressIndicator(color: goldColor),
      ),
    );
  }

  final double bottomPadding = MediaQuery.of(context).padding.bottom;

  return Scaffold(
    backgroundColor: primaryDark,
    appBar: AppBar(
      title: Text(
        "Holla, $username",
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      backgroundColor: primaryDark,
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.white),
      actions: [
        // 🔹 TOKO
        IconButton(
          icon: const Icon(Icons.storefront, color: Colors.white),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const BuyPage()),
            );
          },
        ),
        // 🔹 MUSIC
        IconButton(
          icon: const Icon(Icons.music_note, color: Colors.white),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SpotifyPage()),
            );
          },
        ),
        // 🔹 CONTACT
        IconButton(
          icon: const Icon(Icons.headset_mic_outlined, color: Colors.white),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ContactPage()),
            );
          },
        ),
        // 🔹 MY INFO
        IconButton(
          icon: const Icon(Icons.account_circle, color: Colors.white),
          onPressed: () {
            if (sessionKey == null) return;
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MyInfoPage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey!,
                ),
              ),
            );
          },
        ),
      ],
    ),
    drawer: _buildDrawer(),
    body: FadeTransition(
      opacity: _animation,
      child: _selectedPage,
    ),
    bottomNavigationBar: Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: bottomPadding + 12,
        top: 4,
      ),
      child: Container(
        height: 68,
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: cardDark.withOpacity(0.92),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.10)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.55),
              blurRadius: 24,
              spreadRadius: 1,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            _buildAnimatedNavItem(0, Icons.home_rounded, Icons.home_outlined, "Home"),
            _buildAnimatedNavItem(1, FontAwesomeIcons.whatsapp, FontAwesomeIcons.whatsapp, "WhatsApp"),
            _buildAnimatedNavItem(2, Icons.notifications_rounded, Icons.notifications_none_rounded, "Info"),
            _buildAnimatedNavItem(3, Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded, "Chat"),
          ],
        ),
      ),
    )
  );
}


  @override
  void dispose() {
    _controller.dispose();
    _fadeController.dispose();
    _pulseController.dispose();
    if (_isVideoInitialized) {
      _videoController.dispose();
      _chewieController.dispose();
    }
    _slideController.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatelessWidget {
  final String url;

  const NewsMedia({required this.url});

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: url,
      fit: BoxFit.cover,
      placeholder: (context, url) => Container(
        color: const Color(0xFF1A1A1A),
        child: const Center(
          child: CircularProgressIndicator(color: Color(0xFF9E9E9E)),
        ),
      ),
      errorWidget: (context, url, error) => Container(
        color: const Color(0xFF2D2D2D),
        child: const Center(
          child: Icon(Icons.error, color: Colors.white70),
        ),
      ),
    );
  }
}

class _QuickActionData {
  final IconData icon;
  final String label;
  final String subtitle;
  final Gradient gradient;
  final VoidCallback onTap;

  const _QuickActionData({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// Data dan widget untuk bottom sheet (sama seperti asli, diperbesar)
class _SheetItemData {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final void Function(BuildContext) onTap;
  
  const _SheetItemData({  // ✅ Tambah const
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

void _showCustomSheet(
  BuildContext context, {
  required String title,
  required IconData titleIcon,
  required Color titleColor,
  required List<_SheetItemData> items,
}) {
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: "sheet",
    barrierColor: Colors.black.withOpacity(0.55),
    transitionDuration: const Duration(milliseconds: 360),
    pageBuilder: (_, __, ___) => const SizedBox.shrink(),
    transitionBuilder: (ctx, anim, _, __) {
      final curved = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic, reverseCurve: Curves.easeInCubic);
      return GestureDetector(
        onTap: () => Navigator.of(ctx).pop(),
        behavior: HitTestBehavior.opaque,
        child: Align(
          alignment: Alignment.bottomCenter,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero).animate(curved),
            child: GestureDetector(
              onTap: () {},
              child: _SheetContent(
                title: title,
                titleIcon: titleIcon,
                titleColor: titleColor,
                items: items,
              ),
            ),
          ),
        ),
      );
    },
  );
}

class _SheetContent extends StatelessWidget {
  final String title;
  final IconData titleIcon;
  final Color titleColor;
  final List<_SheetItemData> items;

  const _SheetContent({
    required this.title,
    required this.titleIcon,
    required this.titleColor,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
            decoration: BoxDecoration(
              color: const Color(0xFF0E1118).withOpacity(0.96),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border(top: BorderSide(color: titleColor.withOpacity(0.45), width: 1.4)),
              boxShadow: [BoxShadow(color: titleColor.withOpacity(0.20), blurRadius: 30, offset: const Offset(0, -6))],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.22),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: titleColor.withOpacity(0.16),
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: titleColor.withOpacity(0.40)),
                      ),
                      child: Icon(titleIcon, color: titleColor, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      title,
                      style: const TextStyle(
                        fontFamily: 'Orbitron',  // ✅ Ganti _font dengan 'Orbitron'
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                ...items.map((it) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _SheetButton(data: it, accent: titleColor),
                )),
                const SizedBox(height: 6),
                Center(
                  child: Text(
                    "Tap di luar untuk menutup",
                    style: TextStyle(
                      fontFamily: 'Orbitron',  // ✅ Ganti _font dengan 'Orbitron'
                      color: Colors.white.withOpacity(0.40),
                      fontSize: 11,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SheetButton extends StatelessWidget {
  final _SheetItemData data;
  final Color accent;

  const _SheetButton({
    required this.data,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => data.onTap(context),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accent.withOpacity(0.20), width: 1.1),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 8, offset: const Offset(0, 4))],
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: data.iconColor.withOpacity(0.14),
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: data.iconColor.withOpacity(0.40)),
              ),
              child: Icon(data.icon, color: data.iconColor, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data.title,
                    style: const TextStyle(
                      fontFamily: 'Orbitron',  // ✅ Ganti _font dengan 'Orbitron'
                      color: Colors.white,
                      fontSize: 14.5,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    data.subtitle,
                    style: TextStyle(
                      fontFamily: 'Orbitron',  // ✅ Ganti _font dengan 'Orbitron'
                      color: Colors.white.withOpacity(0.55),
                      fontSize: 11.5,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: accent.withOpacity(0.85),
              size: 13,
            ),
          ],
        ),
      ),
    );
  }
}

class DarkCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final EdgeInsets? margin;

  const DarkCard({
    Key? key,
    required this.child,
    this.padding,
    this.margin,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin ?? EdgeInsets.zero,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }
}
