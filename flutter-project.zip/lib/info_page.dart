// info_page.dart - VERSI TRANSPARAN GLASSMORPHISM (Terhubung GlobalTheme + FIXED)

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import 'global_theme.dart';

// ─── Neo Design System ─────────────────────────────────────
class _C {
  _C._();

  // ═══ STATIC (tidak ikut tema) ═══
  static const bg        = Color(0xFF080C1A);
  static const surface   = Color(0xFF0E1A2B);
  static const card      = Color(0xFF14233A);
  static const border    = Color(0xFF1E3350);
  static const borderLit = Color(0xFF2A4A70);

  // ═══ STATUS COLORS (tetap) ═══
  static const green     = Color(0xFF2DD36F);
  static const amber     = Color(0xFFFBBF24);
  static const red       = Color(0xFFF87171);
  static const purple    = Color(0xFFC084FC);
  static const teal      = Color(0xFF2DD4BF);
  static const pink      = Color(0xFFF472B6);

  // ═══ TEXT (tetap) ═══
  static const text      = Color(0xFFF0F6FF);
  static const textSub   = Color(0xFFB8D4EC);
  static const textDim   = Color(0xFF8AB4D6);
  static const textMuted = Color(0xFF4A6A8A);

  // ═══ DYNAMIC (ikut GlobalTheme) ═══
  static Color get blue      => GlobalTheme.darken(GlobalTheme.primary, 0.15);
  static Color get blueMid   => GlobalTheme.primary;
  static Color get blueLight => GlobalTheme.lighten(GlobalTheme.primary, 0.20);
  static Color get blueGlow  => GlobalTheme.lighten(GlobalTheme.primary, 0.10);

  // ═══ GRADIENTS ═══
  static LinearGradient get primaryGrad => LinearGradient(
    colors: [blueMid, blueGlow],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient secondaryGrad = LinearGradient(
    colors: [purple, pink],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get accentGrad => LinearGradient(
    colors: [teal, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient dangerGrad = LinearGradient(
    colors: [red, Color(0xFFEF4444)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Text Shadow Global ────────────────────────────────────
const _textShadow = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ─── Rules data ─────────────────────────────────────────────
const _rules = [
  _Rule(
    title: 'Larangan Barter Akun',
    desc:  'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun.',
    icon:  Icons.swap_horiz_rounded,
    color: Color(0xFFFBBF24),
  ),
  _Rule(
    title: 'Larangan Membagikan Akun',
    desc:  'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar.',
    icon:  Icons.share_rounded,
    color: Color(0xFF3B9EFF),
  ),
  _Rule(
    title: 'Larangan Menjual Akun',
    desc:  'Member TIDAK diperbolehkan menjual akun. Penjualan hanya boleh dilakukan oleh role yang diizinkan secara resmi.',
    icon:  Icons.sell_rounded,
    color: Color(0xFFF87171),
  ),
  _Rule(
    title: 'Larangan Jual Durasi Ilegal',
    desc:  'Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan.',
    icon:  Icons.timer_off_rounded,
    color: Color(0xFFC084FC),
  ),
  _Rule(
    title: 'Larangan Banting Harga',
    desc:  'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan VOR4X.',
    icon:  Icons.trending_down_rounded,
    color: Color(0xFF2DD4BF),
  ),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc,
      required this.icon, required this.color});
}

// ─── Fallback Data ──────────────────────────────────────────
const _fallbackServerInfo = {
  'name': 'VOR4X Server',
  'version': '1.0',
  'status': 'online',
};

// ─── Main Page ──────────────────────────────────────────────
class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  Map<String, dynamic> serverInfo = _fallbackServerInfo;
  bool isLoading = false;

  bool   _apiOnline   = false;
  int    _pingMs      = 0;
  String _pingStatus  = 'Checking...';
  Timer? _pingTimer;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pingDotCtrl;
  late AnimationController _sanctionCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _floatCtrl;
  late AnimationController _gradientShiftCtrl;
  late AnimationController _glowPulseCtrl;

  late Animation<double> _entrance;
  late Animation<double> _pingDot;
  late Animation<double> _sanctionGlow;
  late Animation<double> _pulseAnim;
  late Animation<double> _floatAnim;
  late Animation<double> _gradientShift;
  late Animation<double> _glowPulse;

  int? _expandedRule;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 22))..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _pingDotCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
    _pingDot = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _pingDotCtrl, curve: Curves.easeInOut));

    _sanctionCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2500))
      ..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.15, end: 0.55)
        .animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _floatCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 4))
      ..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -6, end: 6)
        .animate(CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));

    _gradientShiftCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))..repeat();
    _gradientShift = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _gradientShiftCtrl, curve: Curves.linear));

    _glowPulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _glowPulse = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _glowPulseCtrl, curve: Curves.easeInOut));

    _fetchServerInfo();
    _startPingLoop();

    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _pingDotCtrl.dispose();
    _sanctionCtrl.dispose();
    _pulseCtrl.dispose();
    _floatCtrl.dispose();
    _gradientShiftCtrl.dispose();
    _glowPulseCtrl.dispose();
    super.dispose();
  }

  // ─── API ───────────────────────────────────────────────────
  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(Uri.parse(
          'https://paultzy.pteroqhost.web.id5015/getServerInfo?key=${widget.sessionKey}'));
      if (res.statusCode == 200 && mounted) {
        setState(() { serverInfo = jsonDecode(res.body); });
      }
    } catch (_) {}
  }

  void _startPingLoop() {
    _checkPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkPing());
  }

  Future<void> _checkPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(Uri.parse(
              'https://paultzy.pteroqhost.web.id5015/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final ms = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          _apiOnline  = true;
          _pingMs     = ms;
          _pingStatus = '${ms}ms';
        });
      } else {
        throw Exception();
      }
    } catch (_) {
      if (mounted) setState(() {
        _apiOnline = false;
        _pingMs = 0;
        _pingStatus = 'Offline';
      });
    }
  }

  Color get _pingColor {
    if (!_apiOnline) return _C.red;
    if (_pingMs < 150) return _C.green;
    if (_pingMs < 400) return _C.amber;
    return const Color(0xFFFB923C);
  }

  String get _pingLabel {
    if (!_apiOnline) return 'OFFLINE';
    if (_pingMs < 150) return 'PERFECT';
    if (_pingMs < 400) return 'STABLE';
    return 'SLOW';
  }

  // ─── Build ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (context, _, __) {
        return Scaffold(
          backgroundColor: Colors.transparent,
          extendBody: true,
          extendBodyBehindAppBar: true,
          appBar: _buildAppBar(),
          body: Stack(
            children: [
              Positioned.fill(
                child: _AnimatedBg(controller: _bgCtrl),
              ),
              SafeArea(
                child: FadeTransition(
                  opacity: _entrance,
                  child: ListView(
                    physics: const BouncingScrollPhysics(
                      parent: AlwaysScrollableScrollPhysics(),
                    ),
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 50),
                    children: [
                      _buildNeoHeader(),
                      const SizedBox(height: 18),
                      _buildNeoStatusCard(),
                      const SizedBox(height: 26),
                      _buildNeoSectionHeader(),
                      const SizedBox(height: 18),
                      ..._rules.asMap().entries.map((e) =>
                        Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _NeoRuleCard(
                            rule: e.value,
                            number: e.key + 1,
                            isExpanded: _expandedRule == e.key,
                            onTap: () => setState(() {
                              _expandedRule = _expandedRule == e.key ? null : e.key;
                            }),
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),
                      _buildNeoSanctionCard(),
                      const SizedBox(height: 26),
                      _buildNeoFooter(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── Neo Header ───────────────────────────────────────────
  Widget _buildNeoHeader() {
    return AnimatedBuilder(
      animation: _floatAnim,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, _floatAnim.value),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  gradient: _C.primaryGrad,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: _C.blueMid.withOpacity(0.4),
                      blurRadius: 20,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.bolt_rounded, color: Colors.white, size: 14),
                    SizedBox(width: 6),
                    Text('VOR4X',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5,
                        )),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              ShaderMask(
                shaderCallback: (rect) => LinearGradient(
                  colors: [_C.text, _C.blueLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(rect),
                child: const Text('Rules &\nInformation',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                      letterSpacing: -0.8,
                      shadows: _textShadow,
                    )),
              ),
              const SizedBox(height: 6),
              const Text('Stay informed, stay compliant',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    letterSpacing: 0.3,
                    shadows: _textShadow,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Glass Card Helper ────────────────────────────────────
  Widget _buildGlassCard({
    required Widget child,
    Color? accentColor,
    double blur = 18,
    double opacity = 0.16,
    double borderOpacity = 0.28,
    EdgeInsets padding = const EdgeInsets.all(18),
    double radius = 28,
    double glowAmount = 0.0,
  }) {
    final accent = accentColor ?? _C.blueMid;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(opacity * 0.7),
                Colors.white.withOpacity(opacity * 0.15),
                Colors.black.withOpacity(opacity * 0.5),
              ],
            ),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(
              color: accent.withOpacity(borderOpacity),
              width: 1.2,
            ),
            boxShadow: [
              if (glowAmount > 0)
                BoxShadow(
                  color: accent.withOpacity(glowAmount),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              BoxShadow(
                color: Colors.black.withOpacity(0.35),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  // ─── Neo Status Card (GLASS) ──────────────────────────────
  Widget _buildNeoStatusCard() {
    final color = _apiOnline ? _pingColor : _C.red;
    return AnimatedBuilder(
      animation: _glowPulse,
      builder: (_, __) => _buildGlassCard(
        accentColor: color,
        glowAmount: _apiOnline ? 0.12 * _glowPulse.value : 0.15,
        opacity: 0.18,
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        color.withOpacity(0.28),
                        color.withOpacity(0.06),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: color.withOpacity(0.35)),
                  ),
                  child: AnimatedBuilder(
                    animation: _pingDot,
                    builder: (_, __) => Icon(
                      _apiOnline ? Icons.check_circle_rounded : Icons.error_rounded,
                      color: color.withOpacity(_apiOnline ? _pingDot.value : 0.9),
                      size: 28,
                      shadows: _textShadow,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 8, height: 8,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: color.withOpacity(0.6),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Text('API SERVER STATUS',
                              style: TextStyle(
                                  color: _C.textDim,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1.2,
                                  shadows: _textShadow)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(_apiOnline ? 'Connected' : 'Disconnected',
                          style: TextStyle(
                              color: color,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              letterSpacing: -0.3,
                              shadows: _textShadow)),
                    ],
                  ),
                ),
                SizedBox(
                  width: 64, height: 64,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 58, height: 58,
                        child: CircularProgressIndicator(
                          value: _apiOnline ? (_pingMs / 500).clamp(0.0, 1.0) : 0,
                          strokeWidth: 3.5,
                          backgroundColor: Colors.white.withOpacity(0.08),
                          color: color,
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(_apiOnline ? '$_pingMs' : '--',
                              style: TextStyle(
                                  color: color,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  shadows: _textShadow)),
                          Text(_pingLabel,
                              style: TextStyle(
                                  color: color.withOpacity(0.7),
                                  fontSize: 7,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (!_apiOnline) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.red.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _C.red.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.wifi_off_rounded, color: _C.red, size: 18,
                        shadows: _textShadow),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text('Connection lost. Retrying...',
                          style: TextStyle(
                            color: _C.textSub,
                            fontSize: 12,
                            shadows: _textShadow,
                          )),
                    ),
                    const SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: _C.red,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ─── Neo Section Header ───────────────────────────────────
  Widget _buildNeoSectionHeader() {
    return Row(
      children: [
        Container(
          width: 5, height: 30,
          decoration: BoxDecoration(
            gradient: _C.primaryGrad,
            borderRadius: BorderRadius.circular(4),
            boxShadow: [
              BoxShadow(
                color: _C.blueMid.withOpacity(0.5),
                blurRadius: 12,
              ),
            ],
          ),
        ),
        const SizedBox(width: 14),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('REGULATIONS',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.4,
                  shadows: _textShadow,
                )),
            Text('Tap to expand details',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                  shadows: _textShadow,
                )),
          ],
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(
            gradient: _C.secondaryGrad,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: _C.purple.withOpacity(0.4),
                blurRadius: 14,
              ),
            ],
          ),
          child: Text('${_rules.length} RULES',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
                shadows: _textShadow,
              )),
        ),
      ],
    );
  }

  // ─── Neo Sanction Card (GLASS) ────────────────────────────
  Widget _buildNeoSanctionCard() {
    return AnimatedBuilder(
      animation: _sanctionCtrl,
      builder: (_, __) => _buildGlassCard(
        accentColor: _C.red,
        glowAmount: 0.08 + _sanctionGlow.value * 0.10,
        borderOpacity: 0.25 + _sanctionGlow.value * 0.30,
        opacity: 0.16,
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            children: [
              Positioned(
                right: -30, top: -30,
                child: AnimatedBuilder(
                  animation: _sanctionCtrl,
                  builder: (_, __) => Icon(Icons.gavel_rounded,
                      size: 120,
                      color: _C.red.withOpacity(0.05 + _sanctionGlow.value * 0.05)),
                ),
              ),
              Positioned(
                left: -20, bottom: -20,
                child: Icon(Icons.shield_rounded,
                    size: 80,
                    color: _C.red.withOpacity(0.04)),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _C.red.withOpacity(0.28),
                                _C.red.withOpacity(0.06),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: _C.red.withOpacity(0.3 + _sanctionGlow.value * 0.2),
                              width: 1,
                            ),
                          ),
                          child: AnimatedBuilder(
                            animation: _sanctionCtrl,
                            builder: (_, __) => Icon(Icons.warning_rounded,
                                color: _C.red.withOpacity(0.75 + _sanctionGlow.value * 0.25),
                                size: 24,
                                shadows: _textShadow),
                          ),
                        ),
                        const SizedBox(width: 14),
                        const Expanded(
                          child: Text('SANCTIONS',
                              style: TextStyle(
                                color: _C.red,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.2,
                                shadows: _textShadow,
                              )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: _C.red.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: _C.red.withOpacity(0.18)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.block_rounded,
                              color: _C.red.withOpacity(0.9),
                              size: 22,
                              shadows: _textShadow),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Text('Account will be DELETED permanently',
                                style: TextStyle(
                                  color: _C.text,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: -0.2,
                                  shadows: _textShadow,
                                )),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 10,
                      runSpacing: 8,
                      children: [
                        _neoSanctionChip(Icons.account_balance_wallet_rounded, 'No Refund'),
                        _neoSanctionChip(Icons.sync_disabled_rounded, 'No Compensation'),
                        _neoSanctionChip(Icons.person_off_rounded, 'Permanent Ban'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _neoSanctionChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: _C.red.withOpacity(0.12),
        border: Border.all(color: _C.red.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.red.withOpacity(0.85), size: 14, shadows: _textShadow),
          const SizedBox(width: 6),
          Text(label,
              style: const TextStyle(
                color: _C.text,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                shadows: _textShadow,
              )),
        ],
      ),
    );
  }

  // ─── Neo Footer (GLASS) ───────────────────────────────────
  Widget _buildNeoFooter() {
    return Column(children: [
      _buildGlassCard(
        accentColor: _C.blueMid,
        opacity: 0.14,
        blur: 14,
        radius: 20,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ✅ FIX: hapus 'const' karena _C.blueLight adalah getter
            Icon(Icons.shield_moon_rounded, color: _C.blueLight, size: 20,
                shadows: _textShadow),
            const SizedBox(width: 14),
            const Expanded(
              child: Text(
                'By using this application, users agree to comply with '
                'all applicable rules and regulations.',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 12,
                  height: 1.6,
                  fontWeight: FontWeight.w400,
                  shadows: _textShadow,
                ),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          height: 2, width: 40,
          decoration: BoxDecoration(
            gradient: _C.primaryGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _C.blueMid.withOpacity(0.5), blurRadius: 10),
            ],
          ),
        ),
        const SizedBox(width: 14),
        ShaderMask(
          shaderCallback: (rect) => const LinearGradient(
            colors: [_C.textDim, _C.textSub],
          ).createShader(rect),
          child: const Text('VOR4X',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                shadows: _textShadow,
              )),
        ),
        const SizedBox(width: 14),
        Container(
          height: 2, width: 40,
          decoration: BoxDecoration(
            gradient: _C.primaryGrad,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [
              BoxShadow(color: _C.blueMid.withOpacity(0.5), blurRadius: 10),
            ],
          ),
        ),
      ]),
    ]);
  }

  // ─── AppBar TRANSPARAN PENUH (menyatu) ────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      automaticallyImplyLeading: false,
      centerTitle: true,
      title: const SizedBox.shrink(),
    );
  }
}

// ─── Neo Rule Card (GLASS) ──────────────────────────────────
class _NeoRuleCard extends StatelessWidget {
  final _Rule rule;
  final int number;
  final bool isExpanded;
  final VoidCallback onTap;

  const _NeoRuleCard({
    required this.rule,
    required this.number,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = rule.color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            if (isExpanded)
              BoxShadow(
                color: color.withOpacity(0.15),
                blurRadius: 25,
                offset: const Offset(0, 8),
              ),
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: isExpanded
                      ? [
                          color.withOpacity(0.20),
                          Colors.white.withOpacity(0.08),
                          Colors.black.withOpacity(0.15),
                        ]
                      : [
                          Colors.white.withOpacity(0.14),
                          Colors.white.withOpacity(0.05),
                          Colors.black.withOpacity(0.15),
                        ],
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: isExpanded
                      ? color.withOpacity(0.55)
                      : Colors.white.withOpacity(0.18),
                  width: isExpanded ? 1.5 : 1,
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          width: 36, height: 36,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                color.withOpacity(0.35),
                                color.withOpacity(0.08),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: color.withOpacity(0.4)),
                          ),
                          child: Center(
                            child: Text('$number',
                                style: TextStyle(
                                  color: color,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  shadows: _textShadow,
                                )),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                color.withOpacity(0.22),
                                color.withOpacity(0.05),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(rule.icon, color: color, size: 20,
                              shadows: _textShadow),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Text(rule.title,
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 15,
                                fontWeight: isExpanded ? FontWeight.w700 : FontWeight.w600,
                                letterSpacing: -0.2,
                                shadows: _textShadow,
                              )),
                        ),
                        AnimatedRotation(
                          turns: isExpanded ? 0.5 : 0,
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.easeInOutCubic,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: isExpanded ? color.withOpacity(0.15) : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              Icons.keyboard_arrow_down_rounded,
                              color: isExpanded ? color : _C.textSub,
                              size: 22,
                              shadows: _textShadow,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  AnimatedCrossFade(
                    firstChild: const SizedBox(width: double.infinity),
                    secondChild: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white.withOpacity(0.10)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 3,
                              height: 36,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [color, color.withOpacity(0.3)],
                                ),
                                borderRadius: BorderRadius.circular(2),
                                boxShadow: [
                                  BoxShadow(
                                    color: color.withOpacity(0.5),
                                    blurRadius: 8,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(rule.desc,
                                  style: const TextStyle(
                                    color: _C.textSub,
                                    fontSize: 13,
                                    height: 1.6,
                                    fontWeight: FontWeight.w400,
                                    shadows: _textShadow,
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                    crossFadeState: isExpanded
                        ? CrossFadeState.showSecond
                        : CrossFadeState.showFirst,
                    duration: const Duration(milliseconds: 400),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Animated Background (SUBTLE) ───────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // Grid super tipis
    final grid = Paint()
      ..color = Colors.white.withOpacity(0.035)
      ..strokeWidth = 0.3;
    const step = 48.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // ⚡ Ambil warna dari GlobalTheme
    final baseColor = GlobalTheme.primary;

    // Glow subtle 1 (primary)
    final glow1 = Paint()
      ..shader = RadialGradient(colors: [
        baseColor.withOpacity(0.04 + math.sin(t * math.pi * 2) * 0.012),
        Colors.transparent,
      ], radius: 0.8).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.5, size.height * 0.12),
          radius: size.width * 0.65));
    canvas.drawCircle(
        Offset(size.width * 0.5, size.height * 0.12), size.width * 0.65, glow1);

    // Glow subtle 2 (purple tetap)
    final glow2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.purple.withOpacity(0.02 + math.cos(t * math.pi * 2 + 1) * 0.008),
        Colors.transparent,
      ], radius: 0.7).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.85, size.height * 0.8),
          radius: size.width * 0.5));
    canvas.drawCircle(
        Offset(size.width * 0.85, size.height * 0.8), size.width * 0.5, glow2);

    // Glow subtle 3 (teal tetap)
    final glow3 = Paint()
      ..shader = RadialGradient(colors: [
        _C.teal.withOpacity(0.015 + math.sin(t * math.pi * 2 + 2) * 0.008),
        Colors.transparent,
      ], radius: 0.6).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.15, size.height * 0.7),
          radius: size.width * 0.4));
    canvas.drawCircle(
        Offset(size.width * 0.15, size.height * 0.7), size.width * 0.4, glow3);

    // Partikel (ikut warna tema)
    final particle = Paint()..color = baseColor.withOpacity(0.05);
    for (int i = 0; i < 8; i++) {
      final px = (i * 137.5 + t * 20) % size.width;
      final py = (i * 97.3 + t * 15) % size.height;
      canvas.drawCircle(Offset(px, py), 2 + math.sin(i + t * 2) * 1, particle);
    }
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}