// lib/home_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

// ─── 🌐 KONFIGURASI SERVER ────────────────────────────────
const String _BASE_URL = 'https://paultzy.pteroqhost.web.id5015';

// ─── 🎯 ROLE SYSTEM ───────────────────────────────────────
const List<String> GLOBAL_SENDER_ROLES = [
  'developers', 'ceo', 'owner', 'admin', 'tangan_kanan', 'vip'
];

bool canAccessGlobalSender(String role) =>
    GLOBAL_SENDER_ROLES.contains(role.toLowerCase());

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return 'DEVELOPER';
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'developers': return const Color(0xFF9C27FF);
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF7A00);
    case 'admin': return const Color(0xFFFF3355);
    case 'tangan_kanan': return const Color(0xFFFF2D95);
    case 'vip': return const Color(0xFF00D4FF);
    case 'reseller': return const Color(0xFF2196F3);
    case 'full_up': return const Color(0xFF00E5A0);
    case 'member_perbulan': return const Color(0xFF64B5F6);
    case 'member_perminggu': return const Color(0xFF18FFFF);
    case 'member_perhari': return const Color(0xFF00FF88);
    default: return const Color(0xFF2196F3);
  }
}

// ─── 🎨 PALET WARNA NEON ─────────────────────────────────
class _C {
  static const Color blue = Color(0xFF2196F3);
  static const Color blueLight = Color(0xFF64B5F6);
  static const Color blueDark = Color(0xFF0D47A1);
  static const Color cyan = Color(0xFF00D4FF);
  static const Color cyanLight = Color(0xFF80DEEA);
  static const Color ice = Color(0xFFE3F2FD);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color blackDeep = Color(0xFF03060D);
  static const Color navy = Color(0xFF061225);
  static const Color textSecondary = Color(0xFFB0C4DE);
  static const Color textMuted = Color(0xFF6B7B8F);
  static const Color textBlueMuted = Color(0xFF8BA3C7);
  static const Color neonGreen = Color(0xFF00FF88);
  static const Color neonGold = Color(0xFFFFD700);
  static const Color neonRed = Color(0xFFFF3355);
  static const Color purple = Color(0xFF9C27FF);

  static const List<Color> neonPalette = [
    Color(0xFF2196F3), Color(0xFF9C27FF), Color(0xFF00D4FF),
    Color(0xFFFF2D95), Color(0xFF00FF88), Color(0xFFFFD700),
    Color(0xFFFF7A00), Color(0xFF18FFFF), Color(0xFFFF3355),
    Color(0xFF00E5A0),
  ];

  static Color neonFor(int i) => neonPalette[i % neonPalette.length];
}

// ═══════════════════════════════════════════════════════════
// 🏠 HOME PAGE
// ═══════════════════════════════════════════════════════════
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  // Video
  VideoPlayerController? _videoController;
  bool _videoInitialized = false;
  bool _isSoundOn = false;

  // Animation
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late AnimationController _progressShineController;
  late AnimationController _avatarRingController;
  late AnimationController _scanLineController;

  // Input
  final TextEditingController targetController = TextEditingController();
  final FocusNode _targetFocus = FocusNode();
  bool _targetFocused = false;

  // Bug carousel
  final PageController _bugPageController =
      PageController(viewportFraction: 0.78);
  int _currentBugIndex = 0;

  // Sender
  int _selectedSenderIndex = 0;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;

  // Status
  bool _isSending = false;

  bool get canAccessGlobal => canAccessGlobalSender(widget.role);
  String get roleDisplay => getRoleDisplay(widget.role);
  Color get roleColor => getRoleColor(widget.role);

  String? get _selectedBugId {
    if (widget.listBug.isEmpty) return null;
    if (_currentBugIndex < 0 || _currentBugIndex >= widget.listBug.length) {
      return widget.listBug[0]['bug_id'] as String?;
    }
    return widget.listBug[_currentBugIndex]['bug_id'] as String?;
  }

  String get _selectedSender => _selectedSenderIndex == 0 ? 'private' : 'global';

  // ─── INIT ─────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _progressShineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();

    _avatarRingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _scanLineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat();

    _targetFocus.addListener(() {
      setState(() => _targetFocused = _targetFocus.hasFocus);
    });

    _initVideo();
    _fetchSenderStats();

    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      _videoController?.play();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _videoController?.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _videoController?.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _progressShineController.dispose();
    _avatarRingController.dispose();
    _scanLineController.dispose();
    _bugPageController.dispose();
    _targetFocus.dispose();
    targetController.dispose();
    _senderTimer?.cancel();
    super.dispose();
  }

  // ─── VIDEO ────────────────────────────────────────────
  Future<void> _initVideo() async {
    try {
      final controller =
          VideoPlayerController.asset('assets/videos/background.mp4');
      await controller.initialize();
      if (!mounted) {
        controller.dispose();
        return;
      }
      controller.setLooping(true);
      controller.setVolume(0.0);
      controller.setPlaybackSpeed(1.0);
      await controller.play();
      setState(() {
        _videoController = controller;
        _videoInitialized = true;
      });
    } catch (e) {
      debugPrint('Video init error: $e');
    }
  }

  void _toggleSound() {
    final ctrl = _videoController;
    if (ctrl == null || !_videoInitialized) return;
    setState(() {
      _isSoundOn = !_isSoundOn;
      ctrl.setVolume(_isSoundOn ? 0.7 : 0.0);
    });
  }

  // ─── API ──────────────────────────────────────────────
  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final res = await http
          .get(Uri.parse("$_BASE_URL/getSenderStats?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = canAccessGlobal ? (data['global'] ?? 0) : 0;
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  // ─── VALIDASI & SEND ──────────────────────────────────
  String? _formatPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final raw = targetController.text.trim();
    final bugId = _selectedBugId;

    if (_formatPhone(raw) == null) {
      _showDialog('Invalid Number',
          'Use international format.\nExample: +62812xxxxxxxx',
          Icons.error_outline_rounded, _C.neonRed);
      return;
    }
    if (_selectedSender == 'global' && !canAccessGlobal) {
      _showDialog('Access Denied',
          'Global Sender hanya untuk role tertentu!',
          Icons.lock_outline_rounded, _C.neonRed);
      return;
    }
    if (bugId == null || bugId.isEmpty) {
      _showDialog('No Bug', 'Pilih bug dulu.', Icons.bug_report_outlined,
          _C.neonRed);
      return;
    }

    setState(() => _isSending = true);

    try {
      final encoded = Uri.encodeComponent(raw);
      final url =
          '$_BASE_URL/sendBug?key=${widget.sessionKey}&target=$encoded&bug=$bugId'
          '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}';

      final res =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (!mounted) return;
      if (data['valid'] == false) {
        _showToast('error', 'Session invalid. Login ulang.');
      } else if (data['cooldown'] == true) {
        _showToast('warning', 'Cooldown! Tunggu ${data['wait'] ?? 0}s.');
      } else if (data['sended'] == true) {
        _showToast('success', 'Bug terkirim ke $raw!');
        targetController.clear();
      } else {
        _showToast('error', 'Gagal kirim.');
      }
    } catch (_) {
      _showToast('error', 'Koneksi error.');
    }

    if (mounted) setState(() => _isSending = false);
  }

  void _showToast(String type, String msg) {
    final colors = {
      'error': _C.neonRed,
      'success': _C.neonGreen,
      'warning': _C.neonGold,
      'info': _C.cyan,
    };
    final color = colors[type] ?? _C.cyan;
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg,
            style: const TextStyle(
              fontFamily: 'ShareTechMono',
              color: Colors.white,
              fontWeight: FontWeight.w600,
            )),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  void _showDialog(String title, String msg, IconData icon, Color color) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.78),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 320,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _C.blue.withOpacity(0.2),
                _C.black.withOpacity(0.4),
                color.withOpacity(0.15),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.4), blurRadius: 50),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.2),
                  border: Border.all(color: color, width: 2),
                ),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                    fontFamily: 'Orbitron',
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  )),
              const SizedBox(height: 8),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontFamily: 'ShareTechMono',
                    color: _C.textSecondary,
                    fontSize: 12,
                    height: 1.5,
                  )),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 44,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.blue,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('MENGERTI',
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.blackDeep,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // ── BACKGROUND: dashboard.png ──
          Positioned.fill(
            child: Image.asset(
              'assets/images/dashboard.png',
              fit: BoxFit.cover,
              opacity: const AlwaysStoppedAnimation(0.30),
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [_C.blackDeep, _C.navy, _C.blackDeep],
                  ),
                ),
              ),
            ),
          ),
          // Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _C.black.withOpacity(0.35),
                    _C.black.withOpacity(0.72),
                  ],
                ),
              ),
            ),
          ),
          // Glow
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _glowController,
              builder: (_, __) => Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0.7, -0.5),
                    radius: 1.5,
                    colors: [
                      _C.blue
                          .withOpacity(0.15 + _glowController.value * 0.05),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // CONTENT
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.only(bottom: 24),
                    child: Column(
                      children: [
                        _buildVortexCard(),
                        const SizedBox(height: 14),
                        _buildVideoBanner(),
                        const SizedBox(height: 12),
                        _buildStatusBar(),
                        const SizedBox(height: 14),
                        _buildSectionTitle('TARGET NUMBER'),
                        const SizedBox(height: 6),
                        _buildTargetPanel(),
                        const SizedBox(height: 12),
                        _buildSectionTitle('PILIH BUG  •  GESER ➜'),
                        const SizedBox(height: 6),
                        _buildBugCarousel(),
                        const SizedBox(height: 4),
                        _buildDots(),
                        const SizedBox(height: 10),
                        _buildSenderLabel(),
                        const SizedBox(height: 10),
                        _buildSenderGrid(),
                        const SizedBox(height: 14),
                        _buildSendButton(),
                        const SizedBox(height: 12),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HEADER ───────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _avatarRingController,
            builder: (_, __) {
              return Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(
                      colors: [_C.ice, _C.blueDark]),
                  boxShadow: [
                    BoxShadow(
                        color: _C.blue.withOpacity(0.7), blurRadius: 25),
                    BoxShadow(
                        color: _C.cyan.withOpacity(
                            0.4 + _avatarRingController.value * 0.4),
                        blurRadius: 40),
                  ],
                  border:
                      Border.all(color: _C.ice.withOpacity(0.6), width: 1.2),
                ),
                child: Transform.rotate(
                  angle: _avatarRingController.value * 6.2831,
                  child: const Icon(Icons.shield_rounded,
                      color: Colors.white, size: 18),
                ),
              );
            },
          ),
          const SizedBox(width: 12),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [_C.ice, _C.cyan],
            ).createShader(b),
            child: const Text('VOR4X',
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  letterSpacing: 5,
                )),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: roleColor, width: 1),
              boxShadow: [
                BoxShadow(
                    color: roleColor.withOpacity(0.5), blurRadius: 15),
              ],
            ),
            child: Text(roleDisplay,
                style: TextStyle(
                  fontFamily: 'ShareTechMono',
                  color: roleColor,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                )),
          ),
        ],
      ),
    );
  }

  // ─── VOR4X ACCOUNT CARD — MODERN HORIZONTAL ───────────
  Widget _buildVortexCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1A3A), Color(0xFF061225), Color(0xFF03060D)],
        ),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: _C.ice.withOpacity(0.45), width: 1.4),
        boxShadow: [
          BoxShadow(
              color: _C.blue.withOpacity(0.50),
              blurRadius: 35,
              spreadRadius: 1),
          BoxShadow(color: _C.cyan.withOpacity(0.20), blurRadius: 80),
        ],
      ),
      child: Stack(
        children: [
          // Banner subtle
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: Opacity(
                opacity: 0.15,
                child: Image.asset(
                  'assets/images/menu_header.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ),
          ),
          // Blue overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _C.blueDark.withOpacity(0.45),
                    _C.blue.withOpacity(0.20),
                    _C.blackDeep.withOpacity(0.70),
                  ],
                ),
              ),
            ),
          ),
          // Scan line
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: AnimatedBuilder(
                animation: _scanLineController,
                builder: (_, __) => Align(
                  alignment:
                      Alignment(0, -1.0 + _scanLineController.value * 2.0),
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          _C.cyan.withOpacity(0.08),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // CONTENT — logo kiri, info tengah, status kanan
          Row(
            children: [
              _buildVortexAvatar(),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      widget.username,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5,
                        height: 1.1,
                        shadows: [
                          Shadow(color: _C.cyan, blurRadius: 14),
                          Shadow(color: _C.blue, blurRadius: 24),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      roleDisplay,
                      style: const TextStyle(
                        fontFamily: 'ShareTechMono',
                        color: _C.textSecondary,
                        fontSize: 12.5,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today_rounded,
                          color: _C.cyan.withOpacity(0.9),
                          size: 13,
                        ),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            'Member since ${widget.expiredDate.isEmpty ? "01/01/2026" : widget.expiredDate}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'ShareTechMono',
                              color: _C.textSecondary,
                              fontSize: 11.5,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F2E1E),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _C.neonGreen.withOpacity(0.7),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _C.neonGreen.withOpacity(0.35),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _C.neonGreen,
                            boxShadow: [
                              BoxShadow(
                                  color: _C.neonGreen, blurRadius: 10),
                            ],
                          ),
                        ),
                        const SizedBox(width: 7),
                        const Text(
                          'Active',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            color: _C.neonGreen,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 8),
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [
                        _C.purple.withOpacity(0.20),
                        _C.blue.withOpacity(0.10),
                      ]),
                      border: Border.all(
                        color: _C.purple.withOpacity(0.5),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _C.purple.withOpacity(0.4),
                          blurRadius: 14,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.chevron_right_rounded,
                      color: _C.purple,
                      size: 22,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildVortexAvatar() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        final pulse = 0.5 + _pulseController.value * 0.5;
        return Container(
          width: 84,
          height: 84,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFF03060D),
            border: Border.all(color: _C.ice, width: 2),
            boxShadow: [
              BoxShadow(
                  color: _C.blue.withOpacity(0.9),
                  blurRadius: 18 + pulse * 8,
                  spreadRadius: 1),
              BoxShadow(
                  color: _C.cyan.withOpacity(0.5 + pulse * 0.3),
                  blurRadius: 30 + pulse * 12),
              BoxShadow(
                  color: _C.blueDark.withOpacity(0.6), blurRadius: 45),
            ],
          ),
          child: ClipOval(
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 62,
                  height: 62,
                  child: Image.asset(
                    'assets/images/menu_header.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => CustomPaint(
                      size: const Size(60, 60),
                      painter: _Vor4xLogoPainter(),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 6,
                  child: Text(
                    'VOR4X',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: _C.ice,
                      fontSize: 7,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      shadows: [
                        Shadow(
                            color: _C.cyan.withOpacity(0.9),
                            blurRadius: 8),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── VIDEO BANNER ─────────────────────────────────────
  Widget _buildVideoBanner() {
    return VisibilityDetector(
      key: const Key('video-banner'),
      onVisibilityChanged: (info) {
        if (info.visibleFraction > 0.1) {
          _videoController?.play();
        } else {
          _videoController?.pause();
        }
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 14),
        height: 220,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _C.ice.withOpacity(0.55), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: _C.blue.withOpacity(0.45),
                blurRadius: 50,
                offset: const Offset(0, 10)),
            BoxShadow(color: _C.cyan.withOpacity(0.20), blurRadius: 30),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_videoInitialized && _videoController != null)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController!.value.size.width,
                    height: _videoController!.value.size.height,
                    child: VideoPlayer(_videoController!),
                  ),
                )
              else
                Container(
                  color: _C.blackDeep,
                  child: const Center(
                    child: CircularProgressIndicator(color: _C.cyan),
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      _C.black.withOpacity(0.85),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 14,
                left: 14,
                child: GestureDetector(
                  onTap: _toggleSound,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      color: _C.black.withOpacity(0.75),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _isSoundOn ? _C.cyan : _C.cyanLight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (_isSoundOn ? _C.cyan : _C.cyanLight)
                              .withOpacity(0.4),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _isSoundOn
                              ? Icons.volume_up_rounded
                              : Icons.volume_off_rounded,
                          color: _isSoundOn ? _C.cyan : _C.cyanLight,
                          size: 13,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          _isSoundOn ? 'SUARA ON' : 'SUARA OFF',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            color: _isSoundOn ? _C.cyan : _C.cyanLight,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 14,
                right: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 11, vertical: 6),
                  decoration: BoxDecoration(
                    color: _C.black.withOpacity(0.65),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.cyan.withOpacity(0.7)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _pulsingDot(),
                      const SizedBox(width: 5),
                      const Text('PLAYING',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            color: _C.cyan,
                            letterSpacing: 1.5,
                          )),
                    ],
                  ),
                ),
              ),
              const Positioned(
                bottom: 16,
                left: 20,
                child: Row(
                  children: [
                    Icon(Icons.circle, color: _C.cyan, size: 8),
                    SizedBox(width: 10),
                    Text('VOR4X',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 3,
                        )),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── STATUS BAR ───────────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          _C.blue.withOpacity(0.10),
          _C.cyan.withOpacity(0.05),
        ]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.ice.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _pulsingDot(),
          const SizedBox(width: 8),
          const Text('Powered by ',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                color: Colors.white,
              )),
          const Text('@ZIL • @DANZ',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                color: _C.cyan,
                fontWeight: FontWeight.bold,
              )),
        ],
      ),
    );
  }

  // ─── SECTION TITLE ────────────────────────────────────
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.cyan,
              boxShadow: [BoxShadow(color: _C.cyan, blurRadius: 10)],
            ),
          ),
          const SizedBox(width: 10),
          Text(title,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                letterSpacing: 2,
              )),
        ],
      ),
    );
  }

  // ─── TARGET PANEL ─────────────────────────────────────
  Widget _buildTargetPanel() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          _C.blue.withOpacity(_targetFocused ? 0.20 : 0.10),
          _C.cyan.withOpacity(_targetFocused ? 0.10 : 0.05),
          _C.black.withOpacity(0.15),
        ]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: _targetFocused ? _C.cyan : _C.blue.withOpacity(0.40),
          width: _targetFocused ? 1.6 : 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: _C.blue.withOpacity(_targetFocused ? 0.40 : 0.15),
            blurRadius: _targetFocused ? 40 : 30,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.phone_android_rounded, color: _C.cyan, size: 14),
              SizedBox(width: 8),
              Text('MASUKKAN NOMOR',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 2,
                  )),
              Spacer(),
              Text('INTL FORMAT',
                  style: TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 9,
                    color: _C.textBlueMuted,
                  )),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 52,
            decoration: BoxDecoration(
              color: _C.black.withOpacity(0.30),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _targetFocused ? _C.cyan : _C.blue.withOpacity(0.40),
              ),
              boxShadow: _targetFocused
                  ? [
                      BoxShadow(
                          color: _C.cyan.withOpacity(0.35),
                          blurRadius: 20),
                    ]
                  : null,
            ),
            child: Row(
              children: [
                const SizedBox(width: 14),
                Icon(Icons.language,
                    color: _targetFocused ? _C.cyan : _C.cyanLight,
                    size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: targetController,
                    focusNode: _targetFocus,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(
                      fontFamily: 'ShareTechMono',
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                    cursorColor: _C.cyan,
                    decoration: InputDecoration(
                      hintText: '+62812xxxxxxxx',
                      hintStyle: TextStyle(
                        color: _C.textMuted.withOpacity(0.6),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.only(bottom: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUG CAROUSEL ─────────────────────────────────────
  Widget _buildBugCarousel() {
    if (widget.listBug.isEmpty) return const SizedBox(height: 200);
    return SizedBox(
      height: 200,
      child: PageView.builder(
        controller: _bugPageController,
        physics: const BouncingScrollPhysics(),
        onPageChanged: (i) => setState(() => _currentBugIndex = i),
        itemCount: widget.listBug.length,
        itemBuilder: (_, i) => _buildBugCard(i),
      ),
    );
  }

  Widget _buildBugCard(int index) {
    final bug = widget.listBug[index];
    final bugId = bug['bug_id'] as String? ?? '$index';
    final bugName = bug['bug_name'] as String? ?? 'VOR4X';
    final isSelected = _currentBugIndex == index;
    final neon = _C.neonFor(index);

    return AnimatedScale(
      scale: isSelected ? 1.0 : 0.86,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: neon.withOpacity(isSelected ? 0.85 : 0.35),
              blurRadius: isSelected ? 35 : 18,
              spreadRadius: isSelected ? 2 : 1,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      neon.withOpacity(isSelected ? 0.55 : 0.35),
                      neon.withOpacity(0.15),
                      _C.black.withOpacity(0.85),
                    ],
                  ),
                ),
              ),
              Positioned.fill(
                child: CustomPaint(
                  painter: _WebPatternPainter(
                    color: _C.ice.withOpacity(isSelected ? 0.35 : 0.18),
                  ),
                ),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        _C.black.withOpacity(0.30),
                        _C.black.withOpacity(0.65),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: isSelected ? _C.ice : neon.withOpacity(0.75),
                    width: isSelected ? 2.0 : 1.4,
                  ),
                ),
              ),
              Positioned(top: 8, left: 8, child: _corner(neon, true, true)),
              Positioned(top: 8, right: 8, child: _corner(neon, true, false)),
              Positioned(
                  bottom: 8, left: 8, child: _corner(neon, false, true)),
              Positioned(
                  bottom: 8, right: 8, child: _corner(neon, false, false)),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: _C.ice,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                  color: neon.withOpacity(0.8),
                                  blurRadius: 18),
                            ],
                          ),
                          child: const Icon(Icons.bug_report_rounded,
                              color: _C.black, size: 24),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: _C.black.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: neon, width: 1),
                          ),
                          child: Text(
                            bugId.startsWith('#') ? bugId : '#$bugId',
                            style: TextStyle(
                              fontFamily: 'Orbitron',
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              color: neon,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Center(
                      child: Text(
                        bugName.toUpperCase(),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 1.8,
                          height: 1.2,
                          shadows: [
                            Shadow(color: Colors.black, blurRadius: 16),
                          ],
                        ),
                      ),
                    ),
                    const Spacer(),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 9, vertical: 5),
                          decoration: BoxDecoration(
                            color: _C.black.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: neon.withOpacity(0.6), width: 0.8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.circle,
                                  color: _C.neonGreen, size: 6),
                              SizedBox(width: 5),
                              Text('connected',
                                  style: TextStyle(
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    color: _C.ice,
                                  )),
                            ],
                          ),
                        ),
                        const Spacer(),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          width: isSelected ? 30 : 24,
                          height: isSelected ? 30 : 24,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: isSelected
                                ? const LinearGradient(colors: [
                                    _C.neonGreen,
                                    Color(0xFF00E5A0)
                                  ])
                                : null,
                            color: isSelected
                                ? null
                                : _C.black.withOpacity(0.70),
                            border: Border.all(
                              color: isSelected
                                  ? _C.ice
                                  : _C.ice.withOpacity(0.4),
                              width: 1.5,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: _C.neonGreen.withOpacity(0.9),
                                      blurRadius: 18,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Icon(
                            Icons.check_rounded,
                            color: isSelected
                                ? _C.black
                                : _C.ice.withOpacity(0.3),
                            size: isSelected ? 16 : 13,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _corner(Color c, bool top, bool left) {
    return SizedBox(
      width: 20,
      height: 20,
      child: CustomPaint(
        painter: _CornerPainter(color: c, top: top, left: left),
      ),
    );
  }

  // ─── DOTS ─────────────────────────────────────────────
  Widget _buildDots() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(widget.listBug.length, (i) {
          final neon = _C.neonFor(i);
          final active = i == _currentBugIndex;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 350),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: active ? 26 : 6,
            height: 6,
            decoration: BoxDecoration(
              color: active ? neon : neon.withOpacity(0.3),
              borderRadius: BorderRadius.circular(4),
              boxShadow: active
                  ? [BoxShadow(color: neon, blurRadius: 12)]
                  : null,
            ),
          );
        }),
      ),
    );
  }

  // ─── SENDER LABEL ─────────────────────────────────────
  Widget _buildSenderLabel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  _C.cyan.withOpacity(0.7),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          const SizedBox(width: 10),
          _pulsingDot(),
          const SizedBox(width: 10),
          const Text('PILIH SENDER',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: _C.ice,
                letterSpacing: 2.5,
              )),
          const SizedBox(width: 10),
          _pulsingDot(),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  Colors.transparent,
                  _C.cyan.withOpacity(0.7),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SENDER GRID ──────────────────────────────────────
  Widget _buildSenderGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: _buildSenderBtn(
              idx: 0,
              icon: Icons.person_rounded,
              label: 'PRIBADI',
              count: _privateSenderCount,
              accent: _C.cyan,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildSenderBtn(
              idx: 1,
              icon: Icons.public_rounded,
              label: 'GLOBAL',
              count: _globalSenderCount,
              accent: _C.purple,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderBtn({
    required int idx,
    required IconData icon,
    required String label,
    required int count,
    required Color accent,
  }) {
    final isSelected = _selectedSenderIndex == idx;
    final isLocked = idx == 1 && !canAccessGlobal;

    return GestureDetector(
      onTap: () {
        if (isLocked) {
          _showDialog(
            'Access Denied',
            'Global Sender hanya untuk role tertentu!',
            Icons.lock_outline_rounded,
            _C.neonRed,
          );
          return;
        }
        setState(() => _selectedSenderIndex = idx);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(colors: [
                  accent.withOpacity(0.28),
                  _C.blue.withOpacity(0.10),
                ])
              : LinearGradient(colors: [
                  _C.blue.withOpacity(0.10),
                  _C.black.withOpacity(0.35),
                ]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? accent : _C.blueLight.withOpacity(0.4),
            width: 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                      color: accent.withOpacity(0.75),
                      blurRadius: 28,
                      spreadRadius: 1),
                ]
              : [
                  BoxShadow(
                      color: _C.blue.withOpacity(0.2), blurRadius: 16),
                ],
        ),
        child: Opacity(
          opacity: isLocked ? 0.55 : 1,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? accent.withOpacity(0.22)
                          : _C.cyan.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected
                            ? accent
                            : _C.blueLight.withOpacity(0.5),
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                  color: accent.withOpacity(0.7),
                                  blurRadius: 16),
                            ]
                          : null,
                    ),
                    child: Icon(
                      icon,
                      color: isSelected ? accent : _C.textBlueMuted,
                      size: 18,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(label,
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                        color: isSelected ? accent : _C.textBlueMuted,
                      )),
                  const SizedBox(height: 4),
                  Text(
                    count == 0 ? '✕ Kosong' : '$count active',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      color: isSelected
                          ? accent.withOpacity(0.9)
                          : _C.textBlueMuted.withOpacity(0.65),
                    ),
                  ),
                ],
              ),
              if (isLocked)
                Positioned(
                  top: -8,
                  right: -8,
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.neonRed,
                      boxShadow: [
                        BoxShadow(color: _C.neonRed, blurRadius: 14),
                      ],
                    ),
                    child: const Icon(Icons.lock_rounded,
                        color: Colors.white, size: 11),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SEND BUTTON ──────────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 14),
        height: 58,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: _isSending
              ? null
              : LinearGradient(colors: [
                  _C.blue.withOpacity(0.9),
                  _C.blueDark.withOpacity(0.85),
                  _C.cyan.withOpacity(0.75),
                ]),
          color: _isSending ? _C.black.withOpacity(0.30) : null,
          boxShadow: _isSending
              ? []
              : [
                  BoxShadow(
                    color: _C.blue.withOpacity(
                        0.65 + _pulseController.value * 0.25),
                    blurRadius: 30 + _pulseController.value * 15,
                    spreadRadius: 3,
                    offset: const Offset(0, 8),
                  ),
                ],
          border: Border.all(
            color: _isSending
                ? _C.blue.withOpacity(0.4)
                : _C.ice.withOpacity(0.7),
            width: 1.2,
          ),
        ),
        child: ElevatedButton(
          onPressed: _isSending ? null : _sendBug,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
          ),
          child: _isSending
              ? const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2)),
                    SizedBox(width: 12),
                    Text('SENDING...',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                          letterSpacing: 1.5,
                        )),
                  ],
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.rocket_launch_rounded,
                        color: Colors.white, size: 20),
                    SizedBox(width: 10),
                    Text('SEND BUG',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          letterSpacing: 2.5,
                        )),
                  ],
                ),
        ),
      ),
    );
  }

  // ─── FOOTER ───────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('© VOR4X 2026',
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                color: _C.textMuted.withOpacity(0.7),
                fontSize: 9,
                letterSpacing: 1,
              )),
          const SizedBox(width: 8),
          Container(
            width: 3,
            height: 3,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.cyan.withOpacity(0.7),
            ),
          ),
          const SizedBox(width: 8),
          Text(roleDisplay,
              style: TextStyle(
                fontFamily: 'ShareTechMono',
                color: roleColor.withOpacity(0.9),
                fontSize: 9,
                fontWeight: FontWeight.w700,
              )),
        ],
      ),
    );
  }

  Widget _pulsingDot() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) => Container(
        width: 6,
        height: 6,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _C.cyan,
          boxShadow: [
            BoxShadow(
                color:
                    _C.cyan.withOpacity(0.5 + _pulseController.value * 0.5),
                blurRadius: 10),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🎨 CUSTOM PAINTERS
// ═══════════════════════════════════════════════════════════

class _WebPatternPainter extends CustomPainter {
  final Color color;
  _WebPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    final center = Offset(size.width * 0.5, size.height * 0.45);
    const spokes = 8;

    for (int i = 0; i < spokes; i++) {
      final angle = (i / spokes) * 3.14159 * 2;
      final end = Offset(
        center.dx + size.width * 0.9 * _cos(angle),
        center.dy + size.height * 0.9 * _sin(angle),
      );
      canvas.drawLine(center, end, paint);
    }

    for (int r = 1; r <= 3; r++) {
      final radius = (size.width / 2) * (r / 3.5);
      final path = Path();
      for (int i = 0; i <= spokes; i++) {
        final angle = (i / spokes) * 3.14159 * 2;
        final x = center.dx + radius * _cos(angle);
        final y = center.dy + radius * _sin(angle);
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  double _cos(double x) {
    while (x > 3.14159) x -= 3.14159 * 2;
    while (x < -3.14159) x += 3.14159 * 2;
    double result = 1, term = 1;
    for (int i = 1; i < 8; i++) {
      term *= -x * x / ((2 * i - 1) * (2 * i));
      result += term;
    }
    return result;
  }

  double _sin(double x) {
    while (x > 3.14159) x -= 3.14159 * 2;
    while (x < -3.14159) x += 3.14159 * 2;
    double result = x, term = x;
    for (int i = 1; i < 8; i++) {
      term *= -x * x / ((2 * i) * (2 * i + 1));
      result += term;
    }
    return result;
  }

  @override
  bool shouldRepaint(covariant _WebPatternPainter old) => old.color != color;
}

class _CornerPainter extends CustomPainter {
  final Color color;
  final bool top;
  final bool left;
  _CornerPainter({
    required this.color,
    required this.top,
    required this.left,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    if (top && left) {
      path.moveTo(0, size.height);
      path.lineTo(0, 0);
      path.lineTo(size.width, 0);
    } else if (top && !left) {
      path.moveTo(0, 0);
      path.lineTo(size.width, 0);
      path.lineTo(size.width, size.height);
    } else if (!top && left) {
      path.moveTo(0, 0);
      path.lineTo(0, size.height);
      path.lineTo(size.width, size.height);
    } else {
      path.moveTo(0, size.height);
      path.lineTo(size.width, size.height);
      path.lineTo(size.width, 0);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _CornerPainter old) =>
      old.color != color || old.top != top || old.left != left;
}

class _Vor4xLogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Shield outline
    final shieldPath = Path()
      ..moveTo(w * 0.5, h * 0.08)
      ..lineTo(w * 0.88, h * 0.25)
      ..lineTo(w * 0.88, h * 0.62)
      ..lineTo(w * 0.5, h * 0.92)
      ..lineTo(w * 0.12, h * 0.62)
      ..lineTo(w * 0.12, h * 0.25)
      ..close();

    canvas.drawPath(
      shieldPath,
      Paint()
        ..color = const Color(0xFF00D4FF).withOpacity(0.14)
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      shieldPath,
      Paint()
        ..color = const Color(0xFF64B5F6)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2,
    );

    // Wolf head outline
    final headPaint = Paint()
      ..color = const Color(0xFF64B5F6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final leftEar = Path()
      ..moveTo(w * 0.28, h * 0.32)
      ..lineTo(w * 0.30, h * 0.18)
      ..lineTo(w * 0.42, h * 0.28);
    canvas.drawPath(leftEar, headPaint);

    final rightEar = Path()
      ..moveTo(w * 0.72, h * 0.32)
      ..lineTo(w * 0.70, h * 0.18)
      ..lineTo(w * 0.58, h * 0.28);
    canvas.drawPath(rightEar, headPaint);

    final face = Path()
      ..moveTo(w * 0.28, h * 0.32)
      ..quadraticBezierTo(w * 0.25, h * 0.55, w * 0.38, h * 0.65)
      ..lineTo(w * 0.50, h * 0.72)
      ..lineTo(w * 0.62, h * 0.65)
      ..quadraticBezierTo(w * 0.75, h * 0.55, w * 0.72, h * 0.32);
    canvas.drawPath(face, headPaint);

    // Eyes
    final eyePaint = Paint()..color = const Color(0xFF00D4FF);
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(w * 0.40, h * 0.45),
        width: w * 0.08,
        height: h * 0.05,
      ),
      eyePaint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(w * 0.60, h * 0.45),
        width: w * 0.08,
        height: h * 0.05,
      ),
      eyePaint,
    );

    // Nose
    final nose = Path()
      ..moveTo(w * 0.48, h * 0.55)
      ..lineTo(w * 0.52, h * 0.55)
      ..lineTo(w * 0.50, h * 0.58)
      ..close();
    canvas.drawPath(nose, Paint()..color = const Color(0xFF00D4FF));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}