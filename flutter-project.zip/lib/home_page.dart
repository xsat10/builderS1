import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';
import 'bug_sender.dart';
import 'config.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;

  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;

  // ============ TEMA HITAM TOTAL ============
  final Color primaryBg = const Color(0xFF050505);
  final Color cardBg = const Color(0xFF050505);
  final Color sectionBg = const Color(0xFF0A0A0A);
  final Color accentGreen = const Color(0xFF2ECC71);
  final Color accentPurple = const Color(0xFF7C4DFF);
  final Color accentCyan = const Color(0xFF00BCD4);
  final Color textMain = Colors.white;
  final Color textSub = Colors.white70;
  final Color textHint = Colors.white38;
  final Color dangerRed = const Color(0xFFFF5252);
  final Color silverLight = const Color(0xFFE0E0E0);

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip')
        ? _senderMode
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    CustomPopup.display(
      context,
      title: title,
      message: msg,
      icon: title.contains("✅") ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: title.contains("✅") ? accentCyan : dangerRed,
      confirmText: "Close",
    );
  }

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentGreen.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: accentGreen.withOpacity(0.03),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: accentGreen.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: accentGreen.withOpacity(0.3)),
            ),
            child: Icon(Icons.bug_report_outlined, color: accentGreen, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "WHATSAPP CRASH",
                  style: TextStyle(
                    color: textMain,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(
                    color: textSub,
                    fontFamily: 'ShareTechMono',
                    fontSize: 11,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectionButton({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: sectionBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accentGreen.withOpacity(0.15)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: accentGreen, size: 28),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textSub,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: TextStyle(
                      color: textMain,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.keyboard_arrow_right_rounded, color: textSub, size: 28),
          ],
        ),
      ),
    );
  }

  Widget _buildPopupOption({
    required IconData icon,
    required Color color,
    required String title,
    String? sub,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white.withOpacity(0.05)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  if (sub != null)
                    Text(
                      sub,
                      style: TextStyle(
                        color: textSub,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: textHint, size: 14),
          ],
        ),
      ),
    );
  }

  void _showTargetTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
              border: Border.all(color: accentGreen.withOpacity(0.2)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "PILIH TARGET",
                  style: TextStyle(
                    color: textMain,
                    fontFamily: 'Orbitron',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.phone_android_rounded,
                  color: accentGreen,
                  title: "BUG NOMOR",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "number";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
                const SizedBox(height: 12),
                _buildPopupOption(
                  icon: Icons.group_add,
                  color: accentPurple,
                  title: "BUG GROUP",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "group";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSenderTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
              border: Border.all(color: accentGreen.withOpacity(0.2)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "PILIH SENDER",
                  style: TextStyle(
                    color: textMain,
                    fontFamily: 'Orbitron',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.person_outline,
                  color: accentCyan,
                  title: "PRIVATE ($_privateSenderCount Active)",
                  onTap: () {
                    setState(() => _senderMode = 'private');
                    Navigator.pop(context);
                  },
                ),
                const SizedBox(height: 12),
                _buildPopupOption(
                  icon: Icons.public,
                  color: accentPurple,
                  title: "GLOBAL ($_globalSenderCount Active)",
                  onTap: () {
                    setState(() => _senderMode = 'global');
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSelectionButton(
          title: "TARGET TYPE",
          value: _selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP",
          icon: _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.group_add,
          onTap: _showTargetTypePopup,
        ),
        const SizedBox(height: 16),

        _buildSelectionButton(
          title: "MANAGE ACTIVE SENDERS",
          value: "MANAGE BUG SENDER",
          icon: Icons.sensors,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BugSenderPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.role,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 16),

        if (widget.role == 'owner' || widget.role == 'vip') ...[
          _buildSelectionButton(
            title: "SENDER MODE",
            value: _senderMode == 'private' ? "PRIVATE SENDER" : "GLOBAL SENDER",
            icon: _senderMode == 'private' ? Icons.person_outline : Icons.public,
            onTap: _showSenderTypePopup,
          ),
          const SizedBox(height: 24),
        ],

        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            style: TextStyle(
              color: textSub,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),

        TextField(
          controller: targetController,
          style: TextStyle(color: textMain, fontSize: 16),
          cursorColor: accentGreen,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "e.g. +628xxxxxxxx"
                : "e.g. https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textHint),
            filled: true,
            fillColor: sectionBg,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: accentGreen.withOpacity(0.15)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: accentGreen.withOpacity(0.15)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide(color: accentGreen, width: 1.5),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
              color: accentGreen,
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
          ),
        ),

        const SizedBox(height: 24),

        if (availableBugs.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "SELECT PAYLOAD BUG",
              style: TextStyle(
                color: textSub,
                fontWeight: FontWeight.bold,
                fontSize: 12,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            decoration: BoxDecoration(
              color: sectionBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: accentGreen.withOpacity(0.15)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: sectionBg,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: textSub),
                iconSize: 28,
                style: TextStyle(
                  color: textMain,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'ShareTechMono',
                ),
                items: availableBugs.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Row(
                      children: [
                        Icon(Icons.bug_report, color: accentGreen, size: 20),
                        const SizedBox(width: 12),
                        Expanded(child: Text(bug['bug_name'])),
                      ],
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value ?? "";
                  });
                },
              ),
            ),
          ),
        ] else ...[
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "No payload available for this mode.",
                style: TextStyle(color: textSub),
              ),
            ),
          )
        ]
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: accentGreen.withOpacity(0.2)),
            color: accentGreen.withOpacity(0.03),
            boxShadow: [
              BoxShadow(
                color: accentGreen.withOpacity(0.03 * _pulseController.value),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
            ),
            child: _isSending
                ? SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: accentGreen,
                      strokeWidth: 2,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_outlined, color: silverLight, size: 20),
                      const SizedBox(width: 12),
                      Text(
                        "LAUNCH ATTACK",
                        style: TextStyle(
                          color: silverLight, // SILVER TERANG #E0E0E0
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTopHeader(),
              const SizedBox(height: 20),

              if (_videoController != null && _videoController!.value.isInitialized)
                Container(
                  height: 220,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: accentGreen.withOpacity(0.15), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: SizedBox.expand(
                      child: FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoController!.value.size.width,
                          height: _videoController!.value.size.height,
                          child: VideoPlayer(_videoController!),
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 20),

              _buildInputPanel(),
              const SizedBox(height: 30),

              _buildSendButton(),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}