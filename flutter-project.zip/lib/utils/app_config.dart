class AppConfig {
  AppConfig._();

  // Raw URL GitHub Gist berisi 1 baris: URL server (mis. https://server.domainmu.com)
  // Ganti isi Gist => semua APK otomatis pakai server baru tanpa rebuild.
  static const String remoteConfigUrl =
      'https://gist.githubusercontent.com/kamu';
 
  static const String buyNowUrl = 'https://t.me/info_alexyusomo';
  static const String createNovaBotUrl = 'https://t.me/createnova_bot';
  static const String developerWhatsAppUrl = 'https://wa.me/6285760472601';
  static const String developerTelegramUrl = 'https://t.me/alexyusomo';
  static const String developerGithubUrl = 'https://github.com/alexyusomo';
}
