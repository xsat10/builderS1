import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:open_file/open_file.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

const String versionUrl =
    'https://raw.githubusercontent.com/seishiro9/server1/refs/heads/main/srv1.json';

Future<void> checkForUpdate(BuildContext context) async {
  try {
    final dio = Dio();
    final res = await dio.get(versionUrl);
    
    // Parse JSON jika response adalah string
    final data = res.data is String 
        ? jsonDecode(res.data) as Map<String, dynamic>
        : res.data as Map<String, dynamic>;

    final info = await PackageInfo.fromPlatform();
    final currentBuild = int.tryParse(info.buildNumber) ?? 0;
    final latestBuild = int.tryParse(data['build'].toString()) ?? 0;

    print("🔍 Current: $currentBuild, Latest: $latestBuild");

    if (latestBuild > currentBuild) {
      if (!context.mounted) return;
      _showUpdateDialog(context, data);
    }
  } catch (e) {
    print("❌ Update check error: $e");
  }
}

void _showUpdateDialog(BuildContext context, Map<String, dynamic> data) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => _UpdateDialog(data: data),
  );
}

class _UpdateDialog extends StatefulWidget {
  final Map<String, dynamic> data;
  const _UpdateDialog({required this.data});

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  double _progress = 0;
  bool _downloading = false;
  String _status = '';

Future<void> _download() async {
  try {
    final uri = Uri.parse(widget.data['apk_url']);
    await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    );
  } catch (e) {
    setState(() { _status = 'Gagal buka link'; });
  }
}

@override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF1A1A1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(children: [
        const Icon(Icons.system_update, color: Color(0xFF9E9E9E), size: 28),
        const SizedBox(width: 10),
        const Text('Update Wajib',
            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(
          'Versi ${widget.data['version']} telah tersedia! Anda wajib memperbarui aplikasi untuk dapat menggunakannya.',
          style: const TextStyle(color: Colors.white70, fontSize: 14),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.withOpacity(0.4)),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            widget.data['changelog'] ?? '',
            style: const TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ),
        if (_downloading) ...[
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: _progress,
            backgroundColor: Colors.white12,
            valueColor: const AlwaysStoppedAnimation(Color(0xFF9E9E9E)),
          ),
          const SizedBox(height: 8),
          Text('${(_progress * 100).toStringAsFixed(0)}% — $_status',
              style: const TextStyle(color: Colors.white38, fontSize: 12)),
        ],
      ]),
      actions: [
        if (!_downloading)
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.download, color: Colors.white),
              label: const Text('Download Update',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF616161),
                side: const BorderSide(color: Color(0xFF9E9E9E)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onPressed: _download,
            ),
          ),
      ],
    );
  }
}