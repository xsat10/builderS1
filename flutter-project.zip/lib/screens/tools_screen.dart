import '../theme.dart';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:provider/provider.dart';

import '../services/api_service.dart';
import '../providers/theme_provider.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_royal_frame.dart';
import '../widgets/roman_sheet.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scene_background.dart';
import '../widgets/scroll_clearance.dart';
import 'tools/anime_page.dart';
import 'tools/catbox_uploader_page.dart';
import 'tools/comic_page.dart';
import 'tools/converter_page.dart';
import 'tools/domain_page.dart';
import 'tools/encryption_base64_page.dart';
import 'tools/fake_identity_page.dart';
import 'tools/instagram_page.dart';
import 'tools/ip_geo_page.dart';
import 'tools/iqc_page.dart';
import 'tools/qr_gen_page.dart';
import 'tools/speed_test_page.dart';
import 'tools/spotify_downloader_page.dart';
import 'tools/tiktok_page.dart';
import 'tools/web_scanner_page.dart';
import 'tools/youtube_downloader_page.dart';

// ─── Roman Imperial Palette ────────────────────────────────────────────────
class _Rome {
  _Rome._();

  static const Color purple = Color(0xFF2B1A3C);
  static const Color purpleDeep = Color(0xFF180E26);
  static const Color purpleVelvet = Color(0xFF3E2554);
  static const Color gold = Color(0xFFFFD98A);
  static const Color goldDeep = Color(0xFFBB8C2E);
  static const Color ivory = Color(0xFFFBF5E6);
  static const Color bronze = Color(0xFF9C7B4E);
  static const Color ember = Color(0xFFFFA14B);
  static const Color jade = Color(0xFF4DD0A8);
}

class _RomeStyle {
  _RomeStyle._();

  static const double archRadius = 26;
  static const double baseRadius = 12;
  static const Color hairline = Color(0x66FFD98A);
}

class _Laurel {
  static const String mark = '\u2766'; // â¦
  static const String cross = '\u2726'; // âœ¦
}

// ─── Tool Definitions ──────────────────────────────────────────────────────
class _ToolDef {
  final String? id;
  final IconData icon;
  final String title;
  final String subtitle;
  final Category cat;
  final Widget Function()? page;

  const _ToolDef.api({
    required this.id,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.cat,
  }) : page = null;

  const _ToolDef.page({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.cat,
    required this.page,
  }) : id = null;

  bool get isApi => id != null;
}

enum Category { osint, opus, media, arena }

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  static final List<_ToolDef> _osintTools = [
    _ToolDef.api(
      id: 'ip',
      icon: Icons.dns_outlined,
      title: 'IP Lookup',
      subtitle: 'Info detail sebuah IP publik',
      cat: Category.osint,
    ),
    _ToolDef.api(
      id: 'myip',
      icon: Icons.wifi_tethering,
      title: 'My IP',
      subtitle: 'Cek IP publik koneksi kamu',
      cat: Category.osint,
    ),
    _ToolDef.api(
      id: 'phone',
      icon: Icons.phone_outlined,
      title: 'Phone Lookup',
      subtitle: 'Validasi & info nomor telepon',
      cat: Category.osint,
    ),
    _ToolDef.api(
      id: 'email',
      icon: Icons.alternate_email,
      title: 'Email Check',
      subtitle: 'Cek validitas dan status email',
      cat: Category.osint,
    ),
    _ToolDef.api(
      id: 'domain',
      icon: Icons.language_outlined,
      title: 'Domain WHOIS',
      subtitle: 'Info kepemilikan domain',
      cat: Category.osint,
    ),
    _ToolDef.api(
      id: 'pwned',
      icon: Icons.shield_outlined,
      title: 'Pwned Password',
      subtitle: 'Cek password pernah bocor di breach',
      cat: Category.osint,
    ),
    _ToolDef.page(
      icon: Icons.public,
      title: 'IP Geo',
      subtitle: 'Geolokasi lengkap sebuah IP + peta',
      cat: Category.osint,
      page: () => const IpGeoPage(),
    ),
    _ToolDef.page(
      icon: Icons.developer_board,
      title: 'Domain OSINT',
      subtitle: 'Subdomain & record dari sebuah domain',
      cat: Category.osint,
      page: () => const DomainOsintPage(),
    ),
    _ToolDef.page(
      icon: Icons.radar_outlined,
      title: 'Web Scanner',
      subtitle: 'Scan keamanan sederhana website',
      cat: Category.osint,
      page: () => const WebScannerPage(),
    ),
    _ToolDef.api(
      id: 'dns',
      icon: Icons.dns_outlined,
      title: 'DNS Lookup',
      subtitle: 'Resolve A record sebuah host',
      cat: Category.osint,
    ),
  ];

  static final List<_ToolDef> _opusTools = [
    _ToolDef.api(
      id: 'qr',
      icon: Icons.qr_code_2,
      title: 'QR Code',
      subtitle: 'Buat QR code dari teks atau URL',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'shorten',
      icon: Icons.link_outlined,
      title: 'Link Shortener',
      subtitle: 'Perpendek tautan via is.gd',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'currency',
      icon: Icons.currency_exchange,
      title: 'Currency Converter',
      subtitle: 'Konversi USD ke mata uang lain',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'password',
      icon: Icons.password_outlined,
      title: 'Password Generator',
      subtitle: 'Buat password acak yang kuat',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'weather',
      icon: Icons.cloud_outlined,
      title: 'Weather',
      subtitle: 'Cuaca terkini sebuah kota',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'dictionary',
      icon: Icons.menu_book_outlined,
      title: 'Dictionary',
      subtitle: 'Arti kata bahasa Inggris',
      cat: Category.opus,
    ),
    _ToolDef.api(
      id: 'isbn',
      icon: Icons.book_outlined,
      title: 'ISBN Lookup',
      subtitle: 'Info buku dari nomor ISBN',
      cat: Category.opus,
    ),
    _ToolDef.page(
      icon: Icons.swap_vert,
      title: 'Converter',
      subtitle: 'Konversi unit, suhu, kecepatan & data',
      cat: Category.opus,
      page: () => const ConverterPage(),
    ),
    _ToolDef.page(
      icon: Icons.lock_outlined,
      title: 'Base64',
      subtitle: 'Enkripsi / dekripsi Base64',
      cat: Category.opus,
      page: () => const EncryptionRavenClawx(),
    ),
    _ToolDef.page(
      icon: Icons.badge_outlined,
      title: 'Fake Identity',
      subtitle: 'Generator identitas palsu acak',
      cat: Category.opus,
      page: () => const FakeIdentityPage(),
    ),
    _ToolDef.page(
      icon: Icons.cloud_upload_outlined,
      title: 'Catbox Upload',
      subtitle: 'Upload media ke catbox.moe',
      cat: Category.opus,
      page: () => CatboxUploaderPage(username: 'GUEST', role: 'member'),
    ),
    _ToolDef.page(
      icon: Icons.speed_outlined,
      title: 'Speed Test',
      subtitle: 'Uji kecepatan internet kamu',
      cat: Category.opus,
      page: () => const SpeedTestPage(),
    ),
    _ToolDef.page(
      icon: Icons.qr_code,
      title: 'QR Creator',
      subtitle: 'Buat QR & simpan ke galeri',
      cat: Category.opus,
      page: () => const QrGeneratorPage(),
    ),
  ];

  static final List<_ToolDef> _mediaTools = [
    _ToolDef.page(
      icon: Icons.live_tv_outlined,
      title: 'Anime',
      subtitle: 'Streaming anime + riwayat nonton',
      cat: Category.media,
      page: () => const HomeAnimePage(),
    ),
    _ToolDef.page(
      icon: Icons.auto_stories_outlined,
      title: 'Comic',
      subtitle: 'Baca komik manga online',
      cat: Category.media,
      page: () => const ComicPage(),
    ),
    _ToolDef.page(
      icon: Icons.play_circle_outline,
      title: 'YouTube Download',
      subtitle: 'Download video YouTube',
      cat: Category.media,
      page: () => const YoutubeDownloaderPage(),
    ),
    _ToolDef.page(
      icon: Icons.album_outlined,
      title: 'Spotify Download',
      subtitle: 'Download lagu Spotify',
      cat: Category.media,
      page: () => const SpotifyDownloaderPage(),
    ),
    _ToolDef.page(
      icon: Icons.music_video_outlined,
      title: 'TikTok Download',
      subtitle: 'Download video TikTok tanpa watermark',
      cat: Category.media,
      page: () => const TiktokDownloaderPage(),
    ),
    _ToolDef.page(
      icon: Icons.camera_alt_outlined,
      title: 'Instagram Download',
      subtitle: 'Download reels / foto Instagram',
      cat: Category.media,
      page: () => const InstagramDownloaderPage(),
    ),
  ];

  static final List<_ToolDef> _arenaTools = [
    _ToolDef.page(
      icon: Icons.chat_bubble_outline,
      title: 'IQC Screen',
      subtitle: 'Generator fake chat / screenshot',
      cat: Category.arena,
      page: () => const IQCScreen(),
    ),
  ];

  void _runBottomSheet(BuildContext context, _ToolDef tool) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: _Rome.purpleDeep,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(_RomeStyle.archRadius),
        ),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: _ToolRunnerSheet(tool: tool),
      ),
    );
  }

  void _openPage(BuildContext context, _ToolDef tool) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => tool.page!()));
  }

  void _onTap(BuildContext context, _ToolDef tool) {
    if (tool.isApi) {
      _runBottomSheet(context, tool);
    } else {
      _openPage(context, tool);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SceneBackground(
      theme: FeatureConfig.tools,
      screenIndex: FeatureConfig.toolsIndex,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  14,
                  6,
                  14,
                  ScrollClearance.bottomNav(context),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const RomanTitle('TOOLS', icon: Icons.handyman_outlined),
                    const SizedBox(height: 12),
                    const _LaurelDivider(),
                    const SizedBox(height: 10),
                    _RomanSection(
                      numeral: 'I',
                      title: 'OSINT · INTEL',
                      subtitle: 'konstantin agung — pengumpul info',
                      tools: _osintTools,
                      onTap: (t) => _onTap(context, t),
                    ),
                    const SizedBox(height: 20),
                    _RomanSection(
                      numeral: 'II',
                      title: 'UTILITAS · OPUS',
                      subtitle: 'jalan appia — karya & perkakas',
                      tools: _opusTools,
                      onTap: (t) => _onTap(context, t),
                    ),
                    const SizedBox(height: 20),
                    _RomanSection(
                      numeral: 'III',
                      title: 'MEDIA · THEATRUM',
                      subtitle: 'rodeo maximus — hiburan sang raja',
                      tools: _mediaTools,
                      onTap: (t) => _onTap(context, t),
                    ),
                    const SizedBox(height: 20),
                    _RomanSection(
                      numeral: 'IV',
                      title: 'ARENA · LUDUS',
                      subtitle: 'aula gladiator — permainan pedang',
                      tools: _arenaTools,
                      onTap: (t) => _onTap(context, t),
                    ),
                    const SizedBox(height: 8),
                    const _SenateFooter(),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Laurel Divider ────────────────────────────────────────────────────────
class _LaurelDivider extends StatelessWidget {
  const _LaurelDivider();

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Row(
      children: [
        Expanded(
          child: Divider(color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.45) : _RomeStyle.hairline, thickness: 1),
        ),
        const SizedBox(width: 12),
        Text(
          '${_Laurel.mark}  ${_Laurel.cross}  ${_Laurel.mark}',
          style: TextStyle(
            color: skin.isBubbleGum ? palette.primary : _Rome.gold,
            fontSize: 13,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Divider(color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.45) : _RomeStyle.hairline, thickness: 1),
        ),
      ],
    );
  }
}

// ─── Roman Section ─────────────────────────────────────────────────────────
class _RomanSection extends StatelessWidget {
  final String numeral;
  final String title;
  final String subtitle;
  final List<_ToolDef> tools;
  final void Function(_ToolDef) onTap;

  const _RomanSection({
    required this.numeral,
    required this.title,
    required this.subtitle,
    required this.tools,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: skin.isBubbleGum ? [palette.primary, palette.accent] : const [_Rome.gold, _Rome.goldDeep],
                ),
                borderRadius: BorderRadius.circular(6),
                boxShadow: [
                  BoxShadow(
                    color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.25) : _Rome.gold.withValues(alpha: 0.25),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Text(
                numeral,
                style: GoogleFonts.cinzel(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: _Rome.purpleDeep,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.cinzel(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.5,
                      color: _Rome.ivory,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 10,
                      fontStyle: FontStyle.italic,
                      color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.75) : _Rome.gold.withValues(alpha: 0.75),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.22,
          children: List.generate(tools.length, (index) {
            final tool = tools[index];
            return _RomanToolCard(
              tool: tool,
              numeral: '${numeral}.${index + 1}',
              isApi: tool.isApi,
              onTap: () => onTap(tool),
            );
          }),
        ),
      ],
    );
  }
}

// ─── Roman Tool Card ───────────────────────────────────────────────────────
class _RomanToolCard extends StatelessWidget {
  final _ToolDef tool;
  final String numeral;
  final bool isApi;
  final VoidCallback onTap;

  const _RomanToolCard({
    required this.tool,
    required this.numeral,
    required this.isApi,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0x24FFFFFF), Color(0x0BFFFFFF)],
          ),
          borderRadius: BorderRadius.circular(_RomeStyle.baseRadius),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.25),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: RoyalFrame(
          radius: _RomeStyle.baseRadius,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      numeral,
                      style: GoogleFonts.cinzel(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: _Rome.gold.withValues(alpha: 0.8),
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.25),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.35) : _Rome.gold.withValues(alpha: 0.35),
                        ),
                      ),
                      child: Text(
                        isApi ? 'API' : 'PAGE',
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                          color: isApi ? _Rome.ember : _Rome.jade,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  tool.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cinzel(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                    color: _Rome.ivory,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  tool.subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 10,
                    height: 1.3,
                    color: _Rome.ivory.withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Senate Footer ─────────────────────────────────────────────────────────
class _SenateFooter extends StatelessWidget {
  const _SenateFooter();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _LaurelDivider(),
        const SizedBox(height: 10),
        Text(
          'SENATVS POPVLVSQVE NOVACORE',
          textAlign: TextAlign.center,
          style: GoogleFonts.cinzel(
            fontSize: 11,
            letterSpacing: 3,
            fontWeight: FontWeight.w600,
            color: _Rome.goldDeep,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '${_Laurel.mark}  ANNO IMPERII · SPQR  ${_Laurel.mark}',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 9,
            letterSpacing: 2,
            color: _Rome.ivory.withValues(alpha: 0.4),
          ),
        ),
      ],
    );
  }
}

// ─── Bottom Sheet Runner (API tools) ───────────────────────────────────────
class _ToolRunnerSheet extends StatefulWidget {
  final _ToolDef tool;

  const _ToolRunnerSheet({required this.tool});

  @override
  State<_ToolRunnerSheet> createState() => _ToolRunnerSheetState();
}

class _ToolRunnerSheetState extends State<_ToolRunnerSheet> {
  final _inputCtrl = TextEditingController();
  final _secondCtrl = TextEditingController(text: 'IDR');
  bool _loading = false;
  String? _error;
  Widget? _result;

  bool get _hasSecondField => widget.tool.id == 'currency';

  @override
  void dispose() {
    _inputCtrl.dispose();
    _secondCtrl.dispose();
    super.dispose();
  }

  String get _hint {
    switch (widget.tool.id) {
      case 'ip':
        return 'Masukkan IP, contoh: 8.8.8.8';
      case 'myip':
        return 'Tekan RUN untuk cek IP kamu';
      case 'phone':
        return 'Masukkan nomor, contoh: +6281234567890';
      case 'email':
        return 'Masukkan email, contoh: nama@email.com';
      case 'domain':
        return 'Masukkan domain, contoh: google.com';
      case 'pwned':
        return 'Masukkan password yang ingin dicek';
      case 'shorten':
        return 'Masukkan URL panjang, contoh: https://contoh.com/artikel';
      case 'qr':
        return 'Teks atau URL untuk dijadikan QR code';
      case 'currency':
        return 'Jumlah USD, contoh: 100';
      case 'password':
        return 'Panjang karakter (opsional, default 16)';
      case 'weather':
        return 'Masukkan nama kota, contoh: Jakarta';
      case 'dictionary':
        return 'Masukkan kata, contoh: security';
      case 'dns':
        return 'Masukkan host/domain, contoh: google.com';
      case 'isbn':
        return 'Masukkan ISBN, contoh: 9780132350884';
      default:
        return 'Masukkan input';
    }
  }

  bool get _needsInput =>
      widget.tool.id != 'myip' && widget.tool.id != 'password';

  Future<void> _run() async {
    final input = _inputCtrl.text.trim();
    if (_needsInput && input.isEmpty) {
      setState(() {
        _error = 'Isi input terlebih dahulu.';
        _result = null;
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _result = null;
    });
    try {
      switch (widget.tool.id) {
        case 'ip':
          _result = await _lookupIp(input);
        case 'myip':
          _result = await _myIp();
        case 'phone':
          _result = await _phone(input);
        case 'email':
          _result = await _email(input);
        case 'domain':
          _result = await _domain(input);
        case 'pwned':
          _result = await _pwned(input);
        case 'shorten':
          _result = await _shorten(input);
        case 'qr':
          _result = _buildQr(input);
        case 'currency':
          _result = await _currency(input, _secondCtrl.text.trim());
        case 'password':
          _result = _buildPassword(input);
        case 'weather':
          _result = await _weather(input);
        case 'dictionary':
          _result = await _dictionary(input);
        case 'dns':
          _result = await _dns(input);
        case 'isbn':
          _result = await _isbn(input);
      }
    } catch (e) {
      _error = 'Gagal memproses: $e';
    }
    if (mounted) setState(() => _loading = false);
    final summary = _error == null
        ? 'Input: ${input.isEmpty ? '-' : input} - berhasil'
        : 'Input: ${input.isEmpty ? '-' : input} - $_error';
    ApiService().logActivity(
      'Tool: ${widget.tool.title}',
      summary,
      status: _error == null ? 'success' : 'failed',
    );
  }

  Future<Map<String, dynamic>> _getJson(String url) async {
    final res = await http
        .get(Uri.parse(url))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode >= 400) throw Exception('HTTP ${res.statusCode}');
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<dynamic>> _getJsonList(String url) async {
    final res = await http
        .get(Uri.parse(url))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode >= 400) throw Exception('HTTP ${res.statusCode}');
    return jsonDecode(res.body) as List<dynamic>;
  }

  Future<Widget> _weather(String input) async {
    final data = await _getJson(
      'https://wttr.in/${Uri.encodeComponent(input)}?format=j1',
    );
    final cc =
        data['current_condition'] is List &&
            (data['current_condition'] as List).isNotEmpty
        ? (data['current_condition'] as List).first as Map<String, dynamic>
        : <String, dynamic>{};
    final area =
        data['nearest_area'] is List &&
            (data['nearest_area'] as List).isNotEmpty
        ? (data['nearest_area'] as List).first as Map<String, dynamic>
        : <String, dynamic>{};
    String nestedValue(Map<String, dynamic> map, String key) {
      final list = map[key];
      if (list is List &&
          list.isNotEmpty &&
          list.first is Map<String, dynamic>) {
        return list.first['value']?.toString() ?? '-';
      }
      return '-';
    }

    return _ResultView(
      title: 'CUACA - ${input.toUpperCase()}',
      rows: [
        (
          'Lokasi',
          '${nestedValue(area, 'areaName')}, ${nestedValue(area, 'country')}',
        ),
        ('Suhu', '${cc['temp_C'] ?? '-'} C'),
        ('Terasa', '${cc['FeelsLikeC'] ?? '-'} C'),
        ('Kondisi', nestedValue(cc, 'weatherDesc')),
        ('Kelembaban', '${cc['humidity'] ?? '-'}%'),
        (
          'Angin',
          '${cc['windspeedKmph'] ?? '-'} km/h ${cc['winddir16Point'] ?? '-'}',
        ),
        ('Tekanan', '${cc['pressure'] ?? '-'} hPa'),
        ('UV Index', '${cc['uvIndex'] ?? '-'}'),
        ('Observasi', cc['observation_time'] ?? '-'),
      ],
    );
  }

  Future<Widget> _dictionary(String input) async {
    final list = await _getJsonList(
      'https://api.dictionaryapi.dev/api/v2/entries/en/${Uri.encodeComponent(input)}',
    );
    final data = list.first as Map<String, dynamic>;
    final meanings =
        data['meanings'] is List && (data['meanings'] as List).isNotEmpty
        ? data['meanings'] as List
        : <dynamic>[];
    final m0 = meanings.first as Map<String, dynamic>;
    final defs =
        m0['definitions'] is List && (m0['definitions'] as List).isNotEmpty
        ? m0['definitions'] as List
        : <dynamic>[];
    final d0 = defs.first as Map<String, dynamic>;
    return _ResultView(
      title: 'DICTIONARY - ${(data['word'] ?? input).toString().toUpperCase()}',
      rows: [
        ('Kata', data['word']?.toString() ?? input),
        ('Fonetik', data['phonetic']?.toString() ?? '-'),
        ('Jenis', m0['partOfSpeech']?.toString() ?? '-'),
        ('Definisi', d0['definition']?.toString() ?? '-'),
        ('Contoh', d0['example']?.toString() ?? '-'),
      ],
    );
  }

  Future<Widget> _dns(String input) async {
    final data = await _getJson(
      'https://dns.google/resolve?name=${Uri.encodeComponent(input)}&type=A',
    );
    final answers = data['Answer'] is List
        ? data['Answer'] as List
        : <dynamic>[];
    final rows = <(String, String)>[
      ('Host', input),
      (
        'Status',
        data['Status']?.toString() == '0' ? 'OK (NOERROR)' : 'TIDAK DITEMUKAN',
      ),
      ('Jumlah jawaban', answers.length.toString()),
    ];
    for (var i = 0; i < answers.length && i < 10; i++) {
      final a = answers[i] as Map<String, dynamic>;
      rows.add((
        'Record ${i + 1}',
        '${a['data'] ?? '-'} (TTL ${a['TTL'] ?? '-'})',
      ));
    }
    return _ResultView(title: 'DNS LOOKUP', rows: rows);
  }

  Future<Widget> _isbn(String input) async {
    final data = await _getJson(
      'https://openlibrary.org/api/books?bibkeys=ISBN:${Uri.encodeComponent(input)}&format=json&jscmd=data',
    );
    final book = data['ISBN:$input'];
    if (book is! Map<String, dynamic>) {
      throw Exception('Buku tidak ditemukan untuk ISBN tersebut');
    }
    String join(dynamic v) {
      if (v is List) {
        return v
            .map(
              (e) => e is Map<String, dynamic>
                  ? (e['name']?.toString() ?? '')
                  : e.toString(),
            )
            .where((s) => s.isNotEmpty)
            .join(', ');
      }
      return v?.toString() ?? '-';
    }

    return _ResultView(
      title:
          'ISBN LOOKUP - ${(book['title'] ?? input).toString().toUpperCase()}',
      rows: [
        ('Judul', book['title']?.toString() ?? '-'),
        ('Subjudul', book['subtitle']?.toString() ?? '-'),
        ('Penulis', join(book['authors'])),
        ('Terbit', book['publish_date']?.toString() ?? '-'),
        ('Penerbit', join(book['publishers'])),
        ('Halaman', book['number_of_pages']?.toString() ?? '-'),
        ('Subjek', join(book['subjects'])),
      ],
    );
  }

  String _fmtDate(dynamic value) {
    final dt = DateTime.tryParse(value?.toString() ?? '');
    if (dt == null) return '-';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
  }

  String _v(Map<String, dynamic> data, String key) {
    final s = data[key]?.toString() ?? '';
    return (s.isEmpty || s == 'N/A') ? '-' : s;
  }

  Future<Widget> _lookupIp(String input) async {
    final data = await _getJson(
      'https://ipinfo.io/${Uri.encodeComponent(input)}/json',
    );
    final ip = _v(data, 'ip');
    return _ResultView(
      title: 'HASIL IP LOOKUP',
      rows: [
        ('IP', ip),
        ('Hostname', _v(data, 'hostname')),
        ('City', _v(data, 'city')),
        ('Region', _v(data, 'region')),
        ('Country', _v(data, 'country')),
        ('Postal', _v(data, 'postal')),
        ('Org', _v(data, 'org')),
        ('Timezone', _v(data, 'timezone')),
        ('Location', _v(data, 'loc')),
      ],
      copyable: ip == '-' ? null : ip,
    );
  }

  Future<Widget> _myIp() async {
    final data = await _getJson('https://api.ipify.org?format=json');
    final ip = data['ip']?.toString() ?? '-';
    return _ResultView(
      title: 'MY IP',
      rows: [('IP Publik', ip)],
      copyable: ip == '-' ? null : ip,
    );
  }

  Future<Widget> _phone(String input) async {
    final data = await _getJson(
      'https://api.veriphone.io/v2/verify?phone=${Uri.encodeComponent(input)}',
    );
    return _ResultView(
      title: 'HASIL PHONE LOOKUP',
      rows: [
        ('Nomor', data['international_number']?.toString() ?? input),
        ('Valid', data['phone_valid'] == true ? 'YA' : 'TIDAK'),
        ('Type', data['phone_type']?.toString() ?? '-'),
        ('Country', data['country_name']?.toString() ?? '-'),
        ('Carrier', data['carrier']?.toString() ?? '-'),
        ('Line', data['line_type']?.toString() ?? '-'),
      ],
    );
  }

  Future<Widget> _email(String input) async {
    final data = await _getJson(
      'https://api.eva.pingutil.com/email?email=${Uri.encodeComponent(input)}',
    );
    final d = data['data'] is Map<String, dynamic>
        ? data['data'] as Map<String, dynamic>
        : <String, dynamic>{};
    String flag(String key) => d[key] == 'true' ? 'YA' : 'TIDAK';
    return _ResultView(
      title: 'HASIL EMAIL CHECK',
      rows: [
        ('Email', d['email']?.toString() ?? input),
        ('Format valid', flag('format_valid')),
        ('Deliverable', flag('deliverable')),
        ('SMTP check', flag('smtp_check')),
        ('Disposable', flag('disposable')),
      ],
    );
  }

  Future<Widget> _domain(String input) async {
    final data = await _getJson(
      'https://rdap.org/domain/${Uri.encodeComponent(input)}',
    );
    final statuses = data['status'];
    final status = statuses is List && statuses.isNotEmpty
        ? statuses.join(', ')
        : '-';
    return _ResultView(
      title: 'HASIL DOMAIN WHOIS',
      rows: [
        ('Domain', data['ldhName']?.toString() ?? input),
        ('Registrar', _rdapRegistrar(data)),
        ('Status', status),
        ('Dibuat', _rdapEvent(data, 'registration')),
        ('Kadaluarsa', _rdapEvent(data, 'expiration')),
        ('Terakhir', _rdapEvent(data, 'last changed')),
      ],
    );
  }

  String _rdapRegistrar(Map<String, dynamic> data) {
    final entities = data['entities'];
    if (entities is List) {
      for (final e in entities) {
        if (e is Map<String, dynamic>) {
          final vcard = e['vcardArray'];
          if (vcard is List && vcard.length > 1 && vcard[1] is List) {
            for (final item in vcard[1]) {
              if (item is List &&
                  item.isNotEmpty &&
                  item[0] == 'fn' &&
                  item.length > 3) {
                final name = item[3]?.toString() ?? '';
                if (name.isNotEmpty) return name;
              }
            }
          }
        }
      }
    }
    return '-';
  }

  String _rdapEvent(Map<String, dynamic> data, String action) {
    final events = data['events'];
    if (events is List) {
      for (final e in events) {
        if (e is Map<String, dynamic> && e['eventAction'] == action) {
          return _fmtDate(e['eventDate']);
        }
      }
    }
    return '-';
  }

  Future<Widget> _pwned(String input) async {
    final data = await _getJson(
      'https://api.xposedornot.com/v1/pwned-password/${Uri.encodeComponent(input)}',
    );
    final isPwned = data['IsPwned'] == true;
    return _ResultView(
      title: 'HASIL PWNED CHECK',
      rows: [
        ('Password', '(di-hash & dihapus otomatis)'),
        ('Pernah bocor', isPwned ? 'YA - GANTI SEGERA!' : 'Tidak ditemukan'),
        ('Jumlah kemunculan', '${data['HashCount'] ?? 0}'),
      ],
    );
  }

  Future<Widget> _shorten(String input) async {
    final data = await _getJson(
      'https://is.gd/create.php?format=json&url=${Uri.encodeComponent(input)}',
    );
    if (data.containsKey('errorcode')) {
      throw Exception(data['errormessage'] ?? 'Gagal memperpendek tautan');
    }
    final short = data['shorturl']?.toString() ?? '-';
    return _ResultView(
      title: 'HASIL LINK SHORTENER',
      rows: [('URL', input), ('Short', short)],
      copyable: short == '-' ? null : short,
    );
  }

  Future<Widget> _currency(String amountText, String code) async {
    final codeUp = code.toUpperCase().trim();
    final amount = double.tryParse(amountText.replaceAll(',', '')) ?? 0;
    final data = await _getJson('https://open.er-api.com/v6/latest/USD');
    final rates = data['rates'] is Map<String, dynamic>
        ? data['rates'] as Map<String, dynamic>
        : <String, dynamic>{};
    final rate = rates[codeUp];
    if (rate == null) throw Exception('Kode mata uang tidak dikenal: $codeUp');
    final result = amount * (rate as num).toDouble();
    return _ResultView(
      title: 'HASIL CURRENCY CONVERTER',
      rows: [
        ('Jumlah', '$amount USD'),
        ('Rate', '1 USD = $rate $codeUp'),
        ('Hasil', '${result.toStringAsFixed(2)} $codeUp'),
      ],
      copyable: result.toStringAsFixed(2),
    );
  }

  Widget _buildQr(String input) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: const Border.fromBorderSide(
          BorderSide(color: _Rome.goldDeep, width: 2),
        ),
      ),
      child: QrImageView(data: input, size: 220),
    );
  }

  Widget _buildPassword(String input) {
    final len = (int.tryParse(input) ?? 16).clamp(8, 64);
    const chars =
        'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#\$%^&*()_+-=';
    final rnd = Random.secure();
    final pw = List.generate(
      len,
      (_) => chars[rnd.nextInt(chars.length)],
    ).join();
    return _ResultView(
      title: 'PASSWORD GENERATOR',
      rows: [('Panjang', len.toString()), ('Password', pw)],
      copyable: pw,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [_Rome.gold, _Rome.goldDeep],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    border: const Border.fromBorderSide(
                      BorderSide(color: _Rome.ivory, width: 1.2),
                    ),
                  ),
                  child: Icon(
                    widget.tool.icon,
                    size: 20,
                    color: _Rome.purpleDeep,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.tool.title,
                        style: GoogleFonts.cinzel(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5,
                          color: _Rome.ivory,
                        ),
                      ),
                      Text(
                        widget.tool.subtitle,
                        style: TextStyle(
                          fontSize: 11,
                          color: _Rome.ivory.withValues(alpha: 0.55),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (_hasSecondField)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      autofocus: true,
                      style: const TextStyle(color: _Rome.ivory),
                      decoration: _romInput('Jumlah', _hint),
                      keyboardType: TextInputType.number,
                      onSubmitted: (_) => _run(),
                    ),
                  ),
                  const SizedBox(width: 12),
                  SizedBox(
                    width: 110,
                    child: TextField(
                      controller: _secondCtrl,
                      style: const TextStyle(color: _Rome.ivory),
                      decoration: _romInput('Kode', 'IDR'),
                      textCapitalization: TextCapitalization.characters,
                      onSubmitted: (_) => _run(),
                    ),
                  ),
                ],
              )
            else
              TextField(
                controller: _inputCtrl,
                autofocus: true,
                style: const TextStyle(color: _Rome.ivory),
                decoration: _romInput('Input', _hint),
                onSubmitted: (_) => _run(),
              ),
            const SizedBox(height: 12),
            _RomanRunButton(loading: _loading, onPressed: _run),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(
                _error!,
                style: const TextStyle(
                  color: _Rome.ember,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
            if (_result != null) ...[
              const SizedBox(height: 12),
              Flexible(
                child: SingleChildScrollView(
                  child: Align(alignment: Alignment.centerLeft, child: _result),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  InputDecoration _romInput(String label, String hint) {
    return InputDecoration(
      labelText: label,
      hintText: hint,
      labelStyle: const TextStyle(color: _Rome.gold),
      hintStyle: TextStyle(color: _Rome.ivory.withValues(alpha: 0.35)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _Rome.gold.withValues(alpha: 0.45)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _Rome.gold, width: 1.4),
      ),
    );
  }
}

class _RomanRunButton extends StatelessWidget {
  final bool loading;
  final VoidCallback onPressed;

  const _RomanRunButton({required this.loading, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: loading ? null : onPressed,
      child: Container(
        height: 46,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_Rome.gold, _Rome.goldDeep]),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _Rome.ivory.withValues(alpha: 0.6),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(color: _Rome.gold.withValues(alpha: 0.3), blurRadius: 14),
          ],
        ),
        child: Center(
          child: loading
              ? const NeoBlockLoader(
                  compact: true,
                  size: 20,
                  c1: _Rome.purpleDeep,
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(
                      Icons.military_tech,
                      size: 16,
                      color: _Rome.purpleDeep,
                    ),
                    SizedBox(width: 8),
                    Text(
                      'EXECUTE',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        letterSpacing: 2,
                        color: _Rome.purpleDeep,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _ResultView extends StatelessWidget {
  final String title;
  final List<(String, String)> rows;
  final String? copyable;

  const _ResultView({required this.title, required this.rows, this.copyable});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _Rome.purpleVelvet.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Rome.gold.withValues(alpha: 0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.cinzel(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.4,
              color: _Rome.gold,
            ),
          ),
          const SizedBox(height: 12),
          ...rows.map(
            (r) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 105,
                    child: Text(
                      '${r.$1}: ',
                      style: TextStyle(
                        fontSize: 12,
                        color: _Rome.ivory.withValues(alpha: 0.55),
                      ),
                    ),
                  ),
                  Expanded(
                    child: SelectableText(
                      r.$2,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: _Rome.ivory,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (copyable != null && copyable!.isNotEmpty) ...[
            const SizedBox(height: 4),
            GestureDetector(
              onTap: () async {
                await Clipboard.setData(ClipboardData(text: copyable!));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
                      content: Text('Disalin ke clipboard'),
                      backgroundColor: _Rome.goldDeep,
                      duration: Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Row(
                children: [
                  const Icon(Icons.copy, size: 16, color: _Rome.gold),
                  const SizedBox(width: 8),
                  const Text(
                    'SALIN',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                      color: _Rome.gold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
