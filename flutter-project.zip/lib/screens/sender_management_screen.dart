import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/wa_sender.dart';
import '../providers/auth_provider.dart';
import '../providers/whatsapp_provider.dart';
import '../theme.dart';
import '../providers/theme_provider.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_card.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scroll_clearance.dart';

class SenderManagementScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const SenderManagementScreen({super.key, this.onBack});

  @override
  State<SenderManagementScreen> createState() => _SenderManagementScreenState();
}

class _SenderManagementScreenState extends State<SenderManagementScreen> {
  String _search = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<WhatsAppProvider>().loadSenders();
    });
  }

  String _ownerName(WaSender s) {
    final o = s.owner;
    if (o != null) return o['username']?.toString() ?? '-';
    return '-';
  }

  // Hanya owner sender / developer yang boleh kelola sender. Partner &
  // moderator bisa MELIHAT sender akun di bawah hierarki mereka, tetapi
  // tidak boleh mengubah/nonaktifkan/menghapus milik orang lain.
  bool _canManage(WaSender s) {
    final auth = context.read<AuthProvider>();
    final myId = auth.user?.id;
    return auth.user?.role == 'developer' || (myId != null && s.userId == myId);
  }

  Future<void> _toggleEnabled(WaSender s) async {
    final wp = context.read<WhatsAppProvider>();
    final result = await wp.setSenderEnabled(s.id, !s.enabled);
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? (s.enabled ? 'Sender dinonaktifkan' : 'Sender diaktifkan')
              : (result['error']?['message'] ?? 'Gagal mengubah status'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
  }

  Future<void> _changeVisibility(WaSender s) async {
    final auth = context.read<AuthProvider>();
    final isDev = auth.user?.role == 'developer';
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      useSafeArea: true,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(NeoRadius.xl)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            NeoSpacing.lg,
            NeoSpacing.lg,
            NeoSpacing.lg,
            NeoSpacing.md,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: NeoColors.grey,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'VISIBILITAS SENDER',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: NeoColors.primaryText,
                ),
              ),
              const SizedBox(height: 16),
              _visibilityOption(
                ctx,
                'private',
                'Private',
                'Hanya terlihat oleh pemiliknya',
                s.visibility,
              ),
              if (isDev) ...[
                const SizedBox(height: NeoSpacing.md),
                _visibilityOption(
                  ctx,
                  'global',
                  'Global',
                  'Terlihat oleh semua role tanpa terkecuali (khusus developer)',
                  s.visibility,
                ),
              ],
            ],
          ),
        ),
      ),
    );
    if (selected == null || selected == s.visibility) return;
    if (!mounted) return;
    final wp = context.read<WhatsAppProvider>();
    final result = await wp.updateVisibility(s.id, selected);
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? 'Visibilitas diubah ke ${selected.toUpperCase()}'
              : (result['error']?['message'] ?? 'Gagal mengubah visibilitas'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
  }

  Widget _visibilityOption(
    BuildContext ctx,
    String value,
    String label,
    String desc,
    String current,
  ) {
    final active = value == current;
    return GestureDetector(
      onTap: () => Navigator.pop(ctx, value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: active
              ? NeoColors.yellow
              : Theme.of(ctx).scaffoldBackgroundColor,
          border: Border.all(
            color: active ? NeoColors.yellow : NeoColors.border,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.md),
          boxShadow: active
              ? NeoShadows.smD(Theme.of(ctx).brightness == Brightness.dark)
              : null,
        ),
        child: Row(
          children: [
            Icon(
              Icons.visibility_outlined,
              size: 20,
              color: active ? NeoColors.yellow : NeoColors.grey,
            ),
            const SizedBox(width: NeoSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label.toUpperCase(),
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.primaryText,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    desc,
                    style: const TextStyle(fontSize: 10, color: NeoColors.grey),
                  ),
                ],
              ),
            ),
            if (active)
              const Icon(Icons.check_circle, size: 18, color: NeoColors.yellow),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(WaSender s) async {
    final confirmed = await NeoDialog.show(
      context: context,
      title: 'HAPUS SENDER?',
      message:
          'Hapus sender ${_formatPhone(s.phoneNumber)} milik ${_ownerName(s)}?\n\nSession credentials akan dihapus dan koneksi dihentikan. Tindakan ini tidak bisa dibatalkan.',
      cancelLabel: 'BATAL',
      confirmLabel: 'HAPUS',
      confirmColor: NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    final wp = context.read<WhatsAppProvider>();
    final result = await wp.deleteSender(s.id);
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? 'Sender dihapus'
              : (result['error']?['message'] ?? 'Gagal menghapus sender'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
  }

  String _formatPhone(String phone) {
    if (phone.startsWith('62')) return '+$phone';
    return phone;
  }

  Color _statusColor(String status) {
    switch (status) {
      case WaStatus.connected:
        return NeoColors.green;
      case WaStatus.qr:
        return NeoColors.blue;
      case WaStatus.pairing:
        return NeoColors.purple;
      case WaStatus.connecting:
        return NeoColors.orange;
      default:
        return NeoColors.grey;
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case WaStatus.connected:
        return 'CONNECTED';
      case WaStatus.qr:
        return 'QR READY';
      case WaStatus.pairing:
        return 'PAIRING';
      case WaStatus.connecting:
        return 'CONNECTING';
      default:
        return 'DISCONNECTED';
    }
  }

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SceneBackground(
      theme: FeatureConfig.manage,
      screenIndex: FeatureConfig.sendersIndex,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const NeoAppHeader(),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                NeoSpacing.lg,
                NeoSpacing.xs,
                NeoSpacing.lg,
                0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.onBack != null)
                    Row(
                      children: [
                        NeoBackButton(onTap: widget.onBack),
                        const Spacer(),
                        const SizedBox(width: 36),
                      ],
                    ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        Icons.chat_bubble_rounded,
                        color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'WHATSAPP SENDERS',
                        style: GoogleFonts.cinzel(
                          textStyle: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.5,
                            color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.marble,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          height: 1,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                skin.isBubbleGum ? palette.primary.withValues(alpha: 0.60) : NeoColors.goldDeep.withValues(alpha: 102 / 255),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: NeoSpacing.md),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: Container(
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  border: Border.all(
                    color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.45) : NeoColors.gold.withValues(alpha: 68 / 255),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextField(
                  onChanged: (v) => setState(() => _search = v),
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: NeoColors.marble,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Search senders...',
                    hintStyle: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: NeoColors.grey,
                    ),
                    prefixIcon: Icon(
                      Icons.search,
                      size: 18,
                      color: NeoColors.gold.withValues(alpha: 153 / 255),
                    ),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(height: NeoSpacing.sm),
            Expanded(
              child: Consumer<WhatsAppProvider>(
                builder: (ctx, wp, _) {
                  final senders = _search.isEmpty
                      ? wp.senders
                      : wp.senders.where((s) {
                          final q = _search.toLowerCase();
                          return s.phoneNumber.toLowerCase().contains(q) ||
                              s.sessionName.toLowerCase().contains(q) ||
                              _ownerName(s).toLowerCase().contains(q);
                        }).toList();
                  if (wp.loading) {
                    return const Center(
                      child: NeoBlockLoader(
                        blockSize: 8,
                        c0: NeoColors.black,
                        c1: NeoColors.yellow,
                      ),
                    );
                  }
                  if (senders.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            wp.error == null
                                ? Icons.chat_bubble_outline
                                : Icons.error_outline,
                            size: 36,
                            color: wp.error == null
                                ? NeoColors.secondaryText
                                : NeoColors.pink,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            wp.error ??
                                (_search.isNotEmpty
                                    ? 'TIDAK DITEMUKAN'
                                    : 'BELUM ADA SENDER'),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: wp.error == null
                                  ? (isDark
                                        ? NeoColors.secondaryText
                                        : NeoColors.grey)
                                  : NeoColors.pink,
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                  return ListView.builder(
                    padding: EdgeInsets.fromLTRB(
                      NeoSpacing.lg,
                      0,
                      NeoSpacing.lg,
                      ScrollClearance.bottomNav(context),
                    ),
                    itemCount: senders.length,
                    itemBuilder: (ctx, i) {
                      final s = senders[i];
                      final color = _statusColor(s.status);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: NeoSpacing.md),
                        child: NeoCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 42,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      color: color,
                                      border: Border.all(
                                        color: color,
                                        width: 2,
                                      ),
                                      borderRadius: BorderRadius.circular(
                                        NeoRadius.sm,
                                      ),
                                    ),
                                    child: Icon(
                                      Icons.chat_bubble_outline,
                                      size: 20,
                                      color: NeoColors.black,
                                    ),
                                  ),
                                  const SizedBox(width: NeoSpacing.md),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          _formatPhone(s.phoneNumber),
                                          style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w800,
                                            color: isDark
                                                ? NeoColors.primaryText
                                                : NeoColors.black,
                                          ),
                                        ),
                                        if (s.sessionName.isNotEmpty) ...[
                                          const SizedBox(height: 1),
                                          Text(
                                            s.sessionName,
                                            style: const TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                              color: NeoColors.grey,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  if (!s.enabled)
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 3,
                                      ),
                                      decoration: BoxDecoration(
                                        color: NeoColors.grey,
                                        border: Border.all(
                                          color: NeoColors.grey,
                                          width: 1.5,
                                        ),
                                        borderRadius: BorderRadius.circular(
                                          NeoRadius.sm,
                                        ),
                                      ),
                                      child: const Text(
                                        'NONAKTIF',
                                        style: TextStyle(
                                          fontSize: 8,
                                          fontWeight: FontWeight.w800,
                                          color: NeoColors.black,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                    )
                                  else
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 3,
                                      ),
                                      decoration: BoxDecoration(
                                        color: color,
                                        border: Border.all(
                                          color: color,
                                          width: 1.5,
                                        ),
                                        borderRadius: BorderRadius.circular(
                                          NeoRadius.sm,
                                        ),
                                      ),
                                      child: Text(
                                        _statusLabel(s.status),
                                        style: TextStyle(
                                          fontSize: 8,
                                          fontWeight: FontWeight.w800,
                                          color: NeoColors.black,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: NeoSpacing.sm),
                              Row(
                                children: [
                                  const Icon(
                                    Icons.person_outline,
                                    size: 13,
                                    color: NeoColors.grey,
                                  ),
                                  const SizedBox(width: 4),
                                  Expanded(
                                    child: Text(
                                      _ownerName(s),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        color: NeoColors.grey,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: NeoSpacing.md),
                                  const Icon(
                                    Icons.visibility_outlined,
                                    size: 13,
                                    color: NeoColors.grey,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    s.effectiveVisibility.toUpperCase(),
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: NeoColors.grey,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: NeoSpacing.md),
                              if (!_canManage(s))
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.visibility_off_outlined,
                                        size: 13,
                                        color: NeoColors.grey,
                                      ),
                                      const SizedBox(width: 5),
                                      Expanded(
                                        child: Text(
                                          'Sender akun di bawah Anda (hanya lihat, tidak dikelola)',
                                          style: const TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w600,
                                            color: NeoColors.grey,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              Row(
                                children: [
                                  Expanded(
                                    child: NeoButton(
                                      label: s.enabled
                                          ? 'NONAKTIFKAN'
                                          : 'AKTIFKAN',
                                      bgColor: s.enabled
                                          ? NeoColors.burgundy
                                          : NeoColors.goldDeep,
                                      textColor: NeoColors.white,
                                      height: 38,
                                      fontSize: 11,
                                      onPressed: _canManage(s)
                                          ? () => _toggleEnabled(s)
                                          : null,
                                    ),
                                  ),
                                  const SizedBox(width: NeoSpacing.sm),
                                  Expanded(
                                    child: NeoButton(
                                      label: 'VISIBILITAS',
                                      bgColor: NeoColors.surfaceElevated,
                                      textColor: NeoColors.primaryText,
                                      height: 38,
                                      fontSize: 11,
                                      onPressed: _canManage(s)
                                          ? () => _changeVisibility(s)
                                          : null,
                                    ),
                                  ),
                                  const SizedBox(width: NeoSpacing.sm),
                                  Expanded(
                                    child: NeoButton(
                                      label: 'HAPUS',
                                      bgColor: NeoColors.burgundy,
                                      textColor: NeoColors.white,
                                      height: 38,
                                      fontSize: 11,
                                      onPressed: _canManage(s)
                                          ? () => _confirmDelete(s)
                                          : null,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
