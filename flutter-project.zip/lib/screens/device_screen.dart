import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/device.dart';
import '../providers/app_refresh_provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../providers/theme_provider.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_glass_overlay.dart';
import '../widgets/neo_table.dart';
import '../widgets/scene_background.dart';
import '../widgets/scroll_clearance.dart';

class DeviceScreen extends StatefulWidget {
  final VoidCallback? onBack;
  final ValueChanged<Device>? onOpenControl;

  const DeviceScreen({super.key, this.onBack, this.onOpenControl});

  @override
  State<DeviceScreen> createState() => _DeviceScreenState();
}

class _DeviceScreenState extends State<DeviceScreen> {
  List<Map<String, dynamic>> _devices = [];
  bool _loading = true;
  late AppRefreshProvider _refresh;
  int _lastRevision = -1;
  bool _isDeveloper = false;
  bool _isPartner = false;
  bool _isModerator = false;

  @override
  void initState() {
    super.initState();
    _isDeveloper = context.read<AuthProvider>().isDeveloper;
    _isPartner = context.read<AuthProvider>().isPartner;
    _isModerator = context.read<AuthProvider>().user?.role == 'moderator';
    _refresh = context.read<AppRefreshProvider>();
    _lastRevision = _refresh.revision;
    _refresh.addListener(_onRefreshChanged);
    _load();
  }

  @override
  void dispose() {
    _refresh.removeListener(_onRefreshChanged);
    super.dispose();
  }

  void _onRefreshChanged() {
    if (!mounted) return;
    final rev = _refresh.revision;
    if (rev != _lastRevision) {
      _lastRevision = rev;
      _load();
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = (_isDeveloper || _isPartner || _isModerator)
        ? await ApiService().getManageDevices()
        : await ApiService().getDevices();
    if (!mounted) return;
    setState(() {
      _devices = List<Map<String, dynamic>>.from(res['data'] as List? ?? []);
      _loading = false;
    });
  }

  Future<void> _transfer(Map<String, dynamic> d) async {
    final deviceName = (d['name'] ?? '').toString();
    final usersRes = await ApiService().getUsers();
    if (!mounted) return;
    final users =
        List<Map<String, dynamic>>.from(usersRes['data'] as List? ?? []).where((
          u,
        ) {
          final role = (u['role'] ?? '').toString();
          return role == 'partner' ||
              role == 'reseller' ||
              role == 'member' ||
              role == 'developer';
        }).toList();

    String? selectedId;
    final currentOwner = (d['owner_username'] ?? '').toString();
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: NeoGlassOverlay(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TRANSFER OWNERSHIP',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 18,
                    color: NeoColors.primaryText,
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: 360,
                  child: SingleChildScrollView(
                    child: StatefulBuilder(
                      builder: (ctx, setLocal) => Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Device: $deviceName\nPemilik saat ini: ${currentOwner.isEmpty ? 'TANPA USER' : currentOwner}',
                            style: TextStyle(
                              fontSize: 12,
                              color: NeoColors.secondaryText,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'PEMILIK BARU',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: NeoColors.secondaryText,
                            ),
                          ),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            initialValue: selectedId,
                            dropdownColor: NeoColors.surfaceElevated,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('TANPA USER'),
                              ),
                              ...users.map(
                                (u) => DropdownMenuItem(
                                  value: (u['id'] ?? '').toString(),
                                  child: Text(
                                    '${(u['username'] ?? u['email'] ?? '').toString().toUpperCase()} • ${(u['role'] ?? '').toString().toUpperCase()}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ],
                            onChanged: (v) => setLocal(
                              () => selectedId = (v == '' ? null : v),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text(
                          'BATAL',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeoButton(
                        label: 'TRANSFER',
                        height: 40,
                        fontSize: 13,
                        onPressed: () => Navigator.pop(ctx, true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    if (saved != true || !mounted) return;

    final newOwnerName = selectedId == null
        ? 'TANPA USER'
        : users
                  .where((x) => (x['id'] ?? '').toString() == selectedId)
                  .firstOrNull?['username']
                  ?.toString() ??
              'user';

    try {
      final res = await ApiService().transferDeviceOwner(
        (d['id'] ?? '').toString(),
        selectedId,
      );
      if (!mounted) return;
      if (res['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              'Kepemilikan "$deviceName" dipindahkan ke $newOwnerName',
            ),
            backgroundColor: NeoColors.green,
          ),
        );
        await _load();
        if (mounted) context.read<AppRefreshProvider>().bump();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              res['error']?['message'] ?? 'Gagal memindahkan kepemilikan',
            ),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal memindahkan kepemilikan: $e'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  Future<void> _toggleLock(Map<String, dynamic> d) async {
    final deviceId = (d['id'] ?? '').toString();
    final deviceName = (d['name'] ?? '').toString();
    final locked = d['locked'] == true;
    try {
      final res = await ApiService().setDeviceLock(deviceId, !locked);
      if (!mounted) return;
      if (res['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              !locked
                  ? '"$deviceName" dikunci'
                  : '"$deviceName" dibuka kuncinya',
            ),
            backgroundColor: NeoColors.green,
          ),
        );
        _load();
        context.read<AppRefreshProvider>().bump();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              res['error']?['message'] ?? 'Gagal memperbarui kunci device',
            ),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal memperbarui kunci device: $e'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  Future<void> _delete(Map<String, dynamic> d) async {
    final deviceId = (d['id'] ?? '').toString();
    final deviceName = (d['name'] ?? '').toString();
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: NeoGlassOverlay(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'HAPUS DEVICE?',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  color: NeoColors.primaryText,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Device "$deviceName" akan dihapus permanen.\nSemua aktivitas, notifikasi, dan permission ikut terhapus.\nLanjutkan?',
                textAlign: TextAlign.center,
                style: TextStyle(color: NeoColors.secondaryText),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text(
                        'BATAL',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: NeoButton(
                      label: 'HAPUS',
                      height: 40,
                      fontSize: 13,
                      bgColor: NeoColors.pink,
                      textColor: Colors.white,
                      onPressed: () => Navigator.pop(ctx, true),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed != true || !mounted) return;

    try {
      final res = await ApiService().deleteDevice(deviceId);
      if (!mounted) return;
      if (res['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Device "$deviceName" dihapus'),
            backgroundColor: NeoColors.green,
          ),
        );
        await _load();
        if (mounted) context.read<AppRefreshProvider>().bump();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(res['error']?['message'] ?? 'Gagal menghapus device'),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal menghapus device: $e'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SceneBackground(
      theme: FeatureConfig.device,
      screenIndex: FeatureConfig.deviceIndex,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.sm,
                  NeoSpacing.lg,
                  ScrollClearance.bottomNav(context),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.devices_other,
                          color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'DEVICES',
                          style: GoogleFonts.cinzel(
                            textStyle: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2,
                              color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.marble,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  skin.isBubbleGum ? palette.primary.withValues(alpha: 0.60) : NeoColors.goldDeep.withValues(alpha: 102 / 255),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    NeoTable(
                      headers: const [
                        'NAMA',
                        'MODEL',
                        'PEMILIK',
                        'STATUS',
                        'AKSI',
                      ],
                      columnWidths: const [8, 8, 8, 6, 8],
                      loading: _loading,
                      emptyWidget: Padding(
                        padding: const EdgeInsets.all(NeoSpacing.xl),
                        child: Center(
                          child: Text(
                            'Belum ada device',
                            style: TextStyle(
                              fontSize: 13,
                              color: isDark
                                  ? NeoColors.secondaryText
                                  : NeoColors.grey,
                            ),
                          ),
                        ),
                      ),
                      rows: [for (final d in _devices) _row(d, isDark)],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _row(Map<String, dynamic> d, bool isDark) {
    final status = (d['status'] ?? 'offline').toString();
    final isOnline = status == 'online';
    final statusColor = isOnline ? NeoColors.green : NeoColors.grey;
    final owner = (d['owner_username'] ?? '').toString();
    return [
      Text(
        (d['name'] ?? '').toString(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      Text(
        (d['model'] ?? '').toString(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      Text(
        owner.isEmpty ? 'TANPA USER' : owner,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: statusColor,
          border: Border.all(color: NeoColors.black, width: 1.5),
          borderRadius: BorderRadius.circular(NeoRadius.sm),
        ),
        child: Text(
          status.toUpperCase(),
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w800,
            color: isDark ? NeoColors.primaryText : Colors.black,
          ),
        ),
      ),
      Wrap(
        spacing: 2,
        runSpacing: 2,
        children: [
          if (_isDeveloper) ...[
            Tooltip(
              message: 'Transfer Ownership',
              child: InkWell(
                onTap: () => _transfer(d),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.swap_horiz,
                    size: 18,
                    color: NeoColors.yellow,
                  ),
                ),
              ),
            ),
            Tooltip(
              message: (d['locked'] == true)
                  ? 'Buka Kunci Device'
                  : 'Kunci Device',
              child: InkWell(
                onTap: () => _toggleLock(d),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    (d['locked'] == true) ? Icons.lock : Icons.lock_open,
                    size: 18,
                    color: (d['locked'] == true)
                        ? NeoColors.yellow
                        : NeoColors.grey,
                  ),
                ),
              ),
            ),
            Tooltip(
              message: 'Hapus Device',
              child: InkWell(
                onTap: () => _delete(d),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.delete_outline,
                    size: 18,
                    color: NeoColors.pink,
                  ),
                ),
              ),
            ),
          ] else if (_isPartner || _isModerator) ...[
            Tooltip(
              message: (d['locked'] == true)
                  ? 'Device di-lock developer'
                  : 'Transfer Ownership',
              child: InkWell(
                onTap: (d['locked'] == true) ? null : () => _transfer(d),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    (d['locked'] == true) ? Icons.lock : Icons.swap_horiz,
                    size: 18,
                    color: (d['locked'] == true)
                        ? NeoColors.grey
                        : NeoColors.yellow,
                  ),
                ),
              ),
            ),
            Tooltip(
              message: (d['locked'] == true)
                  ? 'Device di-lock developer'
                  : 'Hapus Device',
              child: InkWell(
                onTap: (d['locked'] == true) ? null : () => _delete(d),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.delete_outline,
                    size: 18,
                    color: (d['locked'] == true)
                        ? NeoColors.grey
                        : NeoColors.pink,
                  ),
                ),
              ),
            ),
          ] else if (widget.onOpenControl != null)
            Tooltip(
              message: 'Buka Control',
              child: InkWell(
                onTap: () => widget.onOpenControl!(Device.fromJson(d)),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.tune_rounded,
                    size: 18,
                    color: NeoColors.gold,
                  ),
                ),
              ),
            )
          else
            const Text('—', style: TextStyle(color: NeoColors.grey)),
        ],
      ),
    ];
  }
}
