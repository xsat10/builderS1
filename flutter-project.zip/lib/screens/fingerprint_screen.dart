import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../theme.dart';
import '../providers/theme_provider.dart';

/// First landing screen — mandatory fingerprint scan.
///
/// Themed fingerprint gate shown before the pre-login card deck.
class FingerprintScreen extends StatefulWidget {
  const FingerprintScreen({super.key});

  @override
  State<FingerprintScreen> createState() => _FingerprintScreenState();
}

class _FingerprintScreenState extends State<FingerprintScreen>
  with TickerProviderStateMixin {
  bool _authInProgress = false;
  late final AnimationController _enter;
  late final AnimationController _pulse;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _enter = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fade = CurvedAnimation(parent: _enter, curve: Curves.easeOut);
    _scale = Tween(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _enter, curve: Curves.easeOutBack),
    );
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  Future<void> _handleFingerprint() async {
    if (_authInProgress) return;
    setState(() => _authInProgress = true);
    await Future<void>.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;
    setState(() => _authInProgress = false);
    final auth = context.read<AuthProvider>();
    await auth.tryAutoLogin();
    if (!mounted) return;
    final hasSession = auth.authenticated;
    _showMessage(
      hasSession
          ? 'Sidik jari dikenali. Membuka video…'
          : 'Sidik jari dikenali. Membuka kartu…',
    );
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (!mounted) return;
    Navigator.of(context).pushReplacementNamed(
      hasSession ? '/video' : '/prelogin',
    );
  }

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        behavior: SnackBarBehavior.floating,
        content: Text(
          msg,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: NeoColors.primaryText,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: const Color(0xCC101820),
      ),
    );
  }

  @override
  void dispose() {
    _enter.dispose();
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          Navigator.of(context).pop();
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: NeoColors.darkBg,
        body: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/bg/screen.png', fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.45),
                    Colors.black.withValues(alpha: 0.20),
                    Colors.black.withValues(alpha: 0.75),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                  horizontal: 28,
                  vertical: 24,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 28),
                    FadeTransition(
                      opacity: _fade,
                      child: ScaleTransition(
                        scale: _scale,
                        child: _buildBrand(),
                      ),
                    ),
                    const SizedBox(height: 26),
                    _buildPrompt(),
                    const SizedBox(height: 28),
                    _buildFingerprintCard(),
                    const SizedBox(height: 18),
                    Text(
                      'Sidik jari wajib dipindai untuk membuka kunci.',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: NeoColors.secondaryText,
                        letterSpacing: 0.4,
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildHintRow(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBrand() {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.75) : NeoColors.gold.withValues(alpha: 102 / 255),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.35) : NeoColors.gold.withValues(alpha: 85 / 255),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipOval(
            child: Image.asset('assets/logo.png', fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'NOVACORE',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
            letterSpacing: 6,
            fontFamily: 'monospace',
            shadows: [
              Shadow(color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.45) : NeoColors.gold.withValues(alpha: 102 / 255), blurRadius: 18),
            ],
          ),
        ),
        SizedBox(height: 4),
        Text(
          'BUG x RAT',
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
            letterSpacing: 3,
            fontFamily: 'monospace',
          ),
        ),
      ],
    );
  }

  Widget _buildPrompt() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'BERIKAN SIDIK JARI ANDA',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: NeoColors.primaryText,
            letterSpacing: 2.4,
          ),
        ),
        SizedBox(height: 6),
        Text(
          'Pindai sidik jari di sensor perangkat untuk membuka kunci ke kartu NovaCore.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
            color: NeoColors.secondaryText,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildFingerprintCard() {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return GestureDetector(
      onTap: _handleFingerprint,
      onLongPress: _handleFingerprint,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            height: 188,
            width: double.infinity,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: _authInProgress
                    ? [
                        (skin.isBubbleGum ? palette.primary : NeoColors.gold).withValues(alpha: 0.20),
                        NeoColors.black.withValues(alpha: 0.35),
                      ]
                    : [
                        Colors.white.withValues(alpha: 0.10),
                        Colors.white.withValues(alpha: 0.03),
                      ],
              ),
              border: Border.all(
                color: _authInProgress
                    ? (skin.isBubbleGum ? palette.primary : NeoColors.gold).withValues(alpha: 0.85)
                    : skin.isBubbleGum ? palette.primary.withValues(alpha: 0.45) : NeoColors.gold.withValues(alpha: 68 / 255),
                width: 1.3,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: (_authInProgress
                          ? (skin.isBubbleGum ? palette.primary : NeoColors.gold)
                          : (skin.isBubbleGum ? palette.primary : NeoColors.gold).withValues(alpha: 0.10))
                      .withValues(alpha: 0.30),
                  blurRadius: 32,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AnimatedBuilder(
                  animation: _pulse,
                  builder: (context, child) {
                    final glow = 18 + (_pulse.value * 12);
                    return Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: (skin.isBubbleGum ? palette.primary : NeoColors.gold).withValues(alpha: 0.12),
                        border: Border.all(
                          color: (skin.isBubbleGum ? palette.primary : NeoColors.gold).withValues(
                            alpha: 0.55 + (_pulse.value * 0.25),
                          ),
                          width: 1.4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.40) : NeoColors.gold.withValues(alpha: 102 / 255),
                            blurRadius: glow,
                            spreadRadius: _pulse.value * 2,
                          ),
                        ],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          child!,
                          if (_authInProgress)
                            SizedBox(
                              width: 68,
                              height: 68,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.2,
                                color: NeoColors.gold,
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                  child: Icon(
                    Icons.fingerprint,
                    size: 42,
                    color: NeoColors.gold,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _authInProgress
                      ? 'MEMINDAI SIDIK JARI…'
                      : 'TAP ATAU TAHAN UNTUK MEMINDAI',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.6,
                    color: NeoColors.primaryText,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHintRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          Icons.lock_open_outlined,
          size: 14,
          color: NeoColors.gold,
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            'Animasi pemindaian aktif — akses dibuka otomatis',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10.5,
              color: NeoColors.secondaryText,
            ),
          ),
        ),
      ],
    );
  }
}
