import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme.dart';
import '../utils/app_config.dart';
import '../providers/auth_provider.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_social_button.dart';
import '../widgets/roman_sheet.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _logoFade;
  late final Animation<double> _logoScl;
  late final Animation<double> _titleSlide;
  late final Animation<double> _btnSlide;
  late final Animation<double> _socialFade;

  @override
  void initState() {
    super.initState();
    context.read<AuthProvider>().addListener(_onAuthChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _showBlockedIfAny());
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _logoFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0, 0.35, curve: Curves.easeOut),
      ),
    );
    _logoScl = Tween<double>(begin: 0.6, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0, 0.35, curve: Curves.easeOutBack),
      ),
    );
    _titleSlide = Tween<double>(begin: 24, end: 0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.2, 0.5, curve: Curves.easeOut),
      ),
    );
    _btnSlide = Tween<double>(begin: 32, end: 0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.4, 0.7, curve: Curves.easeOut),
      ),
    );
    _socialFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.6, 1, curve: Curves.easeOut),
      ),
    );
    _ctrl.forward();
  }

  @override
  void dispose() {
    context.read<AuthProvider>().removeListener(_onAuthChanged);
    _ctrl.dispose();
    super.dispose();
  }

  void _onAuthChanged() => _showBlockedIfAny();

  void _showBlockedIfAny() {
    final auth = context.read<AuthProvider>();
    final msg = auth.sessionBlockedMessage;
    if (msg == null || !mounted) return;
    auth.clearSessionBlocked();
    showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => SessionKickedDialog(message: msg),
    );
  }

  Future<void> _launch(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Could not open: $url'),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: NeoColors.darkBg,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // Background Artwork
            Image.asset('assets/bg/login_screen.png', fit: BoxFit.cover),
            // Dark Gradient Overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.60),
                    Colors.black.withValues(alpha: 0.30),
                    Colors.black.withValues(alpha: 0.70),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 32),

                      // Glass Logo
                      FadeTransition(
                        opacity: _logoFade,
                        child: ScaleTransition(
                          scale: _logoScl,
                          child: Container(
                            width: 104,
                            height: 104,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: NeoColors.gold.withValues(alpha: 102 / 255),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoColors.gold.withValues(alpha: 85 / 255),
                                  blurRadius: 32,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: ClipOval(
                              child: Image.asset(
                                'assets/logo.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Branding Title
                      AnimatedBuilder(
                        animation: _titleSlide,
                        builder: (ctx, _) => Transform.translate(
                          offset: Offset(0, _titleSlide.value),
                          child: Column(
                            children: [
                              Text(
                                'NOVACORE',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 3,
                                  color: NeoColors.primaryText,
                                  fontFamily: 'monospace',
                                  shadows: [
                                    Shadow(
                                      color: NeoColors.gold.withValues(alpha: 85 / 255),
                                      blurRadius: 16,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'BUG x RAT',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: NeoColors.gold,
                                  letterSpacing: 3,
                                  fontFamily: 'monospace',
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Design By @alexyusomo',
                                style: TextStyle(
                                  fontSize: 8.5,
                                  fontWeight: FontWeight.w700,
                                  color: NeoColors.secondaryText,
                                  letterSpacing: 2,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 60),

                      // Action Buttons
                      AnimatedBuilder(
                        animation: _btnSlide,
                        builder: (ctx, _) => Transform.translate(
                          offset: Offset(0, _btnSlide.value),
                          child: Column(
                            children: [
                              NeoButton(
                                label: 'LOGIN',
                                bgColor: NeoColors.gold,
                                textColor: NeoColors.ink,
                                height: 50,
                                fontSize: 15,
                                onPressed: () => Navigator.of(context)
                                    .pushNamedAndRemoveUntil(
                                      '/login',
                                      (route) => false,
                                    ),
                              ),
                              const SizedBox(height: 16),
                              NeoButton(
                                label: 'BUY NOW',
                                bgColor: const Color(0x22FFFFFF),
                                textColor: NeoColors.primaryText,
                                height: 50,
                                fontSize: 15,
                                onPressed: () => _launch(AppConfig.buyNowUrl),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 48),

                      // Social Buttons
                      FadeTransition(
                        opacity: _socialFade,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            NeoSocialButton(
                              icon: Icons.chat_outlined,
                              label: 'WhatsApp',
                              onTap: () =>
                                  _launch(AppConfig.developerWhatsAppUrl),
                            ),
                            const SizedBox(width: 16),
                            NeoSocialButton(
                              icon: Icons.send_outlined,
                              label: 'Telegram',
                              onTap: () =>
                                  _launch(AppConfig.developerTelegramUrl),
                            ),
                            const SizedBox(width: 16),
                            NeoSocialButton(
                              icon: Icons.code_outlined,
                              label: 'GitHub',
                              onTap: () =>
                                  _launch(AppConfig.developerGithubUrl),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
