import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import '../providers/public_chat_unread_provider.dart';
import '../providers/connection_provider.dart';
import '../providers/device_provider.dart';
import '../providers/whatsapp_provider.dart';
import '../providers/news_provider.dart';
import '../models/news_item.dart';
import '../services/prayer_service.dart';
import '../services/remote_config_service.dart';
import '../services/api_service.dart';
import '../utils/app_config.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_card.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scroll_clearance.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_game_dialog.dart';
import '../widgets/neo_news_carousel.dart';
import '../widgets/neo_role_badge.dart';
import '../widgets/neo_role_ring.dart';
import '../widgets/nova_stories_section.dart';
import '../widgets/roman_sheet.dart';
import '../widgets/neo_roman_clock.dart';
import '../public.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DeviceProvider>().loadDevices();
      context.read<WhatsAppProvider>().loadSenders();
      context.read<NewsProvider>().loadNews();
      context.read<PublicChatUnreadProvider>().refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SceneBackground(
      theme: FeatureConfig.dashboard,
      screenIndex: 0,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  0,
                  NeoSpacing.sm,
                  0,
                  ScrollClearance.bottomNav(context),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _pad(const _HeroCard()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    const NovaStoriesSection(),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _AccountDataCard()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    const _HomeNewsSection(),
                    if (context.watch<NewsProvider>().news.isNotEmpty) ...[
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: NeoSpacing.md),
                        child: _RomanDivider(),
                      ),
                    ],
                    _pad(const NeoNewsCarousel()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const NovaGamesCard()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(_SectionTitle('JADWAL IBADAH')),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _PrayerCard()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _RomanDivider()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(_SectionTitle('CONNECT WITH')),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _PublicChatBanner()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _DeveloperCard()),
                    const SizedBox(height: NeoSpacing.md),
                    _pad(const _ConnectCard()),
                    const SizedBox(height: NeoSpacing.lg),
                    _pad(
                      const RomanFooter(
                        words: 'SENATVS POPVLVSQVE NOVACORE',
                        subline: 'PAX · ET · PROSPERITAS',
                      ),
                    ),
                    const SizedBox(height: NeoSpacing.sm),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final b = RemoteConfigService.instance.branding;
    final appName = b['appName']?.toString() ?? 'NovaCore';
    final tagline = b['tagline']?.toString() ?? 'Audentes Fortuna Iuvat';

    return NeoCard(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      child: Column(
        children: [
          Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: skin.isBubbleGum
                    ? [palette.primary, palette.accent, palette.secondary]
                    : [NeoColors.gold, NeoColors.goldDeep, Color(0xFF8A6D2B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0x99FFFFFF), width: 2),
              boxShadow: [
                BoxShadow(
                  color: skin.isBubbleGum ? palette.primary.withValues(alpha: 0.40) : NeoColors.gold.withValues(alpha: 138 / 255),
                  blurRadius: 30,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/logo.png',
                width: 84,
                height: 84,
                fit: BoxFit.cover,
                errorBuilder: (_, _, _) => Icon(
                  Icons.account_balance_rounded,
                  size: 40,
                  color: NeoColors.darkCard,
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            tagline.toUpperCase(),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 13,
              fontWeight: FontWeight.w800,
              letterSpacing: 3,
              color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
            ),
          ),
          const SizedBox(height: 10),
          // Brand name penuh: pembatas kiri/kanan memanjang hingga tepi card
          // sehingga card tidak tampak "setengah" / tidak penuh di lebar.
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 1,
                  color: skin.isBubbleGum
                      ? palette.primary.withValues(alpha: 0.55)
                      : NeoColors.gold.withValues(alpha: 102 / 255),
                ),
              ),
              const SizedBox(width: 12),
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    appName.toUpperCase(),
                    style: GoogleFonts.cinzel(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 6,
                      color: NeoColors.primaryText,
                      shadows: [
                        Shadow(color: NeoColors.gold.withValues(alpha: 102 / 255), blurRadius: 14),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  height: 1,
                  color: skin.isBubbleGum
                      ? palette.primary.withValues(alpha: 0.55)
                      : NeoColors.gold.withValues(alpha: 102 / 255),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            '— Alex Yusomo —',
            style: TextStyle(
              fontSize: 11,
              color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _AccountDataCard extends StatefulWidget {
  const _AccountDataCard();

  @override
  State<_AccountDataCard> createState() => _AccountDataCardState();
}

class _AccountDataCardState extends State<_AccountDataCard> {
  int _userCount = 0;
  int _onlineCount = 0;
  bool _statsLoaded = false;
  Timer? _statsTimer;

  @override
  void initState() {
    super.initState();
    _load();
    _statsTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) _load();
    });
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final r = await ApiService().getStats();
    if (!mounted) return;
    setState(() {
      if (r['success'] == true && r['data'] is Map) {
        final data = Map<String, dynamic>.from(r['data'] as Map);
        _userCount = _readCount(data['total_users']);
        _onlineCount = _readCount(data['online_users']);
        _statsLoaded = true;
      }
    });
    if (_statsLoaded && _userCount > 0) return;

    // Fallback for servers that have not deployed the new /api/stats code.
    final users = await ApiService().getUsers();
    if (!mounted) return;
    if (users['success'] == true && users['data'] is List) {
      final activeUsers = (users['data'] as List)
          .where((user) => user is Map && user['status'] != 'deleted')
          .length;
      if (activeUsers > 0) {
        setState(() {
          _userCount = activeUsers;
          _onlineCount = context.read<ConnectionProvider>().socketConnected
              ? 1
              : _onlineCount;
          _statsLoaded = true;
        });
        return;
      }
    }

    if (!_statsLoaded) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && !_statsLoaded) _load();
      });
    }
  }

  int _readCount(Object? value) {
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '') ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final conn = context.watch<ConnectionProvider>();
    final user = auth.user;
    final dp = context.watch<DeviceProvider>();
    final wp = context.watch<WhatsAppProvider>();
    final b = RemoteConfigService.instance.branding;
    final motto = b['motto']?.toString() ?? 'Flectere Si Nequeo Superos, Acheronta Movebo';
    final initials = _getInitials(user?.displayName ?? '?');
    final roleColor = NeoColors.roleColor(user?.role ?? 'member');
    final free = user?.isFree ?? false;

    return Column(
      children: [
        NeoCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  SizedBox(
                    width: 62,
                    height: 62,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Positioned.fill(
                          child: free
                              ? Container(
                                  margin: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        roleColor,
                                        roleColor.withValues(alpha: 0.6),
                                      ],
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: const Color(0x33FFFFFF),
                                      width: 2,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withValues(
                                          alpha: 0.35,
                                        ),
                                        blurRadius: 12,
                                      ),
                                    ],
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: (user?.avatar?.isNotEmpty ?? false)
                                      ? Image.network(
                                          user!.avatar!,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, _, _) => Center(
                                            child: Text(
                                              initials,
                                              style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w800,
                                                color: NeoColors.darkCard,
                                              ),
                                            ),
                                          ),
                                        )
                                      : Center(
                                          child: Text(
                                            initials,
                                            style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w800,
                                              color: NeoColors.darkCard,
                                            ),
                                          ),
                                        ),
                                )
                              : NeoRoleRing(
                                  role: user?.role ?? 'member',
                                  size: 62,
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          roleColor,
                                          roleColor.withValues(alpha: 0.6),
                                        ],
                                      ),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: const Color(0x77FFFFFF),
                                        width: 2,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: roleColor.withValues(
                                            alpha: 0.5,
                                          ),
                                          blurRadius: 16,
                                        ),
                                      ],
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                    child: (user?.avatar?.isNotEmpty ?? false)
                                        ? Image.network(
                                            user!.avatar!,
                                            fit: BoxFit.cover,
                                            errorBuilder: (_, _, _) => Center(
                                              child: Text(
                                                initials,
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w800,
                                                  color: NeoColors.darkCard,
                                                ),
                                              ),
                                            ),
                                          )
                                        : Center(
                                            child: Text(
                                              initials,
                                              style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w800,
                                                color: NeoColors.darkCard,
                                              ),
                                            ),
                                          ),
                                  ),
                                ),
                        ),
                        if (!free)
                          Positioned(
                            right: -3,
                            bottom: -3,
                            child: NeoRoleBadge(
                              role: user?.role ?? 'member',
                              size: 20,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.displayIdentifier ?? 'Not logged in',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: NeoColors.primaryText,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            if (!free)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  color: roleColor,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  user?.roleLabel ?? 'MEMBER',
                                  style: const TextStyle(
                                    fontSize: 8,
                                    fontWeight: FontWeight.w800,
                                    color: NeoColors.white,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                            const SizedBox(width: 6),
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: conn.connected
                                    ? const Color(0xFF00E676)
                                    : NeoColors.grey,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              conn.connected ? 'ONLINE' : 'OFFLINE',
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                color: conn.connected
                                    ? const Color(0xFF00E676)
                                    : NeoColors.grey,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    flex: 0,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerRight,
                      child: const Padding(
                        padding: EdgeInsets.all(2),
                        child: NeoRomanClock(size: 44),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                height: 30,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: NeoColors.gold.withValues(alpha: 51 / 255), width: 1),
                ),
                child: Text(
                  motto.toUpperCase(),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 4,
                    color: NeoColors.primaryText,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: NeoSpacing.sm),
        NeoCard(
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _RoundStat(
                      label: 'ONLINE USER',
                      value: _onlineCount.toString(),
                      color: NeoColors.gold,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _RoundStat(
                      label: 'SENDER',
                      value: '${wp.connectedSenders}/${wp.totalSenders}',
                      color: NeoColors.blue,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _RoundStat(
                      label: 'DEVICE',
                      value: '${dp.onlineDevices}/${dp.totalDevices}',
                      color: NeoColors.green,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _RoundStat(
                      label: 'TOTAL USER',
                      value: _userCount.toString(),
                      color: NeoColors.orange,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: conn.connected
                          ? const Color(0xFF00E676)
                          : NeoColors.grey,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    conn.connected ? 'SOCKET TERHUBUNG' : 'SOCKET TERPUTUS',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                      color: conn.connected
                          ? const Color(0xFF00E676)
                          : NeoColors.grey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _ExpiryStat(expiresAt: user?.expiresAt),
            ],
          ),
        ),
      ],
    );
  }

  String _getInitials(String name) {
    if (name.isEmpty) return '?';
    if (name.startsWith('@')) name = name.substring(1);
    final parts = name.split(RegExp(r'[. _]'));
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return name[0].toUpperCase();
  }
}

class _RoundStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _RoundStat({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0x0FFFFFFF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x22FFFFFF), width: 1),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 8,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
              color: NeoColors.secondaryText,
            ),
          ),
        ],
      ),
    );
  }
}

class _ExpiryStat extends StatelessWidget {
  final String? expiresAt;
  const _ExpiryStat({this.expiresAt});

  bool _isUnlimited(String? iso) => iso == null || iso.isEmpty;

  String _fmt(String iso) {
    final dt = DateTime.tryParse(iso);
    if (dt == null) return '∞';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    if (_isUnlimited(expiresAt)) {
      return _pill(
        label: 'UNLIMITED',
        pillBg: LinearGradient(
          colors: [NeoColors.gold, NeoColors.goldDeep],
        ),
        pillColor: const Color(0xFF2A1E00),
        caption: 'AKSES SELAMANYA',
        captionColor: NeoColors.gold,
        track: [NeoColors.gold.withValues(alpha: 51 / 255), NeoColors.gold.withValues(alpha: 20 / 255)],
        border: NeoColors.gold.withValues(alpha: 102 / 255),
        icon: Icons.all_inclusive_rounded,
      );
    }

    final dt = DateTime.tryParse(expiresAt!);
    final expired = dt != null && !dt.isAfter(DateTime.now());

    if (dt == null) {
      return _pill(
        label: 'EXP DATE',
        pillBg: LinearGradient(
          colors: [NeoColors.goldDeep, Color(0xFF8A6D2B)],
        ),
        pillColor: NeoColors.white,
        caption: 'OPSI AKSES',
        captionColor: NeoColors.gold,
        track: [NeoColors.gold.withValues(alpha: 51 / 255), NeoColors.gold.withValues(alpha: 20 / 255)],
        border: NeoColors.gold.withValues(alpha: 102 / 255),
      );
    }

    if (expired) {
      return _pill(
        label: 'EXPIRED',
        pillBg: const LinearGradient(
          colors: [Color(0xFFFF5252), Color(0xFFD63B3B)],
        ),
        pillColor: NeoColors.white,
        caption: 'Akses kedaluwarsa. Perpanjang untuk melanjutkan.',
        captionColor: NeoColors.pink,
        track: const [Color(0x33FF5252), Color(0x14FF5252)],
        border: const Color(0x66FF5252),
        icon: Icons.timer_off_rounded,
      );
    }

    // Aktif / TRIAL: tampilkan sisa hari + tanggal kedaluwarsa.
    final now = DateTime.now();
    final daysLeft = dt.difference(now).inDays + 1;
    final closeToExpiry = daysLeft <= 3;
    final accent = closeToExpiry
        ? const Color(0xFFFF9F43)
        : NeoColors.gold;
    return _pill(
      label: 'AKTIF',
      pillBg: LinearGradient(colors: [accent, accent.withValues(alpha: 0.7)]),
      pillColor: const Color(0xFF2A1E00),
      caption:
          '${_fmt(expiresAt!)}  ·  ${daysLeft > 1 ? '$daysLeft hari lagi' : 'Hari terakhir'}${closeToExpiry ? '  — segera perpanjang' : ''}',
      captionColor: closeToExpiry ? NeoColors.orange : NeoColors.gold,
      track: [accent.withValues(alpha: 0.22), accent.withValues(alpha: 0.10)],
      border: accent.withValues(alpha: 0.55),
      icon: Icons.verified_rounded,
    );
  }

  Widget _pill({
    required String label,
    required Gradient pillBg,
    required Color pillColor,
    required String caption,
    required Color captionColor,
    required List<Color> track,
    required Color border,
    IconData? icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: track,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border, width: 1),
      ),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, size: 15, color: captionColor),
            const SizedBox(width: 8),
          ],
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              gradient: pillBg,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                color: pillColor,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              caption,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: captionColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PrayerCard extends StatefulWidget {
  const _PrayerCard();

  @override
  State<_PrayerCard> createState() => _PrayerCardState();
}

class _PrayerCardState extends State<_PrayerCard> {
  Map<String, dynamic>? _data;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final d = await PrayerService.instance.getTodaySchedule();
    if (!mounted) return;
    setState(() {
      _data = d;
      _loading = false;
    });
  }

  static const _rows = [
    ('Subuh', 'subuh', Icons.wb_twilight),
    ('Dzuhur', 'dzuhur', Icons.wb_sunny),
    ('Ashar', 'ashar', Icons.wb_cloudy),
    ('Maghrib', 'maghrib', Icons.nightlight),
    ('Isya', 'isya', Icons.dark_mode),
  ];

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return NeoCard(
      child: _loading
          ? const Padding(
              padding: EdgeInsets.all(20),
              child: Center(child: NeoBlockLoader(label: '')),
            )
          : _data == null
          ? Padding(
              padding: EdgeInsets.all(20),
              child: Center(
                child: Text(
                  'Jadwal tidak tersedia',
                  style: TextStyle(color: NeoColors.secondaryText),
                ),
              ),
            )
          : Column(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.mosque_rounded,
                      size: 18,
                      color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '${_data!['kota']}',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: NeoColors.primaryText,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '${_data!['date']}',
                      style: TextStyle(
                        fontSize: 11,
                        color: NeoColors.secondaryText,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                for (final (name, key, icon) in _rows)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      children: [
                        Icon(
                          icon,
                          size: 16,
                          color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            name,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: NeoColors.primaryText,
                              fontSize: 13,
                            ),
                          ),
                        ),
                        Text(
                          _data![key]?.toString() ?? '—',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}

class _PublicChatBanner extends StatelessWidget {
  const _PublicChatBanner();

  @override
  Widget build(BuildContext context) {
    final unread = context.watch<PublicChatUnreadProvider>().count;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final ink = palette.onBackground1;
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const PublicChatPage()),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: skin.isBubbleGum
                ? [palette.primary, palette.accent]
                : const [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: (skin.isBubbleGum ? palette.primary : const Color(0xFFC9A55A)).withValues(alpha: 0.25),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: ink.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.public,
                color: ink,
                size: 24,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'NOVACORE CHAT',
                    style: GoogleFonts.cinzel(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: ink,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Ngobrol real-time dengan semua user',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: ink.withValues(alpha: 0.65),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: ink,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.arrow_forward_rounded,
                color: skin.isBubbleGum ? palette.accent : const Color(0xFFE8D5A3),
                size: 18,
              ),
            ),
            if (unread > 0)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: _UnreadBadge(count: unread),
              ),
          ],
        ),
      ),
    );
  }
}

class _UnreadBadge extends StatelessWidget {
  final int count;
  const _UnreadBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.redAccent,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        '$count pesan belum terbaca',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _DeveloperCard extends StatelessWidget {
  const _DeveloperCard();

  Future<void> _launchTelegram(BuildContext context) async {
    final url = AppConfig.createNovaBotUrl;
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _launchTelegram(context),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              NeoColors.gold.withValues(alpha: 51 / 255),
              Color(0x1F1B1030),
              Color(0x440D081D),
            ],
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: NeoColors.gold.withValues(alpha: 51 / 255),
              blurRadius: 20,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            // Mahkota raja (laurel)
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    NeoColors.gold,
                    NeoColors.goldDeep,
                    Color(0xFF8A6D2B),
                  ],
                ),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0x99FFFFFF), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: NeoColors.gold.withValues(alpha: 138 / 255),
                    blurRadius: 22,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(
                Icons.workspace_premium_rounded,
                color: Color(0xFF0D0D2B),
                size: 28,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ASSISTENT ABADI',
                    style: GoogleFonts.cinzel(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 3,
                      color: NeoColors.gold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'ASSISTENT NOVACORE',
                    style: GoogleFonts.cinzel(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      color: NeoColors.marble,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Bot · TELEGRAM',
                    style: GoogleFonts.inter(
                      fontSize: 10,
                      letterSpacing: 1,
                      color: NeoColors.marble.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF0D0D2B),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.arrow_forward_rounded,
                color: NeoColors.gold,
                size: 18,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ConnectCard extends StatelessWidget {
  const _ConnectCard();

  Future<void> _launch(BuildContext context, String url, String label) async {
    if (url.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('$label belum dikonfigurasi. Hubungi developer.'),
            backgroundColor: NeoColors.goldDeep,
          ),
        );
      }
      return;
    }
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final s = RemoteConfigService.instance.social;
    final telegram = s['telegram']?.toString() ?? '';
    final instagram = s['instagram']?.toString() ?? '';
    final tiktok = s['tiktok']?.toString() ?? '';

    return NeoCard(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _SocialIcon(
            icon: Icons.telegram,
            label: 'TELEGRAM',
            color: const Color(0xFF229ED9),
            enabled: telegram.isNotEmpty,
            onTap: () => _launch(context, telegram, 'Telegram'),
          ),
          _SocialIcon(
            icon: Icons.camera_alt_rounded,
            label: 'INSTAGRAM',
            color: const Color(0xFFE4405F),
            enabled: instagram.isNotEmpty,
            onTap: () => _launch(context, instagram, 'Instagram'),
          ),
          _SocialIcon(
            icon: Icons.music_video_rounded,
            label: 'TIKTOK',
            color: const Color(0xFF69C9D0),
            enabled: tiktok.isNotEmpty,
            onTap: () => _launch(context, tiktok, 'TikTok'),
          ),
        ],
      ),
    );
  }
}

class _SocialIcon extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool enabled;
  final VoidCallback onTap;
  const _SocialIcon({
    required this.icon,
    required this.label,
    required this.color,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
        child: Column(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: enabled
                    ? LinearGradient(
                        colors: [color, color.withValues(alpha: 0.5)],
                      )
                    : const LinearGradient(
                        colors: [Color(0x33000000), Color(0x11000000)],
                      ),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 22,
                color: enabled ? Colors.white : NeoColors.secondaryText,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                color: NeoColors.secondaryText,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 18,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFC9A55A), Color(0xFFE8D5A3)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          text,
          style: GoogleFonts.cinzel(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            letterSpacing: 2.5,
            color: const Color(0xFFC9A55A),
          ),
        ),
      ],
    );
  }
}

Padding _pad(Widget child) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
  child: child,
);

class _HomeNewsSection extends StatelessWidget {
  const _HomeNewsSection();

  @override
  Widget build(BuildContext context) {
    return Consumer<NewsProvider>(
      builder: (_, provider, _) {
        final news = provider.news;
        // Kesampingkan bila tidak ada pengumuman dari server.
        if (news.isEmpty) return const SizedBox.shrink();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                top: NeoSpacing.md,
                bottom: NeoSpacing.md,
                left: NeoSpacing.lg,
              ),
              child: const _SectionTitle('PENGUMUMAN'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: NeoCard(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                child: Column(
                  children: [
                    for (var i = 0; i < news.length; i++) ...[
                      if (i > 0)
                        Divider(
                          height: 1,
                          thickness: 1,
                          color: context.read<NeoThemeProvider>().isBubbleGum
                              ? context.read<NeoThemeProvider>().palette.primary.withValues(alpha: 0.35)
                              : NeoColors.gold.withValues(alpha: 51 / 255),
                        ),
                      _AnnouncementRow(item: news[i]),
                    ],
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _AnnouncementRow extends StatelessWidget {
  final NewsItem item;
  const _AnnouncementRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final imageUrl = (item.backgroundImageUrl ?? item.imageUrl);
    final hasImage = imageUrl != null && imageUrl.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: SizedBox(
              width: 44,
              height: 44,
              child: hasImage
                  ? Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => _AnnouncementThumb(),
                      loadingBuilder: (ctx, child, progress) {
                        if (progress == null) return child;
                        return const _AnnouncementThumb();
                      },
                    )
                  : const _AnnouncementThumb(),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                    color: NeoColors.primaryText,
                  ),
                ),
                if (item.description.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(
                    item.description,
                    style: TextStyle(
                      fontSize: 11,
                      color: NeoColors.secondaryText,
                      height: 1.3,
                    ),
                  ),
                ],
                if (item.showButton &&
                    item.buttonText != null &&
                    item.buttonText!.isNotEmpty &&
                    (item.buttonUrl?.isNotEmpty ?? false)) ...[
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () async {
                      final url = item.buttonUrl!;
                      try {
                        await launchUrl(
                          Uri.parse(url),
                          mode: LaunchMode.externalApplication,
                        );
                      } catch (_) {}
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [NeoColors.gold, NeoColors.goldDeep],
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            item.buttonText!,
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF0D0D2B),
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(width: 4),
                          const Icon(
                            Icons.arrow_forward_rounded,
                            size: 13,
                            color: Color(0xFF0D0D2B),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AnnouncementThumb extends StatelessWidget {
  const _AnnouncementThumb();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [NeoColors.gold, NeoColors.goldDeep],
        ),
      ),
      child: Icon(
        Icons.campaign_rounded,
        color: NeoColors.darkCard,
        size: 20,
      ),
    );
  }
}

class _RomanDivider extends StatelessWidget {
  const _RomanDivider();

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final line = skin.isBubbleGum ? palette.primary : NeoColors.gold.withValues(alpha: 102 / 255);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [Colors.transparent, line.withValues(alpha: 0.72)],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: skin.isBubbleGum ? palette.accent : NeoColors.gold,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Transform.rotate(
                  angle: 0.785398,
                  child: Container(
                    width: 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                      borderRadius: BorderRadius.circular(1),
                      boxShadow: [
                        BoxShadow(
                          color: skin.isBubbleGum ? palette.primary : NeoColors.gold,
                          blurRadius: 8,
                          spreadRadius: 0.5,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: skin.isBubbleGum ? palette.accent : NeoColors.gold,
                    shape: BoxShape.circle,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [line.withValues(alpha: 0.72), Colors.transparent],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
