import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/remote_config_service.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_card.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scroll_clearance.dart';

class ManageScreen extends StatelessWidget {
  final void Function(int index)? onOpen;

  const ManageScreen({super.key, this.onOpen});

  static const List<({IconData icon, String title, String subtitle, int index})>
  _items = [
    (
      icon: Icons.people_outline,
      title: 'Users',
      subtitle: 'Manage users & roles',
      index: FeatureConfig.usersIndex,
    ),
    (
      icon: Icons.campaign_outlined,
      title: 'News',
      subtitle: 'Announcements & updates',
      index: FeatureConfig.newsIndex,
    ),
    (
      icon: Icons.widgets_outlined,
      title: 'Fitur WhatsApp',
      subtitle: 'Kelola fungsi kirim WhatsApp',
      index: FeatureConfig.featuresIndex,
    ),
    (
      icon: Icons.chat_bubble_outline,
      title: 'Senders',
      subtitle: 'Kelola semua sender WhatsApp',
      index: FeatureConfig.sendersIndex,
    ),
    (
      icon: Icons.qr_code_2,
      title: 'Pairing',
      subtitle: 'Daftar kode pairing device',
      index: FeatureConfig.pairingIndex,
    ),
    (
      icon: Icons.image_outlined,
      title: 'Set Image',
      subtitle: 'Gambar touch screen (Developer)',
      index: FeatureConfig.imageIndex,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SceneBackground(
      theme: FeatureConfig.manage,
      screenIndex: 6,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.sm,
                  NeoSpacing.lg,
                  ScrollClearance.bottomNav(context),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MANAGEMENT',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: isDark
                            ? NeoColors.secondaryText
                            : NeoColors.grey,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    ..._items.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: NeoSpacing.md),
                        child: _ManageTile(item: item, onOpen: onOpen),
                      ),
                    ),
                    Consumer<AuthProvider>(
                      builder: (_, auth, _) => auth.isDeveloper
                          ? Padding(
                              padding: const EdgeInsets.only(
                                top: NeoSpacing.sm,
                              ),
                              child: const _FreeAccessToggle(),
                            )
                          : const SizedBox.shrink(),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ManageTile extends StatelessWidget {
  final ({IconData icon, String title, String subtitle, int index}) item;
  final void Function(int index)? onOpen;

  const _ManageTile({required this.item, this.onOpen});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: () => onOpen?.call(item.index),
      child: NeoCard(
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: NeoColors.purple.withValues(alpha: 0.15),
                border: Border.all(
                  color: NeoColors.purple.withValues(alpha: 0.45),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(NeoRadius.md),
              ),
              child: Icon(item.icon, size: 24, color: NeoColors.purple),
            ),
            const SizedBox(width: NeoSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: isDark ? NeoColors.primaryText : NeoColors.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    item.subtitle,
                    style: const TextStyle(fontSize: 12, color: NeoColors.grey),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: isDark ? NeoColors.secondaryText : NeoColors.grey,
              size: 24,
            ),
          ],
        ),
      ),
    );
  }
}

class _FreeAccessToggle extends StatefulWidget {
  const _FreeAccessToggle();

  @override
  State<_FreeAccessToggle> createState() => _FreeAccessToggleState();
}

class _FreeAccessToggleState extends State<_FreeAccessToggle> {
  bool _saving = false;
  String? _error;
  bool _expanded = false;
  late TextEditingController _daysCtrl;
  bool _featureBug = false;
  bool _featureBan = false;
  bool _featureProtected = false;

  @override
  void initState() {
    super.initState();
    final cfg = RemoteConfigService.instance;
    _daysCtrl = TextEditingController(
      text: cfg.freeAccessDurationDays.toString(),
    );
    final features = cfg.freeAccessFeatures;
    _featureBug = features['bug'] == true;
    _featureBan = features['ban'] == true;
    _featureProtected = features['protected'] == true;
  }

  @override
  void dispose() {
    _daysCtrl.dispose();
    super.dispose();
  }

  Future<void> _toggle(bool value) async {
    setState(() {
      _saving = true;
      _error = null;
    });
    final ok = await RemoteConfigService.instance.setFreeAccessEnabled(value);
    if (!mounted) return;
    setState(() {
      _saving = false;
      if (!ok) {
        final reason = RemoteConfigService.instance.lastError;
        _error = reason == null || reason.isEmpty
            ? 'Gagal menyimpan konfigurasi.'
            : 'Gagal menyimpan: $reason';
      }
    });
    if (ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text(
            value ? 'Buat akun gratis: AKTIF' : 'Buat akun gratis: MATI',
          ),
          backgroundColor: NeoColors.green,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _saveConfig() async {
    setState(() {
      _saving = true;
      _error = null;
    });
    final days = int.tryParse(_daysCtrl.text.trim()) ?? 1;
    final ok = await RemoteConfigService.instance.setFreeAccessConfig(
      durationDays: days < 1 ? 1 : days,
      features: {
        'bug': _featureBug,
        'ban': _featureBan,
        'protected': _featureProtected,
      },
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Konfigurasi akses gratis tersimpan'),
          backgroundColor: NeoColors.green,
          duration: Duration(seconds: 2),
        ),
      );
    } else if (mounted) {
      final reason = RemoteConfigService.instance.lastError;
      setState(
        () => _error = reason == null || reason.isEmpty
            ? 'Gagal menyimpan.'
            : 'Gagal menyimpan: $reason',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cfg = RemoteConfigService.instance;
    final enabled = cfg.freeAccessEnabled;

    return NeoCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NeoColors.yellow.withValues(alpha: 0.18),
                    border: Border.all(
                      color: NeoColors.yellow.withValues(alpha: 0.5),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(NeoRadius.md),
                  ),
                  child: Icon(
                    Icons.person_add_alt,
                    size: 24,
                    color: NeoColors.gold,
                  ),
                ),
                const SizedBox(width: NeoSpacing.md),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Buat Akun Gratis',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: isDark
                              ? NeoColors.primaryText
                              : NeoColors.black,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        enabled
                            ? 'User bisa daftar akun tanpa invite'
                            : 'Daftar akun dinonaktifkan di login',
                        style: const TextStyle(
                          fontSize: 12,
                          color: NeoColors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: NeoSpacing.sm),
                Switch(
                  value: enabled,
                  onChanged: _saving ? null : _toggle,
                  activeThumbColor: NeoColors.yellow,
                  activeTrackColor: NeoColors.yellow.withValues(alpha: 0.3),
                ),
                const SizedBox(width: 4),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: const Icon(
                    Icons.expand_more,
                    color: NeoColors.grey,
                    size: 22,
                  ),
                ),
              ],
            ),
          ),
          AnimatedCrossFade(
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: const EdgeInsets.only(top: NeoSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(color: Color(0x22FFFFFF), height: 1),
                  const SizedBox(height: NeoSpacing.md),
                  Text(
                    'DURASI AKUN (HARI)',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.yellow,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: 120,
                    child: TextField(
                      controller: _daysCtrl,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        color: NeoColors.primaryText,
                        fontSize: 14,
                      ),
                      cursorColor: NeoColors.gold,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: const Color(0x0AFFFFFF),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(NeoRadius.lg),
                          borderSide: const BorderSide(
                            color: Color(0x22FFFFFF),
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(NeoRadius.lg),
                          borderSide: BorderSide(
                            color: NeoColors.gold,
                            width: 1.4,
                          ),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        suffixText: 'hari',
                        suffixStyle: const TextStyle(
                          color: NeoColors.grey,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: NeoSpacing.md),
                  Text(
                    'FITUR YANG BOLEH DIPAKAI',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.yellow,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _FeatureToggle(
                    label: 'Bug',
                    subtitle: 'Crash, freeze, delay, dll.',
                    value: _featureBug,
                    icon: Icons.bug_report_outlined,
                    color: NeoColors.pink,
                    onChanged: _saving
                        ? null
                        : (v) => setState(() => _featureBug = v),
                  ),
                  const SizedBox(height: 6),
                  _FeatureToggle(
                    label: 'Ban',
                    subtitle: 'Fungsi ban',
                    value: _featureBan,
                    icon: Icons.block,
                    color: NeoColors.orange,
                    onChanged: _saving
                        ? null
                        : (v) => setState(() => _featureBan = v),
                  ),
                  const SizedBox(height: 6),
                  _FeatureToggle(
                    label: 'Protected',
                    subtitle: 'Grup & target terproteksi',
                    value: _featureProtected,
                    icon: Icons.shield_outlined,
                    color: NeoColors.blue,
                    onChanged: _saving
                        ? null
                        : (v) => setState(() => _featureProtected = v),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      _error!,
                      style: const TextStyle(
                        fontSize: 11,
                        color: NeoColors.pink,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                  const SizedBox(height: NeoSpacing.md),
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: _saving ? null : _saveConfig,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [NeoColors.gold, NeoColors.goldDeep],
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: _saving
                            ? NeoBlockLoader(
                                compact: true,
                                size: 16,
                                c1: NeoColors.darkCard,
                                label: '',
                              )
                            : Text(
                                'SIMPAN',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  color: NeoColors.darkCard,
                                  letterSpacing: 1,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            crossFadeState: _expanded
                ? CrossFadeState.showSecond
                : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 250),
          ),
        ],
      ),
    );
  }
}

class _FeatureToggle extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool value;
  final IconData icon;
  final Color color;
  final ValueChanged<bool>? onChanged;

  const _FeatureToggle({
    required this.label,
    required this.subtitle,
    required this.value,
    required this.icon,
    required this.color,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: value ? color.withValues(alpha: 0.12) : const Color(0x06FFFFFF),
        borderRadius: BorderRadius.circular(NeoRadius.lg),
        border: Border.all(
          color: value ? color.withValues(alpha: 0.4) : const Color(0x11FFFFFF),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: value ? color : NeoColors.grey),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: value
                        ? NeoColors.primaryText
                        : NeoColors.secondaryText,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10,
                    color: value ? NeoColors.secondaryText : NeoColors.grey,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: color,
            activeTrackColor: color.withValues(alpha: 0.3),
          ),
        ],
      ),
    );
  }
}
