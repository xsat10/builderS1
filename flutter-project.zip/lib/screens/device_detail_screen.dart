import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/device_provider.dart';
import '../providers/auth_provider.dart';
import '../models/device.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_card.dart';
import '../widgets/neo_badge.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/neo_status_indicator.dart';
import '../services/api_service.dart';
import '../services/mic_live_player.dart';
import 'package:gal/gal.dart';
import '../widgets/scroll_clearance.dart';

class DeviceDetailScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const DeviceDetailScreen({super.key, this.onBack});

  @override
  State<DeviceDetailScreen> createState() => _DeviceDetailScreenState();
}

class _DeviceDetailScreenState extends State<DeviceDetailScreen> {
  bool _flashOn = false;
  bool _screenSharing = false;
  bool _cameraActive = false;
  bool _micActive = false;
  bool _touchLockActive = false;
  bool _disconnecting = false;
  bool _revoking = false;
  bool _screenshotDialogShowing = false;
  StreamSubscription<Map<String, dynamic>>? _screenStatusSub;
  final Map<String, bool> _featurePermitted = {};
  StreamSubscription<Map<String, dynamic>>? _actionResultSub;
  StreamSubscription<Map<String, dynamic>>? _screenshotSub;
  StreamSubscription<Map<String, dynamic>>? _cameraStatusSub;
  StreamSubscription<Map<String, dynamic>>? _micStatusSub;
  StreamSubscription<Map<String, dynamic>>? _touchStatusSub;
  StreamSubscription<Map<String, dynamic>>? _permissionSub;
  StreamSubscription<Map<String, dynamic>>? _stolenSub;
  String? _actionError;
  late final DeviceProvider _dp;

  @override
  void initState() {
    super.initState();
    _dp = context.read<DeviceProvider>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initPermissions();
      _listenActionResult();
      _listenScreenStatus();
      _listenScreenshots();
      _listenCameraStatus();
      _listenMicStatus();
      _listenTouchStatus();
      _listenPermissions();
      final device = _dp.selectedDevice;
      if (device != null) {
        _dp.emitView(device.id);
      }
      _stolenSub = _dp.socket.viewingStolenStream.listen((data) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Pemilik device mengambil alih tampilan'),
            backgroundColor: NeoColors.pink,
          ),
        );
        _dp.clearSelection();
        Navigator.of(context).pop();
      });
    });
  }

  void _initPermissions() {
    final dp = context.read<DeviceProvider>();
    final device = dp.selectedDevice;
    if (device == null) return;
    if (device.screenSharing) _featurePermitted['screen'] = true;
    if (device.camera) _featurePermitted['camera_start'] = true;
    if (device.microphone) _featurePermitted['microphone_start'] = true;
  }

  void _listenActionResult() {
    final dp = context.read<DeviceProvider>();
    _actionResultSub = dp.socket.activityStream.listen((data) {
      final type = data['type'] as String? ?? data['action'] as String? ?? '';
      final status = data['status'] as String? ?? '';
      if (type == 'screenshot' && status == 'error' && mounted) {
        _showError(data['message'] as String? ?? 'Screenshot failed');
      }
      if ((type == 'camera_start' ||
              type == 'camera_stop' ||
              type == 'camera_switch') &&
          status == 'error' &&
          mounted) {
        setState(() => _cameraActive = false);
        _showError(data['message'] as String? ?? 'Camera action failed');
      }
      if (type == 'microphone_start' && status == 'error' && mounted) {
        setState(() => _micActive = false);
        _showError(data['message'] as String? ?? 'Microphone action failed');
      }
      if (type == 'touch_lock') {
        if (mounted) setState(() => _touchLockActive = status == 'success');
        if (status == 'error' && mounted) {
          _showError(data['message'] as String? ?? 'Touch lock failed');
        }
      }
    });
  }

  void _listenScreenStatus() {
    final dp = context.read<DeviceProvider>();
    _screenStatusSub = dp.socket.screenStatusStream.listen((data) {
      final active = data['active'] as bool? ?? false;
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId != null && deviceId == selectedId && mounted) {
        setState(() => _screenSharing = active);
      }
    });
  }

  void _listenScreenshots() {
    final dp = context.read<DeviceProvider>();
    _screenshotSub = dp.socket.screenshotCapturedStream.listen((data) {
      if (!mounted) return;
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId == null || selectedId == null || deviceId != selectedId) {
        return;
      }

      final raw = data['data'];
      Uint8List? bytes;
      if (raw is String) {
        try {
          bytes = base64Decode(raw);
        } catch (_) {}
      } else if (raw is List<int>) {
        bytes = Uint8List.fromList(raw);
      }
      if (bytes == null || bytes.isEmpty) return;
      _showScreenshotDialog(bytes);
    });
  }

  void _showScreenshotDialog(Uint8List bytes) {
    if (_screenshotDialogShowing) return;
    _screenshotDialogShowing = true;
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: NeoCard(
          width: double.maxFinite,
          padding: const EdgeInsets.all(NeoSpacing.md),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    'SCREENSHOT',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => Navigator.pop(ctx),
                    child: const Icon(Icons.close, size: 22),
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.md),
              ClipRRect(
                borderRadius: BorderRadius.circular(NeoRadius.sm),
                child: Image.memory(
                  bytes,
                  fit: BoxFit.contain,
                  width: double.infinity,
                ),
              ),
              const SizedBox(height: NeoSpacing.md),
              Row(
                children: [
                  Expanded(
                    child: NeoButton(
                      label: 'DOWNLOAD IMAGE',
                      height: 40,
                      fontSize: 13,
                      onPressed: () => _downloadScreenshot(bytes),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ).whenComplete(() => _screenshotDialogShowing = false);
  }

  Future<void> _downloadScreenshot(Uint8List bytes) async {
    try {
      if (!await Gal.hasAccess()) {
        final granted = await Gal.requestAccess();
        if (!granted) {
          _showError('Izin akses galeri ditolak');
          return;
        }
      }
      await Gal.putImageBytes(
        bytes,
        album: 'NovaCore',
        name: 'screenshot_${DateTime.now().millisecondsSinceEpoch}',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Screenshot disimpan ke galeri'),
          backgroundColor: NeoColors.green,
        ),
      );
    } catch (_) {
      _showError('Gagal menyimpan screenshot');
    }
  }

  @override
  void dispose() {
    _stolenSub?.cancel();
    final deviceId = _dp.selectedDevice?.id;
    if (deviceId != null) {
      _dp.emitUnview(deviceId);
    }
    _actionResultSub?.cancel();
    _screenStatusSub?.cancel();
    _screenshotSub?.cancel();
    _cameraStatusSub?.cancel();
    _micStatusSub?.cancel();
    _touchStatusSub?.cancel();
    _permissionSub?.cancel();
    if (_cameraActive) {
      final deviceId = _dp.selectedDevice?.id;
      if (deviceId != null) {
        ApiService().sendAction(deviceId, 'camera_stop', 'stop');
      }
    }
    super.dispose();
  }

  Future<void> _toggleScreenShare(bool active) async {
    setState(() => _screenSharing = active);
    if (active) {
      final ok = await _sendAction('screen', 'start');
      if (!ok) {
        setState(() => _screenSharing = false);
      }
    } else {
      await _sendAction('screen', 'stop');
    }
  }

  void _listenCameraStatus() {
    final dp = context.read<DeviceProvider>();
    _cameraStatusSub = dp.socket.cameraStatusStream.listen((data) {
      final active = data['active'] as bool? ?? false;
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId != null && deviceId == selectedId && mounted) {
        setState(() => _cameraActive = active);
      }
    });
  }

  void _listenMicStatus() {
    final dp = context.read<DeviceProvider>();
    _micStatusSub = dp.socket.micStatusStream.listen((data) {
      final active = data['active'] as bool? ?? false;
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId != null && deviceId == selectedId && mounted) {
        setState(() => _micActive = active);
      }
    });
  }

  void _listenTouchStatus() {
    final dp = context.read<DeviceProvider>();
    _touchStatusSub = dp.socket.touchStatusStream.listen((data) {
      final active = data['active'] as bool? ?? false;
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId != null && deviceId == selectedId && mounted) {
        setState(() => _touchLockActive = active);
      }
    });
  }

  Future<void> _toggleTouchLock(bool active) async {
    if (active) {
      await _sendAction('touch_lock', 'start');
    } else {
      await _sendAction('touch_lock', 'stop');
    }
  }

  Future<void> _toggleCamera(bool active) async {
    setState(() => _cameraActive = active);
    if (active) {
      final ok = await _sendAction('camera_start', 'start');
      if (!ok) setState(() => _cameraActive = false);
    } else {
      await _sendAction('camera_stop', 'stop');
    }
  }

  void _listenPermissions() {
    final dp = context.read<DeviceProvider>();
    _permissionSub = dp.socket.permissionStream.listen((data) {
      final deviceId = data['deviceId'] as String?;
      final selectedId = dp.selectedDevice?.id;
      if (deviceId == null || selectedId == null || deviceId != selectedId) {
        return;
      }
      if (!mounted) return;
      setState(() {
        if (data['screenSharing'] != null) {
          _featurePermitted['screen'] = data['screenSharing'] as bool;
        }
        if (data['camera'] != null) {
          _featurePermitted['camera_start'] = data['camera'] as bool;
        }
        if (data['microphone'] != null) {
          _featurePermitted['microphone_start'] = data['microphone'] as bool;
        }
      });
    });
  }

  Future<bool> _sendAction(
    String type,
    String action, {
    Map<String, dynamic>? payload,
  }) async {
    final dp = context.read<DeviceProvider>();
    final api = ApiService();
    final deviceId = dp.selectedDevice?.id;
    if (deviceId == null) return false;
    final res = await api.sendAction(deviceId, type, action, payload: payload);
    if (res['success'] != true) {
      final msg = res['error']?['message'] ?? 'Action failed';
      if (mounted) {
        setState(() => _actionError = msg);
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) setState(() => _actionError = null);
        });
      }
      return false;
    }
    dp.loadActivities(deviceId);
    return true;
  }

  void _showError(String message) {
    if (!mounted) return;
    setState(() => _actionError = message);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _actionError = null);
    });
  }

  Future<void> _confirmAndDisconnect(Device device) async {
    final confirm = await NeoDialog.show(
      context: context,
      title: 'DISCONNECT DEVICE?',
      message: 'The device will be temporarily disconnected.',
      confirmLabel: 'DISCONNECT',
    );
    if (confirm != true || !mounted) return;

    setState(() => _disconnecting = true);
    final api = ApiService();
    final res = await api.disconnectDevice(device.id);
    if (!mounted) return;
    setState(() => _disconnecting = false);

    if (res['success'] == true) {
      context.read<DeviceProvider>().updateDeviceStatus(device.id, 'offline');
      widget.onBack?.call();
    } else {
      _showError(res['error']?['message'] ?? 'Failed to disconnect device');
    }
  }

  Future<void> _confirmAndRevoke(Device device) async {
    final confirm = await NeoDialog.show(
      context: context,
      title: 'REVOKE ACCESS?',
      message:
          'This device will no longer be connected to this Control account.',
      confirmLabel: 'REVOKE',
    );
    if (confirm != true || !mounted) return;

    // Capture the messenger while this widget is still active; after removal the
    // context may be deactivated and looking up an ancestor would crash.
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _revoking = true);
    final api = ApiService();
    final res = await api.revokeDevice(device.id);
    if (!mounted) return;
    setState(() => _revoking = false);

    if (res['success'] == true) {
      _dp.removeDevice(device.id);
      messenger.showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Device access revoked'),
          backgroundColor: NeoColors.pink,
        ),
      );
      widget.onBack?.call();
    } else {
      _showError(res['error']?['message'] ?? 'Failed to revoke device');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isDeveloper = context.read<AuthProvider>().isDeveloper;
    final device = context.watch<DeviceProvider>().selectedDevice;
    if (device == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Device Detail')),
        body: const Center(child: Text('No device selected')),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            NeoSpacing.lg,
            0,
            NeoSpacing.lg,
            ScrollClearance.bottomNav(context),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: NeoSpacing.md),
              _BackButton(onTap: widget.onBack),
              const SizedBox(height: NeoSpacing.md),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    device.name.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: NeoSpacing.xs),
                  Row(
                    children: [
                      NeoStatusIndicator(
                        active: device.isOnline,
                        activeLabel: 'ONLINE',
                        inactiveLabel: 'OFFLINE',
                      ),
                      const SizedBox(width: NeoSpacing.sm),
                      NeoBadge(label: 'Android ${device.androidVersion}'),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.xs),
              Text(
                'Device ID: ${device.id}',
                style: TextStyle(
                  fontSize: 12,
                  color: isDark ? NeoColors.secondaryText : NeoColors.grey,
                ),
              ),
              const SizedBox(height: NeoSpacing.xl),
              _sectionTitle('SYSTEM'),
              const SizedBox(height: NeoSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      'CPU',
                      '${device.cpu.toInt()}%',
                      NeoColors.blue,
                    ),
                  ),
                  const SizedBox(width: NeoSpacing.sm),
                  Expanded(
                    child: _statCard(
                      'RAM',
                      '${device.ram.toInt()}%',
                      NeoColors.purple,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      'STORAGE',
                      '${device.storage.toInt()}%',
                      NeoColors.orange,
                    ),
                  ),
                  const SizedBox(width: NeoSpacing.sm),
                  Expanded(
                    child: _statCard(
                      'BATTERY',
                      '${device.battery.toInt()}%',
                      NeoColors.green,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.sm),
              _infoCard('WiFi', device.isOnline ? 'CONNECTED' : 'DISCONNECTED'),
              const SizedBox(height: NeoSpacing.xs),
              _infoCard('Connection', device.isOnline ? 'Stable' : 'Offline'),
              const SizedBox(height: NeoSpacing.xs),
              _infoCard('Last heartbeat', device.lastHeartbeat ?? 'Never'),
              const SizedBox(height: NeoSpacing.xl),
              _sectionTitle('REMOTE CONTROL'),
              const SizedBox(height: NeoSpacing.md),
              if (_actionError != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: NeoSpacing.sm),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(NeoSpacing.sm),
                    decoration: BoxDecoration(
                      color: NeoColors.pink,
                      border: Border.all(color: NeoColors.pink),
                      borderRadius: BorderRadius.circular(NeoRadius.md),
                    ),
                    child: Text(
                      _actionError!,
                      style: const TextStyle(
                        color: NeoColors.black,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              NeoCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.touch_app_outlined, size: 20),
                        const SizedBox(width: NeoSpacing.sm),
                        const Expanded(
                          child: Text(
                            'TOUCH LOCK',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        NeoStatusIndicator(
                          active: _touchLockActive,
                          activeLabel: 'LOCKED',
                          inactiveLabel: 'UNLOCKED',
                        ),
                      ],
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    Text(
                      'Layar tetap menyala menampilkan gambar; seluruh sentuhan, tap & scroll terkunci. Volume ikut mute.',
                      style: const TextStyle(
                        fontSize: 11,
                        color: NeoColors.grey,
                      ),
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    if (isDeveloper) ...[
                      SizedBox(
                        width: double.infinity,
                        child: NeoButton(
                          label: _touchLockActive ? 'UNLOCK' : 'LOCK',
                          height: 40,
                          fontSize: 13,
                          bgColor: _touchLockActive
                              ? NeoColors.orange
                              : NeoColors.black,
                          textColor: NeoColors.white,
                          onPressed: () => _toggleTouchLock(!_touchLockActive),
                        ),
                      ),
                      const SizedBox(height: NeoSpacing.sm),
                      Text(
                        'Gambar touch screen mengikuti gambar yang diatur di Manage > Set Image.',
                        style: const TextStyle(
                          fontSize: 11,
                          color: NeoColors.grey,
                        ),
                      ),
                    ] else ...[
                      SizedBox(
                        width: double.infinity,
                        child: NeoButton(
                          label: _touchLockActive ? 'UNLOCK' : 'LOCK',
                          height: 40,
                          fontSize: 13,
                          bgColor: _touchLockActive
                              ? NeoColors.orange
                              : NeoColors.black,
                          textColor: NeoColors.white,
                          onPressed: () => _toggleTouchLock(!_touchLockActive),
                        ),
                      ),
                      const SizedBox(height: NeoSpacing.sm),
                      Text(
                        'Gambar touch screen mengikuti gambar yang diatur Developer.',
                        style: const TextStyle(
                          fontSize: 11,
                          color: NeoColors.grey,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: NeoSpacing.sm),
              _featureRow(
                'LIVE SCREEN',
                _screenSharing,
                () {
                  _toggleScreenShare(!_screenSharing);
                },
                permitted: _featurePermitted['screen'],
              ),
              if (_screenSharing)
                Padding(
                  padding: const EdgeInsets.only(top: NeoSpacing.sm),
                  child: NeoCard(
                    child: _LivePreviewWidget(deviceId: device.id),
                  ),
                ),
              const SizedBox(height: NeoSpacing.sm),
              _featureButton(
                'SCREENSHOT',
                Icons.camera_alt_outlined,
                () => _sendAction('screenshot', 'capture'),
              ),
              const SizedBox(height: NeoSpacing.sm),
              _featureToggle('FLASHLIGHT', _flashOn, () {
                setState(() => _flashOn = !_flashOn);
                _sendAction('flashlight', _flashOn ? 'on' : 'off');
              }, permitted: _featurePermitted['flashlight']),
              const SizedBox(height: NeoSpacing.sm),
              _featureButton(
                'VIBRATE',
                Icons.vibration_outlined,
                () => _sendAction('vibrate', 'vibrate'),
              ),
              const SizedBox(height: NeoSpacing.sm),
              _featureRow(
                'CAMERA',
                _cameraActive,
                () => _toggleCamera(!_cameraActive),
                permitted: _featurePermitted['camera_start'],
              ),
              if (_cameraActive)
                Padding(
                  padding: const EdgeInsets.only(top: NeoSpacing.sm),
                  child: NeoCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _CameraPreviewWidget(deviceId: device.id),
                        const SizedBox(height: NeoSpacing.sm),
                        SizedBox(
                          width: double.infinity,
                          child: NeoButton(
                            label: 'SWITCH CAMERA',
                            bgColor: NeoColors.blue,
                            onPressed: () =>
                                _sendAction('camera_switch', 'switch'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: NeoSpacing.sm),
              _featureToggle(
                'MICROPHONE',
                _micActive,
                () {
                  setState(() => _micActive = !_micActive);
                  _sendAction(
                    _micActive ? 'microphone_start' : 'microphone_stop',
                    _micActive ? 'start' : 'stop',
                  );
                },
                permitted: _featurePermitted['microphone_start'],
              ),
              if (_micActive)
                Padding(
                  padding: const EdgeInsets.only(top: NeoSpacing.sm),
                  child: NeoCard(child: _MicPreviewWidget(deviceId: device.id)),
                ),
              const SizedBox(height: NeoSpacing.sm),
              _sectionTitle('INFORMATION'),
              const SizedBox(height: NeoSpacing.md),
              _infoRow('Device Name', device.name),
              _infoRow('Model', device.model),
              _infoRow('Android', device.androidVersion),
              _infoRow('NovaCore', device.novaVersion),
              _infoRow('Battery', '${device.battery.toInt()}%'),
              _infoRow('Network', device.network.toUpperCase()),
              const SizedBox(height: NeoSpacing.xl),
              _dangerButton(
                'DISCONNECT',
                NeoColors.orange,
                _disconnecting ? null : () => _confirmAndDisconnect(device),
                loading: _disconnecting,
              ),
              const SizedBox(height: NeoSpacing.sm),
              _dangerButton(
                'REVOKE ACCESS',
                NeoColors.pink,
                _revoking ? null : () => _confirmAndRevoke(device),
                loading: _revoking,
              ),
              const SizedBox(height: NeoSpacing.xxl),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: NeoColors.secondaryText,
        letterSpacing: 1,
      ),
    );
  }

  Widget _statCard(String label, String value, Color accent) {
    return NeoCard(
      padding: const EdgeInsets.all(NeoSpacing.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: NeoColors.grey,
            ),
          ),
          const SizedBox(height: NeoSpacing.xs),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: accent,
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoCard(String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return NeoCard(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: NeoSpacing.md,
        vertical: NeoSpacing.sm + 2,
      ),
      child: Row(
        children: [
          Text(
            '$label  ',
            style: TextStyle(
              fontSize: 12,
              color: isDark ? NeoColors.secondaryText : NeoColors.grey,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureRow(
    String label,
    bool active,
    VoidCallback? onTap, {
    bool? permitted,
  }) {
    final bool canTap = onTap != null;
    return NeoCard(
      child: Row(
        children: [
          if (permitted == true)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.check_circle, size: 14, color: NeoColors.green),
            )
          else if (permitted == false)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.lock, size: 14, color: NeoColors.grey),
            ),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          NeoStatusIndicator(
            active: active,
            activeLabel: 'ACTIVE',
            inactiveLabel: 'INACTIVE',
          ),
          if (canTap) ...[
            const SizedBox(width: NeoSpacing.sm),
            GestureDetector(
              onTap: onTap,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: NeoSpacing.md,
                  vertical: NeoSpacing.xs + 2,
                ),
                decoration: BoxDecoration(
                  color: active ? NeoColors.pink : NeoColors.black,
                  border: Border.all(
                    color: NeoColors.border,
                    width: NeoTheme.borderWidth,
                  ),
                  borderRadius: BorderRadius.circular(NeoRadius.md),
                ),
                child: Text(
                  active ? 'STOP' : 'START',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: NeoColors.white,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _featureButton(
    String label,
    IconData icon,
    VoidCallback? onTap, {
    bool? permitted,
  }) {
    final bool canTap = onTap != null;
    return NeoCard(
      child: Row(
        children: [
          if (permitted == true)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.check_circle, size: 14, color: NeoColors.green),
            )
          else if (permitted == false)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.lock, size: 14, color: NeoColors.grey),
            ),
          Icon(icon, size: 20),
          const SizedBox(width: NeoSpacing.sm),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          GestureDetector(
            onTap: canTap ? onTap : null,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: NeoSpacing.md,
                vertical: NeoSpacing.xs + 2,
              ),
              decoration: BoxDecoration(
                color: canTap ? NeoColors.black : NeoColors.grey,
                border: Border.all(
                  color: NeoColors.border,
                  width: NeoTheme.borderWidth,
                ),
                borderRadius: BorderRadius.circular(NeoRadius.md),
              ),
              child: Text(
                'SEND',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: canTap ? NeoColors.white : NeoColors.grey,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureToggle(
    String label,
    bool active,
    VoidCallback? onTap, {
    bool? permitted,
  }) {
    final bool canTap = onTap != null;
    return NeoCard(
      child: Row(
        children: [
          if (permitted == true)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.check_circle, size: 14, color: NeoColors.green),
            )
          else if (permitted == false)
            const Padding(
              padding: EdgeInsets.only(right: NeoSpacing.xs),
              child: Icon(Icons.lock, size: 14, color: NeoColors.grey),
            ),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          GestureDetector(
            onTap: canTap ? onTap : null,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: NeoSpacing.md,
                vertical: NeoSpacing.xs + 2,
              ),
              decoration: BoxDecoration(
                color: canTap
                    ? (active ? NeoColors.green : NeoColors.grey)
                    : NeoColors.grey,
                border: Border.all(
                  color: NeoColors.border,
                  width: NeoTheme.borderWidth,
                ),
                borderRadius: BorderRadius.circular(NeoRadius.md),
              ),
              child: Text(
                active ? 'ON' : 'OFF',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: NeoSpacing.xs),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                color: isDark ? NeoColors.secondaryText : NeoColors.grey,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dangerButton(
    String label,
    Color color,
    VoidCallback? onTap, {
    bool loading = false,
  }) {
    return SizedBox(
      width: double.infinity,
      child: NeoButton(
        label: label,
        bgColor: color,
        textColor: NeoColors.white,
        onPressed: onTap,
        loading: loading,
      ),
    );
  }
}

class _BackButton extends StatelessWidget {
  final VoidCallback? onTap;
  const _BackButton({this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(NeoSpacing.sm),
        decoration: BoxDecoration(
          border: Border.all(
            color: NeoColors.border,
            width: NeoTheme.borderWidth,
          ),
          borderRadius: BorderRadius.circular(NeoRadius.md),
        ),
        child: const Icon(Icons.arrow_back, size: 20),
      ),
    );
  }
}

class _LivePreviewWidget extends StatefulWidget {
  final String deviceId;
  const _LivePreviewWidget({required this.deviceId});

  @override
  State<_LivePreviewWidget> createState() => _LivePreviewWidgetState();
}

class _LivePreviewWidgetState extends State<_LivePreviewWidget> {
  Uint8List? _frame;
  StreamSubscription<Map<String, dynamic>>? _sub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startListening());
  }

  void _startListening() {
    final socket = context.read<DeviceProvider>().socket;
    _sub = socket.screenFrameStream
        .where((data) => data['deviceId'] == widget.deviceId)
        .listen((data) {
          final raw = data['data'];
          Uint8List? bytes;
          if (raw is String) {
            try {
              bytes = base64Decode(raw);
            } catch (_) {}
          } else if (raw is List<int>) {
            bytes = Uint8List.fromList(raw);
          }
          if (bytes != null && mounted) {
            setState(() => _frame = bytes);
          }
        });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'LIVE PREVIEW',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
            ),
            const Spacer(),
            if (_frame != null)
              Text(
                '${_frame!.length} bytes',
                style: const TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
            if (_frame == null)
              const Text(
                'waiting for frames...',
                style: TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
          ],
        ),
        const SizedBox(height: NeoSpacing.sm),
        if (_frame != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(NeoRadius.md),
            child: RepaintBoundary(
              child: Image.memory(
                _frame!,
                fit: BoxFit.contain,
                width: double.infinity,
                gaplessPlayback: true,
              ),
            ),
          )
        else
          Container(
            width: double.infinity,
            height: 200,
            decoration: BoxDecoration(
              color: NeoColors.surface,
              borderRadius: BorderRadius.circular(NeoRadius.md),
              border: Border.all(color: NeoColors.border),
            ),
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.screen_share, size: 48, color: NeoColors.grey),
                  SizedBox(height: 8),
                  Text(
                    'Video will appear here',
                    style: TextStyle(color: NeoColors.grey, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _CameraPreviewWidget extends StatefulWidget {
  final String deviceId;
  const _CameraPreviewWidget({required this.deviceId});

  @override
  State<_CameraPreviewWidget> createState() => _CameraPreviewWidgetState();
}

class _CameraPreviewWidgetState extends State<_CameraPreviewWidget> {
  Uint8List? _frame;
  StreamSubscription<Map<String, dynamic>>? _sub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startListening());
  }

  void _startListening() {
    final socket = context.read<DeviceProvider>().socket;
    _sub = socket.cameraFrameStream
        .where((data) => data['deviceId'] == widget.deviceId)
        .listen((data) {
          final raw = data['data'];
          Uint8List? bytes;
          if (raw is String) {
            try {
              bytes = base64Decode(raw);
            } catch (_) {}
          } else if (raw is List<int>) {
            bytes = Uint8List.fromList(raw);
          }
          if (bytes != null && mounted) {
            setState(() => _frame = bytes);
          }
        });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'CAMERA PREVIEW',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
            ),
            const Spacer(),
            if (_frame != null)
              Text(
                '${_frame!.length} bytes',
                style: const TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
            if (_frame == null)
              const Text(
                'waiting for frames...',
                style: TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
          ],
        ),
        const SizedBox(height: NeoSpacing.sm),
        if (_frame != null)
          ClipRRect(
            borderRadius: BorderRadius.circular(NeoRadius.md),
            child: RepaintBoundary(
              child: Image.memory(
                _frame!,
                fit: BoxFit.contain,
                width: double.infinity,
                gaplessPlayback: true,
              ),
            ),
          )
        else
          Container(
            width: double.infinity,
            height: 200,
            decoration: BoxDecoration(
              color: NeoColors.surface,
              borderRadius: BorderRadius.circular(NeoRadius.md),
              border: Border.all(color: NeoColors.border),
            ),
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.videocam_off_outlined,
                    size: 48,
                    color: NeoColors.grey,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Camera feed will appear here',
                    style: TextStyle(color: NeoColors.grey, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _MicPreviewWidget extends StatefulWidget {
  final String deviceId;
  const _MicPreviewWidget({required this.deviceId});

  @override
  State<_MicPreviewWidget> createState() => _MicPreviewWidgetState();
}

class _MicPreviewWidgetState extends State<_MicPreviewWidget> {
  double _level = 0.0;
  bool _audioOn = false;
  StreamSubscription<Map<String, dynamic>>? _sub;
  StreamSubscription<Map<String, dynamic>>? _audioSub;
  MicLivePlayer? _player;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startListening());
  }

  void _startListening() {
    final socket = context.read<DeviceProvider>().socket;
    _sub = socket.micLevelStream
        .where((data) => data['deviceId'] == widget.deviceId)
        .listen((data) {
          final level = (data['level'] as num?)?.toDouble() ?? 0.0;
          if (mounted) {
            setState(() => _level = level.clamp(0.0, 1.0));
          }
        });
    _player = MicLivePlayer();
    _player?.start();
    _audioSub = socket.micAudioStream
        .where((data) => data['deviceId'] == widget.deviceId)
        .listen((data) {
          final raw = data['data'];
          if (raw is! String || raw.isEmpty) return;
          try {
            final pcm = base64Decode(raw);
            if (mounted && _audioOn == false) {
              setState(() => _audioOn = true);
            }
            final rate = (data['sampleRate'] as num?)?.toInt() ?? 0;
            _player?.addChunk(pcm, sampleRate: rate);
          } catch (_) {}
        });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _audioSub?.cancel();
    _player?.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final segments = 12;
    final filled = (_level * segments).round();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'LIVE AUDIO',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
            ),
            const SizedBox(width: NeoSpacing.xs),
            Text(
              _audioOn ? '● PLAYING' : '○ MUTED',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: _audioOn ? NeoColors.green : NeoColors.grey,
              ),
            ),
            const Spacer(),
            if (_level <= 0.0)
              const Text(
                'waiting for audio...',
                style: TextStyle(fontSize: 10, color: NeoColors.grey),
              )
            else
              Text(
                '${(_level * 100).round()}%',
                style: const TextStyle(fontSize: 10, color: NeoColors.grey),
              ),
          ],
        ),
        const SizedBox(height: NeoSpacing.sm),
        Row(
          children: List.generate(segments, (i) {
            return Expanded(
              child: Container(
                height: 18,
                margin: EdgeInsets.only(right: i == segments - 1 ? 0 : 4),
                decoration: BoxDecoration(
                  color: i < filled ? NeoColors.pink : NeoColors.grey,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}
