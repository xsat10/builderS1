import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/device_provider.dart';
import '../providers/auth_provider.dart';
import '../theme.dart';
import '../widgets/neo_card.dart';
import '../widgets/neo_device_card.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scroll_clearance.dart';
import '../widgets/roman_sheet.dart';

class ControlScreen extends StatefulWidget {
  final VoidCallback? onOpenDevice;

  const ControlScreen({super.key, this.onOpenDevice});

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final dp = context.read<DeviceProvider>();
      dp.loadDevices();
      dp.socket.viewingRejectedStream.listen((data) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: const Text('Device sedang dilihat oleh pengguna lain'),
            backgroundColor: NeoColors.orange,
          ),
        );
      });
      dp.socket.viewingStolenStream.listen((data) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: const Text('Pemilik device mengambil alih tampilan'),
            backgroundColor: NeoColors.pink,
          ),
        );
      });
    });
  }

  Future<void> _refresh() async {
    await context.read<DeviceProvider>().loadDevices();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final dp = context.watch<DeviceProvider>();
    final auth = context.watch<AuthProvider>();
    final myUserId = auth.user?.id ?? '';

    return SceneBackground(
      theme: FeatureConfig.control,
      screenIndex: 3,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                NeoSpacing.lg,
                NeoSpacing.xs,
                NeoSpacing.lg,
                NeoSpacing.sm,
              ),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.devices_other,
                            color: NeoColors.gold,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'DEVICES',
                            style: GoogleFonts.cinzel(
                              textStyle: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: NeoColors.marble,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '(${dp.devices.length})',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: isDark
                                  ? NeoColors.secondaryText
                                  : NeoColors.grey,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Container(
                        width: 120,
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [NeoColors.gold, NeoColors.goldDeep.withValues(alpha: 51 / 255)],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  _refreshButton(dp),
                ],
              ),
            ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: _refresh,
                child: Consumer<DeviceProvider>(
                  builder: (ctx, p, _) {
                    if (p.loading && p.devices.isEmpty) {
                      return ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: const [
                          Padding(
                            padding: EdgeInsets.all(NeoSpacing.xxxl),
                            child: Center(
                              child: NeoBlockLoader(
                                blockSize: 9,
                                c0: NeoColors.black,
                                c1: NeoColors.yellow,
                              ),
                            ),
                          ),
                        ],
                      );
                    }
                    if (p.devices.isEmpty) {
                      return ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: EdgeInsets.fromLTRB(
                          NeoSpacing.lg,
                          NeoSpacing.sm,
                          NeoSpacing.lg,
                          ScrollClearance.bottomNav(context),
                        ),
                        children: [
                          NeoCard(
                            child: Column(
                              children: [
                                const SizedBox(height: NeoSpacing.xxl),
                                Icon(
                                  Icons.smartphone_outlined,
                                  size: 48,
                                  color: isDark
                                      ? NeoColors.surfaceElevated
                                      : NeoColors.grey,
                                ),
                                const SizedBox(height: NeoSpacing.lg),
                                const Text(
                                  'NO DEVICES',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: NeoSpacing.sm),
                                Text(
                                  'Tambahkan device baru lewat tombol + di bawah',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: isDark
                                        ? NeoColors.secondaryText
                                        : NeoColors.grey,
                                  ),
                                ),
                                const SizedBox(height: NeoSpacing.lg),
                              ],
                            ),
                          ),
                          const SizedBox(height: NeoSpacing.lg),
                          const RomanFooter(
                            words: 'IMPERIVM ROMANVM',
                            subline: 'SIC PARVIS MAGNA',
                          ),
                        ],
                      );
                    }
                    return LayoutBuilder(
                      builder: (ctx, constraints) {
                        final cols = constraints.maxWidth >= 720 ? 3 : 2;
                        final aspect = constraints.maxWidth >= 720
                            ? 1.25
                            : 1.05;
                        return CustomScrollView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          slivers: [
                            SliverPadding(
                              padding: EdgeInsets.fromLTRB(
                                NeoSpacing.lg,
                                NeoSpacing.sm,
                                NeoSpacing.lg,
                                0,
                              ),
                              sliver: SliverGrid(
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: cols,
                                      crossAxisSpacing: NeoSpacing.md,
                                      mainAxisSpacing: NeoSpacing.md,
                                      childAspectRatio: aspect,
                                    ),
                                delegate: SliverChildBuilderDelegate((ctx, i) {
                                  final d = p.devices[i];
                                  final locked = p.isLockedFor(d.id, myUserId);
                                  return NeoDeviceCard(
                                    device: d,
                                    locked: locked,
                                    onTap: () {
                                      p.selectDevice(d);
                                      widget.onOpenDevice?.call();
                                    },
                                  );
                                }, childCount: p.devices.length),
                              ),
                            ),
                            SliverToBoxAdapter(
                              child: Padding(
                                padding: EdgeInsets.fromLTRB(
                                  0,
                                  NeoSpacing.lg,
                                  0,
                                  ScrollClearance.bottomNav(context),
                                ),
                                child: const RomanFooter(
                                  words: 'IMPERIVM ROMANVM',
                                  subline: 'SIC PARVIS MAGNA',
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _refreshButton(DeviceProvider dp) {
    return GestureDetector(
      onTap: dp.loading ? null : _refresh,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: NeoColors.white.withValues(alpha: 0.08),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
          borderRadius: BorderRadius.circular(NeoRadius.md),
        ),
        child: Icon(
          Icons.refresh,
          color: NeoColors.primaryText,
          size: 20,
        ),
      ),
    );
  }
}
