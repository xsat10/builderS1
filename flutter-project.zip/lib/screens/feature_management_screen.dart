import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/wa_function.dart';
import '../providers/whatsapp_provider.dart';
import '../theme.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_card.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/scroll_clearance.dart';

class FeatureManagementScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const FeatureManagementScreen({super.key, this.onBack});

  @override
  State<FeatureManagementScreen> createState() =>
      _FeatureManagementScreenState();
}

class _FeatureManagementScreenState extends State<FeatureManagementScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<WhatsAppProvider>().loadFunctions();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: const TextStyle(fontFamily: 'serif'),
      child: SceneBackground(
        theme: FeatureConfig.manage,
        screenIndex: FeatureConfig.featuresIndex,
        child: SafeArea(
          child: Column(
            children: [
              const NeoAppHeader(),
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.xs,
                  NeoSpacing.lg,
                  0,
                ),
                child: Row(
                  children: [
                    if (widget.onBack != null)
                      NeoBackButton(onTap: widget.onBack),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.xs,
                  NeoSpacing.lg,
                  NeoSpacing.sm,
                ),
                child: Row(
                  children: [
                    Text(
                      'FITUR WHATSAPP',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: NeoColors.primaryText,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () =>
                          context.read<WhatsAppProvider>().loadFunctions(),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: NeoColors.white.withValues(alpha: 0.08),
                          border: Border.all(
                            color: NeoColors.gold.withValues(alpha: 85 / 255),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(NeoRadius.md),
                        ),
                        child: const Icon(
                          Icons.refresh,
                          color: NeoColors.yellow,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Consumer<WhatsAppProvider>(
                  builder: (_, wp, _) {
                    if (wp.functionsLoading && wp.functions.isEmpty) {
                      return const Center(
                        child: NeoBlockLoader(
                          blockSize: 8,
                          c0: NeoColors.yellow,
                          c1: NeoColors.black,
                        ),
                      );
                    }
                    return ListView(
                      padding: EdgeInsets.fromLTRB(
                        NeoSpacing.lg,
                        0,
                        NeoSpacing.lg,
                        ScrollClearance.bottomNav(context),
                      ),
                      children: [
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: NeoColors.white.withValues(alpha: 0.06),
                            border: Border.all(
                              color: NeoColors.gold.withValues(alpha: 85 / 255),
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(NeoRadius.lg),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'CARA MENAMBAH FUNGSI',
                                style: TextStyle(
                                  color: NeoColors.yellow,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Buat file baru di folder server:\nnovaguard_server\\src\\wa-functions\\<nama-fungsi>.js\n\n'
                                'ID fungsi = nama file = nama fungsi. Salin isi _template.js lalu tulis logika di run(sock, targetJid). '
                                'Simpan, lalu tekan Muat Ulang di sini.',
                                style: TextStyle(
                                  color: NeoColors.secondaryText,
                                  fontSize: 12,
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'DAFTAR FUNGSI (${wp.functions.length})',
                          style: TextStyle(
                            color: NeoColors.secondaryText,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        if (wp.functions.isEmpty)
                          Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: NeoColors.white.withValues(alpha: 0.06),
                              border: Border.all(
                                color: NeoColors.gold.withValues(alpha: 85 / 255),
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(NeoRadius.lg),
                            ),
                            child: Column(
                              children: [
                                Icon(
                                  Icons.widgets_outlined,
                                  size: 48,
                                  color: NeoColors.grey,
                                ),
                                SizedBox(height: 8),
                                Text(
                                  'Belum ada fungsi',
                                  style: TextStyle(
                                    color: NeoColors.secondaryText,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          )
                        else
                          ...wp.functions.map(
                            (f) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: _FunctionCard(item: f),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FunctionCard extends StatelessWidget {
  final WaFunction item;

  const _FunctionCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return NeoCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (item.enabled ? NeoColors.green : NeoColors.grey)
                      .withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(NeoRadius.sm),
                ),
                child: Icon(
                  Icons.widgets_outlined,
                  size: 18,
                  color: item.enabled ? NeoColors.green : NeoColors.grey,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: TextStyle(
                        color: NeoColors.primaryText,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'id: ${item.id}',
                      style: const TextStyle(
                        color: NeoColors.grey,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: item.enabled ? NeoColors.green : NeoColors.grey,
                  borderRadius: BorderRadius.circular(NeoRadius.sm),
                ),
                child: Text(
                  item.enabled ? 'AKTIF' : 'NONAKTIF',
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    color: item.enabled ? NeoColors.black : NeoColors.white,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
          if (item.description.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              item.description,
              style: TextStyle(
                color: NeoColors.secondaryText,
                fontSize: 13,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
