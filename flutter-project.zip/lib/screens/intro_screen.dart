import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import '../providers/connection_provider.dart';
import '../providers/device_provider.dart';
import '../services/remote_config_service.dart';
import '../theme.dart';
import '../widgets/neo_block_loader.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key});

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  VideoPlayerController? _controller;
  bool _initialized = false;
  bool _hasNavigated = false;
  Timer? _fallbackTimer;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final auth = context.read<AuthProvider>();
      if (!auth.authenticated) {
        await auth.tryAutoLogin();
      }
      if (!mounted) return;
      if (!auth.authenticated) {
        Navigator.pushReplacementNamed(context, '/welcome');
        return;
      }
      final conn = context.read<ConnectionProvider>();
      unawaited(() async {
        await conn.checkConnection();
        if (!mounted) return;
        conn.startMonitoring();
        conn.bindSocket(context.read<DeviceProvider>().socket.connectedStream);
        conn.bindSocketErrors(context.read<DeviceProvider>().socket.errorStream);
      }());
      _initVideo();
    });
  }

  void _initVideo() {
    // Fallback timer: auto navigate after max 7 seconds if video gets stuck or fails
    _fallbackTimer?.cancel();
    _fallbackTimer = Timer(const Duration(seconds: 7), () {
      if (mounted && !_hasNavigated) {
        _navigateHome();
      }
    });

    _controller = VideoPlayerController.asset('assets/video/screen.mp4')
      ..setLooping(false)
      ..addListener(_onVideoTick)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _initialized = true);
        _controller?.seekTo(Duration.zero);
        _controller?.play();
      }).catchError((e) {
        debugPrint('Intro video error: $e');
        if (mounted) {
          setState(() => _initialized = false);
          // If video fails, auto navigate after short pause
          Future.delayed(const Duration(milliseconds: 800), () {
            if (mounted) _navigateHome();
          });
        }
      });
  }

  @override
  void dispose() {
    _fallbackTimer?.cancel();
    _controller?.removeListener(_onVideoTick);
    _controller?.dispose();
    super.dispose();
  }

  void _onVideoTick() {
    final c = _controller;
    if (!mounted || c == null || !_initialized || _hasNavigated) return;
    final pos = c.value.position;
    final dur = c.value.duration;
    if (dur > Duration.zero && pos >= dur) {
      _navigateHome();
    }
  }

  void _navigateHome() {
    if (!mounted || _hasNavigated) return;
    _hasNavigated = true;
    _fallbackTimer?.cancel();
    try {
      _controller?.pause();
    } catch (_) {}
    Navigator.of(context, rootNavigator: true).pushReplacementNamed('/home');
  }

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final backgroundAsset = skin.isBubbleGum
        ? 'assets/bubble/login_screen.png'
        : 'assets/bg/login_screen.png';
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: palette.background,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // Background artwork
            Image.asset(
              backgroundAsset,
              fit: BoxFit.cover,
            ),
            // Dark gradient overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.50),
                    Colors.black.withValues(alpha: 0.20),
                    Colors.black.withValues(alpha: 0.60),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    // === Logo — focal point ===
                    _buildLogo(),
                    const SizedBox(height: 18),
                    // === NOVA branding ===
                    Text(
                      (RemoteConfigService.instance.branding['appName']?.toString() ?? 'NOVACORE').toUpperCase(),
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        color: NeoColors.primaryText,
                        fontFamily: 'monospace',
                        shadows: [
                          Shadow(color: NeoColors.gold.withValues(alpha: 85 / 255), blurRadius: 18),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'AUDENTES FORTUNA IUVAT',
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 3,
                        color: palette.primary,
                        fontFamily: 'monospace',
                      ),
                    ),
                    const SizedBox(height: 28),
                    // === Glass video card ===
                    Expanded(
                      child: Center(
                        child: _buildGlassVideoCard(),
                      ),
                    ),
                    const SizedBox(height: 22),
                    // === SKIP button — ALWAYS ACTIVE & RESPONSIVE ===
                    _buildSkipButton(),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Container(
      width: 76,
      height: 76,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: NeoColors.gold.withValues(alpha: 102 / 255), width: 1.5),
        boxShadow: [
          BoxShadow(color: NeoColors.gold.withValues(alpha: 102 / 255), blurRadius: 28, spreadRadius: 2),
        ],
      ),
      child: ClipOval(
        child: Image.asset(
          'assets/logo.png',
          width: 76,
          height: 76,
          fit: BoxFit.cover,
          errorBuilder: (_, _, _) => Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [NeoColors.gold, NeoColors.goldDeep],
              ),
            ),
            child: Icon(Icons.account_balance_rounded, size: 32, color: NeoColors.ink),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassVideoCard() {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    if (!_initialized) {
      return AspectRatio(
        aspectRatio: 16 / 9,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.white.withValues(alpha: 0.12),
                    Colors.white.withValues(alpha: 0.04),
                  ],
                ),
                border: Border.all(
                  color: skin.isBubbleGum
                      ? palette.primary.withValues(alpha: 0.55)
                      : NeoColors.gold.withValues(alpha: 51 / 255),
                  width: 0.8,
                ),
                borderRadius: BorderRadius.circular(24),
              ),
                child: Center(
                  child: NeoBlockLoader(
                    blockSize: 7,
                    c0: palette.background,
                    c1: skin.isBubbleGum ? palette.primary : NeoColors.yellow,
                  ),
              ),
            ),
          ),
        ),
      );
    }
    final c = _controller!;
    return AspectRatio(
      aspectRatio: c.value.aspectRatio,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: skin.isBubbleGum
                    ? palette.primary.withValues(alpha: 0.55)
                    : NeoColors.gold.withValues(alpha: 51 / 255),
                width: 0.8,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: skin.isBubbleGum
                      ? palette.primary.withValues(alpha: 0.30)
                      : NeoColors.gold.withValues(alpha: 51 / 255),
                  blurRadius: 24,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(23),
              child: VideoPlayer(c),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSkipButton() {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return GestureDetector(
      // SKIP IS ALWAYS ACTIVE AND INSTANT:
      onTap: _navigateHome,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 200,
        height: 52,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: skin.isBubbleGum
              ? [palette.primary, palette.accent]
              : [NeoColors.gold, NeoColors.goldDeep],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0x88FFFFFF),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: skin.isBubbleGum
                  ? palette.primary.withValues(alpha: 0.40)
                  : NeoColors.gold.withValues(alpha: 102 / 255),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: Text(
            'SKIP  ›',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink,
            ),
          ),
        ),
      ),
    );
  }
}
