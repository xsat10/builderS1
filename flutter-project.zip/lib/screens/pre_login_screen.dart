import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/remote_config_service.dart';
import '../theme.dart';
import '../utils/app_config.dart';
import '../widgets/neo_button.dart';
import '../widgets/nova_core_card_stack.dart';

/// Pre-login card deck shown after the mandatory fingerprint scan.
class PreLoginScreen extends StatefulWidget {
  const PreLoginScreen({super.key});

  @override
  State<PreLoginScreen> createState() => _PreLoginScreenState();
}

class _PreLoginScreenState extends State<PreLoginScreen> {

  String _brandTagline() {
    final tagline = RemoteConfigService.instance.tagline.trim();
    return tagline.isEmpty ? 'Audentes Fortuna Iuvat' : tagline;
  }

  String _deckTagline() {
    final t = RemoteConfigService.instance.tagline.trim();
    return t.isEmpty ? 'Bug Hunter of the Digital Shadows' : t;
  }

  Future<void> _launch(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: NeoColors.darkBg,
        body: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/bg/screen.png', fit: BoxFit.cover),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.45),
                    Colors.black.withValues(alpha: 0.20),
                    Colors.black.withValues(alpha: 0.70),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 20,
                ),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 16),
                    _buildDeck(),
                    const SizedBox(height: 24),
                    _buildContinueRow(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeck() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: NovaCoreCardStack(
        maxCardWidth: 320,
        cardAspectRatio: 0.86,
        cycleDuration: const Duration(milliseconds: 560),
        snapDuration: const Duration(milliseconds: 420),
        cards: [
          NovaCoreStackCard(
            title: 'NovaCore',
            subtitle: 'BUG x RAT',
            badge: 'NOVACORE',
            description: _brandTagline(),
            image: 'assets/logo.png',
            accent: NeoColors.gold,
          ),
          NovaCoreStackCard(
            title: 'Developer',
            subtitle: 'Alex Yusomo',
            badge: 'DEVELOPER',
            description: _deckTagline(),
            icon: Icons.code,
            accent: NeoColors.developer,
            footer: _deckSocialRow(),
          ),
        ],
      ),
    );
  }

  Widget _deckSocialRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _deckSocialButton(
          icon: Icons.chat_outlined,
          url: AppConfig.developerWhatsAppUrl,
        ),
        const SizedBox(width: 14),
        _deckSocialButton(
          icon: Icons.send_outlined,
          url: AppConfig.developerTelegramUrl,
        ),
        const SizedBox(width: 14),
        _deckSocialButton(
          icon: Icons.code,
          url: AppConfig.developerGithubUrl,
        ),
      ],
    );
  }

  Widget _deckSocialButton({required IconData icon, required String url}) {
    return GestureDetector(
      onTap: () => _launch(url),
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: NeoColors.developer.withValues(alpha: 0.12),
          border: Border.all(
            color: NeoColors.developer.withValues(alpha: 0.45),
            width: 1,
          ),
        ),
        child: Icon(icon, size: 16, color: NeoColors.developer),
      ),
    );
  }

  Widget _buildContinueRow() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        NeoButton(
          label: 'CONTINUE',
          bgColor: NeoColors.gold,
          textColor: NeoColors.ink,
          height: 50,
          fontSize: 15,
          onPressed: () => Navigator.of(context).pushReplacementNamed('/login'),
        ),
      ],
    );
  }
}
