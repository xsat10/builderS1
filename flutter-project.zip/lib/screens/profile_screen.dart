import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/user.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../services/remote_config_service.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/scroll_clearance.dart';
import '../widgets/neo_role_badge.dart';

/// Profil ala WhatsApp — foto besar, nama, about, info akun, dan edit.
class ProfileScreen extends StatefulWidget {
  final VoidCallback? onBack;
  const ProfileScreen({super.key, this.onBack});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Uint8List? _avatar;
  bool _loadingPhoto = false;

  Future<void> _pickPhoto() async {
    if (_loadingPhoto) return;
    final auth = context.read<AuthProvider>();
    setState(() => _loadingPhoto = true);
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (mounted) setState(() => _avatar = bytes);
      final api = ApiService();
      final ext = picked.path.contains('.')
          ? picked.path.split('.').last.toLowerCase()
          : 'jpg';
      const allowedExt = {'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'};
      final safeExt = allowedExt.contains(ext) ? ext : 'jpg';
      final upload = await api.uploadImage(
        picked.path,
        filename: 'avatar_${DateTime.now().millisecondsSinceEpoch}.$safeExt',
      );
      final url = (upload['data']?['url'] as String?) ?? '';
      if (url.isEmpty) {
        _toast('Gagal mengunggah foto.');
        return;
      }
      final user = auth.user;
      if (user == null) return;
      final result = await auth.updateProfile({'avatar': url});
      _toast(
        result['success'] == true
            ? 'Foto profil diperbarui.'
            : (result['error']?['message']?.toString() ??
                  'Gagal menyimpan foto.'),
      );
    } catch (_) {
      _toast('Gagal memilih foto.');
    } finally {
      if (mounted) setState(() => _loadingPhoto = false);
    }
  }

  Future<void> _editProfile(User user) async {
    final nameCtrl = TextEditingController(text: user.displayName);
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.55),
      builder: (ctx) =>
          _EditProfileSheet(nameCtrl: nameCtrl, username: user.username),
    );
    if (saved == true && mounted) {
      final auth = context.read<AuthProvider>();
      final newName = nameCtrl.text.trim();
      if (newName.isEmpty) {
        _toast('Nama tidak boleh kosong.');
        return;
      }
      final result = await auth.updateProfile({'name': newName});
      _toast(
        result['success'] == true
            ? 'Profil berhasil diperbarui.'
            : (result['error']?['message']?.toString() ??
                  'Gagal memperbarui profil.'),
      );
    }
  }

  Future<void> _changePassword() async {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();
    final saved = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.55),
      builder: (ctx) => _ChangePasswordSheet(
        currentCtrl: currentCtrl,
        newCtrl: newCtrl,
        confirmCtrl: confirmCtrl,
      ),
    );
    if (saved != null && mounted) {
      final auth = context.read<AuthProvider>();
      final result = await auth.changePassword(
        saved['current']!,
        saved['new']!,
      );
      _toast(
        result['success'] == true
            ? 'Password berhasil diganti.'
            : (result['error']?['message']?.toString() ??
                  'Gagal mengganti password.'),
      );
    }
    currentCtrl.dispose();
    newCtrl.dispose();
    confirmCtrl.dispose();
  }

  Future<void> _deletePhoto() async {
    final auth = context.read<AuthProvider>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: NeoColors.surfaceElevated,
        title: const Text(
          'HAPUS FOTO?',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontSize: 16,
          ),
        ),
        content: const Text(
          'Foto profil akan dihapus dan diganti ikon default.',
          style: TextStyle(color: Colors.white70, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('BATAL', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text(
              'HAPUS',
              style: TextStyle(
                color: Color(0xFFFF5252),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _avatar = null);
    final result = await auth.updateProfile({'avatar': ''});
    _toast(
      result['success'] == true
          ? 'Foto profil dihapus.'
          : (result['error']?['message']?.toString() ??
                'Gagal menghapus foto.'),
    );
  }

  Future<void> _showPhotoMenu() async {
    final hasAvatar =
        _avatar != null ||
        (context.read<AuthProvider>().user?.avatar?.isNotEmpty ?? false);
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.5),
      builder: (ctx) => Container(
        margin: const EdgeInsets.all(12),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: const Color(0xF01A1A33),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 16),
            Text(
              'Foto Profil',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: NeoColors.primaryText,
              ),
            ),
            const SizedBox(height: 8),
            _photoMenuTile(
              Icons.photo_camera_outlined,
              'Ganti Foto',
              () => Navigator.pop(ctx, 'change'),
            ),
            if (hasAvatar)
              _photoMenuTile(
                Icons.delete_outline,
                'Hapus Foto',
                () => Navigator.pop(ctx, 'delete'),
                color: const Color(0xFFFF5252),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (!mounted || action == null) return;
    if (action == 'change') {
      await _pickPhoto();
    } else if (action == 'delete') {
      await _deletePhoto();
    }
  }

  Widget _photoMenuTile(
    IconData icon,
    String label,
    VoidCallback onTap, {
    Color? color,
  }) {
    return ListTile(
      leading: Icon(icon, color: color ?? NeoColors.primaryText, size: 22),
      title: Text(
        label,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
      onTap: onTap,
    );
  }

  void _toast(String msg, {Color? color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(msg),
        backgroundColor: color ?? NeoColors.goldDeep,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;
    final branding = RemoteConfigService.instance.branding;
    final tagline = branding['tagline']?.toString() ?? '';
    final roleLabel = auth.roleLabel;

    final roleColor = NeoColors.roleColor(user?.role ?? 'member');
    final roleIcon = NeoColors.roleIcon[user?.role] ?? Icons.person;

    return Scaffold(
      backgroundColor: NeoColors.background,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF0B0D1F),
                    Color(0xFF1A1433),
                    Color(0xFF0B0D1F),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  pinned: true,
                  backgroundColor: Colors.transparent,
                  leading: _IconCircle(
                    icon: Icons.arrow_back,
                    onTap:
                        widget.onBack ??
                        () {
                          if (Navigator.canPop(context)) {
                            Navigator.pop(context);
                          }
                        },
                  ),
                  title: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'PROFIL',
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: NeoColors.gold,
                        letterSpacing: 3,
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Column(
                      children: [
                        _buildAvatar(user, roleColor, roleIcon),
                        const SizedBox(height: 18),
                        Text(
                          user?.displayName ?? 'User',
                          style: TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            color: NeoColors.gold,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: roleColor.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: roleColor.withValues(alpha: 0.4),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(roleIcon, size: 14, color: roleColor),
                              const SizedBox(width: 6),
                              Text(
                                roleLabel,
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: roleColor,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tagline.isEmpty ? 'Audentes Fortuna Iuvat' : tagline,
                          style: TextStyle(
                            fontSize: 12,
                            color: NeoColors.gold,
                            fontStyle: FontStyle.italic,
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          user != null ? '@${user.username ?? 'user'}' : '',
                          style: TextStyle(
                            fontSize: 13,
                            color: NeoColors.gold,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 24),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  height: 1,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        NeoColors.gold.withValues(alpha: 102 / 255),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Text(
                                '✦  AKUN  ✦',
                                style: TextStyle(
                                  color: NeoColors.gold,
                                  fontSize: 11,
                                  letterSpacing: 2,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Container(
                                  height: 1,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        NeoColors.gold.withValues(alpha: 102 / 255),
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        _buildInfoCard(user),
                        const SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: NeoButton(
                            label: 'EDIT PROFIL',
                            bgColor: NeoColors.goldDeep,
                            textColor: NeoColors.white,
                            height: 50,
                            fontSize: 13,
                            icon: Icons.edit_rounded,
                            onPressed: user == null
                                ? null
                                : () => _editProfile(user),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: NeoButton(
                            label: 'GANTI PASSWORD',
                            bgColor: const Color(0xFF1E1E2E),
                            textColor: NeoColors.primaryText,
                            height: 50,
                            fontSize: 13,
                            icon: Icons.lock_reset_rounded,
                            onPressed: user == null ? null : _changePassword,
                          ),
                        ),
                        SizedBox(height: ScrollClearance.bottomNav(context)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar(User? user, Color roleColor, IconData roleIcon) {
    final free = user?.isFree ?? false;
    return GestureDetector(
      onTap: _showPhotoMenu,
      child: Stack(
        children: [
          Container(
            width: 128,
            height: 128,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [NeoColors.gold, NeoColors.goldDeep],
              ),
              boxShadow: [
                BoxShadow(
                  color: roleColor.withValues(alpha: 0.4),
                  blurRadius: 28,
                ),
              ],
            ),
            child: Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF14142A),
              ),
              clipBehavior: Clip.antiAlias,
              child: _avatar != null
                  ? Image.memory(_avatar!, fit: BoxFit.cover)
                  : (user?.avatar?.isNotEmpty ?? false)
                  ? Image.network(
                      user!.avatar!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => Icon(
                        roleIcon,
                        size: 60,
                        color: roleColor.withValues(alpha: 0.9),
                      ),
                    )
                  : Icon(
                      roleIcon,
                      size: 60,
                      color: roleColor.withValues(alpha: 0.9),
                    ),
            ),
          ),
          if (!free)
            Positioned(
              top: 2,
              right: 2,
              child: NeoRoleBadge(role: user?.role ?? 'member', size: 30),
            ),
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: NeoColors.white,
                border: Border.all(color: NeoColors.goldDeep, width: 2),
                boxShadow: const [
                  BoxShadow(color: Color(0x66000000), blurRadius: 8),
                ],
              ),
              child: _loadingPhoto
                  ? const Padding(
                      padding: EdgeInsets.all(8),
                      child: NeoBlockLoader(compact: true, size: 18),
                    )
                  : Icon(
                      Icons.camera_alt,
                      size: 18,
                      color: NeoColors.goldDeep,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(User? user) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(NeoRadius.xl),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1.2),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: isDark ? 0.06 : 0.12),
            borderRadius: BorderRadius.circular(NeoRadius.xl),
          ),
          child: Column(
            children: [
              _infoTile(
                Icons.alternate_email,
                'Username',
                user?.username ?? '-',
              ),
              _divider(),
              _infoTile(
                Icons.badge_outlined,
                'Role',
                (user?.isFree ?? false)
                    ? 'GRATIS (tanpa role)'
                    : (user?.roleLabel ?? '-'),
                valueColor: NeoColors.roleColor(user?.role ?? 'member'),
              ),
              _divider(),
              _infoTile(
                Icons.schedule,
                'Status',
                user == null ? '-' : user.status.toUpperCase(),
                valueColor: (user?.status ?? 'active') == 'active'
                    ? NeoColors.green
                    : NeoColors.pink,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoTile(
    IconData icon,
    String label,
    String value, {
    Color? valueColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: NeoColors.gold.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: NeoColors.gold),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: NeoColors.secondaryText,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: valueColor ?? NeoColors.primaryText,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() =>
      const Divider(height: 1, indent: 64, color: Color(0x22FFFFFF));
}

class _IconCircle extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _IconCircle({required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        margin: const EdgeInsets.only(left: 12, top: 8),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withValues(alpha: 0.08),
          border: Border.all(color: const Color(0x33FFFFFF), width: 1),
        ),
        child: Icon(icon, size: 20, color: NeoColors.primaryText),
      ),
    );
  }
}

class _EditProfileSheet extends StatefulWidget {
  final TextEditingController nameCtrl;
  final String? username;
  const _EditProfileSheet({required this.nameCtrl, this.username});

  @override
  State<_EditProfileSheet> createState() => _EditProfileSheetState();
}

class _EditProfileSheetState extends State<_EditProfileSheet> {
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SafeArea(
        top: false,
        child: Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
          ),
          child: Container(
            color: const Color(0xF01A1A33),
            padding: const EdgeInsets.all(24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 20),
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  Text(
                    'Edit Profil',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.primaryText,
                    ),
                  ),
                  const SizedBox(height: 18),
                  _fieldLabel('NAMA (TAMPILAN)'),
                  TextField(
                    controller: widget.nameCtrl,
                    style: TextStyle(color: NeoColors.primaryText),
                    decoration: _fieldDecoration('Nama Anda'),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Nama ini akan tampil di profil dan beranda.',
                    style: TextStyle(
                      fontSize: 10,
                      color: NeoColors.secondaryText,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _fieldLabel('USERNAME (TERKUNCI)'),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.04),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: const Color(0x22FFFFFF),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.lock_outline,
                          size: 16,
                          color: NeoColors.grey,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            widget.username == null || widget.username!.isEmpty
                                ? 'Tidak dapat diubah'
                                : '@${widget.username}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: NeoColors.secondaryText,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: NeoButton(
                          label: 'BATAL',
                          bgColor: isDark
                              ? const Color(0xFF1E1E2E)
                              : NeoColors.grey,
                          textColor: NeoColors.secondaryText,
                          height: 50,
                          fontSize: 13,
                          onPressed: () => Navigator.pop(context, false),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: NeoButton(
                          label: 'SIMPAN',
                          bgColor: NeoColors.goldDeep,
                          textColor: NeoColors.white,
                          height: 50,
                          fontSize: 13,
                          icon: Icons.check_rounded,
                          onPressed: () => Navigator.pop(context, true),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: NeoColors.secondaryText,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  InputDecoration _fieldDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: NeoColors.grey),
      filled: true,
      fillColor: Colors.white.withValues(alpha: 0.06),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0x33FFFFFF), width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: NeoColors.gold.withValues(alpha: 136 / 255), width: 1.4),
      ),
    );
  }
}

class _ChangePasswordSheet extends StatefulWidget {
  final TextEditingController currentCtrl;
  final TextEditingController newCtrl;
  final TextEditingController confirmCtrl;
  const _ChangePasswordSheet({
    required this.currentCtrl,
    required this.newCtrl,
    required this.confirmCtrl,
  });

  @override
  State<_ChangePasswordSheet> createState() => _ChangePasswordSheetState();
}

class _ChangePasswordSheetState extends State<_ChangePasswordSheet> {
  bool _obscureCurrent = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: SafeArea(
        top: false,
        child: Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
          ),
          child: Container(
            color: const Color(0xF01A1A33),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                Text(
                  'Ganti Password',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: NeoColors.primaryText,
                  ),
                ),
                const SizedBox(height: 18),
                _fieldLabel('PASSWORD LAMA'),
                _passwordField(widget.currentCtrl, _obscureCurrent, () {
                  setState(() => _obscureCurrent = !_obscureCurrent);
                }),
                const SizedBox(height: 12),
                _fieldLabel('PASSWORD BARU'),
                _passwordField(widget.newCtrl, _obscureNew, () {
                  setState(() => _obscureNew = !_obscureNew);
                }),
                const SizedBox(height: 6),
                Text(
                  'Minimal 6 karakter, kombinasi huruf & angka.',
                  style: TextStyle(
                    fontSize: 10,
                    color: NeoColors.secondaryText,
                  ),
                ),
                const SizedBox(height: 12),
                _fieldLabel('KONFIRMASI PASSWORD BARU'),
                _passwordField(widget.confirmCtrl, _obscureConfirm, () {
                  setState(() => _obscureConfirm = !_obscureConfirm);
                }),
                if (_error != null) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 16,
                        color: Color(0xFFFF6B6B),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          _error!,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFFFF6B6B),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: NeoButton(
                        label: 'BATAL',
                        bgColor: isDark
                            ? const Color(0xFF1E1E2E)
                            : NeoColors.grey,
                        textColor: NeoColors.secondaryText,
                        height: 50,
                        fontSize: 13,
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeoButton(
                        label: 'SIMPAN',
                        bgColor: NeoColors.goldDeep,
                        textColor: NeoColors.white,
                        height: 50,
                        fontSize: 13,
                        icon: Icons.check_rounded,
                        onPressed: _submit,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submit() {
    final current = widget.currentCtrl.text.trim();
    final newPass = widget.newCtrl.text.trim();
    final confirm = widget.confirmCtrl.text.trim();
    setState(() => _error = null);

    if (current.isEmpty) {
      setState(() => _error = 'Password lama tidak boleh kosong.');
      return;
    }
    if (newPass.length < 6) {
      setState(() => _error = 'Password baru minimal 6 karakter.');
      return;
    }
    if (newPass != confirm) {
      setState(() => _error = 'Konfirmasi password baru tidak sama.');
      return;
    }
    Navigator.pop(context, {'current': current, 'new': newPass});
  }

  Widget _fieldLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          color: NeoColors.secondaryText,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _passwordField(
    TextEditingController ctrl,
    bool obscure,
    VoidCallback toggle,
  ) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      style: TextStyle(color: NeoColors.primaryText),
      decoration: InputDecoration(
        hintText: '••••••••',
        hintStyle: const TextStyle(color: NeoColors.grey),
        filled: true,
        fillColor: Colors.white.withValues(alpha: 0.06),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        suffixIcon: IconButton(
          icon: Icon(
            obscure ? Icons.visibility_off : Icons.visibility,
            size: 18,
            color: NeoColors.grey,
          ),
          onPressed: toggle,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0x33FFFFFF), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: NeoColors.gold.withValues(alpha: 136 / 255), width: 1.4),
        ),
      ),
    );
  }
}
