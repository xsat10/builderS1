import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/app_refresh_provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_glass_overlay.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scene_background.dart';
import '../widgets/scroll_clearance.dart';

class PairingScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const PairingScreen({super.key, this.onBack});

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> {
  List<Map<String, dynamic>> _codes = [];
  Map<String, Map<String, dynamic>> _users = {};
  bool _loading = true;
  late AppRefreshProvider _refresh;
  int _lastRevision = -1;
  bool _isDeveloper = false;
  String _search = '';
  String _statusFilter = 'all';

  static const _filters = ['all', 'active', 'used', 'revoked'];

  @override
  void initState() {
    super.initState();
    _isDeveloper = context.read<AuthProvider>().isDeveloper;
    _refresh = context.read<AppRefreshProvider>();
    _lastRevision = _refresh.revision;
    _refresh.addListener(_onRefreshChanged);
    _load();
  }

  @override
  void dispose() {
    _refresh.removeListener(_onRefreshChanged);
    super.dispose();
  }

  void _onRefreshChanged() {
    if (!mounted) return;
    final rev = _refresh.revision;
    if (rev != _lastRevision) {
      _lastRevision = rev;
      _load();
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final api = ApiService();
    final codesRes = _isDeveloper
        ? await api.getPairingCodes()
        : await api.getMyPairingCodes();
    Map<String, Map<String, dynamic>> usersMap = {};
    if (_isDeveloper) {
      final usersRes = await api.getUsers();
      if (usersRes['success'] == true) {
        usersMap = {
          for (final u in (usersRes['data'] as List? ?? []))
            '${u['id']}': Map<String, dynamic>.from(u as Map),
        };
      }
    }
    if (!mounted) return;
    setState(() {
      _codes = List<Map<String, dynamic>>.from(codesRes['data'] as List? ?? []);
      _users = usersMap;
      _loading = false;
    });
  }

  // ── filter & search
  List<Map<String, dynamic>> get _filtered {
    final status = _statusFilter == 'all' ? null : _statusFilter;
    final q = _search.trim().toLowerCase();
    return _codes.where((c) {
      final codeMatch = status == null || (c['status'] ?? '') == status;
      if (!codeMatch) return false;
      if (q.isEmpty) return true;
      final code = (c['code'] ?? '').toString().toLowerCase();
      final assigned = (c['assigned_user_id'] ?? '').toString();
      final user = _users[assigned];
      final uname = ((user?['username'] ?? '') as String).toLowerCase();
      return code.contains(q) || uname.contains(q);
    }).toList();
  }

  int get _totalCount => _codes.length;
  int get _activeCount =>
      _codes.where((c) => (c['status'] ?? '') == 'active').length;
  int get _usedCount =>
      _codes.where((c) => (c['status'] ?? '') == 'used').length;

  String _userLabel(String? id) {
    if (id == null || id.isEmpty) return 'TANPA USER';
    final u = _users[id];
    if (u == null) return '—';
    final name = (u['username'] ?? u['email'] ?? '').toString();
    return name.isEmpty ? id : name;
  }

  String _userRole(String? id) {
    if (id == null || id.isEmpty) return '';
    final u = _users[id];
    if (u == null) return '';
    return ((u['role'] ?? '') as String).toUpperCase();
  }

  String _formatDate(String? raw) {
    if (raw == null || raw.isEmpty) return '';
    final dt = DateTime.tryParse(raw);
    if (dt == null) return '';
    final local = dt.toLocal();
    final mon = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Agu',
      'Sep',
      'Okt',
      'Nov',
      'Des',
    ][local.month - 1];
    return '$mon ${local.day}, ${local.year}';
  }

  Future<void> _showCreatePairingDialog() async {
    final usersRes = await ApiService().getUsers();
    if (!mounted) return;
    final users =
        List<Map<String, dynamic>>.from(usersRes['data'] as List? ?? []).where((
          u,
        ) {
          final role = (u['role'] ?? '').toString();
          return role == 'partner' || role == 'reseller' || role == 'member';
        }).toList();

    String? selectedId;
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: NeoGlassOverlay(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: NeoColors.gold.withValues(alpha: 34 / 255),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Icon(
                        Icons.qr_code_2_rounded,
                        size: 20,
                        color: NeoColors.gold,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'BUAT KODE PAIRING',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 17,
                          color: NeoColors.primaryText,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Kode ini bisa dipakai berkali-kali oleh banyak device baru.',
                  style: TextStyle(
                    fontSize: 12,
                    color: NeoColors.secondaryText,
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: 360,
                  child: SingleChildScrollView(
                    child: StatefulBuilder(
                      builder: (ctx, setLocal) => Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'TARGET USER',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: NeoColors.secondaryText,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 6),
                          DropdownButtonFormField<String>(
                            initialValue: selectedId,
                            dropdownColor: NeoColors.surfaceElevated,
                            style: TextStyle(
                              color: NeoColors.primaryText,
                              fontSize: 13,
                            ),
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('TANPA USER'),
                              ),
                              ...users.map(
                                (u) => DropdownMenuItem(
                                  value: (u['id'] ?? '').toString(),
                                  child: Text(
                                    '${(u['username'] ?? u['email'] ?? '').toString().toUpperCase()} • ${(u['role'] ?? '').toString().toUpperCase()}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ],
                            onChanged: (v) => setLocal(
                              () => selectedId = (v == '' ? null : v),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text(
                          'BATAL',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeoButton(
                        label: 'BUAT',
                        height: 40,
                        fontSize: 13,
                        onPressed: () => Navigator.pop(ctx, true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
    if (saved != true || !mounted) return;

    final res = await ApiService().createPairingCode(userId: selectedId);
    if (!mounted) return;
    final ok = res['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? 'Kode pairing berhasil dibuat'
              : (res['error']?['message'] ?? 'Gagal membuat kode pairing'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
    if (ok) _load();
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'active':
        return 'AKTIF';
      case 'used':
        return 'DIPAKAI';
      case 'revoked':
        return 'DICABUT';
      default:
        return status.toUpperCase();
    }
  }

  void _copy(String code) {
    Clipboard.setData(ClipboardData(text: code));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Kode disalin ke clipboard'),
          backgroundColor: NeoColors.green,
        ),
      );
    }
  }

  Future<void> _revoke(String code) async {
    final confirmed = await NeoDialog.show(
      context: context,
      title: 'Cabut kode?',
      message: 'Kode "$code" tidak bisa lagi dipakai device baru.',
      cancelLabel: 'BATAL',
      confirmLabel: 'CABUT',
      confirmColor: NeoColors.orange,
    );
    if (confirmed != true || !mounted) return;
    await ApiService().revokePairingCode(code);
    if (mounted) _load();
  }

  Future<void> _delete(String code) async {
    final confirmed = await NeoDialog.show(
      context: context,
      title: 'Hapus kode?',
      message:
          'Kode ini akan dihapus permanen. Device yang sudah terhubung tetap aman.',
      cancelLabel: 'BATAL',
      confirmLabel: 'HAPUS',
      confirmColor: NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    await ApiService().deletePairingCode(code);
    if (mounted) _load();
  }

  void _openActions(Map<String, dynamic> c) {
    final code = (c['code'] ?? '').toString();
    final status = (c['status'] ?? '').toString();
    final isActive = status == 'active';
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => NeoGlassOverlay(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                code,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  color: NeoColors.gold,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'KODE PAIRING • ${_statusLabel(status)}',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  color: NeoColors.secondaryText,
                ),
              ),
              const SizedBox(height: 14),
              Divider(height: 1, color: Colors.white.withValues(alpha: 0.06)),
              _ActionItem(
                icon: Icons.copy_rounded,
                label: 'Salin Kode',
                color: NeoColors.gold,
                onTap: () {
                  Navigator.pop(ctx);
                  _copy(code);
                },
              ),
              if (isActive) ...[
                _ActionItem(
                  icon: Icons.link_off_rounded,
                  label: 'Cabut Kode',
                  color: NeoColors.orange,
                  onTap: () {
                    Navigator.pop(ctx);
                    _revoke(code);
                  },
                ),
              ],
              if (_isDeveloper)
                _ActionItem(
                  icon: Icons.delete_outline,
                  label: 'Hapus Kode',
                  color: NeoColors.pink,
                  onTap: () {
                    Navigator.pop(ctx);
                    _delete(code);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;

    return SceneBackground(
      theme: FeatureConfig.pairing,
      screenIndex: FeatureConfig.pairingIndex,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const NeoAppHeader(),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: Row(
                children: [
                  if (widget.onBack != null)
                    NeoBackButton(onTap: widget.onBack),
                  const Spacer(),
                  if (_isDeveloper)
                    NeoButton(
                      label: 'ADD',
                      icon: Icons.add,
                      height: 40,
                      fontSize: 13,
                      bgColor: NeoColors.green,
                      onPressed: _showCreatePairingDialog,
                    ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: _HeroCard(
                total: _totalCount,
                active: _activeCount,
                used: _usedCount,
                isDeveloper: _isDeveloper,
              ),
            ),

            const SizedBox(height: 10),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: _SearchField(
                onChanged: (v) => setState(() => _search = v),
              ),
            ),

            const SizedBox(height: 8),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: _StatusChips(
                filters: _filters,
                current: _statusFilter,
                onSelect: (f) => setState(() => _statusFilter = f),
              ),
            ),

            const SizedBox(height: 8),

            Expanded(
              child: _loading
                  ? const Center(
                      child: NeoBlockLoader(
                        blockSize: 8,
                        c0: NeoColors.black,
                        c1: NeoColors.yellow,
                      ),
                    )
                  : ListView(
                      padding: EdgeInsets.fromLTRB(
                        NeoSpacing.lg,
                        0,
                        NeoSpacing.lg,
                        ScrollClearance.bottomNav(context),
                      ),
                      children: [
                        if (filtered.isEmpty)
                          _EmptyState(
                            isDeveloper: _isDeveloper,
                            hasQuery: _search.isNotEmpty,
                          )
                        else
                          ...filtered.map(
                            (c) => _CodeCard(
                              code: c,
                              userLabel: _userLabel(
                                (c['assigned_user_id'] ?? '').toString().isEmpty
                                    ? null
                                    : (c['assigned_user_id'] ?? '').toString(),
                              ),
                              userRole: _userRole(
                                (c['assigned_user_id'] ?? '').toString().isEmpty
                                    ? null
                                    : (c['assigned_user_id'] ?? '').toString(),
                              ),
                              createdDate: _formatDate(
                                (c['created_at'] ?? '').toString(),
                              ),
                              isDeveloper: _isDeveloper,
                              onTap: () => _openActions(c),
                              onCopy: () => _copy((c['code'] ?? '').toString()),
                              onRevoke: () =>
                                  _revoke((c['code'] ?? '').toString()),
                              onDelete: () =>
                                  _delete((c['code'] ?? '').toString()),
                            ),
                          ),

                        const SizedBox(height: 20),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Widget terkecil yang bisa ditampilkan
// ─────────────────────────────────────────────────────────────
class _HeroCard extends StatelessWidget {
  final int total;
  final int active;
  final int used;
  final bool isDeveloper;

  const _HeroCard({
    required this.total,
    required this.active,
    required this.used,
    required this.isDeveloper,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [NeoColors.gold.withValues(alpha: 51 / 255), Color(0x141628AA)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
        boxShadow: [
          BoxShadow(color: NeoColors.gold.withValues(alpha: 34 / 255), blurRadius: 20, spreadRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: NeoColors.gold.withValues(alpha: 34 / 255),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.qr_code_2_rounded,
                  color: NeoColors.gold,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'PAIRING CENTER',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: NeoColors.primaryText,
                        letterSpacing: 1,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Kode untuk menghubungkan device target',
                      style: TextStyle(
                        fontSize: 11,
                        color: NeoColors.secondaryText,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _Stat(total, 'TOTAL', NeoColors.gold),
              _Stat(active, 'AKTIF', NeoColors.green),
              _Stat(used, 'DIPAKAI', NeoColors.orange),
            ],
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final int value;
  final String label;
  final Color color;

  const _Stat(this.value, this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(
            '$value',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
              color: NeoColors.secondaryText,
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  final ValueChanged<String> onChanged;

  const _SearchField({required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        border: Border.all(color: const Color(0x1AFFFFFF), width: 1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.search_rounded, size: 18, color: NeoColors.grey),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              onChanged: onChanged,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: NeoColors.primaryText,
              ),
              decoration: const InputDecoration(
                hintText: 'Cari kode atau user...',
                hintStyle: TextStyle(fontSize: 13, color: NeoColors.grey),
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusChips extends StatelessWidget {
  final List<String> filters;
  final String current;
  final ValueChanged<String> onSelect;

  const _StatusChips({
    required this.filters,
    required this.current,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final f = filters[i];
          final active = current == f;
          return GestureDetector(
            onTap: () => onSelect(f),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: active
                    ? NeoColors.gold.withValues(alpha: 0.18)
                    : Colors.white.withValues(alpha: 0.04),
                border: Border.all(
                  color: active
                      ? NeoColors.gold.withValues(alpha: 0.50)
                      : const Color(0x14FFFFFF),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Align(
                alignment: Alignment.center,
                child: Text(
                  f == 'all' ? 'SEMUA' : f.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                    color: active ? NeoColors.gold : NeoColors.secondaryText,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _CodeCard extends StatelessWidget {
  final Map<String, dynamic> code;
  final String userLabel;
  final String userRole;
  final String createdDate;
  final bool isDeveloper;
  final VoidCallback onTap;
  final VoidCallback onCopy;
  final VoidCallback onRevoke;
  final VoidCallback onDelete;

  const _CodeCard({
    required this.code,
    required this.userLabel,
    required this.userRole,
    required this.createdDate,
    required this.isDeveloper,
    required this.onTap,
    required this.onCopy,
    required this.onRevoke,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final status = (code['status'] ?? 'active').toString();
    final isActive = status == 'active';
    final statusColor = _statusColor(status);
    final icon = _statusIcon(status);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            border: Border.all(color: const Color(0x12FFFFFF), width: 1),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      (code['code'] ?? '').toString(),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.5,
                        color: NeoColors.gold,
                        fontFamily: 'monospace',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(icon, size: 11, color: statusColor),
                        const SizedBox(width: 4),
                        Text(
                          (_statusLabel(status)),
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                            color: statusColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Divider(height: 1, color: Colors.white.withValues(alpha: 0.06)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          userLabel,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: NeoColors.primaryText,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          userRole.isEmpty
                              ? createdDate
                              : '$userRole • $createdDate',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _QuickAction(
                    icon: Icons.copy_rounded,
                    color: NeoColors.gold,
                    tooltip: 'Salin',
                    onTap: onCopy,
                  ),
                  if (isActive)
                    _QuickAction(
                      icon: Icons.link_off_rounded,
                      color: NeoColors.orange,
                      tooltip: 'Cabut',
                      onTap: onRevoke,
                    ),
                  if (isDeveloper)
                    _QuickAction(
                      icon: Icons.delete_outline,
                      color: NeoColors.pink,
                      tooltip: 'Hapus',
                      onTap: onDelete,
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'active':
        return NeoColors.green;
      case 'used':
        return NeoColors.orange;
      case 'revoked':
        return NeoColors.pink;
      default:
        return NeoColors.grey;
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'active':
        return 'AKTIF';
      case 'used':
        return 'DIPAKAI';
      case 'revoked':
        return 'DICABUT';
      default:
        return status.toUpperCase();
    }
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'active':
        return Icons.bolt_rounded;
      case 'used':
        return Icons.check_circle_rounded;
      case 'revoked':
        return Icons.block_rounded;
      default:
        return Icons.help_outline;
    }
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.color,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          width: 34,
          height: 34,
          margin: const EdgeInsets.only(left: 4),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(9),
          ),
          child: Icon(icon, size: 17, color: color),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final bool isDeveloper;
  final bool hasQuery;

  const _EmptyState({required this.isDeveloper, required this.hasQuery});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 44),
      child: Column(
        children: [
          Icon(
            Icons.qr_code_2_outlined,
            size: 44,
            color: NeoColors.secondaryText.withValues(alpha: 0.35),
          ),
          const SizedBox(height: 12),
          Text(
            hasQuery
                ? 'Tidak ditemukan'
                : (isDeveloper
                      ? 'Belum ada kode pairing'
                      : 'Belum ada kode untuk akun Anda'),
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: NeoColors.secondaryText,
            ),
          ),
          if (!hasQuery) const SizedBox(height: 4),
          if (!hasQuery)
            Text(
              isDeveloper
                  ? 'Tekan ADD untuk membuat kode baru.'
                  : 'Hubungi Developer untuk mendapatkan kode.',
              style: const TextStyle(fontSize: 11, color: NeoColors.grey),
            ),
        ],
      ),
    );
  }
}

class _ActionItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionItem({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.primaryText,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
