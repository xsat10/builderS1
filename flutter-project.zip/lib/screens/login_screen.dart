import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import '../services/remote_config_service.dart';
import '../theme.dart';
import '../utils/app_config.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_glass_overlay.dart';
import '../widgets/neo_social_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _usernameCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;

  late final AnimationController _ctrl;
  late final Animation<double> _logoFade;
  late final Animation<double> _logoScl;
  late final Animation<double> _titleSlide;
  late final Animation<double> _cardSlide;
  late final Animation<double> _cardFade;
  late final Animation<double> _socialFade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _logoFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0, 0.35, curve: Curves.easeOut),
      ),
    );
    _logoScl = Tween<double>(begin: 0.6, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0, 0.35, curve: Curves.easeOutBack),
      ),
    );
    _titleSlide = Tween<double>(begin: 24, end: 0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.2, 0.5, curve: Curves.easeOut),
      ),
    );
    _cardSlide = Tween<double>(begin: 32, end: 0).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.35, 0.75, curve: Curves.easeOut),
      ),
    );
    _cardFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.35, 0.75, curve: Curves.easeOut),
      ),
    );
    _socialFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.6, 1, curve: Curves.easeOut),
      ),
    );
    _ctrl.forward();
    _refreshConfig();
  }

  Future<void> _refreshConfig() async {
    await RemoteConfigService.instance.refresh();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _usernameCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final auth = context.read<AuthProvider>();
    final success = await auth.login(_usernameCtrl.text.trim(), _passCtrl.text);
    if (success && mounted) {
      Navigator.of(context).pushReplacementNamed('/video');
    }
  }

  Future<void> _showFreeAccessDialog() async {
    if (!RemoteConfigService.instance.freeAccessEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text(
            'Akses gratis sedang dinonaktifkan. Hubungi developer.',
          ),
          backgroundColor: NeoColors.pink,
        ),
      );
      return;
    }
    final created = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) => const _FreeAccessDialog(),
    );
    if (created == true && mounted) {
      Navigator.of(context).pushReplacementNamed('/video');
    }
  }

  Future<void> _launch(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text('Could not open: $url'),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final backgroundAsset = skin.isBubbleGum
        ? 'assets/bubble/login_screen.png'
        : 'assets/bg/screen.png';
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: palette.background,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // Background Artwork
            Image.asset(backgroundAsset, fit: BoxFit.cover),

            // Dark Atmospheric Gradient Overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.65),
                    Colors.black.withValues(alpha: 0.35),
                    Colors.black.withValues(alpha: 0.75),
                  ],
                ),
              ),
            ),

            SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 20,
                      ),
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(height: 20),

                          // Logo — Glass focal point
                          FadeTransition(
                            opacity: _logoFade,
                            child: ScaleTransition(
                              scale: _logoScl,
                              child: Container(
                                width: 88,
                                height: 88,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: NeoColors.gold.withValues(alpha: 102 / 255),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: NeoColors.gold.withValues(alpha: 85 / 255),
                                      blurRadius: 28,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: Image.asset(
                                    'assets/logo.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 16),

                          // Branding Title
                          AnimatedBuilder(
                            animation: _titleSlide,
                            builder: (ctx, _) => Transform.translate(
                              offset: Offset(0, _titleSlide.value),
                              child: Column(
                                children: [
                                  Text(
                                    'NOVACORE',
                                    style: TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 3,
                                      color: NeoColors.primaryText,
                                      fontFamily: 'monospace',
                                      shadows: [
                                        Shadow(
                                          color: NeoColors.gold.withValues(alpha: 85 / 255),
                                          blurRadius: 16,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'BUG x RAT',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      color: NeoColors.gold,
                                      letterSpacing: 3,
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 20),

                          // Liquid Glass Login Card
                          AnimatedBuilder(
                            animation: _cardSlide,
                            builder: (ctx, _) => Transform.translate(
                              offset: Offset(0, _cardSlide.value),
                              child: FadeTransition(
                                opacity: _cardFade,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(24),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(
                                      sigmaX: 20,
                                      sigmaY: 20,
                                    ),
                                    child: Container(
                                      padding: const EdgeInsets.all(24),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: [
                                            Colors.white.withValues(
                                              alpha: 0.10,
                                            ),
                                            Colors.white.withValues(
                                              alpha: 0.03,
                                            ),
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(24),
                                        border: Border.all(
                                          color: NeoColors.gold.withValues(alpha: 68 / 255),
                                          width: 1,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black.withValues(
                                              alpha: 0.40,
                                            ),
                                            blurRadius: 32,
                                            offset: const Offset(0, 16),
                                            spreadRadius: -8,
                                          ),
                                        ],
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Welcome Back',
                                            style: TextStyle(
                                              fontSize: 22,
                                              fontWeight: FontWeight.w800,
                                              color: NeoColors.primaryText,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            'Sign in to manage your NovaCore devices',
                                            style: TextStyle(
                                              fontSize: 12.5,
                                              color: NeoColors.secondaryText,
                                            ),
                                          ),
                                          const SizedBox(height: 24),

                                          // Username Input
                                          _GlassField(
                                            controller: _usernameCtrl,
                                            hint: 'Username',
                                            prefixIcon: Icons.person_outline,
                                          ),

                                          const SizedBox(height: 16),

                                          // Password Input
                                          _GlassField(
                                            controller: _passCtrl,
                                            hint: 'Password',
                                            obscure: _obscure,
                                            prefixIcon: Icons.lock_outline,
                                            suffixIcon: IconButton(
                                              icon: Icon(
                                                _obscure
                                                    ? Icons.visibility_outlined
                                                    : Icons
                                                          .visibility_off_outlined,
                                                color: NeoColors.secondaryText,
                                                size: 20,
                                              ),
                                              onPressed: () => setState(
                                                () => _obscure = !_obscure,
                                              ),
                                            ),
                                          ),

                                          const SizedBox(height: 20),

                                          // Error message if any
                                          Consumer<AuthProvider>(
                                            builder: (ctx, auth, _) {
                                              if (auth.error != null) {
                                                return Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                        bottom: 16,
                                                      ),
                                                  child: Text(
                                                    auth.error!,
                                                    style: const TextStyle(
                                                      color: NeoColors.pink,
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                    ),
                                                  ),
                                                );
                                              }
                                              return const SizedBox.shrink();
                                            },
                                          ),

                                          // Login Button — tanpa animasi
                                          // loading di dalam tombol (label
                                          // tetap terbaca); tombol hanya
                                          // dinonaktifkan sambil memproses.
                                          Consumer<AuthProvider>(
                                            builder: (ctx, auth, _) =>
                                                NeoButton(
                                                  label: 'LOGIN',
                                                  bgColor: palette.primary,
                                                  textColor: palette.onBackground1,
                                                  loading: false,
                                                  height: 50,
                                                  fontSize: 15,
                                                  onPressed: auth.loading
                                                      ? null
                                                      : _login,
                                                ),
                                          ),

                                          const SizedBox(height: 16),

                                          // Forgot Password Link
                                          Center(
                                            child: GestureDetector(
                                              onTap: () => _launch(
                                                AppConfig.developerTelegramUrl,
                                              ),
                                              child: Text(
                                                'Lupa password? Hubungi Developer',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w600,
                                                  color: NeoColors.gold,
                                                  decoration:
                                                      TextDecoration.underline,
                                                ),
                                              ),
                                            ),
                                          ),

                                          const SizedBox(height: 16),

                                          // Free Access Button — membuka dialog
                                          // saat aktif dan bot Telegram saat
                                          // akses gratis dimatikan.
                                          Builder(
                                            builder: (ctx) {
                                              final freeEnabled =
                                                  RemoteConfigService
                                                      .instance
                                                      .freeAccessEnabled;
                                              return Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.stretch,
                                                children: [
                                                  NeoButton(
                                                    label: 'AKSES GRATIS',
                                                    bgColor: const Color(
                                                      0x22FFFFFF,
                                                    ),
                                                    textColor:
                                                        NeoColors.primaryText,
                                                    height: 46,
                                                    fontSize: 13,
                                                    icon: Icons.bolt_outlined,
                                                    onPressed: freeEnabled
                                                        ? _showFreeAccessDialog
                                                      : () => _launch(
                                                        AppConfig
                                                          .createNovaBotUrl,
                                                        ),
                                                  ),
                                                  const SizedBox(height: 8),
                                                  Center(
                                                    child: freeEnabled
                                                        ? Text(
                                                            'Coba NovaCore gratis selama yang di tentukan developer tanpa bayar.',
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                              fontSize: 10.5,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: NeoColors
                                                                  .secondaryText,
                                                            ),
                                                          )
                                                        : const SizedBox
                                                            .shrink(),
                                                  ),
                                                ],
                                              );
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 36),

                          // Social Links
                          FadeTransition(
                            opacity: _socialFade,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                NeoSocialButton(
                                  icon: Icons.chat_outlined,
                                  label: 'WhatsApp',
                                  onTap: () =>
                                      _launch(AppConfig.developerWhatsAppUrl),
                                ),
                                const SizedBox(width: 16),
                                NeoSocialButton(
                                  icon: Icons.send_outlined,
                                  label: 'Telegram',
                                  onTap: () =>
                                      _launch(AppConfig.developerTelegramUrl),
                                ),
                                const SizedBox(width: 16),
                                NeoSocialButton(
                                  icon: Icons.code_outlined,
                                  label: 'GitHub',
                                  onTap: () =>
                                      _launch(AppConfig.developerGithubUrl),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),

                  // Footer
                  Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Text(
                      '— Alex Yusomo —',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                        color: NeoColors.gold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlassField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final bool obscure;
  final IconData? prefixIcon;
  final Widget? suffixIcon;

  const _GlassField({
    required this.controller,
    required this.hint,
    this.obscure = false,
    this.prefixIcon,
    this.suffixIcon,
  });

  @override
  State<_GlassField> createState() => _GlassFieldState();
}

class _FreeAccessDialog extends StatefulWidget {
  const _FreeAccessDialog();

  @override
  State<_FreeAccessDialog> createState() => _FreeAccessDialogState();
}

class _FreeAccessDialogState extends State<_FreeAccessDialog> {
  final _usernameCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final auth = context.read<AuthProvider>();
    setState(() {
      _loading = true;
      _error = null;
    });
    final result = await auth.requestFreeAccess(
      _usernameCtrl.text.trim(),
      _passCtrl.text,
    );
    if (!mounted) return;
    setState(() => _loading = false);
    if (result['success'] == true) {
      Navigator.of(context).pop(true);
    } else {
      final code = result['error']?['code'];
      setState(() {
        _error = code == 'DEVICE_ACCOUNT_LIMIT'
            ? (result['error']?['message']?.toString() ??
                  'Perangkat ini sudah digunakan untuk membuat akun gratis. 1 HP = 1 akun.')
            : code == 'LIMIT_REACHED'
            ? (result['error']?['message']?.toString() ??
                  'Anda sudah memakai akses gratis hari ini.')
            : (result['error']?['message']?.toString() ??
                  'Akses gratis gagal. Coba lagi.');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: NeoGlassOverlay(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'AKSES GRATIS',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 18,
                color: NeoColors.primaryText,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Buat akun untuk mencoba NovaGuard gratis. Akun akan kadaluarsa sesuai dengan waktu yang di tentukan developer.',
              style: TextStyle(fontSize: 12, color: NeoColors.secondaryText),
            ),
            const SizedBox(height: 20),
            _GlassField(
              controller: _usernameCtrl,
              hint: 'Username',
              prefixIcon: Icons.person_outline,
            ),
            const SizedBox(height: 14),
            _GlassField(
              controller: _passCtrl,
              hint: 'Password',
              obscure: true,
              prefixIcon: Icons.lock_outline,
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(
                _error!,
                style: const TextStyle(
                  color: NeoColors.pink,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: _loading
                        ? null
                        : () => Navigator.of(context).pop(false),
                    child: Text(
                      'BATAL',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: NeoColors.secondaryText,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: NeoButton(
                    label: 'BUAT AKUN',
                    height: 44,
                    fontSize: 13,
                    loading: _loading,
                    onPressed: _loading ? null : _submit,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _GlassFieldState extends State<_GlassField> {
  final _focus = FocusNode();

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _focus,
      builder: (ctx, _) {
        final focused = _focus.hasFocus;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            color: focused
                ? Colors.white.withValues(alpha: 0.08)
                : Colors.white.withValues(alpha: 0.04),
            border: Border.all(
              color: focused
                  ? NeoColors.gold
                  : Colors.white.withValues(alpha: 0.12),
              width: focused ? 1.2 : 1.0,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: focused
                ? [
                    BoxShadow(
                      color: NeoColors.gold.withValues(alpha: 0.25),
                      blurRadius: 16,
                      spreadRadius: 0,
                    ),
                  ]
                : null,
          ),
          child: TextField(
            controller: widget.controller,
            focusNode: _focus,
            obscureText: widget.obscure,
            style: TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w600,
              color: NeoColors.primaryText,
            ),
            decoration: InputDecoration(
              hintText: widget.hint,
              hintStyle: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: NeoColors.secondaryText,
              ),
              prefixIcon: widget.prefixIcon == null
                  ? null
                  : Icon(
                      widget.prefixIcon,
                      size: 20,
                      color: focused ? NeoColors.gold : NeoColors.secondaryText,
                    ),
              suffixIcon: widget.suffixIcon,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 16,
              ),
            ),
          ),
        );
      },
    );
  }
}
