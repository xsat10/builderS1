import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scene_background.dart';
import '../widgets/scroll_clearance.dart';

class TouchImageScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const TouchImageScreen({super.key, this.onBack});

  @override
  State<TouchImageScreen> createState() => _TouchImageScreenState();
}

class _TouchImageScreenState extends State<TouchImageScreen> {
  String? _savedImage;
  String? _pendingImage;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final res = await ApiService().getTouchImage();
    if (!mounted) return;
    setState(() {
      _savedImage = res['data']?['image'] as String?;
      _loading = false;
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 720,
      maxHeight: 1280,
      imageQuality: 55,
    );
    if (file == null || !mounted) return;
    final bytes = await file.readAsBytes();
    if (!mounted) return;
    setState(() {
      _pendingImage = base64Encode(bytes);
      _savedImage = null;
    });
  }

  Future<void> _save() async {
    final image = _pendingImage ?? '';
    try {
      final res = await ApiService().setTouchImage(image);
      if (!mounted) return;
      if (res['success'] == true) {
        setState(() {
          _savedImage = image.isEmpty ? null : image;
          _pendingImage = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              image.isEmpty
                  ? 'Gambar touch screen dihapus'
                  : 'Gambar touch screen disimpan',
            ),
            backgroundColor: NeoColors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(res['error']?['message'] ?? 'Gagal menyimpan gambar'),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal menyimpan gambar: $e'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  Future<void> _clear() async {
    try {
      final res = await ApiService().setTouchImage('');
      if (!mounted) return;
      if (res['success'] == true) {
        setState(() {
          _savedImage = null;
          _pendingImage = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: const Text('Gambar touch screen dihapus'),
            backgroundColor: NeoColors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(res['error']?['message'] ?? 'Gagal menghapus gambar'),
            backgroundColor: NeoColors.pink,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal menghapus gambar: $e'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  String? get _previewImage {
    if (_pendingImage != null) return _pendingImage;
    if (_savedImage != null && _savedImage!.isNotEmpty) return _savedImage;
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final preview = _previewImage;
    final hasImage = _savedImage != null || _pendingImage != null;

    return DefaultTextStyle(
      style: const TextStyle(fontFamily: 'serif'),
      child: SceneBackground(
        theme: FeatureConfig.manage,
        screenIndex: FeatureConfig.imageIndex,
        child: SafeArea(
          child: Column(
            children: [
              const NeoAppHeader(),
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.xs,
                  NeoSpacing.lg,
                  0,
                ),
                child: Row(
                  children: [
                    if (widget.onBack != null)
                      NeoBackButton(onTap: widget.onBack),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(
                    NeoSpacing.lg,
                    NeoSpacing.sm,
                    NeoSpacing.lg,
                    ScrollClearance.bottomNav(context),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'SET IMAGE',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: isDark
                              ? NeoColors.secondaryText
                              : NeoColors.grey,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: NeoSpacing.md),
                      const Text(
                        'GAMBAR TOUCH SCREEN',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Developer menentukan gambar yang tampil saat touch screen di-lock. Gambar ini dipakai oleh semua user.',
                        style: TextStyle(fontSize: 12, color: NeoColors.grey),
                      ),
                      const SizedBox(height: NeoSpacing.lg),
                      Container(
                        width: double.infinity,
                        constraints: const BoxConstraints(minHeight: 320),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(
                            alpha: isDark ? 0.06 : 0.45,
                          ),
                          border: Border.all(
                            color: NeoColors.gold.withValues(alpha: 85 / 255),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(NeoRadius.lg),
                        ),
                        child: _loading
                            ? const Center(
                                child: NeoBlockLoader(
                                  blockSize: 7,
                                  c0: NeoColors.black,
                                  c1: NeoColors.yellow,
                                ),
                              )
                            : preview == null
                            ? const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(24),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.image_not_supported_outlined,
                                        size: 48,
                                        color: NeoColors.grey,
                                      ),
                                      SizedBox(height: 8),
                                      Text(
                                        'TANPA GAMBAR',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: NeoColors.grey,
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        'Gambar default akan dipakai',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: NeoColors.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : Image.memory(
                                base64Decode(preview),
                                fit: BoxFit.contain,
                                width: double.infinity,
                              ),
                      ),
                      const SizedBox(height: NeoSpacing.lg),
                      Row(
                        children: [
                          Expanded(
                            child: NeoButton(
                              label: 'PILIH GAMBAR',
                              height: 44,
                              onPressed: _pickImage,
                            ),
                          ),
                          const SizedBox(width: NeoSpacing.md),
                          Expanded(
                            child: NeoButton(
                              label: 'SIMPAN',
                              height: 44,
                              onPressed: _pendingImage == null ? null : _save,
                            ),
                          ),
                        ],
                      ),
                      if (hasImage) ...[
                        const SizedBox(height: NeoSpacing.md),
                        SizedBox(
                          width: double.infinity,
                          child: NeoButton(
                            label: 'HAPUS GAMBAR',
                            height: 44,
                            bgColor: NeoColors.pink,
                            textColor: Colors.white,
                            onPressed: _clear,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
