import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'roman_theme.dart';

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});
  @override
  State<InstagramDownloaderPage> createState() => _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  List<Map<String, dynamic>>? _media;
  String? _error;

  // Warna tema gelap
  static const _bg     = Rome.purpleDeep;
  static const _card   = Rome.purple;
  static const _accent = Rome.gold;
  static const _purple = Rome.purpleVelvet;
  static const _grey   = Rome.bronze;
  static const _white  = Rome.ivory;

  Future<void> _download() async {
    String url = _ctrl.text.trim();
    if (url.isEmpty) {
      setState(() { _error = 'URL tidak boleh kosong'; _media = null; }); return;
    }
    // Sanitasi URL — pastikan lengkap
    if (!url.startsWith('http')) url = 'https://www.instagram.com/$url';
    if (!url.contains('instagram.com')) {
      setState(() { _error = 'URL tidak valid. Gunakan link dari Instagram (instagram.com/p/..., /reel/...)'; _media = null; });
      return;
    }
    // Normalize URL
    url = url.split('?').first;
    if (!url.endsWith('/')) url = '$url/';

    setState(() { _loading = true; _error = null; _media = null; });

    List<Map<String, dynamic>>? result;
    result ??= await _trySaveig(url);
    result ??= await _trySnapinsta(url);
    result ??= await _tryIgram(url);
    result ??= await _tryCobalt(url);
    result ??= await _tryInstadownloader(url);

    if (result != null && result.isNotEmpty) {
      setState(() { _media = result; _loading = false; });
    } else {
      setState(() {
        _error = 'Gagal mengambil media. Pastikan:\n• URL lengkap (instagram.com/p/xxx/ atau /reel/xxx/)\n• Akun tidak private\n• Koneksi stabil';
        _loading = false;
      });
    }
  }

  // Source 1: saveig.app — sangat reliable untuk reels + posts
  Future<List<Map<String,dynamic>>?> _trySaveig(String url) async {
    try {
      final r1 = await http.get(
        Uri.parse('https://saveig.app/en'),
        headers: {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120'},
      ).timeout(const Duration(seconds: 8));
      final token = RegExp(r'"csrf_token"\s*:\s*"([^"]+)"')
          .firstMatch(r1.body)?.group(1) ?? '';
      if (token.isEmpty) return null;

      final r2 = await http.post(
        Uri.parse('https://saveig.app/api/ajaxSearch'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Requested-With': 'XMLHttpRequest',
          'Origin': 'https://saveig.app',
          'Referer': 'https://saveig.app/en',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120',
        },
        body: 'q=${Uri.encodeComponent(url)}&t=media&lang=en',
      ).timeout(const Duration(seconds: 14));

      final d = jsonDecode(r2.body);
      if (d['status'] == 'ok' && d['data'] is String) {
        final html = d['data'] as String;
        final urls = RegExp(
          r'href="(https?://[^"]+\.(mp4|jpg|jpeg|png|webp)[^"]*)"',
          caseSensitive: false,
        ).allMatches(html).map((m) => m.group(1)!).toSet().toList();
        if (urls.isNotEmpty) {
          return urls.map((u) => <String,dynamic>{
            'url': u, 'type': u.contains('.mp4') ? 'video' : 'image',
          }).toList();
        }
      }
      return null;
    } catch (_) { return null; }
  }

  Future<List<Map<String,dynamic>>?> _trySnapinsta(String url) async {
    try {
      final r1 = await http.get(Uri.parse('https://snapinsta.app/'),
        headers: {'User-Agent': 'Mozilla/5.0 (Android 13) Chrome/119'}).timeout(const Duration(seconds: 8));
      final token = RegExp(r'name="_token"\s+value="([^"]+)"').firstMatch(r1.body)?.group(1) ?? '';
      if (token.isEmpty) return null;
      final r2 = await http.post(Uri.parse('https://snapinsta.app/action'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Origin': 'https://snapinsta.app', 'Referer': 'https://snapinsta.app/',
          'User-Agent': 'Mozilla/5.0 (Android 13) Chrome/119',
        },
        body: Uri(queryParameters: {'url': url, 'token': token, 'lang': 'id'}).query,
      ).timeout(const Duration(seconds: 14));
      final html = jsonDecode(r2.body)['data'] ?? '';
      final urls = RegExp(r'href="(https?://[^"]+\.(mp4|jpg|jpeg|png|webp)[^"]*)"', caseSensitive: false)
          .allMatches(html).map((m) => m.group(1)!).toSet().toList();
      if (urls.isEmpty) return null;
      return urls.map((u) => <String, dynamic>{
        'url': u, 'type': u.contains('.mp4') ? 'video' : 'image',
      }).toList();
    } catch (_) { return null; }
  }

  Future<List<Map<String,dynamic>>?> _tryIgram(String url) async {
    try {
      final r = await http.post(Uri.parse('https://igram.world/api/ajax/search'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Origin': 'https://igram.world', 'Referer': 'https://igram.world/',
          'User-Agent': 'Mozilla/5.0 (Android 13) Chrome/119',
        },
        body: 'url=${Uri.encodeComponent(url)}&lang=id',
      ).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (d['status'] == 'ok' && d['media'] is List) {
        return (d['media'] as List).map<Map<String,dynamic>>((m) => {
          'url': m['url'] ?? m['src'], 'type': m['type'] ?? 'video',
        }).toList();
      }
      return null;
    } catch (_) { return null; }
  }

  Future<List<Map<String,dynamic>>?> _tryInstadownloader(String url) async {
    try {
      final r = await http.post(Uri.parse('https://instadownloader.co/api/'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'Mozilla/5.0 (Android 13) Chrome/119',
        },
        body: 'url=${Uri.encodeComponent(url)}',
      ).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (d['status'] == true && d['data'] is List) {
        return (d['data'] as List).map<Map<String,dynamic>>((m) => {
          'url': m['url'], 'type': (m['type'] ?? 'video'),
        }).toList();
      }
      return null;
    } catch (_) { return null; }
  }

  Future<List<Map<String,dynamic>>?> _tryCobalt(String url) async {
    try {
      final r = await http.post(Uri.parse('https://api.cobalt.tools/'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'User-Agent': 'VoltaraApp/5.0',
        },
        body: jsonEncode({'url': url, 'downloadMode': 'auto'}),
      ).timeout(const Duration(seconds: 18));
      if (r.statusCode == 200) {
        final d = jsonDecode(r.body);
        if (d['url'] != null) {
          return [{'url': d['url'], 'type': 'video'}];
        }
        if (d['picker'] is List) {
          return (d['picker'] as List).map<Map<String,dynamic>>((m) => {
            'url': m['url'], 'type': 'video',
          }).toList();
        }
      }
      return null;
    } catch (_) { return null; }
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        title: const Text('INSTAGRAM DOWNLOADER',
          style: TextStyle(fontWeight: FontWeight.bold, color: _white, fontSize: 14, letterSpacing: 1)),
        backgroundColor: _bg, centerTitle: true, elevation: 0,
        iconTheme: const IconThemeData(color: _white),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: _white), onPressed: () => Navigator.pop(context)),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Input card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _card, borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _purple.withOpacity(0.4)),
                ),
                child: Column(children: [
                  TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: _white, fontSize: 14),
                    decoration: InputDecoration(
                      labelText: 'Masukkan URL Instagram',
                      labelStyle: const TextStyle(color: _grey),
                      hintText: 'https://www.instagram.com/reel/...',
                      hintStyle: const TextStyle(color: _grey, fontSize: 12),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: _purple.withOpacity(0.5)),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: _accent, width: 2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true, fillColor: _bg.withOpacity(0.4),
                      prefixIcon: const Icon(Icons.camera_alt, color: _accent),
                      suffixIcon: _loading ? const Padding(
                        padding: EdgeInsets.all(12),
                        child: SizedBox(width: 18, height: 18,
                          child: CircularProgressIndicator(color: _accent, strokeWidth: 2)),
                      ) : null,
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _loading ? null : _download,
                      icon: Icon(_loading ? Icons.hourglass_top : Icons.download, size: 20),
                      label: Text(_loading ? 'PROSES...' : 'DOWNLOAD',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 1)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _purple, foregroundColor: _white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ]),
              ),

              const SizedBox(height: 16),

              // Error
              if (_error != null)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.purple.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.purple.withOpacity(0.3)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.error_outline, color: _accent),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_error!, style: const TextStyle(color: _accent, fontSize: 13))),
                  ]),
                ),

              // Hasil media
              if (_media != null) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: _purple, borderRadius: BorderRadius.circular(8)),
                  child: Text('MEDIA (${_media!.length})', style: const TextStyle(color: _white, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: _media!.length,
                    itemBuilder: (ctx, i) {
                      final m = _media![i];
                      final isVid = m['type'] == 'video';
                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _card, borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _purple.withOpacity(0.3)),
                        ),
                        child: Row(children: [
                          Container(
                            width: 48, height: 48,
                            decoration: BoxDecoration(color: _purple.withOpacity(0.3), borderRadius: BorderRadius.circular(8)),
                            child: Icon(isVid ? Icons.videocam : Icons.photo, color: _accent, size: 26),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(isVid ? 'Video ${i+1}' : 'Gambar ${i+1}',
                              style: const TextStyle(color: _white, fontWeight: FontWeight.w700, fontSize: 13)),
                            Text(isVid ? 'MP4 Video' : 'Gambar',
                              style: const TextStyle(color: _grey, fontSize: 11)),
                          ])),
                          ElevatedButton.icon(
                            onPressed: () => _open(m['url']),
                            icon: const Icon(Icons.download, size: 16),
                            label: const Text('DL', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _accent, foregroundColor: _bg,
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ]),
                      );
                    },
                  ),
                ),
              ],

              // Placeholder
              if (_media == null && !_loading && _error == null)
                Expanded(
                  child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.camera_alt, size: 72, color: _purple.withOpacity(0.4)),
                    const SizedBox(height: 14),
                    const Text('Instagram Downloader', style: TextStyle(color: _grey, fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 32),
                      child: Text('Paste link Reel, Post, atau Story Instagram',
                        style: TextStyle(color: _grey, fontSize: 12), textAlign: TextAlign.center),
                    ),
                  ])),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
