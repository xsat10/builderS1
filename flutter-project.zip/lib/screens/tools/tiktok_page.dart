import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

import 'roman_theme.dart';

const _kBase = 'http://kentodewehinata.cloudnestpanel.my.id:2500';

// ── Warna ──
const _bg = Rome.purpleDeep;
const _card = Rome.purple;
const _acc = Rome.gold;
const _acD = Rome.goldDeep;
const _wh = Rome.ivory;
const _sub = Rome.bronze;
const _brd = Rome.purpleVelvet;

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});
  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage>
    with SingleTickerProviderStateMixin {
  final _urlCtrl = TextEditingController();
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _data;
  VideoPlayerController? _vpc;
  ChewieController? _chewieCtrl;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    _vpc?.dispose();
    _chewieCtrl?.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Fetch from own API server ──
  Future<void> _download() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) {
      setState(() => _error = 'Masukkan URL TikTok terlebih dahulu.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
      _data = null;
    });
    _vpc?.dispose();
    _chewieCtrl?.dispose();
    _vpc = null;
    _chewieCtrl = null;

    try {
      final uri = Uri.parse(
        '$_kBase/api/d/tiktok',
      ).replace(queryParameters: {'url': url});
      final res = await http
          .get(uri, headers: {'User-Agent': 'VoltaraApp/7.5'})
          .timeout(const Duration(seconds: 25));

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _data = Map<String, dynamic>.from(json['data']));
          _initVideo();
        } else {
          setState(
            () => _error = json['msg'] ?? 'Gagal mengambil video TikTok.',
          );
        }
      } else {
        setState(() => _error = 'Server error: ${res.statusCode}');
      }
    } catch (e) {
      setState(() => _error = 'Timeout atau koneksi gagal. Coba lagi.');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _initVideo() {
    final urls = (_data?['urls'] as List?)?.cast<String>() ?? [];
    if (urls.isEmpty) return;
    final videoUrl = urls.first;
    _vpc = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieCtrl = ChewieController(
            videoPlayerController: _vpc!,
            autoPlay: true,
            looping: false,
            showControls: true,
            materialProgressColors: ChewieProgressColors(
              playedColor: _acc,
              handleColor: _acD,
              backgroundColor: _brd,
              bufferedColor: _sub.withOpacity(0.3),
            ),
          );
        });
      });
  }

  Future<void> _share() async {
    final urls = (_data?['urls'] as List?)?.cast<String>() ?? [];
    if (urls.isEmpty) return;
    try {
      final r = await http.get(Uri.parse(urls.first));
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4',
      );
      await file.writeAsBytes(r.bodyBytes);
      await Share.shareXFiles(
        [XFile(file.path)],
        text:
            'Video TikTok dari: ${_data?['metadata']?['creator'] ?? '@tiktok'}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
            content: Text(
              'Gagal share: $e',
              style: const TextStyle(color: _wh),
            ),
            backgroundColor: _card,
          ),
        );
      }
    }
  }

  void _pasteClipboard() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      _urlCtrl.text = data!.text!;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: _wh,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: const Color(0xFFEE1D52).withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.music_note,
                color: Color(0xFFEE1D52),
                size: 18,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'TikTok Downloader',
              style: TextStyle(
                color: _wh,
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        centerTitle: false,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // ── URL Input ──
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Container(
                decoration: BoxDecoration(
                  color: _card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _brd),
                ),
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.link_rounded, color: _acc, size: 20),
                        const SizedBox(width: 8),
                        const Text(
                          'URL TikTok',
                          style: TextStyle(
                            color: _wh,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: _pasteClipboard,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: _acc.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: _acc.withOpacity(0.3)),
                            ),
                            child: const Text(
                              'Paste',
                              style: TextStyle(
                                color: _acc,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _urlCtrl,
                      style: const TextStyle(color: _wh, fontSize: 13),
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        hintText:
                            'https://vt.tiktok.com/xxx/ atau vm.tiktok.com/xxx/',
                        hintStyle: TextStyle(
                          color: _sub.withOpacity(0.7),
                          fontSize: 12,
                        ),
                        filled: true,
                        fillColor: _bg,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: _brd),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: _brd),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: _acc, width: 1.5),
                        ),
                        suffixIcon: _urlCtrl.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(
                                  Icons.clear,
                                  color: _sub,
                                  size: 16,
                                ),
                                onPressed: () {
                                  _urlCtrl.clear();
                                  setState(() {});
                                },
                              )
                            : null,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _download,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _acc,
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 0,
                        ),
                        child: _loading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.black,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.download_rounded, size: 20),
                                  SizedBox(width: 8),
                                  Text(
                                    'DOWNLOAD',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 14,
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ── Error ──
            if (_error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.error_outline,
                        color: Colors.redAccent,
                        size: 18,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _error!,
                          style: const TextStyle(
                            color: Colors.redAccent,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // ── Result ──
            Expanded(
              child: _data == null ? _buildPlaceholder() : _buildResult(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholder() => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Opacity(
            opacity: 0.3 + 0.3 * _pulseCtrl.value,
            child: const Icon(
              Icons.video_collection_rounded,
              size: 72,
              color: _acc,
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'TikTok Downloader',
          style: TextStyle(
            color: _wh,
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Paste URL TikTok dan tekan Download',
          style: TextStyle(color: _sub, fontSize: 12),
        ),
        const SizedBox(height: 4),
        const Text(
          'Tanpa watermark • HD quality',
          style: TextStyle(
            color: _acc,
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );

  Widget _buildResult() {
    final meta = _data?['metadata'] as Map? ?? {};
    final title = (meta['title'] ?? 'TikTok Video') as String;
    final creator = (meta['creator'] ?? '@tiktok') as String;
    final cover = (meta['cover'] ?? '') as String;
    final noWm = (_data?['noWatermark'] ?? '') as String;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Video Player ──
          if (_chewieCtrl != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: AspectRatio(
                aspectRatio: _vpc!.value.aspectRatio,
                child: Chewie(controller: _chewieCtrl!),
              ),
            ),
            const SizedBox(height: 12),
          ] else if (cover.isNotEmpty) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.network(
                cover,
                width: double.infinity,
                height: 220,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 220,
                  color: _card,
                  child: const Icon(
                    Icons.videocam_rounded,
                    color: _sub,
                    size: 48,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],

          // ── Meta info ──
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _brd),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _wh,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.person_rounded, color: _acc, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      creator,
                      style: const TextStyle(color: _sub, fontSize: 12),
                    ),
                    const Spacer(),
                    if (_data?['source'] != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: _acc.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: _acc.withOpacity(0.3)),
                        ),
                        child: Text(
                          (_data!['source'] as String).toUpperCase(),
                          style: const TextStyle(
                            color: _acc,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ── Download buttons ──
          if (noWm.isNotEmpty)
            _dlButton(
              'Download Tanpa Watermark (HD)',
              Icons.hd_rounded,
              const Color(0xFF1AA34A),
              noWm,
              'no_watermark.mp4',
            ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: ElevatedButton.icon(
              onPressed: _share,
              icon: const Icon(Icons.share_rounded, size: 18),
              label: const Text(
                'Share Video',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1877F2),
                foregroundColor: _wh,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),

          // ── Audio ──
          if ((_data?['audio'] as String? ?? '').isNotEmpty) ...[
            const SizedBox(height: 8),
            _dlButton(
              'Download Audio Saja',
              Icons.music_note_rounded,
              const Color(0xFF7C3AED),
              _data!['audio'] as String,
              'audio_tiktok.mp3',
            ),
          ],
        ],
      ),
    );
  }

  Widget _dlButton(
    String label,
    IconData icon,
    Color color,
    String url,
    String filename,
  ) {
    return SizedBox(
      width: double.infinity,
      height: 46,
      child: ElevatedButton.icon(
        onPressed: () async {
          try {
            final r = await http.get(Uri.parse(url));
            final dir = await getTemporaryDirectory();
            final f = File('${dir.path}/$filename');
            await f.writeAsBytes(r.bodyBytes);
            await Share.shareXFiles([XFile(f.path)]);
          } catch (e) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
                  content: Text('Gagal: $e'),
                  backgroundColor: _card,
                ),
              );
            }
          }
        },
        icon: Icon(icon, size: 18),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: _wh,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}
