import 'package:flutter/material.dart';

class Rome {
  Rome._();

  static const Color purple = Color(0xFF2B1A3C);
  static const Color purpleDeep = Color(0xFF180E26);
  static const Color purpleVelvet = Color(0xFF3E2554);
  static const Color gold = Color(0xFFFFD98A);
  static const Color goldDeep = Color(0xFFBB8C2E);
  static const Color ivory = Color(0xFFFBF5E6);
  static const Color bronze = Color(0xFF9C7B4E);
  static const Color ember = Color(0xFFFFA14B);
  static const Color jade = Color(0xFF4DD0A8);

  static const Color voidBg = Color(0xFF100A1E);
  static const Color cardBg = Color(0xFF211534);
  static const Color line = Color(0x66FFD98A);
}