import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'roman_theme.dart';

const Color _bg      = Rome.purpleDeep;
const Color _card    = Rome.purple;
const Color _accent  = Rome.gold;
const Color _textMain = Rome.ivory;
const Color _textSub  = Rome.bronze;

class SpotifyDownloaderPage extends StatefulWidget {
  const SpotifyDownloaderPage({super.key});
  @override
  State<SpotifyDownloaderPage> createState() => _SpotifyDownloaderPageState();
}

class _SpotifyDownloaderPageState extends State<SpotifyDownloaderPage> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _result;
  String? _error;

  // Resolve Spotify short link → full URL
  Future<String> _resolveUrl(String url) async {
    // short links: open.spotify.com/s/xxx
    if (url.contains('/s/') || (!url.contains('/track/') && !url.contains('/playlist/') && !url.contains('/album/'))) {
      try {
        final r = await http.get(Uri.parse(url),
          headers: {'User-Agent': 'Mozilla/5.0'}).timeout(const Duration(seconds: 10));
        // follow redirect — http package doesn't auto-follow on some configs
        final location = r.headers['location'];
        if (location != null && location.isNotEmpty) return location;
        // check if response URL changed (body may have canonical link)
        final canonical = RegExp(r'<link rel="canonical" href="([^"]+)"').firstMatch(r.body);
        if (canonical != null) return canonical.group(1)!;
      } catch (_) {}
    }
    return url;
  }

  Future<void> _fetch() async {
    var url = _ctrl.text.trim();
    if (url.isEmpty) return;
    setState(() { _loading = true; _result = null; _error = null; });

    try {
      // Step 1: resolve short link
      url = await _resolveUrl(url);

      // Step 2: coba cobalt.tools (support spotify)
      final cobaltEndpoints = [
        'https://api.cobalt.tools/',
        'https://cobalt.tools/api/',
      ];
      dynamic cobaltData;
      for (final ep in cobaltEndpoints) {
        try {
          final r = await http.post(Uri.parse(ep),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'User-Agent': 'VoltaraApp/5.0 (Android; Flutter)',
            },
            body: jsonEncode({
              'url': url,
              'downloadMode': 'audio',
              'audioFormat': 'mp3',
              'audioBitrate': '320',
            })).timeout(const Duration(seconds: 20));
          if (r.statusCode == 200) {
            cobaltData = jsonDecode(r.body);
            break;
          }
        } catch (_) { continue; }
      }

      if (cobaltData != null &&
          (cobaltData['status'] == 'redirect' || cobaltData['status'] == 'stream' || cobaltData['status'] == 'tunnel')) {
        setState(() { _result = cobaltData; _loading = false; });
        return;
      }

      // Step 3: spotifydown fallback — coba extract track ID dari URL yang sudah di-resolve
      await _spotifyDownFallback(url);

    } catch (e) {
      setState(() { _error = 'Koneksi gagal: $e'; _loading = false; });
    }
  }

  Future<void> _spotifyDownFallback(String url) async {
    try {
      final match = RegExp(r'track/([a-zA-Z0-9]+)').firstMatch(url);
      if (match == null) {
        // Coba endpoint alternatif langsung dengan full URL
        await _yank(url);
        return;
      }
      final trackId = match.group(1)!;

      // spotifydown.com
      final res = await http.get(
        Uri.parse('https://spotifydown.com/api/download?link=https://open.spotify.com/track/$trackId'),
        headers: {
          'origin': 'https://spotifydown.com',
          'referer': 'https://spotifydown.com/',
          'User-Agent': 'Mozilla/5.0 (Android 13) AppleWebKit/537.36',
        },
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        setState(() { _result = {'url': data['link'], 'metadata': data}; _loading = false; });
        return;
      }

      // Coba spotifydl.co
      final res2 = await http.get(
        Uri.parse('https://spotifydl.co/api/track?url=https://open.spotify.com/track/$trackId'),
        headers: {'User-Agent': 'Mozilla/5.0'},
      ).timeout(const Duration(seconds: 12));
      final d2 = jsonDecode(res2.body);
      if (d2['success'] == true || d2['url'] != null) {
        setState(() { _result = {'url': d2['url'] ?? d2['link'], 'metadata': d2}; _loading = false; });
        return;
      }

      setState(() { _error = 'Gagal download: ${data['message'] ?? 'Semua endpoint gagal'}'; _loading = false; });
    } catch (e) {
      setState(() { _error = 'Error: $e'; _loading = false; });
    }
  }

  Future<void> _yank(String url) async {
    try {
      // y2mate / loader.to sebagai last resort
      final res = await http.post(
        Uri.parse('https://loader.to/ajax/download.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'start=1&end=1&format=mp3&url=${Uri.encodeComponent(url)}',
      ).timeout(const Duration(seconds: 12));
      final d = jsonDecode(res.body);
      if (d['success'] == 1) {
        setState(() { _result = {'url': d['download_url'] ?? d['url']}; _loading = false; });
      } else {
        setState(() { _error = 'Link Spotify tidak valid atau tidak didukung. Coba link track langsung.'; _loading = false; });
      }
    } catch (e) {
      setState(() { _error = 'Link tidak valid. Gunakan link track/playlist langsung (bukan short link).'; _loading = false; });
    }
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _card, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: _textMain), onPressed: () => Navigator.pop(context)),
        title: const Text('Spotify Downloader', style: TextStyle(color: _textMain, fontWeight: FontWeight.w800, fontSize: 16)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14),
                boxShadow: const [BoxShadow(color: Color(0x221A1A1A), blurRadius: 8, offset: Offset(3, 3))]),
              child: Column(children: [
                const Icon(Icons.music_note, size: 48, color: _accent),
                const SizedBox(height: 8),
                const Text('Paste link track atau playlist Spotify', style: TextStyle(color: _textSub, fontSize: 12), textAlign: TextAlign.center),
                const SizedBox(height: 4),
                const Text('(link biasa maupun short link didukung)', style: TextStyle(color: _textSub, fontSize: 10), textAlign: TextAlign.center),
                const SizedBox(height: 12),
                TextField(
                  controller: _ctrl,
                  decoration: InputDecoration(
                    hintText: 'https://open.spotify.com/track/... atau short link',
                    hintStyle: const TextStyle(color: _textSub, fontSize: 11),
                    filled: true, fillColor: const Color(0xFFF0F0F0),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                    prefixIcon: const Icon(Icons.link, color: _accent),
                  ),
                  style: const TextStyle(color: _textMain, fontSize: 12),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _fetch,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: _loading
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: _textMain, strokeWidth: 2))
                      : const Text('FETCH TRACK', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 20),
            if (_error != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade200)),
                child: Row(children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12))),
                ]),
              ),
            if (_result != null) ...[
              const Text('HASIL', style: TextStyle(color: _textSub, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 2)),
              const SizedBox(height: 10),
              if (_result!['metadata'] != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(_result!['metadata']['title'] ?? '', style: const TextStyle(color: _textMain, fontWeight: FontWeight.w700)),
                    Text(_result!['metadata']['artists'] ?? _result!['metadata']['artist'] ?? '', style: const TextStyle(color: _textSub, fontSize: 12)),
                  ]),
                ),
                const SizedBox(height: 10),
              ],
              if (_result!['url'] != null)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => _open(_result!['url']),
                    icon: const Icon(Icons.download),
                    label: const Text('Download MP3', style: TextStyle(fontWeight: FontWeight.w700)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
