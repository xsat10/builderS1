import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'roman_theme.dart';

const Color _ytBg      = Rome.purpleDeep;
const Color _ytCard    = Rome.purple;
const Color _ytAccent  = Rome.gold;
const Color _ytText    = Rome.ivory;
const Color _ytSub     = Rome.bronze;
const Color _ytField   = Rome.purpleVelvet;

class YoutubeDownloaderPage extends StatefulWidget {
  const YoutubeDownloaderPage({super.key});
  @override
  State<YoutubeDownloaderPage> createState() => _YoutubeDownloaderPageState();
}

class _YoutubeDownloaderPageState extends State<YoutubeDownloaderPage> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  Map<String, dynamic>? _result;
  String? _error;

  Future<void> _fetch() async {
    final url = _ctrl.text.trim();
    if (url.isEmpty) return;
    setState(() { _loading = true; _result = null; _error = null; });

    // Coba cobalt.tools
    dynamic data = await _tryCobalt(url);

    if (data != null &&
        (data['status'] == 'redirect' || data['status'] == 'stream' ||
         data['status'] == 'tunnel' || data['status'] == 'picker')) {
      setState(() { _result = data; _loading = false; });
      return;
    }

    // Fallback: yt1s / y2mate-style API
    await _fallbackYtdl(url);
  }

  Future<dynamic> _tryCobalt(String url) async {
    final endpoints = [
      'https://api.cobalt.tools/',
      'https://cobalt.tools/api/',
      'https://co.wuk.sh/api/json',   // community instance
    ];
    for (final ep in endpoints) {
      try {
        final r = await http.post(Uri.parse(ep),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': 'VoltaraApp/5.0 (Android; Flutter)',
          },
          body: jsonEncode({
            'url': url,
            'downloadMode': 'auto',
            'videoQuality': '1080',
            'audioFormat': 'mp3',
          })).timeout(const Duration(seconds: 18));
        if (r.statusCode == 200) return jsonDecode(r.body);
      } catch (_) { continue; }
    }
    return null;
  }

  Future<void> _fallbackYtdl(String url) async {
    // Coba yt5s.io
    try {
      final r1 = await http.post(Uri.parse('https://yt5s.io/api/ajaxSearch'),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Referer': 'https://yt5s.io/',
          'Origin': 'https://yt5s.io',
          'User-Agent': 'Mozilla/5.0 (Android 13) Chrome/119.0',
        },
        body: 'q=${Uri.encodeComponent(url)}&vt=mp4',
      ).timeout(const Duration(seconds: 15));
      if (r1.statusCode == 200) {
        final d = jsonDecode(r1.body);
        if (d['status'] == 'ok' && d['links'] != null) {
          // ambil kualitas terbaik
          final links = d['links'] as Map<String, dynamic>;
          String? dlUrl;
          for (final quality in ['1080', '720', '480', '360']) {
            if (links[quality] != null) { dlUrl = links[quality]['url']; break; }
          }
          if (dlUrl != null) {
            setState(() { _result = {'url': dlUrl, 'title': d['title']}; _loading = false; });
            return;
          }
        }
      }
    } catch (_) {}

    // Last resort: yt1s.com
    try {
      final r2 = await http.post(Uri.parse('https://yt1s.com/api/ajaxSearch/index'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'q=${Uri.encodeComponent(url)}&vt=mp4',
      ).timeout(const Duration(seconds: 15));
      if (r2.statusCode == 200) {
        final d = jsonDecode(r2.body);
        if (d['status'] == 'ok') {
          setState(() { _result = {'url': url, '_needConvert': true, 'vid': d['vid'], 'title': d['title']}; _loading = false; });
          return;
        }
      }
    } catch (_) {}

    setState(() { _error = 'Semua endpoint gagal. Cek URL YouTube dan koneksi internet.'; _loading = false; });
  }

  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _ytBg,
      appBar: AppBar(
        backgroundColor: _ytCard, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: _ytText), onPressed: () => Navigator.pop(context)),
        title: const Text('YouTube Downloader', style: TextStyle(color: _ytText, fontWeight: FontWeight.w800, fontSize: 16)),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _ytCard,
                borderRadius: BorderRadius.circular(14),
                boxShadow: const [BoxShadow(color: Color(0x221A1A1A), blurRadius: 8, offset: Offset(3, 3))],
              ),
              child: Column(children: [
                const Icon(Icons.play_circle_outline, size: 48, color: _ytAccent),
                const SizedBox(height: 8),
                const Text('Paste link video YouTube', style: TextStyle(color: _ytSub, fontSize: 12), textAlign: TextAlign.center),
                const SizedBox(height: 12),
                // ── FIX: fillColor terang + style teks hitam ──
                TextField(
                  controller: _ctrl,
                  style: const TextStyle(color: _ytText, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'https://youtu.be/... atau youtube.com/watch?v=...',
                    hintStyle: const TextStyle(color: _ytSub, fontSize: 11),
                    filled: true,
                    fillColor: _ytField,        // ← putih terang, bukan hitam
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                    prefixIcon: const Icon(Icons.link, color: _ytAccent),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _fetch,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _ytAccent, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: _loading
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: _ytText, strokeWidth: 2))
                      : const Text('FETCH VIDEO', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 20),
            if (_error != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade200)),
                child: Row(children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12))),
                ]),
              ),
            if (_result != null) ...[
              const Text('HASIL', style: TextStyle(color: _ytSub, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 2)),
              const SizedBox(height: 10),
              if (_result!['title'] != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(_result!['title'], style: const TextStyle(color: _ytText, fontWeight: FontWeight.w700, fontSize: 13)),
                ),
              if (_result!['url'] != null && _result!['_needConvert'] != true)
                _DlBtn(label: 'Download Video/Audio', url: _result!['url'], onTap: _open),
              if (_result!['picker'] != null)
                ...(_result!['picker'] as List).asMap().entries.map((e) =>
                  _DlBtn(label: 'Stream ${e.key + 1}', url: e.value['url'], onTap: _open)),
              if (_result!['_needConvert'] == true)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _ytCard, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _ytAccent)),
                  child: const Text('Video ditemukan. Buka link YouTube di browser untuk download.',
                    style: TextStyle(color: _ytSub, fontSize: 12)),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DlBtn extends StatelessWidget {
  final String label, url;
  final Function(String) onTap;
  const _DlBtn({required this.label, required this.url, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: () => onTap(url),
        icon: const Icon(Icons.download, size: 18),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        style: ElevatedButton.styleFrom(
          backgroundColor: _ytCard, foregroundColor: _ytAccent,
          side: const BorderSide(color: _ytAccent),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}
