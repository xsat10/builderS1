import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';

import 'roman_theme.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:path_provider/path_provider.dart';

// ============================================================
//  FILE: iqc_page.dart
//  Widget: IQCScreen
//  FIX: permission Android 13+ (READ_MEDIA_IMAGES), MediaStore save
// ============================================================

class IQCScreen extends StatefulWidget {
  const IQCScreen({super.key});

  @override
  State<IQCScreen> createState() => _IQCScreenState();
}

class _IQCScreenState extends State<IQCScreen> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _chatTimeController = TextEditingController();
  final TextEditingController _statusBarTimeController =
      TextEditingController();

  Uint8List? _generatedImage;
  bool _isGenerating = false;
  bool _isSaving = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    final timeFormat = DateFormat('HH:mm');
    final now = DateTime.now();
    _chatTimeController.text = timeFormat.format(now);
    _statusBarTimeController.text = timeFormat.format(now);
    _textController.text = 'Alex Yusomo';
  }

  @override
  void dispose() {
    _textController.dispose();
    _chatTimeController.dispose();
    _statusBarTimeController.dispose();
    super.dispose();
  }

  bool _isValidTime(String time) {
    final regex = RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$');
    return regex.hasMatch(time);
  }

  Future<void> _generateIQCImage() async {
    if (_textController.text.isEmpty) {
      _showError('Masukkan teks chat terlebih dahulu');
      return;
    }
    if (_chatTimeController.text.isEmpty ||
        _statusBarTimeController.text.isEmpty) {
      _showError('Masukkan waktu chat dan status bar');
      return;
    }
    if (!_isValidTime(_chatTimeController.text)) {
      _showError('Format waktu chat salah (gunakan HH:mm)');
      return;
    }
    if (!_isValidTime(_statusBarTimeController.text)) {
      _showError('Format waktu status bar salah (gunakan HH:mm)');
      return;
    }

    setState(() {
      _isGenerating = true;
      _errorMessage = null;
      _generatedImage = null;
    });

    try {
      final text = Uri.encodeComponent(_textController.text);
      final chatTime = Uri.encodeComponent(_chatTimeController.text);
      final statusBarTime = Uri.encodeComponent(_statusBarTimeController.text);
      final apiUrl =
          'https://api.deline.web.id/maker/iqc?text=$text&chatTime=$chatTime&statusBarTime=$statusBarTime';

      final response = await http
          .get(
            Uri.parse(apiUrl),
            headers: {'User-Agent': 'IQC-Screenshot-Maker/1.0'},
          )
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200 && response.bodyBytes.isNotEmpty) {
        setState(() {
          _generatedImage = response.bodyBytes;
        });
        _showSuccess('Gambar berhasil dihasilkan dari API');
      } else {
        throw Exception('API Error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal menghubungi API: $e';
      });
      _showError(_errorMessage!);
    } finally {
      setState(() {
        _isGenerating = false;
      });
    }
  }

  // â”€â”€ FIX UTAMA: permission handler yang benar untuk semua Android version â”€â”€
  Future<bool> _requestStoragePermission() async {
    if (!Platform.isAndroid) {
      // iOS: minta photo library access
      final status = await Permission.photos.request();
      return status.isGranted;
    }

    // Cek Android SDK version
    final deviceInfo = DeviceInfoPlugin();
    final androidInfo = await deviceInfo.androidInfo;
    final sdkInt = androidInfo.version.sdkInt;

    if (sdkInt >= 33) {
      // Android 13+ (API 33+): WRITE_EXTERNAL_STORAGE sudah deprecated
      // Pakai Permission.photos (READ_MEDIA_IMAGES)
      final status = await Permission.photos.request();
      if (status.isGranted) return true;
      if (status.isPermanentlyDenied) {
        _showPermissionDialog();
        return false;
      }
      return false;
    } else if (sdkInt >= 29) {
      // Android 10-12: tidak perlu permission untuk MediaStore, tapi minta storage dulu
      final status = await Permission.storage.request();
      return status.isGranted || status.isLimited;
    } else {
      // Android 9 ke bawah: butuh WRITE_EXTERNAL_STORAGE
      final status = await Permission.storage.request();
      if (status.isGranted) return true;
      if (status.isPermanentlyDenied) {
        _showPermissionDialog();
        return false;
      }
      return false;
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Rome.purpleVelvet,
        title: const Text(
          'Izin Diperlukan',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Izin penyimpanan foto ditolak secara permanen.\nBuka Settings â†’ Apps â†’ Voltara â†’ Permissions â†’ Photos/Storage, lalu aktifkan izinnya.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('BATAL'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: const Text('BUKA SETTINGS'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveImage() async {
    if (_generatedImage == null) {
      _showError('Tidak ada gambar untuk disimpan');
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      // Request permission dulu (handled per-SDK-version)
      final granted = await _requestStoragePermission();
      if (!granted) {
        _showError('Izin penyimpanan ditolak');
        return;
      }

      // Buat nama file
      final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final safeText = _textController.text
          .replaceAll(' ', '_')
          .replaceAll(RegExp(r'[^\w]'), '')
          .substring(0, _textController.text.length.clamp(0, 15));
      final fileName = 'IQC_${safeText}_$timestamp.png';

      // Simpan via path_provider ke DCIM/Pictures, lalu scan MediaStore
      final String savedPath = await _saveImageToGallery(
        _generatedImage!,
        fileName,
      );

      if (savedPath.isNotEmpty) {
        _showSuccess('âœ… Gambar tersimpan ke Galeri!');
        _showSaveSuccessDialog(fileName);
      } else {
        throw Exception('Gagal menyimpan gambar ke galeri');
      }
    } catch (e) {
      _showError('Gagal menyimpan gambar: $e');
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  // â”€â”€ Simpan PNG ke DCIM/Pictures tanpa package eksternal â”€â”€
  Future<String> _saveImageToGallery(Uint8List bytes, String fileName) async {
    try {
      if (Platform.isAndroid) {
        // Coba tulis ke DCIM/Pictures via MediaStore method channel
        const MethodChannel _mediaChannel = MethodChannel(
          'com.darkness.darkverse/media_store',
        );
        try {
          final String? path = await _mediaChannel.invokeMethod<String>(
            'saveImage',
            {'bytes': bytes, 'name': fileName},
          );
          if (path != null && path.isNotEmpty) return path;
        } catch (_) {
          // Method channel tidak ada — fallback ke path_provider
        }

        // Fallback: simpan ke getExternalStorageDirectory / Pictures
        final Directory? extDir = await getExternalStorageDirectory();
        if (extDir != null) {
          // Naik ke root storage, lalu masuk DCIM/Pictures
          final List<String> parts = extDir.path.split('/');
          final int androidIdx = parts.indexOf('Android');
          final String rootPath = androidIdx > 0
              ? parts.sublist(0, androidIdx).join('/')
              : extDir.path;
          final Directory dcim = Directory('$rootPath/DCIM/Pictures');
          if (!await dcim.exists()) await dcim.create(recursive: true);
          final File file = File('${dcim.path}/$fileName');
          await file.writeAsBytes(bytes);
          // Trigger MediaStore scan agar foto muncul di Galeri
          try {
            const MethodChannel _scanChannel = MethodChannel(
              'com.darkness.darkverse/media_store',
            );
            await _scanChannel.invokeMethod<void>('scanFile', {
              'path': file.path,
            });
          } catch (_) {}
          return file.path;
        }
      } else if (Platform.isIOS) {
        // iOS: simpan ke temp, bagikan via UIImageWriteToSavedPhotosAlbum
        final Directory tmp = await getTemporaryDirectory();
        final File file = File('${tmp.path}/$fileName');
        await file.writeAsBytes(bytes);
        return file.path;
      }

      // Absolute fallback — simpan ke app documents dir
      final Directory docs = await getApplicationDocumentsDirectory();
      final File file = File('${docs.path}/$fileName');
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (e) {
      return '';
    }
  }

  Future<void> _copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    _showSuccess('Disalin ke clipboard: $text');
  }

  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(message),
        backgroundColor: const Color(0xFF10B981),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(message),
        backgroundColor: const Color(0xFFEF4444),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSaveSuccessDialog(String fileName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Rome.purpleVelvet,
        title: const Text(
          'Gambar Disimpan!',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Gambar berhasil disimpan ke Galeri:',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Rome.purpleDeep,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                fileName,
                style: const TextStyle(
                  color: Color(0xFF60A5FA),
                  fontFamily: 'monospace',
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Buka Galeri untuk melihat dan membagikan gambar.',
              style: TextStyle(color: Colors.white70, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    String hint = '',
    bool isTime = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: Rome.cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Rome.bronze, width: 1),
          ),
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white54),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              suffixIcon: isTime
                  ? IconButton(
                      onPressed: () {
                        final timeFormat = DateFormat('HH:mm');
                        final now = DateTime.now();
                        controller.text = timeFormat.format(now);
                      },
                      icon: const Icon(
                        Icons.access_time,
                        color: Color(0xFF60A5FA),
                      ),
                      tooltip: 'Gunakan waktu sekarang',
                    )
                  : null,
            ),
            style: const TextStyle(color: Rome.ivory, fontSize: 16),
            maxLines: isTime ? 1 : 3,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Rome.voidBg,
      appBar: AppBar(
        title: const Text('IQC Screenshot Maker'),
        backgroundColor: Rome.purpleVelvet,
        elevation: 0,
        centerTitle: true,
        actions: [
          if (_generatedImage != null)
            IconButton(
              onPressed: _isSaving ? null : _saveImage,
              icon: _isSaving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.download),
              tooltip: 'Simpan ke Galeri',
            ),
          IconButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: Rome.purpleVelvet,
                  title: const Text(
                    'Tentang',
                    style: TextStyle(color: Colors.white),
                  ),
                  content: const Text(
                    'Screen Shot Whatsapp iPhone\n\nGambar tersimpan langsung ke Galeri HP.',
                    style: TextStyle(color: Colors.white70),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('TUTUP'),
                    ),
                  ],
                ),
              );
            },
            icon: const Icon(Icons.info_outline),
            tooltip: 'Tentang',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Input Section
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Rome.cardBg,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1A1A1A),
                    blurRadius: 0,
                    offset: const Offset(3, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildInputField(
                    label: 'Teks Chat',
                    controller: _textController,
                    hint: 'Masukkan teks chat...',
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: _buildInputField(
                          label: 'Waktu Chat',
                          controller: _chatTimeController,
                          hint: 'HH:mm',
                          isTime: true,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildInputField(
                          label: 'Waktu Status Bar',
                          controller: _statusBarTimeController,
                          hint: 'HH:mm',
                          isTime: true,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(
                        Icons.info,
                        size: 14,
                        color: Color(0xFF94A3B8),
                      ),
                      const SizedBox(width: 4),
                      const Text(
                        'Format waktu: HH:mm (contoh: 22:11)',
                        style: TextStyle(
                          color: Color(0xFF94A3B8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton.icon(
                      onPressed: _isGenerating ? null : _generateIQCImage,
                      icon: _isGenerating
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Rome.ivory,
                              ),
                            )
                          : const Icon(Icons.generating_tokens),
                      label: Text(
                        _isGenerating ? 'SEDANG MEMBUAT...' : 'BUAT SCREENSHOT',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Rome.gold,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 5,
                      ),
                    ),
                  ),
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEF4444).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFEF4444)),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.error_outline,
                            color: Color(0xFFEF4444),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),

            // API Endpoint
            GestureDetector(
              onTap: () {
                final apiUrl =
                    'https://api.deline.web.id/maker/iqc?text=${Uri.encodeComponent(_textController.text)}&chatTime=${Uri.encodeComponent(_chatTimeController.text)}&statusBarTime=${Uri.encodeComponent(_statusBarTimeController.text)}';
                _copyToClipboard(apiUrl);
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Rome.cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Rome.bronze),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.api, color: Color(0xFF60A5FA)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'API Endpoint',
                            style: TextStyle(
                              color: Rome.ivory,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'https://api.deline.web.id/maker/iqc',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.content_copy,
                      color: Color(0xFF94A3B8),
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Preview Section
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Rome.cardBg,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF1A1A1A),
                    blurRadius: 0,
                    offset: const Offset(3, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.preview, color: Color(0xFF60A5FA)),
                      SizedBox(width: 8),
                      Text(
                        'Hasil Screenshot',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Rome.ivory,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (_generatedImage != null)
                    Container(
                      width: double.infinity,
                      constraints: const BoxConstraints(maxHeight: 600),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF1A1A1A),
                            blurRadius: 0,
                            offset: const Offset(3, 3),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          _generatedImage!,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              height: 300,
                              decoration: BoxDecoration(
                                color: Rome.cardBg,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.broken_image,
                                    size: 64,
                                    color: Color(0xFFEF4444),
                                  ),
                                  SizedBox(height: 16),
                                  Text(
                                    'Gagal memuat gambar',
                                    style: TextStyle(color: Colors.white70),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    )
                  else
                    Container(
                      height: 300,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Rome.cardBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Rome.bronze, width: 2),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.screenshot_monitor,
                            size: 80,
                            color: Rome.bronze.withOpacity(0.5),
                          ),
                          const SizedBox(height: 20),
                          const Text(
                            'Belum ada screenshot',
                            style: TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              'Masukkan teks dan waktu, lalu klik "Buat Screenshot"',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFF64748B),
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (_generatedImage != null) ...[
                    const SizedBox(height: 20),
                    // Download button di bawah preview juga
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton.icon(
                        onPressed: _isSaving ? null : _saveImage,
                        icon: _isSaving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.save_alt_rounded),
                        label: Text(
                          _isSaving ? 'MENYIMPAN...' : 'SIMPAN KE GALERI',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF10B981),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Ukuran: ${(_generatedImage!.lengthInBytes / 1024).toStringAsFixed(1)} KB',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                        Text(
                          'Dibuat: ${DateFormat('HH:mm:ss').format(DateTime.now())}',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Quick examples
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Rome.cardBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Contoh Cepat:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Rome.ivory,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildExampleChip('Malam minggu yuk', '20:00', '20:05'),
                      _buildExampleChip(
                        'Besok ketemuan dimana?',
                        '15:30',
                        '15:45',
                      ),
                      _buildExampleChip('Lagi apa?', '21:15', '21:20'),
                      _buildExampleChip('Udah makan belum?', '12:00', '12:10'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildExampleChip(String text, String chatTime, String statusBarTime) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _textController.text = text;
          _chatTimeController.text = chatTime;
          _statusBarTimeController.text = statusBarTime;
        });
        _showSuccess('Contoh diterapkan');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Rome.bronze,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Rome.bronze),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text.length > 20 ? '${text.substring(0, 20)}...' : text,
              style: const TextStyle(color: Rome.ivory, fontSize: 12),
            ),
            const SizedBox(height: 4),
            Text(
              '$chatTime | $statusBarTime',
              style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}
