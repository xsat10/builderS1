import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/news_provider.dart';
import '../models/news_item.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/scroll_clearance.dart';

class NewsManagementScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const NewsManagementScreen({super.key, this.onBack});

  static Future<void> showCreateDialog(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (ctx) => _NewsFormDialog(
        onSave: (data) async {
          final ok = await context.read<NewsProvider>().addNews(data);
          if (ok && ctx.mounted) Navigator.of(ctx).pop();
        },
      ),
    );
  }

  @override
  State<NewsManagementScreen> createState() => _NewsManagementScreenState();
}

class _NewsManagementScreenState extends State<NewsManagementScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NewsProvider>().loadNews();
    });
  }

  void _showForm({NewsItem? item}) {
    showDialog(
      context: context,
      builder: (_) => _NewsFormDialog(
        item: item,
        onSave: (data) async {
          final provider = context.read<NewsProvider>();
          bool ok;
          if (item == null) {
            ok = await provider.addNews(data);
          } else {
            ok = await provider.editNews(item.id, data);
          }
          if (ok && mounted) Navigator.of(context).pop();
        },
      ),
    );
  }

  Future<void> _deleteNews(NewsItem item) async {
    final confirmed = await NeoDialog.confirm(
      context,
      title: 'Delete News',
      message: 'Delete "${item.title}"?',
    );
    if (confirmed == true && mounted) {
      await context.read<NewsProvider>().removeNews(item.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SceneBackground(
      theme: FeatureConfig.manage,
      screenIndex: FeatureConfig.newsIndex,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                NeoSpacing.lg,
                NeoSpacing.xs,
                NeoSpacing.lg,
                0,
              ),
              child: Row(
                children: [
                  if (widget.onBack != null)
                    NeoBackButton(onTap: widget.onBack),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                NeoSpacing.lg,
                NeoSpacing.xs,
                NeoSpacing.lg,
                NeoSpacing.sm,
              ),
              child: Row(
                children: [
                  Icon(Icons.campaign_rounded, color: NeoColors.gold, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'MANAGE ANNOUNCEMENTS',
                    style: GoogleFonts.cinzel(
                      textStyle: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.5,
                        color: NeoColors.marble,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [NeoColors.goldDeep.withValues(alpha: 102 / 255), Colors.transparent],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () => context.read<NewsProvider>().loadNews(),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: NeoColors.yellow,
                        border: Border.all(color: NeoColors.border, width: 2),
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                      ),
                      child: const Icon(
                        Icons.refresh,
                        color: NeoColors.black,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Consumer<NewsProvider>(
                builder: (_, provider, _) {
                  if (provider.loading) {
                    return const Center(
                      child: NeoBlockLoader(blockSize: 8, c0: NeoColors.yellow, c1: NeoColors.black),
                    );
                  }
                  if (provider.news.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.article_outlined,
                            size: 64,
                            color: NeoColors.grey,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No announcements yet',
                            style: TextStyle(
                              color: NeoColors.secondaryText,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 16),
                          NeoButton(
                            label: 'CREATE FIRST',
                            onPressed: () => _showForm(),
                          ),
                        ],
                      ),
                    );
                  }
                  return ListView.separated(
                    padding: EdgeInsets.fromLTRB(
                      NeoSpacing.lg,
                      0,
                      NeoSpacing.lg,
                      ScrollClearance.bottomNav(context),
                    ),
                    itemCount: provider.news.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final n = provider.news[i];
                      return _NewsCard(
                        item: n,
                        onEdit: () => _showForm(item: n),
                        onDelete: () => _deleteNews(n),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NewsCard extends StatelessWidget {
  final NewsItem item;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _NewsCard({
    required this.item,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final imageUrl =
        (item.backgroundImageUrl ?? item.imageUrl) ?? '';
    final hasImage = imageUrl.isNotEmpty;

    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(NeoRadius.xl),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0x22FFFFFF), Color(0x0AFFFFFF)],
        ),
        border: Border.all(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1.2),
        boxShadow: NeoShadows.mdD(
          Theme.of(context).brightness == Brightness.dark,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (hasImage) ...[
            SizedBox(
              height: 88,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [NeoColors.gold, NeoColors.goldDeep],
                        ),
                      ),
                      child: Icon(
                        Icons.campaign_rounded,
                        color: NeoColors.darkCard,
                        size: 28,
                      ),
                    ),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Color(0x990B0D1F),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 12,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0x660B0D1F),
                        border: Border.all(
                          color: NeoColors.gold.withValues(alpha: 102 / 255),
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'PENGUMUMAN',
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                          color: NeoColors.gold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),
          ],
          Padding(
            padding: EdgeInsets.fromLTRB(16, hasImage ? 8 : 16, 8, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [NeoColors.gold, NeoColors.goldDeep],
                        ),
                        borderRadius: BorderRadius.circular(NeoRadius.lg),
                      ),
                      child: Icon(
                        Icons.campaign_rounded,
                        color: NeoColors.darkCard,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        item.title,
                        style: TextStyle(
                          color: NeoColors.primaryText,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          height: 1.2,
                        ),
                      ),
                    ),
                    PopupMenuButton<String>(
                      icon: Icon(
                        Icons.more_vert,
                        color: NeoColors.secondaryText,
                      ),
                      color: NeoColors.surfaceElevated,
                      onSelected: (v) {
                        if (v == 'edit') onEdit();
                        if (v == 'delete') onDelete();
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(
                          value: 'edit',
                          child: Row(
                            children: [
                              Icon(Icons.edit, color: NeoColors.yellow, size: 18),
                              SizedBox(width: 8),
                              Text(
                                'Edit',
                                style: TextStyle(color: NeoColors.primaryText),
                              ),
                            ],
                          ),
                        ),
                        const PopupMenuItem(
                          value: 'delete',
                          child: Row(
                            children: [
                              Icon(Icons.delete, color: Colors.redAccent, size: 18),
                              SizedBox(width: 8),
                              Text(
                                'Delete',
                                style: TextStyle(color: Colors.redAccent),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                if (item.description.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    item.description,
                    style: TextStyle(
                      color: NeoColors.secondaryText,
                      fontSize: 13,
                      height: 1.4,
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (item.showButton &&
                        item.buttonText != null &&
                        item.buttonText!.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: NeoColors.gold.withValues(alpha: 34 / 255),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.arrow_forward_rounded,
                              color: NeoColors.gold,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              item.buttonText!,
                              style: TextStyle(
                                color: NeoColors.gold,
                                fontWeight: FontWeight.w800,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ] else ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: NeoColors.grey.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'Button hidden',
                          style: TextStyle(
                            color: NeoColors.grey,
                            fontSize: 10,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ],
                    const Spacer(),
                    Icon(
                      Icons.tune_rounded,
                      color: NeoColors.gold,
                      size: 16,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NewsFormDialog extends StatefulWidget {
  final NewsItem? item;
  final Future<void> Function(NewsItem) onSave;
  const _NewsFormDialog({this.item, required this.onSave});

  @override
  State<_NewsFormDialog> createState() => _NewsFormDialogState();
}

class _NewsFormDialogState extends State<_NewsFormDialog> {
  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  late TextEditingController _bgCtrl;
  late TextEditingController _btnTextCtrl;
  late TextEditingController _btnUrlCtrl;
  late bool _showBtn;
  bool _saving = false;
  bool _uploading = false;
  String? _uploadError;

  @override
  void initState() {
    super.initState();
    final i = widget.item;
    _titleCtrl = TextEditingController(text: i?.title ?? '');
    _descCtrl = TextEditingController(text: i?.description ?? '');
    _bgCtrl = TextEditingController(text: i?.backgroundImageUrl ?? '');
    _btnTextCtrl = TextEditingController(text: i?.buttonText ?? '');
    _btnUrlCtrl = TextEditingController(text: i?.buttonUrl ?? '');
    _showBtn = i?.showButton ?? false;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _bgCtrl.dispose();
    _btnTextCtrl.dispose();
    _btnUrlCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickFromGallery() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (file == null || !mounted) return;
    setState(() {
      _uploading = true;
      _uploadError = null;
    });
    final result = await ApiService().uploadImage(
      file.path,
      filename: file.name,
    );
    if (!mounted) return;
    setState(() => _uploading = false);
    if (result['success'] == true) {
      _bgCtrl.text = (result['data']?['url'] ?? '').toString();
    } else {
      _uploadError = result['error']?['message'] ?? 'Upload gagal';
    }
  }

  void _submit() async {
    if (_titleCtrl.text.trim().isEmpty) return;
    setState(() => _saving = true);

    var closed = false;
    await widget.onSave(
      NewsItem(
        id: widget.item?.id ?? '',
        title: _titleCtrl.text.trim(),
        description: _descCtrl.text.trim(),
        backgroundImageUrl: _bgCtrl.text.trim().isEmpty
            ? null
            : _bgCtrl.text.trim(),
        buttonText: _showBtn ? _btnTextCtrl.text.trim() : null,
        buttonUrl: _showBtn ? _btnUrlCtrl.text.trim() : null,
        showButton: _showBtn,
        sortOrder: widget.item?.sortOrder ?? 0,
      ),
    );
    if (mounted) closed = !mounted;
    if (!closed && mounted) setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    final maxDialogHeight =
        MediaQuery.sizeOf(context).height -
        MediaQuery.viewInsetsOf(context).bottom -
        60;
    final isEdit = widget.item != null;
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Container(
        clipBehavior: Clip.antiAlias,
        constraints: BoxConstraints(maxHeight: maxDialogHeight),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(NeoRadius.xl),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1C1B2E), Color(0xFF12101F)],
          ),
          border: Border.all(color: NeoColors.gold.withValues(alpha: 102 / 255), width: 1.2),
          boxShadow: const [
            BoxShadow(color: Color(0x66000000), blurRadius: 40, offset: Offset(0, 16)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 18, 12, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 260),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Expanded(child: _GoldLine()),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Icon(
                            Icons.campaign_rounded,
                            color: NeoColors.gold,
                            size: 16,
                          ),
                        ),
                        const Expanded(child: _GoldLine()),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [NeoColors.gold, NeoColors.goldDeep],
                          ),
                          borderRadius: BorderRadius.circular(NeoRadius.lg),
                        ),
                        child: Icon(
                          Icons.campaign_rounded,
                          color: NeoColors.darkCard,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isEdit ? 'EDIT PENGUMUMAN' : 'PENGUMUMAN BARU',
                              style: GoogleFonts.cinzel(
                                textStyle: TextStyle(
                                  color: NeoColors.marble,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              'Audentes Fortuna Iuvat',
                              style: TextStyle(
                                color: NeoColors.marble.withValues(alpha: 153 / 255),
                                fontSize: 10,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: Icon(
                          Icons.close,
                          color: NeoColors.gold,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _Field(label: 'Judul', controller: _titleCtrl),
                    const SizedBox(height: 14),
                    _Field(
                      label: 'Deskripsi',
                      controller: _descCtrl,
                      maxLines: 3,
                    ),
                    const SizedBox(height: 18),
                    _SectionLabel('GAMBAR BACKGROUND'),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        if (_uploading)
                          const NeoBlockLoader(blockSize: 6, c0: NeoColors.yellow, c1: NeoColors.black)
                        else
                          NeoButton(
                            label: 'PILIH DARI GALERI',
                            onPressed: _pickFromGallery,
                            icon: Icons.photo_library_outlined,
                          ),
                        const Spacer(),
                        if (_bgCtrl.text.trim().isNotEmpty)
                          TextButton(
                            onPressed: () => setState(() => _bgCtrl.clear()),
                            child: const Text(
                              'Hapus',
                              style: TextStyle(color: NeoColors.pink, fontWeight: FontWeight.w700, fontSize: 12),
                            ),
                          ),
                      ],
                    ),
                    if (_bgCtrl.text.trim().isNotEmpty) ...[
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(NeoRadius.lg),
                        child: SizedBox(
                          height: 110,
                          width: double.infinity,
                          child: Image.network(
                            _bgCtrl.text.trim(),
                            fit: BoxFit.cover,
                            errorBuilder: (_, _, _) => Container(
                              color: NeoColors.grey.withValues(alpha: 0.3),
                              child: const Center(
                                child: Icon(
                                  Icons.image_not_supported_outlined,
                                  color: NeoColors.grey,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    _Field(
                      label: 'Atau URL gambar (opsional)',
                      controller: _bgCtrl,
                    ),
                    if (_uploadError != null) ...[
                      const SizedBox(height: 8),
                      Text(
                        _uploadError!,
                        style: const TextStyle(
                          color: NeoColors.pink,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    const Divider(color: Color(0x33FFFFFF), height: 1),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: NeoColors.gold.withValues(alpha: 16 / 255),
                        borderRadius: BorderRadius.circular(NeoRadius.lg),
                        border: Border.all(
                          color: NeoColors.gold.withValues(alpha: 51 / 255),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.touch_app_rounded,
                            color: NeoColors.gold,
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'Tampilkan Tombol',
                              style: TextStyle(
                                color: NeoColors.primaryText,
                                fontWeight: FontWeight.w800,
                                fontSize: 13,
                              ),
                            ),
                          ),
                          Switch(
                            value: _showBtn,
                            onChanged: (v) => setState(() => _showBtn = v),
                            activeThumbColor: NeoColors.yellow,
                            activeTrackColor: NeoColors.gold.withValues(alpha: 68 / 255),
                          ),
                        ],
                      ),
                    ),
                    if (_showBtn) ...[
                      const SizedBox(height: 14),
                      _Field(label: 'Teks Tombol', controller: _btnTextCtrl),
                      const SizedBox(height: 14),
                      _Field(label: 'URL Tombol', controller: _btnUrlCtrl),
                    ],
                  ],
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 18),
              decoration: const BoxDecoration(
                color: Color(0x0AFFFFFF),
                border: Border(top: BorderSide(color: Color(0x22FFFFFF))),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text(
                      'BATAL',
                      style: TextStyle(
                        color: NeoColors.secondaryText,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  NeoButton(
                    label: isEdit ? 'SIMPAN' : 'BUAT',
                    loading: _saving,
                    onPressed: _submit,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 12,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [NeoColors.gold, NeoColors.goldDeep],
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: NeoColors.gold,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

class _GoldLine extends StatelessWidget {
  const _GoldLine();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.transparent, NeoColors.goldDeep.withValues(alpha: 119 / 255), Colors.transparent],
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final int maxLines;
  const _Field({
    required this.label,
    required this.controller,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: NeoColors.gold,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          maxLines: maxLines,
          style: TextStyle(color: NeoColors.primaryText, fontSize: 14),
          cursorColor: NeoColors.gold,
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0x0AFFFFFF),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(NeoRadius.lg),
              borderSide: const BorderSide(color: Color(0x22FFFFFF)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(NeoRadius.lg),
              borderSide: BorderSide(color: NeoColors.gold, width: 1.4),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
          ),
        ),
      ],
    );
  }
}
