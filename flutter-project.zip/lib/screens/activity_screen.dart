import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/device_provider.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_card.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/scroll_clearance.dart';

class ActivityScreen extends StatefulWidget {
  const ActivityScreen({super.key});

  @override
  State<ActivityScreen> createState() => _ActivityScreenState();
}

class _ActivityScreenState extends State<ActivityScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DeviceProvider>().loadMyActivities();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SceneBackground(
      theme: FeatureConfig.activity,
      screenIndex: 2,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: Consumer<DeviceProvider>(
              builder: (_, dp, _) {
                if (dp.activities.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.history_outlined, size: 48, color: isDark ? NeoColors.surfaceElevated : NeoColors.grey),
                        const SizedBox(height: 16),
                        Text('No activity yet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: NeoColors.secondaryText)),
                        const SizedBox(height: 4),
                        Text('Actions will appear here in real-time', style: TextStyle(fontSize: 13, color: isDark ? NeoColors.secondaryText : NeoColors.grey)),
                      ],
                    ),
                  );
                }
                return ListView.builder(
                  padding: EdgeInsets.fromLTRB(NeoSpacing.lg, NeoSpacing.sm, NeoSpacing.lg, ScrollClearance.bottomNav(context)),
                  itemCount: dp.activities.length,
                  itemBuilder: (ctx, i) {
                    final a = dp.activities[i];
                    final isSuccess = a.status == 'success';
                    return Padding(
                      padding: const EdgeInsets.only(bottom: NeoSpacing.sm),
                      child: NeoCard(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: isSuccess
                                    ? NeoColors.green.withValues(alpha: 0.18)
                                    : NeoColors.pink.withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(NeoRadius.sm),
                              ),
                              child: Icon(
                                isSuccess ? Icons.check_circle_outlined : Icons.error_outline,
                                size: 18, color: isSuccess ? NeoColors.green : NeoColors.pink,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(a.actionLabel, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                                  const SizedBox(height: 2),
                                  Text(a.message, style: TextStyle(fontSize: 11, color: isDark ? NeoColors.secondaryText : NeoColors.grey)),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(_timeAgo(a.createdAt), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: isDark ? NeoColors.secondaryText : NeoColors.grey)),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }

  String _timeAgo(String iso) {
    try {
      final dt = DateTime.parse(iso);
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 1) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m';
      if (diff.inHours < 24) return '${diff.inHours}h';
      return '${diff.inDays}d';
    } catch (_) {
      return iso;
    }
  }
}
