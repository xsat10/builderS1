import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_role_ring.dart';
import '../widgets/neo_royal_frame.dart';
import '../widgets/scene_background.dart';

class RoleRingPage extends StatelessWidget {
  const RoleRingPage({super.key});

  static const Color _gold = Color(0xFFE5C365);
  static const Color _goldDeep = Color(0xFFBB8C2E);
  static const Color _ivory = Color(0xFFFBF5E6);
  static const Color _purpleDeep = Color(0xFF180E26);
  static const Color _hairline = Color(0x66E5C365);

  static const List<_RoleInfo> _roles = [
    _RoleInfo(
      role: 'member',
      numeral: 'I · MILES',
      title: 'MEMBER',
      subtitle: 'PRAETORIAN RENDAH',
      color: Color(0xFFFF6B8A),
      capabilities: [
        'Pairing & kontrol device sendiri',
        'Akses Tools lengkap',
        'Pantau aktivitas & limit sendiri',
        'WhatsApp: scan bug (tanpa ban & protected)',
      ],
    ),
    _RoleInfo(
      role: 'vip',
      numeral: 'II · EVOCATVS',
      title: 'VIP',
      subtitle: 'PRAETORIAN PILIHAN',
      color: Color(0xFFFFD700),
      capabilities: [
        'Semua milik Member',
        'Ban nomor/grup WhatsApp',
        'Lihat mode Protected',
        'Lihat daftar member',
      ],
    ),
    _RoleInfo(
      role: 'reseller',
      numeral: 'III · MERCATOR',
      title: 'RESELLER',
      subtitle: 'PEDAGANG JABATAN',
      color: Color(0xFF36C5F0),
      capabilities: [
        'Buat akun Member & VIP',
        'Set limit sender, edit, hapus & blokir akun buatannya',
        'Ban WhatsApp + kelola Protected',
        'Pairing code untuk akun buatannya',
      ],
    ),
    _RoleInfo(
      role: 'moderator',
      numeral: 'IV · PRAEFECTVS',
      title: 'MODERATOR',
      subtitle: 'PENGUASA MENENGAH',
      color: Color(0xFF3DD3A5),
      capabilities: [
        'Buat akun Reseller, VIP & Member',
        'Edit user yang dibuatnya & bawahan reseller',
        'Story priority paling pertama muncul di nova stories',
        'Hapus / blokir / aktifkan akun',
        'Atur limit sender user bawahan',
        'Ban WhatsApp + kelola Protected',
      ],
    ),
    _RoleInfo(
      role: 'partner',
      numeral: 'V · CONSVL',
      title: 'PARTNER',
      subtitle: 'PERWAKILAN SENAT',
      color: Color(0xFFFF9F43),
      capabilities: [
        'Buat akun Reseller & Moderator',
        'Sama seperti Moderator',
        'Kelola semua user di bawahnya',
        'Ban WhatsApp + kelola Protected',
      ],
    ),
    _RoleInfo(
      role: 'developer',
      numeral: 'VI · CAESAR',
      title: 'DEVELOPER',
      subtitle: 'KAISAR NOVACORE',
      color: Color(0xFF9B6BFF),
      capabilities: [
        'Seluruh kekuasaan tanpa batas',
        'Kelola semua role, limit & fitur sistem',
        'Manage, news, sender, pairing global',
        'Api ungu paling menyala di altar ring',
      ],
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SceneBackground(
        theme: FeatureConfig.manage,
        screenIndex: FeatureConfig.manageIndex,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: NeoSpacing.lg,
                  vertical: NeoSpacing.sm,
                ),
                child: Row(
                  children: [
                    NeoBackButton(onTap: () => Navigator.of(context).pop()),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ROLE & RING',
                          style: GoogleFonts.cinzel(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 3,
                            color: _gold,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'HIERARCHIA CIRCULI NOVACORE',
                          style: GoogleFonts.cinzel(
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 2,
                            color: _goldDeep,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.fromLTRB(
                    NeoSpacing.lg,
                    NeoSpacing.sm,
                    NeoSpacing.lg,
                    40,
                  ),
                  children: [
                    _previewStrip(),
                    const SizedBox(height: 18),
                    _romanCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'RING MANYALA',
                            style: GoogleFonts.cinzel(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2.5,
                              color: _gold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Cincin mengikuti warna role dan menyala berdenyut. Semakin tinggi jabatan, semakin mewah ornamennya — Developer (Kaisar) terpancar paling terang dengan api ungu yang berputar. Akun gratis tidak memakai cincin sama sekali.',
                            style: TextStyle(
                              fontSize: 12,
                              height: 1.5,
                              color: Color(0xB3FBF5E6),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    for (final r in _roles) ...[
                      _roleCard(r),
                      const SizedBox(height: 14),
                    ],
                    _romanCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'AKUN GRATIS — POLOSAN',
                            style: GoogleFonts.cinzel(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2.5,
                              color: _gold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Akun free access tidak memiliki role resmi: tanpa badge, tanpa cincin, avatar tampil polos. Masa aktifnya singkat (±24 jam) dan dibuat langsung oleh Developer.',
                            style: TextStyle(
                              fontSize: 12,
                              height: 1.5,
                              color: Color(0xB3FBF5E6),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _previewStrip() {
    return _romanCard(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          for (final r in _roles)
            Column(
              children: [
                NeoRoleRing(role: r.role, size: 52, padding: const EdgeInsets.all(4)),
                const SizedBox(height: 6),
                Text(
                  r.numeral.split(' ').first,
                  style: GoogleFonts.cinzel(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: r.color,
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _roleCard(_RoleInfo r) {
    return RoyalFrame(
      radius: 18,
      cornerLength: 16,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _purpleDeep.withValues(alpha: 0.9),
              const Color(0xFF2B1A3C).withValues(alpha: 0.75),
            ],
          ),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                NeoRoleRing(
                  role: r.role,
                  size: 64,
                  padding: const EdgeInsets.all(4),
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [r.color, r.color.withValues(alpha: 0.55)],
                      ),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.4),
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      NeoColors.roleIcon[r.role] ?? Icons.military_tech,
                      size: 26,
                      color: const Color(0xFF2A1E00),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        r.numeral,
                        style: GoogleFonts.cinzel(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                          color: r.color,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        r.title,
                        style: GoogleFonts.cinzel(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                          color: _ivory,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        r.subtitle,
                        style: GoogleFonts.cinzel(
                          fontSize: 9,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 2,
                          color: _goldDeep,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              height: 1,
              color: _hairline,
            ),
            const SizedBox(height: 12),
            for (final c in r.capabilities)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '❧',
                      style: TextStyle(
                        fontSize: 11,
                        color: _gold.withValues(alpha: 0.85),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        c,
                        style: const TextStyle(
                          fontSize: 11.5,
                          height: 1.35,
                          color: Color(0xD9FBF5E6),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _romanCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF1A1126).withValues(alpha: 0.92),
            const Color(0xFF241733).withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _hairline, width: 1),
      ),
      child: child,
    );
  }
}

class _RoleInfo {
  final String role;
  final String numeral;
  final String title;
  final String subtitle;
  final Color color;
  final List<String> capabilities;

  const _RoleInfo({
    required this.role,
    required this.numeral,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.capabilities,
  });
}