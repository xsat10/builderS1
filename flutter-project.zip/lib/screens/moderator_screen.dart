import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/neo_user_tree.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_edit_account_dialog.dart';
import '../widgets/neo_reset_password_dialog.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/scroll_clearance.dart';
import '../providers/auth_provider.dart';
import '../providers/app_refresh_provider.dart';
import '../services/api_service.dart';

class ModeratorScreen extends StatefulWidget {
  final VoidCallback? onBack;

  const ModeratorScreen({super.key, this.onBack});

  @override
  State<ModeratorScreen> createState() => _ModeratorScreenState();
}

class _ModeratorScreenState extends State<ModeratorScreen> {
  static const Set<String> _modRoles = {'reseller', 'vip', 'member'};
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;
  late AppRefreshProvider _refresh;
  int _lastRevision = -1;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _refresh = context.read<AppRefreshProvider>();
    _lastRevision = _refresh.revision;
    _refresh.addListener(_onRefreshChanged);
    _load();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _refresh.removeListener(_onRefreshChanged);
    super.dispose();
  }

  void _startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) _load(silent: true);
    });
  }

  void _onRefreshChanged() {
    if (!mounted) return;
    final rev = _refresh.revision;
    if (rev != _lastRevision) {
      _lastRevision = rev;
      _load();
    }
  }

  Color _accentFor(Map<String, dynamic> u) {
    switch ((u['role'] ?? 'member').toString()) {
      case 'reseller':
        return NeoColors.reseller;
      case 'vip':
        return NeoColors.vip;
      case 'moderator':
        return NeoColors.moderator;
      default:
        return NeoColors.member;
    }
  }

  Future<void> _load({bool silent = false}) async {
    if (!mounted) return;
    if (!silent || _users.isEmpty) setState(() => _loading = true);
    final r = await ApiService().getUsers();
    if (!mounted) return;
    _users = List<Map<String, dynamic>>.from(
      r['data'] as List? ?? [],
    ).where((u) => _modRoles.contains((u['role'] ?? '').toString())).toList();
    if (mounted) setState(() => _loading = false);
  }

  bool _canDelete(Map<String, dynamic> u) {
    final auth = context.read<AuthProvider>();
    return (u['parent_id']?.toString() ?? '') ==
        (auth.user?.id.toString() ?? '');
  }

  Future<void> _deleteUser(Map<String, dynamic> u) async {
    final confirmed = await NeoDialog.show(
      context: context,
      title: 'HAPUS USER?',
      message:
          'Hapus user "${u['username'] ?? ''}"?\n\nAkun ini tidak bisa login lagi setelah dihapus. Tindakan ini tidak bisa dibatalkan.',
      cancelLabel: 'BATAL',
      confirmLabel: 'HAPUS',
      confirmColor: NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    final api = ApiService();
    final result = await api.deleteUser((u['id'] ?? '').toString());
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? 'User dihapus'
              : (result['error']?['message'] ?? 'Gagal menghapus user'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
    if (ok) _load();
  }

  Future<void> _editUser(Map<String, dynamic> u) async {
    final rawExpiry = u['expires_at']?.toString();
    final name = _displayName(u);
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => NeoEditAccountDialog(
        title: 'EDIT USER',
        accent: _accentFor(u),
        initialName: name,
        lockedUsername: (u['username'] ?? '').toString(),
        initialExpiry: rawExpiry != null && rawExpiry.isNotEmpty
            ? DateTime.tryParse(rawExpiry)
            : null,
        initialSenderLimit: u['sender_limit'] is num
            ? (u['sender_limit'] as num).toInt()
            : null,
        onSave: (editedName, expiresAt, senderLimit) {
          final body = <String, dynamic>{
            'name': editedName,
            'expires_at': expiresAt,
          };
          if (senderLimit != null) body['sender_limit'] = senderLimit;
          return ApiService().updateUser((u['id'] ?? '').toString(), body);
        },
      ),
    );
    if (saved == true) _load();
  }

  String _displayName(Map<String, dynamic> u) {
    final name = (u['name'] ?? '').toString().trim();
    if (name.isNotEmpty) return name;
    final username = (u['username'] ?? '').toString().trim();
    if (username.isNotEmpty) return username;
    final prefix = (u['email'] ?? '').toString().split('@').first.trim();
    return prefix.isEmpty ? 'User' : prefix;
  }

  Future<void> _toggleDisable(Map<String, dynamic> u) async {
    final isDisabled = (u['status'] ?? 'active').toString() == 'disabled';
    final confirmed = await NeoDialog.show(
      context: context,
      title: isDisabled ? 'Aktifkan akun?' : 'Nonaktifkan akun?',
      message:
          '${isDisabled ? 'Aktifkan' : 'Nonaktifkan'} user "${u['username'] ?? ''}"?'
          '${isDisabled ? '' : ' Akun ini tidak bisa login sementara.'}',
      cancelLabel: 'TIDAK',
      confirmLabel: 'YA',
      confirmColor: isDisabled ? NeoColors.green : NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    try {
      final res = await ApiService().disableUser((u['id'] ?? '').toString());
      if (!mounted) return;
      final ok = res['success'] == true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text(
            ok
                ? (isDisabled
                      ? 'Akun berhasil diaktifkan.'
                      : 'Akun berhasil dinonaktifkan.')
                : (res['error']?['message']?.toString() ??
                      'Gagal mengubah status akun.'),
          ),
          backgroundColor: ok ? NeoColors.green : NeoColors.pink,
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal mengubah status akun.'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
    _load();
  }

  Future<void> _resetPassword(Map<String, dynamic> u) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => NeoResetPasswordDialog(
        title: 'RESET PASSWORD',
        accent: _accentFor(u),
        username: (u['username'] ?? u['email'] ?? '').toString(),
        onReset: (newPassword) => ApiService().resetUserPassword(
          (u['id'] ?? '').toString(),
          newPassword,
        ),
      ),
    );
    if (saved == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Password berhasil direset'),
          backgroundColor: NeoColors.green,
        ),
      );
      _load();
    }
  }

  Future<void> _banUser(Map<String, dynamic> u) async {
    final banned = (u['banned_at']?.toString() ?? '').isNotEmpty;
    final result = await ApiService().banUser((u['id'] ?? '').toString());
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? (banned ? 'Ban dibuka' : 'User di-ban')
              : (result['error']?['message']?.toString() ??
                    'Gagal mengubah status ban'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
    if (ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return SceneBackground(
      theme: FeatureConfig.moderator,
      screenIndex: FeatureConfig.moderatorIndex,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const NeoAppHeader(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
              child: Row(
                children: [
                  if (widget.onBack != null)
                    NeoBackButton(onTap: widget.onBack),
                  const Spacer(),
                  GestureDetector(
                    onTap: _load,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: NeoColors.yellow,
                        border: Border.all(color: NeoColors.border, width: 2),
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                      ),
                      child: const Icon(
                        Icons.refresh,
                        color: NeoColors.black,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: NeoSpacing.sm),
            Expanded(
              child: ListView(
                padding: EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.lg,
                  NeoSpacing.lg,
                  ScrollClearance.bottomNav(context),
                ),
                children: [
                  NeoUserTree(
                    users: _users,
                    accent: NeoColors.yellow,
                    loading: _loading,
                    canDelete: _canDelete,
                    onEdit: _editUser,
                    onReset: _resetPassword,
                    onBan: _banUser,
                    onToggle: _toggleDisable,
                    onDelete: _deleteUser,
                    emptyWidget: Padding(
                      padding: const EdgeInsets.all(NeoSpacing.xxl),
                      child: Center(
                        child: Text(
                          'Belum ada user',
                          style: TextStyle(
                            fontSize: 13,
                            color: isDark
                                ? NeoColors.secondaryText
                                : NeoColors.grey,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
