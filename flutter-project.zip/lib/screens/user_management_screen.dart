import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/scene_background.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_back_button.dart';
import '../widgets/neo_edit_account_dialog.dart';
import '../widgets/neo_reset_password_dialog.dart';
import '../widgets/neo_dialog.dart';
import '../widgets/neo_role_picker_dialog.dart';
import '../widgets/neo_block_loader.dart';
import '../providers/auth_provider.dart';
import '../providers/app_refresh_provider.dart';
import '../services/api_service.dart';
import '../widgets/scroll_clearance.dart';

class UserManagementScreen extends StatefulWidget {
  final VoidCallback? onBack;

  /// Roles yang boleh tampil pada daftar user. Kosong/null berarti pakai
  /// default developer (partner/reseller/member). Server /api/users sudah
  /// membatasi hasil sesuai hierarchy, jadi list otomatis hanya user buatan
  /// account yang sedang login.
  final List<String>? roleFilter;

  const UserManagementScreen({super.key, this.onBack, this.roleFilter});

  @override
  State<UserManagementScreen> createState() => _UserManagementScreenState();
}

class _UserManagementScreenState extends State<UserManagementScreen> {
  List<Map<String, dynamic>> _users = [];
  bool _loading = true;
  late AppRefreshProvider _refresh;
  int _lastRevision = -1;
  Timer? _refreshTimer;
  String _search = '';
  String _roleFilter = 'all';
  late List<String> _roleBase;

  List<String> get _filters => ['all', ..._roleBase];

  Set<String> get _visibleRoles => _roleBase.toSet();

  static const Map<String, List<String>> _rolesBelow = {
    'developer': ['partner', 'moderator', 'reseller', 'vip', 'member'],
    'partner': ['moderator', 'reseller', 'vip', 'member'],
    'moderator': ['reseller', 'vip', 'member'],
    'reseller': ['vip', 'member'],
    'vip': ['member'],
  };

  List<String> _rolesForRole(String role) =>
      _rolesBelow[role] ?? const ['member'];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final myRole =
        (context.read<AuthProvider>().user?.role ?? '').toString();
    _roleBase = widget.roleFilter ?? _rolesForRole(myRole);
  }

  @override
  void initState() {
    super.initState();
    _refresh = context.read<AppRefreshProvider>();
    _lastRevision = _refresh.revision;
    _refresh.addListener(_onRefreshChanged);
    _load();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _refresh.removeListener(_onRefreshChanged);
    super.dispose();
  }

  void _startAutoRefresh() {
    _refreshTimer?.cancel();
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) _load(silent: true);
    });
  }

  void _onRefreshChanged() {
    if (!mounted) return;
    final rev = _refresh.revision;
    if (rev != _lastRevision) {
      _lastRevision = rev;
      _load();
    }
  }

  Future<void> _load({bool silent = false}) async {
    if (!mounted) return;
    if (!silent || _users.isEmpty) setState(() => _loading = true);
    final api = ApiService();
    final result = await api.getUsers();
    if (!mounted) return;
    if (result['success'] == true) {
      _users = List<Map<String, dynamic>>.from(result['data'] as List? ?? [])
          .where((u) {
            final role = (u['role'] ?? '').toString();
            return _visibleRoles.contains(role);
          })
          .toList();
    }
    if (mounted) setState(() => _loading = false);
  }

  List<Map<String, dynamic>> get _filtered {
    var list = _users;
    if (_roleFilter != 'all') {
      list = list.where((u) => (u['role'] ?? '') == _roleFilter).toList();
    }
    if (_search.isNotEmpty) {
      final q = _search.toLowerCase();
      list = list.where((u) {
        final name = _displayName(u).toLowerCase();
        final username = (u['username'] ?? '').toString().toLowerCase();
        final email = (u['email'] ?? '').toString().toLowerCase();
        return name.contains(q) || username.contains(q) || email.contains(q);
      }).toList();
    }
    return list;
  }

  int _countRole(String role) =>
      _users.where((u) => (u['role'] ?? '') == role).length;
  int _countActive() =>
      _users.where((u) => (u['status'] ?? 'active') == 'active').length;

  Color _accentFor(String role) {
    switch (role) {
      case 'partner':
        return NeoColors.developer;
      case 'reseller':
        return NeoColors.reseller;
      case 'vip':
        return NeoColors.vip;
      case 'moderator':
        return NeoColors.moderator;
      default:
        return NeoColors.member;
    }
  }

  Future<void> _editUser(Map<String, dynamic> u) async {
    final role = (u['role'] ?? 'member').toString();
    final accent = _accentFor(role);
    final rawExpiry = u['expires_at']?.toString();
    final name = _displayName(u);
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => NeoEditAccountDialog(
        title: 'EDIT USER',
        accent: accent,
        initialName: name,
        lockedUsername: (u['username'] ?? '').toString(),
        initialExpiry: rawExpiry != null && rawExpiry.isNotEmpty
            ? DateTime.tryParse(rawExpiry)
            : null,
        initialSenderLimit: u['sender_limit'] is num
            ? (u['sender_limit'] as num).toInt()
            : null,
        onSave: (editedName, expiresAt, senderLimit) {
          final body = <String, dynamic>{
            'name': editedName,
            'expires_at': expiresAt,
          };
          if (senderLimit != null) body['sender_limit'] = senderLimit;
          return ApiService().updateUser((u['id'] ?? '').toString(), body);
        },
      ),
    );
    if (saved == true) _load();
  }

  String _displayName(Map<String, dynamic> u) {
    final name = (u['name'] ?? '').toString().trim();
    if (name.isNotEmpty) return name;
    final username = (u['username'] ?? '').toString().trim();
    if (username.isNotEmpty) return username;
    final email = (u['email'] ?? '').toString();
    final prefix = email.split('@').first.trim();
    return prefix.isEmpty ? 'User' : prefix;
  }

  Future<void> _changeRole(Map<String, dynamic> u) async {
    final currentRole = (u['role'] ?? 'member').toString();
    if (currentRole == 'developer') return;
    final auth = context.read<AuthProvider>();
    final myRole = auth.user?.role ?? '';
    final List<String> allowed;
    if (auth.isDeveloper) {
      allowed = ['partner', 'moderator', 'reseller', 'vip', 'member'];
    } else {
      switch (myRole) {
        case 'partner':
          allowed = ['moderator', 'reseller', 'vip', 'member'];
          break;
        case 'moderator':
          allowed = ['reseller', 'vip', 'member'];
          break;
        default:
          allowed = ['vip', 'member'];
      }
    }
    if (allowed.isEmpty) return;
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => NeoRolePickerDialog(
        initialRole: currentRole,
        roles: allowed,
        onSave: (role) =>
            ApiService().updateUser((u['id'] ?? '').toString(), {'role': role}),
      ),
    );
    if (saved == true) _load();
  }

  Future<void> _toggleDisable(Map<String, dynamic> u) async {
    final isDisabled = (u['status'] ?? 'active').toString() == 'disabled';
    final confirmed = await NeoDialog.show(
      context: context,
      title: isDisabled ? 'Aktifkan akun?' : 'Nonaktifkan akun?',
      message:
          '${isDisabled ? 'Aktifkan' : 'Nonaktifkan'} user "${_displayName(u)}"?'
          '${isDisabled ? '' : ' Akun ini tidak bisa login sementara.'}',
      cancelLabel: 'TIDAK',
      confirmLabel: 'YA',
      confirmColor: isDisabled ? NeoColors.green : NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    try {
      final res = await ApiService().disableUser((u['id'] ?? '').toString());
      if (!mounted) return;
      final ok = res['success'] == true;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text(
            ok
                ? (isDisabled
                      ? 'Akun berhasil diaktifkan.'
                      : 'Akun berhasil dinonaktifkan.')
                : (res['error']?['message']?.toString() ??
                      'Gagal mengubah status akun.'),
          ),
          backgroundColor: ok ? NeoColors.green : NeoColors.pink,
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal mengubah status akun.'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
    _load();
  }

  Future<void> _resetPassword(Map<String, dynamic> u) async {
    final role = (u['role'] ?? 'member').toString();
    final accent = _accentFor(role);
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => NeoResetPasswordDialog(
        title: 'RESET PASSWORD',
        accent: accent,
        username: (u['username'] ?? u['email'] ?? '').toString(),
        onReset: (newPassword) => ApiService().resetUserPassword(
          (u['id'] ?? '').toString(),
          newPassword,
        ),
      ),
    );
    if (saved == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Password berhasil direset'),
          backgroundColor: NeoColors.green,
        ),
      );
      _load();
    }
  }

  Future<void> _banUser(Map<String, dynamic> u) async {
    final banned = (u['banned_at']?.toString() ?? '').isNotEmpty;
    final name = _displayName(u);
    final confirmed = await NeoDialog.show(
      context: context,
      title: banned ? 'BUKA BAN?' : 'BAN USER?',
      message: banned
          ? 'Buka ban untuk "$name"?\n\nUser kembali bisa membuat story.'
          : 'Ban "$name"?\n\nUser diblokir untuk membuat story. Dialog "Akun anda telah di ban oleh <username>" akan muncul saat user mencoba membuat story.',
      cancelLabel: 'BATAL',
      confirmLabel: banned ? 'BUKA BAN' : 'BAN',
      confirmColor: banned ? NeoColors.green : NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    final result = await ApiService().banUser((u['id'] ?? '').toString());
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? (banned ? 'Ban dibuka' : 'User di-ban')
              : (result['error']?['message'] ?? 'Gagal mengubah status ban'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
    if (ok) _load();
  }

  bool _canDelete(Map<String, dynamic> u) {
    final auth = context.read<AuthProvider>();
    if (auth.isDeveloper) return true;
    return (u['parent_id']?.toString() ?? '') ==
        (auth.user?.id.toString() ?? '');
  }

  Future<void> _deleteUser(Map<String, dynamic> u) async {
    final confirmed = await NeoDialog.show(
      context: context,
      title: 'HAPUS USER?',
      message:
          'Hapus user "${_displayName(u)}"?\n\nAkun akan dihapus PERMANEN dari database (beserta device, sender, story & data terkait). Username bisa langsung dipakai untuk akun baru. Tindakan ini tidak bisa dibatalkan.',
      cancelLabel: 'BATAL',
      confirmLabel: 'HAPUS PERMANEN',
      confirmColor: NeoColors.pink,
    );
    if (confirmed != true || !mounted) return;
    final result = await ApiService().deleteUser((u['id'] ?? '').toString());
    if (!mounted) return;
    final ok = result['success'] == true;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
        content: Text(
          ok
              ? 'User dihapus'
              : (result['error']?['message'] ?? 'Gagal menghapus user'),
        ),
        backgroundColor: ok ? NeoColors.green : NeoColors.pink,
      ),
    );
    if (ok) _load();
  }

  void _showActions(Map<String, dynamic> u) {
    final role = (u['role'] ?? 'member').toString();
    final status = (u['status'] ?? 'active').toString();
    final auth = context.read<AuthProvider>();
    final isDev = auth.isDeveloper;
    final canDel = _canDelete(u);
    // Partner/Moderator/Reseller boleh set role akun yang DIBUAT-nya sendiri
    // (server sudah membolehkan bila target.parent_id === pembuat).
    final myRole = auth.user?.role ?? '';
    final canSetRole = isDev ||
        ((myRole == 'partner' || myRole == 'moderator' || myRole == 'reseller') &&
            (u['parent_id']?.toString() ?? '') == (auth.user?.id.toString() ?? ''));
    final notSelf = (u['id']?.toString() ?? '') != (auth.user?.id.toString() ?? '');

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (ctx) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: Container(
              padding: const EdgeInsets.fromLTRB(0, 8, 0, 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [NeoColors.darkBg.withValues(alpha: 240 / 255), Color(0xF0141628)],
                ),
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                border: Border(
                  top: BorderSide(color: NeoColors.gold.withValues(alpha: 68 / 255), width: 1),
                ),
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 36,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.20),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 4,
                      ),
                      child: Row(
                        children: [
                          _GlassAvatar(
                            initial: _displayName(u).isNotEmpty
                                ? _displayName(u)[0].toUpperCase()
                                : '?',
                            roleColor: NeoColors.roleColor(role),
                            size: 36,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _displayName(u),
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    color: NeoColors.primaryText,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  role.toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    color: NeoColors.roleColor(role),
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Divider(
                      height: 1,
                      color: Colors.white.withValues(alpha: 0.06),
                    ),
                    _ActionItem(
                      icon: Icons.edit_outlined,
                      label: 'Edit',
                      onTap: () {
                        Navigator.pop(ctx);
                        _editUser(u);
                      },
                    ),
                    if (canSetRole && role != 'developer' && notSelf)
                      _ActionItem(
                        icon: Icons.shield_outlined,
                        label: 'Set Role',
                        onTap: () {
                          Navigator.pop(ctx);
                          _changeRole(u);
                        },
                      ),
                    if ((isDev || myRole == 'partner' || myRole == 'moderator') &&
                        notSelf)
                      _ActionItem(
                        icon: Icons.gavel_outlined,
                        label: (u['banned_at']?.toString() ?? '').isNotEmpty
                            ? 'Buka Ban'
                            : 'Ban',
                        color: (u['banned_at']?.toString() ?? '').isNotEmpty
                            ? NeoColors.green
                            : NeoColors.pink,
                        onTap: () {
                          Navigator.pop(ctx);
                          _banUser(u);
                        },
                      ),
                    _ActionItem(
                      icon: Icons.lock_reset_outlined,
                      label: 'Reset Password',
                      onTap: () {
                        Navigator.pop(ctx);
                        _resetPassword(u);
                      },
                    ),
                    _ActionItem(
                      icon: status == 'disabled'
                          ? Icons.check_circle_outline
                          : Icons.block_outlined,
                      label: status == 'disabled' ? 'Aktifkan' : 'Nonaktifkan',
                      color: status == 'disabled'
                          ? NeoColors.green
                          : NeoColors.orange,
                      onTap: () {
                        Navigator.pop(ctx);
                        _toggleDisable(u);
                      },
                    ),
                    if (canDel)
                      _ActionItem(
                        icon: Icons.delete_outline,
                        label: 'Hapus',
                        color: NeoColors.pink,
                        onTap: () {
                          Navigator.pop(ctx);
                          _deleteUser(u);
                        },
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final totalCount = _users.length;
    final activeCount = _countActive();

    return DefaultTextStyle(
      style: const TextStyle(fontFamily: 'serif'),
      child: SceneBackground(
        theme: FeatureConfig.users,
        screenIndex: FeatureConfig.usersIndex,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const NeoAppHeader(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
                child: Row(
                  children: [
                    if (widget.onBack != null)
                      NeoBackButton(onTap: widget.onBack),
                    const Spacer(),
                    GestureDetector(
                      onTap: _load,
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.06),
                          border: Border.all(
                            color: const Color(0x33FFFFFF),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          Icons.refresh,
                          color: _loading
                              ? NeoColors.gold
                              : NeoColors.secondaryText,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'USERS',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: NeoColors.primaryText,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$totalCount users · $activeCount active · ${_countRole('reseller')} resellers',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: NeoColors.secondaryText,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // Search
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: NeoSpacing.lg),
                child: Container(
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.05),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.10),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: TextField(
                    onChanged: (v) => setState(() => _search = v),
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: NeoColors.primaryText,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Search users...',
                      hintStyle: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: NeoColors.grey,
                      ),
                      prefixIcon: Icon(
                        Icons.search,
                        size: 18,
                        color: NeoColors.grey,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Filters
              SizedBox(
                height: 32,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(
                    horizontal: NeoSpacing.lg,
                  ),
                  itemCount: _filters.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final f = _filters[i];
                    final active = _roleFilter == f;
                    return GestureDetector(
                      onTap: () => setState(() => _roleFilter = f),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: active
                              ? NeoColors.gold.withValues(alpha: 0.18)
                              : Colors.white.withValues(alpha: 0.04),
                          border: Border.all(
                            color: active
                                ? NeoColors.gold.withValues(alpha: 0.50)
                                : Colors.white.withValues(alpha: 0.08),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          f == 'all' ? 'ALL' : f.toUpperCase(),
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1,
                            color: active
                                ? NeoColors.gold
                                : NeoColors.secondaryText,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 8),

              // User List
              Expanded(
                child: _loading
                    ? const Center(
                        child: NeoBlockLoader(
                          blockSize: 8,
                          c0: NeoColors.black,
                          c1: NeoColors.yellow,
                        ),
                      )
                    : filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.person_search_outlined,
                              size: 40,
                              color: NeoColors.secondaryText.withValues(
                                alpha: 0.4,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _search.isNotEmpty
                                  ? 'Tidak ditemukan'
                                  : 'Belum ada user',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: NeoColors.secondaryText,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: EdgeInsets.fromLTRB(
                          NeoSpacing.lg,
                          4,
                          NeoSpacing.lg,
                          ScrollClearance.bottomNav(context),
                        ),
                        itemCount: filtered.length,
                        itemBuilder: (context, index) {
                          final u = filtered[index];
                          return _UserCard(
                            user: u,
                            index: index,
                            displayName: _displayName(u),
                            onTap: () => _showActions(u),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UserCard extends StatefulWidget {
  final Map<String, dynamic> user;
  final int index;
  final String displayName;
  final VoidCallback onTap;

  const _UserCard({
    required this.user,
    required this.index,
    required this.displayName,
    required this.onTap,
  });

  @override
  State<_UserCard> createState() => _UserCardState();
}

class _UserCardState extends State<_UserCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _entryCtrl;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    final stagger = (widget.index * 40).clamp(0, 300);
    Future.delayed(Duration(milliseconds: stagger), () {
      if (mounted) _entryCtrl.forward();
    });
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.user;
    final role = (u['role'] ?? '').toString();
    final status = (u['status'] ?? 'active').toString();
    final roleColor = NeoColors.roleColor(role);
    final initial = widget.displayName.isNotEmpty
        ? widget.displayName[0].toUpperCase()
        : '?';
    final username = (u['username'] ?? '').toString().trim();

    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (context, child) {
        final t = CurvedAnimation(
          parent: _entryCtrl,
          curve: Curves.easeOut,
        ).value;
        return Opacity(
          opacity: t,
          child: Transform.translate(
            offset: Offset(0, 12 * (1 - t)),
            child: child,
          ),
        );
      },
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.98 : 1.0,
          duration: const Duration(milliseconds: 100),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _pressed
                  ? Colors.white.withValues(alpha: 0.08)
                  : Colors.white.withValues(alpha: 0.04),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.07),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                _GlassAvatar(initial: initial, roleColor: roleColor, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.displayName,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: NeoColors.primaryText,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (username.isNotEmpty)
                        Text(
                          '@$username',
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w500,
                            color: NeoColors.secondaryText,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: roleColor.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              role.toUpperCase(),
                              style: TextStyle(
                                fontSize: 8,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.8,
                                color: roleColor,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(
                              color: status == 'active'
                                  ? NeoColors.green
                                  : NeoColors.grey,
                              shape: BoxShape.circle,
                              boxShadow: status == 'active'
                                  ? const [
                                      BoxShadow(
                                        color: Color(0x6600C853),
                                        blurRadius: 6,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            status.toUpperCase(),
                            style: TextStyle(
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                              color: NeoColors.secondaryText,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.more_horiz,
                    size: 18,
                    color: NeoColors.secondaryText,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GlassAvatar extends StatelessWidget {
  final String initial;
  final Color roleColor;
  final double size;

  const _GlassAvatar({
    required this.initial,
    required this.roleColor,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            roleColor.withValues(alpha: 0.35),
            roleColor.withValues(alpha: 0.12),
          ],
        ),
        borderRadius: BorderRadius.circular(size * 0.3),
        border: Border.all(color: roleColor.withValues(alpha: 0.30), width: 1),
      ),
      child: Center(
        child: Text(
          initial,
          style: TextStyle(
            fontSize: size * 0.38,
            fontWeight: FontWeight.w800,
            color: roleColor,
          ),
        ),
      ),
    );
  }
}

class _ActionItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _ActionItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color ?? NeoColors.primaryText),
            const SizedBox(width: 14),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: color ?? NeoColors.primaryText,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
