import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../models/wa_sender.dart';
import '../models/wa_function.dart';
import '../providers/whatsapp_provider.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import '../providers/public_chat_unread_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/neo_button.dart';
import '../widgets/neo_card.dart';
import '../widgets/glass_card.dart';
import '../widgets/neo_app_bar.dart';
import '../widgets/scene_background.dart';
import '../widgets/scroll_clearance.dart';
import '../widgets/neo_feature_config.dart';
import '../widgets/neo_block_loader.dart';
import '../widgets/neo_glass_overlay.dart';
import '../widgets/roman_sheet.dart';
import '../public.dart';
import 'package:google_fonts/google_fonts.dart';

Color statusColor(String status) {
  switch (status) {
    case WaStatus.connected:
      return NeoColors.green;
    case WaStatus.qr:
      return NeoColors.blue;
    case WaStatus.pairing:
      return NeoColors.purple;
    case WaStatus.connecting:
      return NeoColors.orange;
    default:
      return NeoColors.grey;
  }
}

String statusLabel(String status) {
  switch (status) {
    case WaStatus.connected:
      return 'CONNECTED';
    case WaStatus.qr:
      return 'QR READY';
    case WaStatus.pairing:
      return 'PAIRING';
    case WaStatus.connecting:
      return 'CONNECTING';
    default:
      return 'DISCONNECTED';
  }
}

Future<WaSender?> showAddWaSenderSheet(BuildContext context) async {
  final provider = context.read<WhatsAppProvider>();
  final result = await showModalBottomSheet<WaSender>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.5),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(NeoRadius.xl)),
    ),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: _AddSenderSheet(provider: provider),
    ),
  );
  if (result != null && context.mounted) {
    await showWaConnectSheet(context, result);
  }
  return result;
}

Future<void> showWaConnectSheet(BuildContext context, WaSender sender) async {
  final provider = context.read<WhatsAppProvider>();
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.5),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(NeoRadius.xl)),
    ),
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: RomanSheet(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 14),
              const Center(child: RomanHandle()),
              const SizedBox(height: 16),
              const RomanSheetTitle('CONNECT SENDER', fontSize: 14),
              const SizedBox(height: 6),
              Text(
                formatPhone(sender.phoneNumber),
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.marble.withValues(alpha: 153 / 255),
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: NeoButton(
                        label: 'SCAN QR',
                        icon: Icons.qr_code_2,
                        bgColor: NeoColors.blue,
                        height: 52,
                        roman: true,
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await provider.startQr(sender.id);
                          if (context.mounted)
                            showWaQrDialog(context, sender.id);
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeoButton(
                        label: 'PAIRING CODE',
                        icon: Icons.password,
                        bgColor: NeoColors.purple,
                        height: 52,
                        roman: true,
                        onPressed: () async {
                          Navigator.pop(ctx);
                          await provider.startPairing(sender.id);
                          if (context.mounted)
                            showWaPairingDialog(context, sender.id);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    ),
  );
}

Future<void> showWaQrDialog(BuildContext context, String senderId) async {
  final provider = context.read<WhatsAppProvider>();
  await showDialog<void>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) => _WaQrDialog(senderId: senderId, provider: provider),
  );
  provider.selectSender(senderId);
}

Future<void> showWaPairingDialog(BuildContext context, String senderId) async {
  final provider = context.read<WhatsAppProvider>();
  await showDialog<void>(
    context: context,
    barrierDismissible: true,
    builder: (ctx) => _WaPairingDialog(senderId: senderId, provider: provider),
  );
  provider.selectSender(senderId);
}

String formatPhone(String phone) {
  if (phone.startsWith('62')) return '+$phone';
  return phone;
}

class WhatsAppScreen extends StatefulWidget {
  const WhatsAppScreen({super.key});

  @override
  State<WhatsAppScreen> createState() => _WhatsAppScreenState();
}

class _WhatsAppScreenState extends State<WhatsAppScreen> {
  String _mode = 'bug';
  String _bugSubMode = 'bug';
  bool _canBan = false;
  bool _canManageProtected = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = context.read<AuthProvider>();
      final role = auth.user?.role ?? 'member';
      setState(() {
        _canBan = const {
          'developer',
          'partner',
          'reseller',
          'vip',
          'moderator',
        }.contains(role);
        _canManageProtected = const {
          'developer',
          'partner',
          'reseller',
          'moderator',
          'vip',
        }.contains(role);
        _mode = 'bug';
      });
      final api = ApiService();
      final token = api.token;
      if (token != null) {
        context.read<WhatsAppProvider>().connectSocket(api.baseUrl, token);
      }
      context.read<WhatsAppProvider>().loadSenders();
      context.read<WhatsAppProvider>().loadFunctions();
      context.read<PublicChatUnreadProvider>().refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    final unread = context.watch<PublicChatUnreadProvider>().count;

    return SceneBackground(
      theme: FeatureConfig.whatsapp,
      screenIndex: 1,
      child: SafeArea(
        child: Column(
          children: [
            const NeoAppHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(
                  NeoSpacing.lg,
                  NeoSpacing.sm,
                  NeoSpacing.lg,
                  ScrollClearance.bottomNav(context),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const RomanTitle(
                      'WHATSAPP',
                      icon: Icons.chat_bubble_rounded,
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    // Nova Chat button
                    GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const PublicChatPage(),
                        ),
                      ),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: skin.isBubbleGum
                                ? [palette.primary, palette.accent]
                                : [const Color(0xFFC9A55A), const Color(0xFFE8D5A3)],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.public,
                              color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink,
                              size: 18,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'NOVACORE CHAT',
                                    style: GoogleFonts.cinzel(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                      color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                  Text(
                                    'Public chat room',
                                    style: GoogleFonts.inter(
                                      fontSize: 10,
                                      color: (skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink).withValues(alpha: 0.6),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              color: skin.isBubbleGum ? palette.onBackground1 : NeoColors.ink,
                              size: 14,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: NeoSpacing.md),
                    _ModeSelector(
                      mode: _mode,
                      canBan: _canBan,
                      canManageProtected: _canManageProtected,
                      onChanged: (m) => setState(() => _mode = m),
                    ),
                    const SizedBox(height: NeoSpacing.lg),
                    if (_mode == 'bug') ...[
                      _SendPanel(
                        subMode: _bugSubMode,
                        onSubModeChanged: (m) =>
                            setState(() => _bugSubMode = m),
                      ),
                      const SizedBox(height: NeoSpacing.xl),
                      Row(
                        children: [
                          const SizedBox(width: 4),
                          Text(
                            'SENDERS',
                            style: GoogleFonts.cinzel(
                              textStyle: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 2,
                                color: NeoColors.gold,
                              ),
                            ),
                          ),
                          if (unread > 0) _WhatsappUnreadBadge(count: unread),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    NeoColors.goldDeep.withValues(alpha: 119 / 255),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: NeoSpacing.sm),
                      Consumer<WhatsAppProvider>(
                        builder: (ctx, wp, _) {
                          if (wp.loading) {
                            return const Center(
                              child: Padding(
                                padding: EdgeInsets.all(NeoSpacing.xl),
                                child: NeoBlockLoader(
                                  blockSize: 8,
                                  c0: NeoColors.black,
                                  c1: NeoColors.yellow,
                                ),
                              ),
                            );
                          }
                          if (wp.senders.isEmpty) {
                            return SizedBox(
                              width: double.infinity,
                              child: Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    const SizedBox(height: NeoSpacing.lg),
                                    Icon(
                                      Icons.chat_bubble_outline,
                                      size: 48,
                                      color: NeoColors.secondaryText,
                                    ),
                                    const SizedBox(height: NeoSpacing.md),
                                    const Text(
                                      'NO SENDERS',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    const SizedBox(height: NeoSpacing.sm),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: NeoSpacing.lg,
                                      ),
                                      child: Text(
                                        'Tambahkan sender baru lewat tombol + di bawah',
                                        textAlign: TextAlign.center,
                                        softWrap: true,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: isDark
                                              ? NeoColors.secondaryText
                                              : NeoColors.grey,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: NeoSpacing.lg),
                                  ],
                                ),
                              ),
                            );
                          }
                          return Column(
                            children: wp.senders
                                .map(
                                  (s) => Padding(
                                    padding: const EdgeInsets.only(
                                      bottom: NeoSpacing.md,
                                    ),
                                    child: _SenderCard(sender: s),
                                  ),
                                )
                                .toList(),
                          );
                        },
                      ),
                    ] else if (_mode == 'ban') ...[
                      _BanPanel(),
                    ] else if (_mode == 'protected') ...[
                      _ProtectedPanel(),
                    ],
                    const SizedBox(height: NeoSpacing.lg),
                    const RomanFooter(
                      words: 'SENATVS POPVLVSQVE NOVACORE',
                      subline: 'QVANTVM MANDATA · TANTVM VIRTVS',
                    ),
                    const SizedBox(height: NeoSpacing.sm),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SendPanel extends StatefulWidget {
  const _SendPanel({required this.subMode, required this.onSubModeChanged});
  final String subMode;
  final ValueChanged<String> onSubModeChanged;
  @override
  State<_SendPanel> createState() => _SendPanelState();
}

class _SendPanelState extends State<_SendPanel> {
  final _targetCtrl = TextEditingController();
  String? _senderId;
  String? _functionId;
  bool _sending = false;

  bool _isGroupFunction(WaFunction f) {
    return f.kind == 'group' || f.kind == 'grup';
  }

  bool _isBanFunction(WaFunction f) {
    final id = f.id.toLowerCase();
    final name = f.name.toLowerCase();
    return id.contains('ban') || name.contains('ban');
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WhatsAppProvider>(
      builder: (ctx, wp, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final senders = wp.senders;
        final functions = wp.functions
            .where(
              (f) =>
                  f.enabled &&
                  !_isBanFunction(f) &&
                  (widget.subMode == 'group'
                      ? _isGroupFunction(f)
                      : !_isGroupFunction(f)),
            )
            .toList();
        final effectiveSenderId =
            _senderId ?? (senders.isNotEmpty ? senders.first.id : null);
        final effectiveFunctionId =
            _functionId ?? (functions.isNotEmpty ? functions.first.id : null);
        final senderIndex = senders.indexWhere(
          (s) => s.id == effectiveSenderId,
        );
        final functionIndex = functions.indexWhere(
          (f) => f.id == effectiveFunctionId,
        );

        final canExecute =
            !_sending &&
            effectiveSenderId != null &&
            effectiveFunctionId != null &&
            _targetCtrl.text.trim().isNotEmpty;

        return NeoCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: NeoColors.green.withValues(alpha: 0.18),
                      border: Border.all(
                        color: NeoColors.green.withValues(alpha: 0.5),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(NeoRadius.sm),
                    ),
                    child: const Icon(
                      Icons.send_rounded,
                      size: 18,
                      color: NeoColors.green,
                    ),
                  ),
                  const SizedBox(width: NeoSpacing.md),
                  Expanded(
                    child: Text(
                      'Bug Whatsapp',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: NeoColors.primaryText,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.touch_app_outlined,
                    size: 16,
                    color: NeoColors.grey,
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.md),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: isDark ? 0.07 : 0.5),
                  borderRadius: BorderRadius.circular(NeoRadius.lg),
                  border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _BugSubTab(
                        label: 'BUG',
                        icon: Icons.person,
                        active: widget.subMode == 'bug',
                        onTap: () => widget.onSubModeChanged('bug'),
                      ),
                    ),
                    Expanded(
                      child: _BugSubTab(
                        label: 'BUG GRUP',
                        icon: Icons.groups,
                        active: widget.subMode == 'group',
                        onTap: () => widget.onSubModeChanged('group'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: NeoSpacing.md),
              const Text(
                'SENDER',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.grey,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 6),
              IgnorePointer(
                ignoring: _sending,
                child: _CarouselPicker(
                  options: senders
                      .map(
                        (s) => _CarouselOption(
                          id: s.id,
                          icon: Icons.phone_android,
                          title: formatPhone(s.phoneNumber),
                          subtitle: s.sessionName.isNotEmpty
                              ? s.sessionName
                              : statusLabel(s.status),
                          color: statusColor(s.status),
                        ),
                      )
                      .toList(),
                  emptyLabel: 'Belum ada sender',
                  initialIndex: senderIndex < 0 ? 0 : senderIndex,
                  onChanged: (i) => setState(() => _senderId = senders[i].id),
                ),
              ),
              const SizedBox(height: NeoSpacing.md),
              Row(
                children: [
                  Text(
                    widget.subMode == 'group'
                        ? 'ID / LINK GRUP TARGET'
                        : 'NOMOR TARGET',
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: NeoColors.grey,
                      letterSpacing: 1,
                    ),
                  ),
                  if (_sending) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: NeoColors.yellow,
                        border: Border.all(color: NeoColors.black, width: 1.5),
                        borderRadius: BorderRadius.circular(3),
                      ),
                      child: const Text(
                        'LOCKED',
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w800,
                          color: NeoColors.black,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 6),
              TextField(
                controller: _targetCtrl,
                enabled: !_sending,
                keyboardType: widget.subMode == 'group'
                    ? TextInputType.url
                    : TextInputType.phone,
                onChanged: (_) => setState(() {}),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: NeoColors.primaryText,
                ),
                decoration: InputDecoration(
                  hintText: widget.subMode == 'group'
                      ? 'Link grup WhatsApp'
                      : '0812xxxx atau 62812xxxx',
                  prefixIcon: Icon(
                    widget.subMode == 'group'
                        ? Icons.groups
                        : Icons.person_add_alt_1,
                    size: 20,
                  ),
                  filled: true,
                  fillColor: NeoColors.white.withValues(
                    alpha: isDark ? 0.06 : 0.45,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(NeoRadius.md),
                    borderSide: BorderSide(
                      color: context.watch<NeoThemeProvider>().isBubbleGum
                          ? context.watch<NeoThemeProvider>().palette.primary.withValues(alpha: 0.55)
                          : NeoColors.gold.withValues(alpha: 102 / 255),
                      width: 1,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(NeoRadius.md),
                    borderSide: BorderSide(
                      color: context.watch<NeoThemeProvider>().isBubbleGum
                          ? context.watch<NeoThemeProvider>().palette.primary
                          : NeoColors.gold,
                      width: 1.2,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: NeoSpacing.md),
              Text(
                widget.subMode == 'group' ? 'FUNGSI BUG GRUP' : 'FUNGSI BUG',
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.grey,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 6),
              IgnorePointer(
                ignoring: _sending,
                child: _CarouselPicker(
                  options: functions
                      .map(
                        (f) => _CarouselOption(
                          id: f.id,
                          icon: Icons.widgets_outlined,
                          title: f.name,
                          subtitle: f.description.isNotEmpty
                              ? f.description
                              : 'Fungsi WhatsApp',
                          color: NeoColors.purple,
                        ),
                      )
                      .toList(),
                  emptyLabel: 'Belum ada fungsi',
                  initialIndex: functionIndex < 0 ? 0 : functionIndex,
                  onChanged: (i) =>
                      setState(() => _functionId = functions[i].id),
                ),
              ),
              if (functions.isEmpty) ...[
                const SizedBox(height: 8),
                const Text(
                  'Belum ada fungsi untuk mode ini. Developer menambahkannya di Manage > Fitur WhatsApp.',
                  style: TextStyle(fontSize: 11, color: NeoColors.grey),
                ),
              ],
              const SizedBox(height: NeoSpacing.lg),
              NeoButton(
                label: 'EXECUTE',
                icon: Icons.play_arrow_rounded,
                bgColor: NeoColors.green,
                loading: _sending,
                onPressed: canExecute
                    ? () => _execute(
                        ctx,
                        wp,
                        effectiveSenderId,
                        effectiveFunctionId,
                      )
                    : null,
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _execute(
    BuildContext context,
    WhatsAppProvider wp,
    String senderId,
    String functionId,
  ) async {
    final target = _targetCtrl.text.trim();
    if (target.isEmpty) return;

    setState(() => _sending = true);
    final res = await _showRomanExec(
      context,
      () => wp.execute(senderId, target, functionId),
      title: 'EKSEKUSI BUG',
      stages: const ['KIRIM KE SERVER', 'PROSES BUG', 'LAPORAN TERKIRIM'],
    );
    if (!context.mounted) return;
    setState(() => _sending = false);
    if (res?.ok == true) {
      _targetCtrl.clear();
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Bug terkirim.'),
          backgroundColor: NeoColors.green,
        ),
      );
    }
  }
}

class _SenderCard extends StatelessWidget {
  final WaSender sender;

  const _SenderCard({required this.sender});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.border;
    final color = statusColor(sender.status);
    final isConnected = sender.status == WaStatus.connected;

    return NeoCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color,
                  border: Border.all(color: lineColor, width: 2),
                  borderRadius: BorderRadius.circular(NeoRadius.sm),
                  boxShadow: NeoShadows.smD(isDark),
                ),
                child: Icon(
                  isConnected ? Icons.wifi : Icons.chat_bubble_rounded,
                  size: 20,
                  color: NeoColors.black,
                ),
              ),
              const SizedBox(width: NeoSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      formatPhone(sender.phoneNumber),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: isDark ? NeoColors.primaryText : NeoColors.black,
                      ),
                    ),
                    if (sender.sessionName.isNotEmpty) ...[
                      const SizedBox(height: 1),
                      Text(
                        sender.sessionName,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: NeoColors.grey,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
              if (!sender.enabled)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: NeoColors.grey,
                    border: Border.all(color: lineColor, width: 1.5),
                    borderRadius: BorderRadius.circular(NeoRadius.sm),
                  ),
                  child: const Text(
                    'NONAKTIF',
                    style: TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.white,
                      letterSpacing: 0.8,
                    ),
                  ),
                )
              else
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: color,
                    border: Border.all(color: lineColor, width: 1.5),
                    borderRadius: BorderRadius.circular(NeoRadius.sm),
                    boxShadow: NeoShadows.smD(isDark),
                  ),
                  child: Text(
                    statusLabel(sender.status),
                    style: const TextStyle(
                      fontSize: 8,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.black,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: NeoSpacing.md),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Icon(Icons.visibility_outlined, size: 13, color: NeoColors.grey),
                  const SizedBox(width: 4),
                  Text(
                    sender.effectiveVisibility.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: NeoColors.grey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: NeoSpacing.sm),
              Wrap(
                alignment: WrapAlignment.end,
                spacing: 4,
                runSpacing: 4,
                children: [
                  _ActionIconButton(
                    icon: Icons.refresh,
                    tooltip: 'Refresh',
                    color: NeoColors.blue,
                    onTap: () => context
                        .read<WhatsAppProvider>()
                        .refreshStatus(sender.id),
                  ),
                  if (isConnected)
                    _ActionIconButton(
                      icon: Icons.link_off,
                      tooltip: 'Disconnect',
                      color: NeoColors.orange,
                      onTap: () => context
                          .read<WhatsAppProvider>()
                          .disconnect(sender.id),
                    )
                  else ...[
                    _ActionIconButton(
                      icon: Icons.qr_code_2,
                      tooltip: 'Scan QR',
                      color: NeoColors.blue,
                      onTap: () async {
                        final ok = await context
                            .read<WhatsAppProvider>()
                            .startQr(sender.id);
                        if (ok['success'] == true && context.mounted) {
                          showWaQrDialog(context, sender.id);
                        }
                      },
                    ),
                    _ActionIconButton(
                      icon: Icons.password,
                      tooltip: 'Pairing code',
                      color: NeoColors.purple,
                      onTap: () async {
                        final ok = await context
                            .read<WhatsAppProvider>()
                            .startPairing(sender.id);
                        if (ok['success'] == true && context.mounted) {
                          showWaPairingDialog(context, sender.id);
                        }
                      },
                    ),
                  ],
                  _ActionIconButton(
                    icon: Icons.delete_outline,
                    tooltip: 'Delete',
                    color: NeoColors.pink,
                    onTap: () => _confirmDelete(context),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: NeoGlassOverlay(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'DELETE SENDER?',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: NeoColors.primaryText,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Delete WhatsApp sender ${formatPhone(sender.phoneNumber)}?\n\nSession credentials will be removed and the connection stopped. This cannot be undone.',
                style: TextStyle(color: NeoColors.secondaryText),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('BATAL'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextButton(
                      style: TextButton.styleFrom(
                        foregroundColor: NeoColors.pink,
                      ),
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('HAPUS'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ).then((confirmed) async {
      if (confirmed == true && context.mounted) {
        final wp = context.read<WhatsAppProvider>();
        final result = await wp.deleteSender(sender.id);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
              content: Text(
                result['success'] == true
                    ? 'Sender deleted'
                    : (result['error']?['message'] ?? 'Delete failed'),
              ),
              backgroundColor: result['success'] == true
                  ? NeoColors.green
                  : NeoColors.pink,
            ),
          );
        }
      }
    });
  }
}

class _ActionIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final Color color;
  final VoidCallback onTap;

  const _ActionIconButton({
    required this.icon,
    required this.tooltip,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isDark
                ? Colors.white.withValues(alpha: 0.08)
                : NeoColors.white.withValues(alpha: 0.8),
            border: Border.all(
              color: isDark ? NeoColors.gold.withValues(alpha: 51 / 255) : NeoColors.gold.withValues(alpha: 85 / 255),
              width: 1,
            ),
            borderRadius: BorderRadius.circular(NeoRadius.sm),
          ),
          child: Icon(icon, size: 16, color: color),
        ),
      ),
    );
  }
}

class _AddSenderSheet extends StatefulWidget {
  final WhatsAppProvider provider;

  const _AddSenderSheet({required this.provider});

  @override
  State<_AddSenderSheet> createState() => _AddSenderSheetState();
}

class _AddSenderSheetState extends State<_AddSenderSheet> {
  final _phoneCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  String _visibility = 'private';
  bool _creating = false;
  String? _error;

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final phone = _phoneCtrl.text.trim();
    if (phone.isEmpty) {
      setState(() => _error = 'Nomor WhatsApp wajib diisi.');
      return;
    }
    setState(() {
      _creating = true;
      _error = null;
    });
    final result = await widget.provider.createSender(
      phone,
      visibility: _visibility,
      sessionName: _nameCtrl.text.trim().isEmpty ? null : _nameCtrl.text.trim(),
    );
    if (!mounted) return;
    setState(() => _creating = false);
    if (result['success'] == true && result['data'] is Map) {
      final s = WaSender.fromJson(
        Map<String, dynamic>.from(result['data'] as Map),
      );
      Navigator.pop(context, s);
    } else {
      setState(
        () =>
            _error = result['error']?['message'] ?? 'Gagal menambahkan sender.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return RomanSheet(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(child: RomanHandle()),
            const SizedBox(height: 16),
            const RomanSheetTitle('ADD SENDER'),
            const SizedBox(height: 20),
            RomanLabel('NOMOR WHATSAPP', color: NeoColors.grey),
            const SizedBox(height: 6),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: NeoColors.marble,
              ),
              decoration: romanFieldDecoration(
                hint: '0812xxxx atau 62812xxxx',
                icon: Icons.phone_android,
              ),
            ),
            const SizedBox(height: NeoSpacing.md),
            RomanLabel('NAMA SESI (OPSIONAL)', color: NeoColors.grey),
            const SizedBox(height: 6),
            TextField(
              controller: _nameCtrl,
              style: TextStyle(fontSize: 14, color: NeoColors.marble),
              decoration: romanFieldDecoration(
                hint: 'Contoh: Sender Support',
                icon: Icons.label_outline,
              ),
            ),
            const SizedBox(height: NeoSpacing.lg),
            RomanLabel('VISIBILITAS', color: NeoColors.grey),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: _VisibilityOption(
                    label: 'PRIVATE',
                    icon: Icons.lock_outline,
                    selected: _visibility == 'private',
                    onTap: () => setState(() => _visibility = 'private'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _VisibilityOption(
                    label: 'GLOBAL',
                    icon: Icons.public,
                    selected: _visibility == 'global',
                    onTap: () => setState(() => _visibility = 'global'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              _visibility == 'global'
                  ? 'Terlihat oleh semua role tanpa terkecuali.'
                  : 'Hanya bisa dilihat oleh Anda.',
              style: const TextStyle(fontSize: 10, color: NeoColors.grey),
            ),
            if (_error != null) ...[
              const SizedBox(height: NeoSpacing.md),
              Text(
                _error!,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: NeoColors.pink,
                ),
              ),
            ],
            const SizedBox(height: NeoSpacing.lg),
            NeoButton(
              label: 'LANJUT',
              icon: Icons.arrow_forward,
              bgColor: NeoColors.green,
              loading: _creating,
              roman: true,
              onPressed: _submit,
            ),
            const SizedBox(height: NeoSpacing.sm),
            NeoButton(
              label: 'BATAL',
              bgColor: NeoColors.surfaceElevated,
              textColor: NeoColors.primaryText,
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }
}

class _VisibilityOption extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _VisibilityOption({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final lineColor = isDark ? NeoColors.line : NeoColors.border;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? NeoColors.yellow : NeoColors.surfaceElevated,
          border: Border.all(color: lineColor, width: 2),
          borderRadius: BorderRadius.circular(NeoRadius.md),
          boxShadow: selected ? NeoShadows.smD(isDark) : null,
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 22,
              color: selected ? NeoColors.black : NeoColors.secondaryText,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: selected ? NeoColors.black : NeoColors.secondaryText,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WaQrDialog extends StatefulWidget {
  final String senderId;
  final WhatsAppProvider provider;

  const _WaQrDialog({required this.senderId, required this.provider});

  @override
  State<_WaQrDialog> createState() => _WaQrDialogState();
}

class _WaQrDialogState extends State<_WaQrDialog> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      widget.provider.refreshStatus(widget.senderId);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WhatsAppProvider>(
      builder: (ctx, wp, _) {
        final sender = wp.senderById(widget.senderId);
        final status = sender?.status ?? WaStatus.connecting;
        final qr = wp.qrFor(widget.senderId);

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: NeoGlassOverlay(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(Icons.qr_code_2, color: statusColor(status)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'SCAN QR CODE',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: NeoColors.primaryText,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(
                        Icons.close,
                        color: NeoColors.grey,
                        size: 20,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  formatPhone(sender?.phoneNumber ?? ''),
                  style: const TextStyle(
                    fontSize: 12,
                    color: NeoColors.grey,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: NeoColors.white,
                    border: Border.all(color: NeoColors.border, width: 3),
                    borderRadius: BorderRadius.circular(NeoRadius.md),
                  ),
                  child: qr != null && qr.isNotEmpty
                      ? QrImageView(
                          data: qr,
                          version: QrVersions.auto,
                          size: 220,
                          backgroundColor: NeoColors.white,
                          eyeStyle: const QrEyeStyle(
                            eyeShape: QrEyeShape.square,
                            color: NeoColors.black,
                          ),
                          dataModuleStyle: const QrDataModuleStyle(
                            dataModuleShape: QrDataModuleShape.square,
                            color: NeoColors.black,
                          ),
                        )
                      : SizedBox(
                          width: 220,
                          height: 220,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const NeoBlockLoader(
                                  blockSize: 12,
                                  c0: NeoColors.black,
                                  c1: NeoColors.yellow,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  status == WaStatus.connected
                                      ? 'Connected!'
                                      : 'Menunggu QR...',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    color: NeoColors.black,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: NeoColors.surfaceElevated,
                    border: Border.all(color: NeoColors.border, width: 2),
                    borderRadius: BorderRadius.circular(NeoRadius.sm),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        size: 14,
                        color: statusColor(status),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          status == WaStatus.connected
                              ? 'WhatsApp terhubung.'
                              : 'Scan dengan WhatsApp > Linked Devices > Link a Device.',
                          style: TextStyle(
                            fontSize: 11,
                            color: NeoColors.secondaryText,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (status == WaStatus.connected) ...[
                  const SizedBox(height: 12),
                  NeoButton(
                    label: 'SELESAI',
                    bgColor: NeoColors.green,
                    height: 40,
                    fontSize: 13,
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WaPairingDialog extends StatefulWidget {
  final String senderId;
  final WhatsAppProvider provider;

  const _WaPairingDialog({required this.senderId, required this.provider});

  @override
  State<_WaPairingDialog> createState() => _WaPairingDialogState();
}

class _WaPairingDialogState extends State<_WaPairingDialog> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      widget.provider.refreshStatus(widget.senderId);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WhatsAppProvider>(
      builder: (ctx, wp, _) {
        final sender = wp.senderById(widget.senderId);
        final status = sender?.status ?? WaStatus.pairing;
        final code = sender?.pairingCode;

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 24,
          ),
          child: NeoGlassOverlay(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(Icons.shield_moon_rounded, color: statusColor(status)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'PAIRING CODE',
                        style: GoogleFonts.cinzel(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          color: NeoColors.gold,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(
                        Icons.close,
                        color: NeoColors.grey,
                        size: 20,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const RomanSheetTitle('KODE AKSES', fontSize: 12),
                const SizedBox(height: 4),
                Text(
                  formatPhone(sender?.phoneNumber ?? ''),
                  style: const TextStyle(
                    fontSize: 12,
                    color: NeoColors.grey,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                if (status == WaStatus.connected)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: NeoColors.goldDeep,
                      border: Border.all(
                        color: NeoColors.gold,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text(
                      'WhatsApp TERHUBUNG',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF0D0D2B),
                      ),
                    ),
                  )
                else if (code != null && code.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 16,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [NeoColors.gold, NeoColors.goldDeep, Color(0xFF8A6D2B)],
                      ),
                      border: Border.all(
                        color: const Color(0x99FFFFFF),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: NeoColors.gold.withValues(alpha: 138 / 255),
                          blurRadius: 22,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          code,
                          style: GoogleFonts.cinzel(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            color: const Color(0xFF0D0D2B),
                            letterSpacing: 3,
                          ),
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () async {
                            await Clipboard.setData(ClipboardData(text: code));
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  margin: const EdgeInsets.fromLTRB(
                                    16,
                                    0,
                                    16,
                                    91,
                                  ),
                                  content: Text('Kode pairing disalin'),
                                  backgroundColor: NeoColors.goldDeep,
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: const Color(0xFF0D0D2B),
                              borderRadius: BorderRadius.circular(NeoRadius.sm),
                            ),
                            child: Icon(
                              Icons.copy,
                              size: 16,
                              color: NeoColors.gold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  const Padding(
                    padding: EdgeInsets.all(20),
                    child: NeoBlockLoader(
                      blockSize: 12,
                      c0: NeoColors.yellow,
                      c1: NeoColors.white,
                    ),
                  ),
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.06),
                    border: Border.all(
                      color: NeoColors.gold.withValues(alpha: 68 / 255),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'Masukkan kode ini di WhatsApp > Linked Devices > Link with phone number instead.',
                    style: TextStyle(
                      fontSize: 11,
                      color: NeoColors.marble.withValues(alpha: 0.7),
                    ),
                  ),
                ),
                if (status == WaStatus.connected) ...[
                  const SizedBox(height: 12),
                  NeoButton(
                    label: 'SELESAI',
                    bgColor: NeoColors.green,
                    height: 40,
                    fontSize: 13,
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _WhatsappUnreadBadge extends StatelessWidget {
  final int count;
  const _WhatsappUnreadBadge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.redAccent,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        '$count',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _ModeSelector extends StatelessWidget {
  final String mode;
  final bool canBan;
  final bool canManageProtected;
  final ValueChanged<String> onChanged;

  const _ModeSelector({
    required this.mode,
    required this.canBan,
    required this.canManageProtected,
    required this.onChanged,
  });

  double _xFor(String mode) {
    switch (mode) {
      case 'bug':
        return -1.0;
      case 'ban':
        return 0.0;
      case 'protected':
        return 1.0;
      default:
        return -1.0;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Satu Liquid Glass container
        ClipRRect(
          borderRadius: BorderRadius.circular(21),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              height: 42,
              decoration: BoxDecoration(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.05)
                    : Colors.white.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(21),
                border: Border.all(
                  color: isDark
                      ? NeoColors.gold.withValues(alpha: 51 / 255)
                      : NeoColors.gold.withValues(alpha: 34 / 255),
                  width: 1.0,
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: _ModeTab(
                      label: 'BUG',
                      icon: Icons.bug_report_outlined,
                      active: mode == 'bug',
                      onTap: () => onChanged('bug'),
                    ),
                  ),
                  Expanded(
                    child: _ModeTab(
                      label: 'BAN',
                      icon: Icons.gpp_bad_outlined,
                      enabled: canBan,
                      active: mode == 'ban',
                      onTap: () => onChanged('ban'),
                    ),
                  ),
                  Expanded(
                    child: _ModeTab(
                      label: 'PROTECTED',
                      icon: Icons.shield_outlined,
                      enabled: canManageProtected,
                      active: mode == 'protected',
                      onTap: () => onChanged('protected'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // ACTIVE INDICATOR: Single small gold dot on TOP EDGE (clipBehavior: Clip.none)
        Positioned(
          top: -3.5,
          left: 0,
          right: 0,
          height: 7,
          child: _DotIndicator(alignX: _xFor(mode)),
        ),
      ],
    );
  }
}

class _DotIndicator extends StatefulWidget {
  final double alignX;
  const _DotIndicator({required this.alignX});

  @override
  State<_DotIndicator> createState() => _DotIndicatorState();
}

class _DotIndicatorState extends State<_DotIndicator>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  double _fromX = -1.0;

  @override
  void initState() {
    super.initState();
    _fromX = widget.alignX;
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _ctrl.forward(from: 0);
    });
  }

  @override
  void didUpdateWidget(covariant _DotIndicator old) {
    super.didUpdateWidget(old);
    if (old.alignX != widget.alignX) {
      _fromX = widget.alignX;
      _ctrl.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        final spring = Curves.easeOutBack.transform(_ctrl.value);
        final x = _fromX + (widget.alignX - _fromX) * spring;
        return Align(
          alignment: Alignment(x.clamp(-1.0, 1.0), -1.0),
          child: FractionallySizedBox(
            widthFactor: 1 / 3,
            child: Center(
              child: Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  color: context.watch<NeoThemeProvider>().isBubbleGum
                      ? context.watch<NeoThemeProvider>().palette.primary
                      : NeoColors.gold,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: context.watch<NeoThemeProvider>().isBubbleGum
                          ? context.watch<NeoThemeProvider>().palette.primary
                          : NeoColors.gold,
                      blurRadius: 8,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ModeTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool enabled;
  final bool active;
  final VoidCallback onTap;

  const _ModeTab({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final usable = enabled && !active;
    final color = !enabled
        ? NeoColors.grey
      : (active
        ? (context.watch<NeoThemeProvider>().isBubbleGum
          ? context.watch<NeoThemeProvider>().palette.primary
          : NeoColors.gold)
        : NeoColors.primaryText);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: usable ? onTap : null,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 17, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.3,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _BugSubTab extends StatefulWidget {
  const _BugSubTab({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  State<_BugSubTab> createState() => _BugSubTabState();
}

class _BugSubTabState extends State<_BugSubTab> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          gradient: widget.active
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [NeoColors.gold, NeoColors.goldDeep],
                )
              : null,
          color: widget.active ? null : Colors.transparent,
          borderRadius: BorderRadius.circular(NeoRadius.md - 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              widget.icon,
              size: 15,
              color: widget.active ? const Color(0xFF2A1E00) : NeoColors.gold,
            ),
            const SizedBox(width: 5),
            Text(
              widget.label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
                color: widget.active
                    ? const Color(0xFF2A1E00)
                    : NeoColors.primaryText,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BanPanel extends StatefulWidget {
  const _BanPanel();
  @override
  State<_BanPanel> createState() => _BanPanelState();
}

class _BanPanelState extends State<_BanPanel> {
  final _targetCtrl = TextEditingController();
  String? _senderId;
  String? _functionId;
  bool _sending = false;
  String _banSub = 'nomor';

  @override
  void dispose() {
    _targetCtrl.dispose();
    super.dispose();
  }

  bool _isBanFunction(WaFunction f) {
    final id = f.id.toLowerCase();
    final name = f.name.toLowerCase();
    return id.contains('ban') || name.contains('ban');
  }

  bool _isGroupBanFunction(WaFunction f) {
    return f.kind == 'group' || f.kind == 'grup' || f.kind == 'group-ban';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WhatsAppProvider>(
      builder: (ctx, wp, _) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final senders = wp.senders;
        final functions = wp.functions
            .where(
              (f) =>
                  f.enabled &&
                  _isBanFunction(f) &&
                  (_banSub == 'grup'
                      ? _isGroupBanFunction(f)
                      : !_isGroupBanFunction(f)),
            )
            .toList();
        final effectiveSenderId =
            _senderId ?? (senders.isNotEmpty ? senders.first.id : null);
        final effectiveFunctionId =
            _functionId ?? (functions.isNotEmpty ? functions.first.id : null);
        final senderIndex = senders.indexWhere(
          (s) => s.id == effectiveSenderId,
        );
        final functionIndex = functions.indexWhere(
          (f) => f.id == effectiveFunctionId,
        );

        final canExecute =
            !_sending &&
            effectiveSenderId != null &&
            effectiveFunctionId != null &&
            _targetCtrl.text.trim().isNotEmpty;

        return Column(
          children: [
            GlassCard(
              padding: const EdgeInsets.all(0),
              child: Padding(
                padding: const EdgeInsets.all(NeoSpacing.lg),
                child: Row(
                  children: [
                    Icon(Icons.gpp_bad_outlined, color: NeoColors.pink),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(
                      child: Text(
                        'Mode ini mengirimkan interaksi agar nomor/grup target dapat dibanned. Gunakan dengan bijak.',
                        style: TextStyle(
                          fontSize: 11,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: NeoSpacing.md),
            NeoCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [NeoColors.pink, Color(0xFFB71C1C)],
                          ),
                          borderRadius: BorderRadius.circular(NeoRadius.sm),
                        ),
                        child: const Icon(
                          Icons.block,
                          size: 18,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(width: NeoSpacing.md),
                      Expanded(
                        child: Text(
                          'Ban Target',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: NeoColors.primaryText,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: NeoSpacing.md),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(
                        alpha: isDark ? 0.07 : 0.5,
                      ),
                      borderRadius: BorderRadius.circular(NeoRadius.lg),
                      border: Border.all(
                        color: NeoColors.gold.withValues(alpha: 85 / 255),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _BugSubTab(
                            label: 'NOMOR',
                            icon: Icons.person,
                            active: _banSub == 'nomor',
                            onTap: () => setState(() => _banSub = 'nomor'),
                          ),
                        ),
                        Expanded(
                          child: _BugSubTab(
                            label: 'GRUP',
                            icon: Icons.groups,
                            active: _banSub == 'grup',
                            onTap: () => setState(() => _banSub = 'grup'),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: NeoSpacing.md),
                  const Text(
                    'SENDER',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: NeoColors.grey,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  IgnorePointer(
                    ignoring: _sending,
                    child: _CarouselPicker(
                      options: senders
                          .map(
                            (s) => _CarouselOption(
                              id: s.id,
                              icon: Icons.phone_android,
                              title: formatPhone(s.phoneNumber),
                              subtitle: s.sessionName.isNotEmpty
                                  ? s.sessionName
                                  : statusLabel(s.status),
                              color: statusColor(s.status),
                            ),
                          )
                          .toList(),
                      emptyLabel: 'Belum ada sender',
                      initialIndex: senderIndex < 0 ? 0 : senderIndex,
                      onChanged: (i) =>
                          setState(() => _senderId = senders[i].id),
                    ),
                  ),
                  const SizedBox(height: NeoSpacing.md),
                  Text(
                    _banSub == 'grup'
                        ? 'ID / LINK GRUP TARGET'
                        : 'NOMOR TARGET',
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: NeoColors.grey,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextField(
                    controller: _targetCtrl,
                    enabled: !_sending,
                    onChanged: (_) => setState(() {}),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.primaryText,
                    ),
                    decoration: InputDecoration(
                      hintText: _banSub == 'grup'
                          ? 'Link / ID grup WhatsApp'
                          : '0812xxxx atau 62812xxxx',
                      prefixIcon: Icon(
                        _banSub == 'grup'
                            ? Icons.groups
                            : Icons.person_add_alt_1,
                        size: 20,
                      ),
                      filled: true,
                      fillColor: NeoColors.white.withValues(
                        alpha: isDark ? 0.06 : 0.45,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                        borderSide: BorderSide(
                          color: NeoColors.gold.withValues(alpha: 102 / 255),
                          width: 1,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                        borderSide: BorderSide(
                          color: NeoColors.gold,
                          width: 1.2,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: NeoSpacing.md),
                  Text(
                    _banSub == 'grup' ? 'FUNGSI BAN GRUP' : 'FUNGSI BAN NOMOR',
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: NeoColors.grey,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  IgnorePointer(
                    ignoring: _sending,
                    child: _CarouselPicker(
                      options: functions
                          .map(
                            (f) => _CarouselOption(
                              id: f.id,
                              icon: Icons.block,
                              title: f.name,
                              subtitle: f.description.isNotEmpty
                                  ? f.description
                                  : 'Fungsi ban WhatsApp',
                              color: NeoColors.pink,
                            ),
                          )
                          .toList(),
                      emptyLabel: 'Belum ada fungsi',
                      initialIndex: functionIndex < 0 ? 0 : functionIndex,
                      onChanged: (i) =>
                          setState(() => _functionId = functions[i].id),
                    ),
                  ),
                  if (functions.isEmpty) ...[
                    const SizedBox(height: 8),
                    const Text(
                      'Belum ada fungsi. Developer menambahkannya di Manage > Fitur WhatsApp.',
                      style: TextStyle(fontSize: 11, color: NeoColors.grey),
                    ),
                  ],
                  const SizedBox(height: NeoSpacing.lg),
                  NeoButton(
                    label: 'EXECUTE BAN',
                    icon: Icons.block,
                    bgColor: NeoColors.goldDeep,
                    loading: _sending,
                    onPressed: canExecute
                        ? () => _execute(
                            ctx,
                            wp,
                            effectiveSenderId,
                            effectiveFunctionId,
                          )
                        : null,
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _execute(
    BuildContext context,
    WhatsAppProvider wp,
    String senderId,
    String functionId,
  ) async {
    final target = _targetCtrl.text.trim();
    if (target.isEmpty) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        child: RomanDialog(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [NeoColors.pink, Color(0xFF8A1C1C)],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0x99FFFFFF),
                        width: 2,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x66D32F2F),
                          blurRadius: 24,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.gpp_bad_outlined,
                      color: Color(0xFF0D0D2B),
                      size: 30,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const RomanSheetTitle('EKSEKUSI BAN?', fontSize: 16),
                const SizedBox(height: 14),
                Text(
                  'Kirim interaksi ban ke\n$target?\n\nPastikan target benar karena tindakan ini berdampak pada nomor/grup tersebut.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.5,
                    color: NeoColors.marble,
                  ),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: NeoButton(
                        label: 'BATAL',
                        bgColor: NeoColors.surfaceElevated,
                        textColor: NeoColors.primaryText,
                        height: 40,
                        fontSize: 13,
                        roman: true,
                        onPressed: () => Navigator.pop(ctx, false),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: NeoButton(
                        label: 'EKSEKUSI',
                        bgColor: NeoColors.goldDeep,
                        textColor: NeoColors.white,
                        height: 40,
                        fontSize: 13,
                        roman: true,
                        onPressed: () => Navigator.pop(ctx, true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (confirm != true || !mounted) return;

    setState(() => _sending = true);
    if (!context.mounted) return;
    final res = await _showRomanExec(
      context,
      () => wp.execute(senderId, target, functionId),
      title: 'EKSEKUSI BAN',
      stages: const ['KIRIM KE SERVER', 'PROSES BAN', 'LAPORAN TERKIRIM'],
    );
    if (!context.mounted) return;
    setState(() => _sending = false);
    if (res?.ok == true) {
      _targetCtrl.clear();
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Perintah ban terkirim.'),
          backgroundColor: NeoColors.green,
        ),
      );
    }
  }
}

class _ProtectedPanel extends StatefulWidget {
  const _ProtectedPanel();
  @override
  State<_ProtectedPanel> createState() => _ProtectedPanelState();
}

class _ProtectedPanelState extends State<_ProtectedPanel> {
  // Hanya sender yang masih TERHUBUNG, dan tanpa duplikat nomor
  // (nomor sama yang dipasang di beberapa slot hanya muncul satu baris).
  List<WaSender> _connectedUnique(List<WaSender> senders) {
    final seen = <String>{};
    final out = <WaSender>[];
    for (final s in senders) {
      if (s.status != WaStatus.connected) continue;
      final key = s.phoneNumber.replaceAll(RegExp(r'\D'), '');
      if (key.isEmpty || !seen.add(key)) continue;
      out.add(s);
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WhatsAppProvider>(
      builder: (ctx, wp, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GlassCard(
              padding: const EdgeInsets.all(0),
              child: Padding(
                padding: const EdgeInsets.all(NeoSpacing.lg),
                child: Row(
                  children: [
                    const Icon(Icons.shield_outlined, color: NeoColors.green),
                    const SizedBox(width: NeoSpacing.sm),
                    Expanded(
                      child: Text(
                        'Aktifkan PROTEKSI pada sender agar akun tersebut aman dari serangan bug/ban dari sender lain. Setiap sender punya tombol proteksi ON/OFF sendiri.',
                        style: TextStyle(
                          fontSize: 11,
                          color: NeoColors.secondaryText,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: NeoSpacing.md),
            const Text(
              'SENDER & PROTEKSI',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: NeoColors.grey,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 6),
            if (wp.loading)
              Center(
                child: Padding(
                  padding: EdgeInsets.all(NeoSpacing.lg),
                  child: NeoBlockLoader(
                    blockSize: 8,
                    c0: NeoColors.green,
                    c1: NeoColors.gold,
                  ),
                ),
              )
            else if (wp.senders.isEmpty)
              NeoCard(
                child: Padding(
                  padding: const EdgeInsets.all(NeoSpacing.xl),
                  child: Center(
                    child: Text(
                      'Belum ada sender. Tambahkan sender terlebih dahulu.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? NeoColors.secondaryText
                            : NeoColors.grey,
                      ),
                    ),
                  ),
                ),
              )
            else if (_connectedUnique(wp.senders).isEmpty)
              NeoCard(
                child: Padding(
                  padding: const EdgeInsets.all(NeoSpacing.xl),
                  child: Center(
                    child: Text(
                      'Belum ada sender terhubung. Hubungkan sender dulu untuk mengelola proteksi.',
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? NeoColors.secondaryText
                            : NeoColors.grey,
                      ),
                    ),
                  ),
                ),
              )
            else
              ..._connectedUnique(wp.senders).map(
                (s) => Padding(
                  padding: const EdgeInsets.only(bottom: NeoSpacing.sm),
                  child: _ProtectedSenderCard(sender: s),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _ProtectedSenderCard extends StatefulWidget {
  const _ProtectedSenderCard({required this.sender});
  final WaSender sender;
  @override
  State<_ProtectedSenderCard> createState() => _ProtectedSenderCardState();
}

class _ProtectedSenderCardState extends State<_ProtectedSenderCard> {
  late bool _protected = widget.sender.protected;
  bool _busy = false;

  Future<void> _toggle(bool value) async {
    setState(() {
      _busy = true;
      _protected = value;
    });
    final ok = await context.read<WhatsAppProvider>().setSenderProtected(
      widget.sender.id,
      value,
    );
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok['success'] != true) _protected = !value;
    });
    if (ok['success'] != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 91),
          content: Text('Gagal memperbarui proteksi.'),
          backgroundColor: NeoColors.pink,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.sender;
    return NeoCard(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _protected
                      ? const [NeoColors.green, Color(0xFF00695C)]
                      : const [NeoColors.grey, Color(0xFF555555)],
                ),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
              ),
              child: Icon(
                _protected ? Icons.shield : Icons.shield_outlined,
                size: 16,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: NeoSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    formatPhone(s.phoneNumber),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.primaryText,
                    ),
                  ),
                  Text(
                    s.sessionName.isNotEmpty
                        ? s.sessionName
                        : statusLabel(s.status),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10, color: NeoColors.grey),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            _busy
                ? const NeoBlockLoader(compact: true, size: 18)
                : GestureDetector(
                    onTap: () => _toggle(!_protected),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        gradient: _protected
                            ? const LinearGradient(
                                colors: [NeoColors.green, Color(0xFF00695C)],
                              )
                            : null,
                        color: _protected ? null : Colors.transparent,
                        borderRadius: BorderRadius.circular(NeoRadius.md),
                        border: Border.all(
                          color: _protected
                              ? NeoColors.green
                              : const Color(0x55FFFFFF),
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _protected
                                ? Icons.verified_user
                                : Icons.gpp_bad_outlined,
                            size: 14,
                            color: _protected ? Colors.white : NeoColors.grey,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _protected ? 'PROTEKSI ON' : 'PROTEKSI OFF',
                            style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              color: _protected ? Colors.white : NeoColors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

class _CarouselOption {
  final String id;
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  const _CarouselOption({
    required this.id,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
  });
}

class _CarouselPicker extends StatefulWidget {
  final List<_CarouselOption> options;
  final String emptyLabel;
  final int initialIndex;
  final ValueChanged<int> onChanged;

  const _CarouselPicker({
    required this.options,
    required this.emptyLabel,
    required this.initialIndex,
    required this.onChanged,
  });

  @override
  State<_CarouselPicker> createState() => _CarouselPickerState();
}

class _CarouselPickerState extends State<_CarouselPicker> {
  late final PageController _ctrl;
  int _current = 0;

  @override
  void initState() {
    super.initState();
    _current = widget.options.isEmpty
        ? 0
        : widget.initialIndex.clamp(0, widget.options.length - 1);
    _ctrl = PageController(initialPage: _current);
  }

  @override
  void didUpdateWidget(_CarouselPicker old) {
    super.didUpdateWidget(old);
    final target = widget.options.isEmpty
        ? 0
        : widget.initialIndex.clamp(0, widget.options.length - 1);
    if (widget.options.length != old.options.length && target != _current) {
      _current = target;
      _ctrl.jumpToPage(target);
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (widget.options.isEmpty) {
      return ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 68),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: isDark ? 0.06 : 0.45),
            border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
            borderRadius: BorderRadius.circular(NeoRadius.md),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.chat_bubble_outline,
                size: 18,
                color: NeoColors.grey,
              ),
              const SizedBox(height: 4),
              Text(
                widget.emptyLabel,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: NeoColors.grey),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      children: [
        SizedBox(
          height: 60,
          child: PageView.builder(
            controller: _ctrl,
            onPageChanged: (i) {
              setState(() => _current = i);
              widget.onChanged(i);
            },
            itemCount: widget.options.length,
            itemBuilder: (ctx, i) {
              final o = widget.options[i];
              final selected = i == _current;
              return GestureDetector(
                onTap: () => _ctrl.animateToPage(
                  i,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                ),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    gradient: selected
                        ? const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFFFFE3A3), Color(0xFFD9B35F)],
                          )
                        : null,
                    color: selected
                        ? null
                        : Colors.white.withValues(alpha: isDark ? 0.06 : 0.45),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFF8A6D2B)
                          : NeoColors.gold.withValues(alpha: 85 / 255),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(NeoRadius.md),
                    boxShadow: selected ? NeoShadows.smD(isDark) : null,
                  ),
                  child: Row(
                    children: [
                      Icon(
                        o.icon,
                        size: 18,
                        color: selected ? const Color(0xFF4A3800) : o.color,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              o.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: selected
                                    ? const Color(0xFF2A1E00)
                                    : (isDark
                                          ? NeoColors.primaryText
                                          : NeoColors.black),
                              ),
                            ),
                            const SizedBox(height: 1),
                            Text(
                              o.subtitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 10,
                                color: selected
                                    ? const Color(0x992A1E00)
                                    : NeoColors.grey,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 6),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 6,
          runSpacing: 4,
          children: List.generate(widget.options.length, (i) {
            final active = i == _current;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: active ? 20 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: active ? NeoColors.yellow : NeoColors.grey,
                border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
                borderRadius: BorderRadius.circular(NeoRadius.sm),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _ExecResult {
  final bool ok;
  final String message;
  const _ExecResult(this.ok, this.message);
}

/// Eksekusi fungsi WA dengan panel Roman TANPA animasi (tanpa stamp/spinner).
/// Menampilkan tahapan sebagai baris statis; hasil muncul dengan pesan asli
/// dari server. Tidak menggunakan TickerProvider sama sekali.
Future<_ExecResult?> _showRomanExec(
  BuildContext context,
  Future<Map<String, dynamic>> Function() execute, {
  String title = 'EKSEKUSI',
  List<String> stages = const ['KIRIM KE SERVER', 'PROSES', 'LAPORAN TERKIRIM'],
}) {
  return showDialog<_ExecResult>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _RomanExecPanel(execute: execute, title: title, stages: stages),
  );
}

class _RomanExecPanel extends StatefulWidget {
  final Future<Map<String, dynamic>> Function() execute;
  final String title;
  final List<String> stages;
  const _RomanExecPanel({
    required this.execute,
    required this.title,
    required this.stages,
  });

  @override
  State<_RomanExecPanel> createState() => _RomanExecPanelState();
}

class _RomanExecPanelState extends State<_RomanExecPanel> {
  int _step = 0;
  bool _done = false;
  bool _ok = false;
  String _info = 'Menghubungkan ke server...';

  @override
  void initState() {
    super.initState();
    _work();
  }

  Future<void> _work() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      setState(() {
        _step = 1;
        _info = 'Menjalankan fungsi...';
      });
      final result = await widget.execute();
      if (!mounted) return;
      if (result['success'] == true) {
        setState(() {
          _step = widget.stages.length;
          _done = true;
          _ok = true;
          _info = 'Semua perintah terkirim ke target.';
        });
        await Future.delayed(const Duration(milliseconds: 500));
        if (mounted) Navigator.of(context).pop(_ExecResult(true, _info));
      } else {
        final em = result['error']?['message']?.toString() ?? 'Gagal mengirim. Coba lagi.';
        setState(() {
          _step = widget.stages.length;
          _done = true;
          _ok = false;
          _info = em;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: RomanDialog(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              RomanSheetTitle(widget.title, fontSize: 15),
              const SizedBox(height: 4),
              Center(
                child: Text(
                  'NOVACORE • WA REPORT',
                  style: TextStyle(
                    fontSize: 9,
                    letterSpacing: 2,
                    color: NeoColors.gold.withValues(alpha: 128 / 255),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              for (var i = 0; i < widget.stages.length; i++)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _StaticStageRow(
                    index: i,
                    label: widget.stages[i],
                    state: i < _step
                        ? _StaticStage.done
                        : (i == _step
                            ? _StaticStage.active
                            : _StaticStage.pending),
                  ),
                ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0x14FFFFFF),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: NeoColors.gold.withValues(alpha: 46 / 255), width: 1),
                ),
                child: Text(
                  _info,
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.4,
                    color: _done && !_ok
                        ? const Color(0xFFFF9BB0)
                        : NeoColors.marble,
                  ),
                ),
              ),
              if (_done && _ok) ...[
                const SizedBox(height: 14),
                const Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_circle_rounded,
                          color: Color(0xFF55E878), size: 18),
                      SizedBox(width: 8),
                      Text(
                        'SELESAI • TERKIRIM',
                        style: TextStyle(
                          fontSize: 10,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF55E878),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              if (_done && !_ok) ...[
                const SizedBox(height: 16),
                NeoButton(
                  label: 'TUTUP',
                  bgColor: NeoColors.pink,
                  textColor: NeoColors.white,
                  height: 42,
                  fontSize: 13,
                  roman: true,
                  onPressed: () =>
                      Navigator.of(context).pop(_ExecResult(false, _info)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

enum _StaticStage { pending, active, done }

class _StaticStageRow extends StatelessWidget {
  final int index;
  final String label;
  final _StaticStage state;

  const _StaticStageRow({
    required this.index,
    required this.label,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    final done = state == _StaticStage.done;
    final active = state == _StaticStage.active;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xCC1F1330),
        border: Border.all(
          color: done || active ? NeoColors.gold : const Color(0x224F4F66),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: done ? NeoColors.gold : NeoColors.ink,
              border: Border.all(color: NeoColors.gold.withValues(alpha: 85 / 255), width: 1),
              borderRadius: BorderRadius.circular(4),
            ),
            alignment: Alignment.center,
            child: done
                ? const Icon(
                    Icons.check_rounded,
                    size: 14,
                    color: Color(0xFF111111),
                  )
                : Text(
                    '${index + 1}',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: NeoColors.gold,
                    ),
                  ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                color: state == _StaticStage.pending
                    ? const Color(0x77B8B8CF)
                    : NeoColors.marble,
              ),
            ),
          ),
          if (done)
            Icon(Icons.done, size: 14, color: NeoColors.gold)
          else if (active)
            Icon(Icons.arrow_right_alt_rounded,
                size: 16, color: NeoColors.gold.withValues(alpha: 153 / 255))
          else
            const Icon(Icons.radio_button_unchecked,
                size: 12, color: Color(0x77B8B8CF)),
        ],
      ),
    );
  }
}
