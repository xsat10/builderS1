import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/auth_provider.dart';
import 'providers/device_provider.dart';
import 'providers/connection_provider.dart';
import 'providers/news_provider.dart';
import 'providers/whatsapp_provider.dart';
import 'providers/app_refresh_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/public_chat_unread_provider.dart';
import 'app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppRefreshProvider()),
        ChangeNotifierProvider(create: (_) => DeviceProvider()),
        ChangeNotifierProxyProvider<DeviceProvider, AuthProvider>(
          create: (_) => AuthProvider(),
          update: (_, dp, ap) {
            ap!.attachDeviceProvider(dp);
            return ap;
          },
        ),
        ChangeNotifierProvider(create: (_) => ConnectionProvider()),
        ChangeNotifierProvider(create: (_) => NewsProvider()),
        ChangeNotifierProvider(create: (_) => WhatsAppProvider()),
        ChangeNotifierProvider<NeoThemeProvider>(
          create: (_) => NeoThemeProvider()..loadFromDisk(),
        ),
        ChangeNotifierProvider(create: (_) => PublicChatUnreadProvider()),
      ],
      child: const NovaGuardControlApp(),
    ),
  );
}
