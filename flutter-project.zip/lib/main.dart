import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const NullxApp());
}

class NullxApp extends StatelessWidget {
  const NullxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const DashboardPanel(),
    );
  }
}

class DashboardPanel extends StatefulWidget {
  const DashboardPanel({super.key});

  @override
  State<DashboardPanel> createState() => _DashboardPanelState();
}

class _DashboardPanelState extends State<DashboardPanel> {
  static const _methodChannel = MethodChannel('com.nullx.pp/spy_channel');
  String _localPairId = "Loading...";

  @override
  void initState() {
    super.initState();
    _readConfig();
  }

  // Membaca file json di sisi Flutter UI sekadar untuk validasi tampilan
  Future<void> _readConfig() async {
    try {
      final String response = await rootBundle.loadString('assets/config.json');
      final data = json.decode(response);
      setState(() {
        _localPairId = data['pairId'] ?? 'ID tidak ditemukan';
      });
    } catch (e) {
      setState(() {
        _localPairId = 'Gagal memuat file config.json';
      });
    }
  }

  Future<void> _triggerNativeActivation() async {
    try {
      // Memanggil native tanpa beban parameter kiriman
      final String response = await _methodChannel.invokeMethod(
        'startSpyService',
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(response), backgroundColor: Colors.green),
      );
    } on PlatformException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error: ${e.message}"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nullx System Control')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Pair ID Terkunci di config.json:',
                style: TextStyle(fontSize: 14, color: Colors.white64),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12),
                ),
                child: Text(
                  _localPairId,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.amber,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: _triggerNativeActivation,
                icon: const Icon(Icons.power_settings_new),
                label: const Text('Inisialisasi Sistem Latar Belakang'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 14,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
