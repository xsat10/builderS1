import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'splash_dashboard.dart';
import 'otw_landing.dart';
import 'intro_fingerprint_page.dart';
import 'widgets/tap_logo_overlay.dart';
import 'global_theme.dart';
import 'color_settings_page.dart';

// ═══════════════════════════════════════════════════════════════
// GLOBAL NAVIGATOR KEY
// ═══════════════════════════════════════════════════════════════
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ─────────────────────────────────────────────
//  COLOR SYSTEM — FALLBACK STATIS
// ─────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF050A12);
  static const surface   = Color(0xFF0A1525);
  static const card      = Color(0xFF0E1E35);
  static const border    = Color(0xFF162B4A);
  static const borderLit = Color(0xFF1E3F6E);

  static const steel     = Color(0xFF1A4F8A);
  static const blueMid   = Color(0xFF2370BE);
  static const blueLight = Color(0xFF4A94E8);
  static const chrome    = Color(0xFF7AB4E8);
  static const frost     = Color(0xFFADD4F5);

  static const green     = Color(0xFF22C55E);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);

  static const text      = Color(0xFFDEEEFB);
  static const textSub   = Color(0xFF6A92B8);
  static const textDim   = Color(0xFF2E4E6E);
}

// ─────────────────────────────────────────────
//  THEME BUILDER
// ─────────────────────────────────────────────
class _AppTheme {
  static const _font = 'ShareTechMono';

  static ThemeData build(Color primaryColor) {
    final bgTop     = GlobalTheme.bgTop;
    final surface   = GlobalTheme.cardBg;
    final card      = GlobalTheme.darken(primaryColor, 0.65);
    final border    = primaryColor.withOpacity(0.25);
    final borderLit = primaryColor.withOpacity(0.5);
    final blueLight = primaryColor;
    final chrome    = GlobalTheme.lighten(primaryColor, 0.15);
    final frost     = GlobalTheme.lighten(primaryColor, 0.3);
    final steel     = GlobalTheme.darken(primaryColor, 0.3);
    final text      = Colors.white;
    final textSub   = Colors.white.withOpacity(0.65);
    final textDim   = Colors.white.withOpacity(0.35);

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      fontFamily: _font,
      scaffoldBackgroundColor: bgTop,

      colorScheme: ColorScheme.dark(
        brightness:              Brightness.dark,
        primary:                 blueLight,
        onPrimary:               Colors.black,
        primaryContainer:        steel,
        onPrimaryContainer:      frost,
        secondary:               chrome,
        onSecondary:             Colors.black,
        secondaryContainer:      borderLit,
        onSecondaryContainer:    text,
        tertiary:                _C.green,
        onTertiary:              Colors.black,
        error:                   _C.red,
        onError:                 text,
        surface:                 surface,
        onSurface:               text,
        surfaceContainerHighest: card,
        outline:                 border,
        outlineVariant:          borderLit,
        shadow:                  Colors.black,
        scrim:                   Colors.black87,
        inverseSurface:          frost,
        onInverseSurface:        bgTop,
        inversePrimary:          steel,
      ),

      appBarTheme: AppBarTheme(
        backgroundColor:        surface,
        foregroundColor:        text,
        elevation:              0,
        scrolledUnderElevation: 0,
        centerTitle:            false,
        titleTextStyle: TextStyle(
          fontFamily:    _font,
          fontSize:      18,
          fontWeight:    FontWeight.w600,
          color:         text,
          letterSpacing: 0.4,
        ),
        iconTheme:        IconThemeData(color: chrome, size: 22),
        actionsIconTheme: IconThemeData(color: textSub, size: 20),
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor:                    Colors.transparent,
          statusBarIconBrightness:           Brightness.light,
          statusBarBrightness:               Brightness.dark,
          systemNavigationBarColor:          bgTop,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
      ),

      cardTheme: CardThemeData(
        color:     card,
        elevation: 0,
        margin:    EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: border, width: 1),
        ),
        clipBehavior: Clip.antiAlias,
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return border;
            if (s.contains(WidgetState.pressed))  return steel;
            return blueLight;
          }),
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return textDim;
            return Colors.black;
          }),
          overlayColor:  WidgetStateProperty.all(frost.withOpacity(0.1)),
          elevation:     WidgetStateProperty.all(0),
          shadowColor:   WidgetStateProperty.all(Colors.transparent),
          padding:       WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
              fontFamily: _font,
              fontSize: 14,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.8,
            ),
          ),
          animationDuration: const Duration(milliseconds: 180),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return frost;
            return chrome;
          }),
          side: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed))
              return BorderSide(color: chrome, width: 1.5);
            if (s.contains(WidgetState.focused))
              return BorderSide(color: blueLight, width: 1.5);
            return BorderSide(color: borderLit, width: 1);
          }),
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed))
              return blueLight.withOpacity(0.08);
            return Colors.transparent;
          }),
          overlayColor: WidgetStateProperty.all(blueLight.withOpacity(0.06)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
              fontFamily: _font,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ),

      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return frost;
            return chrome;
          }),
          overlayColor: WidgetStateProperty.all(blueLight.withOpacity(0.08)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
              fontFamily: _font,
              fontSize: 13,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.4,
            ),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled:         true,
        fillColor:      surface,
        hoverColor:     card,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   BorderSide(color: border, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   BorderSide(color: border, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   BorderSide(color: blueLight, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   const BorderSide(color: _C.red, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   const BorderSide(color: _C.red, width: 1.5),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:   BorderSide(color: textDim, width: 1),
        ),
        labelStyle:         TextStyle(color: textSub, fontSize: 13),
        hintStyle:          TextStyle(color: textDim, fontSize: 13),
        errorStyle:         const TextStyle(color: _C.red, fontSize: 11),
        prefixIconColor:    textSub,
        suffixIconColor:    textSub,
        floatingLabelStyle: TextStyle(color: blueLight, fontSize: 12),
      ),

      chipTheme: ChipThemeData(
        backgroundColor:     surface,
        selectedColor:       steel,
        disabledColor:       border,
        deleteIconColor:     textSub,
        labelStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
        secondaryLabelStyle: TextStyle(color: frost, fontSize: 12, fontFamily: _font),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side:         BorderSide(color: border),
        ),
        side:           BorderSide(color: border),
        elevation:      0,
        pressElevation: 0,
        showCheckmark:  false,
      ),

      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor:     surface,
        selectedItemColor:   blueLight,
        unselectedItemColor: textDim,
        elevation:           0,
        type:                BottomNavigationBarType.fixed,
        selectedLabelStyle: const TextStyle(
            fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w600),
        unselectedLabelStyle:
            const TextStyle(fontSize: 10, fontFamily: _font),
      ),

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor:  steel.withOpacity(0.45),
        iconTheme: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected))
            return IconThemeData(color: blueLight, size: 22);
          return IconThemeData(color: textDim, size: 22);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return TextStyle(
                color: blueLight,
                fontSize: 11,
                fontFamily: _font,
                fontWeight: FontWeight.w600);
          }
          return TextStyle(color: textDim, fontSize: 11, fontFamily: _font);
        }),
        elevation:     0,
        overlayColor:  WidgetStateProperty.all(blueLight.withOpacity(0.06)),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      ),

      drawerTheme: DrawerThemeData(
        backgroundColor:  surface,
        elevation:        0,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight:    Radius.circular(24),
            bottomRight: Radius.circular(24),
          ),
        ),
      ),

      dialogTheme: DialogThemeData(
        backgroundColor:  card,
        elevation:        0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side:         BorderSide(color: borderLit, width: 1),
        ),
        titleTextStyle: TextStyle(
          fontFamily:    _font,
          fontSize:      18,
          fontWeight:    FontWeight.w700,
          color:         text,
          letterSpacing: 0.2,
        ),
        contentTextStyle: TextStyle(
          fontFamily: _font,
          fontSize:   14,
          color:      textSub,
          height:     1.6,
        ),
      ),

      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor:      surface,
        modalBackgroundColor: surface,
        elevation:            0,
        modalElevation:       0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        showDragHandle:  true,
        dragHandleColor: borderLit,
        dragHandleSize:  const Size(40, 4),
        clipBehavior:    Clip.antiAlias,
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor:  card,
        contentTextStyle:
            TextStyle(color: text, fontFamily: _font, fontSize: 13),
        actionTextColor:  blueLight,
        behavior:         SnackBarBehavior.floating,
        elevation:        0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side:         BorderSide(color: borderLit, width: 1),
        ),
      ),

      tabBarTheme: TabBarThemeData(
        labelColor:           blueLight,
        unselectedLabelColor: textDim,
        indicatorColor:       blueLight,
        indicatorSize:        TabBarIndicatorSize.label,
        labelStyle: const TextStyle(
            fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600),
        unselectedLabelStyle:
            const TextStyle(fontFamily: _font, fontSize: 13),
        overlayColor: WidgetStateProperty.all(blueLight.withOpacity(0.06)),
        dividerColor: border,
      ),

      listTileTheme: ListTileThemeData(
        tileColor:         Colors.transparent,
        selectedTileColor: blueLight.withOpacity(0.1),
        iconColor:         textSub,
        selectedColor:     blueLight,
        textColor:         text,
        subtitleTextStyle: TextStyle(color: textSub, fontSize: 12),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
      ),

      dividerTheme: DividerThemeData(
        color:     border,
        thickness: 1,
        space:     1,
      ),

      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return blueLight;
          return textDim;
        }),
        trackColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected))
            return steel.withOpacity(0.5);
          return border;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
        overlayColor:      WidgetStateProperty.all(blueLight.withOpacity(0.08)),
      ),

      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return blueLight;
          return Colors.transparent;
        }),
        checkColor:   WidgetStateProperty.all(Colors.black),
        side:         BorderSide(color: borderLit, width: 1.5),
        shape:        RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4)),
        overlayColor: WidgetStateProperty.all(blueLight.withOpacity(0.08)),
      ),

      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return blueLight;
          return textDim;
        }),
        overlayColor: WidgetStateProperty.all(blueLight.withOpacity(0.08)),
      ),

      sliderTheme: SliderThemeData(
        activeTrackColor:    blueLight,
        inactiveTrackColor:  border,
        thumbColor:          blueLight,
        overlayColor:        blueLight.withOpacity(0.12),
        valueIndicatorColor: steel,
        valueIndicatorTextStyle:
            TextStyle(color: text, fontSize: 12, fontFamily: _font),
        trackHeight: 3,
        thumbShape:  const RoundSliderThumbShape(enabledThumbRadius: 7),
      ),

      progressIndicatorTheme: ProgressIndicatorThemeData(
        color:              blueLight,
        linearTrackColor:   border,
        circularTrackColor: border,
        linearMinHeight:    3,
      ),

      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor:    blueLight,
        foregroundColor:    Colors.black,
        elevation:          0,
        focusElevation:     0,
        hoverElevation:     0,
        highlightElevation: 0,
        splashColor:        frost.withOpacity(0.2),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
      ),

      iconTheme:        IconThemeData(color: chrome, size: 22),
      primaryIconTheme: IconThemeData(color: blueLight, size: 22),

      popupMenuTheme: PopupMenuThemeData(
        color:            card,
        elevation:        0,
        shadowColor:      Colors.transparent,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side:         BorderSide(color: borderLit, width: 1),
        ),
        textStyle:
            TextStyle(color: text, fontFamily: _font, fontSize: 13),
        labelTextStyle: WidgetStateProperty.all(
          TextStyle(color: text, fontFamily: _font, fontSize: 13),
        ),
        iconColor: textSub,
      ),

      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color:        surface,
          borderRadius: BorderRadius.circular(8),
          border:       Border.all(color: borderLit),
        ),
        textStyle:
            TextStyle(color: text, fontSize: 11, fontFamily: _font),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),

      scrollbarTheme: ScrollbarThemeData(
        thumbColor:      WidgetStateProperty.all(borderLit),
        trackColor:      WidgetStateProperty.all(surface),
        radius:          const Radius.circular(4),
        thickness:       WidgetStateProperty.all(3),
        crossAxisMargin: 2,
      ),

      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: _SteelTransitionBuilder(),
          TargetPlatform.iOS:     _SteelTransitionBuilder(),
          TargetPlatform.windows: _SteelTransitionBuilder(),
          TargetPlatform.macOS:   _SteelTransitionBuilder(),
          TargetPlatform.linux:   _SteelTransitionBuilder(),
        },
      ),

      textTheme: TextTheme(
        displayLarge: TextStyle(
            fontFamily: _font, fontSize: 57, fontWeight: FontWeight.w800,
            color: text, letterSpacing: -1.5),
        displayMedium: TextStyle(
            fontFamily: _font, fontSize: 45, fontWeight: FontWeight.w700,
            color: text, letterSpacing: -1.0),
        displaySmall: TextStyle(
            fontFamily: _font, fontSize: 36, fontWeight: FontWeight.w700,
            color: text, letterSpacing: -0.5),
        headlineLarge: TextStyle(
            fontFamily: _font, fontSize: 32, fontWeight: FontWeight.w700,
            color: text, letterSpacing: -0.3),
        headlineMedium: TextStyle(
            fontFamily: _font, fontSize: 26, fontWeight: FontWeight.w600,
            color: text, letterSpacing: -0.2),
        headlineSmall: TextStyle(
            fontFamily: _font, fontSize: 22, fontWeight: FontWeight.w600,
            color: text),
        titleLarge: TextStyle(
            fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600,
            color: text, letterSpacing: 0.2),
        titleMedium: TextStyle(
            fontFamily: _font, fontSize: 15, fontWeight: FontWeight.w500,
            color: text, letterSpacing: 0.1),
        titleSmall: TextStyle(
            fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500,
            color: textSub),
        bodyLarge: TextStyle(
            fontFamily: _font, fontSize: 16, fontWeight: FontWeight.w400,
            color: text, height: 1.6),
        bodyMedium: TextStyle(
            fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w400,
            color: text, height: 1.6),
        bodySmall: TextStyle(
            fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w400,
            color: textSub, height: 1.5),
        labelLarge: TextStyle(
            fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600,
            color: text, letterSpacing: 0.5),
        labelMedium: TextStyle(
            fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w500,
            color: textSub, letterSpacing: 0.4),
        labelSmall: TextStyle(
            fontFamily: _font, fontSize: 10, fontWeight: FontWeight.w500,
            color: textDim, letterSpacing: 0.6),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  CUSTOM PAGE TRANSITION
// ─────────────────────────────────────────────
class _SteelTransitionBuilder extends PageTransitionsBuilder {
  const _SteelTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(
        parent: animation, curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(
        parent: secondaryAnimation, curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.035),
          end:   Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity:
              Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
          child: ScaleTransition(
            scale:
                Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  HELPER: FINGERPRINT PAGE BUILDER
//  ✅ FIX: Pakai IntroFingerprintPage (bukan FingerprintAccessPage)
// ─────────────────────────────────────────────
Widget _buildFingerprintPage() {
  return IntroFingerprintPage(
    onVerified: () {
      navigatorKey.currentState?.pushReplacementNamed('/otw_landing');
    },
  );
}

// ─────────────────────────────────────────────
//  ROUTE BUILDER
// ─────────────────────────────────────────────
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
      page = _buildFingerprintPage();
      break;

    case '/otw_landing':
      page = const OtwLandingPage();
      break;

    case '/login':
      page = const LoginPage();
      break;

    case '/landing':
      page = const LandingPage();
      break;

    case '/splash_dashboard':
      page = SplashDashboardPage(data: args);
      break;

    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );
      break;

    case '/home':
      page = HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );
      break;

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
      break;

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
      break;

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );
      break;

    case '/color_settings':
      page = const ColorSettingsPage();
      break;

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
      break;
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(
          parent: animation, curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(
          parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end:   Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity:
                Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale:
                  Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ─────────────────────────────────────────────
//  404 PAGE
// ─────────────────────────────────────────────
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 800))
      ..forward();

    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
            begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(
            CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final primary = GlobalTheme.primary;
    final bgTop   = GlobalTheme.bgTop;

    return Scaffold(
      backgroundColor: bgTop,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glow,
                    builder: (_, child) => Container(
                      width: 88, height: 88,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: GlobalTheme.cardBg,
                        border: Border.all(
                            color: primary.withOpacity(0.5),
                            width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: primary.withOpacity(
                                0.18 * _glow.value),
                            blurRadius:   40,
                            spreadRadius: 6,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: Icon(Icons.explore_off_rounded,
                        color: primary, size: 34),
                  ),

                  const SizedBox(height: 28),

                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0.35),
                        primary.withOpacity(0.5),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      '404',
                      style: TextStyle(
                        fontFamily:    'ShareTechMono',
                        fontSize:      72,
                        fontWeight:    FontWeight.w800,
                        color:         Colors.white,
                        height:        1,
                        letterSpacing: -3,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  const Text(
                    'Route not found',
                    style: TextStyle(
                      fontFamily:    'ShareTechMono',
                      fontSize:      16,
                      fontWeight:    FontWeight.w600,
                      color:         Colors.white70,
                      letterSpacing: 0.3,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color:        GlobalTheme.cardBg,
                      borderRadius: BorderRadius.circular(6),
                      border:       Border.all(
                          color: primary.withOpacity(0.3)),
                    ),
                    child: Text(
                      '"${widget.routeName}"',
                      style: const TextStyle(
                        fontFamily:    'ShareTechMono',
                        fontSize:      12,
                        color:         Colors.white54,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),

                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context)
                        .pushNamedAndRemoveUntil('/', (_) => false),
                    icon:  const Icon(Icons.arrow_back_rounded, size: 16),
                    label: const Text('Back to Home'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.light,
    statusBarBrightness:               Brightness.dark,
    systemNavigationBarColor:          Color(0xFF050A12),
    systemNavigationBarDividerColor:   Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _OrcaApp());
}

// ─────────────────────────────────────────────
//  ROOT APP WIDGET
// ─────────────────────────────────────────────
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: GlobalTheme.primaryNotifier,
      builder: (context, primaryColor, _) {
        final bgTop = GlobalTheme.bgTop;

        SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
          statusBarColor:                    Colors.transparent,
          statusBarIconBrightness:           Brightness.light,
          statusBarBrightness:               Brightness.dark,
          systemNavigationBarColor:          bgTop,
          systemNavigationBarDividerColor:   Colors.transparent,
          systemNavigationBarIconBrightness: Brightness.light,
        ));

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title:           'BE4X EXES',
          navigatorKey:    navigatorKey,
          theme:           _AppTheme.build(primaryColor),
          initialRoute:    '/',
          onGenerateRoute: _generateRoute,

          builder: (context, child) {
            final mq = MediaQuery.of(context);
            return MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(
                  mq.textScaleFactor.clamp(0.85, 1.2),
                ),
              ),
              child: TapLogoOverlay(
                logoAsset: 'assets/images/logo.png',
                child: child ?? const SizedBox.shrink(),
              ),
            );
          },
        );
      },
    );
  }
}