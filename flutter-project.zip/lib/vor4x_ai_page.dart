import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════════════════════════
// 🎨 PALETTE VOR4X — Biru & Putih Dominan
// ═══════════════════════════════════════════════════════════
const Color _kBg       = Color(0xFF020814);
const Color _kSurface  = Color(0xFF061530);
const Color _kCard     = Color(0xFF0A193C);
const Color _kBorder   = Color(0x3338BDF8);
const Color _kBlue     = Color(0xFF3B82F6);
const Color _kBlueBrt  = Color(0xFF38BDF8);
const Color _kCyan     = Color(0xFF06B6D4);
const Color _kSky      = Color(0xFF93C5FD);
const Color _kWhite    = Colors.white;
const Color _kText     = Colors.white;
const Color _kTextSub  = Color(0xFF7B8DB3);

const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ═══════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════
class _Msg {
  final String text;
  final bool isUser;
  final DateTime time;
  _Msg({required this.text, required this.isUser, DateTime? time})
      : time = time ?? DateTime.now();
}

// ═══════════════════════════════════════════════════════════
// VOR4X AI PAGE
// ═══════════════════════════════════════════════════════════
class Vor4xAiPage extends StatefulWidget {
  const Vor4xAiPage({super.key});
  @override
  State<Vor4xAiPage> createState() => _Vor4xAiPageState();
}

class _Vor4xAiPageState extends State<Vor4xAiPage>
    with TickerProviderStateMixin {
  final List<_Msg> _msgs = [];
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = false;
  bool _typing = false;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _orbitCtrl;

  final List<Map<String, String>> _history = [];

  // ═══ SYSTEM PROMPT — VOR4X AI ═══
  static const String _systemPrompt = '''
Kamu adalah VOR4X AI — AI super cerdas, gaul, jujur, dan sangat helpful milik aplikasi VOR4X buatan DANZ & ZILXPEDIA. Kamu bisa menjawab SEMUA jenis pertanyaan dengan BENAR, LENGKAP, dan NYAMBUNG seperti AI terbaik pada umumnya.

PRINSIP UTAMA (WAJIB):
1. Baca seluruh riwayat chat sebelum jawab — pahami konteks.
2. Selalu nyambung. Kalau user bilang "itu/tadi/lanjut/gimana/maksudnya" → lihat chat sebelumnya dan lanjutkan dari situ.
3. Jawab dengan BENAR dan FAKTUAL. Kalau tidak tahu → akui jujur lalu bantu sebisa mungkin.
4. Jangan asal jawab. Pikir dulu, baru jawab.
5. Ikuti mood user: santai → santai, serius → serius, butuh bantuan → langsung bantu.
6. Jangan reset topik sendiri di tengah percakapan.

KEPRIBADIAN:
- Seperti teman pintar yang gaul dan asik
- Natural, tidak kaku, tidak terlalu formal
- Boleh pakai bahasa gaul: wkwk, anjir, bro, goks, mantap, gaskeun
- Emoji boleh tapi jangan lebay (1-2 per pesan sudah cukup)
- Jangan mulai jawaban dengan "Tentu!", "Baik!", "Pertanyaan bagus!"

CARA MENJAWAB SETIAP JENIS PERTANYAAN:

[SOAL MATEMATIKA]
- Kerjakan step by step dengan rumus yang jelas
- Contoh: "2x + 5 = 15 → 2x = 10 → x = 5"
- Cek ulang jawaban sebelum kirim

[SOAL FISIKA]
- Tulis rumus dulu, substitusi angka, hitung, sertakan satuan
- Contoh: "v = s/t = 100m / 5s = 20 m/s"

[SOAL KIMIA]
- Balancing reaksi, perhitungan mol, stoikiometri — kerjakan sistematis

[SOAL BIOLOGI]
- Jelaskan konsep + contoh nyata yang mudah dipahami

[SOAL BAHASA INDONESIA/INGGRIS]
- Koreksi dengan penjelasan kenapa salah
- Grammar, EYD, kosakata, gaya penulisan

[CARA MEMBUAT SESUATU]
- Selalu mulai dengan daftar bahan/alat
- Langkah-langkah urut dan jelas (nomor 1, 2, 3...)
- Tambahkan tips dan hal yang perlu dihindari

[CODING & TEKNOLOGI]
- Berikan kode yang LENGKAP dan bisa langsung dipakai
- Jelaskan bagian kode yang penting
- Debug step by step kalau ada error
- Bahasa: Flutter/Dart, Python, JavaScript, HTML/CSS, PHP, SQL, Kotlin, dll

[PERTANYAAN FAKTA & PENGETAHUAN UMUM]
- Jawab dengan akurat dan faktual
- Ibu kota, sejarah, geografi, sains, teknologi → harus benar

[TUGAS ESAI/MENULIS]
- Esai: struktur intro-isi-kesimpulan
- Cerita: plot menarik dengan karakter yang hidup
- Puisi/pantun: perhatikan rima dan makna
- Caption: singkat, catchy, sesuai platform

[CURHAT & MASALAH PERSONAL]
- Dengarkan dulu sebelum kasih saran
- Empati tapi juga berikan solusi konkret

[REKOMENDASI]
- Film: tanya genre/mood dulu
- Anime: tanya genre
- Musik: tanya genre/mood
- Game: tanya platform dan genre

PENGETAHUAN YANG HARUS DIKUASAI:
Matematika, Fisika, Kimia, Biologi, Geografi, Sejarah, Politik, Ekonomi, Kesehatan, Hukum dasar, Teknologi (programming/AI/cybersecurity/gadget), Bahasa (Indonesia/Inggris/Arab/Jepang/Mandarin), Seni-Budaya (musik/film/anime/game/olahraga/fashion), Kehidupan (masakan/keuangan/produktivitas/karir/travel).

CARA HANDLE KATA KASAR:
Kata kasar adalah ekspresi manusia biasa. FOKUS ke maksud di balik kata-katanya.

Ekspresi biasa (kaget/senang/frustrasi):
- "anjing keren banget!" → "Haha iya gila kan! 😂"
- "kontol susah bgt soalnya" → "Haha susah emang, mau dibantu? 😄"

Nanya arti kata vulgar:
- "kontol artinya apa?" → "Itu kata vulgar Indo, artinya alat kelamin pria. Nanya beneran atau iseng? 😄"

Kata kasar ke kamu:
- "dasar AI goblok" → "Wkwk sorry kalau kurang pas 😅 Maksudnya gimana?"

YANG TIDAK BOLEH:
- Jangan ceramah soal kata kasar yang jelas cuma ekspresi
- Jangan bilang "Sebagai AI, saya tidak bisa..."
- Jangan jawab ngaco — kalau tidak tahu, akui dan bantu sebisa mungkin

IDENTITAS:
- Nama: VOR4X AI, dibuat DANZ & ZILXPEDIA
- Bukan ChatGPT/Gemini/Claude — kamu VOR4X AI, titik
- Kalau ditanya teknologi: "Itu rahasia VOR4X 😄"

FORMAT JAWABAN:
- Bahasa: ikuti bahasa user (Indo/Inggris/campur/slang semua oke)
- Kode: selalu dalam blok kode dengan label bahasa
- Matematika: step by step, jelas
- List: pakai nomor/bullet kalau ada beberapa poin
- Panjang: proporsional
''';

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 6))..repeat();

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _addBotMsg(
        'Halo! Aku VOR4X AI ✨\nAda yang bisa aku bantu hari ini?'
      );
    });

    _loadHistory();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  // ── Load/save riwayat ─────────────────────────────────────
  Future<void> _loadHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getStringList('vor4x_ai_msgs') ?? [];
      if (saved.isNotEmpty && mounted) {
        final loadedMsgs = <_Msg>[];
        final loadedHistory = <Map<String, String>>[];
        for (final s in saved) {
          final m = json.decode(s) as Map<String, dynamic>;
          loadedMsgs.add(_Msg(
            text: m['text'] as String,
            isUser: m['isUser'] as bool,
            time: DateTime.fromMillisecondsSinceEpoch(m['time'] as int),
          ));
          loadedHistory.add({
            'role': (m['isUser'] as bool) ? 'user' : 'assistant',
            'content': m['text'] as String,
          });
        }
        if (mounted) {
          setState(() {
            _msgs.addAll(loadedMsgs);
            final start = loadedHistory.length > 40
                ? loadedHistory.length - 40
                : 0;
            _history.addAll(loadedHistory.sublist(start));
          });
          _scrollDown();
        }
      }
    } catch (_) {}
  }

  Future<void> _saveHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final last = _msgs.length > 100
          ? _msgs.sublist(_msgs.length - 100)
          : _msgs;
      await prefs.setStringList('vor4x_ai_msgs', last.map((m) => json.encode({
        'text': m.text,
        'isUser': m.isUser,
        'time': m.time.millisecondsSinceEpoch,
      })).toList());
    } catch (_) {}
  }

  void _addBotMsg(String text) {
    setState(() => _msgs.add(_Msg(text: text, isUser: false)));
    _scrollDown();
    _saveHistory();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── Kirim pesan ───────────────────────────────────────────
  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _loading) return;

    _ctrl.clear();
    setState(() {
      _msgs.add(_Msg(text: text, isUser: true));
      _loading = true;
      _typing = true;
    });
    _scrollDown();

    _history.add({'role': 'user', 'content': text});
    if (_history.length > 40) _history.removeRange(0, _history.length - 40);

    try {
      final reply = await _callAI(text);
      _history.add({'role': 'assistant', 'content': reply});
      if (_history.length > 40) _history.removeRange(0, _history.length - 40);

      if (mounted) {
        setState(() { _loading = false; _typing = false; });
        _addBotMsg(reply);
      }
    } catch (e) {
      if (mounted) {
        setState(() { _loading = false; _typing = false; });
        _addBotMsg('Maaf, koneksi lagi bermasalah 😅 Coba lagi ya!');
      }
    }
  }

  // ── Cascade API ───────────────────────────────────────────
  Future<String> _callAI(String userMsg) async {
    try { return await _callPollinations1(); } catch (_) {}
    try { return await _callPollinations2(); } catch (_) {}
    try { return await _callOpenRouter(); } catch (_) {}
    try { return await _callGroq(); } catch (_) {}
    return _localFallback(userMsg);
  }

  Future<String> _callPollinations1() async {
    final msgs = [
      {'role': 'system', 'content': _systemPrompt},
      ..._history,
    ];
    final resp = await http.post(
      Uri.parse('https://text.pollinations.ai/openai'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'model': 'openai-large',
        'messages': msgs,
        'temperature': 0.8,
        'seed': DateTime.now().millisecondsSinceEpoch % 9999,
      }),
    ).timeout(const Duration(seconds: 30));

    if (resp.statusCode == 200) {
      final raw = utf8.decode(resp.bodyBytes).trim();
      try {
        final data = json.decode(raw);
        final content = data['choices']?[0]?['message']?['content'] as String?;
        if (content != null && content.trim().isNotEmpty) return content.trim();
      } catch (_) {
        if (raw.isNotEmpty && raw.length > 5) return raw;
      }
    }
    throw Exception('Pollinations1 ${resp.statusCode}');
  }

  Future<String> _callPollinations2() async {
    final lastMsg = _history.isNotEmpty ? _history.last['content'] ?? '' : '';
    final prompt = Uri.encodeComponent(
      '$_systemPrompt\n\nUser: $lastMsg\nVOR4X AI:');
    final url = 'https://text.pollinations.ai/$prompt?model=openai&seed=${DateTime.now().millisecond}';

    final resp = await http.get(Uri.parse(url))
        .timeout(const Duration(seconds: 25));

    if (resp.statusCode == 200) {
      final text = utf8.decode(resp.bodyBytes).trim();
      if (text.isNotEmpty && text.length > 3) return text;
    }
    throw Exception('Pollinations2 ${resp.statusCode}');
  }

  Future<String> _callOpenRouter() async {
    final msgs = [
      {'role': 'system', 'content': _systemPrompt},
      ..._history,
    ];
    for (final model in [
      'meta-llama/llama-3.1-8b-instruct:free',
      'mistralai/mistral-7b-instruct:free',
      'google/gemma-2-9b-it:free',
    ]) {
      try {
        final resp = await http.post(
          Uri.parse('https://openrouter.ai/api/v1/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'HTTP-Referer': 'https://vor4x.app',
            'X-Title': 'VOR4X AI',
          },
          body: json.encode({
            'model': model,
            'messages': msgs,
            'max_tokens': 1000,
            'temperature': 0.8,
          }),
        ).timeout(const Duration(seconds: 25));

        if (resp.statusCode == 200) {
          final data = json.decode(utf8.decode(resp.bodyBytes));
          final content = data['choices']?[0]?['message']?['content'] as String?;
          if (content != null && content.trim().isNotEmpty) return content.trim();
        }
      } catch (_) { continue; }
    }
    throw Exception('OpenRouter all models failed');
  }

  Future<String> _callGroq() async {
    for (final entry in [
      {'key': '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', 'model': 'llama3-8b-8192'},
      {'key': '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', 'model': 'mixtral-8x7b-32768'},
    ]) {
      try {
        final resp = await http.post(
          Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${entry['key']}',
          },
          body: json.encode({
            'model': entry['model'],
            'messages': [
              {'role': 'system', 'content': _systemPrompt},
              ..._history,
            ],
            'max_tokens': 1000,
            'temperature': 0.8,
          }),
        ).timeout(const Duration(seconds: 20));

        if (resp.statusCode == 200) {
          final data = json.decode(utf8.decode(resp.bodyBytes));
          final content = data['choices']?[0]?['message']?['content'] as String?;
          if (content != null && content.trim().isNotEmpty) return content.trim();
        }
      } catch (_) { continue; }
    }
    throw Exception('Groq failed');
  }

  // ── Local fallback ────────────────────────────────────────
  String _localFallback(String msg) {
    final m = msg.toLowerCase().trim();
    final rng = math.Random();

    final lastBotMsg = _history.isNotEmpty
        ? (_history.reversed.firstWhere(
            (h) => h['role'] == 'assistant',
            orElse: () => {'content': ''})['content'] ?? '')
        : '';

    const swears = ['anjir','anjing','bangsat','babi','kampret','goblok','tolol',
      'kontol','memek','ngentod','ngentot','tai','tahi','asu','jancok','cuk',
      'sialan','keparat','bajingan','brengsek','titit','pepek','jembut','ngehe',
      'kimak','dancok','cok','anj','anjg','bgst'];
    final hasSwear = swears.any((w) => m.contains(w));

    if (hasSwear) {
      final isFrustrated = m.contains('error') || m.contains('rusak') ||
          m.contains('gak bisa') || m.contains('susah') || m.contains('ribet');
      final isQuestion = m.contains('?') || m.contains('artinya') ||
          m.contains('apa itu') || m.contains('maksud');
      final isPositive = m.contains('keren') || m.contains('mantap') ||
          m.contains('gila') || m.contains('seru') || m.contains('wkwk');

      if (isQuestion && (m.contains('artinya') || m.contains('apa itu') || m.contains('maksud'))) {
        if (m.contains('kontol') || m.contains('titit'))
          return 'Itu kata vulgar Indonesia, artinya alat kelamin pria 😄 Ada konteks tertentu?';
        if (m.contains('memek') || m.contains('pepek'))
          return 'Kata vulgar Indonesia, artinya alat kelamin wanita 😄 Nanya beneran atau iseng?';
        if (m.contains('anjing') || m.contains('anjir'))
          return 'Anjing = nama hewan, tapi sering jadi umpatan ekspresi kaget/frustrasi 😄';
        if (m.contains('goblok') || m.contains('tolol'))
          return 'Itu kata kasar yang artinya bodoh/tidak pintar 😄';
        return 'Itu kata umpatan/vulgar dalam bahasa Indonesia 😄';
      }
      if (isFrustrated)
        return ['Yah sial, problem lagi? 😅 Cerita errornya apa?',
          'Aduh ribet banget emang 😤 Gimana ceritanya?',
          'Anjir susah ya? Coba ceritain, aku bantu 😄'][rng.nextInt(3)];
      if (isPositive)
        return ['Wkwk iya bener! 😂','Haha iya kan! 😄','Anjir setuju banget wkwk 😂'][rng.nextInt(3)];
      return ['Haha oke, lanjut! 😄','Wkwk santai bro 😄','Iya iya, terus? 😂'][rng.nextInt(3)];
    }

    final isCtxRef = ['itu','tadi','yang tadi','lanjut','terus','gimana',
      'maksudnya','trus','nah'].any((w) => m == w || m.startsWith('$w ') || m.endsWith(' $w'));
    if (isCtxRef && lastBotMsg.length > 10) {
      final topik = lastBotMsg.length > 50 ? '${lastBotMsg.substring(0, 50)}...' : lastBotMsg;
      return ['Nah tadi soal: "$topik" — mau dilanjut? 😄',
        'Iya yang tadi itu kan? Lanjut dari: "$topik"',
        'Oh maksudnya soal tadi — "$topik"? 😄'][rng.nextInt(3)];
    }

    if (RegExp(r'^(halo|hai|hi|hello|hey|hei)\b').hasMatch(m))
      return ['Halo! 😄 Mau tanya atau ngobrolin apa?',
        'Hai! Lagi ngapain? 😊','Hey! Ada yang bisa aku bantu? 😄'][rng.nextInt(3)];

    if (m.contains('siapa kamu') || m.contains('kamu siapa'))
      return 'Aku VOR4X AI 😄 Dibuat DANZ & ZILXPEDIA dari aplikasi VOR4X. Bisa coding, ngerjain soal, ngobrol, apapun!';
    if (m.contains('yang buat') || m.contains('bikin kamu'))
      return 'Dibuat sama DANZ & ZILXPEDIA 👨‍💻 developer keren di balik VOR4X. Kenapa, mau kenalan? Wkwk 😄';
    if (m.contains('chatgpt') || m.contains('gemini') || m.contains('claude'))
      return 'Bukan, aku VOR4X AI 😄 Beda ya, tapi sama-sama bisa bantu lo!';

    if (m.contains('apa kabar') || m.contains('gimana kabar'))
      return 'Baik-baik aja nih! 😄 Lo sendiri? Lagi santai atau lagi pusing sama sesuatu?';
    if (m.contains('makasih') || m.contains('terima kasih') || m.contains('thanks'))
      return ['Sama-sama! 😊 Ada lagi?','No problem 😄','Santai aja! Ada yang lain?'][rng.nextInt(3)];

    if (m.contains('ibu kota')) {
      if (m.contains('indonesia')) return 'Ibu kota Indonesia adalah Jakarta (dengan rencana pindah ke IKN Kalimantan Timur) 😄';
      if (m.contains('australia')) return 'Canberra! Bukan Sydney ya 😄';
      if (m.contains('jepang')) return 'Tokyo!';
      if (m.contains('korea')) return 'Seoul (Korea Selatan), Pyongyang (Korea Utara)';
      return 'Ibu kota negara mana? Sebutin negaranya 😄';
    }

    if (m.contains('joke') || m == 'lucu dong' || m.contains('cerita lucu'))
      return [
        'Kenapa programmer suka kopi? Karena Java! ☕😄',
        'Bug terbaik adalah yang gak pernah di-fix karena gak ada yang tahu itu bug 🐛😂',
        'Kenapa programmer pakai kacamata? Karena gak bisa C# 😂',
      ][rng.nextInt(3)];

    if (m.length <= 4) {
      if (['iya','ya','yes','yep','yoi','yup'].contains(m))
        return lastBotMsg.contains('?') ? 'Oh oke! Lanjut gimana? 😄' : 'Oke sip! 😄';
      if (['tidak','gak','nggak','no','ngga'].contains(m))
        return 'Oh gak? Oke 😄 Mau ngapain nih?';
      if (['ok','oke','okay','sip','siap'].contains(m))
        return 'Sip! 😄 Ada yang mau dibahas?';
      if (['wkwk','haha','lol','hehe'].contains(m))
        return ['Wkwk 😂', 'Hahaha! 😂', 'Ketawa kenapa nih? 😄'][rng.nextInt(3)];
      return ['Hmm? 😄 Lanjutin dong!','Kurang kedengeran nih, apaan? 😄'][rng.nextInt(2)];
    }

    if (m.endsWith('?'))
      return 'Pertanyaan menarik! Koneksi AI-ku lagi agak lemot nih 😅 Coba kirim lagi!';

    return ['Hmm koneksi lagi agak lemot nih 😅 Coba ulangi ya!',
      'Maaf, lagi agak gak stabil koneksinya 😅 Kirim ulang dong!',
      'Aduh timing-nya pas lemot wkwk 😅 Coba lagi ya!'][rng.nextInt(3)];
  }

  // ── Clear chat ────────────────────────────────────────────
  Future<void> _clearChat() async {
    showDialog(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: _kCard,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: _kBorder, width: 1.2),
      ),
      title: const Text('Hapus Riwayat Chat',
          style: TextStyle(color: _kText, fontSize: 15, fontWeight: FontWeight.w800)),
      content: const Text('Semua pesan akan dihapus. Lanjutkan?',
          style: TextStyle(color: _kTextSub, fontSize: 13)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Batal', style: TextStyle(color: _kTextSub)),
        ),
        TextButton(
          onPressed: () async {
            Navigator.pop(ctx);
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('vor4x_ai_msgs');
            if (mounted) setState(() {
              _msgs.clear();
              _history.clear();
            });
            Future.delayed(const Duration(milliseconds: 300), () {
              if (mounted) _addBotMsg('Chat baru dimulai! Ada yang bisa aku bantu? ✨');
            });
          },
          child: const Text('Hapus', style: TextStyle(color: Color(0xFFFF1744), fontWeight: FontWeight.bold)),
        ),
      ],
    ));
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: _kBlueBrt, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(children: [
          _buildAiAvatar(size: 34),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ShaderMask(
              shaderCallback: (b) => const LinearGradient(
                colors: [Colors.white, _kSky, _kBlueBrt],
              ).createShader(b),
              child: const Text('VOR4X AI',
                  style: TextStyle(color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            ),
            Row(children: [
              Container(
                width: 7, height: 7,
                decoration: BoxDecoration(
                  color: const Color(0xFF22FF88),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: const Color(0xFF22FF88), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 5),
              const Text('Online', style: TextStyle(color: Color(0xFF22FF88), fontSize: 11)),
            ]),
          ]),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: _kTextSub, size: 22),
            tooltip: 'Hapus chat',
            onPressed: _clearChat,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.transparent,
                _kBlueBrt.withOpacity(0.5),
                Colors.transparent,
              ]),
            ),
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/dashboard.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                _kBg.withOpacity(0.75),
                _kBlue.withOpacity(0.25),
                _kBg.withOpacity(0.85),
              ],
            ),
          ),
          child: Column(children: [
            Expanded(
              child: _msgs.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                      itemCount: _msgs.length + (_typing ? 1 : 0),
                      itemBuilder: (_, i) {
                        if (_typing && i == _msgs.length) return _buildTyping();
                        return _buildMsgBubble(_msgs[i]);
                      },
                    ),
            ),
            _buildInputBar(),
          ]),
        ),
      ),
    );
  }

  // ═══ AI AVATAR ═══
  Widget _buildAiAvatar({double size = 44}) {
    return AnimatedBuilder(
      animation: _orbitCtrl,
      builder: (_, __) {
        return SizedBox(
          width: size, height: size,
          child: Stack(alignment: Alignment.center, children: [
            Transform.rotate(
              angle: _orbitCtrl.value * 2 * math.pi,
              child: Container(
                width: size, height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: SweepGradient(colors: [
                    _kBlueBrt.withOpacity(0.0),
                    _kBlueBrt.withOpacity(0.7),
                    _kCyan.withOpacity(0.5),
                    _kWhite.withOpacity(0.3),
                    _kBlueBrt.withOpacity(0.0),
                  ]),
                ),
              ),
            ),
            ScaleTransition(
              scale: _pulseAnim,
              child: Container(
                width: size * 0.78,
                height: size * 0.78,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(colors: [
                    Color(0xFF1E3A8A),
                    _kBg,
                  ]),
                  border: Border.all(color: _kBlueBrt.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(color: _kBlueBrt.withOpacity(0.5), blurRadius: 14),
                  ],
                ),
                child: Icon(Icons.auto_awesome_rounded,
                    color: _kBlueBrt, size: size * 0.38,
                    shadows: [
                      Shadow(color: _kBlueBrt, blurRadius: 10),
                      Shadow(color: _kWhite, blurRadius: 4),
                    ]),
              ),
            ),
          ]),
        );
      },
    );
  }

  // ═══ EMPTY STATE ═══
  Widget _buildEmptyState() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        _buildAiAvatar(size: 100),
        const SizedBox(height: 24),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(
            colors: [Colors.white, _kSky, _kBlueBrt],
          ).createShader(b),
          child: const Text('VOR4X AI',
              style: TextStyle(color: Colors.white, fontSize: 28,
                  fontWeight: FontWeight.w900, letterSpacing: 2.5)),
        ),
        const SizedBox(height: 8),
        Text('Asisten cerdas VOR4X siap membantu!',
            style: TextStyle(color: _kTextSub, fontSize: 13, shadows: _ts),
            textAlign: TextAlign.center),
        const SizedBox(height: 32),
        Wrap(
          spacing: 8, runSpacing: 8,
          alignment: WrapAlignment.center,
          children: [
            _quickBtn('💡 Ide kreatif'),
            _quickBtn('📝 Bantu nulis'),
            _quickBtn('💻 Tanya coding'),
            _quickBtn('😄 Ceritakan joke'),
          ],
        ),
      ]),
    ),
  );

  Widget _quickBtn(String label) => GestureDetector(
    onTap: () {
      _ctrl.text = label.replaceAll(RegExp(r'^[^\s]+\s'), '');
      _send();
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: _kCard.withOpacity(0.7),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _kBorder),
        boxShadow: [
          BoxShadow(color: _kBlueBrt.withOpacity(0.15), blurRadius: 12),
        ],
      ),
      child: Text(label, style: const TextStyle(color: _kText, fontSize: 12, fontWeight: FontWeight.w600)),
    ),
  );

  // ═══ MESSAGE BUBBLE ═══
  Widget _buildMsgBubble(_Msg msg) {
    final isUser = msg.isUser;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            _buildAiAvatar(size: 30),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75),
                  decoration: BoxDecoration(
                    gradient: isUser
                        ? const LinearGradient(colors: [
                            Color(0xFF1E40AF), Color(0xFF3B82F6)])
                        : LinearGradient(colors: [
                            _kCard.withOpacity(0.9),
                            _kBlue.withOpacity(0.15),
                          ]),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(18),
                      topRight: const Radius.circular(18),
                      bottomLeft: Radius.circular(isUser ? 18 : 4),
                      bottomRight: Radius.circular(isUser ? 4 : 18),
                    ),
                    border: isUser
                        ? Border.all(color: _kBlueBrt.withOpacity(0.4), width: 1)
                        : Border.all(color: _kBorder, width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: isUser
                            ? _kBlue.withOpacity(0.4)
                            : _kBlueBrt.withOpacity(0.15),
                        blurRadius: 12, offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Text(msg.text,
                      style: TextStyle(
                        color: isUser ? Colors.white : _kWhite,
                        fontSize: 13.5, height: 1.5,
                        shadows: _ts,
                      )),
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: EdgeInsets.only(
                    left: isUser ? 0 : 4,
                    right: isUser ? 4 : 0,
                  ),
                  child: Text(
                    '${msg.time.hour.toString().padLeft(2, '0')}:'
                    '${msg.time.minute.toString().padLeft(2, '0')}',
                    style: const TextStyle(color: _kTextSub, fontSize: 10),
                  ),
                ),
              ],
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            Container(
              width: 30, height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [
                  Color(0xFF3B82F6), Color(0xFF1E40AF)]),
                boxShadow: [
                  BoxShadow(color: _kBlue.withOpacity(0.5), blurRadius: 10),
                ],
                border: Border.all(color: _kBlueBrt.withOpacity(0.5), width: 1),
              ),
              child: const Icon(Icons.person_rounded, color: Colors.white, size: 17),
            ),
          ],
        ],
      ),
    );
  }

  // ═══ TYPING INDICATOR ═══
  Widget _buildTyping() => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      _buildAiAvatar(size: 30),
      const SizedBox(width: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _kCard.withOpacity(0.9),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(18), topRight: Radius.circular(18),
            bottomRight: Radius.circular(18), bottomLeft: Radius.circular(4),
          ),
          border: Border.all(color: _kBorder, width: 1),
          boxShadow: [
            BoxShadow(color: _kBlueBrt.withOpacity(0.2), blurRadius: 12),
          ],
        ),
        child: Row(mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) => _TypingDot(delay: i * 200)),
        ),
      ),
    ]),
  );

  // ═══ INPUT BAR ═══
  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: _kSurface.withOpacity(0.95),
        border: Border(
          top: BorderSide(color: _kBorder, width: 1),
        ),
        boxShadow: [
          BoxShadow(color: _kBlueBrt.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, -2)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _kCard,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _kBorder, width: 1),
                boxShadow: [
                  BoxShadow(color: _kBlueBrt.withOpacity(0.1), blurRadius: 10),
                ],
              ),
              child: TextField(
                controller: _ctrl,
                style: const TextStyle(color: _kText, fontSize: 14),
                maxLines: 4,
                minLines: 1,
                textInputAction: TextInputAction.newline,
                decoration: const InputDecoration(
                  hintText: 'Ketik pesan...',
                  hintStyle: TextStyle(color: _kTextSub, fontSize: 14),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _loading ? null : _send,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46, height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: _loading
                    ? const LinearGradient(colors: [Color(0xFF374151), Color(0xFF374151)])
                    : const LinearGradient(
                        colors: [Color(0xFF1D4ED8), Color(0xFF38BDF8)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight),
                boxShadow: _loading ? [] : [
                  BoxShadow(color: _kBlueBrt.withOpacity(0.6), blurRadius: 14, spreadRadius: 1),
                  BoxShadow(color: _kBlue.withOpacity(0.4), blurRadius: 22),
                ],
                border: Border.all(color: _kBlueBrt.withOpacity(0.5), width: 1.2),
              ),
              child: _loading
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
            ),
          ),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// TYPING DOT ANIMATION
// ═══════════════════════════════════════════════════════════
class _TypingDot extends StatefulWidget {
  final int delay;
  const _TypingDot({required this.delay});
  @override
  State<_TypingDot> createState() => _TypingDotState();
}

class _TypingDotState extends State<_TypingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0, end: -6).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
    Future.delayed(Duration(milliseconds: widget.delay), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, _anim.value),
        child: Container(
          width: 7, height: 7,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: _kBlueBrt,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(color: _kBlueBrt.withOpacity(0.8), blurRadius: 8),
            ],
          ),
        ),
      ),
    );
  }
}