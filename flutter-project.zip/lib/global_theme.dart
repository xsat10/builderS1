import 'dart:ui';
import 'package:flutter/material.dart';

// ═══════════════════════════════════════════════════════════════
// 🌍 GLOBAL THEME — PUSAT KONTROL WARNA SELURUH APP
// Default: BIRU KHAS VOR4X (user tetap bisa ganti warna lain)
// ═══════════════════════════════════════════════════════════════

class GlobalTheme {
  // ═════════════════════════════════════════════════════════════
  // 🎨 STATE WARNA — DEFAULT BIRU KHAS VOR4X
  // ═════════════════════════════════════════════════════════════
  static final ValueNotifier<Color> _primary =
      ValueNotifier<Color>(const Color(0xFF1565C0)); // ✅ BIRU KHAS VOR4X

  static ValueNotifier<Color> get primaryNotifier => _primary;
  static Color get primary => _primary.value;

  // ═════════════════════════════════════════════════════════════
  // 🎯 WARNA DINAMIS
  // ═════════════════════════════════════════════════════════════
  static Color get bgTop   => darken(primary, 0.9);
  static Color get bgBot   => Colors.black;
  static Color get cardBg  => darken(primary, 0.75);
  static Color get neon    => primary;
  static Color get glow    => lighten(primary, 0.1);
  static Color get border  => primary.withOpacity(0.35);
  static Color get text    => Colors.white;
  static Color get textDim => Colors.white54;

  // ═════════════════════════════════════════════════════════════
  // 🔧 SETTER
  // ═════════════════════════════════════════════════════════════
  static void setColor(Color c) => _primary.value = c;

  static void randomColor() {
    final all = [...allColors, ...signatureColors, ...neonColors];
    final idx = DateTime.now().millisecondsSinceEpoch % all.length;
    _primary.value = all[idx];
  }

  // ✅ RESET KE BIRU KHAS VOR4X
  static void reset() => _primary.value = const Color(0xFF1565C0);

  // ═════════════════════════════════════════════════════════════
  // 🎨 HELPERS
  // ═════════════════════════════════════════════════════════════
  static Color darken(Color c, [double amt = 0.6]) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness * (1 - amt)).clamp(0.0, 1.0))
        .toColor();
  }

  static Color lighten(Color c, [double amt = 0.3]) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness + amt).clamp(0.0, 1.0))
        .toColor();
  }

  static Color _darken(Color c, [double amt = 0.6]) => darken(c, amt);
  static Color _lighten(Color c, [double amt = 0.3]) => lighten(c, amt);

  // ═════════════════════════════════════════════════════════════
  // 🎁 WRAPPER GLOBAL
  // ═════════════════════════════════════════════════════════════
  static Widget wrap({required Widget child}) {
    return ValueListenableBuilder<Color>(
      valueListenable: _primary,
      builder: (context, color, _) {
        return MaterialApp(
          title: 'VOR4X',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            brightness: Brightness.dark,
            useMaterial3: true,
            scaffoldBackgroundColor: bgTop,
            primaryColor: color,
            colorScheme: ColorScheme.dark(
              primary: color,
              secondary: glow,
              surface: cardBg,
            ),
          ),
          home: child,
        );
      },
    );
  }

  // ═════════════════════════════════════════════════════════════
  // 🧊 WIDGET BANTUAN
  // ═════════════════════════════════════════════════════════════
  static BoxDecoration get bgGradient => BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [bgTop, bgBot],
        ),
      );

  static Widget glassCard({
    required Widget child,
    EdgeInsets margin = EdgeInsets.zero,
    EdgeInsets padding = const EdgeInsets.all(14),
    double radius = 16,
    double opacity = 0.35,
  }) {
    return Container(
      margin: margin,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: cardBg.withOpacity(opacity),
              borderRadius: BorderRadius.circular(radius),
              border: Border.all(color: border, width: 1.2),
              boxShadow: [
                BoxShadow(color: glow.withOpacity(0.25), blurRadius: 22),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  static Widget header(String title, String subtitle, {Widget? trailing}) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 36,
          decoration: BoxDecoration(
            color: neon,
            borderRadius: BorderRadius.circular(2),
            boxShadow: [BoxShadow(color: neon, blurRadius: 14)],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  shadows: [Shadow(color: neon, blurRadius: 14)],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(color: textDim, fontSize: 11),
              ),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    );
  }

  static Widget actionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    EdgeInsets margin = EdgeInsets.zero,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: margin,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            primary.withOpacity(0.3),
            primary.withOpacity(0.15),
          ]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: primary.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(color: primary.withOpacity(0.3), blurRadius: 14),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: primary, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: primary,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget primaryButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    EdgeInsets margin = EdgeInsets.zero,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: margin,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [primary, glow]),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: primary.withOpacity(0.6),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget avatar({
    required String imagePath,
    double size = 170,
    EdgeInsets margin = EdgeInsets.zero,
  }) {
    return Container(
      width: size,
      height: size,
      margin: margin,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: neon, width: 4),
        boxShadow: [
          BoxShadow(
            color: neon.withOpacity(1.0),
            blurRadius: 35,
            spreadRadius: 4,
          ),
          BoxShadow(
            color: glow.withOpacity(0.8),
            blurRadius: 60,
            spreadRadius: 6,
          ),
        ],
      ),
      child: ClipOval(
        child: Image.asset(
          imagePath,
          fit: BoxFit.cover,
          width: double.infinity,
          height: double.infinity,
          errorBuilder: (_, __, ___) => Container(
            color: cardBg,
            child: Icon(Icons.person, color: neon, size: size * 0.4),
          ),
        ),
      ),
    );
  }

  static Widget wallpaperOverlay({
    String asset = 'assets/images/dashboard.png',
    double opacity = 0.35,
  }) {
    return Positioned.fill(
      child: IgnorePointer(
        child: Opacity(
          opacity: opacity,
          child: Image.asset(
            asset,
            fit: BoxFit.cover,
            alignment: Alignment.center,
            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
          ),
        ),
      ),
    );
  }

  static Widget darkOverlay() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.25),
                Colors.black.withOpacity(0.55),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// 🌈 PALET WARNA — SEMUA WARNA TETAP ADA (buat ColorSettingsPage)
// ═══════════════════════════════════════════════════════════════

const List<Color> allColors = [
  Color(0xFF2E2E2E), Color(0xFF6B7B8C), Color(0xFF4A5568),
  Color(0xFF5B8FA8), Color(0xFF8FA3B8), Color(0xFF0D0D0D),
  Color(0xFF3D5A4C), Color(0xFF4A4A4A), Color(0xFFE8E8E8),
  Color(0xFFFFC107), Color(0xFFFF8C00), Color(0xFFE07A3F),
  Color(0xFFF5F5DC), Color(0xFFE8B4B8), Color(0xFF9E9E9E),
  Color(0xFFFFFFFF), Color(0xFF9C27B0), Color(0xFF7B68EE),
  Color(0xFFF0E68C), Color(0xFFB8D4D4), Color(0xFFA0522D),
  Color(0xFF8B0000), Color(0xFFCD853F), Color(0xFF6F4E37),
  Color(0xFF009688), Color(0xFFFF5722), Color(0xFFE1BEE7),
  Color(0xFF00BCD4), Color(0xFF80DEEA), Color(0xFFA5D6A7),
  Color(0xFFFF6B6B), Color(0xFFD4C44A), Color(0xFF87CEEB),
  Color(0xFFFFB6A0), Color(0xFF1B8A3A), Color(0xFFF4C430),
  Color(0xFF7B9EE0), Color(0xFFE63946), Color(0xFF4ECDC4),
  Color(0xFF7B2FBE), Color(0xFFFF9800), Color(0xFF00C853),
  Color(0xFF8A2BE2), Color(0xFFD32F2F), Color(0xFFE91E63),
  Color(0xFFF5F5F5), Color(0xFFDAA520), Color(0xFFE8F5E9),
  Color(0xFFFFA726), Color(0xFF4FC3F7), Color(0xFFFF8A65),
  Color(0xFFFF7043), Color(0xFFC62828), Color(0xFF0D47A1),
  Color(0xFF43A047), Color(0xFF8E44AD), Color(0xFFFFB300),
  Color(0xFFFDD835), Color(0xFF8BC34A), Color(0xFF26C6DA),
  Color(0xFFE57373), Color(0xFFD7CCC8), Color(0xFFA1887F),
  Color(0xFFBDBDBD), Color(0xFF7CB342), Color(0xFF8D6E63),
  Color(0xFF64B5F6), Color(0xFF607D8B), Color(0xFF1A237E),
  Color(0xFF00897B), Color(0xFFC5CAE9), Color(0xFF1DE9B6),
  Color(0xFF1B5E20), Color(0xFF00A86B), Color(0xFF66BB6A),
  Color(0xFF2E7D32), Color(0xFF4CAF50), Color(0xFF9E9D24),
  Color(0xFFC8E6C9), Color(0xFFBDB76B), Color(0xFFCCC9A1),
  Color(0xFF558B2F), Color(0xFFFF6F00), Color(0xFFFFA000),
  Color(0xFFFFF8DC), Color(0xFFB8860B), Color(0xFFFF7059),
  Color(0xFFFFEB3B), Color(0xFFFF3D00), Color(0xFFF9A825),
  Color(0xFFEF6C00), Color(0xFF00E5FF), Color(0xFF4DD0E1),
  Color(0xFF0288D1), Color(0xFF4DB6AC), Color(0xFF80CBC4),
  Color(0xFF26A69A), Color(0xFFFFCDD2), Color(0xFFB3E5FC),
  Color(0xFF90EE90), Color(0xFFCE93D8), Color(0xFFFFFACD),
  Color(0xFFFFE0B2), Color(0xFFD1C4E9), Color(0xFFFFCCBC),
  Color(0xFFE1BEE7), Color(0xFF263238),
];

const List<Color> signatureColors = [
  Color(0xFF9C27FF), Color(0xFF2979FF), Color(0xFFD4AF37),
  Color(0xFFE91E63), Color(0xFF00BFA5), Color(0xFF6200EA),
  Color(0xFFFF6B00), Color(0xFF00C853), Color(0xFFC2185B),
  Color(0xFF00695C), Color(0xFF3D5AFE), Color(0xFFAA00FF),
  Color(0xFFFF1744), Color(0xFF00E5FF), Color(0xFF76FF03),
  Color(0xFFFFAB00), Color(0xFF1DE9B6), Color(0xFFFF4081),
];

const List<Color> neonColors = [
  Color(0xFF00FF9F), Color(0xFF00FFFF), Color(0xFFFF00FF),
  Color(0xFFFFFF00), Color(0xFFFF0080), Color(0xFF00BFFF),
  Color(0xFF9D00FF), Color(0xFFFF4500), Color(0xFF39FF14),
  Color(0xFFFF1493), Color(0xFF00FF7F), Color(0xFF7FFF00),
  Color(0xFF1E90FF), Color(0xFFDC143C), Color(0xFFFFD700),
  Color(0xFF8A2BE2), Color(0xFF00CED1), Color(0xFFF0E68C),
  Color(0xFFFF69B4), Color(0xFF00FA9A),
];

const List<List<Color>> gradientColors = [
  [Color(0xFF9C27FF), Color(0xFF2979FF)],
  [Color(0xFF00D4FF), Color(0xFF00FF9F)],
  [Color(0xFFFF6B00), Color(0xFFFF1744)],
  [Color(0xFF7B2FBE), Color(0xFFE91E63)],
  [Color(0xFF00BCD4), Color(0xFF76FF03)],
  [Color(0xFFD4AF37), Color(0xFFFF6B00)],
  [Color(0xFF2979FF), Color(0xFF00E5FF)],
  [Color(0xFFE91E63), Color(0xFFFFAB00)],
  [Color(0xFF1B5E20), Color(0xFF76FF03)],
  [Color(0xFF6200EA), Color(0xFF00BFA5)],
  [Color(0xFFFF00FF), Color(0xFF00FFFF)],
  [Color(0xFFFF4500), Color(0xFFFFD700)],
  [Color(0xFF00FF9F), Color(0xFF00BFFF)],
  [Color(0xFF7B2FBE), Color(0xFFFF00FF)],
  [Color(0xFFD32F2F), Color(0xFFFF6B00)],
  [Color(0xFF00CED1), Color(0xFF1E90FF)],
];