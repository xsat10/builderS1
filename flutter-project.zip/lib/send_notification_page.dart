import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'main.dart';

// ─── 🎯 ROLE SYSTEM BARU ──────────────────────────────────────────────────────
const List<String> NOTIFICATION_ACCESS_ROLES = [
  'ceo',
  'owner',
  'admin',
  'tangan_kanan',
  'vip'
];

const Map<String, int> ROLE_LEVEL = {
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1
};

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
bool _canSendNotification(String role) {
  return NOTIFICATION_ACCESS_ROLES.contains(role.toLowerCase());
}

int getRoleLevel(String role) {
  return ROLE_LEVEL[role.toLowerCase()] ?? 0;
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

class SendNotificationPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role; // <-- TAMBAHKAN PARAMETER ROLE

  const SendNotificationPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role, // <-- TAMBAHKAN INI
  }) : super(key: key);

  @override
  State<SendNotificationPage> createState() => _SendNotificationPageState();
}

class _SendNotificationPageState extends State<SendNotificationPage> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  
  String _selectedType = "info";
  bool _isSending = false;
  String? _errorMessage;
  String? _successMessage;
  
  // Warna tema
  final Color _primaryColor = const Color(0xFFD32F2F);
  final Color _backgroundColor = const Color(0xFF0D0D0D);
  final Color _cardColor = const Color(0xFF1C1C1C);
  final Color _accentColor = const Color(0xFFFF1744);

  // List tipe notifikasi
  final List<Map<String, dynamic>> _notificationTypes = [
    {"value": "info", "label": "Informasi", "icon": Icons.info, "color": Colors.blue},
    {"value": "warning", "label": "Peringatan", "icon": Icons.warning, "color": Colors.orange},
    {"value": "success", "label": "Sukses", "icon": Icons.check_circle, "color": Colors.green},
    {"value": "error", "label": "Error", "icon": Icons.error, "color": Colors.red},
    {"value": "announcement", "label": "Pengumuman", "icon": Icons.announcement, "color": Colors.purple},
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  Future<void> _sendNotification() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() {
      _isSending = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      print("📤 Sending notification...");
      
      final response = await http.post(
        Uri.parse("http://pallmarketplace.ptdlpanel.my.id:11660/notify/send"),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'key': widget.sessionKey,
          'title': _titleController.text.trim(),
          'message': _messageController.text.trim(),
          'type': _selectedType,
        }),
      ).timeout(const Duration(seconds: 10));

      print("📤 Response status: ${response.statusCode}");
      print("📤 Response body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['success'] == true) {
          setState(() {
            _successMessage = "✅ Notifikasi berhasil dikirim!";
            _titleController.clear();
            _messageController.clear();
          });
          
          // Auto-clear success message after 3 seconds
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) {
              setState(() {
                _successMessage = null;
              });
            }
          });
        } else {
          setState(() {
            _errorMessage = data['error'] ?? "Gagal mengirim notifikasi";
          });
        }
      } else if (response.statusCode == 401) {
        setState(() {
          _errorMessage = "Session expired, silakan login ulang";
        });
      } else if (response.statusCode == 403) {
        setState(() {
          _errorMessage = "Hanya OWNER yang dapat mengirim notifikasi";
        });
      } else {
        setState(() {
          _errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      print("❌ Error sending notification: $e");
      setState(() {
        _errorMessage = "Koneksi gagal: $e";
      });
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }
    }
  }

  Widget _buildTypeChip(Map<String, dynamic> type) {
    bool isSelected = _selectedType == type['value'];
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedType = type['value'];
        });
      },
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected 
            ? type['color'].withOpacity(0.2) 
            : _cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? type['color']! : Colors.grey.withOpacity(0.3),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: type['color']!.withOpacity(0.3),
              blurRadius: 10,
              spreadRadius: 2,
            )
          ] : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              type['icon'],
              color: isSelected ? type['color'] : Colors.grey,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              type['label'],
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.grey,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── ACCESS DENIED WIDGET ──────────────────────────────────────────────────
  Widget _buildAccessDenied() {
    final roleDisplay = getRoleDisplay(widget.role);
    final roleLevel = getRoleLevel(widget.role);
    
    return Scaffold(
      backgroundColor: _backgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red.withOpacity(0.1),
                border: Border.all(
                  color: Colors.red.withOpacity(0.3),
                  width: 2,
                ),
              ),
              child: const Icon(
                Icons.lock_outline_rounded,
                color: Colors.redAccent,
                size: 48,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              "AKSES DITOLAK",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Kirim Notifikasi hanya untuk role:\nCEO, Owner, Admin, Tangan Kanan, dan VIP",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 14,
                  height: 1.6,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.orange.withOpacity(0.1),
                border: Border.all(color: Colors.orange.withOpacity(0.2)),
              ),
              child: Text(
                "Role Anda: $roleDisplay (Level $roleLevel)",
                style: TextStyle(
                  color: Colors.orangeAccent,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: 200,
              height: 48,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                label: const Text(
                  "KEMBALI",
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ─── CHECK ACCESS ──────────────────────────────────────────────────────
    if (!_canSendNotification(widget.role)) {
      return _buildAccessDenied();
    }

    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        title: const Text(
          "Kirim Notifikasi",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                _primaryColor.withOpacity(0.8),
                Colors.transparent,
              ],
            ),
          ),
        ),
        actions: [
          // Role Badge
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.green.withOpacity(0.1),
              border: Border.all(color: Colors.green.withOpacity(0.2)),
            ),
            child: Text(
              getRoleDisplay(widget.role),
              style: TextStyle(
                color: Colors.green,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Background effect
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topRight,
                  radius: 1.5,
                  colors: [
                    _primaryColor.withOpacity(0.1),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          
          // Main content
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header Card
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        _primaryColor.withOpacity(0.3),
                        _primaryColor.withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: _primaryColor.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [
                              _primaryColor,
                              _accentColor,
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _primaryColor.withOpacity(0.5),
                              blurRadius: 15,
                              spreadRadius: 3,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.notifications_active,
                          color: Colors.white,
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  "BROADCAST MESSAGE",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.green.withOpacity(0.1),
                                    border: Border.all(color: Colors.green.withOpacity(0.2)),
                                  ),
                                  child: Text(
                                    getRoleDisplay(widget.role),
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Kirim notifikasi ke semua user X-SPYDER yang online",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7),
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 30),
                
                // Form
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title Label
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8, left: 4),
                        child: Row(
                          children: [
                            Icon(
                              Icons.title,
                              color: _primaryColor,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "Judul Notifikasi",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Title Input
                      Container(
                        decoration: BoxDecoration(
                          color: _cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.3),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _titleController,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: "Masukkan judul notifikasi",
                            hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7)),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.all(20),
                            prefixIcon: Icon(
                              Icons.short_text,
                              color: _primaryColor,
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return "Judul tidak boleh kosong";
                            }
                            if (value.trim().length < 3) {
                              return "Judul minimal 3 karakter";
                            }
                            return null;
                          },
                          maxLength: 100,
                        ),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // Message Label
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8, left: 4),
                        child: Row(
                          children: [
                            Icon(
                              Icons.message,
                              color: _primaryColor,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "Pesan Notifikasi",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Message Input
                      Container(
                        decoration: BoxDecoration(
                          color: _cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.3),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: TextFormField(
                          controller: _messageController,
                          style: const TextStyle(color: Colors.white),
                          maxLines: 5,
                          decoration: InputDecoration(
                            hintText: "Tulis pesan notifikasi di sini...",
                            hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7)),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.all(20),
                            alignLabelWithHint: true,
                          ),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return "Pesan tidak boleh kosong";
                            }
                            if (value.trim().length < 5) {
                              return "Pesan minimal 5 karakter";
                            }
                            return null;
                          },
                          maxLength: 500,
                        ),
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // Type Selection Label
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8, left: 4),
                        child: Row(
                          children: [
                            Icon(
                              Icons.category,
                              color: _primaryColor,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "Tipe Notifikasi",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Type Chips
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: _notificationTypes.map(_buildTypeChip).toList(),
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // Error/Success Messages
                      if (_errorMessage != null)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          margin: const EdgeInsets.only(bottom: 20),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.red.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.error,
                                color: Colors.red,
                                size: 24,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _errorMessage!,
                                  style: TextStyle(
                                    color: Colors.red,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      
                      if (_successMessage != null)
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          margin: const EdgeInsets.only(bottom: 20),
                          decoration: BoxDecoration(
                            color: Colors.green.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.green.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 24,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _successMessage!,
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      
                      // Send Button
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _primaryColor,
                              _accentColor,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: _primaryColor.withOpacity(0.4),
                              blurRadius: 20,
                              spreadRadius: 3,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                          child: InkWell(
                            onTap: _isSending ? null : _sendNotification,
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(vertical: 18),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  if (_isSending)
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                  else
                                    Icon(
                                      Icons.send,
                                      color: Colors.white,
                                      size: 22,
                                    ),
                                  const SizedBox(width: 12),
                                  Text(
                                    _isSending ? "MENGIRIM..." : "KIRIM NOTIFIKASI",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              color: _primaryColor,
                              size: 24,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                "Notifikasi akan dikirim ke semua user yang sedang online dan muncul di WebSocket real-time",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.8),
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}