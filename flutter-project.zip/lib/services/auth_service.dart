import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/user.dart';
import 'api_service.dart';

class AuthService {
  final ApiService _api = ApiService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  User? _user;
  bool _authenticated = false;

  static String _freeKey(String username) => 'nc_free_$username';

  Future<void> _markFree(String username) async {
    if (username.isEmpty) return;
    await _storage.write(key: _freeKey(username), value: '1');
  }

  Future<bool> _isMarkedFree(String username) async {
    if (username.isEmpty) return false;
    final v = await _storage.read(key: _freeKey(username));
    return v == '1';
  }

  User? get user => _user;
  bool get isAuthenticated => _authenticated;

  Future<bool> tryAutoLogin() async {
    await _api.init();
    final token = _api.token;
    if (token == null) return false;
    final result = await _api.getMe();
    if (result['success'] == true && result['data'] != null) {
      _authenticated = true;
      _user = User.fromJson(result['data'] as Map<String, dynamic>);
      if (await _isMarkedFree(_user!.username ?? _user!.email)) {
        _user = _user!.copyWith(isFreeAccess: true);
      }
      return true;
    }
    await _api.clearToken();
    return false;
  }

  Future<Map<String, dynamic>> login(String username, String password) async {
    // Fingerprint-first startup can reach login without tryAutoLogin having
    // initialized the API client yet.
    if (_api.baseUrl.isEmpty) await _api.init();
    final result = await _api.loginWithUsername(username, password);
    if (result['success'] == true) {
      _authenticated = true;
      final userData = result['user'] as Map<String, dynamic>?;
      if (userData != null) {
        _user = User.fromJson(userData);
      } else if (result['data'] is Map && (result['data'] as Map)['user'] != null) {
        _user = User.fromJson((result['data'] as Map)['user'] as Map<String, dynamic>);
      }
      await _api.storeCredentials(username, password);
      if (await _isMarkedFree(username)) {
        _user = _user?.copyWith(isFreeAccess: true);
      }
    }
    return result;
  }

  Future<Map<String, dynamic>> freeAccess(
    String username,
    String password,
    String deviceId,
  ) async {
    final result = await _api.freeAccess(username, password, deviceId);
    if (result['success'] == true) {
      _authenticated = true;
      final userData = result['user'] as Map<String, dynamic>?;
      if (userData != null) {
        _user = User.fromJson(userData);
      } else if (result['data'] is Map && (result['data'] as Map)['user'] != null) {
        _user = User.fromJson((result['data'] as Map)['user'] as Map<String, dynamic>);
      }
      await _markFree(username);
      _user = _user?.copyWith(isFreeAccess: true);
      await _api.storeCredentials(username, password);
    }
    return result;
  }

  Future<bool> register(String username, String password, {String? invitationCode, String? email}) async {
    final result = await _api.registerWithUsername(username, password, invitationCode: invitationCode, email: email);
    if (result['success'] == true) {
      _authenticated = true;
      final userData = result['user'] as Map<String, dynamic>?;
      if (userData != null) {
        _user = User.fromJson(userData);
      } else if (result['data'] is Map && (result['data'] as Map)['user'] != null) {
        _user = User.fromJson((result['data'] as Map)['user'] as Map<String, dynamic>);
      }
      await _api.storeCredentials(username, password);
      return true;
    }
    return false;
  }

  Future<void> logout() async {
    await _api.logout();
    _user = null;
    _authenticated = false;
  }

  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> updates) async {
    final result = await _api.updateProfile(updates);
    if (result['success'] == true && result['data'] != null) {
      _user = User.fromJson(result['data'] as Map<String, dynamic>);
    }
    return result;
  }

  Future<Map<String, dynamic>> changePassword(String currentPassword, String newPassword) async {
    return await _api.changePassword(currentPassword, newPassword);
  }
}
