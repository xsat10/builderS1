import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Sticker pack storage using SharedPreferences.
/// Each sticker is stored as base64 PNG data.
class StickerService {
  static const _key = 'nova_sticker_pack';

  // Built-in default sticker URLs (emoji-style remote stickers).
  static const List<String> defaultStickers = [
    'https://res.cloudinary.com/demo/image/upload/sample.jpg',
  ];

  Future<List<String>> _loadRaw() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw;
  }

  /// Load all stickers (defaults + user-created).
  Future<List<String>> loadStickers() async {
    final raw = await _loadRaw();
    return [...defaultStickers, ...raw];
  }

  /// Add a custom sticker from base64 data.
  Future<void> addSticker(String base64Data) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    if (!list.contains(base64Data)) {
      list.add(base64Data);
      await prefs.setStringList(_key, list);
    }
  }

  /// Remove a custom sticker from the pack.
  Future<void> removeSticker(String base64Data) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    list.remove(base64Data);
    await prefs.setStringList(_key, list);
  }

  /// Convert base64 bytes to a data URI usable by Image.
  static String toDataUri(String base64Data) {
    if (base64Data.startsWith('data:')) return base64Data;
    return 'data:image/png;base64,$base64Data';
  }

  static String encodeBytes(List<int> bytes) => base64Encode(bytes);
}
