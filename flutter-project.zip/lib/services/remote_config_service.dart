import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'api_service.dart';

/// RemoteConfigService
/// Flow:
///  1. Parse [AppConfig.remoteConfigUrl] (gist, teks polos URL server).
///  2. Build server baseUrl (dari gist ATAU server_url tersimpan).
///  3. Fetch `/api/remote-config` dari server -> config publik (news, prayer,
///     spotify, social, branding, server).
///  4. Cache semua di secure storage; fallback ke default internal jika
///     server offline / belum login.
class RemoteConfigService {
  RemoteConfigService._();
  static final RemoteConfigService instance = RemoteConfigService._();

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  static const String _configKey = 'remote_config';
  static const String _serverUrlKey = 'server_url';

  Map<String, dynamic> _config = _defaultConfig();
  Map<String, dynamic> get config => _config;

  bool _loaded = false;
  bool get loaded => _loaded;

  /// Alasan kesalahan terakhir (HTTP/network/permintaan server) penyimpanan
  /// remote config, agar UI bisa menampilkan penyebab yang sebenarnya.
  String? lastError;
  void _recordError(Object? e) {
    lastError = e is Map && e['error'] is Map
        ? _errorMessage(e['error'])
        : '$e';
  }

  String _errorMessage(Object e) {
    if (e is! Map) return '$e';
    final msg = e['message'];
    return msg is String ? msg : '$e';
  }

  static const String remoteGistUrl =
      'https://gist.githubusercontent.com/kamu';

  static Map<String, dynamic> _defaultConfig() {
    return {
      'version': 1,
      'server': {'baseUrl': 'https://gist.githubusercontent.com/kamu'},
      'news': {
        'provider': 'berita_indo_api',
        'baseUrl': 'https://berita-indo-api.vercel.app/v1/cnn-news',
        'enabled': true,
      },
      'prayer': {
        'provider': 'myquran',
        'baseUrl': 'https://api.myquran.com/v3/sholat',
        'cityId': 'eda80a3d5b344bc40f3bc04f65b7a357',
        'timezone': 'Asia/Jakarta',
        'enabled': true,
      },
      'spotify': {
        'enabled': false,
        'clientId': '',
        'redirectUri': 'novaguard://spotify-callback',
      },
      'access': {
        'freeAccessEnabled': true,
        'freeAccessDurationHours': 24,
        'freeAccessDurationDays': 1,
        'freeAccessFeatures': {'bug': false, 'ban': false, 'protected': false},
      },
      'music': {'enabled': true, 'table': 'music_tracks'},
      'social': {
        'telegram': 'https://t.me/createnova_bot',
        'instagram': 'https://instagram.com/alexyusomo_',
        'tiktok': 'https://instagram.com/alexyusomo',
        'whatsapp': 'https://wa.me/6285760472601',
        'github': 'https://github.com/alexyusomo',
        'buyNow': 'https://t.me/info_alexyusomo',
      },
      'branding': {
        'appName': 'NovaCore',
        'tagline': 'Audentes Fortuna Iuvat',
        'motto': 'Flectere Si Nequeo Superos, Acheronta Movebo',
        'designer': '@alexyusomo',
        'splashGreeting': 'Valete',
      },
    };
  }

  // ---------- Getters convenience ----------
  String get serverBaseUrl {
    final s = _config['server'];
    if (s is Map && s['baseUrl'] != null) return s['baseUrl'].toString();
    return 'https://gist.githubusercontent.com/kamu';
  }

  Map<String, dynamic> get news =>
      _asMap(_config['news']) ??
      _defaultConfig()['news'] as Map<String, dynamic>;

  Map<String, dynamic> get prayer =>
      _asMap(_config['prayer']) ??
      _defaultConfig()['prayer'] as Map<String, dynamic>;

  Map<String, dynamic> get spotify =>
      _asMap(_config['spotify']) ??
      _defaultConfig()['spotify'] as Map<String, dynamic>;

  Map<String, dynamic> get access =>
      _asMap(_config['access']) ??
      _defaultConfig()['access'] as Map<String, dynamic>;

  bool get freeAccessEnabled => access['freeAccessEnabled'] == true;
  int get freeAccessDurationHours =>
      (access['freeAccessDurationHours'] as num?)?.toInt() ?? 24;
  int get freeAccessDurationDays =>
      (access['freeAccessDurationDays'] as num?)?.toInt() ?? 1;
  Map<String, dynamic> get freeAccessFeatures {
    final raw = access['freeAccessFeatures'];
    if (raw is Map) return Map<String, dynamic>.from(raw);
    return {'bug': false, 'ban': false, 'protected': false};
  }

  Map<String, dynamic> get music =>
      _asMap(_config['music']) ??
      _defaultConfig()['music'] as Map<String, dynamic>;

  bool get musicEnabled => music['enabled'] != false;

  Map<String, dynamic> get social =>
      _asMap(_config['social']) ??
      _defaultConfig()['social'] as Map<String, dynamic>;

  Map<String, dynamic> get branding =>
      _asMap(_config['branding']) ??
      _defaultConfig()['branding'] as Map<String, dynamic>;

  String get appName => branding['appName']?.toString() ?? 'NovaCore';
  String get tagline => branding['tagline']?.toString() ?? '';
  String get motto => branding['motto']?.toString() ?? '';
  String get designer => branding['designer']?.toString() ?? '';
  String get splashGreeting => branding['splashGreeting']?.toString() ?? '';

  Map<String, dynamic>? _asMap(Object? o) =>
      o is Map ? Map<String, dynamic>.from(o) : null;

  // ---------- Init ----------
  Future<void> init() async {
    // 1. Baca server_url tersimpan dulu (fallback).
    String baseUrl = '';
    try {
      final stored = await _storage.read(key: _serverUrlKey);
      if (stored != null && stored.isNotEmpty) baseUrl = stored;
    } catch (_) {}

    // 2. Fetch gist -> dapatkan server URL terbaru (remote SELALU menang).
    final gistUrl = await _fetchGistServerUrl();
    if (gistUrl != null && gistUrl.isNotEmpty) {
      baseUrl = gistUrl;
      try {
        await _storage.write(key: _serverUrlKey, value: gistUrl);
      } catch (_) {}
    }

    // 3. Baca config cache lama.
    await _loadCachedConfig();

    // 4. Set server.baseUrl di config dari hasil gist (jika ada).
    if (baseUrl.isNotEmpty) {
      _config = Map<String, dynamic>.from(_config);
      final server = _asMap(_config['server']) ?? {};
      _config['server'] = {...server, 'baseUrl': baseUrl};
    }

    // 5. Coba fetch /api/remote-config dari server. Gagal -> pakai cache/default.
    await _fetchFromServer();

    _loaded = true;
  }

  Future<String?> _fetchGistServerUrl() async {
    try {
      final res = await http
          .get(Uri.parse(remoteGistUrl))
          .timeout(const Duration(seconds: 5));
      if (res.statusCode != 200) return null;
      final body = res.body.trim();
      if (RegExp(r'^https?://[^\s]+$').hasMatch(body)) {
        return body.trim();
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _loadCachedConfig() async {
    try {
      final cached = await _storage.read(key: _configKey);
      if (cached != null && cached.isNotEmpty) {
        final parsed = jsonDecode(cached);
        if (parsed is Map) {
          _config = _deepMerge(
            _defaultConfig(),
            Map<String, dynamic>.from(parsed),
          );
          return;
        }
      }
    } catch (_) {}
    _config = _defaultConfig();
  }

  Future<void> _fetchFromServer() async {
    final base = serverBaseUrl;
    if (base.isEmpty) return;
    try {
      final res = await http
          .get(Uri.parse('$base/api/remote-config'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return;
      final decoded = jsonDecode(res.body);
      final data = decoded is Map && decoded['data'] is Map
          ? decoded['data']
          : decoded;
      if (data is Map) {
        _config = _deepMerge(_defaultConfig(), Map<String, dynamic>.from(data));
        try {
          await _storage.write(key: _configKey, value: jsonEncode(_config));
        } catch (_) {}
      }
    } catch (_) {}
  }

  Map<String, dynamic> _deepMerge(
    Map<String, dynamic> base,
    Map<String, dynamic> override,
  ) {
    final out = Map<String, dynamic>.from(base);
    override.forEach((key, value) {
      if (value is Map && out[key] is Map) {
        out[key] = _deepMerge(
          Map<String, dynamic>.from(out[key] as Map),
          Map<String, dynamic>.from(value),
        );
      } else {
        out[key] = value;
      }
    });
    return out;
  }

  Future<void> refresh() async {
    await _fetchFromServer();
    final base = serverBaseUrl;
    if (base.isNotEmpty) {
      try {
        await _storage.write(key: _serverUrlKey, value: base);
      } catch (_) {}
    }
  }

  /// Perbarui freeAccessEnabled di server (developer only), lalu muat ulang
  /// config lokal agar value langsung berubah. Gagal di server -> false dan
  /// [lastError] berisi alasan dari server.
  Future<bool> setFreeAccessEnabled(bool enabled) async {
    lastError = null;
    final api = ApiService();
    try {
      final res = await api.updateRemoteConfig({
        'access': {'freeAccessEnabled': enabled},
      });
        final saved = res['data'] is Map
          ? (res['data'] as Map)['saved'] == true
          : false;
        final ok = res['success'] == true && (saved || res['data'] == null);
      if (!ok) {
        _recordError(res['error'] ?? res);
        return false;
      }
      _setAccessValue('freeAccessEnabled', enabled);
      // Refresh boleh gagal (server sibuk/offline) — itu hanya mempengaruhi
      // tampilan lokal, bukan mengubah status berhasilnya SIMPAN.
      try {
        await refresh();
      } catch (_) {}
      return true;
    } catch (e) {
      lastError = '$e';
      return false;
    }
  }

  void _setAccessValue(String key, Object? value) {
    final current = _asMap(_config['access']) ?? {};
    _config = Map<String, dynamic>.from(_config);
    _config['access'] = {...current, key: value};
  }

  /// Perbarui konfigurasi akses gratis (developer only).
  Future<bool> setFreeAccessConfig({
    bool? enabled,
    int? durationDays,
    Map<String, dynamic>? features,
  }) async {
    lastError = null;
    final api = ApiService();
    try {
      final accessPatch = <String, dynamic>{};
      if (enabled != null) accessPatch['freeAccessEnabled'] = enabled;
      if (durationDays != null) {
        accessPatch['freeAccessDurationDays'] = durationDays;
      }
      if (features != null) accessPatch['freeAccessFeatures'] = features;
      if (accessPatch.isEmpty) return true;
      final res = await api.updateRemoteConfig({'access': accessPatch});
        final saved = res['data'] is Map
          ? (res['data'] as Map)['saved'] == true
          : false;
        final ok = res['success'] == true && (saved || res['data'] == null);
      if (!ok) {
        _recordError(res['error'] ?? res);
        return false;
      }
      // Refresh boleh gagal — tidak menjadikan "SIMPAN" gagal.
      try {
        await refresh();
      } catch (_) {}
      return true;
    } catch (e) {
      lastError = '$e';
      return false;
    }
  }
}
