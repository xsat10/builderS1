import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/music_track.dart';
import 'api_service.dart';

/// Musik Nova: daftar lagu diambil dari server (database JSON lokal). Developer
/// hanya meng-input LINK lagu Spotify (bukan upload file). Saat diputar, app
/// me-resolve link Spotify menjadi audio preview (30 detik) dan memutarnya
/// memakai just_audio.
class MusicService {
  final ApiService _api = ApiService();

  Future<List<MusicTrack>> getTracks() async {
    final result = await _api.getMusic();
    if (result['success'] == true && result['data'] != null) {
      final list = result['data'] as List;
      return list
          .map((e) => MusicTrack.fromJson(e as Map<String, dynamic>))
          .where((t) => t.spotifyUrl.isNotEmpty || t.audioUrl.isNotEmpty)
          .toList();
    }
    return [];
  }

  /// Resolve link Spotify menjadi URL preview (MP3 ~30 detik). Dicoba dari:
  /// 1) meta `og:audio` / `music:preview_url` / `audio_preview_url` pada halaman
  ///    track publik,
  /// 2) JSON `audio_preview_url` / `audioPreview.url` — makin sering disediakan
  ///    halaman streaming terbaru,
  /// 3) fallback halaman embed Spotify (`/embed/track/{id}`) yang punya
  ///    struktur JSON lebih stabil.
  /// Mengembalikan null bila gagal (track tidak punya preview / butuh premium).
  static Future<String?> resolvePreviewUrl(String spotifyUrl) async {
    try {
      final uri = Uri.tryParse(spotifyUrl);
      if (uri == null) return null;

      String body = '';
      try {
        final res = await http.get(uri).timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) body = res.body;
      } catch (_) {}

      final direct = _extractPreview(body);
      if (direct != null) return direct;

      // 3) Halaman embed: relung JSON "audioPreview":{"url":...}
      final trackMatch = RegExp(
        r'(?:/track/|/embed/track/)([A-Za-z0-9]+)',
      ).firstMatch(spotifyUrl);
      if (trackMatch != null) {
        final embedUrl = Uri.parse(
          'https://open.spotify.com/embed/track/${trackMatch.group(1)}',
        );
        try {
          final res = await http
              .get(embedUrl)
              .timeout(const Duration(seconds: 10));
          final fromEmbed = _extractPreview(res.body);
          if (fromEmbed != null) return fromEmbed;
        } catch (_) {}
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  static String? _extractPreview(String body) {
    if (body.isEmpty) return null;
    final meta = RegExp(
      r'<meta[^>]+(?:property|name)="(?:og:audio:secure_url|og:audio|music:preview_url)"[^>]+content="([^"]+)"',
    ).firstMatch(body);
    if (meta != null) {
      final url = _unescape(meta.group(1)!);
      if (url.startsWith('http')) return url;
    }
    final audioPreviewUrl = RegExp(
      r'"audio_preview_url"\s*:\s*"([^"]+)"',
    ).firstMatch(body);
    if (audioPreviewUrl != null) {
      final url = _unescape(audioPreviewUrl.group(1)!);
      if (url.startsWith('http')) return url;
    }
    final audioPreview = RegExp(
      r'"audioPreview"\s*:\s*\{[^}]*?"url"\s*:\s*"([^"]+)"',
    ).firstMatch(body);
    if (audioPreview != null) {
      final url = _unescape(audioPreview.group(1)!);
      if (url.startsWith('http')) return url;
    }
    return null;
  }

  static String _unescape(String s) {
    return s
        .replaceAll('\\/', '/')
        .replaceAll('\\u0026', '&')
        .replaceAll('&amp;', '&')
        .replaceAll('\\"', '"');
  }

  /// Metadata judul & seniman dari link Spotify (via oEmbed publik).
  static Future<Map<String, String>> resolveMeta(String spotifyUrl) async {
    try {
      final uri = Uri.parse(
        'https://open.spotify.com/oembed?url=${Uri.encodeComponent(spotifyUrl)}',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return {};
      final decoded = jsonDecode(res.body) as Map<String, dynamic>;
      return {
        'title': (decoded['title']?.toString() ?? ''),
        'artist': (decoded['author_name']?.toString() ?? ''),
        'artwork': (decoded['thumbnail_url']?.toString() ?? ''),
      };
    } catch (_) {
      return {};
    }
  }
}
