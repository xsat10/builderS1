import 'dart:math';
import 'dart:typed_data';
import 'package:just_audio/just_audio.dart';

class SoundService {
  static final AudioPlayer _player = AudioPlayer();

  static Uint8List _generateWav({
    required List<double> frequencies,
    required double durationSec,
    double sampleRate = 22050,
    double volume = 0.5,
  }) {
    final numSamples = (sampleRate * durationSec).toInt();
    final dataSize = numSamples * 2;
    final fileSize = 44 + dataSize;

    final bytes = ByteData(fileSize);

    // RIFF header
    bytes.setUint8(0, 0x52); // R
    bytes.setUint8(1, 0x49); // I
    bytes.setUint8(2, 0x46); // F
    bytes.setUint8(3, 0x46); // F
    bytes.setUint32(4, fileSize - 8, Endian.little);
    bytes.setUint8(8, 0x57); // W
    bytes.setUint8(9, 0x41); // A
    bytes.setUint8(10, 0x56); // V
    bytes.setUint8(11, 0x45); // E

    // fmt chunk
    bytes.setUint8(12, 0x66); // f
    bytes.setUint8(13, 0x6D); // m
    bytes.setUint8(14, 0x74); // t
    bytes.setUint8(15, 0x20); // ' '
    bytes.setUint32(16, 16, Endian.little);
    bytes.setUint16(20, 1, Endian.little); // PCM
    bytes.setUint16(22, 1, Endian.little); // mono
    bytes.setUint32(24, sampleRate.toInt(), Endian.little);
    bytes.setUint32(28, (sampleRate * 2).toInt(), Endian.little);
    bytes.setUint16(32, 2, Endian.little);
    bytes.setUint16(34, 16, Endian.little);

    // data chunk
    bytes.setUint8(36, 0x64); // d
    bytes.setUint8(37, 0x61); // a
    bytes.setUint8(38, 0x74); // t
    bytes.setUint8(39, 0x61); // a
    bytes.setUint32(40, dataSize, Endian.little);

    int offset = 44;
    for (int i = 0; i < numSamples; i++) {
      final t = i / sampleRate;
      final freqIdx = ((i / numSamples) * frequencies.length).floor().clamp(0, frequencies.length - 1);
      final freq = frequencies[freqIdx];
      
      final envelope = 1.0 - (i / numSamples);
      final sample = (sin(2 * pi * freq * t) * 32767 * volume * envelope).toInt().clamp(-32768, 32767);
      bytes.setInt16(offset, sample, Endian.little);
      offset += 2;
    }

    return bytes.buffer.asUint8List();
  }

  static Future<void> playChessMove() async {
    try {
      final wav = _generateWav(frequencies: [600, 450], durationSec: 0.08, volume: 0.6);
      await _player.setAudioSource(AudioSource.uri(Uri.dataFromBytes(wav, mimeType: 'audio/wav')));
      await _player.play();
    } catch (_) {}
  }

  static Future<void> playChessCheck() async {
    try {
      final wav = _generateWav(frequencies: [587, 880], durationSec: 0.25, volume: 0.7);
      await _player.setAudioSource(AudioSource.uri(Uri.dataFromBytes(wav, mimeType: 'audio/wav')));
      await _player.play();
    } catch (_) {}
  }

  static Future<void> playChessCheckmate() async {
    try {
      final wav = _generateWav(frequencies: [523, 659, 784, 1046], durationSec: 0.5, volume: 0.8);
      await _player.setAudioSource(AudioSource.uri(Uri.dataFromBytes(wav, mimeType: 'audio/wav')));
      await _player.play();
    } catch (_) {}
  }

  static Future<void> playBlockTap() async {
    try {
      final wav = _generateWav(frequencies: [500, 700], durationSec: 0.07, volume: 0.5);
      await _player.setAudioSource(AudioSource.uri(Uri.dataFromBytes(wav, mimeType: 'audio/wav')));
      await _player.play();
    } catch (_) {}
  }

  static Future<void> playBlockImpossible() async {
    try {
      final wav = _generateWav(frequencies: [220, 180, 140], durationSec: 0.3, volume: 0.7);
      await _player.setAudioSource(AudioSource.uri(Uri.dataFromBytes(wav, mimeType: 'audio/wav')));
      await _player.play();
    } catch (_) {}
  }
}
