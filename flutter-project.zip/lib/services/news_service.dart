import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_service.dart';
import 'remote_config_service.dart';
import '../models/news_item.dart';

class NewsService {
  final ApiService _api = ApiService();

  Future<List<NewsItem>> getNews() async {
    try {
      final result = await _api.getNews();
      if (result['success'] == true && result['data'] != null) {
        final list = result['data'] as List;
        final items = list
            .map((e) => e is Map
                ? NewsItem.fromJson(e as Map<String, dynamic>)
                : null)
            .whereType<NewsItem>()
            .toList();
        // Jika server ada tapi belum ada pengumuman, tetap tampilkan default
        // supaya section PENGUMUMAN tidak kosong/blank.
        if (items.isNotEmpty) return items;
        return _defaultNews();
      }
    } catch (_) {}
    return _defaultNews();
  }

  Future<bool> createNews(NewsItem item) async {
    final result = await _api.createNews(item.toJson());
    return result['success'] == true;
  }

  Future<bool> updateNews(String id, NewsItem item) async {
    final result = await _api.updateNews(id, item.toJson());
    return result['success'] == true;
  }

  Future<bool> deleteNews(String id) async {
    final result = await _api.deleteNews(id);
    return result['success'] == true;
  }

  List<NewsItem> _defaultNews() {
    return [
      NewsItem(id: '1', title: 'NovaCore v2.0', description: 'Real-time device monitoring, enhanced security, and a brand new UI experience.', buttonText: 'LEARN MORE', buttonUrl: 'https://', showButton: true, sortOrder: 0),
      NewsItem(id: '2', title: 'Security Update', description: 'Advanced encryption protocols deployed.', sortOrder: 1),
      NewsItem(id: '3', title: 'New Features', description: 'Remote camera, microphone, and flashlight controls now available.', buttonText: 'EXPLORE', buttonUrl: 'https://', showButton: true, sortOrder: 2),
      NewsItem(id: '4', title: 'Maintenance', description: 'Scheduled every Sunday 02:00-04:00 UTC.', sortOrder: 3),
    ];
  }

  /// Berita terbaru dari external API (berita-indo-api, dst.) yang
  /// dikelola lewat remote config di server. Kosongkan return jika gagal/disabled.
  Future<List<NewsItem>> getLatestNews() async {
    final cfg = RemoteConfigService.instance.news;
    final enabled = cfg['enabled'] != false;
    final base = (cfg['baseUrl']?.toString() ?? '').trim();
    // Tidak ada sumber berita / baseUrl kosong -> tetap tampilkan berita contoh
    // supaya section BERITA tidak kosong di home.
    if (base.isEmpty) return _fallbackBerita();

    // Jika berita live dinonaktifkan, tetap tampilkan berita contoh supaya
    // section BERITA tidak kosong (bukan layar blank).
    if (!enabled) return _fallbackBerita();

    try {
      final res = await http
          .get(Uri.parse(base))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return _fallbackBerita();
      final decoded = jsonDecode(res.body);
      final root = decoded is Map ? decoded['data'] : null;
      if (root is! List) return _fallbackBerita();

      final items = <NewsItem>[];
      for (int i = 0; i < root.length && i < 10; i++) {
        final e = root[i];
        if (e is! Map) continue;
        // Gambar dari CNN (berita-indo-api) berbentuk objek {small, large}.
        final imgRaw = e['image'] ?? e['imageUrl'] ?? e['image_url'];
        String? img;
        if (imgRaw is Map) {
          img = (imgRaw['large'] ?? imgRaw['small'] ?? imgRaw['url'])?.toString();
        } else if (imgRaw != null) {
          img = imgRaw.toString();
        }
        items.add(NewsItem(
          id: (e['link'] ?? e['url'] ?? i.toString()).toString(),
          title: (e['title'] ?? '').toString(),
          description: (e['description'] ?? e['contentSnippet'] ?? '').toString(),
          imageUrl: img,
          buttonText: i == 0 ? 'BACA' : null,
          buttonUrl: (e['link'] ?? e['url'])?.toString(),
          showButton: i == 0,
          sortOrder: i,
        ));
      }
      // Jangan biarkan section BERITA kosong: fallback ke berita contoh
      // jika API hidup tapi tidak mengembalikan item valid.
      return items.isNotEmpty ? items : _fallbackBerita();
    } catch (_) {
      return _fallbackBerita();
    }
  }

  /// Berita contoh sebagai pengganti ketika API live gagal/offline, supaya
  /// section BERITA tetap tampak (tidak kosong). Ditandai agar jelas sebagai
  /// konten demo dan tetap bisa dibuka.
  List<NewsItem> _fallbackBerita() {
    return [
      NewsItem(
        id: 'fb-1',
        title: 'Kinerja Tetap Solid, Transaksi dan Ekosistem Bank Terus Tumbuh',
        description: 'Update singkat dari kanal berita terkemuka untuk kamu.',
        buttonText: 'BACA',
        buttonUrl: 'https://www.cnnindonesia.com',
        showButton: true,
        sortOrder: 0,
      ),
      NewsItem(
        id: 'fb-2',
        title: 'Berita Terkini Hari Ini',
        description: 'Kumpulan berita terbaru dari berbagai kanal terpercaya.',
        buttonText: 'BACA',
        buttonUrl: 'https://www.cnnindonesia.com',
        showButton: true,
        sortOrder: 1,
      ),
      NewsItem(
        id: 'fb-3',
        title: 'Teknologi & Inovasi',
        description: 'Perkembangan teknologi terkini yang wajib kamu tahu.',
        buttonText: 'BACA',
        buttonUrl: 'https://www.cnnindonesia.com',
        showButton: true,
        sortOrder: 2,
      ),
    ];
  }
}
