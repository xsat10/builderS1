import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../models/music_track.dart';
import 'music_service.dart';

enum MusicPlayResult { ok, noPreview, failed, busy, outOfRange }

/// Player musik global (singleton). Hanya SATU AudioPlayer untuk seluruh app
/// sehingga musik terus berlanjut meski sheet player ditutup (X/back) dan
/// otomatis lanjut ke track berikutnya saat track selesai.
class MusicPlayerController extends ChangeNotifier {
  MusicPlayerController._() {
    _player.playerStateStream.listen(_onPlayerState);
    WidgetsBinding.instance.addObserver(_LifecycleObserver(this));
  }
  static final MusicPlayerController instance = MusicPlayerController._();

  final MusicService _service = MusicService();
  final AudioPlayer _player = AudioPlayer();

  List<MusicTrack> tracks = [];
  int currentIndex = -1;
  bool playing = false;
  bool loading = false;
  String? error;
  Duration position = Duration.zero;
  Duration duration = Duration.zero;
  bool busy = false;

  Timer? _ticker;
  bool _loadedOnce = false;
  int _playToken = 0;

  bool get hasTracks => tracks.isNotEmpty;

  Future<void> ensureLoaded({bool force = false}) async {
    if ((_loadedOnce && !force) || loading) return;
    loading = true;
    error = null;
    notifyListeners();
    try {
      final list = await _service.getTracks().timeout(
        const Duration(seconds: 20),
      );
      tracks = list;
      if (currentIndex < 0 || currentIndex >= tracks.length) {
        currentIndex = tracks.isEmpty ? -1 : 0;
      }
      _loadedOnce = true;
    } catch (_) {
      error = 'Gagal memuat musik.';
      if (currentIndex < 0 || currentIndex >= tracks.length) {
        currentIndex = -1;
      }
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<MusicPlayResult> playTrack(int index) async {
    if (index < 0 || index >= tracks.length) return MusicPlayResult.outOfRange;
    // Pengganti permintaan yang sedang berjalan: setiap panggilan baru
    // membatalkan efek panggilan sebelumnya (token bertambah), sehingga
    // next/prev/klik lagu lain TIDAK pernah ditolak karena `busy`.
    final token = ++_playToken;
    busy = true;
    playing = false;
    error = null;
    final previousIndex = currentIndex;
    currentIndex = index;
    notifyListeners();
    try {
      // Hentikan lagu sebelumnya SEGERA supaya tidak terus berbunyi selama
      // resolusi URL lagu baru berlangsung (ikon loading tidak lagi
      // bertentangan dengan audio yang masih jalan).
      await _player.stop();
      final track = tracks[index];
      String? url = track.audioUrl.isNotEmpty ? track.audioUrl : null;
      if (url == null && track.spotifyUrl.isNotEmpty) {
        url = await MusicService.resolvePreviewUrl(track.spotifyUrl);
      }
      if (url == null || url.isEmpty) {
        if (token != _playToken) return MusicPlayResult.busy;
        currentIndex = previousIndex;
        return MusicPlayResult.noPreview;
      }
      await _player.setUrl(url).timeout(const Duration(seconds: 30));
      // Mulai audio TANPA menunggu future play() selesai. Untuk sumber
      // streaming, future play() bisa tertahan di buffering padahal audio
      // sudah terdengar → ikon loading menggantung. State `playing` disinkron
      // dari playerStateStream (lihat _onPlayerState); error pemutaran
      // ditangani di sana (idle + playerError), jadi aman tidak di-await.
      unawaited(_player.play().catchError((Object _) {}));
      _startTicker();
      if (token != _playToken) return MusicPlayResult.busy;
      playing = true;
      _syncCurrent();
      return MusicPlayResult.ok;
    } catch (_) {
      if (token != _playToken) return MusicPlayResult.busy;
      currentIndex = previousIndex;
      return MusicPlayResult.failed;
    } finally {
      if (token == _playToken) {
        busy = false;
        notifyListeners();
      }
    }
  }

  void _onPlayerState(PlayerState state) {
    if (state.processingState == ProcessingState.completed) {
      _ticker?.cancel();
      if (tracks.isNotEmpty) {
        playTrack((currentIndex + 1) % tracks.length);
      }
      return;
    }
    if (state.processingState == ProcessingState.idle) {
      // Idle tanpa busy: bisa jadi error pemutaran atau pause alami.
      // Reset `playing` ke false agar ikon kembali ke play.
      if (!busy && currentIndex >= 0 && !state.playing) {
        _ticker?.cancel();
        playing = false;
        _syncCurrent();
        notifyListeners();
      }
      return;
    }
    // Hanya sinkronkan `playing` pada kondisi ready. Event buffering (transisi
    // saat stream menyiapkan data) TIDAK dibiarkan menurunkan `playing`, jadi
    // ikon tidak mungkin berubah kembali ke play ketika audio masih berjalan.
    if (busy || state.processingState != ProcessingState.ready) return;
    playing = state.playing;
    _syncCurrent();
    notifyListeners();
  }

  void _syncCurrent() {
    try {
      position = _player.position;
      duration = _player.duration ?? Duration.zero;
    } catch (_) {}
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(milliseconds: 500), (_) {
      _syncCurrent();
      notifyListeners();
    });
  }

  void resume() {
    _player.play();
    playing = true;
    _startTicker();
    notifyListeners();
  }

  void pause() {
    _ticker?.cancel();
    _player.pause();
    playing = false;
    _syncCurrent();
    notifyListeners();
  }

  void stop() {
    _ticker?.cancel();
    _player.stop();
    playing = false;
    position = Duration.zero;
    duration = Duration.zero;
    notifyListeners();
  }

  void next() {
    if (tracks.isEmpty) return;
    playTrack((currentIndex + 1) % tracks.length);
  }

  void prev() {
    if (tracks.isEmpty) return;
    playTrack((currentIndex - 1 + tracks.length) % tracks.length);
  }

  void seek(Duration target) {
    _player.seek(target);
    position = target;
    notifyListeners();
  }

  void _pauseOnBackground() {
    if (playing) pause();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _player.stop();
    _player.dispose();
    super.dispose();
  }
}

class _LifecycleObserver extends WidgetsBindingObserver {
  final MusicPlayerController controller;
  _LifecycleObserver(this.controller);

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Pause saat app keluar layar; tidak dihentikan (agar bisa resume).
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      controller._pauseOnBackground();
    }
  }
}
