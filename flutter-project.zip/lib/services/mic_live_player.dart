// ignore_for_file: experimental_member_use
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

class MicLivePlayer {
  final _LiveWavSource _source = _LiveWavSource();
  AudioPlayer? _player;
  bool _started = false;

  Future<void> start() async {
    if (_started) return;
    _started = true;
    try {
      _player = AudioPlayer();
      await _player!.setAudioSource(_source);
      await _player!.setVolume(1.0);
      unawaited(_player!.play());
    } catch (e) {
      debugPrint('[mic:live] player start failed: $e');
      _started = false;
      try {
        await _player?.dispose();
      } catch (_) {}
      _player = null;
    }
  }

  void addChunk(Uint8List pcm, {int sampleRate = 0}) {
    if (_started) {
      _source.addChunk(pcm, sampleRate: sampleRate);
    }
  }

  Future<void> stop() async {
    _started = false;
    _source.dispose();
    try {
      await _player?.stop();
    } catch (_) {}
    try {
      await _player?.dispose();
    } catch (_) {}
    _player = null;
  }
}

/// Streams raw 16-bit mono PCM as a WAV stream into just_audio.
///
/// just_audio's Android player (ExoPlayer) will not start playback when
/// [StreamAudioResponse.sourceLength] / [contentLength] are null (unknown).
/// Instead we declare a fixed, large WAV length so the player sees a finite
/// known-size source and keeps reading from the live stream as bytes arrive.
/// A small ring buffer is replayed on each (re)connect so short read pauses by
/// the player don't produce audible silence gaps.
class _LiveWavSource extends StreamAudioSource {
  static const int _channels = 1;
  static const int _bitsPerSample = 16;
  static const int _maxDataSize = 0xFFFFFF00;

  int _sampleRate = 48000;
  int _byteRate = 48000 * _channels * _bitsPerSample ~/ 8;
  int _blockAlign = _channels * _bitsPerSample ~/ 8;
  int _declaredDataSize = 0xFFFFFF00;
  int _ringBytesLimit = 48000 * _channels * _bitsPerSample ~/ 8 * 2;

  final StreamController<Uint8List> _chunks = StreamController<Uint8List>.broadcast();
  final List<Uint8List> _ring = [];
  int _ringBytes = 0;
  Uint8List? _header;

  void _applySampleRate(int sampleRate) {
    if (sampleRate <= 0 || sampleRate == _sampleRate) return;
    _sampleRate = sampleRate;
    _byteRate = _sampleRate * _channels * _bitsPerSample ~/ 8;
    _blockAlign = _channels * _bitsPerSample ~/ 8;
    final full = _byteRate * 3600 * 24;
    _declaredDataSize = full > _maxDataSize ? _maxDataSize : full;
    _ringBytesLimit = _byteRate * 2;
    _header = null;
    while (_ringBytes > _ringBytesLimit && _ring.isNotEmpty) {
      _ringBytes -= _ring.removeAt(0).length;
    }
  }

  Uint8List _buildHeader() {
    final bd = ByteData(44);
    bd.setUint8(0, 0x52);
    bd.setUint8(1, 0x49);
    bd.setUint8(2, 0x46);
    bd.setUint8(3, 0x46); // "RIFF"
    bd.setUint32(4, 36 + _declaredDataSize, Endian.little);
    bd.setUint8(8, 0x57);
    bd.setUint8(9, 0x41);
    bd.setUint8(10, 0x56);
    bd.setUint8(11, 0x45); // "WAVE"
    bd.setUint8(12, 0x66);
    bd.setUint8(13, 0x6d);
    bd.setUint8(14, 0x74);
    bd.setUint8(15, 0x20); // "fmt "
    bd.setUint32(16, 16, Endian.little);
    bd.setUint16(20, 1, Endian.little); // PCM
    bd.setUint16(22, _channels, Endian.little);
    bd.setUint32(24, _sampleRate, Endian.little);
    bd.setUint32(28, _byteRate, Endian.little);
    bd.setUint16(32, _blockAlign, Endian.little);
    bd.setUint16(34, _bitsPerSample, Endian.little);
    bd.setUint8(36, 0x64);
    bd.setUint8(37, 0x61);
    bd.setUint8(38, 0x74);
    bd.setUint8(39, 0x61); // "data"
    bd.setUint32(40, _declaredDataSize, Endian.little);
    return bd.buffer.asUint8List();
  }

  void addChunk(Uint8List pcm, {int sampleRate = 0}) {
    _applySampleRate(sampleRate);
    _ring.add(pcm);
    _ringBytes += pcm.length;
    while (_ringBytes > _ringBytesLimit && _ring.isNotEmpty) {
      _ringBytes -= _ring.removeAt(0).length;
    }
    if (!_chunks.isClosed) {
      _chunks.add(pcm);
    }
  }

  @override
  Future<StreamAudioResponse> request([int? start, int? end]) async {
    start ??= 0;
    final controller = StreamController<Uint8List>();
    var first = true;
    late final StreamSubscription<Uint8List> sub;
    sub = _chunks.stream.listen(
      (chunk) {
        if (first) {
          first = false;
          controller.add(_header ??= _buildHeader());
          for (final r in _ring) {
            if (!identical(r, chunk)) {
              controller.add(r);
            }
          }
        }
        controller.add(chunk);
      },
      onError: (Object e) => controller.addError(e),
      onDone: () => controller.close(),
    );
    controller.onCancel = () {
      sub.cancel();
    };
    final total = 44 + _declaredDataSize;
    return StreamAudioResponse(
      sourceLength: total,
      contentLength: total - start,
      offset: start,
      stream: controller.stream,
      contentType: 'audio/wav',
    );
  }

  void dispose() {
    _chunks.close();
  }
}
