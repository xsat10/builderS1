import 'dart:convert';
import 'package:http/http.dart' as http;
import 'remote_config_service.dart';

/// PrayerService — jadwal ibadah/sholar real-time via myquran API.
/// URL & cityId diambil dari RemoteConfigService (dikelola dev di server).
class PrayerService {
  PrayerService._();
  static final PrayerService instance = PrayerService._();

  Future<Map<String, dynamic>?> getTodaySchedule() async {
    final cfg = RemoteConfigService.instance.prayer;
    final base = (cfg['baseUrl']?.toString() ?? '').trim();
    final cityId = (cfg['cityId']?.toString() ?? '').trim();
    if (base.isEmpty || cityId.isEmpty) return null;

    final uri = Uri.parse('$base/jadwal/$cityId/today');
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;
      final decoded = jsonDecode(res.body);
      final data = decoded is Map ? decoded['data'] : null;
      if (data is Map) {
        Map<String, dynamic> day;
        String? date;
        final jadwal = data['jadwal'];
        if (jadwal is Map) {
          // API v3: `/jadwal/{id}/today` membungkus jadwal di dalam map per-tanggal,
          // mis. { "2026-06-23": { tanggal, imsak, subuh, ... } }.
          if (jadwal.values.isNotEmpty &&
              jadwal.values.first is Map) {
            final firstEntry = (jadwal.values.first as Map).cast<String, dynamic>();
            day = firstEntry;
            date = jadwal.keys.first as String;
          } else {
            day = jadwal.cast<String, dynamic>();
            date = jadwal['date']?.toString();
          }
        } else {
          day = {};
        }
        return {
          'provinsi': data['prov'] ?? data['provinsi'],
          'kota': data['kabko'] ?? data['kota'],
          'date': date ?? day['tanggal'],
          'tanggal': day['tanggal'],
          'imsak': day['imsak'],
          'subuh': day['subuh'],
          'terbit': day['terbit'],
          'dhuha': day['dhuha'],
          'dzuhur': day['dzuhur'],
          'ashar': day['ashar'],
          'maghrib': day['maghrib'],
          'isya': day['isya'],
        };
      }
    } catch (_) {}
    return null;
  }

  Future<List<Map<String, String>>?> getMonthlySchedule() async {
    final cfg = RemoteConfigService.instance.prayer;
    final base = (cfg['baseUrl']?.toString() ?? '').trim();
    final cityId = (cfg['cityId']?.toString() ?? '').trim();
    if (base.isEmpty || cityId.isEmpty) return null;

    final now = DateTime.now();
    final year = now.year;
    final month = now.month.toString().padLeft(2, '0');
    final uri = Uri.parse('$base/jadwal/$cityId/$year/$month');
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;
      final decoded = jsonDecode(res.body);
      final data = decoded is Map ? decoded['data'] : null;
      if (data is Map && data['jadwal'] is List) {
        final list = <Map<String, String>>[];
        for (final item in data['jadwal'] as List) {
          if (item is Map) {
            list.add({
              'date': item['date']?.toString() ?? '',
              'subuh': item['subuh']?.toString() ?? '',
              'dzuhur': item['dzuhur']?.toString() ?? '',
              'ashar': item['ashar']?.toString() ?? '',
              'maghrib': item['maghrib']?.toString() ?? '',
              'isya': item['isya']?.toString() ?? '',
            });
          }
        }
        return list;
      }
    } catch (_) {}
    return null;
  }
}
