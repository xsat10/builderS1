import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'remote_config_service.dart';

class ApiService {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  String _baseUrl = '';
  String? _token;

  static final ApiService _instance = ApiService._();
  factory ApiService() => _instance;
  ApiService._();

  static void Function(String code, String message)? onSessionError;

  static const _sessionErrorCodes = {
    'ACCOUNT_EXPIRED',
    'USER_DISABLED',
    'USER_SUSPENDED',
    'ACCOUNT_DELETED',
    'LOGIN_ELSEWHERE',
  };

  String get baseUrl => _baseUrl;
  String? get token => _token;

  Future<void> init() async {
    // Gunakan RemoteConfigService untuk mengambil config (gist + remote config).
    await RemoteConfigService.instance.init();
    _baseUrl = RemoteConfigService.instance.serverBaseUrl;
    _token = await _storage.read(key: 'auth_token');
  }

  Future<void> setServerUrl(String url) async {
    _baseUrl = url;
    await _storage.write(key: 'server_url', value: url);
  }

  Future<void> setToken(String token) async {
    _token = token;
    await _storage.write(key: 'auth_token', value: token);
  }

  Future<void> clearToken() async {
    _token = null;
    await _storage.delete(key: 'auth_token');
  }

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_token != null) 'Authorization': 'Bearer $_token',
  };

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    Duration timeout = const Duration(seconds: 15),
  }) async {
    final uri = Uri.parse('$_baseUrl$path');
    http.Response res;
    try {
      if (method == 'GET') {
        res = await http
            .get(uri, headers: _headers)
            .timeout(timeout);
      } else if (method == 'POST') {
        res = await http
            .post(
              uri,
              headers: _headers,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(timeout);
      } else if (method == 'PATCH') {
        res = await http
            .patch(
              uri,
              headers: _headers,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(timeout);
      } else if (method == 'PUT') {
        res = await http
            .put(
              uri,
              headers: _headers,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(timeout);
      } else if (method == 'DELETE') {
        res = await http
            .delete(uri, headers: _headers)
            .timeout(timeout);
      } else {
        throw Exception('Unsupported method');
      }
    } catch (e) {
      return {
        'success': false,
        'error': {'code': 'NETWORK_ERROR', 'message': e.toString()},
      };
    }
    if (res.statusCode >= 400) {
      try {
        final decoded = jsonDecode(res.body) as Map<String, dynamic>;
        return decoded;
      } catch (_) {
        return {
          'success': false,
          'error': {
            'code': 'HTTP_${res.statusCode}',
            'message': 'Request failed with status ${res.statusCode}',
          },
        };
      }
    }
    try {
      final decoded = jsonDecode(res.body) as Map<String, dynamic>;
      if (decoded['success'] == false) {
        final errCode = (decoded['error']?['code'] as String?) ?? '';
        final errMsg =
            (decoded['error']?['message'] as String?) ?? 'Request failed';
        if (_sessionErrorCodes.contains(errCode)) {
          onSessionError?.call(errCode, errMsg);
        }
      }
      return decoded;
    } catch (_) {
      return {
        'success': false,
        'error': {'code': 'PARSE_ERROR', 'message': 'Invalid response'},
      };
    }
  }

  Future<void> storeCredentials(String email, String password) async {
    await _storage.write(key: 'email', value: email);
    await _storage.write(key: 'password', value: password);
  }

  Future<Map<String, String?>> getCredentials() async {
    final email = await _storage.read(key: 'email');
    final password = await _storage.read(key: 'password');
    return {'email': email, 'password': password};
  }

  // Auth
  Future<Map<String, dynamic>> login(String email, String password) async {
    final result = await _request(
      'POST',
      '/api/auth/login',
      body: {'email': email, 'password': password},
    );
    if (result['success'] == true) {
      final token = result['token'] ?? (result['data']?['token']);
      if (token != null) {
        await setToken(token.toString());
      }
    }
    return result;
  }

  Future<Map<String, dynamic>> loginWithUsername(
    String username,
    String password,
  ) async {
    final result = await _request(
      'POST',
      '/api/auth/login',
      body: {'username': username, 'password': password},
    );
    if (result['success'] == true) {
      final token = result['token'] ?? (result['data']?['token']);
      if (token != null) {
        await setToken(token.toString());
      }
    }
    return result;
  }

  Future<Map<String, dynamic>> freeAccess(
    String username,
    String password,
    String deviceId,
  ) async {
    final result = await _request(
      'POST',
      '/api/auth/free-access',
      body: {'username': username, 'password': password, 'deviceId': deviceId},
    );
    if (result['success'] == true) {
      final token = result['token'] ?? (result['data']?['token']);
      if (token != null) {
        await setToken(token.toString());
      }
    }
    return result;
  }

  Future<Map<String, dynamic>> registerWithUsername(
    String username,
    String password, {
    String? invitationCode,
    String? email,
  }) async {
    final body = <String, dynamic>{'username': username, 'password': password};
    if (invitationCode != null) body['invitationCode'] = invitationCode;
    if (email != null) body['email'] = email;
    final result = await _request('POST', '/api/auth/register', body: body);
    if (result['success'] == true) {
      final token = result['token'] ?? (result['data']?['token']);
      if (token != null) {
        await setToken(token.toString());
      }
    }
    return result;
  }

  Future<void> logout() async {
    final uri = Uri.parse('$_baseUrl/api/auth/logout');
    try {
      await http
          .post(uri, headers: _headers)
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
    await clearToken();
  }

  Future<Map<String, dynamic>> getMe() => _request('GET', '/api/auth/me');
  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> updates) =>
      _request('PATCH', '/api/auth/profile', body: updates);
  Future<Map<String, dynamic>> changePassword(
    String currentPassword,
    String newPassword,
  ) => _request(
    'POST',
    '/api/auth/change-password',
    body: {'currentPassword': currentPassword, 'newPassword': newPassword},
  );
  Future<Map<String, dynamic>> register(
    String email,
    String password, {
    String? invitationCode,
  }) {
    final body = <String, dynamic>{'email': email, 'password': password};
    if (invitationCode != null) body['invitationCode'] = invitationCode;
    return _request('POST', '/api/auth/register', body: body);
  }

  // Limits
  Future<Map<String, dynamic>> getMyLimits() =>
      _request('GET', '/api/limits/me');

  // Users
  Future<Map<String, dynamic>> getUsers() => _request('GET', '/api/users');
  Future<Map<String, dynamic>> getUser(String id) =>
      _request('GET', '/api/users/$id');
  Future<Map<String, dynamic>> createUser(
    String username,
    String password,
    String role, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/users',
    body: {
      'username': username,
      'password': password,
      'role': role,
      'expires_at': ?expiresAt,
    },
  );
  Future<Map<String, dynamic>> updateUser(
    String id,
    Map<String, dynamic> updates,
  ) => _request('PATCH', '/api/users/$id', body: updates);
  Future<Map<String, dynamic>> resetUserPassword(
    String id,
    String newPassword,
  ) => _request(
    'PATCH',
    '/api/users/$id/reset-password',
    body: {'password': newPassword},
  );
  Future<Map<String, dynamic>> disableUser(String id) =>
      _request('PATCH', '/api/users/$id/disable');
  Future<Map<String, dynamic>> banUser(String id) =>
      _request('PATCH', '/api/users/$id/ban');
  Future<Map<String, dynamic>> deleteUser(String id) =>
      _request('DELETE', '/api/users/$id');

  // Partners
  Future<Map<String, dynamic>> getPartners() =>
      _request('GET', '/api/partners');
  Future<Map<String, dynamic>> getPartner(String id) =>
      _request('GET', '/api/partners/$id');
  Future<Map<String, dynamic>> createPartner(
    String username,
    String password, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/partners',
    body: {
      'username': username,
      'password': password,
      'expires_at': ?expiresAt,
    },
  );
  Future<Map<String, dynamic>> disablePartner(String id) =>
      _request('PATCH', '/api/partners/$id/disable');

  // Resellers
  Future<Map<String, dynamic>> getResellers() =>
      _request('GET', '/api/resellers');
  Future<Map<String, dynamic>> getReseller(String id) =>
      _request('GET', '/api/resellers/$id');
  Future<Map<String, dynamic>> createReseller(
    String username,
    String password, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/resellers',
    body: {
      'username': username,
      'password': password,
      'expires_at': ?expiresAt,
    },
  );
  Future<Map<String, dynamic>> disableReseller(String id) =>
      _request('PATCH', '/api/resellers/$id/disable');

  // Members
  Future<Map<String, dynamic>> getMembers() => _request('GET', '/api/members');
  Future<Map<String, dynamic>> getMember(String id) =>
      _request('GET', '/api/members/$id');
  Future<Map<String, dynamic>> createMember(
    String username,
    String password, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/members',
    body: {
      'username': username,
      'password': password,
      'expires_at': ?expiresAt,
    },
  );
  Future<Map<String, dynamic>> disableMember(String id) =>
      _request('PATCH', '/api/members/$id/disable');

  // VIP & Moderator (via generic role-aware create /api/users)
  Future<Map<String, dynamic>> createVip(
    String username,
    String password, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/users',
    body: {
      'username': username,
      'password': password,
      'role': 'vip',
      'expires_at': ?expiresAt,
    },
  );

  Future<Map<String, dynamic>> createModerator(
    String username,
    String password, {
    String? expiresAt,
  }) => _request(
    'POST',
    '/api/users',
    body: {
      'username': username,
      'password': password,
      'role': 'moderator',
      'expires_at': ?expiresAt,
    },
  );

  // News
  Future<Map<String, dynamic>> getNews() => _request('GET', '/api/news');
  Future<Map<String, dynamic>> createNews(Map<String, dynamic> data) =>
      _request('POST', '/api/news', body: data);
  Future<Map<String, dynamic>> updateNews(
    String id,
    Map<String, dynamic> data,
  ) => _request('PATCH', '/api/news/$id', body: data);
  Future<Map<String, dynamic>> deleteNews(String id) =>
      _request('DELETE', '/api/news/$id');

  // Remote config (developer only to update)
  Future<Map<String, dynamic>> updateRemoteConfig(Map<String, dynamic> config) =>
      _request('PUT', '/api/remote-config', body: {'config': config});

  // Invitations
  Future<Map<String, dynamic>> createInvitation(String targetRole) =>
      _request('POST', '/api/invitations', body: {'targetRole': targetRole});
  Future<Map<String, dynamic>> getInvitations() =>
      _request('GET', '/api/invitations');

  // Stats
  Future<Map<String, dynamic>> getStats() => _request('GET', '/api/stats');
  Future<Map<String, dynamic>> getGlobalActivity() =>
      _request('GET', '/api/stats/activity/global');
  Future<Map<String, dynamic>> getHierarchyActivity() =>
      _request('GET', '/api/stats/activity/hierarchy');

  // Activity
  Future<Map<String, dynamic>> getMyActivities() =>
      _request('GET', '/api/activity');
  Future<Map<String, dynamic>> logActivity(
    String action,
    String message, {
    String status = 'success',
  }) => _request(
    'POST',
    '/api/activity',
    body: {'action': action, 'status': status, 'message': message},
  );

  // Devices
  Future<Map<String, dynamic>> getDevices() => _request('GET', '/api/devices');
  Future<Map<String, dynamic>> getManageDevices() =>
      _request('GET', '/api/devices/manage');
  Future<Map<String, dynamic>> transferDeviceOwner(
    String deviceId,
    String? ownerId,
  ) => _request(
    'PATCH',
    '/api/devices/$deviceId/owner',
    body: {'ownerId': ownerId ?? ''},
  );
  Future<Map<String, dynamic>> setDeviceLock(
    String deviceId,
    bool locked,
  ) => _request(
    'POST',
    '/api/devices/$deviceId/lock',
    body: {'locked': locked},
  );
  Future<Map<String, dynamic>> deleteDevice(String deviceId) =>
      _request('DELETE', '/api/devices/$deviceId');
  Future<Map<String, dynamic>> getDevice(String id) =>
      _request('GET', '/api/devices/$id');
  Future<Map<String, dynamic>> getDeviceStatus(String id) =>
      _request('GET', '/api/devices/$id/status');
  Future<Map<String, dynamic>> getDeviceActivity(String id) =>
      _request('GET', '/api/devices/$id/activity');
  Future<Map<String, dynamic>> getDeviceNotifications(String id) =>
      _request('GET', '/api/devices/$id/notifications');

  Future<Map<String, dynamic>> createPairing() =>
      _request('POST', '/api/pairing/create');

  Future<Map<String, dynamic>> createPairingCode({String? userId}) {
    return _request(
      'POST',
      '/api/pairing-codes',
      body: {if (userId != null && userId.isNotEmpty) 'userId': userId},
    );
  }

  Future<Map<String, dynamic>> getPairingCodes() =>
      _request('GET', '/api/pairing-codes');

  Future<Map<String, dynamic>> getMyPairingCodes() =>
      _request('GET', '/api/pairing-codes/mine');

  Future<Map<String, dynamic>> revokePairingCode(String code) =>
      _request('POST', '/api/pairing-codes/$code/revoke');

  Future<Map<String, dynamic>> deletePairingCode(String code) =>
      _request('DELETE', '/api/pairing-codes/$code');

  Future<Map<String, dynamic>> getTouchImage() =>
      _request('GET', '/api/settings/touch-image');

  Future<Map<String, dynamic>> setTouchImage(String imageB64) =>
      _request('PUT', '/api/settings/touch-image', body: {'image': imageB64});

  Future<Map<String, dynamic>> sendAction(
    String deviceId,
    String type,
    String action, {
    Map<String, dynamic>? payload,
  }) {
    return _request(
      'POST',
      '/api/devices/$deviceId/actions',
      body: {'type': type, 'action': action, 'payload': payload ?? {}},
    );
  }

  Future<Map<String, dynamic>> disconnectDevice(String deviceId) {
    return _request('POST', '/api/devices/$deviceId/disconnect');
  }

  Future<Map<String, dynamic>> revokeDevice(String deviceId) {
    return _request('POST', '/api/devices/$deviceId/revoke');
  }

  Future<Map<String, dynamic>> getHealth() => _request('GET', '/api/health');

  Future<Map<String, dynamic>> uploadImage(
    String filePath, {
    String? filename,
    String? kind,
  }) async {
    try {
      final uri = Uri.parse('$_baseUrl/api/upload');
      final request = http.MultipartRequest('POST', uri);
      if (_token != null) {
        request.headers['Authorization'] = 'Bearer $_token';
      }
      if (kind != null && kind.isNotEmpty) {
        request.fields['kind'] = kind;
      }
      request.files.add(
        await http.MultipartFile.fromPath('file', filePath, filename: filename),
      );
      final streamed = await request.send().timeout(
        const Duration(minutes: 5),
        onTimeout: () => throw TimeoutException('Media upload timed out'),
      );
      final res = await http.Response.fromStream(streamed);
      final decoded = jsonDecode(res.body) as Map<String, dynamic>;
      if (decoded['success'] == false) {
        final errCode = (decoded['error']?['code'] as String?) ?? '';
        if (_sessionErrorCodes.contains(errCode)) {
          onSessionError?.call(
            errCode,
            (decoded['error']?['message'] as String?) ?? 'Session error',
          );
        }
      }
      return decoded;
    } catch (e) {
      return {
        'success': false,
        'error': {'code': 'NETWORK_ERROR', 'message': e.toString()},
      };
    }
  }

  // WhatsApp senders
  Future<Map<String, dynamic>> getWaSenders() =>
      _request('GET', '/api/wa/senders');
  Future<Map<String, dynamic>> getWaSender(String id) =>
      _request('GET', '/api/wa/senders/$id');
  Future<Map<String, dynamic>> getWaSenderStatus(String id) =>
      _request('GET', '/api/wa/senders/$id/status');
  Future<Map<String, dynamic>> createWaSender(
    String phoneNumber, {
    String? visibility,
    String? sessionName,
  }) {
    final body = <String, dynamic>{
      'phoneNumber': phoneNumber,
      'visibility': visibility ?? 'private',
    };
    if (sessionName != null && sessionName.isNotEmpty) {
      body['sessionName'] = sessionName;
    }
    return _request('POST', '/api/wa/senders', body: body);
  }

  Future<Map<String, dynamic>> startWaQr(String id) =>
      _request('POST', '/api/wa/senders/$id/qr');
  Future<Map<String, dynamic>> startWaPairing(String id) =>
      _request('POST', '/api/wa/senders/$id/pairing');
  Future<Map<String, dynamic>> disconnectWaSender(String id) =>
      _request('POST', '/api/wa/senders/$id/disconnect');
  Future<Map<String, dynamic>> updateWaSender(
    String id,
    Map<String, dynamic> updates,
  ) => _request('PATCH', '/api/wa/senders/$id', body: updates);
  Future<Map<String, dynamic>> deleteWaSender(String id) =>
      _request('DELETE', '/api/wa/senders/$id');
  Future<Map<String, dynamic>> executeWaFunction(
    String senderId,
    String targetNumber,
    String functionId,
  ) {
    return _request(
      'POST',
      '/api/wa/senders/$senderId/execute',
      body: {'targetNumber': targetNumber, 'functionId': functionId},
      timeout: const Duration(minutes: 90),
    );
  }

  Future<Map<String, dynamic>> getWaFunctions({bool activeOnly = false}) =>
      _request('GET', '/api/wa/functions${activeOnly ? '?active=true' : ''}');

  Future<Map<String, dynamic>> getWaProtectedGroups() =>
      _request('GET', '/api/wa/senders/protected');
  Future<Map<String, dynamic>> addWaProtectedGroup(
    String slotId,
    String groupId, {
    String groupName = '',
    String kind = 'group',
  }) => _request(
        'POST',
        '/api/wa/senders/protected',
        body: {
          'slotId': slotId,
          'groupId': groupId,
          'groupName': groupName,
          'kind': kind,
        },
      );
  Future<Map<String, dynamic>> deleteWaProtectedGroup(String id) =>
      _request('DELETE', '/api/wa/senders/protected/$id');

  // Music
  Future<Map<String, dynamic>> getMusic() => _request('GET', '/api/music');
  Future<Map<String, dynamic>> createMusic(Map<String, dynamic> song) =>
      _request('POST', '/api/music', body: song);

  // Stories
  Future<Map<String, dynamic>> getStories() =>
      _request('GET', '/api/stories');
  Future<Map<String, dynamic>> getMyStories() =>
      _request('GET', '/api/stories/mine');
  Future<Map<String, dynamic>> createStory(Map<String, dynamic> data) =>
      _request('POST', '/api/stories', body: data);
  Future<Map<String, dynamic>> deleteStory(String id) =>
      _request('DELETE', '/api/stories/$id');

  // Public Chat
  Future<Map<String, dynamic>> getPublicChatMessages({String? before, int limit = 50}) {
    final params = <String, String>{
      if (before != null) 'before': before,
      'limit': limit.toString(),
    };
    final qs = params.entries.map((e) => '${e.key}=${e.value}').join('&');
    return _request('GET', '/api/public-chat?$qs');
  }

  Future<Map<String, dynamic>> sendPublicChatMessage(String message, {String? replyToId}) =>
      _request('POST', '/api/public-chat', body: {
        'message': message,
        if (replyToId != null) 'reply_to_id': replyToId,
      });

  Future<Map<String, dynamic>> sendPublicChatMedia({
    required String messageType,
    required String mediaUrl,
    String? mimeType,
    String? fileName,
    int? fileSize,
    String? caption,
    String? replyToId,
  }) =>
      _request('POST', '/api/public-chat', body: {
        'message_type': messageType,
        'media_url': mediaUrl,
        if (mimeType != null) 'mime_type': mimeType,
        if (fileName != null) 'file_name': fileName,
        if (fileSize != null) 'file_size': fileSize,
        if (caption != null) 'caption': caption,
        if (replyToId != null) 'reply_to_id': replyToId,
      });

  Future<Map<String, dynamic>> deletePublicChatMessage(String id) =>
      _request('DELETE', '/api/public-chat/$id');

  Future<Map<String, dynamic>> addPublicChatReaction(String id, String emoji) =>
      _request('POST', '/api/public-chat/$id/reactions', body: {'emoji': emoji});

  Future<Map<String, dynamic>> editPublicChatMessage(String id, String message) =>
      _request('PATCH', '/api/public-chat/$id', body: {'message': message});

  Future<Map<String, dynamic>> clearPublicChat() =>
      _request('POST', '/api/public-chat/clear');

  Future<Map<String, dynamic>> banPublicChatUser(String messageId) =>
      _request('POST', '/api/public-chat/$messageId/ban');

  Future<Map<String, dynamic>> unbanPublicChatUser(String userId) =>
      _request('POST', '/api/public-chat/bans/unban/$userId');

  Future<Map<String, dynamic>> getPublicChatBans() =>
      _request('GET', '/api/public-chat/bans');

  Future<Map<String, dynamic>> getMyPublicChatBan() =>
      _request('GET', '/api/public-chat/bans/me');

  Future<bool> checkConnection() async {
    try {
      final res = await getHealth();
      return res['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
