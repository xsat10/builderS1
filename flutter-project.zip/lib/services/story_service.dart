import '../models/story.dart';
import 'api_service.dart';

class StoryCreateException implements Exception {
  final String code;
  final String message;
  StoryCreateException(this.code, this.message);
  @override
  String toString() => message;
}

class StoryService {
  final ApiService _api = ApiService();

  Future<List<Story>> getStories() async {
    try {
      final result = await _api.getStories();
      if (result['success'] == true && result['data'] != null) {
        final list = result['data'] as List;
        return list
            .map((e) => e is Map ? Story.fromJson(e as Map<String, dynamic>) : null)
            .whereType<Story>()
            .toList();
      }
    } catch (_) {}
    return [];
  }

  Future<List<Story>> getMyStories() async {
    try {
      final result = await _api.getMyStories();
      if (result['success'] == true && result['data'] != null) {
        final list = result['data'] as List;
        return list
            .map((e) => e is Map ? Story.fromJson(e as Map<String, dynamic>) : null)
            .whereType<Story>()
            .toList();
      }
    } catch (_) {}
    return [];
  }

  Future<Story?> createStory({
    required String contentType,
    String? textContent,
    String? mediaUrl,
    String? bgColor,
  }) async {
    try {
      final result = await _api.createStory({
        'content_type': contentType,
        if (textContent != null) 'text_content': textContent,
        if (mediaUrl != null) 'media_url': mediaUrl,
        if (bgColor != null) 'bg_color': bgColor,
      });
      if (result['success'] == true && result['data'] != null) {
        return Story.fromJson(result['data'] as Map<String, dynamic>);
      }
      final err = result['error'] as Map<String, dynamic>?;
      throw StoryCreateException(
        (err?['code'] ?? '').toString(),
        (err?['message'] ?? 'Gagal membuat story').toString(),
      );
    } catch (e) {
      if (e is StoryCreateException) rethrow;
    }
    return null;
  }

  Future<bool> deleteStory(String id) async {
    try {
      final result = await _api.deleteStory(id);
      return result['success'] == true;
    } catch (_) {}
    return false;
  }
}
