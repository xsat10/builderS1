import 'dart:async';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:flutter/foundation.dart';

class SocketService {
  io.Socket? _socket;
  bool _connected = false;

  final StreamController<Map<String, dynamic>> _deviceNewController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceRegisteredController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceCodeLinkedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceLockedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceDeletedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _deviceOwnerChangedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _activityController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _notificationController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _screenFrameController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _screenStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _screenPermissionController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _screenshotController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _cameraFrameController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _cameraStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _micLevelController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _micStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _micAudioController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _touchStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _permissionController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _locationController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _waStatusController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _roleChangedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _waSenderCreatedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _waSenderUpdatedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _waSenderDeletedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _storyNewController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _storyDeletedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _viewingController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _viewingRejectedController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _viewingStolenController = StreamController.broadcast();
  final StreamController<Map<String, dynamic>> _sessionConflictController = StreamController.broadcast();
  final StreamController<bool> _connectedController = StreamController.broadcast();
  final StreamController<String> _errorController = StreamController.broadcast();

  Stream<Map<String, dynamic>> get deviceNewStream => _deviceNewController.stream;
  Stream<Map<String, dynamic>> get deviceRegisteredStream => _deviceRegisteredController.stream;
  Stream<Map<String, dynamic>> get deviceCodeLinkedStream => _deviceCodeLinkedController.stream;
  Stream<Map<String, dynamic>> get deviceLockedStream => _deviceLockedController.stream;
  Stream<Map<String, dynamic>> get deviceDeletedStream => _deviceDeletedController.stream;
  Stream<Map<String, dynamic>> get deviceStatusStream => _deviceStatusController.stream;
  Stream<Map<String, dynamic>> get deviceOwnerChangedStream => _deviceOwnerChangedController.stream;
  Stream<Map<String, dynamic>> get activityStream => _activityController.stream;
  Stream<Map<String, dynamic>> get notificationStream => _notificationController.stream;
  Stream<Map<String, dynamic>> get screenFrameStream => _screenFrameController.stream;
  Stream<Map<String, dynamic>> get screenStatusStream => _screenStatusController.stream;
  Stream<Map<String, dynamic>> get screenPermissionStream => _screenPermissionController.stream;
  Stream<Map<String, dynamic>> get screenshotCapturedStream => _screenshotController.stream;
  Stream<Map<String, dynamic>> get cameraFrameStream => _cameraFrameController.stream;
  Stream<Map<String, dynamic>> get cameraStatusStream => _cameraStatusController.stream;
  Stream<Map<String, dynamic>> get micLevelStream => _micLevelController.stream;
  Stream<Map<String, dynamic>> get micStatusStream => _micStatusController.stream;
  Stream<Map<String, dynamic>> get micAudioStream => _micAudioController.stream;
  Stream<Map<String, dynamic>> get touchStatusStream => _touchStatusController.stream;
  Stream<Map<String, dynamic>> get permissionStream => _permissionController.stream;
  Stream<Map<String, dynamic>> get locationStream => _locationController.stream;
  Stream<Map<String, dynamic>> get waStatusStream => _waStatusController.stream;
  Stream<Map<String, dynamic>> get roleChangedStream => _roleChangedController.stream;
  Stream<Map<String, dynamic>> get waSenderCreatedStream => _waSenderCreatedController.stream;
  Stream<Map<String, dynamic>> get waSenderUpdatedStream => _waSenderUpdatedController.stream;
  Stream<Map<String, dynamic>> get waSenderDeletedStream => _waSenderDeletedController.stream;
  Stream<Map<String, dynamic>> get storyNewStream => _storyNewController.stream;
  Stream<Map<String, dynamic>> get storyDeletedStream => _storyDeletedController.stream;
  Stream<Map<String, dynamic>> get viewingStream => _viewingController.stream;
  Stream<Map<String, dynamic>> get viewingRejectedStream => _viewingRejectedController.stream;
  Stream<Map<String, dynamic>> get viewingStolenStream => _viewingStolenController.stream;
  Stream<Map<String, dynamic>> get sessionConflictStream => _sessionConflictController.stream;
  Stream<bool> get connectedStream => _connectedController.stream;
  Stream<String> get errorStream => _errorController.stream;

  bool get isConnected => _connected;

  void connect(String serverUrl, String token) {
    if (_socket != null) {
      if (_connected) return;
      disconnect();
    }

    _socket = io.io(serverUrl, io.OptionBuilder()
      .setTransports(['websocket'])
      .setAuth({'token': token})
      .setExtraHeaders({'Authorization': 'Bearer $token'})
      .enableAutoConnect()
      .build());

    _socket!.on('connect', (_) {
      _connected = true;
      _connectedController.add(true);
      debugPrint('Socket connected');
    });

    _socket!.on('disconnect', (_) {
      _connected = false;
      _connectedController.add(false);
      debugPrint('Socket disconnected');
    });

    _socket!.on('connect_error', (err) {
      debugPrint('Socket connect error: $err');
      _connectedController.add(false);
      _errorController.add(err.toString());
    });

    _socket!.on('device:new', (data) {
      _deviceNewController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:registered', (data) {
      _deviceRegisteredController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:codeLinked', (data) {
      _deviceCodeLinkedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:locked', (data) {
      _deviceLockedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:deleted', (data) {
      _deviceDeletedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:owner_changed', (data) {
      _deviceOwnerChangedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:status', (data) {
      _deviceStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:activity', (data) {
      _activityController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('notification:received', (data) {
      _notificationController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('action:result', (data) {
      _activityController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('screen:frame', (data) {
      _screenFrameController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('screen:status', (data) {
      _screenStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('screen:permission', (data) {
      _screenPermissionController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('screenshot:captured', (data) {
      _screenshotController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('camera:frame', (data) {
      _cameraFrameController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('camera:status', (data) {
      _cameraStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('mic:level', (data) {
      _micLevelController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('mic:status', (data) {
      _micStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('mic:audio', (data) {
      _micAudioController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('touch:status', (data) {
      _touchStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:permissions', (data) {
      _permissionController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('location:update', (data) {
      _locationController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('wa:status', (data) {
      _waStatusController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('user:roleChanged', (data) {
      _roleChangedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('wa:senderCreated', (data) {
      _waSenderCreatedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('wa:senderUpdated', (data) {
      _waSenderUpdatedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('wa:senderDeleted', (data) {
      _waSenderDeletedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('story:new', (data) {
      _storyNewController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('story:deleted', (data) {
      _storyDeletedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:viewing', (data) {
      _viewingController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:view:rejected', (data) {
      _viewingRejectedController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('device:view:stolen', (data) {
      _viewingStolenController.add(Map<String, dynamic>.from(data));
    });

    _socket!.on('session:conflict', (data) {
      debugPrint('[socket:session:conflict] $data');
      _sessionConflictController.add(Map<String, dynamic>.from(data));
    });

    _socket!.connect();
  }

  void disconnect() {
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    _connected = false;
  }

  void emit(String event, Map<String, dynamic> data) {
    _socket?.emit(event, data);
  }

  void emitView(String deviceId) {
    debugPrint('Socket emitView device=$deviceId connected=$_connected socket=${_socket != null}');
    _socket?.emit('device:view', {'deviceId': deviceId});
  }

  void emitUnview(String deviceId) {
    _socket?.emit('device:unview', {'deviceId': deviceId});
  }

  void dispose() {
    disconnect();
    _deviceNewController.close();
    _deviceRegisteredController.close();
    _deviceCodeLinkedController.close();
    _deviceLockedController.close();
    _deviceDeletedController.close();
    _deviceStatusController.close();
    _deviceOwnerChangedController.close();
    _activityController.close();
    _notificationController.close();
    _screenFrameController.close();
    _screenStatusController.close();
    _screenPermissionController.close();
    _screenshotController.close();
    _cameraFrameController.close();
    _cameraStatusController.close();
    _micLevelController.close();
    _micStatusController.close();
    _micAudioController.close();
    _touchStatusController.close();
    _permissionController.close();
    _locationController.close();
    _waStatusController.close();
    _roleChangedController.close();
    _waSenderCreatedController.close();
    _waSenderUpdatedController.close();
    _waSenderDeletedController.close();
    _viewingController.close();
    _viewingRejectedController.close();
    _viewingStolenController.close();
    _storyNewController.close();
    _storyDeletedController.close();
    _sessionConflictController.close();
    _connectedController.close();
  }
}
