// otw_landing.dart - VOR4X ONBOARDING (VERTICAL SCROLL)
// Tema: Biru-Hitam Dominan Biru (Clean Modern Glassmorphism)
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'landing.dart';
import 'widgets/tap_logo_overlay.dart';

class OtwLandingPage extends StatefulWidget {
  const OtwLandingPage({super.key});

  @override
  State<OtwLandingPage> createState() => _OtwLandingPageState();
}

class _OtwLandingPageState extends State<OtwLandingPage>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  bool _navigated = false;

  // ─── PALET WARNA (BIRU-HITAM DOMINAN BIRU) ──────────────
  static const Color bgMain      = Color(0xFF050B18);
  static const Color bgDeep      = Color(0xFF0A1730);
  static const Color bgAccent    = Color(0xFF0E2A4D);
  static const Color neonBlue    = Color(0xFF00D2FF);
  static const Color neonBlueDim = Color(0xFF0091EA);
  static const Color neonIce     = Color(0xFF7FDBFF);
  static const Color neonWhite   = Color(0xFFF0F8FF);
  static const Color textMain    = Color(0xFFFFFFFF);
  static const Color textSub     = Color(0xFF8AA8C8);
  static const Color textMute    = Color(0xFF5A7090);
  static const Color borderSoft  = Color(0x1F78A0C8);

  // ─── PATH GAMBAR (DIPERTAHANKAN) ────────────────────────
  static const String defaultIcon  = 'assets/images/menu_header.jpg';
  static const String ownerIcon    = 'assets/images/home.png';
  static const String tapLogoImage = 'assets/images/tap_logo.jpg';
  // Background image DIHAPUS — diganti gradient biru-hitam

  // ─── DATA HALAMAN ───────────────────────────────────────
  final List<Map<String, dynamic>> _pages = [
    {
      'step': '01',
      'headerBadge': 'SISTEM UTAMA',
      'iconPath': tapLogoImage,
      'badge': 'GACOR',
      'title': 'XPLOIT',
      'titleAccent': 'WHATSAPP',
      'subtitle':
          'Sistem utama VOR4X siap digunakan. Terpantau, terkendali, dan aman.',
      'metaLeft': 'ONLINE',
      'metaRight': 'v4.0.1',
      'showMeta': true,
    },
    {
      'step': '02',
      'headerBadge': 'DEVELOPERS',
      'iconPath': tapLogoImage,
      'badge': 'DEVELOPERS',
      'title': 'DANZ',
      'titleAccent': '',
      'subtitle': 'Support friend yang selalu ada di balik layar VOR4X.',
      'isDeveloper': true,
      'showHint': true,
    },
    {
      'step': '03',
      'headerBadge': 'PEMILIK',
      'iconPath': ownerIcon,
      'badge': 'PEMILIK',
      'title': 'ZIL',
      'titleAccent': 'XPEDIA',
      'subtitle': 'Pemilik dan penggerak utama di balik VOR4X.',
      'isOwner': true,
      'showHint': true,
    },
    {
      'step': '04',
      'headerBadge': 'STATUS',
      'iconPath': tapLogoImage,
      'badge': 'STATUS',
      'title': 'SYSTEM',
      'titleAccent': 'ACTIVE',
      'subtitle': 'Terpantau. Terkendali. Tanpa downtime.',
      'metaLeft': 'AMAN',
      'metaRight': '24/7 UPTIME',
      'showMeta': true,
    },
    {
      'step': '05',
      'headerBadge': 'SIGN IN',
      'iconPath': tapLogoImage,
      'badge': 'SIGN IN',
      'title': 'SECURE',
      'titleAccent': 'ACCESS',
      'subtitle': 'Safe. Private. Siap masuk ke landing page VOR4X.',
    },
  ];

  // ─── HAPTIC ────────────────────────────────────────────
  void _tap() => HapticFeedback.lightImpact();

  void _goToLanding() {
    if (_navigated) return;
    _tap();
    _navigated = true;
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionDuration: const Duration(milliseconds: 800),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  // ─── EASTER EGG: DEVELOPER ─────────────────────────────
  void _onDeveloperEgg() {
    HapticFeedback.heavyImpact();
    _showEggDialog(
      title: 'DEVELOPER MODE',
      subtitle: 'DANZ GG',
      icon: Icons.code_rounded,
      logoAsset: tapLogoImage,
      message:
          'Kamu menemukan pintu rahasia developer VOR4X!\n\n'
          'danz18 — support friend yang selalu ada.\n\n'
          '"Kode yang baik adalah kode yang bisa dibaca manusia."',
    );
  }

  // ─── EASTER EGG: OWNER ─────────────────────────────────
  void _onOwnerEgg() {
    HapticFeedback.heavyImpact();
    _showEggDialog(
      title: 'OWNER MODE',
      subtitle: 'ZILXPEDIA',
      icon: Icons.workspace_premium_rounded,
      logoAsset: ownerIcon,
      message:
          'Selamat datang, Pemilik!\n\n'
          'Kamu menemukan kunci rahasia ZILXPEDIA.\n\n'
          '"Kekuatan sejati bukan dari jabatan, tapi dari visi."',
    );
  }

  void _showEggDialog({
    required String title,
    required String subtitle,
    required IconData icon,
    required String message,
    String? logoAsset,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.82),
      builder: (_) => _EasterEggDialog(
        title: title,
        subtitle: subtitle,
        icon: icon,
        accent: neonBlue,
        logoAsset: logoAsset,
        message: message,
      ),
    );
  }

  // ─── NAVIGASI ──────────────────────────────────────────
  void _nextPage() {
    if (_currentPage == _pages.length - 1) {
      _goToLanding();
    } else {
      _tap();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOutCubic,
      );
    }
  }

  void _goToPage(int index) {
    _tap();
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOutCubic,
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: Stack(
        children: [
          // ─── BACKGROUND GRADIENT BIRU-HITAM (PENGGANTI IMAGE) ─
          const Positioned.fill(child: _BlueGradientBackground()),

          // ─── GLOW ORBS ────────────────────────────────────
          Positioned(
            top: -120,
            left: -120,
            child: IgnorePointer(
              child: Container(
                width: 420,
                height: 420,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      neonBlue.withOpacity(0.28),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -140,
            right: -120,
            child: IgnorePointer(
              child: Container(
                width: 440,
                height: 440,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      neonBlueDim.withOpacity(0.30),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 200,
            right: -80,
            child: IgnorePointer(
              child: Container(
                width: 280,
                height: 280,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      bgAccent.withOpacity(0.45),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ─── NEON GRID OVERLAY ────────────────────────────
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _GridPainter()),
            ),
          ),

          // ─── PAGEVIEW VERTIKAL ────────────────────────────
          PageView.builder(
            controller: _pageController,
            scrollDirection: Axis.vertical,
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            onPageChanged: (index) {
              HapticFeedback.selectionClick();
              setState(() => _currentPage = index);
            },
            itemCount: _pages.length,
            itemBuilder: (context, index) {
              return _buildPage(_pages[index], index);
            },
          ),

          // ─── TOMBOL LEWATI ────────────────────────────────
          Positioned(
            top: 50,
            right: 22,
            child: _PressableScale(
              onTap: () => _goToPage(_pages.length - 1),
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.10),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Lewati',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        color: textSub.withOpacity(0.95),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      Icons.chevron_right_rounded,
                      color: textSub.withOpacity(0.75),
                      size: 16,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ─── SIDE INDICATOR ───────────────────────────────
          Positioned(
            right: 14,
            top: 0,
            bottom: 0,
            child: Center(
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.06),
                    width: 1,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                    _pages.length,
                    (index) => GestureDetector(
                      onTap: () => _goToPage(index),
                      behavior: HitTestBehavior.opaque,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          curve: Curves.easeOutCubic,
                          width: 5,
                          height: _currentPage == index ? 22 : 5,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: _currentPage == index
                                ? neonBlue
                                : Colors.white.withOpacity(0.18),
                            boxShadow: _currentPage == index
                                ? [
                                    BoxShadow(
                                      color: neonBlue.withOpacity(0.7),
                                      blurRadius: 10,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ─── FOOTER (HINT + BUTTON) ───────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    bgMain.withOpacity(0.85),
                    bgMain,
                  ],
                ),
              ),
              child: Column(
                children: [
                  _ScrollHint(accent: neonBlue, textSub: textMute),
                  const SizedBox(height: 14),
                  _PressableScale(
                    onTap: _nextPage,
                    borderRadius: BorderRadius.circular(12),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      width: double.infinity,
                      constraints: const BoxConstraints(maxWidth: 360),
                      height: 54,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: _currentPage == _pages.length - 1
                            ? LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  const Color(0xFF00E5FF),
                                  neonBlue,
                                ],
                              )
                            : LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  neonBlue.withOpacity(0.18),
                                  neonBlue.withOpacity(0.06),
                                ],
                              ),
                        border: _currentPage == _pages.length - 1
                            ? null
                            : Border.all(
                                color: neonBlue.withOpacity(0.4),
                                width: 1,
                              ),
                        boxShadow: [
                          BoxShadow(
                            color: neonBlue.withOpacity(
                              _currentPage == _pages.length - 1 ? 0.5 : 0.18,
                            ),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _currentPage == _pages.length - 1
                                ? 'Masuk Landing'
                                : 'Lanjut',
                            style: TextStyle(
                              fontFamily: 'Inter',
                              color: _currentPage == _pages.length - 1
                                  ? bgMain
                                  : neonWhite,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.3,
                            ),
                          ),
                          if (_currentPage != _pages.length - 1) ...[
                            const SizedBox(width: 8),
                            const Icon(
                              Icons.arrow_forward_rounded,
                              color: neonWhite,
                              size: 16,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD PAGE ─────────────────────────────────────────
  Widget _buildPage(Map<String, dynamic> data, int index) {
    final bool isDeveloper = data['isDeveloper'] == true;
    final bool isOwner = data['isOwner'] == true;
    final bool showMeta = data['showMeta'] == true;
    final bool showHint = data['showHint'] == true;

    return AnimatedBuilder(
      animation: _pageController,
      builder: (context, child) {
        double value = 0.0;
        if (_pageController.position.haveDimensions &&
            _pageController.position.maxScrollExtent > 0) {
          value = ((_pageController.page ?? _currentPage.toDouble()) - index)
              .clamp(-1.0, 1.0);
        }
        final scale = 1 - (value.abs() * 0.08);
        final opacity = 1 - (value.abs() * 0.65);
        return Transform.scale(
          scale: scale,
          child: Opacity(opacity: opacity, child: child),
        );
      },
      child: Column(
        children: [
          // ─── TOP BAR ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Brand
                Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [neonBlue, neonBlueDim],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: neonBlue.withOpacity(0.4),
                            blurRadius: 14,
                          ),
                        ],
                      ),
                      alignment: Alignment.center,
                      child: const Text(
                        'V',
                        style: TextStyle(
                          fontFamily: 'Inter',
                          color: bgMain,
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          height: 1.0,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'VOR4X',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        color: textMain,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                // Step pill
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 11, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.02),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: borderSoft, width: 1),
                  ),
                  child: RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        fontFamily: 'JetBrains Mono',
                        fontSize: 10.5,
                        color: textSub,
                        letterSpacing: 0.5,
                      ),
                      children: [
                        TextSpan(
                          text: data['step'],
                          style: const TextStyle(
                            color: neonBlue,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const TextSpan(text: ' / 05'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ─── BODY ─────────────────────────────────────────
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                physics: const NeverScrollableScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo orb
                      TapLogoOverlay(
                        logoAsset: data['iconPath'],
                        size: 116,
                        label: (isDeveloper || isOwner) ? 'TAP' : 'VOR4X',
                        tapsToUnlock: (isDeveloper || isOwner) ? 3 : 5,
                        neonColor: neonBlue,
                        glowColor: neonBlueDim,
                        innerColor: bgDeep.withOpacity(0.95),
                        outerColor: bgMain,
                        onSecretTap: () {
                          if (isDeveloper) {
                            _onDeveloperEgg();
                          } else if (isOwner) {
                            _onOwnerEgg();
                          } else {
                            HapticFeedback.heavyImpact();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                backgroundColor: bgDeep,
                                duration: const Duration(seconds: 2),
                                behavior: SnackBarBehavior.floating,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: BorderSide(
                                    color: neonBlue.withOpacity(0.4),
                                  ),
                                ),
                                content: const Text(
                                  '🎉 Easter egg! Coba di halaman DEVELOPERS & PEMILIK',
                                  style: TextStyle(
                                    fontFamily: 'Inter',
                                    color: neonWhite,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ),
                            );
                          }
                        },
                      ),

                      const SizedBox(height: 32),

                      // Eyebrow badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 5),
                        decoration: BoxDecoration(
                          color: neonBlue.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: neonBlue.withOpacity(0.25),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 5,
                              height: 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: neonBlue,
                                boxShadow: [
                                  BoxShadow(
                                    color: neonBlue.withOpacity(0.8),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 7),
                            Text(
                              (data['badge'] as String).toUpperCase(),
                              style: const TextStyle(
                                fontFamily: 'JetBrains Mono',
                                fontSize: 10.5,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 1.2,
                                color: neonBlue,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 22),

                      // Title
                      RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: const TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 34,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -1.0,
                            height: 1.15,
                            color: textMain,
                          ),
                          children: [
                            TextSpan(text: data['title']),
                            const TextSpan(text: '\n'),
                            TextSpan(
                              text: data['titleAccent'],
                              style: const TextStyle(color: neonBlue),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 14),

                      // Subtitle
                      Text(
                        data['subtitle'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Inter',
                          color: textSub,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w400,
                          height: 1.6,
                          letterSpacing: 0.1,
                        ),
                      ),

                      // Meta row
                      if (showMeta) ...[
                        const SizedBox(height: 24),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _LiveDot(color: neonBlue),
                            const SizedBox(width: 6),
                            Text(
                              data['metaLeft'] as String,
                              style: const TextStyle(
                                fontFamily: 'JetBrains Mono',
                                fontSize: 10.5,
                                color: neonBlue,
                                letterSpacing: 0.8,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Container(
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              width: 1,
                              height: 10,
                              color: borderSoft,
                            ),
                            Text(
                              data['metaRight'] as String,
                              style: const TextStyle(
                                fontFamily: 'JetBrains Mono',
                                fontSize: 10.5,
                                color: textMute,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                      ],

                      // Hint easter
                      if (showHint) ...[
                        const SizedBox(height: 18),
                        Text(
                          'tap logo 3× untuk kejutan',
                          style: TextStyle(
                            fontFamily: 'JetBrains Mono',
                            color: textMute.withOpacity(0.75),
                            fontSize: 10,
                            letterSpacing: 0.8,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Space buat footer overlay
          const SizedBox(height: 140),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// BACKGROUND GRADIENT BIRU-HITAM
// ═══════════════════════════════════════════════════════════
class _BlueGradientBackground extends StatelessWidget {
  const _BlueGradientBackground();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF050B18),
            Color(0xFF0A1730),
            Color(0xFF071020),
            Color(0xFF050B18),
          ],
          stops: [0.0, 0.35, 0.7, 1.0],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// SCROLL HINT
// ═══════════════════════════════════════════════════════════
class _ScrollHint extends StatefulWidget {
  final Color accent;
  final Color textSub;

  const _ScrollHint({required this.accent, required this.textSub});

  @override
  State<_ScrollHint> createState() => _ScrollHintState();
}

class _ScrollHintState extends State<_ScrollHint>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _anim = Tween<double>(begin: -2, end: 2).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (context, _) {
        return Transform.translate(
          offset: Offset(0, _anim.value),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.keyboard_arrow_up_rounded,
                color: widget.textSub,
                size: 14,
              ),
              const SizedBox(width: 8),
              Text(
                'GESER KE ATAS',
                style: TextStyle(
                  fontFamily: 'JetBrains Mono',
                  color: widget.textSub,
                  fontSize: 10,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.keyboard_arrow_down_rounded,
                color: widget.textSub,
                size: 14,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// LIVE DOT (pulse animation)
// ═══════════════════════════════════════════════════════════
class _LiveDot extends StatefulWidget {
  final Color color;
  const _LiveDot({required this.color});

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        final v = 0.4 + (_ctrl.value * 0.6);
        return Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color.withOpacity(v),
            boxShadow: [
              BoxShadow(
                color: widget.color.withOpacity(0.7 * v),
                blurRadius: 8,
              ),
            ],
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// PRESSABLE SCALE
// ═══════════════════════════════════════════════════════════
class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  final BorderRadius borderRadius;
  final double pressedScale;

  const _PressableScale({
    required this.child,
    required this.onTap,
    required this.borderRadius,
    this.pressedScale = 0.96,
  });

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
      lowerBound: 0.0,
      upperBound: 1.0,
    );
    _scale = Tween<double>(begin: 1.0, end: widget.pressedScale).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        _ctrl.forward();
        HapticFeedback.selectionClick();
      },
      onTapUp: (_) => _ctrl.reverse(),
      onTapCancel: () => _ctrl.reverse(),
      onTap: widget.onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedBuilder(
        animation: _scale,
        builder: (context, child) => Transform.scale(
          scale: _scale.value,
          child: child,
        ),
        child: widget.child,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// DIALOG EASTER EGG
// ═══════════════════════════════════════════════════════════
class _EasterEggDialog extends StatelessWidget {
  final String title;
  final String subtitle;
  final String message;
  final IconData icon;
  final Color accent;
  final String? logoAsset;

  const _EasterEggDialog({
    required this.title,
    required this.subtitle,
    required this.message,
    required this.icon,
    required this.accent,
    this.logoAsset,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A1730), Color(0xFF050B18)],
          ),
          border: Border.all(color: accent.withOpacity(0.4), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 40,
              offset: const Offset(0, 20),
            ),
            BoxShadow(
              color: accent.withOpacity(0.15),
              blurRadius: 60,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Orb logo
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [accent, accent.withOpacity(0.2)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.4),
                    blurRadius: 30,
                  ),
                ],
              ),
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFF0A1730),
                ),
                child: ClipOval(
                  child: SizedBox(
                    width: 72,
                    height: 72,
                    child: logoAsset != null
                        ? Image.asset(
                            logoAsset!,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => _fallbackIcon(),
                          )
                        : _fallbackIcon(),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Inter',
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              subtitle,
              style: TextStyle(
                fontFamily: 'JetBrains Mono',
                fontSize: 10.5,
                fontWeight: FontWeight.w500,
                color: accent,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF8AA8C8),
                fontSize: 13,
                height: 1.7,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent,
                  foregroundColor: const Color(0xFF050B18),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'Mantap!',
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fallbackIcon() {
    return Container(
      color: accent.withOpacity(0.15),
      child: Icon(icon, color: Colors.white, size: 34),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// GRID PAINTER (halus)
// ═══════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF78A0C8).withOpacity(0.03)
      ..strokeWidth = 1;

    const double gap = 56;

    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}