import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'splash.dart';

// ═══════════════════════════════════════════════════════════
// API CONFIG
// ═══════════════════════════════════════════════════════════
const String _baseUrl = 'https://paultzy.pteroqhost.web.id5015';

// ═══════════════════════════════════════════════════════════
// THEME: DEEP BLUE — Dominan Biru
// ═══════════════════════════════════════════════════════════
class _C {
  // Palet biru
  static const blue1 = Color(0xFF3B82F6); // bright blue
  static const blue2 = Color(0xFF2563EB); // royal blue
  static const blue3 = Color(0xFF1E40AF); // deep blue
  static const blue4 = Color(0xFF06B6D4); // cyan
  static const blue5 = Color(0xFF0EA5E9); // sky
  static const blue6 = Color(0xFF60A5FA); // light blue

  // Background hitam-biru
  static const bgDark   = Color(0xFF020617);
  static const bgNavy   = Color(0xFF030A18);
  static const bgDeep   = Color(0xFF0A1F3D);

  // Glass
  static const cardGlass   = Color(0x8C0F1E3C); // rgba(15,30,60,0.55)
  static const inputGlass  = Color(0x0A3B82F6); // rgba(59,130,246,0.04)
  static const clockGlass  = Color(0x0F3B82F6); // rgba(59,130,246,0.06)

  // Border biru
  static const borderBlue   = Color(0x263B82F6); // rgba(59,130,246,0.15)
  static const borderBlueHi = Color(0x993B82F6); // rgba(59,130,246,0.6)
  static const borderBlueLo = Color(0x1A3B82F6); // rgba(59,130,246,0.1)

  // Text
  static const textWhite = Color(0xFFFFFFFF);
  static const textSub   = Color(0xFF93A5C4);
  static const textMuted = Color(0xFF5A7099);

  static const greenOnline = Color(0xFF22D3A7);
  static const red         = Color(0xFFF43F5E);
  static const amber       = Color(0xFFFBBF24);

  // Gradient biru
  static const gradientBtn = LinearGradient(
    colors: [blue3, blue1, blue4],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const gradientLogo = LinearGradient(
    colors: [blue3, blue1, blue4],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const gradientBrand = LinearGradient(
    colors: [Color(0xFFFFFFFF), blue6],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _userFocus = FocusNode();
  final _passFocus = FocusNode();

  bool _isLoading   = false;
  bool _obscurePass = true;
  String? _androidId;

  // ═══ VIDEO BACKGROUND ═══
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  // Shake
  late AnimationController _shakeCtrl;
  late Animation<double> _shake;

  // Blob animations
  late AnimationController _blob1Ctrl;
  late AnimationController _blob2Ctrl;
  late AnimationController _blob3Ctrl;
  late AnimationController _blob4Ctrl;
  late Animation<double> _blob1;
  late Animation<double> _blob2;
  late Animation<double> _blob3;
  late Animation<double> _blob4;

  // Glow pulse
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  // Button shine
  late AnimationController _shineCtrl;
  late Animation<double> _shine;

  Timer? _clockTimer;
  String _clockTime = '00:00:00';
  String _clockDate = 'Memuat...';

  @override
  void initState() {
    super.initState();

    // Shake
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    // Blob animations
    _blob1Ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat(reverse: true);
    _blob2Ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 24))..repeat(reverse: true);
    _blob3Ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 28))..repeat(reverse: true);
    _blob4Ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 22))..repeat(reverse: true);

    _blob1 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _blob1Ctrl, curve: Curves.easeInOut));
    _blob2 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _blob2Ctrl, curve: Curves.easeInOut));
    _blob3 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _blob3Ctrl, curve: Curves.easeInOut));
    _blob4 = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _blob4Ctrl, curve: Curves.easeInOut));

    // Glow pulse
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.85, end: 1.15).animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    // Shine
    _shineCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..repeat();
    _shine = Tween<double>(begin: -2, end: 2).animate(_shineCtrl);

    _userFocus.addListener(() => setState(() {}));
    _passFocus.addListener(() => setState(() {}));

    _startClock();
    _initVideo();
    _initLogin();
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _videoController?.dispose();
    _shakeCtrl.dispose();
    _blob1Ctrl.dispose();
    _blob2Ctrl.dispose();
    _blob3Ctrl.dispose();
    _blob4Ctrl.dispose();
    _glowCtrl.dispose();
    _shineCtrl.dispose();
    _userFocus.dispose();
    _passFocus.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BACKGROUND INIT
  // ═══════════════════════════════════════════════════════════
  Future<void> _initVideo() async {
    try {
      final controller = VideoPlayerController.asset('assets/videos/otaxai.mp4');
      _videoController = controller;

      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0); // mute
      await controller.play();

      if (mounted) {
        setState(() => _videoReady = true);
      }
    } catch (e) {
      debugPrint('⚠️ Video background error: $e');
      if (mounted) setState(() => _videoReady = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // CLOCK
  // ═══════════════════════════════════════════════════════════
  void _startClock() {
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) _updateClock();
    });
  }

  void _updateClock() {
    final now = DateTime.now();
    final hh = now.hour.toString().padLeft(2, '0');
    final mm = now.minute.toString().padLeft(2, '0');
    final ss = now.second.toString().padLeft(2, '0');

    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'];

    final dayName = days[now.weekday % 7];
    final dd = now.day.toString().padLeft(2, '0');
    final monthName = months[now.month - 1];

    setState(() {
      _clockTime = '$hh:$mm:$ss';
      _clockDate = '$dayName, $dd $monthName'.toUpperCase();
    });
  }

  // ═══════════════════════════════════════════════════════════
  // AUTO LOGIN
  // ═══════════════════════════════════════════════════════════
  Future<void> _initLogin() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _androidId = info.id;

      final prefs     = await SharedPreferences.getInstance();
      final savedUser = prefs.getString('username');
      final savedPass = prefs.getString('password');
      final savedKey  = prefs.getString('key');

      if (savedUser != null && savedPass != null && savedKey != null) {
        final res = await http.get(Uri.parse(
            '$_baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: _parseList(data['listBug']),
                listDoos: _parseList(data['listDDoS']),
                news: _parseList(data['news']),
              ),
            ),
          );
        }
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  // ═══════════════════════════════════════════════════════════
  // LOGIN
  // ═══════════════════════════════════════════════════════════
  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res = await http.post(
        Uri.parse('$_baseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': _androidId ?? 'unknown',
        },
      );
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') ||
            msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);

        await Future.delayed(const Duration(milliseconds: 400));

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: _parseList(data['listBug']),
                listDoos: _parseList(data['listDDoS']),
                news: _parseList(data['news']),
              ),
            ),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  // ═══════════════════════════════════════════════════════════
  // ALERT MODAL
  // ═══════════════════════════════════════════════════════════
  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error   => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.greenOnline,
    };
    final icon = switch (type) {
      _AlertType.error   => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: const Color(0xBF020A19),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.bgDeep, Color(0xFF050F22)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: _C.borderBlue, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.7),
                    blurRadius: 80,
                    offset: const Offset(0, 30),
                  ),
                  BoxShadow(
                    color: _C.blue2.withOpacity(0.25),
                    blurRadius: 60,
                    spreadRadius: 2,
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 22),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.12),
                      border: Border.all(color: color.withOpacity(0.25), width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.3),
                          blurRadius: 30,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: color, size: 28),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    title,
                    style: const TextStyle(
                      color: _C.textWhite,
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _C.textSub,
                      fontSize: 13.5,
                      height: 1.6,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  const SizedBox(height: 24),
                  if (showContact) ...[
                    _buildGradientButton(
                      label: 'Hubungi Owner',
                      icon: Icons.telegram,
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await launchUrl(
                          Uri.parse('https://t.me/r4pzzxi'),
                          mode: LaunchMode.externalApplication,
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                  ],
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _C.borderBlue, width: 1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        backgroundColor: _C.blue1.withOpacity(0.08),
                      ),
                      onPressed: () => Navigator.pop(ctx),
                      child: Text(
                        showContact ? 'Tutup' : 'OK',
                        style: const TextStyle(
                          color: _C.textSub,
                          fontWeight: FontWeight.w600,
                          fontSize: 13.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGradientButton({
    required String label,
    required VoidCallback onPressed,
    IconData? icon,
  }) {
    return Container(
      width: double.infinity,
      height: 46,
      decoration: BoxDecoration(
        gradient: _C.gradientBtn,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: _C.blue1.withOpacity(0.5),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onPressed,
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, color: Colors.white, size: 16),
                  const SizedBox(width: 8),
                ],
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bgDark,
      body: Stack(
        children: [
          // ═══ 1. BASE GRADIENT ═══
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF030A18),
                    Color(0xFF020617),
                    Color(0xFF010308),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),

          // ═══ 2. VIDEO BACKGROUND ═══
          if (_videoReady && _videoController != null)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              ),
            ),

          // ═══ 3. OVERLAY GELAP + NUANSA BIRU ═══
          if (_videoReady)
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.bgDark.withOpacity(0.78),
                      _C.bgNavy.withOpacity(0.65),
                      _C.bgDeep.withOpacity(0.82),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),

          // ═══ 4. BLOB ANIMASI (hanya tampil kalau video tidak siap) ═══
          if (!_videoReady) ...[
            AnimatedBuilder(
              animation: _blob1,
              builder: (_, __) {
                final t = _blob1.value;
                return Positioned(
                  top: -300 + (t * 150),
                  left: -300 + (t * 150),
                  child: _buildBlob(_C.blue1.withOpacity(0.45), 600),
                );
              },
            ),
            AnimatedBuilder(
              animation: _blob2,
              builder: (_, __) {
                final t = _blob2.value;
                return Positioned(
                  bottom: -300 - (t * 100),
                  right: -300 - (t * 100),
                  child: _buildBlob(_C.blue4.withOpacity(0.35), 620),
                );
              },
            ),
            AnimatedBuilder(
              animation: _blob3,
              builder: (_, __) {
                final t = _blob3.value;
                return Positioned(
                  top: 300 + (t * 80),
                  left: 200 + (t * 60),
                  child: _buildBlob(_C.blue2.withOpacity(0.30), 500),
                );
              },
            ),
            AnimatedBuilder(
              animation: _blob4,
              builder: (_, __) {
                final t = _blob4.value;
                return Positioned(
                  top: 100 + (t * 80),
                  right: -100 + (t * 60),
                  child: _buildBlob(_C.blue5.withOpacity(0.25), 420),
                );
              },
            ),
          ],

          // ═══ 5. BLOB OVERLAY TIPIS (biar ada nuansa biru walau ada video) ═══
          if (_videoReady) ...[
            AnimatedBuilder(
              animation: _blob2,
              builder: (_, __) {
                final t = _blob2.value;
                return Positioned(
                  bottom: -300 - (t * 100),
                  right: -300 - (t * 100),
                  child: _buildBlob(_C.blue4.withOpacity(0.18), 620),
                );
              },
            ),
            AnimatedBuilder(
              animation: _blob1,
              builder: (_, __) {
                final t = _blob1.value;
                return Positioned(
                  top: -300 + (t * 150),
                  left: -300 + (t * 150),
                  child: _buildBlob(_C.blue1.withOpacity(0.22), 600),
                );
              },
            ),
          ],

          // ═══ 6. DOT GRID ═══
          Positioned.fill(
            child: CustomPaint(painter: _BlueDotGridPainter()),
          ),

          // ═══ 7. VIGNETTE ═══
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    colors: [
                      Colors.transparent,
                      const Color(0xFF00050F).withOpacity(0.6),
                    ],
                    stops: const [0.3, 1.0],
                  ),
                ),
              ),
            ),
          ),

          // ═══ 8. CONTENT ═══
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: AnimatedBuilder(
                  animation: _shake,
                  builder: (_, child) => Transform.translate(
                    offset: Offset(_shake.value, 0),
                    child: child,
                  ),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 420),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildBrand(),
                        const SizedBox(height: 32),
                        _buildCard(),
                        const SizedBox(height: 20),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BLOB WIDGET
  // ═══════════════════════════════════════════════════════════
  Widget _buildBlob(Color color, double size) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withOpacity(0)],
            stops: const [0.0, 0.7],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BRAND
  // ═══════════════════════════════════════════════════════════
  Widget _buildBrand() {
    return Column(
      children: [
        SizedBox(
          width: 88,
          height: 88,
          child: Stack(
            alignment: Alignment.center,
            children: [
              AnimatedBuilder(
                animation: _glow,
                builder: (_, __) => Transform.scale(
                  scale: _glow.value,
                  child: Container(
                    width: 130,
                    height: 130,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          _C.blue1.withOpacity(0.5),
                          _C.blue1.withOpacity(0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: _C.gradientLogo,
                  boxShadow: [
                    BoxShadow(
                      color: _C.blue1.withOpacity(0.55),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                    BoxShadow(
                      color: _C.blue2.withOpacity(0.45),
                      blurRadius: 60,
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(2),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF0A1F3D), Color(0xFF030A18)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      'assets/images/logo.png',
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Center(
                        child: Text(
                          'VOR4X',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            color: _C.blue1,
                            shadows: [
                              Shadow(color: Color(0x993B82F6), blurRadius: 12),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        ShaderMask(
          shaderCallback: (bounds) => _C.gradientBrand.createShader(bounds),
          child: const Text(
            'VOR4X',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: 4,
              color: Colors.white,
              shadows: [
                Shadow(color: Color(0x663B82F6), blurRadius: 12),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'BY ZIL',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 2,
            color: _C.blue6,
            shadows: [
              Shadow(color: Color(0x803B82F6), blurRadius: 8),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CARD (Glass)
  // ═══════════════════════════════════════════════════════════
  Widget _buildCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 24),
          decoration: BoxDecoration(
            color: _C.cardGlass,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.borderBlue, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 60,
                offset: const Offset(0, 20),
              ),
              BoxShadow(
                color: _C.blue2.withOpacity(0.15),
                blurRadius: 60,
              ),
            ],
          ),
          child: Column(
            children: [
              _buildClock(),
              const SizedBox(height: 22),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    _buildUsernameField(),
                    const SizedBox(height: 14),
                    _buildPasswordField(),
                    const SizedBox(height: 20),
                    _buildLoginButton(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // CLOCK
  // ═══════════════════════════════════════════════════════════
  Widget _buildClock() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _C.clockGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.borderBlue, width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _C.blue4,
              boxShadow: [
                BoxShadow(
                  color: _C.blue4.withOpacity(0.8),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            _clockTime,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
              color: _C.blue6,
              fontFeatures: [FontFeature.tabularFigures()],
              shadows: [
                Shadow(color: Color(0x8060A5FA), blurRadius: 8),
              ],
            ),
          ),
          const Spacer(),
          Text(
            _clockDate,
            style: const TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.3,
              color: _C.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FIELD WRAPPER
  // ═══════════════════════════════════════════════════════════
  Widget _buildField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String hint,
    required IconData icon,
    required bool isPassword,
    bool obscure = false,
    VoidCallback? onToggleObscure,
  }) {
    final isFocused = focusNode.hasFocus;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: isFocused ? _C.blue1.withOpacity(0.08) : _C.inputGlass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isFocused ? _C.borderBlueHi : _C.borderBlue,
          width: 1.5,
        ),
        boxShadow: isFocused
            ? [
                BoxShadow(
                  color: _C.blue1.withOpacity(0.15),
                  blurRadius: 20,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: _C.blue2.withOpacity(0.25),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          const SizedBox(width: 16),
          Icon(
            icon,
            color: isFocused ? _C.blue1 : _C.textMuted,
            size: 20,
          ),
          Expanded(
            child: TextFormField(
              controller: controller,
              focusNode: focusNode,
              obscureText: obscure,
              style: const TextStyle(
                color: _C.textWhite,
                fontSize: 14.5,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.2,
              ),
              validator: (v) =>
                  (v == null || v.isEmpty) ? '$hint wajib diisi' : null,
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(
                  color: _C.textMuted,
                  fontSize: 14.5,
                  fontWeight: FontWeight.w400,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 17,
                ),
              ),
            ),
          ),
          if (isPassword && onToggleObscure != null)
            IconButton(
              icon: Icon(
                obscure
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
                color: _C.textMuted,
                size: 20,
              ),
              onPressed: onToggleObscure,
            )
          else
            const SizedBox(width: 14),
        ],
      ),
    );
  }

  Widget _buildUsernameField() {
    return _buildField(
      controller: userCtrl,
      focusNode: _userFocus,
      hint: 'Username',
      icon: Icons.person_outline_rounded,
      isPassword: false,
    );
  }

  Widget _buildPasswordField() {
    return _buildField(
      controller: passCtrl,
      focusNode: _passFocus,
      hint: 'Password',
      icon: Icons.lock_outline_rounded,
      isPassword: true,
      obscure: _obscurePass,
      onToggleObscure: () => setState(() => _obscurePass = !_obscurePass),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOGIN BUTTON
  // ═══════════════════════════════════════════════════════════
  Widget _buildLoginButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: double.infinity,
      height: 54,
      decoration: BoxDecoration(
        gradient: _isLoading ? null : _C.gradientBtn,
        color: _isLoading ? const Color(0xFF1A2A45) : null,
        borderRadius: BorderRadius.circular(14),
        boxShadow: _isLoading
            ? null
            : [
                BoxShadow(
                  color: _C.blue1.withOpacity(0.5),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
                BoxShadow(
                  color: _C.blue2.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _isLoading ? null : _login,
          child: Stack(
            children: [
              if (!_isLoading)
                AnimatedBuilder(
                  animation: _shine,
                  builder: (_, __) {
                    return Positioned.fill(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: FractionallySizedBox(
                          widthFactor: 0.3,
                          alignment: Alignment(_shine.value, 0),
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.white.withOpacity(0),
                                  Colors.white.withOpacity(0.35),
                                  Colors.white.withOpacity(0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              Center(
                child: _isLoading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: Colors.white,
                        ),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'MASUK',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.5,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.5,
                            ),
                          ),
                          SizedBox(width: 10),
                          Icon(
                            Icons.arrow_forward_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // FOOTER
  // ═══════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildFooterLink(
          icon: Icons.telegram,
          label: 'Contact Owner',
          onTap: () async {
            await launchUrl(
              Uri.parse('https://t.me/r4pzzxi'),
              mode: LaunchMode.externalApplication,
            );
          },
        ),
        Container(
          width: 1,
          height: 12,
          margin: const EdgeInsets.symmetric(horizontal: 12),
          color: _C.borderBlue,
        ),
        _buildFooterLink(
          icon: Icons.info_outline_rounded,
          label: '2.0.0',
          onTap: () {},
        ),
      ],
    );
  }

  Widget _buildFooterLink({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: _C.textMuted, size: 14),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  color: _C.textMuted,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// CUSTOM PAINTER — Blue Dot Grid
// ═══════════════════════════════════════════════════════════
class _BlueDotGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const spacing = 32.0;
    final paint = Paint()
      ..color = const Color(0xFF60A5FA).withOpacity(0.18)
      ..style = PaintingStyle.fill;

    final center = Offset(size.width / 2, size.height / 2);
    final maxDist = size.width > size.height ? size.width : size.height;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        final dist = (Offset(x, y) - center).distance;
        final opacity = (1 - (dist / (maxDist * 0.7))).clamp(0.0, 1.0);
        if (opacity > 0.05) {
          paint.color = const Color(0xFF60A5FA).withOpacity(0.18 * opacity);
          canvas.drawCircle(Offset(x, y), 1, paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════
// ALERT TYPE
// ═══════════════════════════════════════════════════════════
enum _AlertType { error, warning, success }