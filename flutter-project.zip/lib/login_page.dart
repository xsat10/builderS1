import 'dart:convert';
import 'dart:ui';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'splash.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late AnimationController _pulseController;
  late AnimationController _floatController;
  late AnimationController _shineController;

  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // ============================================================
  // STUX01 FUTURISTIC THEME
  // ============================================================

  static const Color bgDark = Color(0xFF050810);
  static const Color bgNavy = Color(0xFF08111F);
  static const Color cyan = Color(0xFF00E5FF);
  static const Color cyanSoft = Color(0xFF67F5FF);
  static const Color blue = Color(0xFF1976FF);
  static const Color white = Color(0xFFF5F9FF);
  static const Color silver = Color(0xFFB8C4D6);
  static const Color grey = Color(0xFF718096);

  static const Color glass = Color(0x121B2A3D);
  static const Color glassStrong = Color(0x1AFFFFFF);

  LinearGradient get primaryGradient {
    return const LinearGradient(
      colors: [
        Color(0xFF00E5FF),
        Color(0xFF0878FF),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  LinearGradient get silverGradient {
    return const LinearGradient(
      colors: [
        Color(0xFFFFFFFF),
        Color(0xFFB8C4D6),
      ],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  @override
  void initState() {
    super.initState();

    _initAnimations();
    initLogin();
  }

  // ============================================================
  // ANIMATIONS
  // ============================================================

  void _initAnimations() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5000),
    )..repeat(reverse: true);

    _shineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();

    _fadeAnim = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );

    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOutCubic,
      ),
    );

    _controller.forward();
  }

  // ============================================================
  // AUTO LOGIN
  // ============================================================

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();

    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null &&
        savedPass != null &&
        savedKey != null) {
      final uri = Uri.parse(
        "http://guntur-jier.hoshino.my.id:11288/myInfo"
        "?username=$savedUser"
        "&password=$savedPass"
        "&androidId=$androidId"
        "&key=$savedKey",
      );

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
                listDoos: (data['listDDoS'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
              ),
            ),
          );
        }
      } catch (_) {}
    }
  }

  // ============================================================
  // DEVICE ID
  // ============================================================

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;

    return android.id ?? "unknown_device";
  }

  // ============================================================
  // LOAD CONFIG
  // ============================================================
  //
  // CATATAN:
  // Implementasi loadConfig() / URL GitHub tidak ada pada source
  // yang dikirim. Tidak dibuat URL dummy agar tidak mengubah
  // sistem konfigurasi asli.
  //
  // Jika project asli memiliki loadConfig() dari file lain,
  // pertahankan implementasi asli tersebut.
  //
  // ============================================================

  Future<void> loadConfig() async {
    // Implementasi config asli dari project tetap digunakan
    // apabila tersedia pada file konfigurasi project.
  }

  // ============================================================
  // LOGIN
  // ============================================================

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() {
      isLoading = true;
    });

    try {
      final validate = await http.post(
        Uri.parse(
          "http://guntur-jier.hoshino.my.id:11288/validate",
        ),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "ACCESS EXPIRED",
          message:
              "Masa akses Anda telah berakhir. Silakan perpanjang.",
          color: cyan,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg =
            (validData['message'] ?? "").toLowerCase();

        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          _showPopup(
            title: "ACTIVE SESSION",
            message:
                "Akun ini sedang login di perangkat lain. Logout terlebih dahulu.",
            color: cyan,
          );
        } else {
          _showPopup(
            title: "LOGIN FAILED",
            message: "Username atau password salah.",
            color: cyan,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();

        await prefs.setString("username", username);
        await prefs.setString("password", password);
        await prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
                listDoos: (validData['listDDoS'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
                news: (validData['news'] as List? ?? [])
                    .map(
                      (e) => Map<String, dynamic>.from(e as Map),
                    )
                    .toList(),
              ),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) {
        _showPopup(
          title: "CONNECTION ERROR",
          message:
              "Gagal terhubung ke server. Periksa internet Anda.",
          color: cyan,
        );
      }
    }

    if (mounted) {
      setState(() {
        isLoading = false;
      });
    }
  }

  // ============================================================
  // POPUP
  // ============================================================

  void _showPopup({
    required String title,
    required String message,
    Color color = cyan,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.72),
      builder: (_) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(
            horizontal: 24,
          ),
          child: TweenAnimationBuilder<double>(
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOutBack,
            tween: Tween<double>(
              begin: 0.85,
              end: 1,
            ),
            builder: (context, value, child) {
              return Transform.scale(
                scale: value,
                child: child,
              );
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: 22,
                  sigmaY: 22,
                ),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: bgNavy.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(
                      color: color.withOpacity(0.28),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: color.withOpacity(0.12),
                        blurRadius: 40,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 62,
                        height: 62,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: primaryGradient,
                          boxShadow: [
                            BoxShadow(
                              color: color.withOpacity(0.3),
                              blurRadius: 22,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.shield_rounded,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),

                      const SizedBox(height: 20),

                      Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: white,
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),

                      const SizedBox(height: 12),

                      Text(
                        message,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: silver,
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 24),

                      Row(
                        children: [
                          if (showContact) ...[
                            Expanded(
                              child: _popupButton(
                                text: "ADMIN",
                                outlined: true,
                                onTap: () async {
                                  await launchUrl(
                                    Uri.parse(
                                      "https://t.me/Xseishz",
                                    ),
                                    mode: LaunchMode
                                        .externalApplication,
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                          ],
                          Expanded(
                            child: _popupButton(
                              text: "CLOSE",
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _popupButton({
    required String text,
    required VoidCallback onTap,
    bool outlined = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          gradient: outlined ? null : primaryGradient,
          color: outlined
              ? Colors.white.withOpacity(0.035)
              : null,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: cyan.withOpacity(
              outlined ? 0.3 : 0.0,
            ),
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: outlined ? cyan : Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.2,
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          const Positioned.fill(
            child: _CyberBackground(),
          ),

          Positioned(
            top: -100,
            right: -80,
            child: AnimatedBuilder(
              animation: _pulseController,
              builder: (_, child) {
                final scale =
                    0.9 + (_pulseController.value * 0.15);

                return Transform.scale(
                  scale: scale,
                  child: child,
                );
              },
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: cyan.withOpacity(0.035),
                  boxShadow: [
                    BoxShadow(
                      color: cyan.withOpacity(0.07),
                      blurRadius: 100,
                      spreadRadius: 20,
                    ),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isSmall =
                        constraints.maxHeight < 700;

                    return SingleChildScrollView(
                      physics:
                          const BouncingScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(
                        22,
                        isSmall ? 18 : 28,
                        22,
                        30,
                      ),
                      child: Center(
                        child: ConstrainedBox(
                          constraints:
                              const BoxConstraints(
                            maxWidth: 520,
                          ),
                          child: Column(
                            children: [
                              _buildTopHeader(
                                isSmall,
                              ),

                              SizedBox(
                                height: isSmall ? 20 : 30,
                              ),

                              _buildMemberActivity(),

                              SizedBox(
                                height: isSmall ? 18 : 24,
                              ),

                              _buildLoginCard(),

                              SizedBox(
                                height: isSmall ? 20 : 28,
                              ),

                              _buildSecurityStatus(),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _buildTopHeader(bool isSmall) {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseController,
          builder: (_, child) {
            final glow =
                0.35 + (_pulseController.value * 0.18);

            return Container(
              width: isSmall ? 82 : 96,
              height: isSmall ? 82 : 96,
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: primaryGradient,
                boxShadow: [
                  BoxShadow(
                    color: cyan.withOpacity(glow),
                    blurRadius: 30,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: child,
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: bgNavy,
              borderRadius: BorderRadius.circular(26),
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(25),
              child: Image.asset(
                "assets/images/login.jpg",
                fit: BoxFit.cover,
                errorBuilder:
                    (context, error, stackTrace) {
                  return const Center(
                    child: Icon(
                      Icons.shield_rounded,
                      color: cyan,
                      size: 42,
                    ),
                  );
                },
              ),
            ),
          ),
        ),

        const SizedBox(height: 20),

        ShaderMask(
          shaderCallback: (bounds) {
            return silverGradient.createShader(bounds);
          },
          child: const Text(
            "STUX01",
            style: TextStyle(
              color: Colors.white,
              fontSize: 31,
              fontWeight: FontWeight.w900,
              letterSpacing: 5,
              height: 1,
            ),
          ),
        ),

        const SizedBox(height: 8),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 28,
              height: 1,
              color: cyan.withOpacity(0.5),
            ),
            const SizedBox(width: 10),
            const Text(
              "CRASHER",
              style: TextStyle(
                color: cyanSoft,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 4,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 28,
              height: 1,
              color: cyan.withOpacity(0.5),
            ),
          ],
        ),

        const SizedBox(height: 8),

        Text(
          "SECURE MEMBER ACCESS",
          style: TextStyle(
            color: grey.withOpacity(0.9),
            fontSize: 10,
            fontWeight: FontWeight.w600,
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // MEMBER ACTIVITY
  // ============================================================

  Widget _buildMemberActivity() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: 18,
          sigmaY: 18,
        ),
        child: Container(
          padding: const EdgeInsets.fromLTRB(
            18,
            16,
            18,
            14,
          ),
          decoration: BoxDecoration(
            color: glass,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: Colors.white.withOpacity(0.07),
            ),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.analytics_outlined,
                    color: cyan,
                    size: 17,
                  ),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      "MEMBER ACTIVITY",
                      style: TextStyle(
                        color: white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                      ),
                    ),
                  ),
                  _liveBadge(),
                ],
              ),

              const SizedBox(height: 15),

              SizedBox(
                height: 90,
                width: double.infinity,
                child: CustomPaint(
                  painter: _ActivityChartPainter(
                    progress:
                        _pulseController.value,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              Row(
                children: [
                  _networkInfo(
                    "MEMBERS",
                    "LIVE",
                    Icons.people_alt_outlined,
                  ),
                  const SizedBox(width: 10),
                  _networkInfo(
                    "ACTIVE NETWORK",
                    "SECURE",
                    Icons.public_rounded,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _liveBadge() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        return Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 9,
            vertical: 5,
          ),
          decoration: BoxDecoration(
            color: cyan.withOpacity(0.08),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: cyan.withOpacity(
                0.18 +
                    (_pulseController.value * 0.15),
              ),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 5,
                height: 5,
                decoration: BoxDecoration(
                  color: cyan,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: cyan.withOpacity(0.8),
                      blurRadius: 7,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Text(
                "LIVE",
                style: TextStyle(
                  color: cyanSoft,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _networkInfo(
    String title,
    String value,
    IconData icon,
  ) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.025),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
            color: Colors.white.withOpacity(0.045),
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: cyan.withOpacity(0.7),
              size: 17,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: grey.withOpacity(0.9),
                      fontSize: 7,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    style: const TextStyle(
                      color: silver,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.7,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // LOGIN CARD
  // ============================================================

  Widget _buildLoginCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: 25,
          sigmaY: 25,
        ),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: const Color(0x15131D2D),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: Colors.white.withOpacity(0.09),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.35),
                blurRadius: 35,
                offset: const Offset(0, 18),
              ),
              BoxShadow(
                color: cyan.withOpacity(0.035),
                blurRadius: 50,
              ),
            ],
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: cyan.withOpacity(0.07),
                        borderRadius:
                            BorderRadius.circular(12),
                        border: Border.all(
                          color: cyan.withOpacity(0.13),
                        ),
                      ),
                      child: const Icon(
                        Icons.lock_person_outlined,
                        color: cyan,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            "MEMBER LOGIN",
                            style: TextStyle(
                              color: white,
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.2,
                            ),
                          ),
                          SizedBox(height: 3),
                          Text(
                            "Authenticate your secure session",
                            style: TextStyle(
                              color: grey,
                              fontSize: 9,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                _buildInput(
                  controller: userController,
                  label: "Username",
                  icon: Icons.person_outline_rounded,
                ),

                const SizedBox(height: 14),

                _buildInput(
                  controller: passController,
                  label: "Password",
                  icon: Icons.key_outlined,
                  isPassword: true,
                ),

                const SizedBox(height: 22),

                _buildButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // INPUT
  // ============================================================

  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.16),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: Colors.white.withOpacity(0.075),
        ),
      ),
      child: TextFormField(
        controller: controller,
        obscureText:
            isPassword ? _obscurePassword : false,
        style: const TextStyle(
          color: white,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: cyan,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: grey.withOpacity(0.95),
            fontSize: 12,
          ),
          floatingLabelStyle: const TextStyle(
            color: cyan,
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
          prefixIcon: Padding(
            padding: const EdgeInsets.only(left: 5),
            child: Icon(
              icon,
              color: cyan.withOpacity(0.72),
              size: 20,
            ),
          ),
          suffixIcon: isPassword
              ? IconButton(
                  splashRadius: 20,
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: grey,
                    size: 19,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword =
                          !_obscurePassword;
                    });
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 18,
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "$label tidak boleh kosong";
          }

          return null;
        },
      ),
    );
  }

  // ============================================================
  // LOGIN BUTTON
  // ============================================================

  Widget _buildButton() {
    return AnimatedBuilder(
      animation: _shineController,
      builder: (_, __) {
        return GestureDetector(
          onTap: isLoading ? null : login,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            width: double.infinity,
            height: 55,
            decoration: BoxDecoration(
              gradient: primaryGradient,
              borderRadius: BorderRadius.circular(17),
              boxShadow: [
                BoxShadow(
                  color: cyan.withOpacity(0.20),
                  blurRadius: 22,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius:
                      BorderRadius.circular(17),
                  child: Align(
                    alignment: Alignment(
                      -1.5 +
                          (_shineController.value * 3),
                      0,
                    ),
                    child: Container(
                      width: 70,
                      height: 100,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0),
                            Colors.white.withOpacity(0.18),
                            Colors.white.withOpacity(0),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                Center(
                  child: isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2.2,
                            color: Colors.white,
                          ),
                        )
                      : const Row(
                          mainAxisAlignment:
                              MainAxisAlignment.center,
                          children: [
                            Text(
                              "LOGIN",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight:
                                    FontWeight.w900,
                                letterSpacing: 2,
                              ),
                            ),
                            SizedBox(width: 12),
                            Icon(
                              Icons.arrow_forward_rounded,
                              color: Colors.white,
                              size: 20,
                            ),
                          ],
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // SECURITY STATUS
  // ============================================================

  Widget _buildSecurityStatus() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        final opacity =
            0.45 + (_pulseController.value * 0.25);

        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: cyan.withOpacity(0.06),
                border: Border.all(
                  color: cyan.withOpacity(0.13),
                ),
              ),
              child: const Icon(
                Icons.verified_user_outlined,
                color: cyan,
                size: 15,
              ),
            ),
            const SizedBox(width: 9),
            Text(
              "ENCRYPTED MEMBER CONNECTION",
              style: TextStyle(
                color: silver.withOpacity(opacity),
                fontSize: 8,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                color: cyan,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: cyan.withOpacity(0.7),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _controller.dispose();
    _pulseController.dispose();
    _floatController.dispose();
    _shineController.dispose();

    userController.dispose();
    passController.dispose();

    super.dispose();
  }
}

// ================================================================
// CYBER BACKGROUND
// ================================================================

class _CyberBackground extends StatefulWidget {
  const _CyberBackground();

  @override
  State<_CyberBackground> createState() =>
      _CyberBackgroundState();
}

class _CyberBackgroundState
    extends State<_CyberBackground>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return CustomPaint(
          painter: _CyberBackgroundPainter(
            animation: _controller.value,
          ),
        );
      },
    );
  }
}

class _CyberBackgroundPainter extends CustomPainter {
  final double animation;

  _CyberBackgroundPainter({
    required this.animation,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    final backgroundPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFF07101C),
          Color(0xFF04070E),
          Color(0xFF020409),
        ],
      ).createShader(rect);

    canvas.drawRect(rect, backgroundPaint);

    // ------------------------------------------------------------
    // RADIAL GLOW
    // ------------------------------------------------------------

    final glowPaint = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.85, -0.9),
        radius: 1.1,
        colors: [
          const Color(0xFF00E5FF).withOpacity(0.07),
          Colors.transparent,
        ],
      ).createShader(rect);

    canvas.drawRect(rect, glowPaint);

    // ------------------------------------------------------------
    // GRID
    // ------------------------------------------------------------

    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.018)
      ..strokeWidth = 0.7;

    const gridSize = 32.0;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        gridPaint,
      );
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    // ------------------------------------------------------------
    // MAJOR GRID
    // ------------------------------------------------------------

    final majorPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.035)
      ..strokeWidth = 1;

    for (double x = 0;
        x <= size.width;
        x += gridSize * 5) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        majorPaint,
      );
    }

    for (double y = 0;
        y <= size.height;
        y += gridSize * 5) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        majorPaint,
      );
    }

    // ------------------------------------------------------------
    // GRID DOTS
    // ------------------------------------------------------------

    final dotPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.055);

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0;
          y <= size.height;
          y += gridSize) {
        canvas.drawCircle(
          Offset(x, y),
          1.1,
          dotPaint,
        );
      }
    }

    // ------------------------------------------------------------
    // AMBIENT PARTICLES
    // ------------------------------------------------------------

    final particlePaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.12);

    final particles = <Offset>[
      Offset(
        size.width * 0.12,
        size.height *
            (0.18 + animation * 0.05),
      ),
      Offset(
        size.width * 0.82,
        size.height *
            (0.30 - animation * 0.04),
      ),
      Offset(
        size.width * 0.26,
        size.height *
            (0.72 + animation * 0.04),
      ),
      Offset(
        size.width * 0.91,
        size.height *
            (0.78 - animation * 0.03),
      ),
      Offset(
        size.width * 0.53,
        size.height *
            (0.12 + animation * 0.025),
      ),
    ];

    for (final point in particles) {
      canvas.drawCircle(
        point,
        1.7,
        particlePaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant _CyberBackgroundPainter oldDelegate,
  ) {
    return oldDelegate.animation != animation;
  }
}

// ================================================================
// MEMBER ACTIVITY CHART
// ================================================================

class _ActivityChartPainter extends CustomPainter {
  final double progress;

  _ActivityChartPainter({
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final chartRect = Rect.fromLTWH(
      0,
      0,
      size.width,
      size.height,
    );

    // ------------------------------------------------------------
    // CHART GRID
    // ------------------------------------------------------------

    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.035)
      ..strokeWidth = 0.7;

    const rows = 4;

    for (int i = 0; i <= rows; i++) {
      final y = size.height * i / rows;

      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    for (int i = 0; i <= 8; i++) {
      final x = size.width * i / 8;

      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        gridPaint,
      );
    }

    // ------------------------------------------------------------
    // CHART LINE
    // Visual-only HUD shape; tidak berasal dari backend/member data.
    // ------------------------------------------------------------

    final points = <Offset>[
      Offset(size.width * 0.00, size.height * 0.70),
      Offset(size.width * 0.10, size.height * 0.62),
      Offset(size.width * 0.20, size.height * 0.67),
      Offset(size.width * 0.30, size.height * 0.42),
      Offset(size.width * 0.40, size.height * 0.50),
      Offset(size.width * 0.50, size.height * 0.31),
      Offset(size.width * 0.60, size.height * 0.38),
      Offset(size.width * 0.70, size.height * 0.20),
      Offset(size.width * 0.80, size.height * 0.30),
      Offset(size.width * 0.90, size.height * 0.13),
      Offset(size.width * 1.00, size.height * 0.18),
    ];

    final path = Path();

    if (points.isNotEmpty) {
      path.moveTo(
        points.first.dx,
        points.first.dy,
      );

      for (int i = 1; i < points.length; i++) {
        final previous = points[i - 1];
        final current = points[i];

        final controlPoint1 = Offset(
          previous.dx +
              ((current.dx - previous.dx) * 0.5),
          previous.dy,
        );

        final controlPoint2 = Offset(
          current.dx -
              ((current.dx - previous.dx) * 0.5),
          current.dy,
        );

        path.cubicTo(
          controlPoint1.dx,
          controlPoint1.dy,
          controlPoint2.dx,
          controlPoint2.dy,
          current.dx,
          current.dy,
        );
      }
    }

    // ------------------------------------------------------------
    // GLOW
    // ------------------------------------------------------------

    final glowPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7
      ..maskFilter = const MaskFilter.blur(
        BlurStyle.normal,
        7,
      );

    canvas.drawPath(path, glowPaint);

    // ------------------------------------------------------------
    // MAIN LINE
    // ------------------------------------------------------------

    final linePaint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color(0xFF00BBD4),
          Color(0xFF00E5FF),
          Color(0xFF65F6FF),
        ],
      ).createShader(chartRect)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8;

    canvas.drawPath(path, linePaint);

    // ------------------------------------------------------------
    // LAST POINT
    // ------------------------------------------------------------

    final last = points.last;

    final pulseRadius =
        4 + (progress * 3);

    final glowPointPaint = Paint()
      ..color = const Color(0xFF00E5FF)
          .withOpacity(0.18);

    canvas.drawCircle(
      last,
      pulseRadius + 4,
      glowPointPaint,
    );

    final pointPaint = Paint()
      ..color = const Color(0xFFB9FAFF);

    canvas.drawCircle(
      last,
      3,
      pointPaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant _ActivityChartPainter oldDelegate,
  ) {
    return oldDelegate.progress != progress;
  }
}