import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'main.dart';

// ─── 🎯 ROLE SYSTEM BARU ──────────────────────────────────────────────────────
const Map<String, int> ROLE_LEVEL = {
  'ceo': 9,
  'owner': 8,
  'admin': 7,
  'tangan_kanan': 6,
  'vip': 5,
  'reseller': 4,
  'full_up': 3,
  'member_perbulan': 2,
  'member_perminggu': 2,
  'member_perhari': 1
};

const List<String> GLOBAL_SENDER_ROLES = [
  'ceo',
  'owner',
  'admin',
  'tangan_kanan',
  'vip'
];

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
int getRoleLevel(String role) {
  return ROLE_LEVEL[role.toLowerCase()] ?? 0;
}

String getRoleDisplay(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return 'CEO';
    case 'owner': return 'OWNER';
    case 'admin': return 'ADMIN';
    case 'tangan_kanan': return 'TANGAN KANAN';
    case 'vip': return 'VIP';
    case 'reseller': return 'RESELLER';
    case 'full_up': return 'FULL UP';
    case 'member_perbulan': return 'MEMBER BULANAN';
    case 'member_perminggu': return 'MEMBER MINGGUAN';
    case 'member_perhari': return 'MEMBER HARIAN';
    default: return role.toUpperCase();
  }
}

Color getRoleColor(String role) {
  switch (role.toLowerCase()) {
    case 'ceo': return const Color(0xFFFFD700);
    case 'owner': return const Color(0xFFFF1744);
    case 'admin': return const Color(0xFFF59E0B);
    case 'tangan_kanan': return const Color(0xFF8B5CF6);
    case 'vip': return const Color(0xFFEC4899);
    case 'reseller': return const Color(0xFF22C55E);
    case 'full_up': return const Color(0xFF10B981);
    case 'member_perbulan': return const Color(0xFF3B82F6);
    case 'member_perminggu': return const Color(0xFFF97316);
    case 'member_perhari': return const Color(0xFF6B7280);
    default: return Colors.white;
  }
}

class ChatRoomPage extends StatefulWidget {
  final String username;

  const ChatRoomPage({
    super.key,
    required this.username,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> with SingleTickerProviderStateMixin {
  final TextEditingController msgCtrl = TextEditingController();
  final ScrollController scrollCtrl = ScrollController();
  final FocusNode focusNode = FocusNode();

  List<Map<String, dynamic>> chats = [];
  bool loading = true;
  bool isSending = false;
  bool showSendButton = false;
  bool showScrollButton = false;
  final GlobalKey<RefreshIndicatorState> refreshKey = GlobalKey<RefreshIndicatorState>();

  // --- Modern Glassmorphism Color Palette ---
  final Color _bgPrimary = const Color(0xFF0A0E17);
  final Color _bgSecondary = const Color(0xFF111827);
  final Color _bgCard = const Color(0xFF1A2332);
  final Color _bgCardHover = const Color(0xFF243044);
  final Color _surfaceGlass = const Color(0x1AFFFFFF);
  final Color _borderGlass = const Color(0x33FFFFFF);

  // --- Vibrant Accent Colors ---
  final Color _accentPrimary = const Color(0xFF6C63FF);
  final Color _accentSecondary = const Color(0xFF3F3D56);
  final Color _accentGradientStart = const Color(0xFF6C63FF);
  final Color _accentGradientEnd = const Color(0xFF9D4EDD);
  final Color _successGreen = const Color(0xFF00C9A7);

  // --- Text Colors ---
  final Color _textPrimary = const Color(0xFFF8FAFC);
  final Color _textSecondary = const Color(0xFF94A3B8);
  final Color _textTertiary = const Color(0xFF475569);

  // --- Bubble Colors ---
  final Color _bubbleOutgoingStart = const Color(0xFF6C63FF);
  final Color _bubbleOutgoingEnd = const Color(0xFF9D4EDD);
  final Color _bubbleIncoming = const Color(0xFF1E293B);

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // ─── ROLE CACHE ─────────────────────────────────────────────────────────────
  Map<String, String> _roleCache = {};
  Map<String, Color> _colorCache = {};

  @override
  void initState() {
    super.initState();
    _loadChats();
    focusNode.addListener(_onFocusChange);
    scrollCtrl.addListener(_scrollListener);

    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.3, end: 0.7).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    focusNode.removeListener(_onFocusChange);
    scrollCtrl.removeListener(_scrollListener);
    focusNode.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    final offset = scrollCtrl.offset;
    final maxScroll = scrollCtrl.position.maxScrollExtent;

    if (maxScroll - offset > 300 && !showScrollButton) {
      setState(() => showScrollButton = true);
    } else if (maxScroll - offset <= 300 && showScrollButton) {
      setState(() => showScrollButton = false);
    }
  }

  void _onFocusChange() {
    if (focusNode.hasFocus) {
      Future.delayed(const Duration(milliseconds: 300), _scrollToBottom);
    }
  }

  Future<void> _loadChats() async {
    try {
      final res = await http.get(Uri.parse('http://paultzy.pteroqhost.web.id5015/chatroom'));
      if (res.statusCode == 200) {
        final List<dynamic> data = jsonDecode(res.body);
        setState(() {
          chats = List<Map<String, dynamic>>.from(data);
          loading = false;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
        
        // Load role untuk setiap user di chat
        for (var chat in chats) {
          final from = chat['from'] as String?;
          if (from != null && from != widget.username && !_roleCache.containsKey(from)) {
            _fetchUserRole(from);
          }
        }
      }
    } catch (e) {
      debugPrint("Error memuat pesan: $e");
      setState(() => loading = false);
    }
  }

  Future<void> _fetchUserRole(String username) async {
    try {
      // Coba dapatkan role dari database
      final res = await http.get(
        Uri.parse('http://paultzy.pteroqhost.web.id5015/getUserRole?username=$username'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final role = data['role'] ?? 'member_perhari';
          setState(() {
            _roleCache[username] = role;
            _colorCache[username] = getRoleColor(role);
          });
        }
      }
    } catch (e) {
      // Jika gagal, gunakan default
      setState(() {
        _roleCache[username] = 'member_perhari';
        _colorCache[username] = getRoleColor('member_perhari');
      });
    }
  }

  Future<void> _refreshChats() async {
    await _loadChats();
  }

  Future<void> _sendMessage() async {
    final msg = msgCtrl.text.trim();
    if (msg.isEmpty || isSending) return;

    setState(() {
      isSending = true;
      showSendButton = false;
    });

    final newMessage = {
      "from": widget.username,
      "message": msg,
      "time": DateTime.now().millisecondsSinceEpoch,
      "status": "mengirim",
    };

    msgCtrl.clear();

    setState(() {
      chats.add(newMessage);
    });

    _scrollToBottom();

    try {
      final response = await http.post(
        Uri.parse('http://paultzy.pteroqhost.web.id5015/chatroom'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "from": widget.username,
          "message": msg,
        }),
      );

      if (response.statusCode == 200) {
        final int lastIndex = chats.length - 1;
        setState(() {
          chats[lastIndex]["status"] = "terkirim";
        });
      } else {
        setState(() {
          chats[chats.length - 1]["status"] = "gagal";
        });
      }
    } catch (e) {
      debugPrint("Error mengirim: $e");
      setState(() {
        chats[chats.length - 1]["status"] = "gagal";
      });
    } finally {
      setState(() => isSending = false);
    }
  }

  void _scrollToBottom() {
    if (scrollCtrl.hasClients) {
      scrollCtrl.animateTo(
        scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  String _formatTime(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
    return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _formatDate(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final today = DateTime.now();

    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return "Hari Ini";
    } else if (date.year == today.year && date.month == today.month && date.day == today.day - 1) {
      return "Kemarin";
    } else {
      return "${date.day}/${date.month}/${date.year}";
    }
  }

  Widget _buildMessageStatus(String status) {
    switch (status) {
      case "mengirim":
        return SizedBox(
          width: 14,
          height: 14,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(_textTertiary),
          ),
        );
      case "terkirim":
        return Icon(Icons.check, size: 16, color: _textTertiary);
      case "diterima":
        return Icon(Icons.done_all, size: 16, color: _textTertiary);
      case "dibaca":
        return Icon(Icons.done_all, size: 16, color: _accentPrimary);
      case "gagal":
        return Icon(Icons.error_outline, size: 16, color: Colors.red[400]);
      default:
        return Icon(Icons.check, size: 16, color: _textTertiary);
    }
  }

  Widget _buildAvatar(String username, {bool isOnline = true}) {
    final role = _roleCache[username] ?? 'member_perhari';
    final color = _colorCache[username] ?? getRoleColor(role);
    final roleDisplay = getRoleDisplay(role);
    
    return Stack(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [color, color.withOpacity(0.7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Center(
            child: Text(
              username.substring(0, 1).toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 2,
                    color: Colors.black26,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ),
        ),
        // Role badge di pojok bawah avatar
        Positioned(
          bottom: -2,
          right: -2,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: Colors.black, width: 1),
            ),
            child: Text(
              roleDisplay.length > 3 ? roleDisplay.substring(0, 3) : roleDisplay,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 6,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        if (isOnline)
          Positioned(
            bottom: 2,
            right: 2,
            child: Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: _successGreen,
                shape: BoxShape.circle,
                border: Border.all(color: _bgPrimary, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _successGreen.withOpacity(0.5),
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> item, bool isMe) {
    final isFirstInSequence = chats.indexOf(item) == 0 ||
        chats[chats.indexOf(item) - 1]['from'] != item['from'];
    
    final from = item['from'] as String;
    final role = _roleCache[from] ?? 'member_perhari';
    final roleDisplay = getRoleDisplay(role);
    final roleColor = _colorCache[from] ?? getRoleColor(role);

    return Padding(
      padding: EdgeInsets.only(
        top: isFirstInSequence ? 8 : 2,
        left: 12,
        right: 12,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isMe) ...[
            AnimatedOpacity(
              opacity: isFirstInSequence ? 1 : 0,
              duration: const Duration(milliseconds: 200),
              child: _buildAvatar(from),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isMe && isFirstInSequence)
                  Padding(
                    padding: const EdgeInsets.only(left: 12, bottom: 4),
                    child: Row(
                      children: [
                        Text(
                          from,
                          style: TextStyle(
                            color: _textSecondary,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: roleColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: roleColor.withOpacity(0.2)),
                          ),
                          child: Text(
                            roleDisplay,
                            style: TextStyle(
                              color: roleColor,
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.7,
                  ),
                  decoration: BoxDecoration(
                    gradient: isMe
                        ? LinearGradient(
                            colors: [_bubbleOutgoingStart, _bubbleOutgoingEnd],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: isMe ? null : _bubbleIncoming,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(20),
                      topRight: const Radius.circular(20),
                      bottomLeft: isMe ? const Radius.circular(20) : const Radius.circular(4),
                      bottomRight: isMe ? const Radius.circular(4) : const Radius.circular(20),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isMe
                            ? _accentPrimary.withOpacity(0.3)
                            : Colors.black.withOpacity(0.2),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['message'],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            height: 1.4,
                            letterSpacing: 0.2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _formatTime(item['time']),
                              style: TextStyle(
                                color: isMe ? Colors.white.withOpacity(0.7) : _textTertiary,
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            if (isMe) ...[
                              const SizedBox(width: 6),
                              _buildMessageStatus(item['status'] ?? 'terkirim'),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (isMe) const SizedBox(width: 8),
        ],
      ),
    );
  }

  Widget _buildDateSeparator(String date) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    _textTertiary.withOpacity(0.3),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_bgCard, _bgCardHover],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _borderGlass, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                date,
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _textTertiary.withOpacity(0.3),
                    Colors.transparent,
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: _bgPrimary,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: _bgPrimary,
        body: SafeArea(
          child: Column(
            children: [
              // --- Modern Header with Glassmorphism ---
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _bgSecondary.withOpacity(0.95),
                      _bgCard.withOpacity(0.9),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: _borderGlass,
                      width: 1,
                    ),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
                  child: Row(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_bgCard, _bgCardHover],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: _borderGlass, width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back_rounded, size: 24),
                          color: _textPrimary,
                          onPressed: () => Navigator.pop(context),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _buildAvatar("Global"),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Obrolan Global",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: _textPrimary,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "${chats.length} pesan • ${chats.map((c) => c['from']).toSet().length} peserta",
                              style: TextStyle(
                                fontSize: 12,
                                color: _textSecondary,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_bgCard, _bgCardHover],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: _borderGlass, width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.search_rounded, size: 22),
                          color: _textSecondary,
                          onPressed: () {},
                        ),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_bgCard, _bgCardHover],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: _borderGlass, width: 1),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.more_vert_rounded, size: 22),
                          color: _textSecondary,
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // --- Chat Messages Area ---
              Expanded(
                child: loading
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [_accentGradientStart, _accentGradientEnd],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: const Center(
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 3,
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Memuat percakapan...",
                              style: TextStyle(
                                color: _textSecondary,
                                fontSize: 14,
                                fontWeight: FontWeight.w300,
                              ),
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        key: refreshKey,
                        backgroundColor: _bgSecondary,
                        color: _accentPrimary,
                        onRefresh: _refreshChats,
                        child: ListView.builder(
                          controller: scrollCtrl,
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: chats.length + 1,
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return _buildDateSeparator("Hari Ini");
                            }
                            final item = chats[index - 1];
                            final isMe = item['from'] == widget.username;

                            if (index > 1) {
                              final prevItem = chats[index - 2];
                              final currentDate = _formatDate(item['time']);
                              final prevDate = _formatDate(prevItem['time']);

                              if (currentDate != prevDate) {
                                return Column(
                                  children: [
                                    _buildDateSeparator(currentDate),
                                    _buildMessageBubble(item, isMe),
                                  ],
                                );
                              }
                            }

                            return _buildMessageBubble(item, isMe);
                          },
                        ),
                      ),
              ),

              // --- Sending Indicator ---
              if (isSending)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_bgCard, _bgCardHover],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _borderGlass, width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation(_accentPrimary),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "Mengirim...",
                          style: TextStyle(
                            color: _textSecondary,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              // --- Modern Input Bar ---
              Container(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _bgSecondary.withOpacity(0.95),
                      _bgCard.withOpacity(0.9),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  border: Border(
                    top: BorderSide(
                      color: _borderGlass,
                      width: 1,
                    ),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_bgCard, _bgCardHover],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: _borderGlass, width: 1),
                      ),
                      child: IconButton(
                        icon: Icon(Icons.emoji_emotions_outlined, size: 22),
                        color: _textTertiary,
                        onPressed: () {},
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [_bgCard, _bgCardHover],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: _borderGlass, width: 1),
                      ),
                      child: IconButton(
                        icon: Icon(Icons.attach_file_rounded, size: 22),
                        color: _textTertiary,
                        onPressed: () {},
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [_bgPrimary, _bgSecondary],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: _borderGlass, width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: msgCtrl,
                          focusNode: focusNode,
                          style: TextStyle(
                            color: _textPrimary,
                            fontSize: 15,
                          ),
                          maxLines: null,
                          onChanged: (value) {
                            setState(() {
                              showSendButton = value.trim().isNotEmpty;
                            });
                          },
                          onSubmitted: (_) => _sendMessage(),
                          decoration: InputDecoration(
                            hintText: "Ketik pesan...",
                            hintStyle: TextStyle(
                              color: _textTertiary.withOpacity(0.7),
                              fontSize: 15,
                              fontWeight: FontWeight.w300,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 14,
                            ),
                            suffixIcon: showSendButton
                                ? Container(
                                    margin: const EdgeInsets.all(4),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        colors: [_accentGradientStart, _accentGradientEnd],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                    ),
                                    child: IconButton(
                                      icon: const Icon(
                                        Icons.send_rounded,
                                        color: Colors.white,
                                        size: 20,
                                      ),
                                      onPressed: _sendMessage,
                                    ),
                                  )
                                : null,
                          ),
                        ),
                      ),
                    ),
                    if (!showSendButton) ...[
                      const SizedBox(width: 10),
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_accentGradientStart, _accentGradientEnd],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _accentPrimary.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.mic_rounded, size: 22),
                          color: Colors.white,
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: showScrollButton
            ? FloatingActionButton(
                backgroundColor: _bgSecondary,
                foregroundColor: _accentPrimary,
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                onPressed: _scrollToBottom,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: _borderGlass, width: 1),
                  ),
                  child: const Icon(Icons.arrow_downward_rounded, size: 20),
                ),
              )
            : null,
      ),
    );
  }
}