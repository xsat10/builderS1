import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ============================================================
  // VIDEO
  // ============================================================

  late VideoPlayerController _videoController;

  // ============================================================
  // ANIMATION CONTROLLERS
  // ============================================================

  late AnimationController _fadeController;
  late AnimationController _bubbleController;
  late AnimationController _pulseController;
  late AnimationController _loadingController;

  // ============================================================
  // TIMERS
  // ============================================================

  Timer? _typingTimer;
  Timer? _messageTimer;

  // ============================================================
  // STATE
  // ============================================================

  double _progress = 0.0;

  int _messageIndex = 0;
  int _characterIndex = 0;

  bool _videoFinished = false;
  bool _introFinished = false;
  bool _fadeOutStarted = false;
  bool _isNavigating = false;

  bool _videoInitialized = false;

  String _currentMessage = '';

  // ============================================================
  // INTRO MESSAGES
  // ============================================================

  late final List<String> _messages = [
    'HOLLA SELAMAT DATANG ${widget.username} KE STUXX',
    'DISINI MENYEDIAKAN BERBAGAI FITUR UNTUK KAMU 😘',
    'SEMOGA BETAH DI APK STUX DAN SETIA DI APK STUX',
    'SEMOGA MENIKMATI ☺',
  ];

  // ============================================================
  // THEME
  // ============================================================

  static const Color _background = Color(0xFF030712);
  static const Color _navy = Color(0xFF07111F);

  static const Color _cyan = Color(0xFF00E5FF);
  static const Color _blue = Color(0xFF1677FF);
  static const Color _white = Color(0xFFF5F9FF);
  static const Color _silver = Color(0xFFB8C4D4);
  static const Color _muted = Color(0xFF718096);

  LinearGradient get _cyanGradient {
    return const LinearGradient(
      colors: [
        Color(0xFF00E5FF),
        Color(0xFF1677FF),
      ],
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    );
  }

  // ============================================================
  // INIT
  // ============================================================

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _bubbleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _loadingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    )..repeat();

    _initializeVideo();
    _startTyping();
  }

  // ============================================================
  // VIDEO INITIALIZATION
  // ============================================================

  Future<void> _initializeVideo() async {
    _videoController = VideoPlayerController.asset(
      'assets/videos/splash.mp4',
    );

    try {
      await _videoController.initialize();

      if (!mounted) return;

      _videoController.setLooping(false);

      _videoController.addListener(_videoListener);

      setState(() {
        _videoInitialized = true;
      });

      await _videoController.play();
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _videoInitialized = false;
      });

      // Tetap lanjutkan intro meskipun video gagal dimuat.
      _videoFinished = true;
      _checkNavigation();
    }
  }

  // ============================================================
  // VIDEO LISTENER
  // ============================================================

  void _videoListener() {
    if (!mounted || !_videoInitialized) return;

    final value = _videoController.value;

    if (!value.isInitialized) return;

    final duration = value.duration;
    final position = value.position;

    if (duration.inMilliseconds > 0) {
      final calculatedProgress =
          position.inMilliseconds / duration.inMilliseconds;

      final safeProgress = calculatedProgress.clamp(0.0, 1.0);

      if (mounted) {
        setState(() {
          _progress = safeProgress;
        });
      }

      if (position >= duration - const Duration(milliseconds: 900) &&
          !_fadeOutStarted) {
        _fadeOutStarted = true;

        if (mounted) {
          _fadeController.forward(from: 0);
        }
      }

      if (position >= duration && !_videoFinished) {
        _videoFinished = true;
        _progress = 1.0;

        _checkNavigation();
      }
    }
  }

  // ============================================================
  // TYPING SYSTEM
  // ============================================================

  void _startTyping() {
    if (_messages.isEmpty) {
      _introFinished = true;
      _checkNavigation();
      return;
    }

    _messageIndex = 0;
    _characterIndex = 0;
    _currentMessage = '';

    _nextMessage();
  }

  void _nextMessage() {
    _typingTimer?.cancel();
    _messageTimer?.cancel();

    if (!mounted) return;

    if (_messageIndex >= _messages.length) {
      _introFinished = true;
      _checkNavigation();
      return;
    }

    final message = _messages[_messageIndex];

    _characterIndex = 0;

    setState(() {
      _currentMessage = '';
    });

    _typingTimer = Timer.periodic(
      const Duration(milliseconds: 34),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (_characterIndex < message.length) {
          setState(() {
            _characterIndex++;
            _currentMessage = message.substring(
              0,
              _characterIndex,
            );
          });
        } else {
          timer.cancel();

          _messageTimer = Timer(
            const Duration(milliseconds: 1900),
            () {
              if (!mounted) return;

              _messageIndex++;

              if (_messageIndex >= _messages.length) {
                _introFinished = true;
                _checkNavigation();
              } else {
                _nextMessage();
              }
            },
          );
        }
      },
    );
  }

  // ============================================================
  // NAVIGATION CHECK
  // ============================================================

  void _checkNavigation() {
    if (!mounted) return;
    if (_isNavigating) return;

    if (_videoFinished && _introFinished) {
      _navigateToDashboard();
    }
  }

  // ============================================================
  // SKIP INTRO
  // ============================================================

  void _skipIntro() {
    if (_isNavigating) return;

    _typingTimer?.cancel();
    _messageTimer?.cancel();

    if (_videoInitialized && _videoController.value.isInitialized) {
      _videoController.pause();
    }

    _videoFinished = true;
    _introFinished = true;

    _navigateToDashboard();
  }

  // ============================================================
  // NAVIGATE DASHBOARD
  // ============================================================

  void _navigateToDashboard() {
    if (!mounted || _isNavigating) return;

    _isNavigating = true;

    _typingTimer?.cancel();
    _messageTimer?.cancel();

    if (_videoInitialized && _videoController.value.isInitialized) {
      _videoController.pause();
    }

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        reverseTransitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );

          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween<double>(
                begin: 0.985,
                end: 1.0,
              ).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _typingTimer?.cancel();
    _messageTimer?.cancel();

    if (_videoInitialized) {
      _videoController.removeListener(_videoListener);
      _videoController.dispose();
    }

    _fadeController.dispose();
    _bubbleController.dispose();
    _pulseController.dispose();
    _loadingController.dispose();

    super.dispose();
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);

    final bool compact = size.height < 700;
    final bool wide = size.width >= 600;

    return Scaffold(
      backgroundColor: _background,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ------------------------------------------------------
          // VIDEO
          // ------------------------------------------------------

          _buildVideoBackground(),

          // ------------------------------------------------------
          // DARK CINEMATIC OVERLAY
          // ------------------------------------------------------

          _buildDarkOverlay(),

          // ------------------------------------------------------
          // AMBIENT GLOW
          // ------------------------------------------------------

          _buildAmbientGlow(),

          // ------------------------------------------------------
          // FUTURISTIC BACKGROUND
          // ------------------------------------------------------

          CustomPaint(
            painter: _CyberBackgroundPainter(
              animation: _bubbleController.value,
            ),
          ),

          // ------------------------------------------------------
          // FLOATING PARTICLES
          // ------------------------------------------------------

          IgnorePointer(
            child: CustomPaint(
              painter: _ParticlePainter(
                animation: _bubbleController.value,
              ),
            ),
          ),

          // ------------------------------------------------------
          // SCANLINE
          // ------------------------------------------------------

          IgnorePointer(
            child: AnimatedBuilder(
              animation: _loadingController,
              builder: (_, __) {
                return CustomPaint(
                  painter: _ScanlinePainter(
                    progress: _loadingController.value,
                  ),
                );
              },
            ),
          ),

          // ------------------------------------------------------
          // MAIN CONTENT
          // ------------------------------------------------------

          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: wide ? 80 : 20,
                    vertical: compact ? 14 : 24,
                  ),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight -
                          (compact ? 28 : 48),
                    ),
                    child: Column(
                      children: [
                        _buildTopBar(),

                        SizedBox(
                          height: compact ? 18 : 30,
                        ),

                        _buildSystemHeader(),

                        SizedBox(
                          height: compact ? 20 : 30,
                        ),

                        _buildAIIcon(),

                        SizedBox(
                          height: compact ? 20 : 28,
                        ),

                        _buildMessageCard(),

                        SizedBox(
                          height: compact ? 20 : 28,
                        ),

                        _buildLoadingStatus(),

                        SizedBox(
                          height: compact ? 16 : 24,
                        ),

                        _buildProgressSection(),

                        SizedBox(
                          height: compact ? 22 : 32,
                        ),

                        _buildBottomInfo(),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // ------------------------------------------------------
          // FADE OVERLAY
          // ------------------------------------------------------

          if (_fadeOutStarted)
            IgnorePointer(
              child: FadeTransition(
                opacity: Tween<double>(
                  begin: 0.0,
                  end: 0.92,
                ).animate(
                  CurvedAnimation(
                    parent: _fadeController,
                    curve: Curves.easeIn,
                  ),
                ),
                child: Container(
                  color: _background,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // VIDEO BACKGROUND
  // ============================================================

  Widget _buildVideoBackground() {
    if (!_videoInitialized ||
        !_videoController.value.isInitialized) {
      return Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.2,
            colors: [
              Color(0xFF0A2035),
              Color(0xFF030712),
            ],
          ),
        ),
        child: Center(
          child: _buildVideoFallback(),
        ),
      );
    }

    final videoSize = _videoController.value.size;

    return Positioned.fill(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: videoSize.width,
          height: videoSize.height,
          child: VideoPlayer(_videoController),
        ),
      ),
    );
  }

  Widget _buildVideoFallback() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        final scale =
            0.9 + (_pulseController.value * 0.1);

        return Transform.scale(
          scale: scale,
          child: Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _cyan.withOpacity(0.35),
              ),
              boxShadow: [
                BoxShadow(
                  color: _cyan.withOpacity(0.16),
                  blurRadius: 30,
                ),
              ],
            ),
            child: const Icon(
              Icons.security_rounded,
              color: _cyan,
              size: 34,
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // DARK OVERLAY
  // ============================================================

  Widget _buildDarkOverlay() {
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withOpacity(0.76),
              _background.withOpacity(0.58),
              _background.withOpacity(0.90),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // AMBIENT GLOW
  // ============================================================

  Widget _buildAmbientGlow() {
    return IgnorePointer(
      child: Stack(
        children: [
          Positioned(
            top: -150,
            left: -100,
            child: _glowOrb(
              size: 340,
              color: _cyan,
            ),
          ),
          Positioned(
            bottom: -180,
            right: -100,
            child: _glowOrb(
              size: 360,
              color: _blue,
            ),
          ),
        ],
      ),
    );
  }

  Widget _glowOrb({
    required double size,
    required Color color,
  }) {
    return ImageFiltered(
      imageFilter: ImageFilter.blur(
        sigmaX: 55,
        sigmaY: 55,
      ),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(0.07),
        ),
      ),
    );
  }

  // ============================================================
  // TOP BAR
  // ============================================================

  Widget _buildTopBar() {
    return Row(
      children: [
        Expanded(
          child: _glassContainer(
            radius: 18,
            padding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 10,
            ),
            child: Row(
              children: [
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (_, __) {
                    return Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _cyan,
                        boxShadow: [
                          BoxShadow(
                            color: _cyan.withOpacity(
                              0.35 +
                                  (_pulseController.value * 0.35),
                            ),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    'STUX AI SYSTEM',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _white,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        _buildSkipButton(),
      ],
    );
  }

  Widget _buildSkipButton() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: _isNavigating ? null : _skipIntro,
        child: _glassContainer(
          radius: 18,
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 10,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Icon(
                Icons.double_arrow_rounded,
                color: _cyan,
                size: 15,
              ),
              SizedBox(width: 7),
              Text(
                'Lewati',
                style: TextStyle(
                  color: _white,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.7,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SYSTEM HEADER
  // ============================================================

  Widget _buildSystemHeader() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) {
            return _cyanGradient.createShader(bounds);
          },
          child: const Text(
            'STUX01',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 31,
              fontWeight: FontWeight.w900,
              letterSpacing: 6,
              height: 1,
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'CRASHER',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _silver,
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 5,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 24,
              height: 1,
              decoration: BoxDecoration(
                gradient: _cyanGradient,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'SECURE MEMBER ACCESS',
              style: TextStyle(
                color: _muted,
                fontSize: 9,
                fontWeight: FontWeight.w600,
                letterSpacing: 2.2,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 24,
              height: 1,
              decoration: BoxDecoration(
                gradient: _cyanGradient,
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ============================================================
  // AI ICON
  // ============================================================

  Widget _buildAIIcon() {
    return AnimatedBuilder(
      animation: Listenable.merge([
        _pulseController,
        _bubbleController,
      ]),
      builder: (_, __) {
        final pulse = _pulseController.value;

        final scale = 0.97 + (pulse * 0.035);

        return Transform.scale(
          scale: scale,
          child: SizedBox(
            width: 150,
            height: 150,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer glow
                Container(
                  width: 138 + (pulse * 8),
                  height: 138 + (pulse * 8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _cyan.withOpacity(
                        0.08 + (pulse * 0.08),
                      ),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _cyan.withOpacity(0.12),
                        blurRadius: 30,
                        spreadRadius: 4,
                      ),
                    ],
                  ),
                ),

                // Rotating HUD ring
                Transform.rotate(
                  angle: _bubbleController.value * math.pi * 2,
                  child: CustomPaint(
                    size: const Size(126, 126),
                    painter: _HudRingPainter(
                      color: _cyan,
                    ),
                  ),
                ),

                // Inner glass
                Container(
                  width: 92,
                  height: 92,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.white.withOpacity(0.12),
                        _navy.withOpacity(0.82),
                      ],
                    ),
                    border: Border.all(
                      color: _cyan.withOpacity(0.38),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _cyan.withOpacity(0.20),
                        blurRadius: 25,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.shield_rounded,
                    color: _white,
                    size: 43,
                  ),
                ),

                // Status dot
                Positioned(
                  right: 16,
                  bottom: 22,
                  child: Container(
                    width: 15,
                    height: 15,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _cyan,
                      border: Border.all(
                        color: _background,
                        width: 3,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _cyan.withOpacity(0.8),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                  ),
                ),

                // Orbit point
                Positioned(
                  top: 12,
                  left: 27,
                  child: Container(
                    width: 5,
                    height: 5,
                    decoration: BoxDecoration(
                      color: _white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _cyan.withOpacity(0.8),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // MESSAGE CARD
  // ============================================================

  Widget _buildMessageCard() {
    return _glassContainer(
      radius: 26,
      padding: const EdgeInsets.fromLTRB(
        20,
        19,
        20,
        19,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 29,
                height: 29,
                decoration: BoxDecoration(
                  color: _cyan.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(
                    color: _cyan.withOpacity(0.18),
                  ),
                ),
                child: const Icon(
                  Icons.smart_toy_outlined,
                  color: _cyan,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'STUX AI',
                  style: TextStyle(
                    color: _white,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.8,
                  ),
                ),
              ),
              _buildLiveBadge(),
            ],
          ),
          const SizedBox(height: 17),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.18),
              borderRadius: BorderRadius.circular(17),
              border: Border.all(
                color: Colors.white.withOpacity(0.055),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 3),
                  width: 2,
                  height: 39,
                  decoration: BoxDecoration(
                    gradient: _cyanGradient,
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: [
                      BoxShadow(
                        color: _cyan.withOpacity(0.5),
                        blurRadius: 7,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 260),
                    transitionBuilder: (child, animation) {
                      return FadeTransition(
                        opacity: animation,
                        child: SlideTransition(
                          position: Tween<Offset>(
                            begin: const Offset(0, 0.08),
                            end: Offset.zero,
                          ).animate(animation),
                          child: child,
                        ),
                      );
                    },
                    child: Text(
                      _currentMessage.isEmpty
                          ? 'INITIALIZING SECURE CHANNEL...'
                          : _currentMessage,
                      key: ValueKey(
                        '${_messageIndex}_$_currentMessage',
                      ),
                      style: const TextStyle(
                        color: _white,
                        fontSize: 13,
                        height: 1.65,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.25,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                _buildTypingCursor(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLiveBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: _cyan.withOpacity(0.07),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _cyan.withOpacity(0.20),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: const BoxDecoration(
              color: _cyan,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 5),
          const Text(
            'LIVE',
            style: TextStyle(
              color: _cyan,
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypingCursor() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        final opacity =
            0.35 + (_pulseController.value * 0.65);

        return Opacity(
          opacity: opacity,
          child: Container(
            width: 2,
            height: 17,
            margin: const EdgeInsets.only(
              top: 3,
            ),
            color: _cyan,
          ),
        );
      },
    );
  }

  // ============================================================
  // LOADING STATUS
  // ============================================================

  Widget _buildLoadingStatus() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: _loadingController,
          builder: (_, __) {
            return Transform.rotate(
              angle: _loadingController.value * math.pi * 2,
              child: const Icon(
                Icons.settings_outlined,
                color: _cyan,
                size: 16,
              ),
            );
          },
        ),
        const SizedBox(width: 9),
        const Flexible(
          child: Text(
            'AI sedang menyiapkan sistem',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _silver,
              fontSize: 10,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.1,
            ),
          ),
        ),
        const SizedBox(width: 8),
        _buildLoadingDots(),
      ],
    );
  }

  Widget _buildLoadingDots() {
    return AnimatedBuilder(
      animation: _loadingController,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(
            3,
            (index) {
              final value =
                  (_loadingController.value * 3 - index)
                      .clamp(0.0, 1.0);

              return Container(
                margin: const EdgeInsets.only(
                  right: 3,
                ),
                width: 4 + (value * 2),
                height: 4 + (value * 2),
                decoration: BoxDecoration(
                  color: _cyan.withOpacity(
                    0.35 + (value * 0.65),
                  ),
                  shape: BoxShape.circle,
                ),
              );
            },
          ),
        );
      },
    );
  }

  // ============================================================
  // PROGRESS
  // ============================================================

  Widget _buildProgressSection() {
    final percent = (_progress * 100).toInt();

    return Column(
      children: [
        Row(
          children: [
            const Text(
              'SYSTEM INITIALIZATION',
              style: TextStyle(
                color: _muted,
                fontSize: 8,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
            const Spacer(),
            Text(
              '$percent%',
              style: const TextStyle(
                color: _cyan,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 5,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.055),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: Colors.white.withOpacity(0.06),
            ),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: _progress.clamp(0.0, 1.0),
            child: Container(
              decoration: BoxDecoration(
                gradient: _cyanGradient,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: _cyan.withOpacity(0.45),
                    blurRadius: 9,
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 9),
        Row(
          children: [
            const Icon(
              Icons.lock_outline_rounded,
              color: _muted,
              size: 11,
            ),
            const SizedBox(width: 5),
            const Expanded(
              child: Text(
                'ENCRYPTED MEMBER CONNECTION',
                style: TextStyle(
                  color: _muted,
                  fontSize: 8,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.1,
                ),
              ),
            ),
            Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _cyan,
                boxShadow: [
                  BoxShadow(
                    color: _cyan,
                    blurRadius: 5,
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ============================================================
  // BOTTOM INFO
  // ============================================================

  Widget _buildBottomInfo() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 32,
              height: 1,
              color: _cyan.withOpacity(0.30),
            ),
            const SizedBox(width: 10),
            const Text(
              'STUX01 CRASHER',
              style: TextStyle(
                color: _white,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 32,
              height: 1,
              color: _cyan.withOpacity(0.30),
            ),
          ],
        ),
        const SizedBox(height: 7),
        const Text(
          'LOADING SCREEN BY STUX01',
          style: TextStyle(
            color: _muted,
            fontSize: 7,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.7,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // GLASS CONTAINER
  // ============================================================

  Widget _glassContainer({
    required Widget child,
    double radius = 22,
    EdgeInsetsGeometry padding = EdgeInsets.zero,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: 15,
          sigmaY: 15,
        ),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(0.075),
                Colors.white.withOpacity(0.025),
              ],
            ),
            border: Border.all(
              color: Colors.white.withOpacity(0.105),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.22),
                blurRadius: 30,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

// ==================================================================
// CYBER BACKGROUND PAINTER
// ==================================================================

class _CyberBackgroundPainter extends CustomPainter {
  final double animation;

  const _CyberBackgroundPainter({
    required this.animation,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = Colors.white.withOpacity(0.018)
      ..strokeWidth = 0.6;

    const grid = 34.0;

    for (double x = 0; x <= size.width; x += grid) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        gridPaint,
      );
    }

    for (double y = 0; y <= size.height; y += grid) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    final accentPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.035)
      ..strokeWidth = 1;

    for (double x = 0; x <= size.width; x += grid * 5) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        accentPaint,
      );
    }

    for (double y = 0; y <= size.height; y += grid * 5) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        accentPaint,
      );
    }

    // Moving HUD line.
    final lineY =
        (size.height * animation) % size.height;

    final scanPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.035)
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(0, lineY),
      Offset(size.width, lineY),
      scanPaint,
    );

    // Corner brackets.
    final bracketPaint = Paint()
      ..color = const Color(0xFF00E5FF).withOpacity(0.10)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    const length = 24.0;
    const margin = 18.0;

    // Top-left
    canvas.drawLine(
      const Offset(margin, margin + length),
      const Offset(margin, margin),
      bracketPaint,
    );
    canvas.drawLine(
      const Offset(margin, margin),
      const Offset(margin + length, margin),
      bracketPaint,
    );

    // Top-right
    canvas.drawLine(
      Offset(size.width - margin - length, margin),
      Offset(size.width - margin, margin),
      bracketPaint,
    );
    canvas.drawLine(
      Offset(size.width - margin, margin),
      Offset(size.width - margin, margin + length),
      bracketPaint,
    );

    // Bottom-left
    canvas.drawLine(
      Offset(margin, size.height - margin - length),
      Offset(margin, size.height - margin),
      bracketPaint,
    );
    canvas.drawLine(
      Offset(margin, size.height - margin),
      Offset(margin + length, size.height - margin),
      bracketPaint,
    );

    // Bottom-right
    canvas.drawLine(
      Offset(size.width - margin - length, size.height - margin),
      Offset(size.width - margin, size.height - margin),
      bracketPaint,
    );
    canvas.drawLine(
      Offset(size.width - margin, size.height - margin - length),
      Offset(size.width - margin, size.height - margin),
      bracketPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _CyberBackgroundPainter oldDelegate) {
    return oldDelegate.animation != animation;
  }
}

// ==================================================================
// PARTICLE PAINTER
// ==================================================================

class _ParticlePainter extends CustomPainter {
  final double animation;

  const _ParticlePainter({
    required this.animation,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill;

    const cyan = Color(0xFF00E5FF);

    for (int i = 0; i < 22; i++) {
      final seed = i * 47.0;

      final baseX =
          (seed * 1.73) % size.width;

      final baseY =
          (seed * 2.41) % size.height;

      final movement =
          math.sin(
            animation * math.pi * 2 + i,
          ) *
          15;

      final x = baseX + movement;

      final y =
          (baseY -
                  animation * (15 + (i % 4) * 7)) %
              size.height;

      final radius =
          0.7 + ((i % 3) * 0.45);

      paint.color = cyan.withOpacity(
        0.035 + ((i % 4) * 0.012),
      );

      canvas.drawCircle(
        Offset(x, y),
        radius,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) {
    return oldDelegate.animation != animation;
  }
}

// ==================================================================
// SCANLINE PAINTER
// ==================================================================

class _ScanlinePainter extends CustomPainter {
  final double progress;

  const _ScanlinePainter({
    required this.progress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final y = size.height * progress;

    final paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Colors.transparent,
          Color(0x1200E5FF),
          Colors.transparent,
        ],
      ).createShader(
        Rect.fromLTWH(
          0,
          y - 20,
          size.width,
          40,
        ),
      );

    canvas.drawRect(
      Rect.fromLTWH(
        0,
        y - 20,
        size.width,
        40,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _ScanlinePainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}

// ==================================================================
// HUD RING PAINTER
// ==================================================================

class _HudRingPainter extends CustomPainter {
  final Color color;

  const _HudRingPainter({
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    final radius = size.width / 2 - 4;

    final paint = Paint()
      ..color = color.withOpacity(0.38)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    canvas.drawArc(
      Rect.fromCircle(
        center: center,
        radius: radius,
      ),
      -math.pi * 0.20,
      math.pi * 0.95,
      false,
      paint,
    );

    canvas.drawArc(
      Rect.fromCircle(
        center: center,
        radius: radius - 7,
      ),
      math.pi * 0.82,
      math.pi * 0.72,
      false,
      paint,
    );

    final smallPaint = Paint()
      ..color = color.withOpacity(0.55)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 8; i++) {
      final angle =
          (math.pi * 2 / 8) * i;

      final x =
          center.dx +
              math.cos(angle) *
                  (radius + 1);

      final y =
          center.dy +
              math.sin(angle) *
                  (radius + 1);

      canvas.drawCircle(
        Offset(x, y),
        1.7,
        smallPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _HudRingPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}