import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;

  late AnimationController _fadeController;
  late AnimationController _bubbleController;
  late AnimationController _pulseController;
  late AnimationController _loadingController;

  Timer? _typingTimer;
  Timer? _messageTimer;

  bool _fadeOutStarted = false;
  bool _videoFinished = false;
  bool _introFinished = false;
  bool _isNavigating = false;

  double _progress = 0.0;

  int _messageIndex = 0;
  int _characterIndex = 0;

  final List<String> _messages = [];

  String get _currentMessage {
    if (_messages.isEmpty) return '';

    final message = _messages[_messageIndex];

    if (_characterIndex > message.length) {
      return message;
    }

    return message.substring(0, _characterIndex);
  }

  @override
  void initState() {
    super.initState();

    _messages.addAll([
      'HOLLA SELAMAT DATANG ${widget.username} KE STUXX',
      'DISINI MENYEDIAKAN BERBAGAI FITUR UNTUK KAMU 😘',
      'SEMOGA BETAH DI APK STUX DAN SETIA DI APK STUX',
      'SEMOGA MENIKMATI ☺',
    ]);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _bubbleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _loadingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat();

    _initializeVideo();
    _startTyping();
  }

  Future<void> _initializeVideo() async {
    _videoController = VideoPlayerController.asset(
      'assets/videos/splash.mp4',
    );

    try {
      await _videoController.initialize();

      if (!mounted) return;

      setState(() {});

      await _videoController.setLooping(false);
      await _videoController.play();

      _videoController.addListener(_videoListener);
    } catch (e) {
      // Jika video gagal di-load, intro tetap dapat berjalan.
      if (!mounted) return;

      setState(() {
        _videoFinished = true;
      });

      _checkNavigation();
    }
  }

  void _videoListener() {
    if (!mounted) return;

    final value = _videoController.value;

    if (!value.isInitialized) return;

    final position = value.position;
    final duration = value.duration;

    if (duration.inMilliseconds <= 0) return;

    final progress =
        position.inMilliseconds / duration.inMilliseconds;

    setState(() {
      _progress = progress.clamp(0.0, 1.0);
    });

    // Mulai fade ketika video hampir selesai.
    if (position >= duration - const Duration(milliseconds: 900) &&
        !_fadeOutStarted) {
      _fadeOutStarted = true;

      if (mounted) {
        _fadeController.forward();
      }
    }

    if (position >= duration && !_videoFinished) {
      _videoFinished = true;
      _checkNavigation();
    }
  }

  // ============================================================
  // TYPING INTRO
  // ============================================================

  void _startTyping() {
    _characterIndex = 0;

    _typingTimer?.cancel();

    _typingTimer = Timer.periodic(
      const Duration(milliseconds: 42),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        final currentText = _messages[_messageIndex];

        if (_characterIndex < currentText.length) {
          setState(() {
            _characterIndex++;
          });
        } else {
          timer.cancel();

          // Beri waktu agar user membaca pesan.
          _messageTimer?.cancel();

          _messageTimer = Timer(
            const Duration(milliseconds: 1800),
            _nextMessage,
          );
        }
      },
    );
  }

  void _nextMessage() {
    if (!mounted) return;

    if (_messageIndex < _messages.length - 1) {
      setState(() {
        _messageIndex++;
        _characterIndex = 0;
      });

      _startTyping();
    } else {
      setState(() {
        _introFinished = true;
      });

      _checkNavigation();
    }
  }

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _checkNavigation() {
    if (!mounted) return;

    if (_videoFinished && _introFinished) {
      _navigateToDashboard();
    }
  }

  void _skipIntro() {
    if (_isNavigating) return;

    try {
      _videoController.removeListener(_videoListener);
      _videoController.pause();
    } catch (_) {}

    _navigateToDashboard();
  }

  void _navigateToDashboard() {
    if (!mounted || _isNavigating) return;

    _isNavigating = true;

    _typingTimer?.cancel();
    _messageTimer?.cancel();

    try {
      _videoController.removeListener(_videoListener);
      _videoController.pause();
    } catch (_) {}

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _messageTimer?.cancel();

    try {
      _videoController.removeListener(_videoListener);
      _videoController.dispose();
    } catch (_) {}

    _fadeController.dispose();
    _bubbleController.dispose();
    _pulseController.dispose();
    _loadingController.dispose();

    super.dispose();
  }

  // ============================================================
  // BACKGROUND BUBBLES
  // ============================================================

  Widget _buildBubble({
    required double size,
    required double left,
    required double top,
    required double delay,
  }) {
    return AnimatedBuilder(
      animation: _bubbleController,
      builder: (context, child) {
        final value =
            (_bubbleController.value + delay) % 1.0;

        final movement = (value * 2 - 1) * 35;

        return Positioned(
          left: left,
          top: top + movement,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.blueAccent.withOpacity(0.08),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.blueAccent.withOpacity(0.08),
                  blurRadius: 35,
                  spreadRadius: 5,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // AI ICON
  // ============================================================

  Widget _buildAIIcon() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final scale = 0.94 + (_pulseController.value * 0.08);

        return Transform.scale(
          scale: scale,
          child: Container(
            width: 76,
            height: 76,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF111827),
                  Color(0xFF020617),
                ],
              ),
              border: Border.all(
                color: Colors.blueAccent.withOpacity(0.55),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.blueAccent.withOpacity(0.25),
                  blurRadius: 28,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: const Icon(
              Icons.smart_toy_rounded,
              color: Colors.white,
              size: 34,
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // LOADING DOTS
  // ============================================================

  Widget _buildLoadingDots() {
    return AnimatedBuilder(
      animation: _loadingController,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(
            3,
            (index) {
              final animationValue =
                  (_loadingController.value + index * 0.18) % 1.0;

              final opacity =
                  0.25 + (animationValue < 0.5
                      ? animationValue * 1.5
                      : (1 - animationValue) * 1.5);

              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 3),
                child: Opacity(
                  opacity: opacity.clamp(0.25, 1.0),
                  child: Container(
                    width: 5,
                    height: 5,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  // ============================================================
  // MAIN UI
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [

          // ======================================================
          // FULLSCREEN VIDEO BACKGROUND
          // ======================================================

          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(
                  sigmaX: 9,
                  sigmaY: 9,
                ),
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              ),
            )
          else
            const SizedBox.expand(
              child: ColoredBox(
                color: Colors.black,
              ),
            ),

          // ======================================================
          // DARK OVERLAY
          // ======================================================

          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.70),
                    Colors.black.withOpacity(0.38),
                    Colors.black.withOpacity(0.82),
                  ],
                ),
              ),
            ),
          ),

          // ======================================================
          // SOFT GLASS OVERLAY
          // ======================================================

          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(
                sigmaX: 2,
                sigmaY: 2,
              ),
              child: Container(
                color: Colors.transparent,
              ),
            ),
          ),

          // ======================================================
          // BUBBLES
          // ======================================================

          _buildBubble(
            size: 150,
            left: -40,
            top: size.height * 0.18,
            delay: 0.1,
          ),

          _buildBubble(
            size: 90,
            left: size.width * 0.78,
            top: size.height * 0.28,
            delay: 0.35,
          ),

          _buildBubble(
            size: 210,
            left: size.width * 0.65,
            top: size.height * 0.68,
            delay: 0.55,
          ),

          _buildBubble(
            size: 75,
            left: size.width * 0.08,
            top: size.height * 0.72,
            delay: 0.75,
          ),

          // ======================================================
          // TOP BAR
          // ======================================================

          Positioned(
            top: MediaQuery.of(context).padding.top + 18,
            left: 20,
            right: 20,
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.28),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.12),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.greenAccent,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.greenAccent,
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'STUX AI SYSTEM',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // SKIP BUTTON
                GestureDetector(
                  onTap: _skipIntro,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 9,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.32),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.18),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.fast_forward_rounded,
                          color: Colors.white.withOpacity(0.9),
                          size: 15,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'Lewati',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ======================================================
          // CENTER AI INTRO
          // ======================================================

          Positioned(
            left: 24,
            right: 24,
            top: size.height * 0.22,
            bottom: size.height * 0.23,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                _buildAIIcon(),

                const SizedBox(height: 25),

                const Text(
                  'INITIALIZING',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 4,
                  ),
                ),

                const SizedBox(height: 18),

                // GLASS MESSAGE CARD
                ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 18,
                      sigmaY: 18,
                    ),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 22,
                        vertical: 25,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.28),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.13),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.28),
                            blurRadius: 30,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        children: [

                          SizedBox(
                            height: 74,
                            child: Center(
                              child: AnimatedSwitcher(
                                duration: const Duration(
                                  milliseconds: 250,
                                ),
                                child: Text(
                                  _currentMessage,
                                  key: ValueKey(
                                    '$_messageIndex-$_characterIndex',
                                  ),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    height: 1.55,
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 14),

                          // Typing cursor
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 5,
                                height: 5,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.blueAccent,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.blueAccent,
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 7),
                              const Text(
                                'STUX AI',
                                style: TextStyle(
                                  color: Colors.white38,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 22),

                // ==================================================
                // LOADING STATUS
                // ==================================================

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RotationTransition(
                      turns: _loadingController,
                      child: const Icon(
                        Icons.sync_rounded,
                        color: Colors.white70,
                        size: 17,
                      ),
                    ),
                    const SizedBox(width: 9),
                    const Text(
                      'AI sedang menyiapkan sistem',
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                        letterSpacing: 0.7,
                      ),
                    ),
                    const SizedBox(width: 5),
                    _buildLoadingDots(),
                  ],
                ),
              ],
            ),
          ),

          // ======================================================
          // BOTTOM AREA
          // ======================================================

          Positioned(
            left: 30,
            right: 30,
            bottom: MediaQuery.of(context).padding.bottom + 35,
            child: Column(
              children: [

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'STUX01 CRASHER',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2.4,
                      ),
                    ),

                    Text(
                      '${(_progress * 100).toInt()}%',
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 11),

                // PROGRESS BAR
                Container(
                  height: 5,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.09),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.06),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: _progress,
                      child: Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF4B5563),
                              Color(0xFFE5E7EB),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                const Text(
                  'LOADING SCREEN BY STUX01',
                  style: TextStyle(
                    color: Colors.white38,
                    fontSize: 8,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),

          // ======================================================
          // FADE OUT
          // ======================================================

          if (_fadeOutStarted)
            IgnorePointer(
              child: FadeTransition(
                opacity: _fadeController,
                child: Container(
                  color: Colors.black,
                ),
              ),
            ),
        ],
      ),
    );
  }
}