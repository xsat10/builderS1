import 'dart:async';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'splash_dashboard.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController? _videoController;
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late Animation<double> _textOpacityAnimation;
  late Animation<double> _scaleAnimation;
  bool _videoReady = false;
  bool _videoError = false;
  bool _skipPressed = false;

  Timer? _timeoutTimer;
  Timer? _checkTimer;

  // Warna premium dark dengan aksen neon futuristik
  final Color _primaryColor = const Color(0xFF080C1A);
  final Color _secondaryColor = const Color(0xFF0F1A2E);
  final Color _textColor = const Color(0xFFE8EDFF);
  final Color _accentColor = const Color(0xFF00E5FF);
  final Color _accentSecondary = const Color(0xFF7C4DFF);
  final Color _accentGlow = const Color(0xFF00B8D4);

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);

    _textOpacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOutCubic,
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.85,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOutBack,
    ));

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _fadeController.forward();
    });

    _timeoutTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && !_videoReady && !_skipPressed) {
        _handleVideoTimeout();
      }
    });

    _initializeVideo();
  }

  void _initializeVideo() async {
    try {
      _videoController = VideoPlayerController.asset(
        "assets/videos/otaxai.mp4",
      );

      final initTimeout = Timer(const Duration(seconds: 3), () {
        if (mounted &&
            _videoController != null &&
            !_videoController!.value.isInitialized) {
          _handleVideoError();
        }
      });

      await _videoController!.initialize();
      initTimeout.cancel();

      if (!mounted) return;

      setState(() {
        _videoReady = true;
      });

      _videoController!.setLooping(false);
      _videoController!.setVolume(0.8);

      _startVideoCheckTimer();

      await _videoController!.play().catchError((e) {
        _handleVideoError();
      });

      _videoController!.addListener(() {
        if (!mounted) return;

        if (_videoController!.value.position >=
            _videoController!.value.duration) {
          if (_videoController!.value.duration > Duration.zero) {
            _navigateToSplashDashboard();
          }
        }
      });
    } catch (e) {
      _handleVideoError();
    }
  }

  void _startVideoCheckTimer() {
    _checkTimer = Timer.periodic(
      const Duration(milliseconds: 500),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (_videoController == null ||
            !_videoController!.value.isInitialized) {
          return;
        }

        final currentPosition = _videoController!.value.position;
        final isPlaying = _videoController!.value.isPlaying;

        if (isPlaying && currentPosition.inMilliseconds > 0) {
          if (_lastPosition == currentPosition) {
            _stuckFrames++;
            if (_stuckFrames > 2) {
              timer.cancel();
              _handleVideoError();
            }
          } else {
            _lastPosition = currentPosition;
            _stuckFrames = 0;
          }
        }
      },
    );
  }

  Duration _lastPosition = Duration.zero;
  int _stuckFrames = 0;

  void _handleVideoError() {
    if (!mounted || _skipPressed) return;

    setState(() {
      _videoError = true;
    });

    _timeoutTimer?.cancel();
    _checkTimer?.cancel();

    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted && !_skipPressed) {
        _navigateToSplashDashboard();
      }
    });
  }

  void _handleVideoTimeout() {
    if (!mounted || _skipPressed) return;

    _timeoutTimer?.cancel();
    _checkTimer?.cancel();

    _navigateToSplashDashboard();
  }

  void _navigateToSplashDashboard() {
    if (_skipPressed) return;

    _skipPressed = true;

    _timeoutTimer?.cancel();
    _checkTimer?.cancel();

    if (_videoController != null && _videoController!.value.isInitialized) {
      _videoController!.pause();
      _videoController!.dispose();
    }

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => SplashDashboardPage(
          data: {
            'username': widget.username,
            'password': widget.password,
            'role': widget.role,
            'key': widget.sessionKey,
            'expiredDate': widget.expiredDate,
            'listBug': widget.listBug,
            'listDoos': widget.listDoos,
            'news': widget.news,
          },
        ),
        transitionDuration: const Duration(milliseconds: 700),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.95, end: 1.0).animate(animation),
              child: child,
            ),
          );
        },
      ),
    );
  }

  void _skipVideo() {
    if (_skipPressed) return;

    _fadeController.reverse().then((_) {
      _navigateToSplashDashboard();
    });
  }

  @override
  void dispose() {
    _timeoutTimer?.cancel();
    _checkTimer?.cancel();
    _fadeController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _primaryColor,
      body: GestureDetector(
        onTap: _skipVideo,
        child: Stack(
          children: [
            // ── VIDEO / FALLBACK BACKGROUND ──────────────────────────────
            if (_videoReady && !_videoError && _videoController != null)
              Positioned.fill(
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController!.value.size.width,
                    height: _videoController!.value.size.height,
                    child: VideoPlayer(_videoController!),
                  ),
                ),
              )
            else
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, child) {
                    return Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: Alignment.center,
                          radius: 1.5,
                          colors: [
                            _secondaryColor.withOpacity(
                              0.6 + 0.2 * _glowController.value,
                            ),
                            _primaryColor,
                            const Color(0xFF050812),
                          ],
                        ),
                      ),
                      child: Center(
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            return Container(
                              width: 180 + 20 * _pulseController.value,
                              height: 180 + 20 * _pulseController.value,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _accentColor.withOpacity(
                                    0.15 + 0.1 * _pulseController.value,
                                  ),
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _accentColor.withOpacity(
                                      0.05 + 0.05 * _pulseController.value,
                                    ),
                                    blurRadius: 60 + 20 * _pulseController.value,
                                    spreadRadius: 10,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),

            // ── DARK OVERLAY ──────────────────────────────────────────────
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.2),
                      Colors.transparent,
                      Colors.transparent,
                      Colors.black.withOpacity(0.6),
                    ],
                    stops: const [0.0, 0.2, 0.6, 1.0],
                  ),
                ),
              ),
            ),

            // ── GLOW ORBS ──────────────────────────────────────────────────
            AnimatedBuilder(
              animation: _glowController,
              builder: (context, child) {
                return Positioned(
                  top: 60 - 30 * _glowController.value,
                  left: -40 + 40 * _glowController.value,
                  child: Container(
                    width: 250,
                    height: 250,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          _accentSecondary.withOpacity(
                            0.08 - 0.03 * _glowController.value,
                          ),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            AnimatedBuilder(
              animation: _glowController,
              builder: (context, child) {
                return Positioned(
                  bottom: 80 - 40 * _glowController.value,
                  right: -30 + 30 * _glowController.value,
                  child: Container(
                    width: 200,
                    height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          _accentColor.withOpacity(
                            0.06 - 0.02 * _glowController.value,
                          ),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),

            // ── CENTER LOGO ───────────────────────────────────────────────
            Positioned.fill(
              child: Center(
                child: FadeTransition(
                  opacity: _textOpacityAnimation,
                  child: ScaleTransition(
                    scale: _scaleAnimation,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Garis atas dengan efek glow
                        Container(
                          width: 1.5,
                          height: 60,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                _accentColor.withOpacity(0.8),
                              ],
                            ),
                          ),
                          margin: const EdgeInsets.only(bottom: 32),
                        ),

                        // ── NAMA APLIKASI — DI TENGAH ──
                        Transform.translate(
                          offset: const Offset(8, 0),
                          child: ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: [
                                _textColor,
                                _accentColor,
                                _accentSecondary,
                                _textColor,
                              ],
                              stops: const [0.0, 0.3, 0.7, 1.0],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ).createShader(bounds),
                            child: const Text(
                              "VOR4X",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 58,
                                fontWeight: FontWeight.w300,
                                color: Colors.white,
                                letterSpacing: 16,
                                height: 1.1,
                                fontFamily: 'Orbitron',
                                shadows: [
                                  Shadow(
                                    color: Color(0x8000E5FF),
                                    blurRadius: 30,
                                    offset: Offset(0, 0),
                                  ),
                                  Shadow(
                                    color: Color(0x4D7C4DFF),
                                    blurRadius: 50,
                                    offset: Offset(0, 0),
                                  ),
                                  Shadow(
                                    color: Color(0xCC000000),
                                    blurRadius: 15,
                                    offset: Offset(0, 4),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        // ── TAGLINE ──
                        AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final glow = 0.75 + 0.25 * _pulseController.value;
                            return Container(
                              margin: const EdgeInsets.only(top: 20),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 22,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.transparent,
                                    _accentColor.withOpacity(
                                      0.05 + 0.05 * _pulseController.value,
                                    ),
                                    Colors.transparent,
                                  ],
                                ),
                                border: Border(
                                  top: BorderSide(
                                    color: _accentColor.withOpacity(0.15),
                                    width: 0.6,
                                  ),
                                  bottom: BorderSide(
                                    color: _accentColor.withOpacity(0.15),
                                    width: 0.6,
                                  ),
                                ),
                              ),
                              child: ShaderMask(
                                shaderCallback: (bounds) => LinearGradient(
                                  colors: [
                                    Colors.white,
                                    _accentColor,
                                    Colors.white,
                                  ],
                                  stops: const [0.0, 0.5, 1.0],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ).createShader(bounds),
                                child: Text(
                                  'hanya untuk bersenang-senang',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                    letterSpacing: 2.5,
                                    fontStyle: FontStyle.italic,
                                    fontFamily: 'Pirata One',
                                    height: 1.2,
                                    shadows: [
                                      Shadow(
                                        color: _accentColor
                                            .withOpacity(0.9 * glow),
                                        blurRadius: 14,
                                        offset: const Offset(0, 0),
                                      ),
                                      Shadow(
                                        color: Colors.white
                                            .withOpacity(0.5 * glow),
                                        blurRadius: 6,
                                        offset: const Offset(0, 0),
                                      ),
                                      Shadow(
                                        color: Colors.black.withOpacity(0.9),
                                        blurRadius: 6,
                                        offset: const Offset(0, 2),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),

                        // Garis bawah
                        Container(
                          width: 100,
                          height: 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                _accentColor.withOpacity(0.7),
                                _accentSecondary.withOpacity(0.7),
                                Colors.transparent,
                              ],
                            ),
                          ),
                          margin: const EdgeInsets.only(top: 28),
                        ),

                        // Loading indicator
                        if (!_videoReady && !_videoError)
                          Padding(
                            padding: const EdgeInsets.only(top: 24),
                            child: AnimatedBuilder(
                              animation: _pulseController,
                              builder: (context, child) {
                                return Container(
                                  width: 20 + 4 * _pulseController.value,
                                  height: 20 + 4 * _pulseController.value,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: _accentColor.withOpacity(
                                        0.3 + 0.2 * _pulseController.value,
                                      ),
                                      width: 2,
                                    ),
                                  ),
                                  child: Center(
                                    child: Container(
                                      width: 6,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _accentColor.withOpacity(
                                          0.4 + 0.3 * _pulseController.value,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // ── SKIP BUTTON ──────────────────────────────────────────────────
            Positioned(
              top: 48,
              right: 20,
              child: MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                  onTap: _skipVideo,
                  child: AnimatedBuilder(
                    animation: _pulseController,
                    builder: (context, child) {
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: _accentColor.withOpacity(
                              0.4 + 0.2 * _pulseController.value,
                            ),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _accentColor.withOpacity(
                                0.1 + 0.1 * _pulseController.value,
                              ),
                              blurRadius: 16,
                              spreadRadius: 2,
                            ),
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.fast_forward_rounded,
                              color: _accentColor,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'LEWATI',
                              style: TextStyle(
                                color: _textColor,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 2,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),

            // ── ERROR BANNER ──────────────────────────────────────────────
            if (_videoError)
              Positioned(
                top: 100,
                left: 24,
                right: 24,
                child: AnimatedOpacity(
                  opacity: 1.0,
                  duration: const Duration(milliseconds: 500),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.orange.withOpacity(0.4),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.orange.withOpacity(0.1),
                          blurRadius: 20,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.info_outline_rounded,
                          color: Colors.orange.withOpacity(0.8),
                          size: 16,
                        ),
                        const SizedBox(width: 10),
                        Flexible(
                          child: Text(
                            "Video tidak tersedia, melanjutkan...",
                            style: TextStyle(
                              color: Colors.orange.withOpacity(0.8),
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              letterSpacing: 0.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            // ── BOTTOM INFO ────────────────────────────────────────────────
            Positioned(
              bottom: 32,
              left: 0,
              right: 0,
              child: FadeTransition(
                opacity: _textOpacityAnimation,
                child: Column(
                  children: [
                    if (!_videoReady || _videoError)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 500),
                              width: 8,
                              height: 8,
                              margin: const EdgeInsets.only(right: 8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _videoError
                                    ? Colors.orange
                                    : _accentColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: (_videoError
                                            ? Colors.orange
                                            : _accentColor)
                                        .withOpacity(0.5),
                                    blurRadius: 8,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              _videoError
                                  ? "Mode fallback aktif"
                                  : "Memuat...",
                              style: TextStyle(
                                fontSize: 10,
                                color: _textColor.withOpacity(0.5),
                                letterSpacing: 1.5,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      ),

                    Text(
                      'Klik di mana saja untuk melanjutkan',
                      style: TextStyle(
                        color: _textColor.withOpacity(0.3),
                        fontSize: 10.5,
                        fontStyle: FontStyle.italic,
                        letterSpacing: 1,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      "VOR4X",
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w300,
                        color: _accentColor.withOpacity(0.25),
                        letterSpacing: 10,
                        fontFamily: 'Orbitron',
                        shadows: [
                          Shadow(
                            color: _accentColor.withOpacity(0.2),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}