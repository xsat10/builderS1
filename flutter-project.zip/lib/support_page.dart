import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

// ═══════════════════════════════════════════════════════════
// 🎨 COLOR PALETTE - BIRU HITAM DOMINAN BIRU
// ═══════════════════════════════════════════════════════════
const Color bgDark      = Color(0xFF02060F);
const Color bgMid       = Color(0xFF071127);
const Color bgCard      = Color(0xFF0A1832);
const Color primaryBlue = Color(0xFF1976D2);
const Color accentBlue  = Color(0xFF2979FF);
const Color cyanBright  = Color(0xFF00E5FF);
const Color lightBlue   = Color(0xFF64B5F6);
const Color navyBlue    = Color(0xFF0D47A1);
const Color skyBlue     = Color(0xFF4FC3F7);
const Color white       = Colors.white;
const Color white54     = Colors.white54;
const Color white24     = Colors.white24;

const List<Shadow> _ts = [
  Shadow(color: Color(0xCC000000), blurRadius: 8, offset: Offset(0, 2)),
  Shadow(color: Color(0x99000000), blurRadius: 16, offset: Offset(0, 4)),
];

// ═══════════════════════════════════════════════════════════
// 🔤 SCRAMBLE LETTER - efek acak + sinar nyala-mati
// ═══════════════════════════════════════════════════════════
class _ScrambleLetter extends StatefulWidget {
  final String targetLetter;
  final bool isBlue;
  final double fontSize;
  const _ScrambleLetter({
    required this.targetLetter,
    required this.isBlue,
    this.fontSize = 16,
  });
  @override
  State<_ScrambleLetter> createState() => _ScrambleLetterState();
}

class _ScrambleLetterState extends State<_ScrambleLetter>
    with SingleTickerProviderStateMixin {
  static const String _chars =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$%&*<>/\\|';
  late String _displayLetter;
  Timer? _scrambleTimer;
  int _frame = 0;

  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  static const int _scrambleSpeed = 12;
  static const int _frameDelayMs = 60;

  @override
  void initState() {
    super.initState();
    _displayLetter = widget.targetLetter;
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    );
    _glowAnim = CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut);
    _glowCtrl.repeat();
    _startScramble();
  }

  void _startScramble() {
    _scrambleTimer?.cancel();
    _frame = 0;
    _scrambleTimer = Timer.periodic(
      const Duration(milliseconds: _frameDelayMs),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }
        if (_frame > _scrambleSpeed) {
          if (mounted) setState(() => _displayLetter = widget.targetLetter);
          timer.cancel();
        } else {
          final rc = _chars[math.Random().nextInt(_chars.length)];
          if (mounted) setState(() => _displayLetter = rc);
          _frame++;
        }
      },
    );
  }

  @override
  void dispose() {
    _scrambleTimer?.cancel();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightColor = widget.isBlue ? cyanBright : white;
    final midColor =
        widget.isBlue ? const Color(0xFF66D9FF) : const Color(0xFFB4DCFF);
    final darkColor =
        widget.isBlue ? const Color(0xFF003844) : const Color(0xFF333333);

    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (context, _) {
        final double t = _glowAnim.value;
        double intensity;
        if (t < 0.35) {
          intensity = t / 0.35;
        } else if (t < 0.55) {
          intensity = 1.0;
        } else if (t < 0.85) {
          intensity = 1.0 - ((t - 0.55) / 0.30);
        } else {
          intensity = 0.0;
        }
        intensity = intensity.clamp(0.0, 1.0);

        final Color currentColor =
            Color.lerp(darkColor, brightColor, intensity)!;

        return Text(
          _displayLetter,
          style: TextStyle(
            color: currentColor,
            fontSize: widget.fontSize,
            fontWeight: FontWeight.w900,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
            shadows: [
              Shadow(
                color: midColor.withOpacity(intensity * 0.9),
                blurRadius: 10 * intensity,
              ),
              Shadow(
                color: brightColor.withOpacity(intensity * 0.7),
                blurRadius: 22 * intensity,
              ),
              Shadow(
                color: brightColor.withOpacity(intensity * 0.4),
                blurRadius: 40 * intensity,
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ScrambleText extends StatelessWidget {
  final String text;
  final double fontSize;
  const _ScrambleText({required this.text, this.fontSize = 16});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(text.length, (i) {
        final ch = text[i];
        if (ch == ' ') return const SizedBox(width: 8);
        return _ScrambleLetter(
          targetLetter: ch,
          isBlue: i % 2 == 0,
          fontSize: fontSize,
        );
      }),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🔤 SCRAMBLE TITLE TEXT (untuk section title)
// ═══════════════════════════════════════════════════════════
class _ScrambleTitleText extends StatefulWidget {
  final String text;
  final double fontSize;
  const _ScrambleTitleText({required this.text, this.fontSize = 13});
  @override
  State<_ScrambleTitleText> createState() => _ScrambleTitleTextState();
}

class _ScrambleTitleTextState extends State<_ScrambleTitleText>
    with SingleTickerProviderStateMixin {
  static const String _chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$';
  late String _displayText;
  Timer? _scrambleTimer;
  int _frame = 0;

  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  static const int _scrambleSpeed = 10;
  static const int _frameDelayMs = 60;

  @override
  void initState() {
    super.initState();
    _displayText = widget.text;
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _glowAnim = CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut);
    _glowCtrl.repeat();
    _startScramble();
  }

  void _startScramble() {
    _scrambleTimer?.cancel();
    _frame = 0;
    _scrambleTimer = Timer.periodic(
      const Duration(milliseconds: _frameDelayMs),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }
        if (_frame > _scrambleSpeed) {
          if (mounted) setState(() => _displayText = widget.text);
          timer.cancel();
        } else {
          final chars = widget.text.split('');
          final newChars = List<String>.from(chars);
          for (int i = 0; i < chars.length; i++) {
            if (chars[i] == ' ') continue;
            if (_frame < _scrambleSpeed - 2) {
              newChars[i] = _chars[math.Random().nextInt(_chars.length)];
            }
          }
          if (mounted) setState(() => _displayText = newChars.join());
          _frame++;
        }
      },
    );
  }

  @override
  void dispose() {
    _scrambleTimer?.cancel();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (context, _) {
        final double t = _glowAnim.value;
        double intensity;
        if (t < 0.35) {
          intensity = t / 0.35;
        } else if (t < 0.55) {
          intensity = 1.0;
        } else if (t < 0.85) {
          intensity = 1.0 - ((t - 0.55) / 0.30);
        } else {
          intensity = 0.0;
        }
        intensity = intensity.clamp(0.0, 1.0);

        final Color c = Color.lerp(
          const Color(0xFF00384A),
          white,
          intensity,
        )!;

        return ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [
              cyanBright.withOpacity(0.6 + intensity * 0.4),
              white,
              accentBlue.withOpacity(0.6 + intensity * 0.4),
            ],
          ).createShader(bounds),
          child: Text(
            _displayText,
            style: TextStyle(
              color: c,
              fontSize: widget.fontSize,
              fontWeight: FontWeight.w900,
              fontFamily: 'Orbitron',
              letterSpacing: 2.5,
              shadows: [
                Shadow(
                  color: cyanBright.withOpacity(intensity * 0.8),
                  blurRadius: 12 * intensity,
                ),
                Shadow(
                  color: accentBlue.withOpacity(intensity * 0.6),
                  blurRadius: 22 * intensity,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🃏 GLASS NAME CARD - TRANSPARAN
// ═══════════════════════════════════════════════════════════
class _GlassNameCard extends StatefulWidget {
  final String name;
  final String subtitle;
  final IconData icon;
  final Color accentColor;
  final int delayIndex;
  const _GlassNameCard({
    required this.name,
    required this.subtitle,
    required this.icon,
    required this.accentColor,
    this.delayIndex = 0,
  });
  @override
  State<_GlassNameCard> createState() => _GlassNameCardState();
}

class _GlassNameCardState extends State<_GlassNameCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _floatCtrl;
  late Animation<double> _floatAnim;

  @override
  void initState() {
    super.initState();
    _floatCtrl = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000 + widget.delayIndex * 200),
    )..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: 0, end: 3).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _floatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _floatAnim,
      builder: (context, child) => Transform.translate(
        offset: Offset(0, -_floatAnim.value),
        child: child,
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.20),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: widget.accentColor.withOpacity(0.65),
            width: 1.4,
          ),
          boxShadow: [
            BoxShadow(
              color: widget.accentColor.withOpacity(0.30),
              blurRadius: 16,
              spreadRadius: 1,
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 4, sigmaY: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Icon bulat
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        widget.accentColor.withOpacity(0.85),
                        widget.accentColor.withOpacity(0.35),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: widget.accentColor.withOpacity(0.95),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: widget.accentColor.withOpacity(0.75),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Icon(
                    widget.icon,
                    color: Colors.white,
                    size: 17,
                    shadows: [
                      Shadow(
                        color: widget.accentColor,
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                // Nama
                Text(
                  widget.name,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.8,
                    height: 1.25,
                    shadows: [
                      Shadow(
                        color: widget.accentColor.withOpacity(0.7),
                        blurRadius: 10,
                      ),
                      const Shadow(
                        color: Colors.black,
                        blurRadius: 4,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                // Subtitle badge
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: widget.accentColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: widget.accentColor.withOpacity(0.35),
                    ),
                  ),
                  child: Text(
                    widget.subtitle,
                    style: TextStyle(
                      color: widget.accentColor,
                      fontSize: 7.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.8,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🏷️ SECTION TITLE - TRANSPARAN
// ═══════════════════════════════════════════════════════════
class _SectionTitle extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionTitle({required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 22, bottom: 4),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 1.5,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    cyanBright.withOpacity(0.6),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Icon(
            icon,
            color: cyanBright,
            size: 16,
            shadows: [Shadow(color: cyanBright, blurRadius: 8)],
          ),
          const SizedBox(width: 8),
          _ScrambleTitleText(text: title, fontSize: 13),
          const SizedBox(width: 8),
          Icon(
            icon,
            color: cyanBright,
            size: 16,
            shadows: [Shadow(color: cyanBright, blurRadius: 8)],
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1.5,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    cyanBright.withOpacity(0.6),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════
// 🎡 HEADER BANNER - GAMBAR BUNDAR + RING BERPUTAR
// ═══════════════════════════════════════════════════════════
class _HeaderBanner extends StatefulWidget {
  final String imagePath;
  const _HeaderBanner({required this.imagePath});

  @override
  State<_HeaderBanner> createState() => _HeaderBannerState();
}

class _HeaderBannerState extends State<_HeaderBanner>
    with TickerProviderStateMixin {
  late AnimationController _spinCtrl;
  late AnimationController _spinCtrl2;
  late AnimationController _floatCtrl;
  late Animation<double> _floatAnim;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    _spinCtrl2 = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat(reverse: true);
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: -3, end: 3).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _spinCtrl2.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 160,
        height: 160,
        child: AnimatedBuilder(
          animation: Listenable.merge([_spinCtrl, _spinCtrl2, _floatAnim]),
          builder: (context, child) {
            return Stack(
              alignment: Alignment.center,
              children: [
                // Ring luar - dashed berputar
                Transform.rotate(
                  angle: _spinCtrl.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(150, 150),
                    painter: _DashedRingPainter(
                      color: cyanBright.withOpacity(0.4),
                      radius: 72,
                    ),
                  ),
                ),
                // Ring dalam - solid berputar reverse
                Transform.rotate(
                  angle: _spinCtrl2.value * 2 * math.pi,
                  child: Container(
                    width: 138,
                    height: 138,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: accentBlue.withOpacity(0.25),
                        width: 1,
                      ),
                    ),
                  ),
                ),
                // Gambar bundar
                Transform.translate(
                  offset: Offset(0, _floatAnim.value),
                  child: Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: cyanBright.withOpacity(0.75),
                        width: 3,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: cyanBright.withOpacity(0.75),
                          blurRadius: 30,
                          spreadRadius: 2,
                        ),
                        BoxShadow(
                          color: accentBlue.withOpacity(0.45),
                          blurRadius: 60,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        widget.imagePath,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [cyanBright, accentBlue, navyBlue],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: const Icon(
                            Icons.code_rounded,
                            color: Colors.white,
                            size: 50,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// Painter untuk ring dashed
class _DashedRingPainter extends CustomPainter {
  final Color color;
  final double radius;
  _DashedRingPainter({required this.color, required this.radius});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final center = Offset(size.width / 2, size.height / 2);
    const dashCount = 24;
    const dashAngle = (2 * math.pi) / dashCount;

    for (int i = 0; i < dashCount; i++) {
      if (i % 2 == 0) {
        final startAngle = i * dashAngle;
        canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius),
          startAngle,
          dashAngle * 0.6,
          false,
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedRingPainter old) =>
      old.color != color || old.radius != radius;
}

// ═══════════════════════════════════════════════════════════
// 📄 SUPPORT PAGE
// ═══════════════════════════════════════════════════════════
class SupportPage extends StatefulWidget {
  const SupportPage({super.key});

  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const _ScrambleText(text: 'SUPPORT', fontSize: 16),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.5),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // 🖼️ BACKGROUND WALLPAPER
          Positioned.fill(
            child: Image.asset(
              'assets/images/dashboard.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [bgDark, bgMid, bgDark],
                  ),
                ),
              ),
            ),
          ),
          // Overlay gelap transparan biar konten kebaca
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    bgDark.withOpacity(0.55),
                    accentBlue.withOpacity(0.10),
                    bgDark.withOpacity(0.65),
                  ],
                ),
              ),
            ),
          ),
          // Konten utama
          SafeArea(
            top: true,
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ─── HEADER BANNER (GAMBAR BUNDAR) ───
                    const _HeaderBanner(
                      imagePath: 'assets/images/menu_header.jpg',
                    ),
                    const SizedBox(height: 20),

                    // ─── SECTION: DEVELOPER ─────────────
                    const _SectionTitle(
                      title: 'DEVELOPER',
                      icon: Icons.code_rounded,
                    ),
                    Center(
                      child: Text(
                        'Orang-orang di balik VOR4X',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.55),
                          fontSize: 10.5,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: const [
                        Expanded(
                          child: _GlassNameCard(
                            name: 'ZILXPEDIA',
                            subtitle: 'PEMILIK',
                            icon: Icons.star_rounded,
                            accentColor: cyanBright,
                            delayIndex: 0,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _GlassNameCard(
                            name: 'DANZ',
                            subtitle: 'CO-DEV',
                            icon: Icons.terminal_rounded,
                            accentColor: accentBlue,
                            delayIndex: 1,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _GlassNameCard(
                            name: 'LEO',
                            subtitle: 'BACKEND',
                            icon: Icons.memory_rounded,
                            accentColor: lightBlue,
                            delayIndex: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ─── SECTION: FRIENDS ───────────────
                    const _SectionTitle(
                      title: 'FRIENDS',
                      icon: Icons.people_alt_rounded,
                    ),
                    Center(
                      child: Text(
                        'Partner & sahabat setia',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.55),
                          fontSize: 10.5,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: const [
                        Expanded(
                          child: _GlassNameCard(
                            name: 'DANZ',
                            subtitle: 'FRIEND',
                            icon: Icons.person_rounded,
                            accentColor: cyanBright,
                            delayIndex: 0,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _GlassNameCard(
                            name: 'ARYA WIRA',
                            subtitle: 'FRIEND',
                            icon: Icons.person_rounded,
                            accentColor: accentBlue,
                            delayIndex: 1,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: const [
                        Expanded(
                          child: _GlassNameCard(
                            name: 'BARA',
                            subtitle: 'FRIEND',
                            icon: Icons.person_rounded,
                            accentColor: lightBlue,
                            delayIndex: 2,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _GlassNameCard(
                            name: 'RAHMAN',
                            subtitle: 'FRIEND',
                            icon: Icons.person_rounded,
                            accentColor: primaryBlue,
                            delayIndex: 3,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ─── SECTION: SYSTEM SUPPORTERS ────
                    const _SectionTitle(
                      title: 'SYSTEM SUPPORTERS',
                      icon: Icons.favorite_rounded,
                    ),
                    Center(
                      child: Text(
                        'Support sistem & server',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.55),
                          fontSize: 10.5,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: const [
                        Expanded(
                          child: _GlassNameCard(
                            name: 'BUYER VOR4X',
                            subtitle: 'OFFICIAL BUYER',
                            icon: Icons.shopping_bag_rounded,
                            accentColor: cyanBright,
                            delayIndex: 0,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _GlassNameCard(
                            name: 'VORTEX',
                            subtitle: 'SUPPORTER',
                            icon: Icons.shield_rounded,
                            accentColor: accentBlue,
                            delayIndex: 1,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // ─── FOOTER ─────────────────────────
                    Center(child: _buildFooter()),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.25),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: cyanBright.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(
                color: cyanBright.withOpacity(0.2),
                blurRadius: 16,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.star, color: cyanBright, size: 12),
                  const SizedBox(width: 8),
                  Text(
                    'VOR4X TEAM',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: cyanBright.withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.star, color: cyanBright, size: 12),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          '© 2026 · All Rights Reserved',
          style: TextStyle(
            color: Colors.white.withOpacity(0.5),
            fontSize: 10,
            letterSpacing: 0.8,
          ),
        ),
      ],
    );
  }
}