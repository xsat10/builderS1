# TikTok Downloader (Flutter)

Aplikasi download video TikTok (no watermark) & foto slide, fetch data via API tikwm.com.

## Struktur

```
tiktok_downloader/
├── lib/
│   ├── main.dart              # UI utama
│   └── services/
│       └── tiktok_service.dart # fetch + parsing data TikTok
├── pubspec.yaml
└── .github/workflows/build-apk.yml
```

Folder `android/` dan `ios/` sengaja TIDAK di-commit — akan otomatis dibuat
oleh GitHub Actions saat build (lewat `flutter create .`), jadi kamu gak perlu
laptop/Flutter SDK di lokal sama sekali.

## Cara pakai

1. Buat repo baru di GitHub, upload semua isi folder ini (drag & drop lewat
   web GitHub juga bisa, atau `git push` kalau ada akses terminal/Termux).
2. Buka tab **Actions** di repo → workflow "Build APK" akan otomatis jalan
   setiap push ke branch `main`, atau trigger manual lewat "Run workflow".
3. Setelah selesai (~3-5 menit), buka run yang sukses → bagian **Artifacts**
   → download `tiktok-downloader-apk.zip`, di dalamnya ada `app-release.apk`.

## Catatan

- Endpoint tikwm kadang rate-limit / berubah struktur respons — kalau fetch
  gagal, cek dulu format JSON terbaru dari API tersebut.
- Download foto/video disimpan ke folder dokumen internal app, lalu dibuka
  lewat share sheet (`share_plus`) supaya user bisa simpan ke galeri/folder
  manapun tanpa perlu izin storage tambahan.
- Kalau mau APK otomatis dikirim ke Telegram (kayak project Vanitas), tinggal
  tambah step `curl` ke Telegram Bot API di akhir workflow, sama seperti yang
  sudah pernah kamu buat sebelumnya.
